module MEDYANVis

using MEDYAN
using MEDYAN: Context, SysDef, CubicGrid, Boundary
using Reexport: @reexport
@reexport using MeshCat
using Colors
import GeometryBasics
using Setfield
using StaticArrays
using Random123: Random123
using Meshing: isosurface, MarchingTetrahedra
using LinearAlgebra

export draw_context!

# Faster norm functions, these may be worse for floating point error.
# See https://github.com/JuliaArrays/StaticArrays.jl/pull/975#issuecomment-1436115140

@inline _sqrt_fast(x::Union{Float16,Float32,Float64}) = Base.sqrt_llvm(x)
@inline _sqrt_fast(x) = sqrt(x)
@inline norm_fast(v) = _sqrt_fast(sum(abs2, v))

@inline normalize_fast(v) = v * inv(norm_fast(v))

"""
Visualize a context
"""
function draw_context!(vis, c::Context, systemdefs::SysDef=c.sys_def)
    #drawdiffusing!(vis["diffusing"], c.grid, c.chemistryengine, systemdefs)
    drawgrid!(vis["grid"],c.grid)
    drawballs!(vis["balls"], c.balls)
    drawhalfedgemeshes!(vis["membrane"], c.membranes; scale=1e-3)
    drawfilaments!(vis["filaments"], c)
    drawfilaments_tubes!(vis["filamentTubes"], c, map(x->x.radius,c.filamentmechparams), systemdefs)
    drawlinks!(vis["links"], c)
    drawboundary!(vis["chemboundary"],c.grid,c.chemboundary)
    drawboundary!(vis["mechboundary"],c.grid,c.mechboundary) 
    drawvertices!(vis["vertex"], c.membranes;scale=1e-3)
    drawintripoints!(vis["inTriPoints"], c.membranes;scale=1e-3)
end

"""
Visualize balls with sphere meshes.
"""
function drawballs!(vis, balls; segments=8)
    scale = 1000
    mymesh = zeromesh()
    for i in eachindex(balls.position)
        pos = SVector{3,Float32}(balls.position[i] ./ scale)
        radius = Float32(balls.radius[i] / scale)
        mymesh = unionmesh(mymesh, spheremesh(pos, radius, segments))
    end
    setobject!(vis, mymesh, MeshCat.MeshPhongMaterial(color=RGB(0.8, 0.2, 0.2)))
end

"""
Generate a sphere mesh centered at `center` with given `radius`.
`segments` controls the tessellation (latitude and longitude divisions).

Written by LLM Claude
"""
function spheremesh(center::SVector{3,Float32}, radius::Float32, segments::Integer)
    # Generate vertices for a UV sphere
    vertices = Vector{SVector{3,Float32}}()
    triInd = Vector{SVector{3,Int32}}()
    
    # Add top pole
    push!(vertices, center + SA_F32[0, 0, radius])
    
    # Add latitude rings
    for i in 1:(segments-1)
        θ = Float32(π * i / segments)
        sinθ, cosθ = sincos(θ)
        z = radius * cosθ
        r_ring = radius * sinθ
        for j in 0:(segments-1)
            ϕ = Float32(2π * j / segments)
            sinϕ, cosϕ = sincos(ϕ)
            push!(vertices, center + SA_F32[r_ring * cosϕ, r_ring * sinϕ, z])
        end
    end
    
    # Add bottom pole
    push!(vertices, center + SA_F32[0, 0, -radius])
    
    # Triangles for top cap
    for j in 0:(segments-1)
        j_next = mod(j + 1, segments)
        push!(triInd, SA[1, 2 + j, 2 + j_next])
    end
    
    # Triangles for middle bands
    for i in 0:(segments-3)
        for j in 0:(segments-1)
            j_next = mod(j + 1, segments)
            v1 = 2 + i * segments + j
            v2 = 2 + i * segments + j_next
            v3 = 2 + (i + 1) * segments + j
            v4 = 2 + (i + 1) * segments + j_next
            push!(triInd, SA[v1, v3, v2])
            push!(triInd, SA[v2, v3, v4])
        end
    end
    
    # Triangles for bottom cap
    bottom_pole = length(vertices)
    last_ring_start = 2 + (segments - 2) * segments
    for j in 0:(segments-1)
        j_next = mod(j + 1, segments)
        push!(triInd, SA[last_ring_start + j, bottom_pole, last_ring_start + j_next])
    end
    
    faces = copy(reinterpret(Int32, triInd))
    GeometryBasics.Mesh(GeometryBasics.Point.(vertices), faces, GeometryBasics.TriangleFace, 3)
end

"""
Visualize boundingplanes and boundingcapsules within one compartment of the grid
"""
function drawboundary!(vis, grid::CubicGrid, boundary::Boundary)
    scale=1000
    samplespergrid = 8
    grid_spacing = grid.spacing/samplespergrid
    N = (grid.n .* samplespergrid) .+ 2
    width = (N .- 1) * grid_spacing
    tsdf = MEDYAN.boundary_tsdf(Tuple(N), grid_spacing, grid_spacing*2, boundary)
    xr,yr,zr = ntuple(i->LinRange(-width[i]/2,+width[i]/2, N[i]),3)
    points, faces = isosurface(tsdf, MarchingTetrahedra(), xr, yr, zr)
    pointsf = GeometryBasics.Point3f.(points)
    pointsf .*= (1//scale)
    facestri = GeometryBasics.TriangleFace{Int}.(faces)
    mesh = GeometryBasics.Mesh(pointsf, facestri)
    mat = MeshPhongMaterial(color=RGBA(0, 1, 1, 0.5),wireframe=true)
    setobject!(vis, mesh, mat)
end

"""
Visualize Links with lines connected to a point offset from the attached places
"""
function drawlinks!(vis, c::Context; size=0.002)
    scale=1000
    num_filament_types= num_fila_types(c)
    _num_link_types= num_link_types(c)
    filamentcolors= distinguishable_colors(num_filament_types,[RGB(1,1,1), RGB(0,0,0),],dropseed=true)
    link_colors= distinguishable_colors(_num_link_types,[RGB(1,1,1); RGB(0,0,0); filamentcolors],dropseed=true)
    foreach(enumerate(c.link_manager.link_data)) do (ltid, d)
        name = string(c.link_manager.names[ltid])
        linesegs= Vector{SVector{3,Float32}}()
        nodepoints= Vector{SVector{3,Float32}}()
        for (lidx, tags) in enumerate(d.per_link.tags)
            append_place_connection!(linesegs, nodepoints, tags, c, UInt64(lidx) + UInt64(ltid)<<32;scale)
        end
        setobject!(vis[name]["lines"], Object(PointCloud(linesegs), LineBasicMaterial(color=link_colors[ltid]), "LineSegments"))
        setobject!(vis[name]["points"], 
                PointCloud(nodepoints),
                PointsMaterial(; size=size, color=link_colors[ltid], vertexColors=0))
    end
end


"""
Append the line segments and node to connect a set of tags
with a arrow on the plus end.
"""
function append_place_connection!(
        linesegs::Vector{SVector{3,Float32}},
        points::Vector{SVector{3,Float32}},
        tags,
        c::Context,
        uid::UInt64,
        ;
        scale = 1000,
    )
    avg_pos::SVector{3, Float32} = zero(SVector{3, Float32})
    n_pos = 0
    for tag in tags
        MEDYAN.is_null(tag) && continue
        avg_pos += MEDYAN.get_position(c, tag)
        n_pos += 1
    end
    if iszero(n_pos)
        return
    end
    avg_pos *= inv(n_pos)
    # add random offset to get node point
    rng = Random123.Philox2x(uid)
    node_p = avg_pos + 10.0*randn(rng, SVector{3, Float32})
    push!(points, node_p * inv(scale))
    for tag in tags
        MEDYAN.is_null(tag) && continue
        local p = MEDYAN.get_position(c, tag)
        push!(linesegs, p * inv(scale))
        push!(linesegs, node_p * inv(scale))
    end
end


"""
Visualize filaments with lines and points
"""
function drawfilaments!(vis, c::MEDYAN.Context, size=0.002)
    systemdefs = c.sys_def
    scale=1000
    num_filament_types = num_fila_types(c)
    filamentcolors= distinguishable_colors(num_filament_types,[RGB(1,1,1), RGB(0,0,0),],dropseed=true)
    for ftid in 1:num_filament_types
        radius = c.filamentmechparams[ftid].radius
        use_twist = use_twist = MEDYAN.is_twistable(c.filamentmechparams[ftid])
        num_monomer_states= length(systemdefs.state[ftid]) + 1
        monomerpoints=[Vector{SVector{3,Float32}}() for i in 1:num_monomer_states]
        linesegs= Vector{SVector{3,Float32}}()
        monomercolors= distinguishable_colors(num_monomer_states,[RGB(1,1,1); RGB(0,0,0); filamentcolors],dropseed=true)
        for fil_idx in 1:num_fila(c; type=ftid)
            for mid in fila_mono_ids(c, FilaIdx(ftid, fil_idx))
                local place = FilaMonoIdx(FilaIdx(ftid, fil_idx), mid)
                local state = MEDYAN.get_chem_state(c, place).monomer_state
                local pos = MEDYAN.get_position(c, place) ./ scale
                if use_twist
                    # Move monomer points out half a radius
                    local dirs = MEDYAN.get_directions(c, place)
                    pos = pos + (radius/scale/2)*dirs[2]
                end
                push!(monomerpoints[state+1],pos)
            end
            local node_pos = fila_node_positions(c, FilaIdx(ftid, fil_idx)) ./ scale
            for i in 2:length(node_pos)
                push!(linesegs, node_pos[i-1])
                push!(linesegs, node_pos[i])
            end
        end
        filamenttypesymbol= collect(keys(systemdefs.filament))[ftid]
        monomerstatesymbols= [:null ;collect(keys(systemdefs.state[ftid]))]
        setobject!(vis[filamenttypesymbol], Object(PointCloud(linesegs), LineBasicMaterial(color=filamentcolors[ftid]), "LineSegments"))
        for mstate in 1:num_monomer_states
            setobject!(vis[filamenttypesymbol][monomerstatesymbols[mstate]], 
                PointCloud(monomerpoints[mstate]),
                PointsMaterial(; size=size, color=monomercolors[mstate], vertexColors=0))
        end
        setvisible!(vis[filamenttypesymbol][:null],false)
    end
end

"""
Visualize filaments with tubes
"""
function drawfilaments_tubes!(vis, c::Context, radii, systemdefs::SysDef, size=0.002)
    scale=1000
    num_filament_types= num_fila_types(c)
    filamentcolors= distinguishable_colors(num_filament_types,[RGB(1,1,1), RGB(0,0,0),],dropseed=true)
    for ftid in 1:num_filament_types
        mymesh= zeromesh()
        for fil_idx in 1:num_fila(c; type=ftid)
            fila = FilaIdx(ftid, fil_idx)
            nodepos = copy(fila_chem_positions(c, FilaIdx(ftid, fil_idx)))
            nodepos[begin] = get_position(c, FilaTipIdx(fila, true))
            nodepos[end] = get_position(c, FilaTipIdx(fila, false))
            mymesh = unionmesh(mymesh, pathExtrudeGenerateWithCaps(nodepos./scale, Float32(radii[ftid]/scale), 8))
        end
        # @show mymesh
        filamenttypesymbol= collect(keys(systemdefs.filament))[ftid]
        setobject!(vis[filamenttypesymbol], mymesh, MeshCat.MeshPhongMaterial(color=filamentcolors[ftid]))
    end
end

"""
Add halfedges to visualization.
"""
function drawhalfedgemeshes!(vis, meshes; scale::Real=1)
    np_tillnow = 0
    nf_tillnow = 0
    ps = Vector{GeometryBasics.Point3f}()
    fs = Vector{GeometryBasics.TriangleFace{Int}}()
    for m ∈ meshes
        resize!(ps, np_tillnow + length(m.vertices))
        for vindex ∈ 1:length(m.vertices)
            ps[np_tillnow + vindex] = convert(GeometryBasics.Point3f, m.vertices.attr.coord[vindex] .* scale)
        end

        resize!(fs, nf_tillnow + length(m.triangles))
        for tindex ∈ 1:length(m.triangles)
            local f = GeometryBasics.TriangleFace{Int}(0,0,0)
            local fi = 0
            for h ∈ MEDYAN.HalfedgesInTriangle(m, MEDYAN.IT(tindex))
                fi += 1
                f = @set f[fi] = (MEDYAN.target(m, h).value + np_tillnow)
            end
            fs[nf_tillnow + tindex] = f
        end

        np_tillnow = length(ps)
        nf_tillnow = length(fs)
    end
	mesh = GeometryBasics.Mesh(ps, fs)
	setobject!(vis["halfedgemesh"], mesh, MeshCat.MeshPhongMaterial(wireframe=true))
end

"""
Visualize diffusing species with point clouds
"""
function drawdiffusing!(vis, grid, rdmesampler::MEDYAN.RDMESampler, systemdefs::SysDef; size=0.02)
    nds= length(systemdefs.diffusing)
    colors= distinguishable_colors(nds,[RGB(1,1,1), RGB(0,0,0),],dropseed=true)
    for dsid in 1:nds
        drawrandomgridpoints!(vis[collect(keys(systemdefs.diffusing))[dsid]],grid,rdmesampler.diffusingcounts[dsid,:],colors[dsid],size)
    end
end

"""
Visualize a grid.
Set two objects in a MeshCat vis, "outer" and  "inner"
"""
function drawgrid!(vis,grid::CubicGrid)
    scale=1000
    #first build up a vector of pairs of points to draw lines
    outerpoints=Vector{SVector{3,Float32}}()
    for axis in 1:3
        for sideaxis in filter(≠(axis),1:3)
            lastaxis= filter(≠(sideaxis),filter(≠(axis),1:3))[1]
            for i in 0:grid.n[sideaxis]
                point1= zeros(3)
                point1[sideaxis]= i*grid.spacing/scale
                point2= copy(point1)
                point2[axis]= grid.n[axis]*grid.spacing/scale
                push!(outerpoints,point1)
                push!(outerpoints,point2)
                point3= copy(point1)
                point3[lastaxis]= grid.n[lastaxis]*grid.spacing/scale
                point4= copy(point2)
                point4[lastaxis]= grid.n[lastaxis]*grid.spacing/scale
                push!(outerpoints,point3)
                push!(outerpoints,point4)
            end
        end
    end
    outerpoints .+= Ref(MEDYAN.cornerof(grid)/scale)
    innerpoints=Vector{SVector{3,Float32}}()
    for axis in 1:3
        iaxis,jaxis = filter(≠(axis),1:3)
        for i in 1:(grid.n[iaxis]-1)
            for j in 1:(grid.n[jaxis]-1)
                point1= zeros(3)
                point1[iaxis]= i*grid.spacing/scale
                point1[jaxis]= j*grid.spacing/scale
                point2= copy(point1)
                point2[axis]= grid.n[axis]*grid.spacing/scale
                push!(innerpoints,point1)
                push!(innerpoints,point2)
            end
        end
    end
    innerpoints .+= Ref(MEDYAN.cornerof(grid)/scale)
    setobject!(vis["outer"], Object(PointCloud(outerpoints), LineBasicMaterial(color=RGB(0)), "LineSegments"))
    setobject!(vis["inner"], Object(PointCloud(innerpoints), LineBasicMaterial(color=RGB(0)), "LineSegments"))
end

"""
Fill random points in a grid.
pointcount is a vector of point counts per compartment,
    indexed by compartment id.
"""
function drawrandomgridpoints!(vis,grid,pointcount,color,size=0.02)
    scale= 1000
    points=Vector{SVector{3,Float32}}(undef,sum(pointcount))
    pid=0
    for cid in 1:length(pointcount)
        for i in 1:pointcount[cid]
            pid+=1
            points[pid]= MEDYAN.randompoint(grid,cid) ./ scale
        end
    end
    setobject!(vis, PointCloud(points),PointsMaterial(; size=size, color=color, vertexColors=0))
end



"""
Append hemisphere cap vertices and faces to existing arrays.

The base ring (at `center`, radius `radius`) aligns with the tube endpoint ring
via the frame (`n0`, `n1`). `axis` is the outward direction of the cap.
"""
function add_hemispherecap!(
    vertices::Vector{SVector{3,Float32}},
    triInd::Vector{SVector{3,Int32}},
    center::SVector{3,Float32},
    axis::SVector{3,Float32},
    n0::SVector{3,Float32},
    n1::SVector{3,Float32},
    radius::Float32,
    sides::Integer,
    lat_rings::Integer,
)
    base_idx = Int32(length(vertices))

    # Latitude rings from equator (φ=0) to just below pole.
    for i in 0:(lat_rings-1)
        φ = Float32(π/2 * i / lat_rings)
        r_ring = radius * cos(φ)
        z_off  = radius * sin(φ)
        for j in 0:(sides-1)
            a = Float32(2π * j / sides)
            push!(vertices, center + axis*z_off + n0*(r_ring*cos(a)) + n1*(r_ring*sin(a)))
        end
    end

    # Pole at center + axis*radius
    push!(vertices, center + axis*radius)
    pole_idx = Int32(length(vertices))

    # Faces between consecutive latitude rings
    for i in 0:(lat_rings-2)
        for j in 0:(sides-1)
            j_next = mod(j+1, sides)
            v1 = base_idx + Int32(i*sides + j + 1)
            v2 = base_idx + Int32(i*sides + j_next + 1)
            v3 = base_idx + Int32((i+1)*sides + j + 1)
            v4 = base_idx + Int32((i+1)*sides + j_next + 1)
            push!(triInd, SA[v1, v3, v2])
            push!(triInd, SA[v2, v3, v4])
        end
    end

    # Faces from last latitude ring to pole
    last_ring_base = base_idx + Int32((lat_rings-1)*sides)
    for j in 0:(sides-1)
        j_next = mod(j+1, sides)
        v1 = last_ring_base + Int32(j + 1)
        v2 = last_ring_base + Int32(j_next + 1)
        push!(triInd, SA[v1, pole_idx, v2])
    end
end

"""
Generate tube mesh with hemisphere caps at both ends.

The path should already include the actual tip positions as first and last points
(from `get_position(c, FilaTipIdx(...))`). Hemisphere caps of radius `radius` are
placed at each end, aligned with the tube's endpoint rings via the Bishop frame.
"""
function pathExtrudeGenerateWithCaps(path, radius::Float32, sides::Integer)
    path = SVector{3,Float32}.(path)
    numVertices = length(path)
    @assert numVertices ≥ 2 "path must have at least two points"

    vertices = Vector{SVector{3,Float32}}()
    triInd = Vector{SVector{3,Int32}}()

    # === Start frame ===
    seg = normalize_fast(path[2]-path[1])
    n0 = if abs(seg[1]) < abs(seg[2])
        cross(seg, SA_F32[1,0,0])
    else
        cross(seg, SA_F32[0,1,0])
    end
    n0 = normalize_fast(n0)
    n1 = normalize_fast(cross(n0, seg))
    seg_start, n0_start, n1_start = seg, n0, n1

    # === First ring ===
    for j in 0:(sides-1)
        a = Float32(j*2π/sides)
        push!(vertices, path[1] + n0*radius*cos(a) + n1*radius*sin(a))
    end

    # === Propagate rings (same as pathExtrudeGenerate) ===
    segn = seg
    for i in 2:numVertices
        segn = normalize_fast(i == numVertices ? segn : path[i+1]-path[i])
        t = normalize_fast(seg+segn)
        dot_seg_t = seg ⋅ t
        for j in 0:(sides-1)
            pp = vertices[(i-2)*sides + j + 1]
            x = dot(path[i]-pp, t) / dot_seg_t
            push!(vertices, x*seg+pp)
        end
        seg = segn
    end
    seg_end = segn

    # === Tube faces ===
    for i in 0:(numVertices-2)
        for j in 0:(sides-1)
            push!(triInd, SA[
                i*sides + j + 1,
                (i+1)*sides + j + 1,
                i*sides + mod(j+1,sides) + 1,
            ])
            push!(triInd, SA[
                i*sides + mod(j+1,sides) + 1,
                (i+1)*sides + j + 1,
                (i+1)*sides + mod(j+1,sides) + 1,
            ])
        end
    end

    # === End frame: derive n0_end from the last ring vertex at j=0 ===
    n0_end = normalize_fast(vertices[(numVertices-1)*sides + 1] - path[numVertices])
    n1_end = normalize_fast(cross(n0_end, seg_end))

    lat_rings = max(2, sides ÷ 2)

    # Minus-end cap: hemisphere of radius `radius` at path[1] (the tip), dome faces outward
    add_hemispherecap!(vertices, triInd, path[1], -seg_start, n0_start, n1_start, radius, sides, lat_rings)

    # Plus-end cap: hemisphere of radius `radius` at path[end] (the tip), dome faces outward
    add_hemispherecap!(vertices, triInd, path[numVertices], seg_end, n0_end, n1_end, radius, sides, lat_rings)

    faces = copy(reinterpret(Int32, triInd))
    GeometryBasics.Mesh(GeometryBasics.Point.(vertices), faces, GeometryBasics.TriangleFace, 3)
end

"""
This function transforms a path to a mesh of tubes.
The returned mesh is a GeometryBasics.Mesh

Copied from C++ medyan, originally written by Haoran Ni (drelatgithub)


Parameters
//   - path:  the container where the coordinates of beads can be found.
//   - radius:  the radius of the tube.
//   - sides:   the number of sides of the tube.

"""
function pathExtrudeGenerate(path, radius::Float32, sides::Integer)
    path = SVector{3,Float32}.(path)
    numVertices = length(path)
    numTubeVertices = sides*numVertices
    numTriangles = (numVertices-1)*2*sides
    vertices = Vector{SVector{3,Float32}}()
    sizehint!(vertices,numTubeVertices)
    triInd = Vector{SVector{3,Int32}}()
    sizehint!(triInd,numTriangles)
    @assert numVertices ≥ 2 "path must have at least two points"

    # Locate first circle
    seg = normalize_fast(path[2]-path[1])
    n0 = if abs(seg[1]) < abs(seg[2])
        cross(seg,SA_F32[1,0,0])
    else
        cross(seg,SA_F32[0,1,0])
    end
    n0 = normalize_fast(n0)
    n1 = normalize_fast(cross(n0,seg))
    
    for j in 0:(sides-1)
        a = j*2*π/sides
        xa = radius*cos(a)
        ya = radius*sin(a)
        point = path[1] + n0*xa + n1*ya
        push!(vertices,point)
    end

    segn = seg
    # Propagate circles
    for i in 2:numVertices
        segn = normalize_fast(i == numVertices ? segn : path[i+1] - path[i])
        t = normalize_fast(seg+segn)
        dot_seg_t = seg ⋅ t
        for j in 0:(sides-1)
            # Solve for p_new given:
            #   dot(p_new - coords[indices[i]], t) = 0
            #   p_new = x * seg + pp
            pp = vertices[(i-2)*sides + j + 1]
            x = dot(path[i] - pp,t)/dot_seg_t
            push!(vertices,x * seg + pp)
        end
        seg = segn
    end

    # Make indices of faces
    for i in 0:(numVertices-2)
        for j in 0:(sides-1)
            # First triangle
            push!(triInd, SA[
                i*sides + j + 1,
                (i+1)*sides + j + 1,
                i*sides + mod(j+1,sides) + 1,
            ])
            # Second triangle
            push!(triInd, SA[
                i*sides + mod(j+1,sides) + 1,
                (i+1)*sides + j + 1,
                (i+1)*sides + mod(j+1,sides) + 1,
            ])
        end
    end

    #combine into a GeometryBasics.Mesh
    faces = copy(reinterpret(Int32,triInd))
    GeometryBasics.Mesh(GeometryBasics.Point.(vertices),faces,GeometryBasics.TriangleFace, 3)
end

"""
Combine two meshes
"""
function unionmesh(mesh1, mesh2)
    points1 = copy(GeometryBasics.coordinates(mesh1))
    points2 = copy(GeometryBasics.coordinates(mesh2))
    faces1 = copy(reinterpret(Int32,GeometryBasics.faces(mesh1)))
    faces2 = copy(reinterpret(Int32,GeometryBasics.faces(mesh2)))
    newfaces2 = faces2 .+ Int32(length(points1))
    newfaces = [faces1; newfaces2]
    newpoints = [points1; points2]
    GeometryBasics.Mesh(newpoints,newfaces,GeometryBasics.TriangleFace, 3)
end

"""
Return an emptymesh
"""
function zeromesh()
    vertices = Vector{SVector{3,Float32}}()
    faces = Vector{Int32}()
    GeometryBasics.Mesh(GeometryBasics.Point.(vertices),faces,GeometryBasics.TriangleFace, 3)
end

"""
Visualize vertices with points. Coloring based on the states of verteices.
"""
function drawvertices!(vis, membranes;scale::Real=1)
    zerostate_vertices = Vector{GeometryBasics.Point3f}()
    inactive_vertices = Vector{GeometryBasics.Point3f}()
    active_vertices = Vector{GeometryBasics.Point3f}()
    for m ∈ membranes
        num_vertex_states = length(m.vertices)#use different colors to distinguish different vertexstates
        for vindex ∈ 1:num_vertex_states
            vertex_point = convert(GeometryBasics.Point3f, m.vertices.attr.coord[vindex].*scale)#.* scale
            if m.vertices.attr.vertex_state[vindex] == 0
                push!(zerostate_vertices, vertex_point)
            elseif m.vertices.attr.vertex_state[vindex] == 1
                push!(inactive_vertices, vertex_point)
            elseif m.vertices.attr.vertex_state[vindex] == 2
                push!(active_vertices, vertex_point)
            end
        end
    end
    setobject!(vis["zerostate vertices"], PointCloud(zerostate_vertices), PointsMaterial(size=0.01, color=RGBA(0,0,1,0.5), vertexColors=0))
    setobject!(vis["inactive vertices"], PointCloud(inactive_vertices), PointsMaterial(size=0.01, color=RGBA(1,0,0,0.5), vertexColors=0))
    setobject!(vis["active vertices"], PointCloud(active_vertices), PointsMaterial(size=0.01, color=RGBA(0,1,0,0.5), vertexColors=0))
end

"""
Visualize in triangle points.
"""
function drawintripoints!(vis, membranes;scale::Real=1)
    p = Vector{GeometryBasics.Point3f}()
    for m in membranes
        n = length(m.metaattr.intripoints)#use different colors to distinguish different vertexstates
        for i in 1:n
            push!(p, MEDYAN.intripoint_cartesian(m, i).*scale)
        end
    end
    setobject!(vis, PointCloud(p), PointsMaterial(size=0.01, color=RGBA(0,0,1,0.5), vertexColors=0))
end

end # module MEDYANVis
