using MEDYAN
using Test
using MEDYANVis
using StaticArrays
using Setfield

@testset "draw_context! with vertices and cadherins" begin
    grid= CubicGrid((3,1,1),500.0)
    corner = MEDYAN.cornerof(grid)
    agentnames = MEDYAN.AgentNames(
        filamentnames= [(:a,[
                                :m,
                                :k,
                                :g,
                            ]),
        ],
    )
    s = MEDYAN.SysDef(agentnames)
    default_actin = MEDYAN.ACTIN_FIL_PARAMS
    add_filament_params!(s, :a, @set(default_actin.numpercylinder = 2)) #number of monomers in each cylinder 40 to 2
    # Initiate a membrane
    m = MEDYAN.create_membranemesh()
    trilist = [SA[1,2,3], SA[3,2,4]]
    vertlist = [SA[0,200,200], SA[300,0,0], SA[1000,500,500], SA[600,500,1]] .+ Ref(corner)
    id = [222,777,888,999]
    vertexstate = [1, 2, 1, 3]
    MEDYAN.initmesh!(m,(; vertlist, trilist, id, vertexstate))


    #Add cadherin to the the system
    MEDYAN.add_link_type!(s;
        name = :filaver,
        places = [MembVertIdx(), FilaMonoIdx()],
        bonds=[
            (;
                bond=MEDYAN.DistanceRestraint(),
                input=(1,2),
                state=(;L0=NaN,),
                param=(;k=8.0,),
            ),
        ],
        reactions = [[
            (; # Test reaction on the membrane vertex place
                name = :a,
                affect! = Returns(1),
                rate = Returns(2.0),
            ),
            (;
                name = :unbinding,
                affect! = (c::MEDYAN.Context; link, chem_voxel, kwargs...) -> let
                    local mt, pt = link2tags(c, link)
                    remove_link!(c, link)
                    #set the new monomer states
                    update_fila_mono_state!(c, mt, :k)
                    update_fila_mono_state!(c, pt, :k)
                    1
                end,
                rate = MEDYAN.LinkRateSlipBond(f0 = 4.9, k0 = 2.0),
            ),
        ]],
    )

    c = MEDYAN.Context(s,grid)
    push!(c.membranes, m)

    MEDYAN.helper_update_allverticesincompartments!(c)

    #Initiate filament
    nmon = 10
    monomerstates = zeros(MonomerState,10)
    monomerstates[1] = s.state.a.m
    monomerstates[end] = s.state.a.g
    monomerstates[2:end-1] .= s.state.a.k
    nodepositions = [SA[490.0, 200.0, 200.0],SA[502.0, 200.0, 200.0],SA[509.0, 200.0, 200.0]] .+ Ref(corner)
    node_mids = [0, 2, 10, ]
    make_fila!(c;
            type= 1,
            mono_states= monomerstates,
            node_mids,
            node_positions= nodepositions,
        )
        
    @testset "visualization of vertices" begin
        vis = Visualizer()
        draw_context!(vis, c, s)
        setvisible!(vis["/meshcat/grid"],true)
        setvisible!(vis["/meshcat/vertex"],true)
        
        render(vis)
        # delete!(vis)
        # vis = nothing
    end

    @testset "visualization of cadherins" begin
        c1 = deepcopy(c)
        # Add three cadherins in different compartments
        place1 = MembVertIdx(1, 4)
        place2 = FilaMonoIdx(FilaIdx(1,1), 7)
        place3 = MembVertIdx(1, 1)
        place4 = FilaMonoIdx(FilaIdx(1,1), 0)
        place5 = MembVertIdx(1, 2)
        place6 = FilaMonoIdx(FilaIdx(1,1), 1)

        MEDYAN.make_link!(c1; type = :filaver, places = (place1, place2),)# cid = 2
        MEDYAN.make_link!(c1; type = :filaver, places = (place3, place4),)# cid = 1
        MEDYAN.make_link!(c1; type = :filaver, places = (place5, place6),)# cid = 1

        vis1 = Visualizer()
        draw_context!(vis1, c1, s)
    end

end