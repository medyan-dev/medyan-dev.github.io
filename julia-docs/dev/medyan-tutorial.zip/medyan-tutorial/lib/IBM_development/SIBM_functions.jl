using MEDYAN
using MEDYANVis
using CairoMakie
using Random
using SmallZarrGroups
using StaticArrays
using LinearAlgebra
using Setfield
using OrderedCollections: OrderedDict
using GLMakie
using FFTW
using OffsetArrays
using Statistics
using BenchmarkTools
using PhiloxArrays
using Test
#Random.seed!(1234);

"""
Struct for hydrodynamic parameters
"""
struct hydroparams
    N::SVector{3,Int64} #number of immersed boundary points
    kT::Float64 #temperature in joules (Boltzmann's constant x actual temperature)
    ρ::Float64 #density of fluid
    μ::Float64 #dynamic viscosity of fluid
    Δx::Float64 #fluid grid cell width
    Δt::Float64 #time step
end

"""
Struct for immersed boundary parameters
"""
struct ibparams
    npart::Int64 #number of immersed boundary points
    a::Float64 #radius of immersed boundary point in multiples of the grid cell width Δx
    K0::Float64 #filament node bond stretching parameter
    S0::Float64 #filament node equilibrium bond length parameter
    k∠::Float64 #filament node bending parameter
end

"""
Struct of parameters for a basic simulation of a single elastic filament in a fluid
"""
struct simparams
    nstep::Int64
    randmag::Float64
    Δz::Float64
    fbits::Int64
end

"""
Struct of parameters for animating simulation
"""
struct animparams
    framerate::Float64
    grid_skip::Int64
    xlow::Float64
    xup::Float64
    ylow::Float64
    yup::Float64
    zlow::Float64
    zup::Float64
    filename::String
end

"""
Use to converts Float64 to Int64, number of fractional bits hardcoded to 20.
"""
function unsaferound(x,::Val{fbits}) where {fbits}
    unsafe_trunc(Int64,(x*(2.0^fbits)))
end

"""
Initialize configuration of IB nodes for a single filament unbent, oriented
parallel to the z-axis.
"""
function initialize_IB_nodes_filparaz(nnode,Δz,Δx,N,disp)
    rnodes = zeros(nnode,3)
    for k in 1:nnode
        rnodes[k,1] = (N[1]/2)*Δx + disp[1]
        rnodes[k,2] = (N[2]/2)*Δx + disp[2]
        rnodes[k,3] = (N[3]/2)*Δx + (k-1)*Δz - (nnode/4)*Δz + disp[3]
    end
    return rnodes
end

"""
Define harmonic force law.
"""
function tension_law(r,K0,S0)
    return K0*(r - S0)
end

"""
Calculate the dispacement vector between two position vectors.
"""
function calculate_forcevec(rveci,rvecj,K0,S0)
    dispvec = SVector{3,Float64}(rvecj .- rveci)
    return (dispvec./norm(dispvec))*tension_law(norm(dispvec),K0,S0)
end

"""
Calculate the array of forces on each node in the IB given the configuration of the nodes in the IB.
"""
function calculate_stretching_force!(Fnodes,rnodes,K0,S0,fbits)
    #sum over all pairs of particles in the polymer
    for ib in 1:size(rnodes,1)-1
        rnodei = SVector{3,Float64}(view(rnodes,ib,:))
        rnodej = SVector{3,Float64}(view(rnodes,ib+1,:))
        temp_arr = calculate_forcevec(rnodei,rnodej,K0,S0)
        for k in 1:3
            temp_arr_round = unsaferound(temp_arr[k],fbits)
            @inbounds Fnodes[ib,k] += temp_arr_round
            @inbounds Fnodes[ib+1,k] -= temp_arr_round
        end
    end
end

"""
Calculate the array of forces on each node in the IB.
"""
function calculate_bending_force!(Fnodes,rnodes,k∠,fbits)
    for i in 1:size(rnodes,1)-2
        lastpos = SVector{3,Float64}(view(rnodes,i,:))
        pos = SVector{3,Float64}(view(rnodes,i+1,:))
        nextpos = SVector{3,Float64}(view(rnodes,i+2,:))
        r1 = lastpos - pos
        L1 = norm(r1)
        invL1 = inv(L1)
        r̂1 = r1*invL1
        r2 = nextpos - pos
        L2 = norm(r2)
        invL2 = inv(L2)
        r̂2 = r2*invL2
        cosθ = r̂1'*r̂2
        F1∠ = k∠*invL1*(r̂1*cosθ .- r̂2)
        F2∠ = k∠*invL2*(r̂2*cosθ .- r̂1)
        Fmid∠ = -(F1∠ + F2∠)
        for k in 1:3
            F1∠_round = unsaferound(F1∠[k],fbits)
            F2∠_round = unsaferound(F2∠[k],fbits)
            Fmid∠_round = unsaferound(Fmid∠[k],fbits)
            @inbounds Fnodes[i,k] += F1∠_round
            @inbounds Fnodes[i+1,k] += Fmid∠_round
            @inbounds Fnodes[i+2,k] += F2∠_round
        end
    end
end

"""
Eqn. 8: Calculate the force density array associated with each IB node.
"""
function calculate_fdens!(fdens,r,F,N,Δx,a)
    fdens .= 0
    #loop over all nodes in the immersed boundary
    for l in eachindex(view(r,:,1))
        rIB = SVector{3}(view(r,l,:))
        FIB = SVector{3}(view(F,l,:))
        #loop over all fluid grid cells in a cube that circumscribes a sphere
        #with radius equal to the immersed boundary point radius a=n*Δx
        for i in ceil(Int,(rIB[1]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[1]*inv(Δx))+2*Int(a*inv(Δx)))
            i -= (floor(Int,i/N[1]))*N[1] #account for PBC
            for j in ceil(Int,(rIB[2]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[2]*inv(Δx))+2*Int(a*inv(Δx)))
                j -= (floor(Int,j/N[2]))*N[2] #account for PBC
                for k in ceil(Int,(rIB[3]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[3]*inv(Δx))+2*Int(a*inv(Δx)))
                    k -= (floor(Int,k/N[3]))*N[3] #account for PBC
                    #use PBC for displacement between grid point (i,j,k)-th and node point r
                    Δrm = SA[i,j,k]*Δx - rIB
                    Δrm -= (round.(Int,Δrm./(N*Δx))).*N*Δx
                    view(fdens,:,i+1,j+1,k+1) .+= FIB*δₐ(Δrm,a)
                end
            end
        end
    end
end

"""
Eqn. 10: Fourier transform of nabla vector operator.
"""
function calc_gk(kvec,N,Δx)
    return SA[sin(2π*kvec[1]*inv(N[1])),sin(2π*kvec[2]*inv(N[2])),sin(2π*kvec[3]*inv(N[3]))]*inv(Δx)
end

"""
Eqn. 12: Fourier transform of laplacian scalar operator.
"""
function calc_αk(kvec,N,ρ,μ,Δx)
    return (2*μ*inv(ρ*Δx^2))*((1-cos(2π*kvec[1]*inv(N[1])))+(1-cos(2π*kvec[2]*inv(N[2])))+(1-cos(2π*kvec[3]*inv(N[3]))))
end

"""
Eqn. 15: Update all IB node positions.
"""
function update_rnodes_old(rnodes,Γm,Δx,N,a)
    Δrnodes = zeros(size(rnodes,1),3)
    #integrate over all grid points
    for i in 0:N[1]-1
        for j in 0:N[2]-1
            for k in 0:N[3]-1
                for l in 1:size(rnodes,1)
                    #use PBC for displacements
                    r = SA[i,j,k]*Δx .- view(rnodes,l,:)
                    r -= (Int.(round.(r./(N*Δx)))).*N*Δx
                    Δrnodes[l,:] += δₐ(r,a)*view(Γm,:,i+1,j+1,k+1)
                end
            end
        end
    end
    #use PBC for positions
    R = rnodes .+ Δrnodes*(Δx^3)
    R -= (floor.(R./(N'*Δx))).*N'*Δx
    return R
end

"""
Eqn. 15: Update all IB node positions.
"""
function update_rnodes!(rold,rnew,Γm,Δx,N,a)
    #loop over all nodes in the immersed boundary
    for l in eachindex(view(rold,:,1))
        rIB = SVector{3}(view(rold,l,:))
        #loop over all fluid grid cells in a cube that circumscribes a sphere
        #with radius equal to the immersed boundary point radius a=n*Δx
        for i in ceil(Int,(rIB[1]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[1]*inv(Δx))+2*Int(a*inv(Δx)))
            i -= (floor(Int,i/N[1]))*N[1] #account for PBC
            for j in ceil(Int,(rIB[2]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[2]*inv(Δx))+2*Int(a*inv(Δx)))
                j -= (floor(Int,j/N[2]))*N[2] #account for PBC
                for k in ceil(Int,(rIB[3]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[3]*inv(Δx))+2*Int(a*inv(Δx)))
                    k -= (floor(Int,k/N[3]))*N[3] #account for PBC
                    #use PBC for displacement between grid point (i,j,k)-th and node point r
                    r = SA[i,j,k]*Δx - rIB
                    r -= (round.(Int,r./(N*Δx))).*N*Δx
                    view(rnew,l,:) .= view(rold,l,:) .+ δₐ(r,a)*view(Γm,:,i+1,j+1,k+1)*(Δx^3)
                end
            end
        end
    end
    #use PBC for positions
    rnew -= (floor.(rnew./(N'*Δx))).*N'*Δx
end

"""
Eqn. 33: Projection operator projects out the part of the field orthogonal to gk field operator.
"""
function calc_Projorthogk(kvec,N,Δx)
    gk = calc_gk(kvec,N,Δx)
    return SMatrix{3,3}(1.0I) - gk.*transpose(gk)*inv(sum(gk.^2))
end

"""
Eqn. A.1: Define the 1D radially dependent Peskin kernel component.
"""
function ϕ(r::T)::T where T
    if r <= -2
        return zero(r)
    elseif -2 <= r < -1
        return inv(8)*(5 + 2*r - sqrt(-7 - 12*r - 4*r^2))
    elseif -1 <= r < 0
        return inv(8)*(3 + 2*r + sqrt(1 - 4*r - 4*r^2)) 
    elseif 0 <= r < 1
        return inv(8)*(3 - 2*r + sqrt(1 + 4*r - 4*r^2)) 
    elseif 1 <= r < 2
        return inv(8)*(5 - 2*r - sqrt(-7 + 12*r - 4*r^2)) 
    elseif 2 <= r
        return zero(r)
    else #this is in the event of an error
        return r
    end
end

"""
Eqn. A.2: Define the 3D radially dependent Peskin kernel.
"""
function δₐ(rvec,a)
    #return inv(a^3)*ϕ(inv(a)*rvec[1])*ϕ(inv(a)*rvec[2])*ϕ(inv(a)*rvec[3])
    term0 = inv(a^3)
    term1 = ϕ(inv(a)*rvec[1])
    term2 = ϕ(inv(a)*rvec[2])
    term3 = ϕ(inv(a)*rvec[3])
    return term0*term1*term2*term3
end

"""
Animate the fluid velocity field and the trajectory of the immersed boundary particle
"""
function animate_ufield_IBtraj(traj_rnodes,total_um,hp::hydroparams,ibp::ibparams,sp::simparams,ap::animparams)

    total_um = permutedims(total_um, (4,2,3,1,5))

    ps = [Point3f(x, y, z) for x in 1:ap.grid_skip:hp.N[1] for y in 1:ap.grid_skip:hp.N[2] for z in 1:ap.grid_skip:hp.N[3]]

    time = Observable(1)

    ufield = @lift(ns = map(
        p -> Vec3f(total_um[Int(p[1]),Int(p[2]),Int(p[3]),1,$time],
        total_um[Int(p[1]),Int(p[2]),Int(p[3]),2,$time],
        total_um[Int(p[1]),Int(p[2]),Int(p[3]),3,$time]),
        ps))

    IBtrajx = @lift(traj_rnodes[:,1,$time])
    IBtrajy = @lift(traj_rnodes[:,2,$time])
    IBtrajz = @lift(traj_rnodes[:,3,$time])
    
    fig = 
    GLMakie.arrows(
        ps*hp.Δx, ufield, fxaa=true, # turn on anti-aliasing
        align = :origin,
        linecolor = :gray, arrowcolor = :black,
        linewidth = 0.01, lengthscale = 0.1, arrowsize = Vec3f(0.02, 0.02, 0.03),
        axis=(type=Axis3,title = @lift("t = $(round($time*hp.Δt, digits = 5)) ns"))
    )

    #GLMakie.scatter!(IBtrajx,IBtrajy,IBtrajz,markersize=ibp.a,color=:blue,alpha=0.8)
    GLMakie.scatter!(IBtrajx,IBtrajy,IBtrajz,markersize=7,color=:red,alpha=1.0)

    GLMakie.xlims!(ap.xlow,ap.xup)
    GLMakie.ylims!(ap.ylow,ap.yup)
    GLMakie.zlims!(ap.zlow,ap.zup)


    fig.axis.xlabel = L"$x \quad [\text{nm}]$"
    fig.axis.ylabel = L"$y \quad [\text{nm}]$"
    fig.axis.zlabel = L"$z \quad [\text{nm}]$"

    #axislegend(position = :rb)
    timestamps = range(1, sp.nstep, step=1)
    record(fig, ap.filename, timestamps;framerate = framerate) do t
        time[] = t
    end
end

"""
Calculate the velocity field uk at the n+1-th timestep at all points in k-space. Also calculate the 
random variable Γk at the n-th timestep at all points in k-space.

Note, ukold and uknew are allowed to be the same array.

Inputs: ukold,fkdens,struct of hydordynamic parameters
Outputs: uknew,Γk
"""
function update_fields!(ukold,uknew,Γk,fkdens,hp::hydroparams,counter,key)
    #define the slab in k-space
    Nirfft = (div(hp.N[1],2)+1,hp.N[2],hp.N[3]) 
    #evaluate fields for every point in k-space
    for kvec in CartesianIndices(Nirfft)
        isone(kvec) && continue
        #FT discrete divergence
        αk = calc_αk(kvec,hp.N,hp.ρ,hp.μ,hp.Δx)
        #projection operator
        Projk = calc_Projorthogk(kvec,hp.N,hp.Δx)
        
        #first correlation coefficient
        c1k = inv(αk)*tanh(0.5*αk*hp.Δt)
        #second correlation coefficient
        c2k = sqrt((2*hp.kT)*inv(hp.ρ*prod(hp.N)*(hp.Δx^3)*(αk^2))*(αk*hp.Δt - 2*tanh(0.5*αk*hp.Δt)))

        #calculate the conjugate kvec
        kvecp = CartesianIndex(mod.(Tuple(hp.N) .- Tuple(kvec) .+ 1,Tuple(hp.N)) .+ 1)

        #generate first RV
        Ξk = sqrt(hp.kT*inv(hp.ρ*prod(hp.N)*(hp.Δx^3))*(1 - exp(-2*αk*hp.Δt))) *
             inv(sqrt(Float32(2))) *
             (PhiloxArrays.ComplexGaussianVectorField(Tuple(hp.N),UInt64(key),UInt64(counter))[kvec] .+
             conj(PhiloxArrays.ComplexGaussianVectorField(Tuple(hp.N),UInt64(key),UInt64(counter))[kvecp]))
        
        #generate second RV
        #note we use key' = key + N₁×N₂×N₃ because we need a different random field for all the grid points
        Gk = inv(sqrt(Float32(2))) *
             (PhiloxArrays.ComplexGaussianVectorField(Tuple(hp.N),UInt64(key+prod(hp.N)),UInt64(counter))[kvec] .+
             conj(PhiloxArrays.ComplexGaussianVectorField(Tuple(hp.N),UInt64(key+prod(hp.N)),UInt64(counter))[kvecp]))

        #calculate Γk
        Γk[kvec] = inv(αk) * (1 - exp(-αk * hp.Δt)) * ukold[kvec] .+ 
                   ((hp.Δt * inv(αk)) + (inv(αk^2) * (exp(-αk * hp.Δt) - 1))) * inv(hp.ρ) * (Projk * fkdens[kvec]) .+ 
                   c1k * (Projk * Ξk) .+
                   c2k * (Projk * Gk)
        
        #calculate uknew
        uknew[kvec] = exp(-αk * hp.Δt) * ukold[kvec] .+ 
                      inv(hp.ρ * αk) * (1 - exp(-αk * hp.Δt)) * (Projk * fkdens[kvec]) .+ 
                      Projk * Ξk
    end
end

"""
Move entire system nstep timesteps forward
"""
function main_filaments_ufield(hp::hydroparams,ibp::ibparams,sp::simparams,key)
    #define slab of points in k-space
    Nirfft = (div(hp.N[1],2)+1,hp.N[2],hp.N[3])
    
    #initialize velocity field and IB node positions in r-space
    fmdens = zeros(SVector{3, Float32},Tuple(hp.N))
    um = zeros(SVector{3, Float32},Tuple(hp.N))
    Γm = zeros(SVector{3, Float32},Tuple(hp.N))

    #initialize velocity field and IB node positions in k-space
    fkdens = zeros(SVector{3, Complex{Float32}},Nirfft)
    uk = zeros(SVector{3, Complex{Float32}},Nirfft)
    Γk = zeros(SVector{3, Complex{Float32}},Nirfft)
    
    #initalize velocity data array
    total_um = copy(reinterpret(reshape,Float32,um))

    #initialize filaments IB node locations
    rnodes = initialize_IB_nodes_filparaz(ibp.npart,sp.Δz,hp.Δx,hp.N,[0,0,0]*sp.Δz)

    #intialize force array
    Fnodes_int = zeros(Int64,size(rnodes))

    #initialize output IB trajectory data arrays
    traj_rnodes = copy(rnodes)

    #Define the rfft and irfft plan
    P_rfft = plan_rfft(reinterpret(reshape,Float32,um),(2,3,4))
    P_brfft = plan_brfft(reinterpret(reshape,ComplexF32,uk),hp.N[1],(2,3,4))

    #integrate system forward in time
    for it in 1:sp.nstep
        #calculate force on filament nodes
        Fnodes_int .= 0
        calculate_stretching_force!(Fnodes_int,rnodes,ibp.K0,ibp.S0,Val(sp.fbits))
        calculate_bending_force!(Fnodes_int,rnodes,ibp.k∠,Val(sp.fbits))
        Fnodes_float = Fnodes_int*(2.0^-sp.fbits)

        #calculate the force density and its discrete FFT
        calculate_fdens!(reinterpret(reshape,Float32,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
        fkdens = reinterpret(reshape,SVector{3,Complex{Float32}},P_rfft*reinterpret(reshape,Float32,fmdens))
        
        #calculate the fields
        update_fields!(uk,uk,Γk,fkdens,hp,it,key)

        #get r-space integrated velocity field
        Γm = P_brfft*reinterpret(reshape,Complex{Float32},Γk)

        #update the IB node positions
        update_rnodes!(rnodes,rnodes,Γm,hp.Δx,hp.N,ibp.a)

        #get r-space velocity field and store
        um = P_brfft*reinterpret(reshape,Complex{Float32},uk)
        total_um = cat(total_um,um,dims=5)
        
        #get the node positions and store
        traj_rnodes = cat(traj_rnodes,rnodes,dims=3)

        @info "Finished timestep it = $it"
    end
    return traj_rnodes,total_um
end


"""
Move entire system nstep timesteps forward
"""
function main_filaments_ufield_profile(hp::hydroparams,ibp::ibparams,sp::simparams,key)
    #define slab of points in k-space
    Nirfft = (div(hp.N[1],2)+1,hp.N[2],hp.N[3])
    
    #initialize velocity field and IB node positions in r-space
    fmdens = zeros(SVector{3, Float32},Tuple(hp.N))
    um = zeros(SVector{3, Float32},Tuple(hp.N))
    Γm = zeros(SVector{3, Float32},Tuple(hp.N))

    #initialize velocity field and IB node positions in k-space
    fkdens = zeros(SVector{3, Complex{Float32}},Nirfft)
    uk = zeros(SVector{3, Complex{Float32}},Nirfft)
    Γk = zeros(SVector{3, Complex{Float32}},Nirfft)
    
    #initalize velocity data array
    total_um = copy(reinterpret(reshape,Float32,um))

    #initialize filaments IB node locations
    rnodes = initialize_IB_nodes_filparaz(ibp.npart,sp.Δz,hp.Δx,hp.N,[0,0,0]*sp.Δz)

    #intialize force array
    Fnodes_int = zeros(Int64,size(rnodes))

    #initialize output IB trajectory data arrays
    traj_rnodes = copy(rnodes)

    #Define the rfft and irfft plan
    P_rfft = plan_rfft(reinterpret(reshape,Float32,um),(2,3,4))
    P_brfft = plan_brfft(reinterpret(reshape,ComplexF32,uk),hp.N[1],(2,3,4))

    #integrate system forward in time
    for it in 1:sp.nstep
        #calculate force on filament nodes
        Fnodes_int .= 0
        @btime calculate_stretching_force!($Fnodes_int,$rnodes,$ibp.K0,$ibp.S0,Val($sp.fbits))
        @btime calculate_bending_force!($Fnodes_int,$rnodes,$ibp.k∠,Val($sp.fbits))
        Fnodes_float = Fnodes_int*(2.0^-sp.fbits)

        #calculate the force density and its discrete FFT
        @btime calculate_fdens!(reinterpret(reshape,Float32,$fmdens),$rnodes,$Fnodes_float,$hp.N,$hp.Δx,$ibp.a)
        @btime fkdens = reinterpret(reshape,SVector{3,Complex{Float32}},$P_rfft*reinterpret(reshape,Float32,$fmdens))
        
        #calculate the fields
        @btime update_fields!($uk,$uk,$Γk,$fkdens,$hp,$it,$key)

        #get r-space integrated velocity field
        Γm = P_brfft*reinterpret(reshape,Complex{Float32},Γk)

        #update the IB node positions
        @btime update_rnodes!($rnodes,$rnodes,$Γm,$hp.Δx,$hp.N,$ibp.a)

        #get r-space velocity field and store
        um = P_brfft*reinterpret(reshape,Complex{Float32},uk)
        total_um = cat(total_um,um,dims=5)
        
        #get the node positions and store
        traj_rnodes = cat(traj_rnodes,rnodes,dims=3)

        @info "Finished timestep it = $it"
    end
    return traj_rnodes,total_um
end
