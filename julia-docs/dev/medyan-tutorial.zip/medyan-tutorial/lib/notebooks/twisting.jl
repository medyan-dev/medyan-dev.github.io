### A Pluto.jl notebook ###
# v0.20.16

using Markdown
using InteractiveUtils

# ╔═╡ 33d95fcd-1fc6-4fac-94a5-2f3b11c04f3e
begin
	filter!(LOAD_PATH) do path
		path != "@v#.#"
	end;
    import Pkg
    # activate the shared project environment
    Pkg.activate(Base.current_project())
	Pkg.resolve()#update Manifest.toml based on MEDYAN Project.toml updates
	Pkg.instantiate()
	
	using ForwardDiff
    using StaticArrays
	using LinearAlgebra
	using ArgCheck
	using StaticArrays
	using Random
	using Rotations
	using Chairmarks
	md"Packages"
end

# ╔═╡ b5869d17-c652-43cf-ac19-ba9a9b70aab0
@inline norm_fast(v) = Base.FastMath.sqrt_fast(sum(abs2, v))

# ╔═╡ 8536a66f-d3f7-4bb7-8a7a-ddc13872c5a4
@inline normalize_fast(v) = v * inv(norm_fast(v))

# ╔═╡ 2fa26fbd-49c7-49c7-b90d-ee570c981331
function generate_example_input()
	while true
		x1 = 200.0*rand(SVector{3, Float64})
		x2 = 200.0*rand(SVector{3, Float64})
		x3 = 200.0*rand(SVector{3, Float64})
		m1h1 = randn(SVector{3, Float64})
		m1h2 = randn(SVector{3, Float64})
		b1 = x2 - x1
		b2 = x3 - x2
		norm_fast(b1) < 0.1 && continue
		norm_fast(b2) < 0.1 && continue
		t1 = normalize_fast(b1)
		t2 = normalize_fast(b2)
		norm_fast(t1 × t2) < 0.1 && continue
		# subtract out part that isn't perpendicular and normalize
		m1h1 = normalize_fast(m1h1 - dot(m1h1,t1)*t1)
		m1h1 = normalize_fast(m1h1 - dot(m1h1,t1)*t1)
		m1h2 = normalize_fast(m1h2 - dot(m1h2,t2)*t2)
		m1h2 = normalize_fast(m1h2 - dot(m1h2,t2)*t2)
		θ1 = 4π*rand()
		θ2 = 4π*rand()
		return x1, x2, x3, m1h1, m1h2, cos(θ1/2), sin(θ1/2), cos(θ2/2), sin(θ2/2)
	end
end

# ╔═╡ 0d3f6ffe-ae67-4188-9cae-4f57ffb6a51f
eg = generate_example_input()

# ╔═╡ 08b6090e-ee96-4040-9975-8b6da1e2168b
function twist_energy2(x1, x2, x3, m1h1, m1h2, cθh1, sθh1, cθh2, sθh2)
	crefθ = cθh1*cθh2 - sθh1*sθh2
	srefθ = sθh1*cθh2 + cθh1*sθh2
	b1 = x2 - x1
	b2 = x3 - x2
	L1 = norm_fast(b1)
	L2 = norm_fast(b2)
	t1 = normalize_fast(b1)
	t2 = normalize_fast(b2)
	m2h1 = t1 × m1h1
	m2h2 = t2 × m1h2
	cos_bend = t1 ⋅ t2
	tx = t1 × t2
	# transport m1h1 to t2 cylinder without twisting
    m1h1_trans = cos_bend * m1h1 + tx × m1h1 + (inv(1 + cos_bend) * (tx ⋅ m1h1)) * tx
    cθm12 = m1h1_trans ⋅ m1h2
    sθm12 = m1h1_trans ⋅ m2h2
    cdtwist = crefθ*cθm12 - srefθ*sθm12
    sdtwist = sθm12*crefθ + cθm12*srefθ
    # tan^2((θ2-θ1)/2)
    E = (1 - cdtwist) * inv(1 + cdtwist)
    dE_ddθ = 2*sdtwist * (inv(1 + cdtwist))^2
    F_m1h2 = +dE_ddθ*m2h2
    F_m1h1 = -dE_ddθ*m2h1
    # get the extra torque term to ensure no net torque
    side_twist = dE_ddθ / (1 + cos_bend)
    F_side_twist2 = (side_twist*inv(L2))*tx
    F_side_twist1 = (side_twist*inv(L1))*tx
    E, -F_side_twist1, F_side_twist1 - F_side_twist2, F_side_twist2, F_m1h1, F_m1h2
end

# ╔═╡ 14586f1f-7dd0-41c9-9d13-781079d53397
@be twist_energy2($(eg)...)

# ╔═╡ 888d02d0-55f2-11f0-314d-b12298270d10
function twist_energy(x1, x2, x3, m1h1, m1h2, cθh1, sθh1, cθh2, sθh2)
	b1 = x2 - x1
	b2 = x3 - x2
	L1 = norm_fast(b1)
	L2 = norm_fast(b2)
	t1 = normalize_fast(b1)
	t2 = normalize_fast(b2)
	cbend = t1 ⋅ t2
	m2h1 = t1 × m1h1
	m2h2 = t2 × m1h2
	m111 = +cθh1*m1h1 + sθh1*m2h1
	m211 = -sθh1*m1h1 + cθh1*m2h1
	m102 = +cθh2*m1h2 - sθh2*m2h2
	m202 = +sθh2*m1h2 + cθh2*m2h2
	# Get a vector that is perpendicular to both t1 and t2
	tx = t1 × t2
	txn = norm_fast(tx)
	# k = normalize(tx)
	# TODO have a more elegent way of getting k
	k = if txn < sqrt(eps(eltype(tx)))
		m111
	else
		tx * inv(txn)
	end
	# Now get a measure of its angle in the material frame on
	# both sides of the joint
	cθ1 = k ⋅ m111
	sθ1 = k ⋅ m211
	cθ2 = k ⋅ m102
	sθ2 = k ⋅ m202
	cdθ = cθ1*cθ2 + sθ1*sθ2
	sdθ = sθ2*cθ1 - cθ2*sθ1
	# tan^2((θ2-θ1)/2)
	E = (1 - cdθ) / (1 + cdθ)
	dE_ddθ = 2*sdθ / (1 + cdθ)^2
	F_m1h2 = +dE_ddθ*m2h2
	F_m1h1 = -dE_ddθ*m2h1
	# get the extra torque term to ensure no net torque
	side_twist = dE_ddθ * txn / (1 + cbend)
	F_side_twist2 = side_twist*inv(L2)*k
	F_side_twist1 = side_twist*inv(L1)*k
	F_x3 = F_side_twist2
	F_x2 = F_side_twist1 - F_side_twist2
	F_x1 = -F_side_twist1
	E, F_x1, F_x2, F_x3, F_m1h1, F_m1h2
end

# ╔═╡ f077b7ef-2744-4203-b2c7-3f8710497b0d
function test_symmetry(;trials=1000000)
	for trial in 1:trials
		x1, x2, x3, m1h1, m1h2, cθh1, sθh1, cθh2, sθh2 = generate_example_input()
		e1, fs... = twist_energy(x1, x2, x3, m1h1, m1h2, cθh1, sθh1, cθh2, sθh2)
		trans = 200.0*randn(SVector{3, Float64})
		x1 += trans
		x2 += trans
		x3 += trans
		rot = rand(QuatRotation{Float64})
		x1 = rot*x1
		x2 = rot*x2
		x3 = rot*x3
		m1h1 = rot*m1h1
		m1h2 = rot*m1h2
		# redefine material vectors at an offset angle
		mat_frame_offset = 2π*rand()
		m1h1 = AngleAxis(mat_frame_offset, normalize_fast(x2-x1)...)*m1h1
		m1h2 = AngleAxis(mat_frame_offset, normalize_fast(x3-x2)...)*m1h2
		e2, fs... = twist_energy2(x1, x2, x3, m1h1, m1h2, cθh1, sθh1, cθh2, sθh2)
		if e2 > 1E6
			@argcheck e1 > 0.9E6
		else
			@argcheck isapprox(e1, e2; atol=1E-8, rtol=1E-6)
		end
	end
end

# ╔═╡ c17c504a-302b-409f-b5b5-747beb6d1e14
test_symmetry()

# ╔═╡ 2594e44b-7987-46a0-b79d-7f9930d91a25
function twist_ad(x1, x2, x3, m1h1, m1h2, cθh1, sθh1, cθh2, sθh2)
	params = (cθh1, sθh1, cθh2, sθh2)
	E, fs... = twist_energy(x1, x2, x3, m1h1, m1h2, params...)
	g = ForwardDiff.gradient(vcat(x1, x2, x3, m1h1, m1h2)) do xdof
		local x1 = xdof[StaticArrays.SUnitRange(1,3)]
		local x2 = xdof[StaticArrays.SUnitRange(4,6)]
		local x3 = xdof[StaticArrays.SUnitRange(7,9)]
		local m1h1 = xdof[StaticArrays.SUnitRange(10,12)]
		local m1h2 = xdof[StaticArrays.SUnitRange(13,15)]
		b1 = x2 - x1
		b2 = x3 - x2
		t1 = normalize_fast(b1)
		t2 = normalize_fast(b2)
		# subtract out part that isn't perpendicular and normalize
		m1h1 = normalize_fast(m1h1 - dot(m1h1,t1)*t1)
		m1h2 = normalize_fast(m1h2 - dot(m1h2,t2)*t2)
		local E, fs... = twist_energy(x1, x2, x3, m1h1, m1h2, params...)
		E
	end
	(
		E,
	 	-g[StaticArrays.SUnitRange(1,3)],
		-g[StaticArrays.SUnitRange(4,6)],
		-g[StaticArrays.SUnitRange(7,9)],
		-g[StaticArrays.SUnitRange(10,12)],
		-g[StaticArrays.SUnitRange(13,15)],
	)
end

# ╔═╡ af8bc5fa-9387-4dbf-a094-42154457ab31
maximum(norm.(twist_ad(eg...) .- twist_energy(eg...)))

# ╔═╡ 0bd97af6-8d25-45fd-8f15-f95b1b04b0e4
function test_grad_matches_forwarddiff(;trials=100000)
	for trial in 1:trials
		eg = generate_example_input()
		ad = twist_ad(eg...)
		sym = twist_energy2(eg...)
		diff = norm.(ad .- sym)
		if ad[1] > 1E4
			# twist is too high
			continue
		end
		if maximum(diff) > 1E-4
			@info "large diff $(maximum(diff))" eg twist_ad(eg...) twist_energy(eg...)
		end
	end
end

# ╔═╡ 0b71ab09-ce4a-4b1c-92c1-61c3bcbef402
test_grad_matches_forwarddiff()

# ╔═╡ Cell order:
# ╠═b5869d17-c652-43cf-ac19-ba9a9b70aab0
# ╠═8536a66f-d3f7-4bb7-8a7a-ddc13872c5a4
# ╠═2fa26fbd-49c7-49c7-b90d-ee570c981331
# ╠═0d3f6ffe-ae67-4188-9cae-4f57ffb6a51f
# ╠═14586f1f-7dd0-41c9-9d13-781079d53397
# ╠═af8bc5fa-9387-4dbf-a094-42154457ab31
# ╠═0bd97af6-8d25-45fd-8f15-f95b1b04b0e4
# ╠═0b71ab09-ce4a-4b1c-92c1-61c3bcbef402
# ╠═f077b7ef-2744-4203-b2c7-3f8710497b0d
# ╠═c17c504a-302b-409f-b5b5-747beb6d1e14
# ╠═08b6090e-ee96-4040-9975-8b6da1e2168b
# ╠═888d02d0-55f2-11f0-314d-b12298270d10
# ╠═2594e44b-7987-46a0-b79d-7f9930d91a25
# ╠═33d95fcd-1fc6-4fac-94a5-2f3b11c04f3e
