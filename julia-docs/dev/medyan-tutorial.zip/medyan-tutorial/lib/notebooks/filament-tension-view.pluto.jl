### A Pluto.jl notebook ###
# v0.20.8

using Markdown
using InteractiveUtils

# This Pluto notebook uses @bind for interactivity. When running this notebook outside of Pluto, the following 'mock version' of @bind gives bound variables a default value (instead of an error).
macro bind(def, element)
    #! format: off
    return quote
        local iv = try Base.loaded_modules[Base.PkgId(Base.UUID("6e696c72-6542-2067-7265-42206c756150"), "AbstractPlutoDingetjes")].Bonds.initial_value catch; b -> missing; end
        local el = $(esc(element))
        global $(esc(def)) = Core.applicable(Base.get, el) ? Base.get(el) : iv(el)
        el
    end
    #! format: on
end

# ╔═╡ fe60f470-3752-11ec-1cf8-19ed0e8f245c
begin
	filter!(LOAD_PATH) do path
		path != "@v#.#"
	end;
    import Pkg
    # activate the shared project environment
    Pkg.activate(Base.current_project())
	Pkg.resolve()#update Manifest.toml based on MEDYAN Project.toml updates
	Pkg.instantiate()
	
	using Revise
    using MEDYAN
	using Colors
	using StaticArrays
	using LinearAlgebra
	import Plots
	using CairoMakie
	import PlutoUI
	using Setfield
	using ImageFiltering
	using MEDYANVis
	md"Packages"
end

# ╔═╡ 3c59de85-df1e-4feb-a0e9-141b1dfa3537
grid= CubicGrid((2,2,2),1000.0)

# ╔═╡ b1a45087-4bc3-4933-803e-ea8bceb3f942
40*14

# ╔═╡ a5b49a86-dd9b-40c0-a778-1ecc15d66e51
md"""
Blur: $(@bind blur PlutoUI.Slider(0:500; show_value=true))

Plane Offset: $(@bind offset PlutoUI.NumberField(-600.0:600.0; default=0.0))

"""

# ╔═╡ f142df19-f55b-483e-a767-bc7cd94e6fe4
nmons = 560 # round(Int, 1500/2.7)

# ╔═╡ ef4b0e29-ca88-42ca-b673-771b354e1299
begin
	c = MEDYAN.example_actin_mech_context(grid;nforce_fractbit=30, nenergy_fractbit=40)
	for z_offset in [-70.0, 70.0]
		ftag1= make_fila!(c;
			type= :actin,
			mono_states=ones(UInt8, nmons),
			node_positions=[SA[-nmons*2.7/2,0,z_offset], SA[+nmons*2.7/2,0,z_offset]],
			node_mids=[0,nmons],
		)
		nmons2 = nmons-150
		ftag2= make_fila!(c;
			type= :actin,
			mono_states=ones(UInt8, nmons2),
			node_positions=[SA[-nmons2*2.7/2, 10, z_offset], SA[+nmons2*2.7/2, 10, z_offset]],
			node_mids=[0,nmons2],
		)
		for dir in (+, -)
			local mono1 = FilaMonoIdx(c, ftag1, dir)
			local mono2 = FilaMonoIdx(c, ftag2, dir)
			make_link!(c;
				type= :fila_mono_distance,
				places= (mono1, mono2),
				bond_states= (
					(
						L0=6.0,
					),
				),
			)
		end
	end
	minimize_energy!(c;g_tol=1E-16)
end

# ╔═╡ e37b714c-a49b-4511-a8d8-190d13f77311
vis = Visualizer()

# ╔═╡ 8170a78e-8311-4aa2-b5b7-bf2bc61e6aaa
render(vis)

# ╔═╡ 0de2da30-5893-4d20-8275-c109088e34e1
draw_context!(vis, c)

# ╔═╡ f2a71453-eec2-4fc6-8fde-3f59d58e651f
fc = MEDYAN.ForceContext(c)

# ╔═╡ 955c1a0c-36d2-40fc-8884-2c65c24bb0bb
MEDYAN.get_internal_forces!(SA[1.0, 0.0, 0.0], 556.0, fc, fc.x0)

# ╔═╡ 168953dd-a980-4861-b418-c10e08846fe1
fc.cylinder_nl

# ╔═╡ f5dd7d38-eb64-465d-9a8c-e69234d1d98b
points = reinterpret(SVector{3, Float64}, fc.x0)[27]

# ╔═╡ 72af812e-8e40-4af9-9696-0bb4877c46ff
fc.simboxsize

# ╔═╡ 5fd275cb-1da0-4e83-b744-19d3829b86a1
function tension_image(fc; N=100, axis=3, offset=0.0)
	normal = setindex(zero(SVector{3,Float64}), 1.0, axis)
	other_axis = circshift(1:3, 1-axis)[2:3]
	matrixsize = maximum(fc.simboxsize[other_axis])
	scaling = N/matrixsize
	internal_f = MEDYAN.get_internal_forces!(normal, offset, fc)
	out = zeros(N, N)
	for (;f, r) in internal_f
		normal_f = f ⋅ normal
		img_x = clamp(round(Int, r[other_axis[1]]*scaling + (N+1)/2), 1, N)
		img_y = clamp(round(Int, r[other_axis[2]]*scaling + (N+1)/2), 1, N)
		out[img_x, img_y] += normal_f
	end
	out
end

# ╔═╡ b122ec18-e9cf-4982-90e0-7d5a55c7bf5a
begin
	image = tension_image(fc;axis=1, offset, N=200)
	smooth_image= imfilter(image, Kernel.gaussian((blur,blur), (blur*10+1, blur*10+1)), "circular")
end

# ╔═╡ d8d845af-0819-4f7d-bea7-e6c46aae71ea
let
	local fig = Figure()
	local ax = Axis(fig[1, 1]; aspect=DataAspect())
	local max_val = maximum(abs, smooth_image)
	local hm = heatmap!(ax, smooth_image; colorrange=(-max_val,max_val), colormap= :diverging_bkr_55_10_c35_n256)
	Colorbar(fig[:, end+1], hm; label = "Tension (pN)")
	fig
end

# ╔═╡ 212fd016-9948-4ea2-bf6f-a6a5d52c28f8
sum(smooth_image)

# ╔═╡ 1ac8c70f-d2c4-49a4-a834-bbbaae88678d
18-12

# ╔═╡ ef85bfbf-74da-4cd4-b988-07d9a43db04d
c.sys_def

# ╔═╡ Cell order:
# ╠═fe60f470-3752-11ec-1cf8-19ed0e8f245c
# ╠═3c59de85-df1e-4feb-a0e9-141b1dfa3537
# ╠═b1a45087-4bc3-4933-803e-ea8bceb3f942
# ╠═b122ec18-e9cf-4982-90e0-7d5a55c7bf5a
# ╠═d8d845af-0819-4f7d-bea7-e6c46aae71ea
# ╠═212fd016-9948-4ea2-bf6f-a6a5d52c28f8
# ╠═a5b49a86-dd9b-40c0-a778-1ecc15d66e51
# ╠═955c1a0c-36d2-40fc-8884-2c65c24bb0bb
# ╠═168953dd-a980-4861-b418-c10e08846fe1
# ╠═f5dd7d38-eb64-465d-9a8c-e69234d1d98b
# ╟─8170a78e-8311-4aa2-b5b7-bf2bc61e6aaa
# ╠═f142df19-f55b-483e-a767-bc7cd94e6fe4
# ╠═ef4b0e29-ca88-42ca-b673-771b354e1299
# ╠═e37b714c-a49b-4511-a8d8-190d13f77311
# ╠═0de2da30-5893-4d20-8275-c109088e34e1
# ╠═f2a71453-eec2-4fc6-8fde-3f59d58e651f
# ╠═72af812e-8e40-4af9-9696-0bb4877c46ff
# ╠═5fd275cb-1da0-4e83-b744-19d3829b86a1
# ╠═1ac8c70f-d2c4-49a4-a834-bbbaae88678d
# ╠═ef85bfbf-74da-4cd4-b988-07d9a43db04d
