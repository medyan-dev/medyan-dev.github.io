### A Pluto.jl notebook ###
# v0.20.8

using Markdown
using InteractiveUtils

# This Pluto notebook uses @bind for interactivity. When running this notebook outside of Pluto, the following 'mock version' of @bind gives bound variables a default value (instead of an error).
macro bind(def, element)
    #! format: off
    return quote
        local iv = try Base.loaded_modules[Base.PkgId(Base.UUID("6e696c72-6542-2067-7265-42206c756150"), "AbstractPlutoDingetjes")].Bonds.initial_value catch; b -> missing; end
        local el = $(esc(element))
        global $(esc(def)) = Core.applicable(Base.get, el) ? Base.get(el) : iv(el)
        el
    end
    #! format: on
end

# ╔═╡ fe60f470-3752-11ec-1cf8-19ed0e8f245c
begin
	filter!(LOAD_PATH) do path
		path != "@v#.#"
	end;
    import Pkg
    # activate the shared project environment
    Pkg.activate(Base.current_project())
	Pkg.resolve()#update Manifest.toml based on MEDYAN Project.toml updates
	Pkg.instantiate()
	
	using Revise
    using MEDYAN
	using Colors
	using StaticArrays
	using LinearAlgebra
	import Plots
	using CairoMakie
	import PlutoUI
	import PlotlyJS
	using Setfield
	md"Packages"
end

# ╔═╡ 56ea2618-446a-4060-a6ba-6b805eea94ca
Plots.plotlyjs()

# ╔═╡ ba276b7b-f136-4799-b767-a6d72c6326eb
agentnames = MEDYAN.AgentNames(
	diffusingspeciesnames= [:a,],
	filamentnames= [(:actin,[
                            :plusend,
                            :minusend,
                            :middle,
                        ]),
	],
)

# ╔═╡ 3c59de85-df1e-4feb-a0e9-141b1dfa3537
grid= CubicGrid((2,2,2),5000.0)

# ╔═╡ 4e2803cb-f3bd-4103-a64a-563ac08f8bcc
function make_context(grid::CubicGrid; fila_params = MEDYAN.ACTIN_FIL_PARAMS)
    agent_names = MEDYAN.AgentNames(
        filamentnames= [(:actin,[
                                :a,
                                :restrained,
                            ]),
        ],
    )

    s= MEDYAN.SysDef(agent_names)

    add_filament_params!(s, 
        :actin,
        fila_params,
    )

    c = MEDYAN.Context(s,grid)
    c
end

# ╔═╡ b34be6aa-4098-43b2-a1ea-d79349c01807
default_params = MEDYAN.ACTIN_FIL_PARAMS

# ╔═╡ b1a45087-4bc3-4933-803e-ea8bceb3f942
40*14

# ╔═╡ f142df19-f55b-483e-a767-bc7cd94e6fe4
nmons = 560 # round(Int, 1500/2.7)

# ╔═╡ ef4b0e29-ca88-42ca-b673-771b354e1299
begin
	c = make_context(grid;fila_params=@set(default_params.numpercylinder=40))
	make_fila!(c;
		mono_states=ones(UInt8, nmons),
		node_positions=[SA[-nmons*2.7/2,0,0], SA[+nmons*2.7/2,0,0]],
		node_mids=[0,nmons],
	)
end;

# ╔═╡ 3a16e5cf-021e-49f1-8e69-5a6f1535f391
begin
	fc = MEDYAN.ForceContext(c)
	H = MEDYAN.hessian!(fc, fc.x0)[3]
	M = Diagonal(MEDYAN._calc_drag_coefficents(fc))
end;

# ╔═╡ a6e717b4-082c-4f72-9f00-fbaa50fd90f7
real(eigvals(inv(M)*H))

# ╔═╡ cafee783-375d-4a1e-8542-bed57e1cae15
# H has units of pN/nm
# inv(M) has units of nm/s/pN
# inv(M)*H has units 1/s

# ╔═╡ 917adcfb-24f3-4027-bc1a-96d25a385499
V = real(eigen(inv(M)*H).vectors)

# ╔═╡ a5b49a86-dd9b-40c0-a778-1ecc15d66e51
md"""
Mode: $(@bind n PlutoUI.Slider(1:size(V,1); show_value=true))

Displacement: $(@bind d PlutoUI.Slider(-500:500; show_value=true))
"""

# ╔═╡ 7923411c-3b7a-48bb-aa99-858ee982c0d3
function plot_fila(x)
	Plots.plot(x[1:3:end], x[2:3:end], x[3:3:end]; lims=(-1000,1000), aspect_ratio = :equal )
	Plots.scatter!(x[1:3:end], x[2:3:end], x[3:3:end])
end

# ╔═╡ ce9adb7b-fca3-4cea-a783-ab10bc9097a4
plot_fila(fc.x0 + d*V[:,n])

# ╔═╡ 24afdd4c-cbfa-415f-89c2-4f5477a0f91b
begin
	ev = sqrt.(abs.(eigvals(inv(M)*H)))
	f = Plots.scatter(ev, 1:length(ev);xlabel="Square root Eigen value √(s⁻¹) ", ylabel="Eigen value order")
	f
end

# ╔═╡ Cell order:
# ╠═fe60f470-3752-11ec-1cf8-19ed0e8f245c
# ╠═56ea2618-446a-4060-a6ba-6b805eea94ca
# ╠═ba276b7b-f136-4799-b767-a6d72c6326eb
# ╠═3c59de85-df1e-4feb-a0e9-141b1dfa3537
# ╠═4e2803cb-f3bd-4103-a64a-563ac08f8bcc
# ╠═b34be6aa-4098-43b2-a1ea-d79349c01807
# ╠═a6e717b4-082c-4f72-9f00-fbaa50fd90f7
# ╠═b1a45087-4bc3-4933-803e-ea8bceb3f942
# ╠═f142df19-f55b-483e-a767-bc7cd94e6fe4
# ╠═ef4b0e29-ca88-42ca-b673-771b354e1299
# ╠═3a16e5cf-021e-49f1-8e69-5a6f1535f391
# ╠═cafee783-375d-4a1e-8542-bed57e1cae15
# ╠═917adcfb-24f3-4027-bc1a-96d25a385499
# ╠═ce9adb7b-fca3-4cea-a783-ab10bc9097a4
# ╠═a5b49a86-dd9b-40c0-a778-1ecc15d66e51
# ╠═7923411c-3b7a-48bb-aa99-858ee982c0d3
# ╠═24afdd4c-cbfa-415f-89c2-4f5477a0f91b
