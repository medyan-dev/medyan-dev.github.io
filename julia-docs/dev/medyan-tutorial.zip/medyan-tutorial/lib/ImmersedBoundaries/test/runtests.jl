using ImmersedBoundaries
using Test
using StaticArrays
using Random

Random.seed!(1234)

@testset "ImmersedBoundaries.jl" begin
    # Write your tests here.
    
    @testset "Force density calculation" begin
        #test force density is correct
        N = SA[32,32,32]
        L = 1.0*10^3 #nm
        Δx = L/N[1] #nm
        npart = 2
        a = Δx #nm
        K0 = 100.0
        S0 = 10.0
        fbits = 20
        Δx1 = 0.0
        Δx2 = 0.0 
        Δx3 = 300.0
        disp = [0,0,0]*Δx

        hp = hydroparams(N,0.0,0.0,0.0,Δx,0.0)
        ibp = ibparams(npart,a)
        fp = forceparams(K0,S0,0.0,SA[0.0,0.0,0.0])
        sp = simparams(0,0.0,0.0,fbits,0)

        #calculate force on filament nodes and the force density
        rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
        Fnodes_int = zeros(Int64,size(rnodes))
        fmdens = zeros(SVector{3, Float32},Tuple(hp.N))
        ImmersedBoundaries.calculate_stretching_force!(Fnodes_int,rnodes,fp.K0,fp.S0,Val(sp.fbits))
        Fnodes_float = Fnodes_int*(2.0^-sp.fbits)
        ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float32,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
        #test total force is zeros
        @test isapprox(Float32[0.0; 0.0; 0.0;;;;], sum(reinterpret(reshape,Float32,fmdens), dims=(2,3,4)), atol=10^-7)
        #test Newton's third law
        Fp1 = [0.0,0.0,0.0]
        Fp2 = [0.0,0.0,0.0]
        #calculate for on lower particle
        for i in 1:hp.N[1]
            for j in 1:hp.N[2]
                for k in 1:div(hp.N[3],2)
                    Fp1 += view(reinterpret(reshape,Float32,fmdens),:,i,j,k)
                end
            end
        end
        #calculate for on upper particle
        for i in 1:hp.N[1]
            for j in 1:hp.N[2]
                for k in div(hp.N[3],2)+1:hp.N[3]
                    Fp2 += view(reinterpret(reshape,Float32,fmdens),:,i,j,k)
                end
            end
        end
        @test isapprox(Fp1, -Fp2, atol=10^-7)

        #test iterating over nodes first gives same result as iterating over grid first
        #calculate for density iterating over grid, then nodes
        #calculate force on filament nodes and the force density
        rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
        Fnodes_int = zeros(Int64,size(rnodes))
        fmdens = zeros(SVector{3, Float32},Tuple(hp.N))
        ImmersedBoundaries.calculate_stretching_force!(Fnodes_int,rnodes,fp.K0,fp.S0,Val(sp.fbits))
        Fnodes_float = Fnodes_int*(2.0^-sp.fbits)
        ImmersedBoundaries.calculate_fdens_grid_first!(reinterpret(reshape,Float32,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
        Fp1gridfirst = [0.0,0.0,0.0]
        Fp2gridfirst = [0.0,0.0,0.0]
        #calculate for on lower particle
        for i in 1:hp.N[1]
            for j in 1:hp.N[2]
                for k in 1:div(hp.N[3],2)
                    Fp1gridfirst += view(reinterpret(reshape,Float32,fmdens),:,i,j,k)
                end
            end
        end
        #calculate for on upper particle
        for i in 1:hp.N[1]
            for j in 1:hp.N[2]
                for k in div(hp.N[3],2)+1:hp.N[3]
                    Fp2gridfirst += view(reinterpret(reshape,Float32,fmdens),:,i,j,k)
                end
            end
        end
        @test isapprox(Fp1, Fp1gridfirst, atol=10^-7)
        @test isapprox(Fp2, Fp2gridfirst, atol=10^-7)
        

        #test force density is correct by placing a single particle at edges and corners, and 
        #randomly placing in the bulk
        N = SA[32,32,32]
        L = 1.0*10^3 #nm
        Δx = L/N[1] #nm
        npart = 1
        a = Δx #nm
        Δx1 = 0.0
        Δx2 = 0.0 
        Δx3 = 0.0
        disp = [0,0,15]*Δx

        hp = hydroparams(N,0.0,0.0,0.0,Δx,0.0)
        ibp = ibparams(npart,a)

        Fnodes_float = Float32[100.0 -150.0 50.0]
        fmdens = zeros(SVector{3, Float32},Tuple(hp.N))

        #test at corners
        for i in [-1,1]
            for j in [-1,1]
                for k in [-1,1]
                    disp = [i,j,k]*hp.N[1]*0.5*hp.Δx
                    rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
                    ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float32,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
                    @test isapprox(Float32[Fnodes_float[1]; Fnodes_float[2]; Fnodes_float[3];;;;], sum(reinterpret(reshape,Float32,fmdens*Float32(hp.Δx^3)), dims=(2,3,4)), atol=10^-7)
                end
            end
        end

        #advance over edges pointing in x-direction
        for k in [-1,1]
            for j in [-1,1]
                for i in 0:35
                    disp = [-1,j,k]*hp.N[1]*0.5*hp.Δx + [i,0,0]*hp.Δx
                    rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
                    ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float32,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
                    @test isapprox(Float32[Fnodes_float[1]; Fnodes_float[2]; Fnodes_float[3];;;;], sum(reinterpret(reshape,Float32,fmdens*Float32(hp.Δx^3)), dims=(2,3,4)), atol=10^-7)
                end
            end
        end

        #advance over edges pointing in y-direction
        for i in [-1,1]
            for k in [-1,1]
                for j in 0:35
                    disp = [i,-1,k]*hp.N[1]*0.5*hp.Δx + [0,j,0]*hp.Δx
                    rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
                    ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float32,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
                    @test isapprox(Float32[Fnodes_float[1]; Fnodes_float[2]; Fnodes_float[3];;;;], sum(reinterpret(reshape,Float32,fmdens*Float32(hp.Δx^3)), dims=(2,3,4)), atol=10^-7)
                end
            end
        end

        #advance over edges pointing in z-direction
        for i in [-1,1]
            for j in [-1,1]
                for k in 0:35
                    disp = [i,j,-1]*hp.N[1]*0.5*hp.Δx + [0,0,k]*hp.Δx
                    rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
                    ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float32,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
                    @test isapprox(Float32[Fnodes_float[1]; Fnodes_float[2]; Fnodes_float[3];;;;], sum(reinterpret(reshape,Float32,fmdens*Float32(hp.Δx^3)), dims=(2,3,4)), atol=10^-7)
                end
            end
        end

        #test by randomly placing in bulk
        for i in 1:100
            disp = rand(3).*hp.N*hp.Δx
            rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
            ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float32,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
            @test isapprox(Float32[Fnodes_float[1]; Fnodes_float[2]; Fnodes_float[3];;;;], sum(reinterpret(reshape,Float32,fmdens*Float32(hp.Δx^3)), dims=(2,3,4)), atol=10^-4)
        end

        #do same tests with Float64 math

        #test force density is correct
        N = SA[32,32,32]
        L = 1.0*10^3 #nm
        Δx = L/N[1] #nm
        npart = 2
        a = Δx #nm
        K0 = 100.0
        S0 = 10.0
        fbits = 20
        Δx1 = 0.0
        Δx2 = 0.0 
        Δx3 = 300.0
        disp = [0,0,0]*Δx

        hp = hydroparams(N,0.0,0.0,0.0,Δx,0.0)
        ibp = ibparams(npart,a)
        fp = forceparams(K0,S0,0.0,SA[0.0,0.0,0.0])
        sp = simparams(0,0.0,0.0,fbits,0)

        #calculate force on filament nodes and the force density
        rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
        Fnodes_int = zeros(Int64,size(rnodes))
        fmdens = zeros(SVector{3, Float64},Tuple(hp.N))
        ImmersedBoundaries.calculate_stretching_force!(Fnodes_int,rnodes,fp.K0,fp.S0,Val(sp.fbits))
        Fnodes_float = Fnodes_int*(2.0^-sp.fbits)
        ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float64,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
        #test total force is zeros
        @test isapprox(Float64[0.0; 0.0; 0.0;;;;], sum(reinterpret(reshape,Float64,fmdens), dims=(2,3,4)), atol=10^-7)
        #test Newton's third law
        Fp1 = [0.0,0.0,0.0]
        Fp2 = [0.0,0.0,0.0]
        #calculate for on lower particle
        for i in 1:hp.N[1]
            for j in 1:hp.N[2]
                for k in 1:div(hp.N[3],2)
                    Fp1 += view(reinterpret(reshape,Float64,fmdens),:,i,j,k)
                end
            end
        end
        #calculate for on upper particle
        for i in 1:hp.N[1]
            for j in 1:hp.N[2]
                for k in div(hp.N[3],2)+1:hp.N[3]
                    Fp2 += view(reinterpret(reshape,Float64,fmdens),:,i,j,k)
                end
            end
        end
        @test isapprox(Fp1, -Fp2, atol=10^-7)

        #test iterating over nodes first gives same result as iterating over grid first
        #calculate for density iterating over grid, then nodes
        #calculate force on filament nodes and the force density
        rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
        Fnodes_int = zeros(Int64,size(rnodes))
        fmdens = zeros(SVector{3, Float64},Tuple(hp.N))
        ImmersedBoundaries.calculate_stretching_force!(Fnodes_int,rnodes,fp.K0,fp.S0,Val(sp.fbits))
        Fnodes_float = Fnodes_int*(2.0^-sp.fbits)
        ImmersedBoundaries.calculate_fdens_grid_first!(reinterpret(reshape,Float64,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
        Fp1gridfirst = [0.0,0.0,0.0]
        Fp2gridfirst = [0.0,0.0,0.0]
        #calculate for on lower particle
        for i in 1:hp.N[1]
            for j in 1:hp.N[2]
                for k in 1:div(hp.N[3],2)
                    Fp1gridfirst += view(reinterpret(reshape,Float64,fmdens),:,i,j,k)
                end
            end
        end
        #calculate for on upper particle
        for i in 1:hp.N[1]
            for j in 1:hp.N[2]
                for k in div(hp.N[3],2)+1:hp.N[3]
                    Fp2gridfirst += view(reinterpret(reshape,Float64,fmdens),:,i,j,k)
                end
            end
        end
        @test isapprox(Fp1, Fp1gridfirst, atol=10^-7)
        @test isapprox(Fp2, Fp2gridfirst, atol=10^-7)
        

        #test force density is correct by placing a single particle at edges and corners, and 
        #randomly placing in the bulk
        N = SA[32,32,32]
        L = 1.0*10^3 #nm
        Δx = L/N[1] #nm
        npart = 1
        a = Δx #nm
        Δx1 = 0.0
        Δx2 = 0.0 
        Δx3 = 0.0
        disp = [0,0,15]*Δx

        hp = hydroparams(N,0.0,0.0,0.0,Δx,0.0)
        ibp = ibparams(npart,a)

        Fnodes_float = Float32[100.0 -150.0 50.0]
        fmdens = zeros(SVector{3, Float64},Tuple(hp.N))

        #test at corners
        for i in [-1,1]
            for j in [-1,1]
                for k in [-1,1]
                    disp = [i,j,k]*hp.N[1]*0.5*hp.Δx
                    rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
                    ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float64,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
                    @test isapprox(Float64[Fnodes_float[1]; Fnodes_float[2]; Fnodes_float[3];;;;], sum(reinterpret(reshape,Float64,fmdens*Float64(hp.Δx^3)), dims=(2,3,4)), atol=10^-7)
                end
            end
        end

        #advance over edges pointing in x-direction
        for k in [-1,1]
            for j in [-1,1]
                for i in 0:35
                    disp = [-1,j,k]*hp.N[1]*0.5*hp.Δx + [i,0,0]*hp.Δx
                    rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
                    ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float64,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
                    @test isapprox(Float64[Fnodes_float[1]; Fnodes_float[2]; Fnodes_float[3];;;;], sum(reinterpret(reshape,Float64,fmdens*Float64(hp.Δx^3)), dims=(2,3,4)), atol=10^-7)
                end
            end
        end

        #advance over edges pointing in y-direction
        for i in [-1,1]
            for k in [-1,1]
                for j in 0:35
                    disp = [i,-1,k]*hp.N[1]*0.5*hp.Δx + [0,j,0]*hp.Δx
                    rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
                    ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float64,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
                    @test isapprox(Float64[Fnodes_float[1]; Fnodes_float[2]; Fnodes_float[3];;;;], sum(reinterpret(reshape,Float64,fmdens*Float64(hp.Δx^3)), dims=(2,3,4)), atol=10^-7)
                end
            end
        end

        #advance over edges pointing in z-direction
        for i in [-1,1]
            for j in [-1,1]
                for k in 0:35
                    disp = [i,j,-1]*hp.N[1]*0.5*hp.Δx + [0,0,k]*hp.Δx
                    rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
                    ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float64,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
                    @test isapprox(Float64[Fnodes_float[1]; Fnodes_float[2]; Fnodes_float[3];;;;], sum(reinterpret(reshape,Float64,fmdens*Float64(hp.Δx^3)), dims=(2,3,4)), atol=10^-7)
                end
            end
        end

        #test by randomly placing in bulk
        for i in 1:100
            disp = rand(3).*hp.N*hp.Δx
            rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
            ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float64,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
            @test isapprox(Float64[Fnodes_float[1]; Fnodes_float[2]; Fnodes_float[3];;;;], sum(reinterpret(reshape,Float64,fmdens*Float64(hp.Δx^3)), dims=(2,3,4)), atol=10^-4)
        end
    end

end
