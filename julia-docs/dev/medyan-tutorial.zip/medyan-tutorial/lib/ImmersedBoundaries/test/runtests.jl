using ImmersedBoundaries
using Test
using StaticArrays
using Random
using FFTW
using CUDA
using PhiloxArrays

Random.seed!(1234)

@testset "ImmersedBoundaries.jl" begin
    # Write your tests here.

    @testset "Force density calculation" begin
        #test force density is correct
        N = SA[32,32,32]
        L = 1.0*10^3 #nm
        Δx = L/N[1] #nm
        npart = 2
        a = Δx #nm
        K0 = 100.0
        S0 = 10.0
        fbits = 20
        Δx1 = 0.0
        Δx2 = 0.0 
        Δx3 = 300.0
        disp = [0,0,0]*Δx

        hp = hydroparams(N,0.0,0.0,0.0,Δx,0.0)
        ibp = ibparams(npart,a)
        fp = forceparams(K0,S0,0.0,SA[0.0,0.0,0.0])
        sp = simparams(0,0.0,0.0,fbits,0)

        #calculate force on filament nodes and the force density
        rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
        Fnodes_int = zeros(Int64,size(rnodes))
        fmdens = zeros(SVector{3, Float32},Tuple(hp.N))
        ImmersedBoundaries.calculate_stretching_force!(Fnodes_int,rnodes,fp.K0,fp.S0,Val(sp.fbits))
        Fnodes_float = Fnodes_int*(2.0^-sp.fbits)
        #test stretching for is correct
        @test isapprox(Fnodes_float, Float32[0.0 0.0 K0*(Δx3-S0); 0.0 0.0 -K0*(Δx3-S0)], atol=10^-7)
        ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float32,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
        #test total force is zeros
        @test isapprox(Float32[0.0; 0.0; 0.0;;;;], sum(reinterpret(reshape,Float32,fmdens), dims=(2,3,4)), atol=10^-7)
        #test Newton's third law
        Fp1 = [0.0,0.0,0.0]
        Fp2 = [0.0,0.0,0.0]
        #calculate for on lower particle
        for i in 1:hp.N[1]
            for j in 1:hp.N[2]
                for k in 1:div(hp.N[3],2)
                    Fp1 += view(reinterpret(reshape,Float32,fmdens),:,i,j,k)
                end
            end
        end
        #calculate for on upper particle
        for i in 1:hp.N[1]
            for j in 1:hp.N[2]
                for k in div(hp.N[3],2)+1:hp.N[3]
                    Fp2 += view(reinterpret(reshape,Float32,fmdens),:,i,j,k)
                end
            end
        end
        @test isapprox(Fp1, -Fp2, atol=10^-7)

        #test iterating over nodes first gives same result as iterating over grid first
        #calculate for density iterating over grid, then nodes
        #calculate force on filament nodes and the force density
        rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
        Fnodes_int = zeros(Int64,size(rnodes))
        fmdens = zeros(SVector{3, Float32},Tuple(hp.N))
        ImmersedBoundaries.calculate_stretching_force!(Fnodes_int,rnodes,fp.K0,fp.S0,Val(sp.fbits))
        Fnodes_float = Fnodes_int*(2.0^-sp.fbits)
        ImmersedBoundaries.calculate_fdens_grid_first!(reinterpret(reshape,Float32,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
        Fp1gridfirst = [0.0,0.0,0.0]
        Fp2gridfirst = [0.0,0.0,0.0]
        #calculate for on lower particle
        for i in 1:hp.N[1]
            for j in 1:hp.N[2]
                for k in 1:div(hp.N[3],2)
                    Fp1gridfirst += view(reinterpret(reshape,Float32,fmdens),:,i,j,k)
                end
            end
        end
        #calculate for on upper particle
        for i in 1:hp.N[1]
            for j in 1:hp.N[2]
                for k in div(hp.N[3],2)+1:hp.N[3]
                    Fp2gridfirst += view(reinterpret(reshape,Float32,fmdens),:,i,j,k)
                end
            end
        end
        @test isapprox(Fp1, Fp1gridfirst, atol=10^-7)
        @test isapprox(Fp2, Fp2gridfirst, atol=10^-7)
        

        #test force density is correct by placing a single particle at edges and corners, and 
        #randomly placing in the bulk
        N = SA[32,32,32]
        L = 1.0*10^3 #nm
        Δx = L/N[1] #nm
        npart = 1
        a = Δx #nm
        Δx1 = 0.0
        Δx2 = 0.0 
        Δx3 = 0.0
        disp = [0,0,15]*Δx

        hp = hydroparams(N,0.0,0.0,0.0,Δx,0.0)
        ibp = ibparams(npart,a)

        Fnodes_float = Float32[100.0 -150.0 50.0]
        fmdens = zeros(SVector{3, Float32},Tuple(hp.N))

        #test at corners
        for i in [-1,1]
            for j in [-1,1]
                for k in [-1,1]
                    disp = [i,j,k]*hp.N[1]*0.5*hp.Δx
                    rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
                    ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float32,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
                    @test isapprox(Float32[Fnodes_float[1]; Fnodes_float[2]; Fnodes_float[3];;;;], sum(reinterpret(reshape,Float32,fmdens*Float32(hp.Δx^3)), dims=(2,3,4)), atol=10^-7)
                end
            end
        end

        #advance over edges pointing in x-direction
        for k in [-1,1]
            for j in [-1,1]
                for i in 0:35
                    disp = [-1,j,k]*hp.N[1]*0.5*hp.Δx + [i,0,0]*hp.Δx
                    rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
                    ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float32,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
                    @test isapprox(Float32[Fnodes_float[1]; Fnodes_float[2]; Fnodes_float[3];;;;], sum(reinterpret(reshape,Float32,fmdens*Float32(hp.Δx^3)), dims=(2,3,4)), atol=10^-7)
                end
            end
        end

        #advance over edges pointing in y-direction
        for i in [-1,1]
            for k in [-1,1]
                for j in 0:35
                    disp = [i,-1,k]*hp.N[1]*0.5*hp.Δx + [0,j,0]*hp.Δx
                    rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
                    ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float32,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
                    @test isapprox(Float32[Fnodes_float[1]; Fnodes_float[2]; Fnodes_float[3];;;;], sum(reinterpret(reshape,Float32,fmdens*Float32(hp.Δx^3)), dims=(2,3,4)), atol=10^-7)
                end
            end
        end

        #advance over edges pointing in z-direction
        for i in [-1,1]
            for j in [-1,1]
                for k in 0:35
                    disp = [i,j,-1]*hp.N[1]*0.5*hp.Δx + [0,0,k]*hp.Δx
                    rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
                    ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float32,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
                    @test isapprox(Float32[Fnodes_float[1]; Fnodes_float[2]; Fnodes_float[3];;;;], sum(reinterpret(reshape,Float32,fmdens*Float32(hp.Δx^3)), dims=(2,3,4)), atol=10^-7)
                end
            end
        end

        #test by randomly placing in bulk
        for i in 1:100
            disp = rand(3).*hp.N*hp.Δx
            rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
            ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float32,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
            @test isapprox(Float32[Fnodes_float[1]; Fnodes_float[2]; Fnodes_float[3];;;;], sum(reinterpret(reshape,Float32,fmdens*Float32(hp.Δx^3)), dims=(2,3,4)), atol=10^-4)
        end

        #do same tests with Float64 math

        #test force density is correct
        N = SA[32,32,32]
        L = 1.0*10^3 #nm
        Δx = L/N[1] #nm
        npart = 2
        a = Δx #nm
        K0 = 100.0
        S0 = 10.0
        fbits = 20
        Δx1 = 0.0
        Δx2 = 0.0 
        Δx3 = 300.0
        disp = [0,0,0]*Δx

        hp = hydroparams(N,0.0,0.0,0.0,Δx,0.0)
        ibp = ibparams(npart,a)
        fp = forceparams(K0,S0,0.0,SA[0.0,0.0,0.0])
        sp = simparams(0,0.0,0.0,fbits,0)

        #calculate force on filament nodes and the force density
        rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
        Fnodes_int = zeros(Int64,size(rnodes))
        fmdens = zeros(SVector{3, Float64},Tuple(hp.N))
        ImmersedBoundaries.calculate_stretching_force!(Fnodes_int,rnodes,fp.K0,fp.S0,Val(sp.fbits))
        Fnodes_float = Fnodes_int*(2.0^-sp.fbits)
        ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float64,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
        #test total force is zeros
        @test isapprox(Float64[0.0; 0.0; 0.0;;;;], sum(reinterpret(reshape,Float64,fmdens), dims=(2,3,4)), atol=10^-7)
        #test Newton's third law
        Fp1 = [0.0,0.0,0.0]
        Fp2 = [0.0,0.0,0.0]
        #calculate for on lower particle
        for i in 1:hp.N[1]
            for j in 1:hp.N[2]
                for k in 1:div(hp.N[3],2)
                    Fp1 += view(reinterpret(reshape,Float64,fmdens),:,i,j,k)
                end
            end
        end
        #calculate for on upper particle
        for i in 1:hp.N[1]
            for j in 1:hp.N[2]
                for k in div(hp.N[3],2)+1:hp.N[3]
                    Fp2 += view(reinterpret(reshape,Float64,fmdens),:,i,j,k)
                end
            end
        end
        @test isapprox(Fp1, -Fp2, atol=10^-7)

        #test iterating over nodes first gives same result as iterating over grid first
        #calculate for density iterating over grid, then nodes
        #calculate force on filament nodes and the force density
        rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
        Fnodes_int = zeros(Int64,size(rnodes))
        fmdens = zeros(SVector{3, Float64},Tuple(hp.N))
        ImmersedBoundaries.calculate_stretching_force!(Fnodes_int,rnodes,fp.K0,fp.S0,Val(sp.fbits))
        Fnodes_float = Fnodes_int*(2.0^-sp.fbits)
        ImmersedBoundaries.calculate_fdens_grid_first!(reinterpret(reshape,Float64,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
        Fp1gridfirst = [0.0,0.0,0.0]
        Fp2gridfirst = [0.0,0.0,0.0]
        #calculate for on lower particle
        for i in 1:hp.N[1]
            for j in 1:hp.N[2]
                for k in 1:div(hp.N[3],2)
                    Fp1gridfirst += view(reinterpret(reshape,Float64,fmdens),:,i,j,k)
                end
            end
        end
        #calculate for on upper particle
        for i in 1:hp.N[1]
            for j in 1:hp.N[2]
                for k in div(hp.N[3],2)+1:hp.N[3]
                    Fp2gridfirst += view(reinterpret(reshape,Float64,fmdens),:,i,j,k)
                end
            end
        end
        @test isapprox(Fp1, Fp1gridfirst, atol=10^-7)
        @test isapprox(Fp2, Fp2gridfirst, atol=10^-7)
        

        #test force density is correct by placing a single particle at edges and corners, and 
        #randomly placing in the bulk
        N = SA[32,32,32]
        L = 1.0*10^3 #nm
        Δx = L/N[1] #nm
        npart = 1
        a = Δx #nm
        Δx1 = 0.0
        Δx2 = 0.0 
        Δx3 = 0.0
        disp = [0,0,15]*Δx

        hp = hydroparams(N,0.0,0.0,0.0,Δx,0.0)
        ibp = ibparams(npart,a)

        Fnodes_float = Float32[100.0 -150.0 50.0]
        fmdens = zeros(SVector{3, Float64},Tuple(hp.N))

        #test at corners
        for i in [-1,1]
            for j in [-1,1]
                for k in [-1,1]
                    disp = [i,j,k]*hp.N[1]*0.5*hp.Δx
                    rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
                    ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float64,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
                    @test isapprox(Float64[Fnodes_float[1]; Fnodes_float[2]; Fnodes_float[3];;;;], sum(reinterpret(reshape,Float64,fmdens*Float64(hp.Δx^3)), dims=(2,3,4)), atol=10^-7)
                end
            end
        end

        #advance over edges pointing in x-direction
        for k in [-1,1]
            for j in [-1,1]
                for i in 0:35
                    disp = [-1,j,k]*hp.N[1]*0.5*hp.Δx + [i,0,0]*hp.Δx
                    rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
                    ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float64,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
                    @test isapprox(Float64[Fnodes_float[1]; Fnodes_float[2]; Fnodes_float[3];;;;], sum(reinterpret(reshape,Float64,fmdens*Float64(hp.Δx^3)), dims=(2,3,4)), atol=10^-7)
                end
            end
        end

        #advance over edges pointing in y-direction
        for i in [-1,1]
            for k in [-1,1]
                for j in 0:35
                    disp = [i,-1,k]*hp.N[1]*0.5*hp.Δx + [0,j,0]*hp.Δx
                    rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
                    ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float64,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
                    @test isapprox(Float64[Fnodes_float[1]; Fnodes_float[2]; Fnodes_float[3];;;;], sum(reinterpret(reshape,Float64,fmdens*Float64(hp.Δx^3)), dims=(2,3,4)), atol=10^-7)
                end
            end
        end

        #advance over edges pointing in z-direction
        for i in [-1,1]
            for j in [-1,1]
                for k in 0:35
                    disp = [i,j,-1]*hp.N[1]*0.5*hp.Δx + [0,0,k]*hp.Δx
                    rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
                    ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float64,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
                    @test isapprox(Float64[Fnodes_float[1]; Fnodes_float[2]; Fnodes_float[3];;;;], sum(reinterpret(reshape,Float64,fmdens*Float64(hp.Δx^3)), dims=(2,3,4)), atol=10^-7)
                end
            end
        end

        #test by randomly placing in bulk
        for i in 1:100
            disp = rand(3).*hp.N*hp.Δx
            rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
            ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float64,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
            @test isapprox(Float64[Fnodes_float[1]; Fnodes_float[2]; Fnodes_float[3];;;;], sum(reinterpret(reshape,Float64,fmdens*Float64(hp.Δx^3)), dims=(2,3,4)), atol=10^-4)
        end
    end

    @testset "Check deterministic velocity field evolution" begin

        ux0 = 100.0 #nm/ns
        N = [32,32,32]
        L = 1.0*10^3 #nm
        kT = (8.316*1E3)*300.0 #(nm^2*amu/ns^2*K)*K
        ρ = 602.0 #amu/nm^3
        μ = 6.02*10^5 #amu/(nm ns)
        Δx = L/N[1] #nm
        Δt = 1.0*(10^-2) #ns
        #Δt = (Δx^2)*(10^-4) #ns   
        nstep = 10
        key = 1234
        hp = hydroparams(N,kT,ρ,μ,Δx,Δt)
        sp = simparams(nstep,0.0,0.0,0,0)
        #define slab of points in k-space
        Nirfft = (div(hp.N[1],2)+1,hp.N[2],hp.N[3])
        #initialize velocity field and IB node positions in r-space
        um = zeros(SVector{3, Float32},Tuple(hp.N))
        um[div(hp.N[1],2),div(hp.N[2],2),div(hp.N[3],2)] = Float32[1.0,0.0,0.0]*ux0
        Γm = zeros(SVector{3, Float32},Tuple(hp.N))
        #initialize velocity field and IB node positions in k-space
        fkdens = zeros(SVector{3, ComplexF32},Tuple(hp.N))
        P_rfft = plan_rfft(reinterpret(reshape,Float32,um),(2,3,4))
        uk = Float32(inv(prod(hp.N)))*reinterpret(reshape,SVector{3,ComplexF32},P_rfft*reinterpret(reshape,Float32,um))
        Γk = zeros(SVector{3, ComplexF32},Nirfft)
        #initalize velocity data array
        total_um = copy(reinterpret(reshape,Float32,um))
        #Define the rfft and irfft plan
        P_brfft = plan_brfft(reinterpret(reshape,ComplexF32,uk),hp.N[1],(2,3,4))
        #integrate system forward in time
        #@show view(um,div(hp.N[1],2),div(hp.N[2],2),div(hp.N[3],2))
        for it in 1:sp.nstep
            #calculate the fields
            ImmersedBoundaries.update_fields!(uk,uk,Γk,fkdens,hp,it,key)
            #get r-space velocity field and store
            um = P_brfft*reinterpret(reshape,ComplexF32,uk)
            #@show view(um,:,div(hp.N[1],2),div(hp.N[2],2),div(hp.N[3],2))
        end
    end

    function calc_rnodes_exact(t,X0,V0)
        Xt = X0 + V0*t
        return Xt
    end

    @testset "Check immersed boundary node position update" begin
        
        Γm0 = 100.0 #nm
        N = [32,32,32]
        L = 1.0*10^3 #nm
        kT = (8.316*1E3)*300.0 #(nm^2*amu/ns^2*K)*K
        ρ = 602.0 #amu/nm^3
        μ = 6.02*10^5 #amu/(nm ns)
        Δx = L/N[1] #nm
        npart = 1
        a = Δx #nm
        Δt = 1.0*(10^3) #ns
        nstep = 100
        key = 1234
        hp = hydroparams(N,kT,ρ,μ,Δx,Δt)
        ibp = ibparams(npart,a)
        sp = simparams(nstep,0.0,0.0,0,0)
        rnodes = Float32[div(hp.N[1],2)*hp.Δx div(hp.N[2],2)*hp.Δx div(hp.N[3],2)*hp.Δx] + rand(Float32,3)'*Float32(hp.Δx)*0
        rnodes0 = copy(rnodes)
        Γm = zeros(SVector{3, Float32},Tuple(hp.N))
        direction = rand(Float32,3)
        direction = [1.0,0.0,0.0]
        reinterpret(reshape,Float32,Γm) .= direction*Γm0
        Γm = reinterpret(reshape,Float32,Γm)
        for it in 1:sp.nstep
            rnodes_exact = calc_rnodes_exact(it*Float32(hp.Δt),rnodes0,direction'*Float32(Γm0/hp.Δt))
            ImmersedBoundaries.update_rnodes_unwrapped!(rnodes,rnodes,Γm,hp.Δx,hp.N,ibp.a)
            @test isapprox(rnodes, rnodes_exact, atol=10^-1)
        end
    end

    @testset "Calculate Single IB node diffusion coefficient for comparison with Atzberger's results" begin
        N = [32,32,32]
        L = 1.0*10^3 #nm
        kT = (8.316*1E3)*300.0 #(nm^2*amu/ns^2*K)*K
        ρ = 602.0 #amu/nm^3
        μ = 6.02*10^5 #amu/(nm ns)
        Δx = L/N[1] #nm
        npart = 1
        a_values = [1,2,3,4,5]*Δx #nm
        Δt = 1.0*(10^3) #ns
        nstep = 10
        nrep = 2
        hp = hydroparams(N,kT,ρ,μ,Δx,Δt)
        ibp = ibparams(1,Δx)
        sp = simparams(nstep,0.0,0.0,0,nrep)
        D_conversion_factor = 1000
        Dymin = 0
        Dymax = 5
        Dyticksize = 1
        filename_plot = "D_est_vs_a_samp_size_$nrep.pdf"
        D_est_all_a, D_est_stddev_all_a, D_est_stderr_all_a = ImmersedBoundaries.main_estimate_D(a_values,hp,ibp,sp)
        ImmersedBoundaries.plot_D_est(D_est_all_a,D_est_stddev_all_a,D_est_stderr_all_a,a_values,Dymin,Dymax,Dyticksize,D_conversion_factor,filename_plot,hp,ibp)
    end

    #CUDA kernel tests

    @testset "Test CPU and GPU versions of functions give same answer with random inputs" begin
        #test stretching force
        npart = 5
        N = SA[32,32,32]
        L = 1.0*10^3 #nm
        kT = (8.316*1E3)*300.0 #(nm^2*amu/ns^2*K)*K
        ρ = 602.0 #amu/nm^3
        μ = 6.02*10^5 #amu/(nm ns)
        Δx = L/N[1] #nm
        a = Δx #nm
        Δt = 1.0*(10^3) #ns
        K0 = 10000.0
        S0 = 10.0 #nm
        fbits = 20

        hp = hydroparams(N,kT,ρ,μ,Δx,Δt)
        ibp = ibparams(npart,a)
        fp = forceparams(K0,S0,0.0,SA[0.0,0.0,0.0])
        sp = simparams(0,0.0,0.0,fbits,0)

        rnodes_host = hp.N[1]*hp.Δx*rand(Float32,ibp.npart,3)
        Fnodes_host = zeros(Int64,size(rnodes_host))
        Fnodes_host_copy = copy(Fnodes_host)
        ImmersedBoundaries.calculate_stretching_force!(Fnodes_host,rnodes_host,fp.K0,fp.S0,Val(sp.fbits))
        ImmersedBoundaries.calculate_stretching_force_CUDA_wrapper!(Fnodes_host_copy,rnodes_host,fp.K0,fp.S0,Val(sp.fbits))
        @test isapprox(Fnodes_host, Fnodes_host_copy, atol=10^6)
    
        #test force density
        Fnodes_host_float = Fnodes_host*(Float32(2.0)^-sp.fbits)         
        fdens_host = zeros(SVector{3, Float32},Tuple(hp.N))
        fdens_host_copy = copy(fdens_host)
        ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float32,fdens_host),rnodes_host,Fnodes_host_float,hp.N,hp.Δx,ibp.a)
        ImmersedBoundaries.calculate_fdens_CUDA_wrapper!(fdens_host_copy,rnodes_host,Fnodes_host_float,hp.N,hp.Δx,ibp.a)
        @test isapprox(fdens_host, fdens_host_copy, atol=10^-3)

        #test field update
        key = rand(UInt64)
        counter = rand(UInt64)
        Nirfft = (div(hp.N[1],2)+1,hp.N[2],hp.N[3])
        uk_host = reinterpret(reshape,SVector{3, ComplexF32},fft(reinterpret(reshape,Float32,rand(SVector{3, Float32},Nirfft)),(2,3,4)))
        #uk_host = zeros(SVector{3, ComplexF32},Nirfft)
        Γk_host = zeros(SVector{3, ComplexF32},Nirfft)
        uk_host_copy = copy(uk_host)
        Γk_host_copy = copy(Γk_host)
        fkdens_host = reinterpret(reshape,SVector{3, ComplexF32},fft(reinterpret(reshape,Float32,fdens_host),(2,3,4)))
        ImmersedBoundaries.update_fields!(uk_host,uk_host,Γk_host,fkdens_host,hp,counter,key)
        ImmersedBoundaries.calculate_update_fields_CUDA_wrapper!(uk_host_copy,uk_host_copy,Γk_host_copy,fkdens_host,hp,counter,key)
        @test isapprox(uk_host, uk_host_copy, atol=10^-5)
        @test isapprox(Γk_host, Γk_host_copy, atol=10^-5)

        #test position update
        P_brfft = plan_brfft(reinterpret(reshape,ComplexF32,Γk_host),hp.N[1],(2,3,4))
        Γm_host = P_brfft*reinterpret(reshape,Complex{Float32},Γk_host)
        rnodes_host_copy = copy(rnodes_host) 
        @show rnodes_host
        @show rnodes_host_copy
        ImmersedBoundaries.update_rnodes_wrapped!(rnodes_host,rnodes_host,Γm_host,hp.Δx,hp.N,ibp.a)
        ImmersedBoundaries.calculate_update_rnodes_CUDA_wrapper!(rnodes_host_copy,rnodes_host_copy,reinterpret(reshape,SVector{3, Float32},Γm_host),hp.N,hp.Δx,ibp.a)
        @show rnodes_host
        @show rnodes_host_copy
        #@test isapprox(rnodes_host, rnodes_host_copy, atol=10^-1)
    end
        
        
    @testset "Force density calculation with CUDA" begin
        #test force density is correct
        N = SA[32,32,32]
        L = 1.0*10^3 #nm
        Δx = L/N[1] #nm
        npart = 2
        a = Δx #nm
        K0 = 100.0
        S0 = 10.0
        fbits = 20
        Δx1 = 0.0
        Δx2 = 0.0 
        Δx3 = 300.0
        disp = [0,0,0]*Δx

        hp = hydroparams(N,0.0,0.0,0.0,Δx,0.0)
        ibp = ibparams(npart,a)
        fp = forceparams(K0,S0,0.0,SA[0.0,0.0,0.0])
        sp = simparams(0,0.0,0.0,fbits,0)

        #calculate force on filament nodes and the force density
        rnodes = cu(ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp))
        Fnodes_int = cu(zeros(Int64,size(rnodes)))
        fmdens = cu(zeros(SVector{3, Float32},Tuple(hp.N)))

        numthreads = 256
        numblocks = ceil(Int, npart/numthreads)
        @cuda threads=numthreads blocks=numblocks ImmersedBoundaries.calculate_stretching_force_CUDA!(Fnodes_int,rnodes,fp.K0,fp.S0,Val(sp.fbits))
        Fnodes_float = Fnodes_int*(Float32(2.0)^-sp.fbits)
        @cuda threads=numthreads blocks=numblocks ImmersedBoundaries.calculate_fdens_CUDA!(reinterpret(reshape,Float32,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
        #test total force is zeros
        @test isapprox(Float32[0.0; 0.0; 0.0;;;;], sum(reinterpret(reshape,Float32,Array(fmdens)), dims=(2,3,4)), atol=10^-7)

    end

    @testset "Force density calculation with CUDA" begin
        #test force density is correct
        N = SA[32,32,32]
        L = 1.0*10^3 #nm
        Δx = L/N[1] #nm
        npart = 20
        a = Δx #nm
        K0 = 100.0
        S0 = 1.0
        fbits = 20
        Δx1 = 0.0
        Δx2 = 0.0 
        Δx3 = 3.0
        disp = [0,0,0]*Δx

        hp = hydroparams(N,0.0,0.0,0.0,Δx,0.0)
        ibp = ibparams(npart,a)
        fp = forceparams(K0,S0,0.0,SA[0.0,0.0,0.0])
        sp = simparams(0,0.0,0.0,fbits,0)

        #calculate force on filament nodes and the force density
        rnodes = cu(ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp))
        Fnodes_int = cu(zeros(Int64,size(rnodes)))
        fmdens = cu(zeros(SVector{3, Float32},Tuple(hp.N)))

        numthreads = 256
        numblocks_nodes = ceil(Int, ibp.npart/numthreads)
        numblocks_grids = ceil(Int, prod(hp.N)/numthreads)
        @cuda threads=numthreads blocks=numblocks_nodes ImmersedBoundaries.calculate_stretching_force_CUDA!(Fnodes_int,rnodes,fp.K0,fp.S0,Val(sp.fbits))
        Fnodes_float = Fnodes_int*(Float32(2.0)^-sp.fbits)
        @cuda threads=numthreads blocks=numblocks_grids ImmersedBoundaries.calculate_fdens_CUDA!(reinterpret(reshape,Float32,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
        
        Nirfft = (div(hp.N[1],2)+1,hp.N[2],hp.N[3]) 
        ukold = cu(zeros(SVector{3, ComplexF32},Tuple(hp.N)))
        uknew = cu(zeros(SVector{3, ComplexF32},Tuple(hp.N)))
        Γk = cu(zeros(SVector{3, ComplexF32},Nirfft))
        fkdens = cu(zeros(SVector{3, ComplexF32},Nirfft))
        counter = 1
        key = 1
        @cuda threads=numthreads blocks=numblocks_grids ImmersedBoundaries.update_fields_CUDA!(ukold,uknew,Γk,fkdens,hp,counter,key)

        Γm = cu(zeros(SVector{3, Float32},Tuple(hp.N)))
        @cuda threads=numthreads blocks=numblocks_nodes ImmersedBoundaries.update_rnodes_CUDA!(rnodes,rnodes,Γm,hp.N,hp.Δx,ibp.a)
    end

    @testset "Calculate Single IB node diffusion coefficient for comparison with Atzberger's results" begin
        N = [32,32,32]
        L = 1.0*10^3 #nm
        kT = (8.316*1E3)*300.0 #(nm^2*amu/ns^2*K)*K
        ρ = 602.0 #amu/nm^3
        μ = 6.02*10^5 #amu/(nm ns)
        Δx = L/N[1] #nm
        npart = 1
        a_values = [1,2,3,4,5]*Δx #nm
        Δt = 1.0*(10^3) #ns
        nstep = 1000
        nrep = 1
        hp = hydroparams(N,kT,ρ,μ,Δx,Δt)
        ibp = ibparams(1,Δx)
        sp = simparams(nstep,0.0,0.0,0,nrep)
        #D_conversion_factor = 1000
        #Dymin = 0
        #Dymax = 5
        #Dyticksize = 1
        #filename_plot = "CUDA_D_est_vs_a_samp_size_$nrep.pdf"
        key = 1
        ImmersedBoundaries.main_single_CUDA(hp,ibp,sp,key)
        #ImmersedBoundaries.main_single_free_Float32(hp,ibp,sp,key)
    end

end
