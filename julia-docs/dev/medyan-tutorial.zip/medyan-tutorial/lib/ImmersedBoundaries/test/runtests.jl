using ImmersedBoundaries
using Test
using StaticArrays
using Random
using FFTW

Random.seed!(1234)

@testset "ImmersedBoundaries.jl" begin
    # Write your tests here.
    
    @testset "Force density calculation" begin
        #test force density is correct
        N = SA[32,32,32]
        L = 1.0*10^3 #nm
        Δx = L/N[1] #nm
        npart = 2
        a = Δx #nm
        K0 = 100.0
        S0 = 10.0
        fbits = 20
        Δx1 = 0.0
        Δx2 = 0.0 
        Δx3 = 300.0
        disp = [0,0,0]*Δx

        hp = hydroparams(N,0.0,0.0,0.0,Δx,0.0)
        ibp = ibparams(npart,a)
        fp = forceparams(K0,S0,0.0,SA[0.0,0.0,0.0])
        sp = simparams(0,0.0,0.0,fbits,0)

        #calculate force on filament nodes and the force density
        rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
        Fnodes_int = zeros(Int64,size(rnodes))
        fmdens = zeros(SVector{3, Float32},Tuple(hp.N))
        ImmersedBoundaries.calculate_stretching_force!(Fnodes_int,rnodes,fp.K0,fp.S0,Val(sp.fbits))
        Fnodes_float = Fnodes_int*(2.0^-sp.fbits)
        ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float32,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
        #test total force is zeros
        @test isapprox(Float32[0.0; 0.0; 0.0;;;;], sum(reinterpret(reshape,Float32,fmdens), dims=(2,3,4)), atol=10^-7)
        #test Newton's third law
        Fp1 = [0.0,0.0,0.0]
        Fp2 = [0.0,0.0,0.0]
        #calculate for on lower particle
        for i in 1:hp.N[1]
            for j in 1:hp.N[2]
                for k in 1:div(hp.N[3],2)
                    Fp1 += view(reinterpret(reshape,Float32,fmdens),:,i,j,k)
                end
            end
        end
        #calculate for on upper particle
        for i in 1:hp.N[1]
            for j in 1:hp.N[2]
                for k in div(hp.N[3],2)+1:hp.N[3]
                    Fp2 += view(reinterpret(reshape,Float32,fmdens),:,i,j,k)
                end
            end
        end
        @test isapprox(Fp1, -Fp2, atol=10^-7)

        #test iterating over nodes first gives same result as iterating over grid first
        #calculate for density iterating over grid, then nodes
        #calculate force on filament nodes and the force density
        rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
        Fnodes_int = zeros(Int64,size(rnodes))
        fmdens = zeros(SVector{3, Float32},Tuple(hp.N))
        ImmersedBoundaries.calculate_stretching_force!(Fnodes_int,rnodes,fp.K0,fp.S0,Val(sp.fbits))
        Fnodes_float = Fnodes_int*(2.0^-sp.fbits)
        ImmersedBoundaries.calculate_fdens_grid_first!(reinterpret(reshape,Float32,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
        Fp1gridfirst = [0.0,0.0,0.0]
        Fp2gridfirst = [0.0,0.0,0.0]
        #calculate for on lower particle
        for i in 1:hp.N[1]
            for j in 1:hp.N[2]
                for k in 1:div(hp.N[3],2)
                    Fp1gridfirst += view(reinterpret(reshape,Float32,fmdens),:,i,j,k)
                end
            end
        end
        #calculate for on upper particle
        for i in 1:hp.N[1]
            for j in 1:hp.N[2]
                for k in div(hp.N[3],2)+1:hp.N[3]
                    Fp2gridfirst += view(reinterpret(reshape,Float32,fmdens),:,i,j,k)
                end
            end
        end
        @test isapprox(Fp1, Fp1gridfirst, atol=10^-7)
        @test isapprox(Fp2, Fp2gridfirst, atol=10^-7)
        

        #test force density is correct by placing a single particle at edges and corners, and 
        #randomly placing in the bulk
        N = SA[32,32,32]
        L = 1.0*10^3 #nm
        Δx = L/N[1] #nm
        npart = 1
        a = Δx #nm
        Δx1 = 0.0
        Δx2 = 0.0 
        Δx3 = 0.0
        disp = [0,0,15]*Δx

        hp = hydroparams(N,0.0,0.0,0.0,Δx,0.0)
        ibp = ibparams(npart,a)

        Fnodes_float = Float32[100.0 -150.0 50.0]
        fmdens = zeros(SVector{3, Float32},Tuple(hp.N))

        #test at corners
        for i in [-1,1]
            for j in [-1,1]
                for k in [-1,1]
                    disp = [i,j,k]*hp.N[1]*0.5*hp.Δx
                    rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
                    ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float32,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
                    @test isapprox(Float32[Fnodes_float[1]; Fnodes_float[2]; Fnodes_float[3];;;;], sum(reinterpret(reshape,Float32,fmdens*Float32(hp.Δx^3)), dims=(2,3,4)), atol=10^-7)
                end
            end
        end

        #advance over edges pointing in x-direction
        for k in [-1,1]
            for j in [-1,1]
                for i in 0:35
                    disp = [-1,j,k]*hp.N[1]*0.5*hp.Δx + [i,0,0]*hp.Δx
                    rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
                    ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float32,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
                    @test isapprox(Float32[Fnodes_float[1]; Fnodes_float[2]; Fnodes_float[3];;;;], sum(reinterpret(reshape,Float32,fmdens*Float32(hp.Δx^3)), dims=(2,3,4)), atol=10^-7)
                end
            end
        end

        #advance over edges pointing in y-direction
        for i in [-1,1]
            for k in [-1,1]
                for j in 0:35
                    disp = [i,-1,k]*hp.N[1]*0.5*hp.Δx + [0,j,0]*hp.Δx
                    rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
                    ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float32,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
                    @test isapprox(Float32[Fnodes_float[1]; Fnodes_float[2]; Fnodes_float[3];;;;], sum(reinterpret(reshape,Float32,fmdens*Float32(hp.Δx^3)), dims=(2,3,4)), atol=10^-7)
                end
            end
        end

        #advance over edges pointing in z-direction
        for i in [-1,1]
            for j in [-1,1]
                for k in 0:35
                    disp = [i,j,-1]*hp.N[1]*0.5*hp.Δx + [0,0,k]*hp.Δx
                    rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
                    ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float32,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
                    @test isapprox(Float32[Fnodes_float[1]; Fnodes_float[2]; Fnodes_float[3];;;;], sum(reinterpret(reshape,Float32,fmdens*Float32(hp.Δx^3)), dims=(2,3,4)), atol=10^-7)
                end
            end
        end

        #test by randomly placing in bulk
        for i in 1:100
            disp = rand(3).*hp.N*hp.Δx
            rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
            ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float32,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
            @test isapprox(Float32[Fnodes_float[1]; Fnodes_float[2]; Fnodes_float[3];;;;], sum(reinterpret(reshape,Float32,fmdens*Float32(hp.Δx^3)), dims=(2,3,4)), atol=10^-4)
        end

        #do same tests with Float64 math

        #test force density is correct
        N = SA[32,32,32]
        L = 1.0*10^3 #nm
        Δx = L/N[1] #nm
        npart = 2
        a = Δx #nm
        K0 = 100.0
        S0 = 10.0
        fbits = 20
        Δx1 = 0.0
        Δx2 = 0.0 
        Δx3 = 300.0
        disp = [0,0,0]*Δx

        hp = hydroparams(N,0.0,0.0,0.0,Δx,0.0)
        ibp = ibparams(npart,a)
        fp = forceparams(K0,S0,0.0,SA[0.0,0.0,0.0])
        sp = simparams(0,0.0,0.0,fbits,0)

        #calculate force on filament nodes and the force density
        rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
        Fnodes_int = zeros(Int64,size(rnodes))
        fmdens = zeros(SVector{3, Float64},Tuple(hp.N))
        ImmersedBoundaries.calculate_stretching_force!(Fnodes_int,rnodes,fp.K0,fp.S0,Val(sp.fbits))
        Fnodes_float = Fnodes_int*(2.0^-sp.fbits)
        ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float64,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
        #test total force is zeros
        @test isapprox(Float64[0.0; 0.0; 0.0;;;;], sum(reinterpret(reshape,Float64,fmdens), dims=(2,3,4)), atol=10^-7)
        #test Newton's third law
        Fp1 = [0.0,0.0,0.0]
        Fp2 = [0.0,0.0,0.0]
        #calculate for on lower particle
        for i in 1:hp.N[1]
            for j in 1:hp.N[2]
                for k in 1:div(hp.N[3],2)
                    Fp1 += view(reinterpret(reshape,Float64,fmdens),:,i,j,k)
                end
            end
        end
        #calculate for on upper particle
        for i in 1:hp.N[1]
            for j in 1:hp.N[2]
                for k in div(hp.N[3],2)+1:hp.N[3]
                    Fp2 += view(reinterpret(reshape,Float64,fmdens),:,i,j,k)
                end
            end
        end
        @test isapprox(Fp1, -Fp2, atol=10^-7)

        #test iterating over nodes first gives same result as iterating over grid first
        #calculate for density iterating over grid, then nodes
        #calculate force on filament nodes and the force density
        rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
        Fnodes_int = zeros(Int64,size(rnodes))
        fmdens = zeros(SVector{3, Float64},Tuple(hp.N))
        ImmersedBoundaries.calculate_stretching_force!(Fnodes_int,rnodes,fp.K0,fp.S0,Val(sp.fbits))
        Fnodes_float = Fnodes_int*(2.0^-sp.fbits)
        ImmersedBoundaries.calculate_fdens_grid_first!(reinterpret(reshape,Float64,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
        Fp1gridfirst = [0.0,0.0,0.0]
        Fp2gridfirst = [0.0,0.0,0.0]
        #calculate for on lower particle
        for i in 1:hp.N[1]
            for j in 1:hp.N[2]
                for k in 1:div(hp.N[3],2)
                    Fp1gridfirst += view(reinterpret(reshape,Float64,fmdens),:,i,j,k)
                end
            end
        end
        #calculate for on upper particle
        for i in 1:hp.N[1]
            for j in 1:hp.N[2]
                for k in div(hp.N[3],2)+1:hp.N[3]
                    Fp2gridfirst += view(reinterpret(reshape,Float64,fmdens),:,i,j,k)
                end
            end
        end
        @test isapprox(Fp1, Fp1gridfirst, atol=10^-7)
        @test isapprox(Fp2, Fp2gridfirst, atol=10^-7)
        

        #test force density is correct by placing a single particle at edges and corners, and 
        #randomly placing in the bulk
        N = SA[32,32,32]
        L = 1.0*10^3 #nm
        Δx = L/N[1] #nm
        npart = 1
        a = Δx #nm
        Δx1 = 0.0
        Δx2 = 0.0 
        Δx3 = 0.0
        disp = [0,0,15]*Δx

        hp = hydroparams(N,0.0,0.0,0.0,Δx,0.0)
        ibp = ibparams(npart,a)

        Fnodes_float = Float32[100.0 -150.0 50.0]
        fmdens = zeros(SVector{3, Float64},Tuple(hp.N))

        #test at corners
        for i in [-1,1]
            for j in [-1,1]
                for k in [-1,1]
                    disp = [i,j,k]*hp.N[1]*0.5*hp.Δx
                    rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
                    ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float64,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
                    @test isapprox(Float64[Fnodes_float[1]; Fnodes_float[2]; Fnodes_float[3];;;;], sum(reinterpret(reshape,Float64,fmdens*Float64(hp.Δx^3)), dims=(2,3,4)), atol=10^-7)
                end
            end
        end

        #advance over edges pointing in x-direction
        for k in [-1,1]
            for j in [-1,1]
                for i in 0:35
                    disp = [-1,j,k]*hp.N[1]*0.5*hp.Δx + [i,0,0]*hp.Δx
                    rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
                    ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float64,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
                    @test isapprox(Float64[Fnodes_float[1]; Fnodes_float[2]; Fnodes_float[3];;;;], sum(reinterpret(reshape,Float64,fmdens*Float64(hp.Δx^3)), dims=(2,3,4)), atol=10^-7)
                end
            end
        end

        #advance over edges pointing in y-direction
        for i in [-1,1]
            for k in [-1,1]
                for j in 0:35
                    disp = [i,-1,k]*hp.N[1]*0.5*hp.Δx + [0,j,0]*hp.Δx
                    rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
                    ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float64,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
                    @test isapprox(Float64[Fnodes_float[1]; Fnodes_float[2]; Fnodes_float[3];;;;], sum(reinterpret(reshape,Float64,fmdens*Float64(hp.Δx^3)), dims=(2,3,4)), atol=10^-7)
                end
            end
        end

        #advance over edges pointing in z-direction
        for i in [-1,1]
            for j in [-1,1]
                for k in 0:35
                    disp = [i,j,-1]*hp.N[1]*0.5*hp.Δx + [0,0,k]*hp.Δx
                    rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
                    ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float64,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
                    @test isapprox(Float64[Fnodes_float[1]; Fnodes_float[2]; Fnodes_float[3];;;;], sum(reinterpret(reshape,Float64,fmdens*Float64(hp.Δx^3)), dims=(2,3,4)), atol=10^-7)
                end
            end
        end

        #test by randomly placing in bulk
        for i in 1:100
            disp = rand(3).*hp.N*hp.Δx
            rnodes = ImmersedBoundaries.initialize_IB_nodes_filparaz(ibp.npart,Δx1,Δx2,Δx3,hp.Δx,hp.N,disp)
            ImmersedBoundaries.calculate_fdens!(reinterpret(reshape,Float64,fmdens),rnodes,Fnodes_float,hp.N,hp.Δx,ibp.a)
            @test isapprox(Float64[Fnodes_float[1]; Fnodes_float[2]; Fnodes_float[3];;;;], sum(reinterpret(reshape,Float64,fmdens*Float64(hp.Δx^3)), dims=(2,3,4)), atol=10^-4)
        end
    end

    @testset "Check deterministic velocity field evolution" begin

        ux0 = 100.0 #nm/ns
        N = [32,32,32]
        L = 1.0*10^3 #nm
        kT = (8.316*1E3)*300.0 #(nm^2*amu/ns^2*K)*K
        ρ = 602.0 #amu/nm^3
        μ = 6.02*10^5 #amu/(nm ns)
        Δx = L/N[1] #nm
        Δt = 1.0*(10^-2) #ns
        #Δt = (Δx^2)*(10^-4) #ns   
        nstep = 10
        key = 1234
        hp = hydroparams(N,kT,ρ,μ,Δx,Δt)
        sp = simparams(nstep,0.0,0.0,0,0)
        #define slab of points in k-space
        Nirfft = (div(hp.N[1],2)+1,hp.N[2],hp.N[3])
        #initialize velocity field and IB node positions in r-space
        um = zeros(SVector{3, Float32},Tuple(hp.N))
        um[div(hp.N[1],2),div(hp.N[2],2),div(hp.N[3],2)] = Float32[1.0,0.0,0.0]*ux0
        Γm = zeros(SVector{3, Float32},Tuple(hp.N))
        #initialize velocity field and IB node positions in k-space
        fkdens = zeros(SVector{3, ComplexF32},Tuple(hp.N))
        P_rfft = plan_rfft(reinterpret(reshape,Float32,um),(2,3,4))
        uk = Float32(inv(prod(hp.N)))*reinterpret(reshape,SVector{3,ComplexF32},P_rfft*reinterpret(reshape,Float32,um))
        Γk = zeros(SVector{3, ComplexF32},Nirfft)
        #initalize velocity data array
        total_um = copy(reinterpret(reshape,Float32,um))
        #Define the rfft and irfft plan
        P_brfft = plan_brfft(reinterpret(reshape,ComplexF32,uk),hp.N[1],(2,3,4))
        #integrate system forward in time
        #@show view(um,div(hp.N[1],2),div(hp.N[2],2),div(hp.N[3],2))
        for it in 1:sp.nstep
            #calculate the fields
            ImmersedBoundaries.update_fields!(uk,uk,Γk,fkdens,hp,it,key)
            #get r-space velocity field and store
            um = P_brfft*reinterpret(reshape,ComplexF32,uk)
            #@show view(um,:,div(hp.N[1],2),div(hp.N[2],2),div(hp.N[3],2))
        end
    end

    function calc_rnodes_exact(t,X0,V0)
        Xt = X0 + V0*t
        return Xt
    end

    @testset "Check immersed boundary node position update" begin
        
        Γm0 = 100.0 #nm
        N = [32,32,32]
        L = 1.0*10^3 #nm
        kT = (8.316*1E3)*300.0 #(nm^2*amu/ns^2*K)*K
        ρ = 602.0 #amu/nm^3
        μ = 6.02*10^5 #amu/(nm ns)
        Δx = L/N[1] #nm
        npart = 1
        a = Δx #nm
        Δt = 1.0*(10^3) #ns
        nstep = 100
        key = 1234
        hp = hydroparams(N,kT,ρ,μ,Δx,Δt)
        ibp = ibparams(npart,a)
        sp = simparams(nstep,0.0,0.0,0,0)
        rnodes = Float32[div(hp.N[1],2)*hp.Δx div(hp.N[2],2)*hp.Δx div(hp.N[3],2)*hp.Δx] + rand(Float32,3)'*Float32(hp.Δx)*0
        rnodes0 = copy(rnodes)
        Γm = zeros(SVector{3, Float32},Tuple(hp.N))
        direction = rand(Float32,3)
        direction = [1.0,0.0,0.0]
        reinterpret(reshape,Float32,Γm) .= direction*Γm0
        Γm = reinterpret(reshape,Float32,Γm)
        for it in 1:sp.nstep
            rnodes_exact = calc_rnodes_exact(it*Float32(hp.Δt),rnodes0,direction'*Float32(Γm0/hp.Δt))
            ImmersedBoundaries.update_rnodes_unwrapped!(rnodes,rnodes,Γm,hp.Δx,hp.N,ibp.a)
            @test isapprox(rnodes, rnodes_exact, atol=10^-1)
        end
    end

    @testset "Calculate Single IB node diffusion coefficient for comparison with Atzberger's results" begin
        N = [32,32,32]
        L = 1.0*10^3 #nm
        kT = (8.316*1E3)*300.0 #(nm^2*amu/ns^2*K)*K
        ρ = 602.0 #amu/nm^3
        μ = 6.02*10^5 #amu/(nm ns)
        Δx = L/N[1] #nm
        npart = 1
        a_values = [1,2,3,4,5]*Δx #nm
        Δt = 1.0*(10^3) #ns
        nstep = 10
        nrep = 100
        hp = hydroparams(N,kT,ρ,μ,Δx,Δt)
        ibp = ibparams(1,Δx)
        sp = simparams(nstep,0.0,0.0,0,nrep)
        D_conversion_factor = 1000
        Dymin = 0.0
        Dymax = 10.0
        Dyticksize = 1
        filename_plot = "D_est_vs_a_samp_size_$nrep.pdf"
        D_est_all_a, D_est_stddev_all_a, D_est_stderr_all_a = ImmersedBoundaries.main_estimate_D(a_values,hp,ibp,sp)
        ImmersedBoundaries.plot_D_est(D_est_all_a,D_est_stddev_all_a,D_est_stderr_all_a,a_values,Dymin,Dymax,Dyticksize,D_conversion_factor,filename_plot,hp,ibp)
    end

end
