using ImmersedBoundaries
using Test
using StaticArrays
using Random
using FFTW
using CUDA

N = 4*[32,32,32]
L = 4*1.0*10^3 #nm
kT = (8.316*1E3)*300.0 #(nm^2*amu/ns^2*K)*K
ρ = 602.0 #amu/nm^3
μ = 6.02*10^5 #amu/(nm ns)
Δx = L/N[1] #nm
npart = 1
a_values = [1,2,3,4,5]*Δx #nm
Δt = 1.0*(10^3) #ns
nstep = 1000
nrep = 1
hp = hydroparams(N,kT,ρ,μ,Δx,Δt)
ibp = ibparams(1,Δx)
sp = simparams(nstep,0.0,0.0,0,nrep)
#D_conversion_factor = 1000
#Dymin = 0
#Dymax = 5
#Dyticksize = 1
#filename_plot = "CUDA_D_est_vs_a_samp_size_$nrep.pdf"
key = 1
@time ImmersedBoundaries.main_single_CUDA(hp,ibp,sp,key)
#@time ImmersedBoundaries.main_single_free_Float32(hp,ibp,sp,key)
