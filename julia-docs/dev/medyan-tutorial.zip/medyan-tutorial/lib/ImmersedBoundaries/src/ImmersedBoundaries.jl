module ImmersedBoundaries
using StaticArrays
using LinearAlgebra
using PhiloxArrays
using Statistics
using LaTeXStrings
using FFTW
using CairoMakie
using OffsetArrays
export hydroparams
export ibparams
export forceparams
export simparams



# Write your package code here.

"""
Struct for hydrodynamic parameters
"""
struct hydroparams
    N::SVector{3,Int64} #number of immersed boundary points
    kT::Float64 #temperature in joules (Boltzmann's constant x actual temperature)
    ρ::Float64 #density of fluid
    μ::Float64 #dynamic viscosity of fluid
    Δx::Float64 #fluid grid cell width
    Δt::Float64 #time step
end

"""
Struct for immersed boundary parameters
"""
mutable struct ibparams
    npart::Int64 #number of immersed boundary points
    a::Float64 #radius of immersed boundary point in multiples of the grid cell width Δx
end

"""
Struct for immersed boundary parameters
"""
struct forceparams
    K0::Float64 #filament node bond stretching parameter
    S0::Float64 #filament node equilibrium bond length parameter
    k∠::Float64 #filament node bending parameter
    rcenter::SVector{3, Float64} #central force center position
end

"""
Struct of parameters for a basic simulation of a single elastic filament in a fluid
"""
struct simparams
    nstep::Int64
    randmag::Float64
    Δz::Float64
    fbits::Int64
    nrep::Int64
end

"""
Use to converts Float64 to Int64, number of fractional bits hardcoded to 20.
"""
function unsaferound(x,::Val{fbits}) where {fbits}
    unsafe_trunc(Int64,(x*(2.0^fbits)))
end

"""
Initialize configuration of IB nodes for a single filament unbent, oriented
parallel to the z-axis.
"""
function initialize_IB_nodes_filparaz(nnode,Δx1,Δx2,Δx3,Δx,N,disp)
    rnodes = zeros(nnode,3)
    for k in 1:nnode
        rnodes[k,1] = (N[1]/2)*Δx + (k-1)*Δx1 - (nnode/4)*Δx1 + disp[1]
        rnodes[k,2] = (N[2]/2)*Δx + (k-1)*Δx2 - (nnode/4)*Δx2 + disp[2]
        rnodes[k,3] = (N[3]/2)*Δx + (k-1)*Δx3 - (nnode/4)*Δx3 + disp[3]
    end
    return rnodes
end

"""
Define harmonic force law.
"""
function tension_law(r,K0,S0)
    return K0*(r - S0)
end

"""
Calculate the dispacement vector between two position vectors.
"""
function calculate_forcevec(rveci,rvecj,K0,S0)
    dispvec = SVector{3,Float64}(rvecj .- rveci)
    return (dispvec./norm(dispvec))*tension_law(norm(dispvec),K0,S0)
end

"""
Calculate the array of forces on each node in the IB given the configuration of the nodes in the IB.
"""
function calculate_stretching_force!(Fnodes,rnodes,K0,S0,fbits)
    #sum over all pairs of particles in the polymer
    for ib in 1:size(rnodes,1)-1
        rnodei = SVector{3,Float64}(view(rnodes,ib,:))
        rnodej = SVector{3,Float64}(view(rnodes,ib+1,:))
        temp_arr = calculate_forcevec(rnodei,rnodej,K0,S0)
        for k in 1:3
            temp_arr_round = unsaferound(temp_arr[k],fbits)
            @inbounds Fnodes[ib,k] += temp_arr_round
            @inbounds Fnodes[ib+1,k] -= temp_arr_round
        end
    end
end

"""
Eqn. 8: Calculate the force density array associated with each IB node.
"""
function calculate_fdens!(fdens,r,F,N,Δx,a)
    fdens .= 0
    #loop over all nodes in the immersed boundary
    for l in eachindex(view(r,:,1))
        rIB = SVector{3}(view(r,l,:))
        FIB = SVector{3}(view(F,l,:))
        #loop over all fluid grid cells in a cube that circumscribes a sphere
        #with radius equal to the immersed boundary point radius a=n*Δx
        for i in ceil(Int,(rIB[1]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[1]*inv(Δx))+2*Int(a*inv(Δx)))
            i -= (floor(Int,i/N[1]))*N[1] #account for PBC
            for j in ceil(Int,(rIB[2]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[2]*inv(Δx))+2*Int(a*inv(Δx)))
                j -= (floor(Int,j/N[2]))*N[2] #account for PBC
                for k in ceil(Int,(rIB[3]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[3]*inv(Δx))+2*Int(a*inv(Δx)))
                    k -= (floor(Int,k/N[3]))*N[3] #account for PBC
                    #use PBC for displacement between grid point (i,j,k)-th and node point r
                    Δrm = SA[i,j,k]*Δx - rIB
                    Δrm -= (round.(Int,Δrm./(N*Δx))).*N*Δx
                    view(fdens,:,i+1,j+1,k+1) .+= FIB*δₐ(Δrm,a)
                end
            end
        end
    end
end

"""
Eqn. 8: Calculate the force density array associated with each IB node.
"""
function calculate_fdens_grid_first!(fdens,r,F,N,Δx,a)
    for i in 1:N[1]
        i -= (floor(Int,i/N[1]))*N[1] #account for PBC
        for j in 1:N[2]
            j -= (floor(Int,j/N[2]))*N[2] #account for PBC
            for k in 1:N[3]
                k -= (floor(Int,k/N[3]))*N[3] #account for PBC
                #use PBC for displacement between grid point (i,j,k)-th and node point r
                #loop over all nodes in the immersed boundary
                for l in eachindex(view(r,:,1))
                    Δrm = SA[i,j,k]*Δx - view(r,l,:)
                    Δrm -= (round.(Int,Δrm./(N*Δx))).*N*Δx
                    view(fdens,:,i+1,j+1,k+1) .+= view(F,l,:)*δₐ(Δrm,a)
                end
            end
        end
    end
end

"""
Eqn. 10: Fourier transform of nabla vector operator.
"""
function calc_gk(kvec,N,Δx)
    return SA[sin(2π*kvec[1]*inv(N[1])),sin(2π*kvec[2]*inv(N[2])),sin(2π*kvec[3]*inv(N[3]))]*inv(Δx)
end

"""
Eqn. 12: Fourier transform of laplacian scalar operator.
"""
function calc_αk(kvec,N,ρ,μ,Δx)
    return (2*μ*inv(ρ*Δx^2))*((1-cos(2π*kvec[1]*inv(N[1])))+(1-cos(2π*kvec[2]*inv(N[2])))+(1-cos(2π*kvec[3]*inv(N[3]))))
end

"""
Eqn. 33: Projection operator projects out the part of the field orthogonal to gk field operator.
"""
function calc_Projorthogk(kvec,N,Δx)
    gk = calc_gk(kvec,N,Δx)
    return SMatrix{3,3}(1.0I) - gk.*transpose(gk)*inv(sum(gk.^2))
end

"""
Eqn. 15: Update all IB node positions.
"""
function update_rnodes_wrapped!(rold,rnew,Γm,Δx,N,a)
    #loop over all nodes in the immersed boundary
    for l in eachindex(view(rold,:,1))
        rIB = SVector{3}(view(rold,l,:))
        #loop over all fluid grid cells in a cube that circumscribes a sphere
        #with radius equal to the immersed boundary point radius a=n*Δx
        for i in ceil(Int,(rIB[1]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[1]*inv(Δx))+2*Int(a*inv(Δx)))
            i -= (floor(Int,i/N[1]))*N[1] #account for PBC
            for j in ceil(Int,(rIB[2]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[2]*inv(Δx))+2*Int(a*inv(Δx)))
                j -= (floor(Int,j/N[2]))*N[2] #account for PBC
                for k in ceil(Int,(rIB[3]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[3]*inv(Δx))+2*Int(a*inv(Δx)))
                    k -= (floor(Int,k/N[3]))*N[3] #account for PBC
                    #use PBC for displacement between grid point (i,j,k)-th and node point r
                    r = SA[i,j,k]*Δx - rIB
                    r -= (round.(Int,r./(N*Δx))).*N*Δx
                    view(rnew,l,:) .= view(rold,l,:) .+ δₐ(r,a)*view(Γm,:,i+1,j+1,k+1)*(Δx^3)
                end
            end
        end
    end
    #use PBC for positions
    rnew .-= (floor.(rnew./(N'*Δx))).*N'*Δx
end

"""
NOTE: need to modify this so that it takes rnodes in as a mutation

Eqn. 15: Update all IB node positions.
"""
function update_rnodes_old(rnodes,Γm,N,Δx,a)
    Δrnodes = zeros(size(rnodes,1),3)
    #integrate over all grid points
    for i in 0:N[1]-1
        for j in 0:N[2]-1
            for k in 0:N[3]-1
                for l in 1:size(rnodes,1)
                    #use PBC for displacements
                    r = SA[i,j,k]*Δx .- view(rnodes,l,:)
                    r -= (Int.(round.(r./(N*Δx)))).*N*Δx
                    Δrnodes[l,:] += δₐ(r,a)*view(Γm,:,i+1,j+1,k+1)
                end
            end
        end
    end
    #use PBC for positions
    R = rnodes .+ Δrnodes*(Δx^3)
    R -= (floor.(R./(N'*Δx))).*N'*Δx
    return R
end

"""
Eqn. 15: Update all IB node positions.
"""
function update_rnodes_unwrapped!(rold,rnew,Γm,Δx,N,a)
    #loop over all nodes in the immersed boundary
    for l in eachindex(view(rold,:,1))
        rIB = SVector{3}(view(rold,l,:))
        #loop over all fluid grid cells in a cube that circumscribes a sphere
        #with radius equal to the immersed boundary point radius a=n*Δx
        for i in ceil(Int,(rIB[1]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[1]*inv(Δx))+2*Int(a*inv(Δx)))
            i -= (floor(Int,i/N[1]))*N[1] #account for PBC
            for j in ceil(Int,(rIB[2]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[2]*inv(Δx))+2*Int(a*inv(Δx)))
                j -= (floor(Int,j/N[2]))*N[2] #account for PBC
                for k in ceil(Int,(rIB[3]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[3]*inv(Δx))+2*Int(a*inv(Δx)))
                    k -= (floor(Int,k/N[3]))*N[3] #account for PBC
                    #use PBC for displacement between grid point (i,j,k)-th and node point r
                    r = SA[i,j,k]*Δx - rIB
                    r -= (round.(Int,r./(N*Δx))).*N*Δx
                    view(rnew,l,:) .= view(rold,l,:) .+ δₐ(r,a)*view(Γm,:,i+1,j+1,k+1)*(Δx^3)
                end
            end
        end
    end
end

"""
Calculate the velocity field uk at the n+1-th timestep at all points in k-space. Also calculate the 
random variable Γk at the n-th timestep at all points in k-space.

Note, ukold and uknew are allowed to be the same array.

Inputs: ukold,fkdens,struct of hydordynamic parameters
Outputs: uknew,Γk
"""
function update_fields!(ukold,uknew,Γk,fkdens,hp::hydroparams,counter,key)    
    
    #define the slab in k-space
    Nirfft = (div(hp.N[1],2)+1,hp.N[2],hp.N[3]) 

    #evaluate fields for every point in k-space
    for kvec in CartesianIndices(Nirfft)
        isone(kvec) && continue
        #FT discrete divergence
        αk = calc_αk(kvec,hp.N,hp.ρ,hp.μ,hp.Δx)
        
        #projection operator
        Projk = calc_Projorthogk(kvec,hp.N,hp.Δx)
        
        #first correlation coefficient
        c1k = inv(αk)*tanh(0.5*αk*hp.Δt)
    
        #second correlation coefficient
        c2k = inv(αk)*sqrt(2*hp.kT*inv(hp.ρ*prod(hp.N)*(hp.Δx^3))*(αk*hp.Δt - 2*tanh(0.5*αk*hp.Δt)))

        #generate first RV
        Ξk = sqrt(hp.kT*inv(hp.ρ*prod(hp.N)*(hp.Δx^3))*(1 - exp(-2*αk*hp.Δt))) *
             PhiloxArrays.ConjSymRandNArray{Float64}(Tuple(hp.N),UInt64(key),UInt64(counter))[kvec]

        #generate second RV
        #note we use key' = key + N₁×N₂×N₃ because we need a different random field for all the grid points
        Gk = PhiloxArrays.ConjSymRandNArray{Float64}(Tuple(hp.N),UInt64(key+prod(hp.N)),UInt64(counter))[kvec]

        #calculate Γk
        Γk[kvec] = inv(αk) * (1 - exp(-αk * hp.Δt)) * ukold[kvec] .+ 
                   ((hp.Δt * inv(αk)) + (inv(αk^2) * (exp(-αk * hp.Δt) - 1))) * inv(hp.ρ) * (Projk * fkdens[kvec]) #.+ 
                   #c1k * (Projk * Ξk) .+
                   #c2k * (Projk * Gk)
        
        #calculate uknew
        uknew[kvec] = exp(-αk * hp.Δt) * ukold[kvec] .+ 
                      inv(hp.ρ * αk) * (1 - exp(-αk * hp.Δt)) * (Projk * fkdens[kvec]) #.+ 
                      #Projk * Ξk
    end
end

"""
Calculate the velocity field uk at the n+1-th timestep at all points in k-space. Also calculate the 
random variable Γm at the n-th timestep at all points in m-space.

Note, ukold and uknew are allowed to be the same array.

Inputs: ukold,fkdens,N,T,ρ,μ,Δx,Δt
Outputs: uknew,Γk
"""
function update_fields_old!(ukold,uknew,Γk,fkdens,N,T,ρ,μ,Δx,Δt)

    #insure grid array functions are indexed from 0,...,N-1
    fkdens_OS = OffsetArray(fkdens,-1,-1,-1,0)
    Γk_OS = OffsetArray(Γk,-1,-1,-1,0)
    ukold_OS = OffsetArray(ukold,-1,-1,-1,0)
    uknew_OS = OffsetArray(uknew,-1,-1,-1,0)
    
    #calculate discrete velocity field in k-space, skipping k=[0,0,0], according to remark after Eqn. 59
    for ik in 0:N[1]-1
        for jk in 0:N[2]-1
            for kk in 0:N[3]-1
                #need to use same value of Ξk to calculate Γk and uk, at particular k-space point
                #evolve k=(0,0,0) mode deterministically
                if (ik == 0) & (jk == 0) & (kk == 0)
                    uknew_OS[ik,jk,kk,:] = view(uknew_OS,ik,jk,kk,:) # + external force?
                
                #evolve all other modes stochastically
                else
                    Ξk = calculate_Ξk(SA[ik,jk,kk],N,T,ρ,μ,Δx,Δt)
                    Γk_OS[ik,jk,kk,:] = calculate_Γk(view(ukold_OS,ik,jk,kk,:),view(fkdens_OS,ik,jk,kk,:),Ξk,SA[ik,jk,kk],N,T,ρ,μ,Δx,Δt)
                    uknew_OS[ik,jk,kk,:] = update_uk(SA[ik,jk,kk],view(ukold_OS,ik,jk,kk,:),view(fkdens_OS,ik,jk,kk,:),Ξk,N,ρ,μ,Δx,Δt)
                end
            end
        end
    end
    
    #symmetrize the k-space field matrices
    for ik in 0:N[1]-1
        for jk in 0:N[2]-1
            for kk in 0:N[3]-1
                #get conjugate indices
                ikp = (N[1] - ik)%N[1]
                jkp = (N[2] - jk)%N[2] 
                kkp = (N[3] - kk)%N[3]
                
                #if k is a special point then field is real
                if (ik == ikp) & (jk == jkp) & (kk == kkp)
                    Γk_OS[ik,jk,kk,:] = real(view(Γk_OS,ik,jk,kk,:))
                    uknew_OS[ik,jk,kk,:] = real(view(uknew_OS,ik,jk,kk,:))
                    Γk_OS[ikp,jkp,kkp,:] = view(Γk_OS,ik,jk,kk,:)
                    uknew_OS[ikp,jkp,kkp,:] = view(uknew_OS,ik,jk,kk,:)
                
                #otherwise impose conjugate symmetry condition
                else
                    Γk_OS[ikp,jkp,kkp,:] = conj(view(Γk_OS,ik,jk,kk,:))
                    uknew_OS[ikp,jkp,kkp,:] = conj(view(uknew_OS,ik,jk,kk,:))
                end
            end
        end
    end
end

"""
Eqn. 104: Numerical estimator of diffusion coefficient for single particle measured from simulation
of a trajectory. Results are then averaged over many trajectories to get Eqn. 104.
"""
function D_estimate(nstep,Δt,X)
    return inv(6*nstep*Δt)*(norm(view(X,1,:,nstep).-view(X,1,:,1)))^2
end

"""
Estimate statistics for diffusion coefficient for single value of IB point radii
"""
function main_estimate_D_single_a(hp::hydroparams,ibp::ibparams,sp::simparams)
    D_sample = []
    for ir in 1:sp.nrep
        traj_rnodes = main_single_free_Float64(hp,ibp,sp,ir)
        D_sample = cat(D_sample,D_estimate(sp.nstep,hp.Δt,traj_rnodes),dims=1)
    end
    D_est = mean(D_sample)
    D_est_stddev = std(D_sample)
    D_est_stderr = sqrt(var(D_sample)/sp.nrep)
    return D_est, D_est_stddev, D_est_stderr
end

"""
Estimate diffusion coefficient for different IB particle radii
"""
function main_estimate_D(a_values,hp::hydroparams,ibp::ibparams,sp::simparams)
    D_est_all_a = []
    D_est_stddev_all_a = []
    D_est_stderr_all_a = []
    for ia in eachindex(a_values)
        ibp.a = a_values[ia]
        D_est, D_est_stddev, D_est_stderr = main_estimate_D_single_a(hp,ibp,sp)
        D_est_all_a = cat(D_est_all_a,D_est,dims=1)
        D_est_stddev_all_a = cat(D_est_stddev_all_a,D_est_stddev,dims=1)
        D_est_stderr_all_a = cat(D_est_stderr_all_a,D_est_stderr,dims=1)
    end
    return D_est_all_a, D_est_stddev_all_a, D_est_stderr_all_a
end

"""
Plot estimate of the diffusion coefficient with standard errors as a function of 
the immersed boundary particle radius parameter a
"""
function plot_D_est(D_est,D_est_stddev,D_est_stderr,a_values,Dymin,Dymax,Dyticksize,D_conversion_factor,filename,hp::hydroparams,ibp::ibparams)
    f = Figure(fontsize = 20)
    ax = Axis(f[1, 1])
    
    #plot numerical results with standard deviation
    #CairoMakie.errorbars!(a_values/hp.Δx, D_est*D_conversion_factor,
    #    D_est_stddev*D_conversion_factor, color = :red, whiskerwidth = 10)

    #plot numerical results with standard error of the mean
    CairoMakie.errorbars!(a_values/hp.Δx, D_est*D_conversion_factor,
        D_est_stderr*D_conversion_factor, color = :red, whiskerwidth = 10)
    
    CairoMakie.scatter!(a_values/hp.Δx, D_est*D_conversion_factor, markersize = 10, color = :black)
    
    #plot stoke-einstein comparison values
    #CairoMakie.scatter!(a_values/hp.Δx, hp.kT*inv(6*π*hp.μ)*inv.(a_values)*D_conversion_factor, markersize = 15, marker = :utriangle, color = :blue)
    
    #ax.title = ""
    ax.xlabel = L"a \quad [\times \Delta x = %$(hp.Δx) \, nm]"
    ax.ylabel = L"D \quad [{\mu m}^{2}/{s}]"
    ax.xticks = a_values/hp.Δx
    ax.yticks = Dymin:Dyticksize:Dymax
    f
    save(filename, f; backend=CairoMakie)
    f
end

"""
Move entire system nstep timesteps forward
"""
function main_single_free_Float32(hp::hydroparams,ibp::ibparams,sp::simparams,key)
    #define slab of points in k-space
    Nirfft = (div(hp.N[1],2)+1,hp.N[2],hp.N[3])
    #initialize velocity field and IB node positions in r-space
    Γm = zeros(SVector{3, Float32},Tuple(hp.N))
    #initialize velocity field and IB node positions in k-space
    fkdens = zeros(SVector{3, Complex{Float32}},Nirfft)
    uk = zeros(SVector{3, Complex{Float32}},Nirfft)
    Γk = zeros(SVector{3, Complex{Float32}},Nirfft)
    #initialize filaments IB node locations
    rnodes = [hp.N[1] hp.N[2] hp.N[3]]*inv(2)*hp.Δx
    #initialize output IB trajectory data arrays
    traj_rnodes = copy(rnodes)
    #Define the brfft plan
    P_brfft = plan_brfft(reinterpret(reshape,ComplexF32,uk),hp.N[1],(2,3,4))
    #integrate system forward in time
    for it in 1:sp.nstep
        #calculate the fields
        update_fields!(uk,uk,Γk,fkdens,hp,it,key)
        #get r-space integrated velocity field
        Γm = P_brfft*reinterpret(reshape,Complex{Float32},Γk)
        #update the IB node positions
        update_rnodes_wrapped!(rnodes,rnodes,Γm,hp.Δx,hp.N,ibp.a)
        #get the node positions and store
        traj_rnodes = cat(traj_rnodes,rnodes,dims=3)
        #display timestep
        @info "Finished timestep it = $it"
    end
    return traj_rnodes
end

"""
Move entire system nstep timesteps forward
"""
function main_single_free_Float64(hp::hydroparams,ibp::ibparams,sp::simparams,key)
    #define slab of points in k-space
    Nirfft = (div(hp.N[1],2)+1,hp.N[2],hp.N[3])
    #initialize velocity field and IB node positions in r-space
    Γm = zeros(SVector{3, Float64},Tuple(hp.N))
    #initialize velocity field and IB node positions in k-space
    fkdens = reinterpret(reshape,ComplexF64,zeros(SVector{3, Complex{Float64}},Nirfft))
    uk = reinterpret(reshape,ComplexF64,zeros(SVector{3, Complex{Float64}},Nirfft))
    Γk = reinterpret(reshape,ComplexF64,zeros(SVector{3, Complex{Float64}},Nirfft))
    #initialize filaments IB node locations
    rnodes = [hp.N[1] hp.N[2] hp.N[3]]*inv(2)*hp.Δx
    #initialize output IB trajectory data arrays
    traj_rnodes = copy(rnodes)
    #Define the brfft plan
    P_brfft = plan_brfft(reinterpret(reshape,ComplexF64,uk),hp.N[1],(2,3,4))
    #integrate system forward in time
    for it in 1:sp.nstep
        #calculate the fields
        #update_fields!(uk,uk,Γk,fkdens,hp,it,key)
        update_fields_old!(uk,uk,Γk,fkdens,hp.N,hp.kT/(8.316*1E3),hp.ρ,hp.μ,hp.Δx,hp.Δt)
        #get r-space integrated velocity field
        Γm = P_brfft*reinterpret(reshape,Complex{Float64},Γk)
        #update the IB node positions
        update_rnodes_wrapped!(rnodes,rnodes,Γm,hp.Δx,hp.N,ibp.a)
        #rnodes = update_rnodes_old(rnodes,Γm,hp.N,hp.Δx,ibp.a)
        #get the node positions and store
        traj_rnodes = cat(traj_rnodes,rnodes,dims=3)
        #display timestep
        @info "Finished timestep it = $it"
    end
    return traj_rnodes
end


"""
Eqn. A.1: Define the 1D radially dependent Peskin kernel component.
"""
function ϕ(r::T)::T where T
    if r <= -2
        return zero(r)
    elseif -2 <= r < -1
        return inv(8)*(5 + 2*r - sqrt(-7 - 12*r - 4*r^2))
    elseif -1 <= r < 0
        return inv(8)*(3 + 2*r + sqrt(1 - 4*r - 4*r^2)) 
    elseif 0 <= r < 1
        return inv(8)*(3 - 2*r + sqrt(1 + 4*r - 4*r^2)) 
    elseif 1 <= r < 2
        return inv(8)*(5 - 2*r - sqrt(-7 + 12*r - 4*r^2)) 
    elseif 2 <= r
        return zero(r)
    else #this is in the event of an error
        return r
    end
end

"""
Eqn. A.2: Define the 3D radially dependent Peskin kernel.
"""
function δₐ(rvec,a)
    #return inv(a^3)*ϕ(inv(a)*rvec[1])*ϕ(inv(a)*rvec[2])*ϕ(inv(a)*rvec[3])
    term0 = inv(a^3)
    term1 = ϕ(inv(a)*rvec[1])
    term2 = ϕ(inv(a)*rvec[2])
    term3 = ϕ(inv(a)*rvec[3])
    return term0*term1*term2*term3
end

"""Add commentMore actions
Move entire system nstep timesteps forward
"""
function main_npart_ufield(npart,N,T,ρ,μ,Δx,Δt,nstep,a,randmag)
    #initialize velocity field and IB node positions
    fkdens = zeros(Complex{Float64},N[1],N[2],N[3],3)
    fmdens = zeros(Complex{Float64},N[1],N[2],N[3],3)
    uk = zeros(Complex{Float64},N[1],N[2],N[3],3)
    Γk = zeros(Complex{Float64},N[1],N[2],N[3],3)
    Γm = zeros(N[1],N[2],N[3],3)
    um = initialize_um_field_randunif(N,randmag)
    
    #FFT initial velocity field
    uk = fft(um,(1,2,3))
    
    #initalize velocity data array
    total_um = um
    
    #initialize the force on the nodes, which in this special 
    #case is zero since there is only a single point
    Fnodes = zeros(npart,3)

    #initialize the npart noninteracting, diffusing particle's IB node location
    #to be the center of the simulation domain
    rnodes = rand(npart,3).*N'*Δx
    
    #initialize output IB trajectory data arrays
    traj_rnodes = rnodes
    
    #integrate system forward in time
    for it in 1:nstep
        #calculate the force density and its discrete FFT
        #fmdens = calculate_fdenstot(rnodes,Fnodes,N,Δx,a)
        calculate_fdens!(fmdens,rnodes,Fnodes,N,Δx,a)
        fkdens = fft(fmdens,(1,2,3))
        
        #calculate the fields
        update_fields!(uk,uk,Γk,fkdens,N,T,ρ,μ,Δx,Δt)

        #get r-space integrated velocity field
        Γm = real.(bfft(Γk,(1,2,3)))

        #update the IB node positions
        rnodes = update_rnodes(rnodes,Γm,Δx,a)

        #get r-space velocity field and store
        um = real.(bfft(uk,(1,2,3)))
        total_um = cat(total_um,um,dims=5)
        
        #get the node positions and store
        traj_rnodes = cat(traj_rnodes,rnodes,dims=3)

        println("Finished step it = ",it)
    end
    return traj_rnodes,total_um
end

end
