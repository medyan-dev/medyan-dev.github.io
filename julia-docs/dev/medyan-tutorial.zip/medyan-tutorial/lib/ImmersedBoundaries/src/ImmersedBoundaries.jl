module ImmersedBoundaries
using StaticArrays
using LinearAlgebra
using PhiloxArrays
using Statistics
using LaTeXStrings
using FFTW
using CairoMakie
using CUDA
using PointNeighbors
using KernelAbstractions
using Adapt
export Hydroparams
export Ibparams
export Forceparams
export Simparams
export Ljforceparams
export Actinstericforceparams

# Write your package code here.

"""
Struct for hydrodynamic parameters
"""
struct Hydroparams
    N::SVector{3,Int64} #number of immersed boundary points
    kT::Float32 #temperature in joules (Boltzmann's constant x actual temperature)
    ρ::Float32 #density of fluid
    μ::Float32 #dynamic viscosity of fluid
    Δx::Float32 #fluid grid cell width
    Δt::Float32 #time step
end

"""
Struct for immersed boundary parameters
"""
mutable struct Ibparams
    npart::Int64 #number of immersed boundary points
    a::Float32 #radius of immersed boundary point in multiples of the grid cell width Δx
end

"""
Struct for immersed boundary parameters
"""
struct Forceparams
    K0::Float32 #filament node bond stretching parameter
    S0::Float32 #filament node equilibrium bond length parameter
    k∠::Float32 #filament node bending parameter
    rcenter::SVector{3, Float32} #central force center position
end

"""
Struct of parameters for a basic simulation of a single elastic filament in a fluid
"""
struct Simparams
    nstep::Int64
    randmag::Float32
    Δz::Float32
    fbits::Int64
    nrep::Int64
end

"""
Struct for Lennard-Jones force parameters
"""
struct Ljforceparams
    ϵ::Float32 #L-J energy parameter
    σ::Float32 #L-J distance parameter
end

"""
Struct for Lennard-Jones force parameters
"""
struct Actinstericforceparams
    Fmax::Float32 #MEDYAN actin steric force parameter
    rcut::Float32 #MEDYAN actin steric cutoff distance parameter
end

"""
Use to converts Float32 or Float64 to Int64, number of fractional bits hardcoded to 20.
"""
function unsaferound_floattoint(x,::Val{fbits}) where {fbits}
    unsafe_trunc(Int64,(x*(2.0^fbits)))
end

"""
Use to converts Int64 to Float32 or Float64, number of fractional bits hardcoded to 20.
"""
function unsaferound_inttofloat_CUDA!(x,::Val{fbits}) where {fbits}
    unsafe_trunc(Float32,(x*(2.0^-fbits)))
    nothing
end

"""
Zero out a field quantity
"""
function zero_field_CUDA!(field)
    field .= 0
    nothing 
end

"""
Initialize configuration of IB nodes for a single filament unbent, oriented
parallel to the z-axis.
"""
function initialize_IB_nodes_filparaz(nnode,Δx1,Δx2,Δx3,Δx,N,disp)
    rnodes = zeros(nnode,3)
    for k in 1:nnode
        rnodes[k,1] = (N[1]/2)*Δx + (k-1)*Δx1 - (nnode/4)*Δx1 + disp[1]
        rnodes[k,2] = (N[2]/2)*Δx + (k-1)*Δx2 - (nnode/4)*Δx2 + disp[2]
        rnodes[k,3] = (N[3]/2)*Δx + (k-1)*Δx3 - (nnode/4)*Δx3 + disp[3]
    end
    return rnodes
end

"""
Lennard-Jones force law divided by r
"""
function LJfrmag(r,ljfp)
    return 48 * ljfp.ϵ * ((ljfp.σ/r)^6) * ((ljfp.σ/r)^6 - 0.5) / (r^2)
end

"""
Globular actin steric interaction force
"""
#function Gactinfmag(r,gactinfp)
#    return gactinfp.Fmax*r
#end

"""
Calculate total Lennard-Jones force vector on group of particles 
"""
function LJ_force_total!(ljfp, ljforce, coordinates, neighborhood_search, parallelization_backend)
    ljforce .= 0
    foreach_point_neighbor(coordinates, coordinates, neighborhood_search; parallelization_backend) do i, j, pos_diff, distance
        # Only consider particles with a distance > 0
        i == j && return
        #distance < sqrt(eps()) && return
        ljforce_ = LJfrmag(distance,ljfp) * pos_diff
        for dim in axes(ljforce, 1)
            @inbounds ljforce[dim, i] += ljforce_[dim]
        end
    end
end

"""
Calculate total globular actin steric interaction force vector on group of particles 
"""
function Gactin_steric_force_total!(gactinfp, gactinforce, coordinates, neighborhood_search, parallelization_backend)
    gactinforce .= 0
    foreach_point_neighbor(coordinates, coordinates, neighborhood_search; parallelization_backend) do i, j, pos_diff, distance
        # Only consider particles with a distance > 0
        i == j && return
        #distance < sqrt(eps()) && return
        gactinforce_ = gactinfp.Fmax * pos_diff
        for dim in axes(gactinforce, 1)
            @inbounds gactinforce[dim, i] += gactinforce_[dim]
        end
    end
end

"""
Define harmonic force law.
"""
function tension_law(r,K0,S0)
    return K0*(r - S0)
end

"""
Calculate the dispacement vector between two position vectors.
"""
function calculate_forcevec(rveci,rvecj,K0,S0)
    dispvec = SVector{3,Float32}(rvecj .- rveci)
    return (dispvec./norm(dispvec))*tension_law(norm(dispvec),K0,S0)
end

"""
Wrapper of CUDA code for testing with CPU inputs; test stretching force calculation
"""
function calculate_stretching_force_CUDA_wrapper!(Fnodes_host,rnodes_host,K0,S0,fbits)
    @assert eltype(Fnodes_host) == Int64
    @assert eltype(rnodes_host) == Float32
    @assert length(size(Fnodes_host)) == 2 
    @assert length(size(rnodes_host)) == 2
    @assert size(rnodes_host) == size(Fnodes_host)

    Fnodes_device = cu(Fnodes_host)
    rnodes_device = cu(rnodes_host)
    npart = size(rnodes_host,1)
    numthreads = 256
    numblocks_nodes = ceil(Int, npart/numthreads)
    @cuda threads=numthreads blocks=numblocks_nodes calculate_stretching_force_CUDA!(Fnodes_device,rnodes_device,K0,S0,fbits)
    copyto!(Fnodes_host, Fnodes_device)
    nothing
end

"""
Calculate the array of forces on each node in the IB given the configuration of the nodes in the IB.
"""
function calculate_stretching_force_CUDA!(Fnodes,rnodes,K0,S0,fbits)
    #sum over all pairs of particles in the polymer
    index = (blockIdx().x - 1) * blockDim().x + threadIdx().x
    stride = gridDim().x * blockDim().x
    for ib = index:stride:size(rnodes,1)-1
        rnodei = SVector{3,Float32}(view(rnodes,ib,:))
        rnodej = SVector{3,Float32}(view(rnodes,ib+1,:))
        temp_arr = calculate_forcevec(rnodei,rnodej,K0,S0)
        for k in 1:3
            temp_arr_round = unsaferound_floattoint(temp_arr[k],fbits)
            @inbounds CUDA.@atomic Fnodes[ib,k] += temp_arr_round
            @inbounds CUDA.@atomic Fnodes[ib+1,k] -= temp_arr_round
        end
    end
end

"""
Calculate the array of forces on each node in the IB given the configuration of the nodes in the IB.
"""
function calculate_stretching_force!(Fnodes,rnodes,K0,S0,fbits)
    #sum over all pairs of particles in the polymer
    for ib in 1:size(rnodes,1)-1
        rnodei = SVector{3,Float64}(view(rnodes,ib,:))
        rnodej = SVector{3,Float64}(view(rnodes,ib+1,:))
        temp_arr = calculate_forcevec(rnodei,rnodej,K0,S0)
        for k in 1:3
            temp_arr_round = unsaferound_floattoint(temp_arr[k],fbits)
            @inbounds Fnodes[ib,k] += temp_arr_round
            @inbounds Fnodes[ib+1,k] -= temp_arr_round
        end
    end
end

"""
Calculate force density with neighbor lists on GPU

function fdens_neighbor_list!(fdens, rnodes, rgrids, Fnodes, hp::Hydroparams, ibp::Ibparams, neighborhood_search, parallelization_backend)
    fdens .= 0
    foreach_point_neighbor(rnodes, rgrids, neighborhood_search; parallelization_backend) do i, j, pos_diff, distance


    end
end
"""

"""
Wrapper of CUDA code for testing with CPU inputs; test force density calculation
"""
function calculate_fdens_CUDA_wrapper!(fdens_host,rnodes_host,Fnodes_host,N,Δx,a)
    @assert size(fdens_host) == Tuple(N)
    @assert eltype(fdens_host) == SVector{3, Float32}
    @assert length(size(rnodes_host)) == 2
    @assert size(rnodes_host) == size(Fnodes_host)
    @assert eltype(rnodes_host) == Float32
    
    fdens_device = cu(fdens_host)
    Fnodes_device = cu(Fnodes_host)
    rnodes_device = cu(rnodes_host)
    npart = size(rnodes_host,1)
    numthreads = 256
    numblocks_nodes = ceil(Int, npart/numthreads)
    @cuda threads=numthreads blocks=numblocks_nodes calculate_fdens_CUDA!(reinterpret(reshape,Float32,fdens_device),rnodes_device,Fnodes_device,N,Δx,a)
    copyto!(fdens_host,fdens_device)
    nothing
end

"""
Eqn. 8: Calculate the force density array associated with each IB node.
"""
function calculate_fdens_CUDA!(fdens,r,F,N,Δx,a)
    index = (blockIdx().x - 1) * blockDim().x + threadIdx().x
    stride = gridDim().x * blockDim().x
    #loop over all nodes in the immersed boundary
    for l = index:stride:size(r,1)
        rIB = SVector{3}(view(r,l,:))
        FIB = SVector{3}(view(F,l,:))
        #loop over all fluid grid cells in a cube that circumscribes a sphere
        #with radius equal to the immersed boundary point radius a=n*Δx
        for i in ceil(Int,(rIB[1]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[1]*inv(Δx))+2*Int(a*inv(Δx)))
            i -= (floor(Int,i/N[1]))*N[1] #account for PBC
            for j in ceil(Int,(rIB[2]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[2]*inv(Δx))+2*Int(a*inv(Δx)))
                j -= (floor(Int,j/N[2]))*N[2] #account for PBC
                for k in ceil(Int,(rIB[3]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[3]*inv(Δx))+2*Int(a*inv(Δx)))
                    k -= (floor(Int,k/N[3]))*N[3] #account for PBC
                    #use PBC for displacement between grid point (i,j,k)-th and node point r
                    Δrm = SA[i,j,k]*Δx - rIB
                    Δrm -= (round.(Int,Δrm./(N*Δx))).*N*Δx
                    for comp in 1:3
                        @inbounds CUDA.@atomic fdens[comp,i+1,j+1,k+1] += FIB[comp]*δₐ(Δrm,a)
                    end
                end
            end
        end
    end
end

"""
Eqn. 8: Calculate the force density array associated with each IB node.
"""
function calculate_fdens!(fdens,r,F,N,Δx,a)
    fdens .= 0
    #loop over all nodes in the immersed boundary
    for l in eachindex(view(r,:,1))
        rIB = SVector{3}(view(r,l,:))
        FIB = SVector{3}(view(F,l,:))
        #loop over all fluid grid cells in a cube that circumscribes a sphere
        #with radius equal to the immersed boundary point radius a=n*Δx
        for i in ceil(Int,(rIB[1]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[1]*inv(Δx))+2*Int(a*inv(Δx)))
            i -= (floor(Int,i/N[1]))*N[1] #account for PBC
            for j in ceil(Int,(rIB[2]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[2]*inv(Δx))+2*Int(a*inv(Δx)))
                j -= (floor(Int,j/N[2]))*N[2] #account for PBC
                for k in ceil(Int,(rIB[3]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[3]*inv(Δx))+2*Int(a*inv(Δx)))
                    k -= (floor(Int,k/N[3]))*N[3] #account for PBC
                    #use PBC for displacement between grid point (i,j,k)-th and node point r
                    Δrm = SA[i,j,k]*Δx - rIB
                    Δrm -= (round.(Int,Δrm./(N*Δx))).*N*Δx
                    view(fdens,:,i+1,j+1,k+1) .+= FIB*δₐ(Δrm,a)
                end
            end
        end
    end
end

"""
Eqn. 8: Calculate the force density array associated with each IB node.
"""
function calculate_fdens_grid_first!(fdens,r,F,N,Δx,a)
    for i in 1:N[1]
        i -= (floor(Int,i/N[1]))*N[1] #account for PBC
        for j in 1:N[2]
            j -= (floor(Int,j/N[2]))*N[2] #account for PBC
            for k in 1:N[3]
                k -= (floor(Int,k/N[3]))*N[3] #account for PBC
                #use PBC for displacement between grid point (i,j,k)-th and node point r
                #loop over all nodes in the immersed boundary
                for l in eachindex(view(r,:,1))
                    Δrm = SA[i,j,k]*Δx - view(r,l,:)
                    Δrm -= (round.(Int,Δrm./(N*Δx))).*N*Δx
                    view(fdens,:,i+1,j+1,k+1) .+= view(F,l,:)*δₐ(Δrm,a)
                end
            end
        end
    end
end

"""
Eqn. 10: Fourier transform of nabla vector operator.
"""
function calc_gk(kvec,N,Δx)
    return SA[sin(2π*kvec[1]*inv(N[1])),sin(2π*kvec[2]*inv(N[2])),sin(2π*kvec[3]*inv(N[3]))]*inv(Δx)
end

"""
Eqn. 12: Fourier transform of laplacian scalar operator.
"""
function calc_αk(kvec,N,ρ,μ,Δx)
    return (2*μ*inv(ρ*Δx^2))*((1-cos(2π*kvec[1]*inv(N[1])))+(1-cos(2π*kvec[2]*inv(N[2])))+(1-cos(2π*kvec[3]*inv(N[3]))))
end

"""
Eqn. 33: Projection operator projects out the part of the field orthogonal to gk field operator.
"""
function calc_Projorthogk(kvec,N,Δx)
    gk = calc_gk(kvec,N,Δx)
    return SMatrix{3,3}(1.0I) - gk.*transpose(gk)*inv(sum(gk.^2))
end

"""
Wrapper of CUDA code for testing with CPU inputs; test rnode position update calculation
"""
function calculate_update_rnodes_CUDA_wrapper!(rold_host,rnew_host,Γm_host,N,Δx,a)
    @assert size(Γm_host) == Tuple(N)
    @assert eltype(Γm_host) == SVector{3, Float32}
    @assert length(size(rold_host)) == 2
    @assert size(rold_host) == size(rnew_host)
    @assert eltype(rold_host) == Float32
    @assert eltype(rnew_host) == Float32

    rold_device = cu(rold_host)
    rnew_device = cu(rnew_host)
    Γm_device = cu(Γm_host)
    npart = size(rold_host,1)
    numthreads = 256
    numblocks_nodes = ceil(Int, npart/numthreads)
    @cuda threads=numthreads blocks=numblocks_nodes update_rnodes_CUDA!(rold_device,rnew_device,Γm_device,N,Δx,a)
    copyto!(rnew_host,rnew_device)
    nothing
end

"""
Eqn. 15: Update all IB node positions.
"""
function update_rnodes_CUDA!(rold,rnew,Γm,N,Δx,a)
    index = (blockIdx().x - 1) * blockDim().x + threadIdx().x
    stride = gridDim().x * blockDim().x
    #loop over all nodes in the immersed boundary
    for l = index:stride:size(rold,1)
        rIB = SVector{3}(view(rold,l,:))
        rIB_new = rIB
        #loop over all fluid grid cells in a cube that circumscribes a sphere
        #with radius equal to the immersed boundary point radius a=n*Δx
        for i in ceil(Int,(rIB[1]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[1]*inv(Δx))+2*Int(a*inv(Δx)))
            i -= (floor(Int,i/N[1]))*N[1] #account for PBC
            for j in ceil(Int,(rIB[2]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[2]*inv(Δx))+2*Int(a*inv(Δx)))
                j -= (floor(Int,j/N[2]))*N[2] #account for PBC
                for k in ceil(Int,(rIB[3]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[3]*inv(Δx))+2*Int(a*inv(Δx)))
                    k -= (floor(Int,k/N[3]))*N[3] #account for PBC
                    #use PBC for displacement between grid point (i,j,k)-th and node point r
                    r = SA[i,j,k]*Δx - rIB
                    r -= (round.(Int,r./(N*Δx))).*N*Δx
                    rIB_new += δₐ(r,a)*Γm[i+1,j+1,k+1]*(Δx^3)
                end
            end
        end
        # wrap PBC
        rIB_new -= (floor.(rIB_new ./ (N * Δx))) .* (N * Δx)
        for comp in 1:3
            rnew[l,comp] = rIB_new[comp]
        end
    end
end

"""
Eqn. 15: Update all IB node positions.
"""

function update_rnodes_wrapped!(rold,rnew,Γm,Δx,N,a)
    #loop over all nodes in the immersed boundary
    for l in eachindex(view(rold,:,1))
        rIB = SVector{3}(view(rold,l,:))
        rIB_new = rIB
        #loop over all fluid grid cells in a cube that circumscribes a sphere
        #with radius equal to the immersed boundary point radius a=n*Δx
        for i in ceil(Int,(rIB[1]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[1]*inv(Δx))+2*Int(a*inv(Δx)))
            i -= (floor(Int,i/N[1]))*N[1] #account for PBC
            for j in ceil(Int,(rIB[2]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[2]*inv(Δx))+2*Int(a*inv(Δx)))
                j -= (floor(Int,j/N[2]))*N[2] #account for PBC
                for k in ceil(Int,(rIB[3]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[3]*inv(Δx))+2*Int(a*inv(Δx)))
                    k -= (floor(Int,k/N[3]))*N[3] #account for PBC
                    #use PBC for displacement between grid point (i,j,k)-th and node point r
                    r = SA[i,j,k]*Δx - rIB
                    r -= (round.(Int,r./(N*Δx))).*N*Δx
                    rIB_new += δₐ(r,a)*Γm[i+1,j+1,k+1]*(Δx^3)
                end
            end
        end
        # wrap PBC
        rIB_new -= (floor.(rIB_new ./ (N * Δx))) .* (N * Δx)
        for comp in 1:3
            rnew[l,comp] = rIB_new[comp]
        end
    end
end

"""
Eqn. 15: Update all IB node positions.
"""
function update_rnodes_unwrapped!(rold,rnew,Γm,Δx,N,a)
    #loop over all nodes in the immersed boundary
    for l in eachindex(view(rold,:,1))
        rIB = SVector{3}(view(rold,l,:))
        #loop over all fluid grid cells in a cube that circumscribes a sphere
        #with radius equal to the immersed boundary point radius a=n*Δx
        for i in ceil(Int,(rIB[1]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[1]*inv(Δx))+2*Int(a*inv(Δx)))
            i -= (floor(Int,i/N[1]))*N[1] #account for PBC
            for j in ceil(Int,(rIB[2]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[2]*inv(Δx))+2*Int(a*inv(Δx)))
                j -= (floor(Int,j/N[2]))*N[2] #account for PBC
                for k in ceil(Int,(rIB[3]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[3]*inv(Δx))+2*Int(a*inv(Δx)))
                    k -= (floor(Int,k/N[3]))*N[3] #account for PBC
                    #use PBC for displacement between grid point (i,j,k)-th and node point r
                    r = SA[i,j,k]*Δx - rIB
                    r -= (round.(Int,r./(N*Δx))).*N*Δx
                    view(rnew,l,:) .= view(rold,l,:) .+ δₐ(r,a)*view(Γm,:,i+1,j+1,k+1)*(Δx^3)
                end
            end
        end
    end
end

"""
Wrapper of CUDA code for testing with CPU inputs; test field update calculation
"""
function calculate_update_fields_CUDA_wrapper!(ukold_host,uknew_host,Γk_host,fkdens_host,hp,counter,key) 
    ukold_device = cu(ukold_host)
    uknew_device = cu(uknew_host)
    Γk_device = cu(Γk_host)
    fkdens_device = cu(fkdens_host)
    numthreads = 256
    numblocks_grids = ceil(Int, prod(hp.N)/numthreads)
    @cuda threads=numthreads blocks=numblocks_grids update_fields_CUDA!(ukold_device,uknew_device,Γk_device,fkdens_device,hp,counter,key) 
    copyto!(uknew_host,uknew_device)
    copyto!(Γk_host,Γk_device)
    nothing
end

"""
Calculate the velocity field uk at the n+1-th timestep at all points in k-space. Also calculate the 
random variable Γk at the n-th timestep at all points in k-space.

Note, ukold and uknew are allowed to be the same array.

Inputs: ukold,fkdens,struct of hydordynamic parameters
Outputs: uknew,Γk
"""
function update_fields_CUDA!(ukold,uknew,Γk,fkdens,hp::Hydroparams,counter,key)    
   
    index = (blockIdx().x - 1) * blockDim().x + threadIdx().x
    stride = gridDim().x * blockDim().x
    
    #define the slab in k-space
    Nirfft = (div(hp.N[1],2)+1,hp.N[2],hp.N[3]) 

    #evaluate fields for every point in k-space
    for l = index:stride:length(CartesianIndices(Nirfft))
        i = CartesianIndices(Nirfft)[l]
        i == oneunit(i) && continue
        # This is to match the equations in the paper.
        # The arrays are still one based however.
        kvec = SA[i[1]-1, i[2]-1, i[3]-1]
        #FT discrete divergence
        αk = calc_αk(kvec,hp.N,hp.ρ,hp.μ,hp.Δx)
        
        #projection operator
        Projk = calc_Projorthogk(kvec,hp.N,hp.Δx)

        Dk_over_αk = hp.kT*inv(2*hp.ρ*prod(hp.N)*(hp.Δx^3))

        #first correlation coefficient
        c1k = inv(αk)*tanh(0.5*αk*hp.Δt)
    
        #second correlation coefficient
        c2k = inv(αk)*sqrt(2*Dk_over_αk*(αk*hp.Δt - 2*tanh(0.5*αk*hp.Δt)))

        #generate first RV
        Ξk = sqrt(Dk_over_αk*(1 - exp(-2*αk*hp.Δt))) *
             PhiloxArrays.ConjSymRandNArray{Float32}(Tuple(hp.N),UInt64(key),UInt64(counter))[i]

        #generate second RV
        #note we use key' = key + N₁×N₂×N₃ because we need a different random field for all the grid points
        Gk = PhiloxArrays.ConjSymRandNArray{Float32}(Tuple(hp.N),UInt64(key+prod(hp.N)),UInt64(counter))[i]

        #calculate Γk
        Γk[i] = inv(αk) * (1 - exp(-αk * hp.Δt)) * ukold[i] .+ 
                   ((hp.Δt * inv(αk)) + (inv(αk^2) * (exp(-αk * hp.Δt) - 1))) * inv(hp.ρ) * (Projk * fkdens[i]) .+ 
                   c1k * (Projk * Ξk) .+
                   c2k * (Projk * Gk)
        
        #calculate uknew
        uknew[i] = exp(-αk * hp.Δt) * ukold[i] .+ 
                      inv(hp.ρ * αk) * (1 - exp(-αk * hp.Δt)) * (Projk * fkdens[i]) .+ 
                      Projk * Ξk
    end
end

"""
Calculate the velocity field uk at the n+1-th timestep at all points in k-space. Also calculate the 
random variable Γk at the n-th timestep at all points in k-space.

Note, ukold and uknew are allowed to be the same array.

Inputs: ukold,fkdens,struct of hydordynamic parameters
Outputs: uknew,Γk
"""
function update_fields!(ukold,uknew,Γk,fkdens,hp::Hydroparams,counter,key)    
    
    #define the slab in k-space
    Nirfft = (div(hp.N[1],2)+1,hp.N[2],hp.N[3]) 

    #evaluate fields for every point in k-space
    for i in CartesianIndices(Nirfft)
        i == oneunit(i) && continue
        # This is to match the equations in the paper.
        # The arrays are still one based however.
        kvec = SA[i[1]-1, i[2]-1, i[3]-1]
        #FT discrete divergence
        αk = calc_αk(kvec,hp.N,hp.ρ,hp.μ,hp.Δx)
        
        #projection operator
        Projk = calc_Projorthogk(kvec,hp.N,hp.Δx)

        Dk_over_αk = hp.kT*inv(2*hp.ρ*prod(hp.N)*(hp.Δx^3))

        #first correlation coefficient
        c1k = inv(αk)*tanh(0.5*αk*hp.Δt)
    
        #second correlation coefficient
        c2k = inv(αk)*sqrt(2*Dk_over_αk*(αk*hp.Δt - 2*tanh(0.5*αk*hp.Δt)))

        #generate first RV
        Ξk = sqrt(Dk_over_αk*(1 - exp(-2*αk*hp.Δt))) *
             PhiloxArrays.ConjSymRandNArray{Float32}(Tuple(hp.N),UInt64(key),UInt64(counter))[i]

        #generate second RV
        #note we use key' = key + N₁×N₂×N₃ because we need a different random field for all the grid points
        Gk = PhiloxArrays.ConjSymRandNArray{Float32}(Tuple(hp.N),UInt64(key+prod(hp.N)),UInt64(counter))[i]

        #calculate Γk
        Γk[i] = inv(αk) * (1 - exp(-αk * hp.Δt)) * ukold[i] .+ 
                   ((hp.Δt * inv(αk)) + (inv(αk^2) * (exp(-αk * hp.Δt) - 1))) * inv(hp.ρ) * (Projk * fkdens[i]) .+ 
                   c1k * (Projk * Ξk) .+
                   c2k * (Projk * Gk)
        
        #calculate uknew
        uknew[i] = exp(-αk * hp.Δt) * ukold[i] .+ 
                      inv(hp.ρ * αk) * (1 - exp(-αk * hp.Δt)) * (Projk * fkdens[i]) .+ 
                      Projk * Ξk
    end
end

"""
Eqn. 104: Numerical estimator of diffusion coefficient for single particle measured from simulation
of a trajectory. Results are then averaged over many trajectories to get Eqn. 104.
"""
function D_estimate(nstep,Δt,X)
    return inv(6*nstep*Δt)*(norm(view(X,1,:,nstep).-view(X,1,:,1)))^2
end

"""
Estimate statistics for diffusion coefficient for single value of IB point radii
"""
function main_estimate_D_single_a(hp::Hydroparams,ibp::Ibparams,sp::Simparams)
    D_sample = []
    for ir in 1:sp.nrep
        traj_rnodes = main_single_free_Float32(hp,ibp,sp,ir)
        #traj_rnodes = main_single_CUDA(hp,ibp,sp,ir)
        D_sample = cat(D_sample,D_estimate(sp.nstep,hp.Δt,traj_rnodes),dims=1)
    end
    D_est = mean(D_sample)
    D_est_stddev = std(D_sample)
    D_est_stderr = sqrt(var(D_sample)/sp.nrep)
    return D_est, D_est_stddev, D_est_stderr
end

"""
Estimate diffusion coefficient for different IB particle radii
"""
function main_estimate_D(a_values,hp::Hydroparams,ibp::Ibparams,sp::Simparams)
    D_est_all_a = []
    D_est_stddev_all_a = []
    D_est_stderr_all_a = []
    for ia in eachindex(a_values)
        ibp.a = a_values[ia]
        D_est, D_est_stddev, D_est_stderr = main_estimate_D_single_a(hp,ibp,sp)
        D_est_all_a = cat(D_est_all_a,D_est,dims=1)
        D_est_stddev_all_a = cat(D_est_stddev_all_a,D_est_stddev,dims=1)
        D_est_stderr_all_a = cat(D_est_stderr_all_a,D_est_stderr,dims=1)
    end
    return D_est_all_a, D_est_stddev_all_a, D_est_stderr_all_a
end

"""
Plot estimate of the diffusion coefficient with standard errors as a function of 
the immersed boundary particle radius parameter a
"""
function plot_D_est(D_est,D_est_stddev,D_est_stderr,a_values,Dymin,Dymax,Dyticksize,D_conversion_factor,filename,hp::Hydroparams,ibp::Ibparams)
    f = Figure(fontsize = 20)
    ax = Axis(f[1, 1])
    
    #plot numerical results with standard deviation
    #CairoMakie.errorbars!(a_values/hp.Δx, D_est*D_conversion_factor,
    #    D_est_stddev*D_conversion_factor, color = :red, whiskerwidth = 10)

    #plot numerical results with standard error of the mean
    CairoMakie.errorbars!(a_values/hp.Δx, D_est*D_conversion_factor,
        D_est_stderr*D_conversion_factor, color = :red, whiskerwidth = 10)
    
    CairoMakie.scatter!(a_values/hp.Δx, D_est*D_conversion_factor, markersize = 10, color = :black)
    
    #plot stoke-einstein comparison values
    #CairoMakie.scatter!(a_values/hp.Δx, hp.kT*inv(6*π*hp.μ)*inv.(a_values)*D_conversion_factor, markersize = 15, marker = :utriangle, color = :blue)
    
    #ax.title = ""
    ax.xlabel = L"a \quad [\times \Delta x = %$(hp.Δx) \, nm]"
    ax.ylabel = L"D \quad [{\mu m}^{2}/{s}]"
    ax.xticks = a_values/hp.Δx
    ax.yticks = Dymin:Dyticksize:Dymax
    f
    save(filename, f; backend=CairoMakie)
    f
end

"""
Move entire system nstep timesteps forward
"""
function main_single_free_Float32(hp::Hydroparams,ibp::Ibparams,sp::Simparams,key)
    #define slab of points in k-space
    Nirfft = (div(hp.N[1],2)+1,hp.N[2],hp.N[3])
    #initialize velocity field and IB node positions in r-space
    Γm = zeros(SVector{3, Float32},Tuple(hp.N))
    #initialize velocity field and IB node positions in k-space
    fkdens = zeros(SVector{3, Complex{Float32}},Nirfft)
    uk = zeros(SVector{3, Complex{Float32}},Nirfft)
    Γk = zeros(SVector{3, Complex{Float32}},Nirfft)
    #initialize filaments IB node locations
    rnodes = [hp.N[1] hp.N[2] hp.N[3]]*inv(2.0f0)*hp.Δx
    #initialize output IB trajectory data arrays
    traj_rnodes = copy(rnodes)
    #Define the brfft plan
    P_brfft = plan_brfft(reinterpret(reshape,ComplexF32,uk),hp.N[1],(2,3,4))
    #integrate system forward in time
    for it in 1:sp.nstep
        #calculate the fields
        update_fields!(uk,uk,Γk,fkdens,hp,it,key)
        #get r-space integrated velocity field
        Γm = P_brfft*reinterpret(reshape,Complex{Float32},Γk)
        #update the IB node positions
        update_rnodes_wrapped!(rnodes,rnodes,Γm,hp.Δx,hp.N,ibp.a)
        #get the node positions and store
        traj_rnodes = cat(traj_rnodes,rnodes,dims=3)
        #display timestep
        #@info "Finished timestep it = $it"
    end
    return traj_rnodes
end

"""
Move entire system nstep timesteps forward
"""
function main_single_CUDA(hp::Hydroparams,ibp::Ibparams,sp::Simparams,key)
    
    numthreads = 256
    numblocks_nodes = ceil(Int, ibp.npart/numthreads)
    numblocks_grids = ceil(Int, prod(hp.N)/numthreads)

    #define slab of points in k-space
    Nirfft = (div(hp.N[1],2)+1,hp.N[2],hp.N[3])
    #initialize velocity field and IB node positions in r-space
    Γm = cu(zeros(SVector{3, Float32},Tuple(hp.N)))
    #initialize velocity field and IB node positions in k-space
    fkdens = cu(zeros(SVector{3, Complex{Float32}},Nirfft))
    uk = cu(zeros(SVector{3, Complex{Float32}},Nirfft))
    Γk = cu(zeros(SVector{3, Complex{Float32}},Nirfft))
    #initialize filaments IB node locations
    rnodes = cu([hp.N[1] hp.N[2] hp.N[3]]*inv(2)*hp.Δx)
    #initialize output IB trajectory data arrays
    traj_rnodes = copy(rnodes)
    #Define the brfft plan
    P_brfft = plan_brfft(reinterpret(reshape,ComplexF32,uk),hp.N[1],(2,3,4))
    #integrate system forward in time
    for it in 1:sp.nstep
        #calculate the fields
        @cuda threads=numthreads blocks=numblocks_grids ImmersedBoundaries.update_fields_CUDA!(uk,uk,Γk,fkdens,hp,it,key)
        #ImmersedBoundaries.update_fields!(uk,uk,Γk,fkdens,hp,it,key)
        #get r-space integrated velocity field
        Γm = reinterpret(reshape,SVector{3, Float32},P_brfft*reinterpret(reshape,ComplexF32,Γk))
        #update the IB node positions
        @cuda threads=numthreads blocks=numblocks_nodes ImmersedBoundaries.update_rnodes_CUDA!(rnodes,rnodes,Γm,hp.N,hp.Δx,ibp.a)
        #ImmersedBoundaries.update_rnodes_wrapped!(rnodes,rnodes,Γm,hp.Δx,hp.N,ibp.a)
        #get the node positions and store
        traj_rnodes = cat(traj_rnodes,rnodes,dims=3)
        #display timestep
        #@info "Finished timestep it = $it"
    end
    return traj_rnodes
end

"""
Main function for SIBM simulation of colloidal globular actin particles with CUDA
"""
function main_gactin_colloid_CUDA(hp::Hydroparams,ibp::Ibparams,sp::Simparams,gactinfp::Actinstericforceparams,key)
    
    # Use your GPU's backend, e.g. CUDABackend()
    backend = CUDABackend()

    numthreads = 256
    numblocks_nodes = ceil(Int, ibp.npart/numthreads)
    numblocks_grids = ceil(Int, prod(hp.N)/numthreads)

    #define slab of points in k-space
    Nirfft = (div(hp.N[1],2)+1,hp.N[2],hp.N[3])
    #initialize the force, force density in r-space, k-space, velocity field and IB node positions in k-space
    Fnodes = cu(zeros(Float32, 3, ibp.npart))
    fmdens = cu(zeros(SVector{3, Float32},Tuple(hp.N)))
    fkdens = cu(zeros(SVector{3, Complex{Float32}},Nirfft))
    uk = cu(zeros(SVector{3, Complex{Float32}},Nirfft))
    Γm = cu(zeros(SVector{3, Float32},Tuple(hp.N)))
    Γk = cu(zeros(SVector{3, Complex{Float32}},Nirfft))
    #Define the rfft and brfft plans
    P_rfft = plan_rfft(reinterpret(reshape,Float32,Γm),(2,3,4))
    P_brfft = plan_brfft(reinterpret(reshape,ComplexF32,Γk),hp.N[1],(2,3,4))


    # Generate grid of particles
    coordinates_ = Array{Float32}(undef, 3, ibp.npart)
    npartedge = Int(cbrt(ibp.npart))
    n_particles_per_dimension = (npartedge,npartedge,npartedge)
    cartesian_indices = CartesianIndices(n_particles_per_dimension)
    Fnodes = cu(zeros(Float32, 3, ibp.npart))
    for i in axes(coordinates_, 2)
        coordinates_[:, i] .= Tuple(cartesian_indices[i])
    end
    #scale and slightly vary the particle positions away from a perfect lattice
    coordinates = (coordinates_*inv(n_particles_per_dimension[1])).*hp.N*hp.Δx .+ (rand(Float32,3,ibp.npart) .- 0.5*ones(Float32,3,ibp.npart))*sp.randmag
    # Create a periodic box for periodicity
    periodic_box = PeriodicBox(min_corner=zeros(Float32,3), max_corner=ones(Float32,3).*hp.N*hp.Δx)
    # `FullGridCellList` requires a bounding box
    min_corner = minimum(coordinates, dims=2)
    max_corner = maximum(coordinates, dims=2)
    search_radius = gactinfp.rcut
    cell_list = FullGridCellList(; search_radius, min_corner, max_corner)
    nhs_cpu = GridNeighborhoodSearch{3}(; search_radius, cell_list, periodic_box)
    # Initialize the NHS to find neighbors in `coordinates` of particles in `coordinates`
    initialize!(nhs_cpu, coordinates, coordinates)
    # Convert data structures to the GPU
    rnodes = adapt(backend, coordinates)
    nhs = adapt(backend, nhs_cpu)

    #initialize output IB trajectory data arrays
    #traj_rnodes = copy(rnodes)
    #integrate system forward in time
    for it in 1:sp.nstep
        # Initialize the NHS to find neighbors in `rnodes` of particles in `rnodes`
        update!(nhs, rnodes, rnodes)
        #calculate the nonbonded forces
        Gactin_steric_force_total!(gactinfp, Fnodes, rnodes, nhs, backend)
        #zero out force density field from previous time step
        zero(fmdens)
        #calculate the force density
        @cuda threads=numthreads blocks=numblocks_nodes ImmersedBoundaries.calculate_fdens_CUDA!(reinterpret(reshape,Float32,fmdens),rnodes',Fnodes',hp.N,hp.Δx,ibp.a)
        #calculate FFT of force density
        fkdens = reinterpret(reshape,SVector{3, ComplexF32},P_rfft*reinterpret(reshape,Float32,fmdens))
        #update the fields
        @cuda threads=numthreads blocks=numblocks_grids ImmersedBoundaries.update_fields_CUDA!(uk,uk,Γk,fkdens,hp,it,key)
        #get r-space integrated velocity field
        Γm = reinterpret(reshape,SVector{3, Float32},P_brfft*reinterpret(reshape,ComplexF32,Γk))
        #update the IB node positions
        @cuda threads=numthreads blocks=numblocks_nodes ImmersedBoundaries.update_rnodes_CUDA!(rnodes',rnodes',Γm,hp.N,hp.Δx,ibp.a)
        #get the node positions and store
        #traj_rnodes = cat(traj_rnodes,rnodes,dims=3)
        #display timestep
        @info "Finished timestep it = $it"
    end
    #return traj_rnodes
end

"""
Eqn. A.1: Define the 1D radially dependent Peskin kernel component.
"""
function ϕ(r::T)::T where T
    if r <= -2
        return zero(r)
    elseif -2 <= r < -1
        return inv(8)*(5 + 2*r - sqrt(-7 - 12*r - 4*r^2))
    elseif -1 <= r < 0
        return inv(8)*(3 + 2*r + sqrt(1 - 4*r - 4*r^2)) 
    elseif 0 <= r < 1
        return inv(8)*(3 - 2*r + sqrt(1 + 4*r - 4*r^2)) 
    elseif 1 <= r < 2
        return inv(8)*(5 - 2*r - sqrt(-7 + 12*r - 4*r^2)) 
    elseif 2 <= r
        return zero(r)
    else #this is in the event of an error
        return r
    end
end

"""
Eqn. A.2: Define the 3D radially dependent Peskin kernel.
"""
function δₐ(rvec,a)
    #return inv(a^3)*ϕ(inv(a)*rvec[1])*ϕ(inv(a)*rvec[2])*ϕ(inv(a)*rvec[3])
    term0 = inv(a^3)
    term1 = ϕ(inv(a)*rvec[1])
    term2 = ϕ(inv(a)*rvec[2])
    term3 = ϕ(inv(a)*rvec[3])
    return term0*term1*term2*term3
end

end
