module ImmersedBoundaries
using StaticArrays
using LinearAlgebra
export hydroparams
export ibparams
export forceparams
export simparams

# Write your package code here.

"""
Struct for hydrodynamic parameters
"""
struct hydroparams
    N::SVector{3,Int64} #number of immersed boundary points
    kT::Float64 #temperature in joules (Boltzmann's constant x actual temperature)
    ρ::Float64 #density of fluid
    μ::Float64 #dynamic viscosity of fluid
    Δx::Float64 #fluid grid cell width
    Δt::Float64 #time step
end

"""
Struct for immersed boundary parameters
"""
mutable struct ibparams
    npart::Int64 #number of immersed boundary points
    a::Float64 #radius of immersed boundary point in multiples of the grid cell width Δx
end

"""
Struct for immersed boundary parameters
"""
struct forceparams
    K0::Float64 #filament node bond stretching parameter
    S0::Float64 #filament node equilibrium bond length parameter
    k∠::Float64 #filament node bending parameter
    rcenter::SVector{3, Float64} #central force center position
end

"""
Struct of parameters for a basic simulation of a single elastic filament in a fluid
"""
struct simparams
    nstep::Int64
    randmag::Float64
    Δz::Float64
    fbits::Int64
    nrep::Int64
end

"""
Use to converts Float64 to Int64, number of fractional bits hardcoded to 20.
"""
function unsaferound(x,::Val{fbits}) where {fbits}
    unsafe_trunc(Int64,(x*(2.0^fbits)))
end

"""
Initialize configuration of IB nodes for a single filament unbent, oriented
parallel to the z-axis.
"""
function initialize_IB_nodes_filparaz(nnode,Δx1,Δx2,Δx3,Δx,N,disp)
    rnodes = zeros(nnode,3)
    for k in 1:nnode
        rnodes[k,1] = (N[1]/2)*Δx + (k-1)*Δx1 - (nnode/4)*Δx1 + disp[1]
        rnodes[k,2] = (N[2]/2)*Δx + (k-1)*Δx2 - (nnode/4)*Δx2 + disp[2]
        rnodes[k,3] = (N[3]/2)*Δx + (k-1)*Δx3 - (nnode/4)*Δx3 + disp[3]
    end
    return rnodes
end

"""
Define harmonic force law.
"""
function tension_law(r,K0,S0)
    return K0*(r - S0)
end

"""
Calculate the dispacement vector between two position vectors.
"""
function calculate_forcevec(rveci,rvecj,K0,S0)
    dispvec = SVector{3,Float64}(rvecj .- rveci)
    return (dispvec./norm(dispvec))*tension_law(norm(dispvec),K0,S0)
end

"""
Calculate the array of forces on each node in the IB given the configuration of the nodes in the IB.
"""
function calculate_stretching_force!(Fnodes,rnodes,K0,S0,fbits)
    #sum over all pairs of particles in the polymer
    for ib in 1:size(rnodes,1)-1
        rnodei = SVector{3,Float64}(view(rnodes,ib,:))
        rnodej = SVector{3,Float64}(view(rnodes,ib+1,:))
        temp_arr = calculate_forcevec(rnodei,rnodej,K0,S0)
        for k in 1:3
            temp_arr_round = unsaferound(temp_arr[k],fbits)
            @inbounds Fnodes[ib,k] += temp_arr_round
            @inbounds Fnodes[ib+1,k] -= temp_arr_round
        end
    end
end

"""
Eqn. 8: Calculate the force density array associated with each IB node.
"""
function calculate_fdens!(fdens,r,F,N,Δx,a)
    fdens .= 0
    #loop over all nodes in the immersed boundary
    for l in eachindex(view(r,:,1))
        rIB = SVector{3}(view(r,l,:))
        FIB = SVector{3}(view(F,l,:))
        #loop over all fluid grid cells in a cube that circumscribes a sphere
        #with radius equal to the immersed boundary point radius a=n*Δx
        for i in ceil(Int,(rIB[1]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[1]*inv(Δx))+2*Int(a*inv(Δx)))
            i -= (floor(Int,i/N[1]))*N[1] #account for PBC
            for j in ceil(Int,(rIB[2]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[2]*inv(Δx))+2*Int(a*inv(Δx)))
                j -= (floor(Int,j/N[2]))*N[2] #account for PBC
                for k in ceil(Int,(rIB[3]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[3]*inv(Δx))+2*Int(a*inv(Δx)))
                    k -= (floor(Int,k/N[3]))*N[3] #account for PBC
                    #use PBC for displacement between grid point (i,j,k)-th and node point r
                    Δrm = SA[i,j,k]*Δx - rIB
                    Δrm -= (round.(Int,Δrm./(N*Δx))).*N*Δx
                    view(fdens,:,i+1,j+1,k+1) .+= FIB*δₐ(Δrm,a)
                end
            end
        end
    end
end

"""
Eqn. 8: Calculate the force density array associated with each IB node.
"""
function calculate_fdens_grid_first!(fdens,r,F,N,Δx,a)
    for i in 1:N[1]
        i -= (floor(Int,i/N[1]))*N[1] #account for PBC
        for j in 1:N[2]
            j -= (floor(Int,j/N[2]))*N[2] #account for PBC
            for k in 1:N[3]
                k -= (floor(Int,k/N[3]))*N[3] #account for PBC
                #use PBC for displacement between grid point (i,j,k)-th and node point r
                #loop over all nodes in the immersed boundary
                for l in eachindex(view(r,:,1))
                    Δrm = SA[i,j,k]*Δx - view(r,l,:)
                    Δrm -= (round.(Int,Δrm./(N*Δx))).*N*Δx
                    view(fdens,:,i+1,j+1,k+1) .+= view(F,l,:)*δₐ(Δrm,a)
                end
            end
        end
    end
end


"""
Eqn. A.1: Define the 1D radially dependent Peskin kernel component.
"""
function ϕ(r::T)::T where T
    if r <= -2
        return zero(r)
    elseif -2 <= r < -1
        return inv(8)*(5 + 2*r - sqrt(-7 - 12*r - 4*r^2))
    elseif -1 <= r < 0
        return inv(8)*(3 + 2*r + sqrt(1 - 4*r - 4*r^2)) 
    elseif 0 <= r < 1
        return inv(8)*(3 - 2*r + sqrt(1 + 4*r - 4*r^2)) 
    elseif 1 <= r < 2
        return inv(8)*(5 - 2*r - sqrt(-7 + 12*r - 4*r^2)) 
    elseif 2 <= r
        return zero(r)
    else #this is in the event of an error
        return r
    end
end

"""
Eqn. A.2: Define the 3D radially dependent Peskin kernel.
"""
function δₐ(rvec,a)
    #return inv(a^3)*ϕ(inv(a)*rvec[1])*ϕ(inv(a)*rvec[2])*ϕ(inv(a)*rvec[3])
    term0 = inv(a^3)
    term1 = ϕ(inv(a)*rvec[1])
    term2 = ϕ(inv(a)*rvec[2])
    term3 = ϕ(inv(a)*rvec[3])
    return term0*term1*term2*term3
end

end
