# Example Simulations

This directory contains example MEDYAN.jl simulation projects.

The example projects use MEDYAN from the parent directory 

If you want to copy these examples to run a simulation outside of this repo,
make sure copy the source code of MEDYAN.jl and edit the Project.toml "sources"
section.


Otherwise, your simulation may fail to run.

## Running Examples

To run the `vesicle` example:

First install example dependencies with:
```sh
julia --project -e 'using Pkg; Pkg.instantiate()'
```

Then run:
```sh
JULIA_LOAD_PATH="@" julia --heap-size-hint=2G --project --startup-file=no vesicle/main.jl --out=vesicle/output
```

Visualizing outputs in Paraview:

```julia
using Pkg
pkg"dev ../MEDYAN2Vtk"
using MEDYAN2Vtk
rm("vesicle/out1.medyanvis"; force=true, recursive=true)
medyan2vtk("vesicle/output/1", "vesicle/out1.medyanvis")
# vesicle/out1.medyanvis/full_simulation.pvd can be opened in paraview.
run(`paraview vesicle/out1.medyanvis/full_simulation.pvd`)
```

## Creating New Example

1. Copy an existing example, and give it a new name.
1. In the `input` directory of the example modify `main.jl` and the local julia environment.

See https://github.com/medyan-dev/MEDYANSimRunner.jl for more details on that goes in the `main.jl` script.

It may be helpful to run a JET analysis on your `main.jl` file to detect errors before running the full simulation.

```julia
using JET
report_file("main.jl"; analyze_from_definitions = true, target_defined_modules=true)
```


