using MEDYAN
using MeshCat
using StaticArrays
using LinearAlgebra
using Random
using Setfield
using Sockets
using Test
using Plots
using Meshing
using MEDYANVis
using DelimitedFiles


"""
Return the context and sysdef
"""
function setup( ;seed = 1234)
    Random.seed!(seed)
    agentnames = MEDYAN.AgentNames(
        diffusingspeciesnames= [
            :A, # actin
            :LD, # crosslinker
            :MD, # motor
            :BD, # branch
            :FO, # formin
            :FOA, # formin actin nucleation intermediate
        ],
        filamentnames= [(:actin,[
                                :AF, # middle actin
                                :PA, # plus end actin
                                :FP, # plus end formin
                                :MA, # minus end actin
                                :freeARP23, #arp23 on minus end of detached daughter filament
                                :boundARP23, #arp23 on minus end of attached daughter filament
                                :bound, # general bound actin
                                :restrained, # Non-active monomers
                                :oldbranch,
                                :newbranch,
                            ]),
        ],
        vertexnames = [],
    )
    grid = CubicGrid((3,3,3),500.0)
    corner = MEDYAN.cornerof(grid)

    # add reactions
    monomerspacing = 2.7 # nm
    numpercylinder = 40
    begin
        s= MEDYAN.SysDef(agentnames)

        #polymerization
        addfilamentend_reaction!(s, :actin, :pp, false,
            [:PA]=>[:AF,:PA], monomerspacing,
            "diffusing.A -->", 0.3852*1E8, 1,
        )
        addfilamentend_reaction!(s, :actin, :mp, true,
            [:MA]=>[:MA,:AF], monomerspacing,
            "diffusing.A -->", 0.0216*1E8, 1,
        )

        #depolymerization
        addfilamentend_reaction!(s, :actin, :dpp, false,
            [:AF,:PA]=>[:PA], 0.0,
            "--> diffusing.A", 1.4, 0,
        )
        #minus end depolymerization
        addfilamentend_reaction!(s, :actin, :dmp, true,
            [:MA,:AF]=>[:MA], 0.0,
            "--> diffusing.A", 1.6, 0,
        )

        #motor stepping
        onrate = 0.2
        offrate = 1.7
        dutyratio = onrate/(onrate+offrate)
        motorstepsize = 10
        stepping_rate = MEDYAN.LinkRateMotorStall(
            fs = 90.0,
            k0 = 6.0/(108/4)*((1 - dutyratio) / dutyratio) * onrate,
        )
        function step_motor_affect!(c::MEDYAN.Context; link, place_idx, kwargs...)
            local t = link2tags(c, link)[place_idx]
            local old_place = tag2place(c, t)::FilaMonoIdx
            local new_place = FilaMonoIdx(c, old_place, +motorstepsize)
            # check if the new monomer exists
            place_exists(c, new_place) || return 0
            # check if the new monomer is in the right state
            get_chem_state(c, new_place).monomer_state == c.sys_def.state.actin.AF || return 0
            #set the new monomer states
            update_fila_mono_state!(c, old_place, :AF)
            update_fila_mono_state!(c, new_place, :bound)
            update_link!(c, link; places=@set((nothing, nothing)[place_idx]=new_place))
            1
        end
        
        MEDYAN.add_link_type!(s;
            name=:motor,
            description="non muscle myosin 2 motor filament",
            places=[MEDYAN.FilaMonoIdx(), MEDYAN.FilaMonoIdx()],
            state= (;numHeads=20,),
            bonds=[
                (;
                    bond=MEDYAN.DistanceRestraint(),
                    input=(1,2),
                    state=(;L0=NaN,),
                    param=(;k=55.0,),
                ),
            ],
            reactions=[
                [
                    (;
                        name = :unbinding,
                        affect! = (c::MEDYAN.Context; link, chem_voxel, kwargs...) -> let
                            local mt, pt = link2tags(c, link)
                            #set the new monomer states
                            if !MEDYAN.is_null(mt)
                                update_fila_mono_state!(c, mt, :AF)
                            end
                            if !MEDYAN.is_null(pt)
                                update_fila_mono_state!(c, pt, :AF)
                            end
                            remove_link!(c, link)
                            add_diffusing_count!(c; species=:MD, chem_voxel, amount=+1)
                            1
                        end,
                        rate= MEDYAN.LinkRateMotorCatch(),
                    ),
                    (;
                        name = :stepping_minus_end,
                        affect! = step_motor_affect!,
                        rate = stepping_rate,
                    ),
                ],
                [
                    (;
                        name = :stepping_plus_end,
                        affect! = step_motor_affect!,
                        rate = stepping_rate,
                    ),
                ],
            ],
        )

        
        MEDYAN.add_link_type!(s;
            name=:crosslinker,
            description="actin crosslinker",
            places=[MEDYAN.FilaMonoIdx(), MEDYAN.FilaMonoIdx()],
            bonds=[
                (;
                    bond=MEDYAN.DistanceRestraint(),
                    input=(1,2),
                    state=(;L0=NaN,),
                    param=(;k=8.0,),
                ),
            ],
            reactions=[
                [
                    (;
                        name = :unbinding,
                        affect! = (c::MEDYAN.Context; link, chem_voxel, kwargs...) -> let
                            local mt, pt = link2tags(c, link)
                            #set the new monomer states
                            if !MEDYAN.is_null(mt)
                                update_fila_mono_state!(c, mt, :AF)
                            end
                            if !MEDYAN.is_null(pt)
                                update_fila_mono_state!(c, pt, :AF)
                            end
                            remove_link!(c, link)
                            add_diffusing_count!(c; species=:LD, chem_voxel, amount=+1)
                            1
                        end,
                        rate= MEDYAN.LinkRateSlipBond(f0 = inv(0.24*MEDYAN.default_β), k0 = 0.3),
                    ),
                ],
            ],
        )

        MEDYAN.add_link_type!(s;
            name=:brancher,
            description="actin brancher",
            places=[MEDYAN.FilaMonoIdx(), MEDYAN.FilaMonoIdx()],
            bonds=[
                (;
                    bond=MEDYAN.BranchBendingCosine(),
                    input=(1,2),
                    param=(;kr=5.0, kbend=5.0, cos0=cos(1.22), sin0=sin(1.22)),
                    no_collide=true,
                ),
            ],
            reactions=[
                [
                    (;
                        name = :unbinding,
                        affect! = (c::MEDYAN.Context; link, chem_voxel, kwargs...) -> let
                            local mt, pt = link2tags(c, link)
                            #set the new monomer states
                            if !MEDYAN.is_null(mt)
                                update_fila_mono_state!(c, mt, :AF)
                            end
                            if !MEDYAN.is_null(pt)
                                update_fila_mono_state!(c, pt, :freeARP23)
                            end
                            remove_link!(c, link)
                            1
                        end,
                        rate= MEDYAN.LinkRateSlipBond(f0 = inv(0.24*MEDYAN.default_β), k0 = 0.01),
                    ),
                ],
            ],
        )

        # COFILIN
        site = MEDYAN.FilamentSiteGeneral(3,fill(s.state.actin.AF,3))# center + 3states
        MEDYAN.addfilamentsite!(s, :actin, :cofilin, site) # add filamentsite info to system 
        sitecallback = MEDYAN.GeneralFilamentSiteCallback(
            s.filament.actin,
            s.filamentsite.actin.cofilin.id,
            2,#fsid
            [s.state.actin.oldbranch],
            [],
        )

        severcallback = MEDYAN.FilamentSiteSeveringCallback(sitecallback, 1, s.filamentsite.actin.cofilin.id, false, s.diffusing.A)
        addreactioncallback!(s,
            "filamentsite.actin.cofilin",
            1.0E6,#Not experimental data. Be large to test. 
            1,
            severcallback,
        ) 

        #Destruction
        addfilamentendsite!(s,:actin,:destroy_actin_fil,
            MEDYAN.FilamentEndSiteGeneral(false,[s.state.actin.MA,s.state.actin.PA],0.0)
        )
        MEDYAN.addreactioncallback!(s, "filamentendsite.actin.destroy_actin_fil", 1.5, 0,
            MEDYAN.FilamentDestructionCallback(s.filament.actin, s.filamentendsite.actin.destroy_actin_fil.id, [s.diffusing.A=>2])
        )
        addfilamentendsite!(s,:actin,:destroy_actin_formin_fil,
            MEDYAN.FilamentEndSiteGeneral(false,[s.state.actin.MA,s.state.actin.FP],0.0)
        )
        MEDYAN.addreactioncallback!(s, "filamentendsite.actin.destroy_actin_formin_fil", 1.5, 0,
            MEDYAN.FilamentDestructionCallback(s.filament.actin, s.filamentendsite.actin.destroy_actin_formin_fil.id, [s.diffusing.A=>1, s.diffusing.FOA=>1])
        )
        addfilamentendsite!(s,:actin,:destroy_actin_arp23_fil,
            MEDYAN.FilamentEndSiteGeneral(false,[s.state.actin.freeARP23,s.state.actin.PA],0.0)
        )
        MEDYAN.addreactioncallback!(s, "filamentendsite.actin.destroy_actin_arp23_fil", 1.5, 0,
            MEDYAN.FilamentDestructionCallback(s.filament.actin, s.filamentendsite.actin.destroy_actin_arp23_fil.id, [s.diffusing.A=>1, s.diffusing.BD=>1])
        )

        #motor binding
        site = MEDYAN.Decimated2MonSiteMinAngleRange(
            s.filament.actin,
            s.filament.actin,
            motorstepsize,
            motorstepsize,
            s.state.actin.AF,
            s.state.actin.AF,
            175.0,
            225.0,
            cos(5*π/180),
        )
        add_decimated_2mon_site!(s, :motorbinding, site)
        bindcallback = MEDYAN.SimpleMotorBindCallback(
            s.decimated_2mon_site.motorbinding.id,
            s.link.motor.id,
            30, #max number of heads
            15, #min number of heads
            s.state.actin.bound,
            [s.diffusing.MD=>-1],
        )
        addreactioncallback!(
            s,
            "decimated_2mon_site.motorbinding + diffusing.MD",
            0.2*22*500^3/2,
            1,
            bindcallback,
        )

        #crosslinker binding site
        site = MEDYAN.Decimated2MonSiteMinAngleRange(
            s.filament.actin,
            s.filament.actin,
            10,
            10,
            s.state.actin.AF,
            s.state.actin.AF,
            30.0,
            40.0,
            cos(5*π/180)
        )
        add_decimated_2mon_site!(s,:crosslinkbinding,site)
        sitecallback = MEDYAN.SimpleCrosslinkBindCallback(
            s.decimated_2mon_site.crosslinkbinding.id,
            s.link.crosslinker.id,
            s.state.actin.bound,
            [s.diffusing.LD=>-1],
        )
        addreactioncallback!(s,
            "decimated_2mon_site.crosslinkbinding + diffusing.LD",
            0.01*500^3/2,
            1,
            sitecallback,
        )


        #branching site
        site = MEDYAN.FilamentSiteGeneral(2,fill(s.state.actin.AF,3))
        addfilamentsite!(s, :actin, :branch, site)
        sitecallback = MEDYAN.GeneralFilamentSiteCallback(
            s.filament.actin,
            s.filamentsite.actin.branch.id,
            1,
            [s.state.actin.bound],
            [],
        )
        branchcallback = MEDYAN.FilamentSiteBranchingCallback(
            sitecallback,
            s.link.brancher.id,
            s.filament.actin,
            true,
            true,
            [s.state.actin.boundARP23,s.state.actin.PA],
            [s.diffusing.A=>-1, s.diffusing.BD=>-1],
        )
        addreactioncallback!(s,
            "filamentsite.actin.branch + diffusing.A + diffusing.BD",
            0.0001*1E8*1E8,
            2,
            branchcallback,
        )


    end

    add_diffusion_coeff!(s, :A, 100.0*0.25E6)
    add_diffusion_coeff!(s, :LD, 10.0*0.25E6)
    add_diffusion_coeff!(s, :MD, 10.0*0.25E6)
    add_diffusion_coeff!(s, :BD, 10.0*0.25E6)

    filamentmechparams= [MEDYAN.ACTIN_FIL_PARAMS]
    add_filament_params!(s, :actin, filamentmechparams)
    membranemechparams = [
        MEDYAN.MembraneMechParams(
            kbend = 100,
            tension = 0.02,
            kpinning = 10,
        ),

    ]

    @info "P start to create context."
    c= MEDYAN.Context(s,grid;
        filamentmechparams,
        membranemechparams,
        g_tol=1.0,
        max_cylinder_force = 2000.0,
        maxstep = 0.7,
    )

    set_mechboundary!(c, MEDYAN.boundary_box(grid; stiffness=1.0))
    adddiffusingcount_rand!(c, s.diffusing.A, 625*prod(grid.n))
    adddiffusingcount_rand!(c, s.diffusing.LD, 63*prod(grid.n))
    adddiffusingcount_rand!(c, s.diffusing.MD, 6*prod(grid.n))
    adddiffusingcount_rand!(c, s.diffusing.BD, 6*prod(grid.n))



    numcyl = 2#10
    monomerspacing = 2.7
    numpercylinder = 40
    nummon = numpercylinder * numcyl
    monomerstates = zeros(UInt8, nummon)#fill(s.state.actin.middle, nummon)
    monomerstates[1:end] .= s.state.actin.AF
    monomerstates[1] = s.state.actin.MA
    monomerstates[end] = s.state.actin.PA


    for i in 1:(1*1)
        make_fila_rand!(c, monomerstates)
        MEDYAN.minimize_energy!(c)
    end
     
    @info "Setup complete."
    return c,s
end


function run(; seed=1234, frames=2000, vis::Union{Visualizer,Nothing}=nothing)
    c,s = setup(;)

    Random.seed!(seed)

    if !isnothing(vis)
        MEDYANVis.draw_context!(vis, c, s)
    end

    MEDYAN.minimize_energy!(c)
    steps_totaldiffusingmonomers::Vector{Tuple{Int, Int}} = []
    @info "P start running."
    for i in 1:frames
        @info "P frame $i started."
        @time MEDYAN.run_chemistry!(c,0.005)      
        @time MEDYAN.minimize_energy!(c)       
        MEDYAN.refresh_chem_cache!(c) 

        totaldiffusingmonomers::Int = MEDYAN.current_diffusing_mon_num(c, s.diffusing.A)
 
        push!(steps_totaldiffusingmonomers, (i, totaldiffusingmonomers))
        
        
        if !isnothing(vis)
            MEDYANVis.draw_context!(vis, c, s)
        end

        @info "P frame $i finished."
        yield()
    end 
    return c, s
end


## Initialize visualizer
vis1 = Visualizer()
delete!(vis1)
setvisible!(vis1["/Grid"],false)
setvisible!(vis1["/Axes"],false)
setvisible!(vis1["/Background"],true)
setvisible!(vis1["/meshcat/mechboundary"],false)

render(vis1)


## Run part.
run(; vis=vis1)  