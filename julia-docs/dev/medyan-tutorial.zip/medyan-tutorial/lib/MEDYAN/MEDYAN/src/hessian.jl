"""
    $(FUNCTIONNAME)(fc::ForceContext, x0; dx=0.0001)
A finite differences approximation to the hessian at position `x0`.
Returns a tuple of the energy, force, and hessian
This may change the cached forces and energies in `fc`
`dx` is the amount to perturb `x0` when approximating the hessian, with units nm
"""
function hessian!(fc::ForceContext, x0; dx=0.0001)
    MEDYAN.refresh_neighborlists!(fc, x0)
    MEDYAN.calc_all_force_energy!(fc, x0)
    x = copy(x0)
    force0 = get_force(fc.per_thread_force_energy[1])
    force_pls = zeros(length(x))
    force_min = zeros(length(x))
    energy = get_energy(fc.per_thread_force_energy[1])
    hess = zeros(length(x),length(x))
    for i in 1:length(x)
        x .= x0
        x[i] += dx
        MEDYAN.calc_all_force_energy!(fc, x)
        get_force!(fc.per_thread_force_energy[1], force_pls)
        x .= x0
        x[i] -= dx
        MEDYAN.calc_all_force_energy!(fc, x)
        get_force!(fc.per_thread_force_energy[1], force_min)
        hess[:,i] .= (force_min .- force_pls)*inv(2*dx)
    end
    hess = 0.5*(hess + hess')
    return energy,force0,hess
end