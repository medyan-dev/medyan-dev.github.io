using CellListMap: ParticleSystem, ParticleSystem1, ParticleSystem2, map_pairwise!
import CellListMap


"""
Store list of pairs of indexes per chem_voxel.
"""
struct PairLists
    pairlists::Vector{Vector{Pair{Int32,Int32}}}
end

function PairLists(n::Integer)
    PairLists([Pair{Int32,Int32}[] for i in 1:n])
end

#define the required Output methods for CellListMap

CellListMap.copy_output(x::PairLists) = PairLists(map(copy,x.pairlists))

function CellListMap.reset_output!(x::PairLists)
    foreach(empty!, x.pairlists)
    x
end

function CellListMap.reducer(x::PairLists, y::PairLists)
    @argcheck length(x.pairlists) == length(y.pairlists)
    foreach(append!, x.pairlists, y.pairlists)
    x
end

abstract type AbstractDecimated2MonSiteManager end

"""

$(TYPEDFIELDS)
"""
Base.@kwdef struct Decimated2MonOneTypeSiteManager{SITE <: SiteData, SYSTEM <: ParticleSystem1} <: AbstractDecimated2MonSiteManager
    ftid::Int
    site::SITE
    system::SYSTEM
    step::Int
    points::Vector{SVector{3,Float64}} = []
    plusvecs::Vector{SVector{3,Float64}} = []
    cids::Vector{Int32} = []
    ftags::Vector{Tag{FilaTipIdx}} = []
    mids::Vector{Int32} = []
end

function Decimated2MonOneTypeSiteManager(grid::CubicGrid, site::SiteData; nthreads=1)
    simboxsize = collect(grid.n) .* grid.compartmentsize
    cutoff = cutoff_distance(site.site)
    ftid, ftid2 = getftids(site.site)
    step, step2 = getmidsteps(site.site)
    @argcheck step == step2
    @argcheck ftid == ftid2
    # pad the unit cell to avoid periodic effects
    unitcell = max.(cutoff*2.4, simboxsize .+ 1.2*cutoff .+ 0.2*grid.compartmentsize)
    system = ParticleSystem(;
        xpositions = SVector{3,Float64}[],
        unitcell,
        cutoff,
        output = PairLists(length(grid)),
        parallel = false,
    )
    Decimated2MonOneTypeSiteManager{
        typeof(site),
        typeof(system),
    }(;
        ftid,
        site,
        system,
        step,
    )
end

abstract type AbstractPossibleCadherinSiteManager end

"""

$(TYPEDFIELDS)
"""
@kwdef struct PossibleCadherinSiteManager{SITE <: SiteData, SYSTEM <: ParticleSystem2} <: AbstractPossibleCadherinSiteManager
    meshid::Int
    ftid::Int
    site::SITE
    system::SYSTEM
    fstep::Int#only for filaments
    vpoints::Vector{SVector{3,Float64}} = []#
    vcids::Vector{Int32} = []
    meshids::Vector{Int32} = []
    vidxs::Vector{Int32} = []
    fpoints::Vector{SVector{3,Float64}} = []
    fvecs::Vector{SVector{3,Float64}} = []
    cids::Vector{Int32} = []
    ftags::Vector{Tag{FilaTipIdx}} = []
    mids::Vector{Int32} = []
end

function PossibleCadherinSiteManager(grid::CubicGrid, site::SiteData; nthreads=1)
    simboxsize = collect(grid.n) .* grid.compartmentsize
    cutoff = cutoff_distance(site.site)
    meshid, ftid = getmeshidftid(site.site)
    fstep = getmidsteps(site.site)
    # pad the unit cell to avoid periodic effects
    unitcell = max.(cutoff*2.4, simboxsize .+ 1.2*cutoff .+ 0.2*grid.compartmentsize)
    system = ParticleSystem(;
        xpositions = SVector{3,Float64}[],#c.membranes[1].vertices.attr.coord,#SVector{3,Float64}[],# coord of vertices and filaments
        ypositions = SVector{3,Float64}[],
        unitcell, 
        cutoff,
        output = PairLists(length(grid)),
        parallel = false,
    )
    PossibleCadherinSiteManager{
        typeof(site),
        typeof(system),
    }(;
        meshid,
        ftid,
        site,
        system,
        fstep,
    )
end