using MEDYAN
using Dictionaries
using Test

@testset "PropDictionary" begin
    d=MEDYAN.PropDictionary(Dict(:a=>1,:b=>2))
    @test d.a == 1
    @test d.b == 2
    d.a = 3
    @test d.a == 3
    d2 = map(i->i*2, d)
    @test d2.a == 6
    insert!(d2,:c,22)
    @test d2.c == 22
    @test !haskey(d,:c)
    @test d2[3] == 22
    @test d[1] == d.a
    @test d[2] == d.b
end