include("./SIBM_functions_new.jl")

nrep = 1
idrep = 1
npart = 18
N = (128,128,128)
L = 4.0*10^3 #nm
kT = (8.316*1E3)*300.0 #(nm^2*amu/ns^2*K)*K
ρ = 602.0 #amu/nm^3
μ = 6.02*10^5 #amu/(nm ns)
Δx = L/N[1] #nm
Δt = 0.5*10^3 #ns
nstep = 500
k₀ = 1
a = k₀*Δx #nm
ia = 1
randmag = 0.0
Δz = 100.0
K0 = 0.5
S0 = 100.0
k∠ = 1000.0
fbits = 20
framerate = 10
grid_skip = 32
xlow = 0000.0
xup = 4000.0
ylow = 0000.0
yup = 4000.0
zlow = 0000.0
zup = 4000.0
filename = "ufield_IBtraj_anim.mp4"

#initialize structs
hp = hydroparams(N,kT,ρ,μ,Δx,Δt)
ibp = ibparams(npart,a,K0,S0,k∠)
sp = simparams(nstep,randmag,Δz,fbits)
ap = animparams(framerate,grid_skip,xlow,xup,ylow,yup,zlow,zup,filename)
main_filaments_ufield_profile(hp,ibp,sp,idrep)
traj_rnodes,total_um = main_filaments_ufield(hp,ibp,sp,idrep)
animate_ufield_IBtraj(traj_rnodes,total_um,hp,ibp,sp,ap)

"""
fbits = 20
K0 = 1.0
S0 = 1.0
k∠ = 1.0
rnodes = vcat([0.0 0.1 1.1],[0.0 0.0 0.0],[0.0 0.0 -0.9])
Fnodes_int = zeros(Int64,size(rnodes))

@profview for i in 1:1000000
    calculate_stretching_force!(Fnodes_int,rnodes,ibp.K0,ibp.S0,Val(sp.fbits))
end
@btime calculate_stretching_force!($Fnodes_int,$rnodes,$ibp.K0,$ibp.S0,Val($sp.fbits))
#calculate_bending_force!(Fnodes_int,rnodes,ibp.k∠,Val(sp.fbits))
#Fnodes_float = Fnodes_int*(2.0^-sp.fbits)
"""