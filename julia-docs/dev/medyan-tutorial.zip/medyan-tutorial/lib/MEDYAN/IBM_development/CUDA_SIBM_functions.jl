using CUDA
using Test
using BenchmarkTools
using StaticArrays
using OffsetArrays
using Adapt

"""
Real space grid struct
"""
struct domaingrid{N}
    boxwidth::Float32
    Δx::Float32
    size::NTuple{N,Int64}
    gridpositions::AbstractArray{SVector{3,Float32},N}
end

"""
Force density field struct
"""
struct forcedensityfield{N}
    grid::domaingrid
    field::AbstractArray{SVector{3,Float32},N}
end

"""
Immersed boundary struct
"""
struct immersedboundary{M}
    radiusIBnodes::Float32
    positionsIBnodes::AbstractArray{SVector{3,Float32},M}
end

#adapt struct for GPU
Adapt.@adapt_structure domaingrid
Adapt.@adapt_structure forcedensityfield
Adapt.@adapt_structure immersedboundary

rIB0 = [SA[Float32(1.0),Float32(1.0),Float32(1.0)],2*SA[Float32(1.0),Float32(1.0),Float32(1.0)]]
IB = immersedboundary(Float32(0.1),rIB0)
IB.positionsIBnodes .= 3*rIB0

println(IB.positionsIBnodes)



"""
Eqn. 8: Calculate the force density array associated with each IB node.
"""
"""
function calculate_fdens!(fdens,r,F,N,Δx,a)
    fdens .= 0
    fdens_OS = OffsetArray(fdens,-1,-1,-1,0)
    #loop over all nodes in the immersed boundary
    for l in eachindex(view(r,:,1))
        rIB = SVector{3}(view(r,l,:))
        FIB = SVector{3}(view(F,l,:))
        #loop over all fluid grid cells in a cube that circumscribes a sphere
        #with radius equal to the immersed boundary point radius a=n*Δx
        for i in ceil(Int,(rIB[1]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[1]*inv(Δx))+2*Int(a*inv(Δx)))
            i -= (floor(Int,i/N[1]))*N[1] #account for PBC
            for j in ceil(Int,(rIB[2]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[2]*inv(Δx))+2*Int(a*inv(Δx)))
                j -= (floor(Int,j/N[2]))*N[2] #account for PBC
                for k in ceil(Int,(rIB[3]*inv(Δx))-2*Int(a*inv(Δx))):1:floor(Int,(rIB[3]*inv(Δx))+2*Int(a*inv(Δx)))
                    k -= (floor(Int,k/N[3]))*N[3] #account for PBC
                    #use PBC for displacement between grid point (i,j,k)-th and node point r
                    Δrm = SA[i,j,k]*Δx - rIB
                    Δrm -= (round.(Int,Δrm./(N*Δx))).*N*Δx
                    view(fdens_OS,i,j,k,:) .+= FIB*δₐ(Δrm,a)
                end
            end
        end
    end
end
"""
"""
Eqn. A.2: Define the 3D radially dependent Peskin kernel.
"""
"""
function δₐ(rvec,a)
    #return inv(a^3)*ϕ(inv(a)*rvec[1])*ϕ(inv(a)*rvec[2])*ϕ(inv(a)*rvec[3])
    term0 = inv(a^3)
    term1 = ϕ(inv(a)*rvec[1])
    term2 = ϕ(inv(a)*rvec[2])
    term3 = ϕ(inv(a)*rvec[3])
    return term0*term1*term2*term3
end
"""