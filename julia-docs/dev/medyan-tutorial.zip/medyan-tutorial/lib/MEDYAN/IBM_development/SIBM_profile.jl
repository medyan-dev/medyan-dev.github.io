includet("./SIBM_functions.jl")

nrep = 1
npart = 10
N = [32,32,32]
L = 1.0*10^3 #nm
T = 300.0 #K
ρ = 602.0 #amu/nm^3
μ = 6.02*10^5 #amu/(nm ns)
Δx = L/N[1] #nm
Δt = 1.0*10^3 #ns
nstep = 20
k₀ = [1,2,3,4,5]
a = k₀*Δx #nm
randmag = 0.0
ia = 1
D_conversion_factor = 1000
framerate = 10
grid_skip = 4
filename = "ufield_IBtraj_anim.mp4"

#initialize velocity field and IB node positions
fkdens = zeros(Complex{Float64},N[1],N[2],N[3],3)
fmdens = zeros(Complex{Float64},N[1],N[2],N[3],3)
uk = zeros(Complex{Float64},N[1],N[2],N[3],3)
Γk = zeros(Complex{Float64},N[1],N[2],N[3],3)
Γm = zeros(N[1],N[2],N[3],3)
um = initialize_um_field_randunif(N,randmag)

#FFT initial velocity field
uk = fft(um,(1,2,3))

#initialize the force on the nodes, which in this special 
#case is zero since there is only a single point
Fnodes = zeros(npart,3)

#initialize the npart noninteracting, diffusing particle's IB node location
#to be the center of the simulation domain
rnodes = rand(npart,3).*N'*Δx

#calculate the force density and its discrete FFT
#fmdens = calculate_fdenstot(rnodes,Fnodes,N,Δx,a)
calculate_fdens!(fmdens,rnodes,Fnodes,N,Δx,a[ia])
fkdens = fft(fmdens,(1,2,3))
    
#calculate the fields
update_fields!(uk,uk,Γk,fkdens,N,T,ρ,μ,Δx,Δt)

@profview for i in 1:10
    update_fields!(uk,uk,Γk,fkdens,N,T,ρ,μ,Δx,Δt)
end

@btime update_fields!(uk,uk,Γk,fkdens,N,T,ρ,μ,Δx,Δt)

