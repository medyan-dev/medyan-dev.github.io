include("./SIBM_functions.jl")

nrep = 1
npart = 10
N = [32,32,32]
L = 1.0*10^3 #nm
T = 300.0 #K
ρ = 602.0 #amu/nm^3
μ = 6.02*10^5 #amu/(nm ns)
Δx = L/N[1] #nm
Δt = 1.0*10^3 #ns
nstep = 100
k₀ = [1,2,3,4,5]
a = k₀*Δx #nm
randmag = 0.0
ia = 1
D_conversion_factor = 1000
framerate = 10
grid_skip = 4
filename = "ufield_IBtraj_anim.mp4"

traj_rnodes,total_um = main_npart_ufield(npart,N,T,ρ,μ,Δx,Δt,nstep,a[ia],randmag)
animate_ufield_IBtraj(traj_rnodes,total_um,N,Δx,nstep,a[ia],framerate,grid_skip,filename)

