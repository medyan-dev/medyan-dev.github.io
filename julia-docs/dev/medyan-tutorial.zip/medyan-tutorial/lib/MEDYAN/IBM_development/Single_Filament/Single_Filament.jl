#import MEDYANSimRunner
using MEDYAN
using MEDYANVis
using StaticArrays
using LinearAlgebra
using Random
using Setfield
using OrderedCollections: OrderedDict
using SmallZarrGroups
using CairoMakie
Random.seed!(1234);

agent_names = MEDYAN.AgentNames(;
    diffusingspeciesnames=[
        :GA, # G-Actin with no bound nucleotide
        :GAD, # G-Actin in the ADP form
        :GADPi, # G-Actin in the ADP Pi form
        :GAT, # G-Actin in the ATP form
    ],
    filamentnames=[
        (:actin, [
            # Monomer states
            :FAD, # F-Actin in the ADP form
            :FADPi, # F-Actin in the ADP Pi form
            :FAT, # F-Actin in the ATP form
            :BarbedD, # Barbed end in the ADP form
            :BarbedDPi, # Barbed end in the ADP Pi form
            :BarbedT, # Barbed end in the ATP form
            :PointedD, # Pointed end in the ADP form
            :PointedDPi, # Pointed end in the ADP Pi form
            :PointedT, # Pointed end in the ATP form
        ])
    ]
)

s = MEDYAN.SysDef(agent_names)

DGActin = 5E6
for name in keys(s.diffusing)
    add_diffusion_coeff!(s, name, DGActin) # nm²/s
end

add_filament_params!(s, :actin, MEDYAN.ACTIN_FIL_PARAMS)

# Assume ATP, Pi, and ADP concentrations are fixed
ATP = 10000.0 * MEDYAN.μM⁻¹_per_nm³
Pi = 2000.0 * MEDYAN.μM⁻¹_per_nm³
ADP = 2000.0 * MEDYAN.μM⁻¹_per_nm³
KfGATPoint  = 0.0/MEDYAN.μM⁻¹_per_nm³
KrGATPoint  = 10.0
KfGADPoint  = 0.0/MEDYAN.μM⁻¹_per_nm³
KrGADPoint  = 10.0
KfGATBarb   = 10.0/MEDYAN.μM⁻¹_per_nm³
KrGATBarb   = 0.0
KfGADBarb   = 10.0/MEDYAN.μM⁻¹_per_nm³
KrGADBarb   = 0.0
KfPiRelease = 0.0026
KrPiRelease = 5.20E-6/MEDYAN.μM⁻¹_per_nm³

# 100
addreaction!(s,
    "diffusing.GADPi --> diffusing.GAD",
    0.0312,
    0,
)
addreaction!(s,
    "diffusing.GAD --> diffusing.GADPi",
    KrPiRelease*Pi,
    0,
)

# 104
addreaction!(s,
    "diffusing.GA --> diffusing.GAT",
    1.7/MEDYAN.μM⁻¹_per_nm³*ATP,
    0,
)
addreaction!(s,
    "diffusing.GAT --> diffusing.GA",
    0.011,
    0,
)

# 109
addreaction!(s,
    "diffusing.GA --> diffusing.GAD",
    0.9/MEDYAN.μM⁻¹_per_nm³*ADP,
    0,
)
addreaction!(s,
    "diffusing.GAD --> diffusing.GA",
    0.071,
    0,
)

monomerspacing=2.7 # nm


nucleotide_states = ("T", "DPi", "D")

# Barbed end polymerization and depolymerization
barbed_rates = [
    ("T", KfGATBarb, KrGATBarb),
    ("DPi", KfGATBarb, KrGATBarb),
    ("D", KfGADBarb, KrGADBarb),
]
for (new_nuc, forward_rate, reverse_rate) in barbed_rates
    for base_nuc in nucleotide_states
        addfilamentend_reaction!(s,
            :actin,
            Symbol("f", "GA", new_nuc, "_to_Barbed", base_nuc),
            false,
            [Symbol("Barbed", base_nuc)]=>[Symbol("FA", base_nuc), Symbol("Barbed", new_nuc)],
            monomerspacing,
            "diffusing.GA"*new_nuc*" -->",
            forward_rate,
            1,
        )
        addfilamentend_reaction!(s,
            :actin,
            Symbol("r", "GA", new_nuc, "_to_Barbed", base_nuc),
            false,
            [Symbol("FA", base_nuc), Symbol("Barbed", new_nuc)]=>[Symbol("Barbed", base_nuc)],
            0.0,
            "--> diffusing.GA"*new_nuc,
            reverse_rate,
            0,
        )
    end
end

# Pointed end polymerization and depolymerization
pointed_rates = [
    ("T", KfGATPoint, KrGATPoint),
    ("DPi", KfGATPoint, KrGATPoint),
    ("D", KfGADPoint, KrGADPoint),
]
for (new_nuc, forward_rate, reverse_rate) in pointed_rates
    for base_nuc in nucleotide_states
        addfilamentend_reaction!(s,
            :actin,
            Symbol("f", "GA", new_nuc, "_to_Pointed", base_nuc),
            true,
            [Symbol("Pointed", base_nuc)]=>[Symbol("Pointed", new_nuc), Symbol("FA", base_nuc)],
            monomerspacing,
            "diffusing.GA"*new_nuc*" -->",
            forward_rate,
            1,
        )
        addfilamentend_reaction!(s,
            :actin,
            Symbol("r", "GA", new_nuc, "_to_Pointed", base_nuc),
            true,
            [Symbol("Pointed", new_nuc), Symbol("FA", base_nuc)]=>[Symbol("Pointed", base_nuc)],
            0.0,
            "--> diffusing.GA"*new_nuc,
            reverse_rate,
            0,
        )
    end
end

# Filament ATP hydrolysis and Pi Dissociation
for monomer_state in ("FA", "Barbed", "Pointed")
    addfilament_reaction!(s,
        :actin,
        Symbol(monomer_state, "T_to_", monomer_state, "DPi"),
        [Symbol(monomer_state, "T")]=>[Symbol(monomer_state, "DPi")],
        1,
        "-->",
        0.3,
        0,
    )
    addfilament_reaction!(s,
        :actin,
        Symbol(monomer_state, "DPi_to_", monomer_state, "D"),
        [Symbol(monomer_state, "DPi")]=>[Symbol(monomer_state, "D")],
        1,
        "-->",
        KfPiRelease,
        0,
    )
    addfilament_reaction!(s,
        :actin,
        Symbol(monomer_state, "D_to_", monomer_state, "DPi"),
        [Symbol(monomer_state, "D")]=>[Symbol(monomer_state, "DPi")],
        1,
        "-->",
        KrPiRelease*Pi,
        0,
    )
end
s

vis = Visualizer()
setvisible!(vis["/Grid"], false)
setvisible!(vis["/Axes"], false)
setvisible!(vis["/Background"], false)

#system parameters
Lx = 1
Ly = 1
Lz = 3
lcell = 500
nsec = 10
dt = 0.01

#set up system and run for nsec seconds
nsubstep = Int(inv(dt))
grid = CubicGrid((Lx,Ly,Lz),lcell)
c = MEDYAN.Context(s, grid)
set_mechboundary!(c, MEDYAN.boundary_box(grid; stiffness=100.0))
adddiffusingcount_rand!(c, s.diffusing.GAT, 700)
monomerstates = [s.state.actin.PointedD, s.state.actin.FADPi, s.state.actin.FAT, s.state.actin.BarbedT]
nodepositions = [SA[0.0,0.0,0.0], SA[0.0,0.0,monomerspacing*length(monomerstates)]]
chem_newfilament!(c; monomerstates, nodepositions, node_mids=[1,])

for i in 1:nsec
    for j in 1:nsubstep
        run_chemistry!(c,dt)
        minimize_energy!(c)
        draw_context!(vis, c, s)
    end
end