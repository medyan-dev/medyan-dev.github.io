using Downloads
using GeometryBasics
using MEDYAN
using Meshes, MeshViz, WGLMakie
using FileIO
using StaticArrays
using Pkg.Artifacts

"Build mesh for halfedge mesh."
function build_mesh(ms::AbstractVector{<:MEDYAN.DynamicHalfedgeMesh})
    ps = Vector{Meshes.Point3}()
    fs = Vector{NTuple{3,Int}}()
    for m ∈ ms
        new_ps = map(eachindex(m.vertices)) do vi
            convert(Meshes.Point3, m.vertices.attr.coord[vi])
        end
        np_tillnow = length(ps)
        append!(ps, new_ps)
        new_fs = map(eachindex(m.triangles)) do ti
            t = MEDYAN.IT(ti)
            h = MEDYAN.halfedge(m, t)
            hn = MEDYAN.next(m, h)
            hp = MEDYAN.prev(m, h)
            vs = (MEDYAN.target(m,h).value, MEDYAN.target(m,hn).value, MEDYAN.target(m,hp).value)
            vs .+ np_tillnow
        end
        append!(fs, new_fs)
    end

    Meshes.SimpleMesh(ps, Meshes.connect.(fs, Meshes.Triangle))
end

"Build mesh for AABB tree."
function build_mesh(tree::MEDYAN.BinaryAABBTree)
    ps = Vector{Meshes.Point3}()
    fs = Vector{NTuple{4,Int}}()
    build_mesh_aabbtree_aux!(tree, 1, ps, fs)

    Meshes.SimpleMesh(ps, Meshes.connect.(fs, Meshes.Quadrangle))
end

function build_mesh_aabbtree_aux!(tree, nodeindex, ps, fs)
    node = tree.nodes[nodeindex]
    np_tillnow = length(ps)
    for dp ∈ 0:7
        point = convert(Meshes.Point3, node.offset + node.size .* (((1 .<< SA[0,1,2]) .& dp) .> 0))
        push!(ps, point)
    end
    push!(fs, (1,2,6,5) .+ np_tillnow)
    push!(fs, (2,4,8,6) .+ np_tillnow)
    push!(fs, (4,3,7,8) .+ np_tillnow)
    push!(fs, (3,1,5,7) .+ np_tillnow)
    push!(fs, (5,6,8,7) .+ np_tillnow)
    push!(fs, (2,1,3,4) .+ np_tillnow)

    if !MEDYAN.isleaf(node)
        build_mesh_aabbtree_aux!(tree, 2*nodeindex, ps, fs)
        build_mesh_aabbtree_aux!(tree, 2*nodeindex+1, ps, fs)
    end
end

function bunny_load()
    # Do not use lower resolution bunnies because many of them have non-manifold structure.
    load(joinpath(artifact"bunny", "bunny", "reconstruction", "bun_zipper.ply"))
end

function bunny_process(bunny_mesh)
    vertlist = map(GeometryBasics.coordinates(bunny_mesh)) do coord
        convert(SVector{3,Float64}, coord)
    end
    trilist = map(GeometryBasics.faces(bunny_mesh)) do face
        convert(SVector{3,Int}, face)
    end

    @info "Originally there are $(length(vertlist)) vertices and $(length(trilist)) triangles."
    # Remove unused vertices.
    (vertlist, trilist) = let
        local num_v_old = length(vertlist)
        local used = fill(false, num_v_old)
        local idx_map = collect(1:num_v_old)
    
        for eachf ∈ trilist
            for i ∈ eachf
                used[i] = true
            end
        end
    
        local vertlist_new = typeof(vertlist)()
        local trilist_new = typeof(trilist)()
        for i ∈ 1:num_v_old
            if used[i]
                push!(vertlist_new, vertlist[i])
                idx_map[i] = length(vertlist_new)
            end
        end
        for eachf ∈ trilist
            push!(trilist_new, map(x->idx_map[x], eachf))
        end
    
        (vertlist_new, trilist_new)
    end
    @info "After removing unused vertices, there are $(length(vertlist)) vertices and $(length(trilist)) triangles."

    # Build halfedge mesh.
    m = MEDYAN.create_membranemesh()
    MEDYAN.initmesh!(m, (; vertlist, trilist))
    @assert isempty(MEDYAN.fullcheck_mesh_consistency(m))
    @info "Halfedge mesh initialized: $m"
    # Adapt mesh.
    MEDYAN.adaptmesh!(MEDYAN.membranemesh_splitfunc!, MEDYAN.membranemesh_collapsefunc!, MEDYAN.membranemesh_flipfunc!, MEDYAN.membranemesh_relocfunc!, m, MEDYAN.MeshAdaptParams(
        max_size = 0.008,
        min_size = 0.001,
    ))
    @info "Mesh after adaptation: $m"

    # Create AABB tree for the mesh.
    tree = MEDYAN.build_aabbtree_frommeshes((m,))
    (; mesh=m, tree)
end

function bunny_visualize(m::MEDYAN.DynamicHalfedgeMesh, tree::MEDYAN.BinaryAABBTree)
    rayo = SA[0,0,0]
    rayd = SA[1,1,1]

    meshmesh = build_mesh(SA[m])
    treemesh = build_mesh(tree)

    v = MeshViz.viz(treemesh; showfacets=false)
    # MeshViz.viz!(v, treemesh)
end

function bunny()
    m, tree = bunny_process(bunny_load())
    bunny_visualize(m, tree)
end

bunny()


