using MEDYAN
using StaticArrays
using LinearAlgebra
using Random
using Setfield
using SmallZarrGroups




"""
Add a filament with type id `ftid` to the Context with random center position in compartment cid and direction.

Return the filament id of a new filament.

`monomerstates` is a collection of the `MonomerState` of the monomers in the new filament.

The filament will be inside the mech boundary.

returns false if it fails to add a filament.
returns the new filament id if succeeds

The monomer are spaced by the value in the filament type's mechanical parameters.
"""
function nucleate_filament!(c::MEDYAN.Context, cid, monomerstates; iterations = 10^9, ftid = 1)
	#get random position in grid
    for i in 1:iterations
        center = MEDYAN.randompoint(c.grid,cid)
        dir = normalize(randn(SVector{3,Float64}))
        n = length(monomerstates)
        spacing = c.filamentmechparams[ftid].spacing
        L = n*spacing
        startpos = center - (L/2)*dir
        endpos = center + (L/2)*dir

        inside = MEDYAN.insideboundary(c.mechboundary,startpos) && MEDYAN.insideboundary(c.mechboundary,endpos)
        if inside
            node_mids = [0,]
            nodepositions = [startpos,endpos]
            return MEDYAN.chem_newfilament!(c;
                ftid,
                monomerstates,
                node_mids,
                nodepositions
            )
        end
    end
    return false
end



"""
Return the context and sysdef
"""
function setup( ;seed = 1234, numFilaments = 300)
    Random.seed!(seed)
    agentnames = MEDYAN.AgentNames(
        diffusingspeciesnames= [
            :A, # actin
            :MD, # motor
            :LD, # crosslinker
            :BD, # brancher
            :FO, # formin
            :FOA, # formin actin nucleation intermediate
        ],
        fixedspeciesnames= [
            :branchingfactor, # set to zero to prevent branching, set to one to enable branching in a chemistry voxel.
        ],
        filamentnames= [(:actin,[
                                :AF, # middle actin
                                :PA, # plus end actin
                                :FP, # plus end formin
                                :MA, # minus end actin
                                :freeARP23, #arp23 on minus end of detached daughter filament
                                :boundARP23, #arp23 on minus end of attached daughter filament
                                :bound, # general bound actin
                            ]),
        ],
        link_2mon_names= [
            :motor,
            :crosslinker,
            :brancher,
        ]
    )
    height = 400.0 # nm
    grid = CubicGrid((10,10,1),400.0)
    # make cylinder boundary 2000.0 nm radius
    chemboundary = MEDYAN.boundary_cylinder(;
        center=MEDYAN.centerof(grid),
        axis=SA[0,0,height],
        radius=2000.0,
    )
    # offset chemboundary by 10.0 nm
    mechboundoffset = 10.0
    mechboundary = MEDYAN.boundary_cylinder(;
        center=MEDYAN.centerof(grid),
        axis=SA[0,0,height-2mechboundoffset],
        radius=2000.0-mechboundoffset,
        stiffness=100.0,
    )
    # add reactions
    monomerspacing = MEDYAN.ACTIN_FIL_PARAMS.spacing # nm
    begin
        s= MEDYAN.SysDef(agentnames)

        add_diffusion_coeff!(s, :A,   100.0*0.25E6)
        add_diffusion_coeff!(s, :MD,  1.0*0.25E6  )
        add_diffusion_coeff!(s, :LD,  10.0*0.25E6 )
        add_diffusion_coeff!(s, :BD,  100.0*0.25E6)
        add_diffusion_coeff!(s, :FO,  10.0*0.25E6 )
        add_diffusion_coeff!(s, :FOA, 0.1*0.25E6  )

        add_filament_params!(s, 
            :actin,
            MEDYAN.ACTIN_FIL_PARAMS,
        )

        add_link_2mon!(s,
            :motor,
            Link2MonState((numHeads=20,),(L0=NaN,)),
            MEDYAN.DistanceRestraintMechParams(k=55.0),
        )
        
        add_link_2mon!(s,
            :crosslinker,
            Link2MonState((;),(L0=NaN,)),
            MEDYAN.DistanceRestraintMechParams(k=8.0),
        )

        add_link_2mon!(s,
            :brancher,
            Link2MonState((;),(;)),
            MEDYAN.RelativeRestraintMechParams(kr=5.0,kv̂=5.0, pr0_mvxmpr= SA[0.0,2.7,0.0], pv̂0_mvxmpr=SA[cos(1.22),sin(1.22),0.0]);
            no_collide=true,
        )
        
        #polymerization
        addfilamentend_reaction!(s, :actin, :pp, false,
            [:PA]=>[:AF,:PA], monomerspacing,
            "diffusing.A -->", 0.3852*1E8, 1,
        )
        addfilamentend_reaction!(s, :actin, :mp, true,
            [:MA]=>[:MA,:AF], monomerspacing,
            "diffusing.A -->", 0.0216*1E8, 1,
        )
        # addfilamentend_reaction!(s, :actin, :pfp, false,
        #     [:FP]=>[:AF,:FP], monomerspacing,
        #     "diffusing.A -->", 0.3852*1E8, 1,
        # )

        #depolymerization
        addfilamentend_reaction!(s, :actin, :dpp, false,
            [:AF,:PA]=>[:PA], 0.0,
            "--> diffusing.A", 1.4, 0,
        )
        #minus end depolymerization
        addfilamentend_reaction!(s, :actin, :dmp, true,
            [:MA,:AF]=>[:MA], 0.0,
            "--> diffusing.A", 1.6, 0,
        )

        motorstepsize = 10

        #motor binding
        site = MEDYAN.Decimated2MonSiteMinAngleRange(
            s.filament.actin,
            s.filament.actin,
            motorstepsize,
            motorstepsize,
            s.state.actin.AF,
            s.state.actin.AF,
            175.0,
            225.0,
            cos(5*π/180),
        )
        add_decimated_2mon_site!(s,:motorbinding,site)
        bindcallback = MEDYAN.SimpleMotorBindCallback(
            s.decimated_2mon_site.motorbinding.id,
            s.link_2mon.motor,
            30, #max number of heads
            15, #min number of heads
            s.state.actin.bound,
            [s.diffusing.MD=>-1],
        )
        addreactioncallback!(
            s,
            "decimated_2mon_site.motorbinding + diffusing.MD",
            0.2*22*500^3/2,
            1,
            bindcallback,
        )

        #motor unbinding
        site = MEDYAN.Link2MonSiteMotorCatch()
        addunbindinglink_2mon_site!(s, 
            :motor, :unbinding, site,
            :actin, :AF, :actin, :AF,
            "--> diffusing.MD", 1.0, 0, 
        )

        #motor stepping
        onrate = 0.2
        offrate = 1.7
        dutyratio = onrate/(onrate+offrate)
        site1 = MEDYAN.Link2MonSiteMotorStall(
            fs = 90.0,
            k0 = 6.0/(108/4)*((1 - dutyratio) / dutyratio) * onrate,
            isminusend = true,
        )
        site2 = @set site1.isminusend = false
        add_link_2mon_site!(s,:motor,:motorstepminus,site1)
        add_link_2mon_site!(s,:motor,:motorstepplus,site2)
        stepcallback1 = MEDYAN.SimpleMotorStepCallback(
            lsid = s.link_2mon_site.motor.motorstepminus.id,
            ltid = s.link_2mon.motor,
            unboundstate = s.state.actin.AF,
            boundstate = s.state.actin.bound,
            stepsize = motorstepsize,
        )
        stepcallback2 = @set stepcallback1.lsid = s.link_2mon_site.motor.motorstepplus.id
        addreactioncallback!(
            s,
            "link_2mon_site.motor.motorstepminus",
            1.0,
            0,
            stepcallback1,
        )
        addreactioncallback!(
            s,
            "link_2mon_site.motor.motorstepplus",
            1.0,
            0,
            stepcallback2,
        )

        #crosslinker binding site
        site = MEDYAN.Decimated2MonSiteMinAngleRange(
            s.filament.actin,
            s.filament.actin,
            10,
            10,
            s.state.actin.AF,
            s.state.actin.AF,
            30.0,
            40.0,
            cos(5*π/180)
        )
        add_decimated_2mon_site!(s,:crosslinkbinding,site)
        sitecallback = MEDYAN.SimpleCrosslinkBindCallback(
            s.decimated_2mon_site.crosslinkbinding.id,
            s.link_2mon.crosslinker,
            s.state.actin.bound,
            [s.diffusing.LD=>-1],
        )
        addreactioncallback!(s,
            "decimated_2mon_site.crosslinkbinding + diffusing.LD",
            0.01*500^3/2,
            1,
            sitecallback,
        )

        #crosslinker unbinding
        site = MEDYAN.Link2MonSiteSlipBond(f0 = inv(0.24*MEDYAN.default_β) , k0 = 0.3)
        addunbindinglink_2mon_site!(s, 
            :crosslinker, :unbinding, site,
            :actin, :AF, :actin, :AF,
            "--> diffusing.LD", 1.0, 0, 
        )



        # Nucleation by formin
        #1. Generate the intermediate reactant FOA
        MEDYAN.addreaction!(s, "diffusing.A + diffusing.FO --> diffusing.FOA", 0.005*1E8, 1)
        #2. Generate new filament, assume to be fast
        formin_nucleation_callback = let 
            local monomerstates = [s.state.actin.MA,s.state.actin.AF,s.state.actin.FP]
            local ftid = s.filament.actin
            local diffusingids = (s.diffusing.A, s.diffusing.FOA)
            """
            Nucleate a filament
            """
            function formin_nucleation_callback(c::MEDYAN.Context,cid)
                result = nucleate_filament!(c, cid, monomerstates; iterations = 10^6, ftid)
                if result === false
                    return false
                else
                    # now remove diffusing species
                    for sid in diffusingids
                        chem_adddiffusingcount!(c, sid, cid, -1)
                    end
                    return true
                end
            end
        end
        MEDYAN.addreactioncallback!(s, "diffusing.A + diffusing.FOA", 1.0*1E8, 1, formin_nucleation_callback)
        #3. Formin dissociation, rate constant source 2016Fritzsche
        MEDYAN.addfilamentend_reaction!(
            s,
            :actin,
            :formin_end,
            false,
            [:AF, :FP] => [:PA],
            0.0,
            "--> diffusing.FO", 0.01, 0
        )

        #Destruction
        addfilamentendsite!(s,:actin,:destroy_actin_fil,
            MEDYAN.FilamentEndSiteGeneral(false,[s.state.actin.MA,s.state.actin.PA],0.0)
        )
        MEDYAN.addreactioncallback!(s, "filamentendsite.actin.destroy_actin_fil", 1.5, 0,
            MEDYAN.FilamentDestructionCallback(s.filament.actin, s.filamentendsite.actin.destroy_actin_fil.id, [s.diffusing.A=>2])
        )
        addfilamentendsite!(s,:actin,:destroy_actin_formin_fil,
            MEDYAN.FilamentEndSiteGeneral(false,[s.state.actin.MA,s.state.actin.FP],0.0)
        )
        MEDYAN.addreactioncallback!(s, "filamentendsite.actin.destroy_actin_formin_fil", 1.5, 0,
            MEDYAN.FilamentDestructionCallback(s.filament.actin, s.filamentendsite.actin.destroy_actin_formin_fil.id, [s.diffusing.A=>1, s.diffusing.FOA=>1])
        )
        addfilamentendsite!(s,:actin,:destroy_actin_arp23_fil,
            MEDYAN.FilamentEndSiteGeneral(false,[s.state.actin.freeARP23,s.state.actin.PA],0.0)
        )
        MEDYAN.addreactioncallback!(s, "filamentendsite.actin.destroy_actin_arp23_fil", 1.5, 0,
            MEDYAN.FilamentDestructionCallback(s.filament.actin, s.filamentendsite.actin.destroy_actin_arp23_fil.id, [s.diffusing.A=>1, s.diffusing.BD=>1])
        )

        #branching site
        site = MEDYAN.FilamentSiteGeneral(2,fill(s.state.actin.AF,3))
        addfilamentsite!(s, :actin, :branch, site)
        sitecallback = MEDYAN.GeneralFilamentSiteCallback(
            s.filament.actin,
            s.filamentsite.actin.branch.id,
            1,
            [s.state.actin.bound],
            [],
        )
        branchcallback = MEDYAN.FilamentSiteBranchingCallback(
            sitecallback,
            s.link_2mon.brancher,
            s.filament.actin,
            true,
            true,
            [s.state.actin.boundARP23,s.state.actin.PA],
            [s.diffusing.A=>-1, s.diffusing.BD=>-1],
        )
        addreactioncallback!(s,
            "filamentsite.actin.branch + diffusing.A + diffusing.BD + fixedspecies.branchingfactor",
            0.0001*1E8*1E8,
            2,
            branchcallback,
        )
        #brancher unbinding
        site = MEDYAN.Link2MonSiteSlipBond(f0 = inv(0.24*MEDYAN.default_β) , k0 = 0.01)
        addunbindinglink_2mon_site!(s, 
            :brancher, :unbinding, site,
            :actin, :freeARP23, :actin, :AF,
            "-->", 1.0, 0, 
        )
        

    end
    c= MEDYAN.Context(s,grid;
        g_tol=1.0,
        max_cylinder_force = 2000.0,
        maxstep = 0.7,
    )
    set_chemboundary!(c, chemboundary)
    set_mechboundary!(c, mechboundary)

    # add branchingfactor so branching can only take place near the curved side.
    for cid in 1:length(grid)
        if norm(MEDYAN.centerof(grid,cid)[1:2] - MEDYAN.centerof(grid)[1:2]) > 1500
            chem_addfixedcount!(c,s.fixedspecies.branchingfactor,cid,1)
        end
    end

    #add initial filaments
    numinitmonomers = 9*40
    initmonomerstates = fill(s.state.actin.AF, numinitmonomers)
    initmonomerstates[begin] = s.state.actin.MA
    initmonomerstates[end] = s.state.actin.PA
    filamentCounter = 0
    while filamentCounter < numFilaments
        # rand filament parallel to the xy plane.
        # must be more than 125 nm away from boundary.
        # must be within 1000 nm of the cylinder curved side.
        #get random position in grid
        local center = MEDYAN.randompoint(c.grid)
        local dir = [normalize(randn(SVector{2,Float64})); 0.0]
        local n = length(initmonomerstates)
        local spacing = c.filamentmechparams[s.filament.actin].spacing
        local L = n*spacing
        local startpos = center - (L/2)*dir
        local endpos = center + (L/2)*dir
        function isinside(x)
            (
                abs(x[3] - MEDYAN.centerof(grid)[3]) < height/2-125 &&
                norm(x[1:2] - MEDYAN.centerof(grid)[1:2]) < 2000-125 &&
                norm(x[1:2] - MEDYAN.centerof(grid)[1:2]) > 1000
            )
        end
        if isinside(startpos) && isinside(endpos)
            local node_mids = [0,]
            local nodepositions = [startpos,endpos]
            MEDYAN.chem_newfilament!(c;
                ftid = s.filament.actin,
                monomerstates = initmonomerstates,
                node_mids,
                nodepositions,
            )
            filamentCounter += 1
        end
    end

    #add initial diffusing species
    adddiffusingcount_rand!(c,s.diffusing.A,85560)
    adddiffusingcount_rand!(c,s.diffusing.FO,50)

    return c,s
end


function run(;seed = 1234, numFilaments = 300, frames=30000)
    c,s = setup(;seed, numFilaments)
    MEDYAN.minimize_energy!(c)
    for i in 1:frames
        MEDYAN.run_chemistry!(c,0.005)
        MEDYAN.minimize_energy!(c)
        @show i
    end
    SmallZarrGroups.save_zip("ring_system.zarr.zip", MEDYAN.snapshot(c))
    return c, s
end

function load_group()
    SmallZarrGroups.load_dir(joinpath(dirname(@__DIR__), "test", "ring_system.zarr"))
end

function rerun(group ;seed=1234, frames=10)
    c,s = setup(;numFilaments=0)
    Random.seed!(seed)
    MEDYAN.load_snapshot!(c, group)
    MEDYAN.minimize_energy!(c)
    for i in 1:frames
        MEDYAN.run_chemistry!(c,0.005)
        MEDYAN.minimize_energy!(c)
        @show i
    end 
    return c, s
end