using MEDYAN

"""
Return a tuple of a Vector length samples of the total count of A in the system,
    and a count of the number of reaction steps
TotalA and TotalB are the total counts of A and B at the start
"""
function sampleAtraj(TotalA, TotalB, samples)
    agentnames = MEDYAN.AgentNames(diffusingspeciesnames = [:a, :b, :c])
    s = MEDYAN.SysDef(agentnames)
    k1 = 0.02
    k2 = 0.1
    addreaction!(s, "diffusing.a + diffusing.b --> diffusing.c", k1, 1)
    addreaction!(s, "diffusing.c --> diffusing.a + diffusing.b", k2, 0)
    
    add_diffusion_coeff!(s, :a, 10.0)
    add_diffusion_coeff!(s, :b, 10.0)
    add_diffusion_coeff!(s, :c, 10.0)
    
    K = 10 #length of compartmentgrid in number of compartments
    h = 0.5 #side length of compartments
    grid = CubicGrid((K, K, K), h)

    c = MEDYAN.Context(
        s,
        grid;
        rdmesamplertype = MEDYAN.RDMEPropensityRejectDiffusion,
    )

    MEDYAN.adddiffusingcount_rand!(
        c,
        s.diffusing.a,
        TotalA,
    )
    MEDYAN.adddiffusingcount_rand!(
        c,
        s.diffusing.b,
        TotalB,
    )


    totalAarray = zeros(Int, samples)
    reactioncount = 0
    Δt = 0.1
    for i = 1:samples
        #println(i)
        MEDYAN.run_chemistry!(c, Δt)
        totalAarray[i] = sum(
            MEDYAN.getdiffusingspeciescount.(
                Ref(c),
                1:length(grid),
                Ref(s.diffusing.a),
            ),
        )
    end
    (totalAarray, reactioncount)
end
