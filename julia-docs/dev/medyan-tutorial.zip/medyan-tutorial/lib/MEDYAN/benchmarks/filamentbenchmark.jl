using MEDYAN
using StaticArrays

"""
Return a tuple of a Vector length samples of the total count of A in the system,
    and a count of the number of reaction steps
TotalA  is the total counts of A at the start
"""
function sampleAtraj(TotalA, samples)
    agentnames = MEDYAN.AgentNames(
    	diffusingspeciesnames= [:a,],
    	filamentnames= [(:actin,[
                                :plusend,
                                :minusend,
                                :middle,
    							:restrained,
                            ]),
    	],
    	link_2mon_names= [:restraint,]
    )
    grid= CubicGrid((3,1,1),500.0)

    monomerspacing= 2.7

    s= MEDYAN.SysDef(agentnames)
    add_link_2mon!(s,
		:restraint,
		Link2MonState((;),(mr0 = zero(SVector{3,Float64}),mv̂0 = zero(SVector{3,Float64}))),
		MEDYAN.RestraintMechParams(kr=5.0,kv̂=2.0),
	)
	add_filament_params!(s, :actin, MEDYAN.ACTIN_FIL_PARAMS)
	add_diffusion_coeff!(s, :a, 1.0)
	#minus end polymerization
	addfilamentend_reaction!(s,
		:actin, #filament type name
		:pm, #new site name
		true, #is minus end
		[:minusend]=>[:minusend,:middle], #change in monomer states
		monomerspacing, #free space needed for reaction (nm)
		"diffusing.a -->", #reaction expression
		10E3, #rate of reaction ((nm^3)^(invvolumepower)/s)
		1, #inverse volume power
	)
	#plus end polymerization
	addfilamentend_reaction!(s, :actin, :pp, false,
		[:plusend]=>[:middle,:plusend], monomerspacing,
		"diffusing.a -->", 10E3, 1,
	)
	#minus end depolymerization
	addfilamentend_reaction!(s, :actin, :dpm, true,
		[:minusend,:middle]=>[:minusend], 0.0,
		"--> diffusing.a", 1.75E-3, 0,
	)
	#plus end depolymerization
	addfilamentend_reaction!(s, :actin, :dpp, false,
		[:middle,:plusend]=>[:plusend], 0.0,
		"--> diffusing.a", 1.75E-3, 0,
	)

	NMonomers= 30
	monomerstates= zeros(UInt8,NMonomers)
	monomerstates[1:end] .= s.state.actin.middle
	monomerstates[1] = s.state.actin.restrained
	monomerstates[end] = s.state.actin.plusend
	node_mids = [1,]
	nodepositions = [SA[200.0,200.0,200.0],
						SA[200.0+NMonomers*monomerspacing,200.0,200.0]]

	c= MEDYAN.Context(s,grid;)
	set_mechboundary!(c, MEDYAN.boundary_box(grid; stiffness=0.01^2))
	adddiffusingcount_rand!(c, s.diffusing.a, TotalA)
	fid1= MEDYAN.chem_newfilament!(c;
		ftid= s.filament.actin,
		monomerstates,
		node_mids,
		nodepositions
	)
	fid2= MEDYAN.chem_newfilament!(c;
		ftid= s.filament.actin,
		monomerstates,
		node_mids,
		nodepositions= nodepositions .+ (SA[0.0,100.0,100.0],),
	)
	eqrv = mon_position_plusvector(c, MonomerName(1, fid1, 1))
	MEDYAN.chem_newlink_2mon!(c,
		s.link_2mon.restraint,#ltid
		MonomerName(s.filament.actin, fid1, 1)=>
		MonomerName(s.filament.actin, fid1, 1);
		changedmechstate = (mr0 = eqrv[1], mv̂0 = eqrv[2]),
	)

	totalAarray = zeros(Int, samples)
	for i in 1:samples
		for j in 1:10
			MEDYAN.run_chemistry!(c,2.0)
			MEDYAN.minimize_energy!(c)
		end
		for cid in 1:length(grid)
			totalAarray[i] += MEDYAN.getdiffusingspeciescount(
	                c,
	                cid,
	                s.diffusing.a,)
		end
		for fil_id in filtype_fil_ids(c, s.filament.actin)
			totalAarray[i] += length(fil_mon_states(c, s.filament.actin, fil_id))
		end
	end
    totalAarray
end
