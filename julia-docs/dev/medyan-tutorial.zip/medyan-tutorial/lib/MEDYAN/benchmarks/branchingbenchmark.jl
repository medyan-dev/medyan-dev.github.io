using MEDYAN
using StaticArrays
using Dictionaries
using LineSearches

"""
Return a tuple of a Vector length samples of the total count of A in the system,
    and a count of the number of reaction steps
TotalA  is the total counts of A at the start
"""
function sampleAtraj(TotalA, samples)
    agentnames = MEDYAN.AgentNames(
	diffusingspeciesnames= [:a,],
	filamentnames= [(:actin,[
                                :plusend,
                                :minusend,
                                :middle,
                                :oldbranch,
                                :newbranch,
                            ]),
        ],
        link_2mon_names= [:branch,]
    )
    grid= CubicGrid((3,1,1),500.0)

    boundingplanes = 1.0 .* [SA[-1.0,0.0,0.0,0.0],
    	SA[1.0,0.0,0.0,1500],
    	SA[0.0,-1.0,0.0,0.0],
    	SA[0.0,1.0,0.0,500],
    	SA[0.0,0.0,-1.0,0.0],
    	SA[0.0,0.0,1.0,500]
    ]

    monomerspacing= 2.7

    begin
        s= MEDYAN.SysDef(agentnames)
        #define restraints

        add_diffusion_coeff!(s, :a, 1.0)

        add_link_2mon!(s,
            :branch,
            nothing,
            MEDYAN.RelativeRestraintMechParams(kr=1.0,kv̂=10.0, pr0_mvxmpr= SA[0.0,2.7,0.0], pv̂0_mvxmpr=SA[0.0,1.0,0.0]),
            nothing)

        #plus end polymerization
        addfilamentend_reaction!(s, :actin, :pp, false,
            [:plusend]=>[:middle,:plusend], monomerspacing,
            "diffusing.a -->", 10E3, 1,
        )
        #plus end depolymerization
        addfilamentend_reaction!(s, :actin, :dpp, false,
            [:middle,:plusend]=>[:plusend], 0.0,
            "--> diffusing.a", 1.75E-3, 0,
        )

        #branching site
        site = MEDYAN.FilamentSiteGeneral(2,fill(s.state.actin.middle,3))
        addfilamentsite!(s, :actin, :branch, site)
        sitecallback = MEDYAN.GeneralFilamentSiteCallback(
            s.filament.actin,
            s.filamentsite.actin.branch.id,
            1,
            [s.state.actin.oldbranch],
            [],
        )
        branchcallback = MEDYAN.FilamentSiteBranchingCallback(
            sitecallback,
            s.link_2mon.branch,
            s.filament.actin,
            true,
            true,
            [s.state.actin.newbranch,s.state.actin.plusend],
            [s.diffusing.a=>-1],
        )
        addreactioncallback!(s,
            "filamentsite.actin.branch + diffusing.a",
            0.001E3,
            1,
            branchcallback,
        )
    end


	begin
        NMonomers= 30
        monomerstates= zeros(UInt8,NMonomers)
        monomerstates[1:end] .= s.state.actin.middle
        monomerstates[1] = s.state.actin.minusend
        monomerstates[end] = s.state.actin.plusend
        node_mids = [0,]
        nodepositions = [SA[200.0,200.0,200.0],
                         SA[200.0+NMonomers*monomerspacing]]
        filamentmechparams= [MEDYAN.ACTIN_FIL_PARAMS]
    end

	c= MEDYAN.Context(s,grid;
		filamentmechparams,
    )
    set_mechboundary!(c; planes=boundingplanes)
	adddiffusingcount_rand!(c, s.diffusing.a, TotalA)
	fid1= MEDYAN.chem_newfilament!(c;
		ftid= s.filament.actin,
		monomerstates,
		node_mids,
		nodepositions
	)

	totalAarray = zeros(Int, samples)
	for i in 1:samples
		@show i
		for j in 1:10
			MEDYAN.run_chemistry!(c,1.0)
			MEDYAN.minimize_energy!(c)
		end
		for cid in 1:length(grid)
			totalAarray[i] += MEDYAN.getdiffusingspeciescount(
	                c,
	                cid,
	                s.diffusing.a,)
		end
		for fil_id in filtype_fil_ids(c, s.filament.actin)
			totalAarray[i] += length(fil_mon_states(c, s.filament.actin, fil_id))
		end
	end
    totalAarray
end
