using MEDYAN
using StaticArrays
using LinearAlgebra
using ForwardDiff

function cylinder_repulsion9(P0,P1,Q0,Q1,kr)
    P = P1-P0
    Q = Q1-Q0
    P0mQ0 = P0 - Q0
    a = P ⋅ P
    b = P ⋅ Q
    c = Q ⋅ Q
    d = P ⋅ P0mQ0
    e = Q ⋅ P0mQ0
    f = P0mQ0 ⋅ P0mQ0
    Δ = a*c - b^2
    #assuming both segments are not zero length
    #critical points
    s0 = clamp(-d/a,0,1)
    s1 = clamp((b-d)/a,0,1)
    t0 = clamp(e/c,0,1)
    t1 = clamp((b+e)/c,0,1)
    sbar = clamp((b*e - c*d)/(Δ+eps(one(Δ))),0,1)
    tbar = clamp((a*e - b*d)/(Δ+eps(one(Δ))),0,1)
    r(s,t) = a*s^2 - 2b*s*t + c*t^2 + 2d*s - 2e*t
    cl = max(0,f+min(
        r(s0,0),
        r(s1,1),
        r(0,t0),
        r(1,t1),
        r(sbar,tbar),
    ))
    switchover = tanh(Δ/sqrt(a*c)*(0.1f0))
    u(distsq) = 1//2*max(0,1-sqrt(distsq)*kr)^2
    E = switchover*u(cl) + 1//2*(1-switchover)*sum(u,(
        f+r(s0,0),
        f+r(s1,1),
        f+r(0,t0),
        f+r(1,t1),
    ))
    return E
end

"""
Add cylinder volume exclusion forces to forces and energies.
Uses the closest approach point
x is the dof
"""
function oldcylinderforce!(forces,energies,x,neighborlist)
    posvect = reinterpret(SVector{3,eltype(x)},x)
    forcesvect = reinterpret(SVector{3,eltype(forces)},forces)
    for edge::MEDYAN.CylinderEdge in neighborlist
        #load positions
        P0, P1 = posvect[edge.id1],posvect[edge.id1+1]
        Q0, Q1 = posvect[edge.id2],posvect[edge.id2+1]
        vectorf(xflat) = cylinder_repulsion9(
            xflat[StaticArrays.SUnitRange(1,3)],
            xflat[StaticArrays.SUnitRange(4,6)],
            xflat[StaticArrays.SUnitRange(7,9)],
            xflat[StaticArrays.SUnitRange(10,12)],
            edge.kr)
        xflat0 = vcat(P0,P1,Q0,Q1)
        u = edge.ke * vectorf(xflat0)
        if u > 0
            g = -edge.ke * ForwardDiff.gradient(vectorf, xflat0)
            # store forces
            forces[3edge.id1-2:3edge.id1+3] .+= g[StaticArrays.SUnitRange(1,6)]
            forces[3edge.id2-2:3edge.id2+3] .+= g[StaticArrays.SUnitRange(7,12)]
            #store energy at id1
            energies[edge.id1] += u
        end
    end
end

function newcylinderforce!(forces,energies,x,neighborlist)
    posvect = reinterpret(SVector{3,eltype(x)},x)
    forcesvect = reinterpret(SVector{3,eltype(forces)},forces)
    switchover_scale = 0.1 # units of 1/nm
    for edge in neighborlist
        kr = edge.kr
        ke = edge.ke
        #load positions
        P0, P1 = posvect[edge.id1],posvect[edge.id1+1]
        Q0, Q1 = posvect[edge.id2],posvect[edge.id2+1]
        P = P1-P0
        Q = Q1-Q0
        P0mQ0 = P0 - Q0
        a = P ⋅ P
        b = P ⋅ Q
        c = Q ⋅ Q
        d = P ⋅ P0mQ0
        e = Q ⋅ P0mQ0
        f = P0mQ0 ⋅ P0mQ0
        Δ = a*c - b^2
        #assuming both segments are not zero length
        #critical points
        s0 = clamp(-d/a,0,1)
        s1 = clamp((b-d)/a,0,1)
        t0 = clamp(e/c,0,1)
        t1 = clamp((b+e)/c,0,1)
        sbar = clamp((b*e - c*d)/(Δ+eps(one(Δ))),0,1)
        tbar = clamp((a*e - b*d)/(Δ+eps(one(Δ))),0,1)
        r(s,t) = a*s^2 - 2b*s*t + c*t^2 + 2d*s - 2e*t
        mins = sbar
        mint = tbar
        minr = r(sbar,tbar)
        if  r(s0,0) < minr
            minr = r(s0,0)
            mins = s0
            mint = 0
        end
        if  r(s1,1) < minr
            minr = r(s1,1)
            mins = s1
            mint = 1
        end
        if  r(0,t0) < minr
            minr = r(0,t0)
            mins = 0
            mint = t0
        end
        if  r(1,t1) < minr
            minr = r(1,t1)
            mins = 1
            mint = t1
        end
        d2cl = max(0,f+minr)
        if d2cl < inv(kr)^2
            #return the energy and force on each point give s and t
            function u_f(s,t)
                local Pcl = P0 + s*P
                local Qcl = Q0 + t*Q
                local Rcl = Qcl - Pcl
                local distsq = Rcl ⋅ Rcl
                local dist = sqrt(distsq)
                local u = 1//2*max(0,1-dist*kr)^2
                local d_u_d_dist = -kr*max(0,1-dist*kr)
                local FP = Rcl/dist * d_u_d_dist
                (u, s*FP, -(1-t)*FP, -t*FP)
            end
            switchover = tanh(Δ/sqrt(a*c)*switchover_scale)
            #P0 is set as origin for now, subtract forces later to get final fp0
            ucl, fp1cl, fq0cl, fq1cl = u_f(mins,mint)
            us0, fp1s0, fq0s0, fq1s0 = u_f(s0,0)
            us1, fp1s1, fq0s1, fq1s1 = u_f(s1,1)
            ut0, fp1t0, fq0t0, fq1t0 = u_f(0,t0)
            ut1, fp1t1, fq0t1, fq1t1 = u_f(1,t1)
            uother = +(
                us0,
                us1,
                ut0,
                ut1,
            )
            fp1other = +(
                fp1s0,
                fp1s1,
                fp1t0,
                fp1t1,
            )
            fq0other = +(
                fq0s0,
                fq0s1,
                fq0t0,
                fq0t1,
            )
            fq1other = +(
                fq1s0,
                fq1s1,
                fq1t0,
                fq1t1,
            )
            u = switchover*ucl + 1//2*(1-switchover)*uother
            p = sqrt(a)
            q = sqrt(c)
            g = b/(p*q)
            uswitched = (ucl + -1//2*uother)
            fp1 = switchover*fp1cl + 1//2*(1-switchover)*fp1other
            d_switchover_dp1 = -switchover_scale*(1-switchover^2)*((q/p+b*g/a)*P - 2*g*Q)
            fp1 += d_switchover_dp1*uswitched

            fq0 = switchover*fq0cl + 1//2*(1-switchover)*fq0other
            fq1 = switchover*fq1cl + 1//2*(1-switchover)*fq1other
            d_switchover_dq0 = switchover_scale*(1-switchover^2)*((p/q+b*g/c)*Q - 2*g*P)
            d_switchover_dq1 = - d_switchover_dq0
            fq0 += d_switchover_dq0*uswitched
            fq1 += d_switchover_dq1*uswitched

            forcesvect[edge.id1] -= ke*(fp1+fq0+fq1)
            forcesvect[edge.id1+1] += ke*fp1

            forcesvect[edge.id2] += ke*fq0
            forcesvect[edge.id2+1] += ke*fq1

            energies[edge.id1] += u*ke
        end
    end
end

N = 10000
x = 1E3 .* rand(3*N)




nl = Vector{MEDYAN.CylinderEdge}()
points = reinterpret(SVector{3,eltype(x)},x)
extra_cutoff = 1.0
r = 3.0
for i in 1:(N-2)
    for j in i+2:(N-1)
        cutoff = extra_cutoff + r + r
        i0 = points[i]
        i1 = points[i+1]
        j0 = points[j]
        j1 = points[j+1]
        d2 = MEDYAN.linesegment_linesegment_dist2(i0,i1,j0,j1)
        if d2 ≤ cutoff^2 && d2 > 0.1 # ignore if dist too small 
            kr = inv(r + r)
            push!(nl,MEDYAN.CylinderEdge(i,j,kr,100.0/kr))
        end
    end
end

# @show length(nl)
oldf = zero(x)
newf = zero(x)

olde = zeros(N)
newe = zeros(N)
@time oldcylinderforce!(oldf,olde,x,nl)
@time newcylinderforce!(newf,newe,x,nl)
@time oldcylinderforce!(oldf,olde,x,nl)
@time newcylinderforce!(newf,newe,x,nl)

@show maximum(abs,olde-newe)


@show maximum(abs,oldf-newf)
@show maximum(abs,newf)