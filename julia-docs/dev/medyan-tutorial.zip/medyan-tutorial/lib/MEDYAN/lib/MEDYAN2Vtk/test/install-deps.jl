#!/bin/env julia
using Pkg: Pkg, PackageSpec
Pkg.activate(@__DIR__)
root = relpath(dirname(@__DIR__))
Pkg.develop([
    PackageSpec(path=root),
    PackageSpec(path=root*"/../.."), # MEDYAN
])
Pkg.instantiate()
# Pkg.build()