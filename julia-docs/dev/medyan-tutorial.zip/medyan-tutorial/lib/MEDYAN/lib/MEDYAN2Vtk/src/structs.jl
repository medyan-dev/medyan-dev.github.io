
struct Monomer
    state::UInt8
    pos::SVector{3,Float32}
    plusvec::SVector{3,Float32}
end

Base.@kwdef struct FilamentData
    monomers::Dictionary{Int,OffsetVector{Monomer, Vector{Monomer}}} = Dictionary()
    node_pos::Vector{SVector{3,Float32}} = []
    node_bend_angles::Vector{Float32} = [] # in radians, 0 is no bend.
    fil_node_ids::Dictionary{Int,UnitRange{Int64}} = Dictionary()
end

Base.@kwdef struct MembraneData
    type_id::Int
    trilist::Vector{SVector{3,Int32}} = []
    vert_coords::Vector{SVector{3,Float32}} = []
    vert_copynumbers::Union{ElasticMatrix{Int32}, Nothing} = nothing
end


Base.@kwdef struct Link2MonData
    end_pos::Vector{SVector{2,SVector{3,Float32}}} = []
end
