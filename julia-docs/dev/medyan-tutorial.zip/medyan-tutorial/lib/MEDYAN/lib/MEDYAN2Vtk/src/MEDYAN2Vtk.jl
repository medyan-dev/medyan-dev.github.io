module MEDYAN2Vtk


using WriteVTK
using StaticArrays
using LinearAlgebra
using JSON3
using SmallZarrGroups
using OffsetArrays
using ElasticArrays
using ArgCheck
using Dictionaries
using MEDYANSimRunner: step_path, steps_traj_dir

export medyan2vtk


include("structs.jl")

"""
    medyan2vtk(medyan_out_dir::AbstractString, output_dir::AbstractString)
Convert a medyan simulation output to a collection of VTK files to view the
trajectory in ParaView.

# Keywords
- `snapshot_path=String["medyan"]`: The path to the context snapshot in the zarr directories and JSON headers.
This is useful if the snapshot and header are also storing other variables.
- `step::Int=1`: Set to over 1 to skip over some snapshots.

"""
function medyan2vtk(medyan_out_dir::AbstractString, output_dir::AbstractString;
        snapshot_path::Vector{<:AbstractString}=String["medyan"],
        step::Int=1,
    )
    traj_dir = abspath(joinpath(medyan_out_dir,"traj"))
    @argcheck !any(contains('/'), snapshot_path)
    @argcheck isdir(traj_dir)
    @argcheck isfile(joinpath(traj_dir,"header.json"))
    snapshots_steps = steps_traj_dir(traj_dir)
    full_header::JSON3.Object = JSON3.read(read(joinpath(traj_dir,"header.json"), String))
    header = foldl(getindex, snapshot_path; init = full_header)
    mkpath(output_dir)
    cd(output_dir) do
        @argcheck !isfile("full_simulation.pvd")
        mkdir("data")
        pvd_lock = ReentrantLock()
        paraview_collection("full_simulation") do pvd
            # Threads.@threads when everything is thread safe,
            # currently Blosc and LightXML may have some issues.
            for step in snapshots_steps
                fullsnapshotpath = joinpath(traj_dir, step_path(step))
                snapshotname = string(step)
                stepdir = mkdir(joinpath("data",snapshotname))
                snapgroup = SmallZarrGroups.load_zip(fullsnapshotpath)["snap/"*join(snapshot_path,"/")]
                version = get_version(snapgroup)
                time = get_time(snapgroup, version)
                filamentdata::Vector{FilamentData} = get_filamentdata(snapgroup, header, version)
                membranedata::Vector{MembraneData} = get_membranedata(snapgroup, header, version)
                tag_data::Dict{Symbol, TagData} = get_tag_data(snapgroup, header, version, filamentdata, membranedata)
                link_data::Vector{LinkData} = get_link_data(snapgroup, header, version, tag_data)
                vtk_multiblock(joinpath(stepdir,"full_domain")) do vtm
                    write_filaments(vtm, stepdir, header, filamentdata; compress = false)
                    write_membranes(vtm, stepdir, header, membranedata; compress = false)
                    write_links(vtm, stepdir, header, link_data)
                    write_chem_voxels(vtm, stepdir, header, snapgroup, version; compress = false)
                    @lock pvd_lock pvd[time] = vtm
                end
            end
        end
    end
end

get_version(snapgroup::ZGroup) = VersionNumber(attrs(snapgroup)["version"])

get_time(snapgroup::ZGroup, version::VersionNumber)::Float64 = attrs(snapgroup)["time (s)"]




"""
Return a Vector{FilamentData}.

Indexed by filament type id.

"""
function get_filamentdata(snapgroup::ZGroup, header::JSON3.Object, version::VersionNumber; 
    )::Vector{FilamentData}
    pos_rounder(pos) = convert.(Float32,pos)
    if !haskey(header,"filaments")
        return []
    end
    out = [FilamentData() for i in eachindex(header["filaments"])]
    if haskey(snapgroup,"filaments")
        filgroup = snapgroup["filaments"]
        filgroup_keys = collect(keys(filgroup))
        for ftidstr in filgroup_keys
            #read the ZGroup here, then do the data processing
            local monomerstates::Vector{UInt8}
            local node_mids::Vector{Int32}
            local nodeposition_vec::Vector{SVector{3,Float64}}
            local fids::Vector{Int}
            local ftid::Int
            local num_fils::Int
            local num_monomers::Vector{Int32}
            local num_cylinders::Vector{Int32}
            begin
                filament_type_group = snapgroup["filaments/$ftidstr"]
                ftid = parse(Int,ftidstr)
                fids = collect(filament_type_group["fids"])
                num_monomers = collect(filament_type_group["num_monomers"])
                num_cylinders = collect(filament_type_group["num_cylinders"])
                num_fils = length(num_cylinders)
                local total_num_cylinders = sum(num_cylinders)
                local total_num_nodes = total_num_cylinders + num_fils # add on last node
                local nodepositions::Array{Float64,2} = copy(transpose(collect(filament_type_group["nodepositions"])))
                @argcheck size(nodepositions) == (3,total_num_nodes)
                nodeposition_vec = collect(reinterpret(reshape,SVector{3,Float64},nodepositions))
                node_mids = collect(filament_type_group["node_mids"])
                @argcheck length(node_mids) == total_num_cylinders
                local total_num_monomers = sum(num_monomers)
                monomerstates = collect(filament_type_group["monomerstates"])
                @argcheck length(monomerstates) == total_num_monomers
            end
            monomerstate_ptr = 0
            nodestate_ptr = 0
            cylstate_ptr = 0
            monomer_vects = OffsetVector{Monomer, Vector{Monomer}}[]
            for fidx in 1:num_fils
                num_monomer = num_monomers[fidx]
                fil_monomerstates = monomerstates[1+monomerstate_ptr:monomerstate_ptr+num_monomer]
                fil_monomerpos = zeros(SVector{3,Float32},num_monomer)
                fil_monomerplusvec = zeros(SVector{3,Float32},num_monomer)
                num_cyl = num_cylinders[fidx]
                first_mon_id = node_mids[1+cylstate_ptr]
                last_mon_id = num_monomer + first_mon_id - 1
                for cyl_i in 1:num_cyl
                    pos1 = nodeposition_vec[1+nodestate_ptr]
                    pos2 = nodeposition_vec[2+nodestate_ptr]
                    mon_id1 = node_mids[1+cylstate_ptr]
                    mon_id2 = (cyl_i == num_cyl) ? (last_mon_id+1) : node_mids[2+cylstate_ptr]
                    num_mon_cyl = mon_id2 - mon_id1
                    @assert num_mon_cyl > 0
                    plus_vec = convert.(Float32,normalize(pos2-pos1))
                    mon_idx_range = mon_id1-first_mon_id+1:mon_id2-first_mon_id
                    fil_monomerplusvec[mon_idx_range] .= (plus_vec,)
                    one_mon_step = (pos2-pos1)/num_mon_cyl
                    mon_pos_a = LinRange(0.5, num_mon_cyl-0.5, num_mon_cyl)
                    fil_monomerpos[mon_idx_range] .= pos_rounder.((pos1,) .+ mon_pos_a .* (one_mon_step,))
                    nodestate_ptr += 1
                    cylstate_ptr += 1
                end
                monomers = Monomer.(fil_monomerstates, fil_monomerpos, fil_monomerplusvec)
                push!(monomer_vects, OffsetArrays.Origin(first_mon_id)(monomers))
                nodestate_ptr += 1
                monomerstate_ptr += num_monomer
            end
            local fil_data = FilamentData(;
                monomers = monomer_vects,
                node_pos = pos_rounder.(nodeposition_vec),
                node_ranges = UnitRange.(cumsum(num_cylinders .+ 1) .- num_cylinders, cumsum(num_cylinders .+ 1)),
                id2idx = Dictionary(fids, eachindex(fids))
            )
            #calc bend angle
            for node_idx_range in fil_data.node_ranges
                @assert length(node_idx_range) ≥ 2
                #end nodes have zero bend
                push!(fil_data.node_bend_angles, 0)
                @inbounds for i in node_idx_range[begin+1:end-1]
                    local r1 = normalize(fil_data.node_pos[i] - fil_data.node_pos[i-1])
                    local r2 = normalize(fil_data.node_pos[i+1] - fil_data.node_pos[i])
                    push!(fil_data.node_bend_angles, acos(clamp((r1 ⋅ r2),-1,1)))
                end
                push!(fil_data.node_bend_angles, 0)
            end
            out[ftid] = fil_data
        end
    end
    return out
end


"""
Return a Vector{MembraneData}.

Indexed by membrane index.

# Keywords
- `position_scale::Int = 5`: vertex positions are rounded to the nearest `2^-position_scale` nm.

"""
function get_membranedata(snapgroup::ZGroup, header::JSON3.Object, version::VersionNumber; 
        position_scale::Int=5,
    )::Vector{MembraneData}
    pos_rounder(pos) = convert.(Float32,round.(pos; digits = position_scale, base=2))
    if !haskey(snapgroup,"membranes")
        return []
    end
    membranes_group = snapgroup["membranes"]
    num_membranes = attrs(snapgroup["membranes"])["num_membranes"]
    out = map(1:num_membranes) do mem_idx
        membrane_group = membranes_group["$mem_idx"]
        typeid = attrs(membrane_group)["typeid"]
        coords::Matrix{Float32} = collect(membrane_group["vertlist"])
        tris::Matrix{Int32} = collect(membrane_group["trilist"])
        vertlist = copy(reinterpret(reshape,SVector{3,Float32},coords))
        trilist = copy(reinterpret(reshape,SVector{3,Int32},tris))
        copynumbers = if haskey(membrane_group, "copynumbers")
            copynumbers_raw::ElasticMatrix{Int32} = collect(membrane_group["copynumbers"])
            @argcheck size(copynumbers_raw, 2) == length(vertlist)
            copynumbers_raw
        else
            nothing
        end
        MembraneData(;
            typeid,
            trilist,
            vert_coords = pos_rounder.(vertlist),
            vert_copynumbers = copynumbers,
        )
    end
    return out
end

_unpack_fila_idx(i::UInt64) = ((i >> 32)%UInt32, (i%UInt32) >> 1)

_zigzag_decode(u::Union{UInt128, UInt64, UInt32, UInt16, UInt8}) = signed((u >>> 1) ⊻ -(u & one(u)))

"""
Return a Dict{Symbol, TagData}.

Indexed by place name.

"""
function get_tag_data(snapgroup::ZGroup, header::JSON3.Object, version::VersionNumber, filamentdata::Vector{FilamentData}, membranedata::Vector{MembraneData})::Dict{Symbol, TagData}
    out = Dict{Symbol, TagData}()
    if haskey(snapgroup, "tags")
        tagsgroup = snapgroup["tags"]
        for (key, taggroup) in pairs(tagsgroup)
            if key == "fila_mono"
                let
                    local generations::Vector{UInt32} = collect(taggroup["g"])
                    local n = length(generations)
                    local tagdata = TagData(generations, fill(SA[NaN32,NaN32,NaN32], n))
                    if haskey(taggroup, "p_1")
                        local data::Vector{UInt64} = collect(taggroup["p_1"])
                        @argcheck length(data) == 2*n
                        for i in 1:n
                            if isodd(generations[i])
                                local ftid, fidx = _unpack_fila_idx(data[i])
                                local mid = _zigzag_decode(data[i+n])
                                tagdata.positions[i] = filamentdata[ftid].monomers[fidx][mid].pos
                            end
                        end
                    else
                        error("unable to read places")
                    end
                    out[:fila_mono] = tagdata
                end
            elseif key == "fila_tip"
                let
                    local generations::Vector{UInt32} = collect(taggroup["g"])
                    local n = length(generations)
                    local tagdata = TagData(generations, fill(SA[NaN32,NaN32,NaN32], n))
                    if haskey(taggroup, "p_1")
                        local data::Vector{UInt64} = collect(taggroup["p_1"])
                        @argcheck length(data) == n
                        for i in 1:n
                            if isodd(generations[i])
                                local ftid, fidx = _unpack_fila_idx(data[i])
                                local is_minus = isodd(data[i])
                                tagdata.positions[i] = if is_minus
                                    filamentdata[ftid].node_pos[first(filamentdata[ftid].node_ranges[fidx])]
                                else
                                    filamentdata[ftid].node_pos[last(filamentdata[ftid].node_ranges[fidx])]
                                end
                            end
                        end
                    else
                        error("unable to read places")
                    end
                    out[:fila_tip] = tagdata
                end
            elseif key == "memb_vert"
                let
                    local generations::Vector{UInt32} = collect(taggroup["g"])
                    local n = length(generations)
                    local tagdata = TagData(generations, fill(SA[NaN32,NaN32,NaN32], n))
                    if haskey(taggroup, "p_1")
                        local data::Vector{UInt64} = collect(taggroup["p_1"])
                        @argcheck length(data) == n
                        for i in 1:n
                            if isodd(generations[i])
                                local dat = data[i]
                                local memb_idx, vert_idx = ((dat >> 32)%UInt32, (dat%UInt32))
                                tagdata.positions[i] = membranedata[memb_idx].vert_coords[vert_idx]
                            end
                        end
                    else
                        error("unable to read places")
                    end
                    out[:memb_vert] = tagdata
                end
            else
                error("$(repr(key)) tags not supported yet")
            end
        end
    end
    out
end

"""
Return a Vector{LinkData}.

Indexed by link type id.
"""
function get_link_data(snapgroup::ZGroup, header::JSON3.Object, version::VersionNumber, tag_data::Dict{Symbol, TagData})::Vector{LinkData}
    if !haskey(header,"links")
        return []
    end
    n_linktypes = length(header["links"])
    out = LinkData[]
    if haskey(snapgroup, "links")
        link_version = attrs(snapgroup["links"])["version"]
        if link_version == 1
            links_group = snapgroup["links"]
            savedltids = parse.(Int,keys(links_group))
            @argcheck all(in(1:n_linktypes),savedltids)
            for ltid in 1:n_linktypes
                place_names = Symbol.(header["links"][ltid]["places"])
                if haskey(links_group,"$ltid")
                    let link_group = links_group["$ltid"]
                        local n::Int = attrs(link_group)["num_links"]
                        local tags::Matrix{UInt32} = collect(link_group["tags"])
                        @argcheck size(tags) == (n, 2*length(place_names))
                        local positions = fill(SA[NaN32, NaN32, NaN32], n, length(place_names))
                        for (place_index, place_name) in enumerate(place_names)
                            local td = tag_data[place_name]
                            for lidx in 1:n
                                local tag_idx = tags[lidx, 2place_index-1]
                                local tag_generation = tags[lidx, 2place_index]
                                if !iszero(tag_idx)
                                    @argcheck td.generations[tag_idx] == tag_generation
                                    positions[lidx, place_index] = td.positions[tag_idx]
                                end
                            end
                        end
                        push!(out, LinkData(positions))
                    end
                else
                    push!(out, LinkData(zeros(SVector{3,Float32}, 0, length(place_names))))
                end
            end
        else
            error("unable to read link version $(link_version)")
        end
    end
    return out
end

function write_filaments(
        vtm::WriteVTK.MultiblockFile,
        path::String,
        header::JSON3.Object,
        fildata::Vector{FilamentData};
        compress = false,
    )
    if isempty(fildata)
        return
    end
    for (ftid, fil_header) in enumerate(header["filaments"])
        if isempty(fildata[ftid].node_pos)
            continue
        end
        block = multiblock_add_block(vtm, "filament_$(fil_header["name"])")

        flat_monomers = collect(Iterators.flatten(fildata[ftid].monomers))
        points = map(x->x.pos, flat_monomers)
        verts = [MeshCell(PolyData.Verts(),collect(1:length(points)))]
        vtk_mon = vtk_grid(joinpath(path,"filament_monomers_$(fil_header["name"])"), points, verts; compress)
        vtk_mon["plusvec", VTKPointData()] = map(x->x.plusvec, flat_monomers)
        vtk_mon["state", VTKPointData()] = map(x->x.state, flat_monomers)
        vtk_mon["radius(nm)", VTKFieldData()] = fil_header["radius(nm)"]
        vtk_mon["states", VTKFieldData()] = repr(fil_header["monomerstates"])
        vtk_mon["name", VTKFieldData()] = fil_header["name"]
        vtk_mon["fil_typeid", VTKFieldData()] = ftid
        multiblock_add_block(block, vtk_mon, "monomers")

        node_pos = fildata[ftid].node_pos
        node_bend_angles = fildata[ftid].node_bend_angles
        node_id_ranges = collect(fildata[ftid].node_ranges)
        cyl_lines = [MeshCell(PolyData.Lines(),node_id_range) for node_id_range in node_id_ranges]
        vtk_lines = vtk_grid(joinpath(path,"filament_lines_$(fil_header["name"])"), node_pos, cyl_lines; compress)
        vtk_lines["radius(nm)", VTKFieldData()] = fil_header["radius(nm)"]
        vtk_lines["name", VTKFieldData()] = fil_header["name"]
        vtk_lines["fil_typeid", VTKFieldData()] = ftid
        vtk_lines["bend_angle_degrees", VTKPointData()] = (180/π)*node_bend_angles
        multiblock_add_block(block, vtk_lines, "lines")
    end
end

function write_membranes(
        vtm::WriteVTK.MultiblockFile,
        path::String,
        header::JSON3.Object,
        memdata::Vector{MembraneData};
        compress = false,
    )
    if isempty(memdata)
        return
    end
    mem_block = multiblock_add_block(vtm, "membranes")
    for (mem_idx, mem::MembraneData) in enumerate(memdata)
        points = mem.vert_coords
        tris = [MeshCell(VTKCellTypes.VTK_TRIANGLE, tri) for tri in mem.trilist]
        vtk = vtk_grid(joinpath(path,"membranes_$mem_idx"), points, tris; compress)
        if !isnothing(mem.vert_copynumbers)
            species_names = map(x->x["name"], header["membrane_diffusing_species"])
            if length(species_names) != size(mem.vert_copynumbers, 1)
                @error "$(length(species_names)) species in header, $(size(mem.vert_copynumbers, 2)) in data."
            else
                for (sid, sname) in enumerate(species_names)
                    vtk["species-$(sname)", VTKPointData()] = mem.vert_copynumbers[sid,:]
                end
            end
        end
        vtk["mem_typeid", VTKFieldData()] = mem.typeid
        multiblock_add_block(mem_block, vtk, "$mem_idx")
    end
end

function write_links(
        vtm::WriteVTK.MultiblockFile,
        path::String,
        header::JSON3.Object,
        linkdata::Vector{LinkData};
        compress = false,
    )
    if isempty(linkdata)
        return
    end
    for (ltid, link_header) in enumerate(header["links"])
        block = multiblock_add_block(vtm, "link_$(link_header["name"])")
        positions = linkdata[ltid].positions
        (n_links, n_places) = size(positions)
        centers = fill(SA[NaN32,NaN32,NaN32], n_links)
        cells = typeof(MeshCell(PolyData.Lines(),(1,2)))[]
        node_pos = SVector{3, Float32}[]
        node_i = 0
        for i in 1:n_links
            local c = zero(eltype(positions))
            local  n = 0
            for j in 1:n_places
                local p = positions[i, j]
                if all(!isnan, p)
                    c += p
                    n += 1
                    push!(node_pos, p)
                    node_i += 1
                end
            end
            if !iszero(n)
                centers[i] = inv(n)*c
                push!(node_pos, inv(n)*c)
                node_i += 1
                for n_i in node_i-n:node_i-1
                    push!(cells, MeshCell(PolyData.Lines(), (n_i, node_i)))
                end
            end
        end
        verts = [MeshCell(PolyData.Verts(),collect(1:n_links))]
        vtk_link_centers = vtk_grid(joinpath(path,"link_centers_$(link_header["name"])"), centers, verts; compress)
        multiblock_add_block(block, vtk_link_centers, "centers")

        vtk_lines = vtk_grid(joinpath(path,"link_$(link_header["name"])"), node_pos, cells; compress)
        vtk_lines["name", VTKFieldData()] = link_header["name"]
        vtk_lines["link_typeid", VTKFieldData()] = ltid
        multiblock_add_block(block, vtk_lines, "lines")
    end
end

function centered_range(;step, length)
    range(;start=-step*(length-1)/2, stop=step*(length-1)/2, length)
end


function write_chem_voxels(
        vtm::WriteVTK.MultiblockFile,
        path::String,
        header::JSON3.Object,
        snapgroup::ZGroup,
        version::VersionNumber;
        compress = false,
    )
    chem_grid_size = header["chem_grid_size"]
    if version < v"0.8"
        # origin in the grid corner
        xs = range(;start = 0.0, step = chem_grid_size["voxel_x(nm)"], length=chem_grid_size["nx"]+1)
        ys = range(;start = 0.0, step = chem_grid_size["voxel_y(nm)"], length=chem_grid_size["ny"]+1)
        zs = range(;start = 0.0, step = chem_grid_size["voxel_z(nm)"], length=chem_grid_size["nz"]+1)
    else
        # origin changed to the center of the grid
        xs = centered_range(step = chem_grid_size["voxel_x(nm)"], length=chem_grid_size["nx"]+1)
        ys = centered_range(step = chem_grid_size["voxel_y(nm)"], length=chem_grid_size["ny"]+1)
        zs = centered_range(step = chem_grid_size["voxel_z(nm)"], length=chem_grid_size["nz"]+1)
    end
    if !haskey(header,"diffusing_species")
        return
    end
    diffusing_species_names = map(x->x["name"], header["diffusing_species"])
    if !isempty(diffusing_species_names)
        diffusing_counts = collect(snapgroup["diffusingcounts"]) #Indexed by [species id, compartment id] to give count.
        vtk_diff = vtk_grid(joinpath(path,"diffusing_species"), xs, ys, zs; compress)
        for (dsid, dsname) in enumerate(diffusing_species_names)
            vtk_diff[dsname] = reshape(diffusing_counts[dsid,:], length(xs)-1, length(ys)-1, length(zs)-1)
        end
        multiblock_add_block(vtm, vtk_diff, "diffusingcounts")
    end
end

end # module MEDYAN2Vtk
