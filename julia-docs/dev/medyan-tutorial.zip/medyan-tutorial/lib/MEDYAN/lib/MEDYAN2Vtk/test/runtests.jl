using MEDYAN
using OrderedCollections: OrderedDict
using MEDYAN2Vtk: medyan2vtk
using Test: @test, @testset, @test_throws, @test_logs
using Random: Random
using JSON3: JSON3
using SmallZarrGroups: ZGroup, save_zip

Random.seed!(1234)

@testset "visualize empty context" begin
    s = MEDYAN.SysDef(MEDYAN.AgentNames())
    grid = CubicGrid((1,1,1), 200.0)
    c = MEDYAN.Context(s, grid)
    mktempdir() do dir
        td = mkdir(joinpath(dir,"traj"))
        JSON3.write(joinpath(td,"header.json"), OrderedDict(["medyan"=>MEDYAN.header(c)]))
        save_zip(joinpath(td,"snap0.zarr.zip"), setindex!(ZGroup(), MEDYAN.snapshot(c), "snap/medyan"))
        mktempdir() do vis_dir
            medyan2vtk(dir, joinpath(vis_dir, "out"))
        end
    end
end