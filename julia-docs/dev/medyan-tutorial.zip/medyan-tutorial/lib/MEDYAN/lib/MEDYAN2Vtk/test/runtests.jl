using MEDYAN
using MEDYAN2Vtk: medyan2vtk
using Test: @test, @testset, @test_throws, @test_logs
using Random: Random

Random.seed!(1234)

@testset "test" begin
    @test 1 + 1 == 2
end