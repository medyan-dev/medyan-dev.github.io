module MEDYANVis

using MEDYAN
using MEDYAN: Context, SysDef, CubicGrid, Boundary
using Reexport: @reexport
@reexport using MeshCat
using Colors
import GeometryBasics
using Setfield
using StaticArrays
using Random123: Random123
using Meshing: isosurface, MarchingTetrahedra
using LinearAlgebra

export draw_context!

# Faster norm functions, these may be worse for floating point error.
# See https://github.com/JuliaArrays/StaticArrays.jl/pull/975#issuecomment-1436115140

@inline norm_fast(v) = Base.FastMath.sqrt_fast(sum(abs2, v))

@inline normalize_fast(v) = v * inv(norm_fast(v))

"""
Visualize a context
"""
function draw_context!(vis, c::Context, systemdefs::SysDef=c.sys_def)
    #drawdiffusing!(vis["diffusing"], c.grid, c.chemistryengine, systemdefs)
    drawgrid!(vis["grid"],c.grid)
    drawhalfedgemeshes!(vis["membrane"], c.membranes; scale=1e-3)
    drawfilaments!(vis["filaments"], c.chem_cylinders, systemdefs)
    drawfilaments_tubes!(vis["filamentTubes"], c, map(x->x.radius,c.filamentmechparams), systemdefs)
    drawlinks!(vis["links"], c)
    drawboundary!(vis["chemboundary"],c.grid,c.chemboundary)
    drawboundary!(vis["mechboundary"],c.grid,c.mechboundary) 
    drawvertices!(vis["vertex"], c.membranes;scale=1e-3)
    drawpossiblecadherins!(vis["possible cadherin site"], c)
end

"""
Visualize boundingplanes and boundingcapsules within one compartment of the grid
"""
function drawboundary!(vis, grid::CubicGrid, boundary::Boundary)
    scale=1000
    signeddistfun = MEDYAN.create_signeddistfun(boundary)
    gridsize = grid.compartmentsize
    samplespergrid = 10
    smallsampledist = grid.compartmentsize/samplespergrid
    origin = (SVector(-gridsize,-gridsize,-gridsize) .- smallsampledist/2) + MEDYAN.cornerof(grid)
    widths =  smallsampledist .+ @SVector [(2+grid.n[i])*gridsize for i in 1:3]
    samples = @SVector([(2+grid.n[i])*10 + 1 for i in 1:3])
    points, faces = old_isosurface(signeddistfun, MarchingTetrahedra(); origin, widths, samples)
    pointsf = GeometryBasics.Point3f.(points)
    pointsf .*= (1//scale)
    facestri = GeometryBasics.TriangleFace{Int}.(faces)
    mesh = GeometryBasics.Mesh(pointsf, facestri)
    mat = MeshPhongMaterial(color=RGBA(0, 1, 1, 0.5),wireframe=true)
    setobject!(vis, mesh, mat)
end

function old_isosurface(f::Function, alg; origin::SVector{3}, widths::SVector{3}, samples::SVector{3,<:Integer})
    xr,yr,zr = ntuple(i->LinRange(origin[i],origin[i] + widths[i], samples[i]),3)
    sdf = [f(SA[x,y,z]) for x in xr, y in yr, z in zr]
    points, triangles = isosurface(sdf, alg, xr, yr, zr)
    SVector.(points), SVector.(triangles)
end

"""
Visualize Links with lines connected to a point offset from the attached places
"""
function drawlinks!(vis, c::Context; size=0.002)
    scale=1000
    num_filament_types= num_fila_types(c)
    _num_link_types= num_link_types(c)
    filamentcolors= distinguishable_colors(num_filament_types,[RGB(1,1,1), RGB(0,0,0),],dropseed=true)
    link_colors= distinguishable_colors(_num_link_types,[RGB(1,1,1); RGB(0,0,0); filamentcolors],dropseed=true)
    foreach(enumerate(c.link_manager.link_data)) do (ltid, d)
        name = string(c.link_manager.names[ltid])
        linesegs= Vector{SVector{3,Float32}}()
        nodepoints= Vector{SVector{3,Float32}}()
        for (lidx, tags) in enumerate(d.per_link.tags)
            append_place_connection!(linesegs, nodepoints, tags, c, UInt64(lidx) + UInt64(ltid)<<32;scale)
        end
        setobject!(vis[name]["lines"], Object(PointCloud(linesegs), LineBasicMaterial(color=link_colors[ltid]), "LineSegments"))
        setobject!(vis[name]["points"], 
                PointCloud(nodepoints),
                PointsMaterial(; size=size, color=link_colors[ltid], vertexColors=0))
    end
end


"""
Append the line segments and node to connect a set of tags
with a arrow on the plus end.
"""
function append_place_connection!(
        linesegs::Vector{SVector{3,Float32}},
        points::Vector{SVector{3,Float32}},
        tags,
        c::Context,
        uid::UInt64,
        ;
        scale = 1000,
    )
    avg_pos::SVector{3, Float32} = zero(SVector{3, Float32})
    n_pos = 0
    for tag in tags
        MEDYAN.is_null(tag) && continue
        avg_pos += MEDYAN.get_position(c, tag)
        n_pos += 1
    end
    if iszero(n_pos)
        return
    end
    avg_pos *= inv(n_pos)
    # add random offset to get node point
    rng = Random123.Philox2x(uid)
    node_p = avg_pos + 10.0*randn(rng, SVector{3, Float32})
    push!(points, node_p * inv(scale))
    for tag in tags
        MEDYAN.is_null(tag) && continue
        local p = MEDYAN.get_position(c, tag)
        push!(linesegs, p * inv(scale))
        push!(linesegs, node_p * inv(scale))
    end
end


"""
Visualize filaments with lines and points
"""
function drawfilaments!(vis, cylinderss::Vector{MEDYAN.ChemCylinders}, systemdefs::SysDef, size=0.002)
    scale=1000
    num_filament_types= length(cylinderss)
    filamentcolors= distinguishable_colors(num_filament_types,[RGB(1,1,1), RGB(0,0,0),],dropseed=true)
    for ftid in 1:num_filament_types
        cylinders::MEDYAN.ChemCylinders = cylinderss[ftid]
        num_monomer_states= length(systemdefs.state[ftid]) + 1
        monomerpoints=[Vector{SVector{3,Float32}}() for i in 1:num_monomer_states]
        linesegs= Vector{SVector{3,Float32}}()
        monomercolors= distinguishable_colors(num_monomer_states,[RGB(1,1,1); RGB(0,0,0); filamentcolors],dropseed=true)
        for fil_idx in eachindex(cylinders.per_fil)
            monstates = MEDYAN._fil_mon_states(cylinders, fil_idx)
            for mid in eachindex(monstates)
                state= monstates[mid]
                pos= MEDYAN._mon_position(cylinders, fil_idx, mid) ./ scale
                push!(monomerpoints[state+1],pos)
            end
            push!(linesegs,MEDYAN._mon_position(cylinders, fil_idx, firstindex(monstates)) ./ scale)
            for mid in (firstindex(monstates)+1):(lastindex(monstates)-1)
                push!(linesegs,MEDYAN._mon_position(cylinders, fil_idx, mid) ./ scale)
                push!(linesegs,MEDYAN._mon_position(cylinders, fil_idx, mid) ./ scale)
            end
            push!(linesegs,MEDYAN._mon_position(cylinders, fil_idx, lastindex(monstates)) ./ scale)
        end
        filamenttypesymbol= collect(keys(systemdefs.filament))[ftid]
        monomerstatesymbols= [:null ;collect(keys(systemdefs.state[ftid]))]
        setobject!(vis[filamenttypesymbol], Object(PointCloud(linesegs), LineBasicMaterial(color=filamentcolors[ftid]), "LineSegments"))
        for mstate in 1:num_monomer_states
            setobject!(vis[filamenttypesymbol][monomerstatesymbols[mstate]], 
                PointCloud(monomerpoints[mstate]),
                PointsMaterial(; size=size, color=monomercolors[mstate], vertexColors=0))
        end
        setvisible!(vis[filamenttypesymbol][:null],false)
    end
end

"""
Visualize filaments with tubes
"""
function drawfilaments_tubes!(vis, c::Context, radii, systemdefs::SysDef, size=0.002)
    scale=1000
    num_filament_types= num_fila_types(c)
    filamentcolors= distinguishable_colors(num_filament_types,[RGB(1,1,1), RGB(0,0,0),],dropseed=true)
    for ftid in 1:num_filament_types
        mymesh= zeromesh()
        for fil_idx in 1:num_fila(c; type=ftid)
            nodepos = fila_node_positions(c, FilaIdx(ftid, fil_idx))
            mymesh = unionmesh(mymesh, pathExtrudeGenerate(nodepos./scale,Float32(radii[ftid]/scale),8))
        end
        # @show mymesh
        filamenttypesymbol= collect(keys(systemdefs.filament))[ftid]
        setobject!(vis[filamenttypesymbol], mymesh, MeshCat.MeshPhongMaterial(color=filamentcolors[ftid]))
    end
end

"""
Add halfedges to visualization.
"""
function drawhalfedgemeshes!(vis, meshes; scale::Real=1)
    np_tillnow = 0
    nf_tillnow = 0
    ps = Vector{GeometryBasics.Point3f}()
    fs = Vector{GeometryBasics.TriangleFace{Int}}()
    for m ∈ meshes
        resize!(ps, np_tillnow + length(m.vertices))
        for vindex ∈ 1:length(m.vertices)
            ps[np_tillnow + vindex] = convert(GeometryBasics.Point3f, m.vertices.attr.coord[vindex] .* scale)
        end

        resize!(fs, nf_tillnow + length(m.triangles))
        for tindex ∈ 1:length(m.triangles)
            local f = GeometryBasics.TriangleFace{Int}(0,0,0)
            local fi = 0
            for h ∈ MEDYAN.HalfedgesInTriangle(m, MEDYAN.IT(tindex))
                fi += 1
                f = @set f[fi] = (MEDYAN.target(m, h).value + np_tillnow)
            end
            fs[nf_tillnow + tindex] = f
        end

        np_tillnow = length(ps)
        nf_tillnow = length(fs)
    end
	mesh = GeometryBasics.Mesh(ps, fs)
	setobject!(vis["halfedgemesh"], mesh, MeshCat.MeshPhongMaterial(wireframe=true))
end

"""
Visualize diffusing species with point clouds
"""
function drawdiffusing!(vis, grid, rdmesampler::MEDYAN.RDMESampler, systemdefs::SysDef; size=0.02)
    nds= length(systemdefs.diffusing)
    colors= distinguishable_colors(nds,[RGB(1,1,1), RGB(0,0,0),],dropseed=true)
    for dsid in 1:nds
        drawrandomgridpoints!(vis[collect(keys(systemdefs.diffusing))[dsid]],grid,rdmesampler.diffusingcounts[dsid,:],colors[dsid],size)
    end
end

"""
Visualize a grid.
Set two objects in a MeshCat vis, "outer" and  "inner"
"""
function drawgrid!(vis,grid::CubicGrid)
    scale=1000
    #first build up a vector of pairs of points to draw lines
    outerpoints=Vector{SVector{3,Float32}}()
    for axis in 1:3
        for sideaxis in filter(≠(axis),1:3)
            lastaxis= filter(≠(sideaxis),filter(≠(axis),1:3))[1]
            for i in 0:grid.n[sideaxis]
                point1= zeros(3)
                point1[sideaxis]= i*grid.compartmentsize/scale
                point2= copy(point1)
                point2[axis]= grid.n[axis]*grid.compartmentsize/scale
                push!(outerpoints,point1)
                push!(outerpoints,point2)
                point3= copy(point1)
                point3[lastaxis]= grid.n[lastaxis]*grid.compartmentsize/scale
                point4= copy(point2)
                point4[lastaxis]= grid.n[lastaxis]*grid.compartmentsize/scale
                push!(outerpoints,point3)
                push!(outerpoints,point4)
            end
        end
    end
    outerpoints .+= Ref(MEDYAN.cornerof(grid)/scale)
    innerpoints=Vector{SVector{3,Float32}}()
    for axis in 1:3
        iaxis,jaxis = filter(≠(axis),1:3)
        for i in 1:(grid.n[iaxis]-1)
            for j in 1:(grid.n[jaxis]-1)
                point1= zeros(3)
                point1[iaxis]= i*grid.compartmentsize/scale
                point1[jaxis]= j*grid.compartmentsize/scale
                point2= copy(point1)
                point2[axis]= grid.n[axis]*grid.compartmentsize/scale
                push!(innerpoints,point1)
                push!(innerpoints,point2)
            end
        end
    end
    innerpoints .+= Ref(MEDYAN.cornerof(grid)/scale)
    setobject!(vis["outer"], Object(PointCloud(outerpoints), LineBasicMaterial(color=RGB(0)), "LineSegments"))
    setobject!(vis["inner"], Object(PointCloud(innerpoints), LineBasicMaterial(color=RGB(0)), "LineSegments"))
end

"""
Fill random points in a grid.
pointcount is a vector of point counts per compartment,
    indexed by compartment id.
"""
function drawrandomgridpoints!(vis,grid,pointcount,color,size=0.02)
    scale= 1000
    points=Vector{SVector{3,Float32}}(undef,sum(pointcount))
    pid=0
    for cid in 1:length(pointcount)
        for i in 1:pointcount[cid]
            pid+=1
            points[pid]= MEDYAN.randompoint(grid,cid) ./ scale
        end
    end
    setobject!(vis, PointCloud(points),PointsMaterial(; size=size, color=color, vertexColors=0))
end



"""
This function transforms a path to a mesh of tubes.
The returned mesh is a GeometryBasics.Mesh

Copied from C++ medyan, originally written by Haoran Ni (drelatgithub)


Parameters
//   - path:  the container where the coordinates of beads can be found.
//   - radius:  the radius of the tube.
//   - sides:   the number of sides of the tube.

"""
function pathExtrudeGenerate(path, radius::Float32, sides::Integer)
    path = SVector{3,Float32}.(path)
    numVertices = length(path)
    numTubeVertices = sides*numVertices
    numTriangles = (numVertices-1)*2*sides
    vertices = Vector{SVector{3,Float32}}()
    sizehint!(vertices,numTubeVertices)
    triInd = Vector{SVector{3,Int32}}()
    sizehint!(triInd,numTriangles)
    @assert numVertices ≥ 2 "path must have at least two points"

    # Locate first circle
    seg = normalize_fast(path[2]-path[1])
    n0 = if abs(seg[1]) < abs(seg[2])
        cross(seg,SA_F32[1,0,0])
    else
        cross(seg,SA_F32[0,1,0])
    end
    n0 = normalize_fast(n0)
    n1 = normalize_fast(cross(n0,seg))
    
    for j in 0:(sides-1)
        a = j*2*π/sides
        xa = radius*cos(a)
        ya = radius*sin(a)
        point = path[1] + n0*xa + n1*ya
        push!(vertices,point)
    end

    segn = seg
    # Propagate circles
    for i in 2:numVertices
        segn = normalize_fast(i == numVertices ? segn : path[i+1] - path[i])
        t = normalize_fast(seg+segn)
        dot_seg_t = seg ⋅ t
        for j in 0:(sides-1)
            # Solve for p_new given:
            #   dot(p_new - coords[indices[i]], t) = 0
            #   p_new = x * seg + pp
            pp = vertices[(i-2)*sides + j + 1]
            x = dot(path[i] - pp,t)/dot_seg_t
            push!(vertices,x * seg + pp)
        end
        seg = segn
    end

    # Make indices of faces
    for i in 0:(numVertices-2)
        for j in 0:(sides-1)
            # First triangle
            push!(triInd, SA[
                i*sides + j + 1,
                (i+1)*sides + j + 1,
                i*sides + mod(j+1,sides) + 1,
            ])
            # Second triangle
            push!(triInd, SA[
                i*sides + mod(j+1,sides) + 1,
                (i+1)*sides + j + 1,
                (i+1)*sides + mod(j+1,sides) + 1,
            ])
        end
    end

    #combine into a GeometryBasics.Mesh
    faces = copy(reinterpret(Int32,triInd))
    GeometryBasics.Mesh(GeometryBasics.Point.(vertices),faces,GeometryBasics.TriangleFace, 3)
end

"""
Combine two meshes
"""
function unionmesh(mesh1, mesh2)
    points1 = copy(GeometryBasics.coordinates(mesh1))
    points2 = copy(GeometryBasics.coordinates(mesh2))
    faces1 = copy(reinterpret(Int32,GeometryBasics.faces(mesh1)))
    faces2 = copy(reinterpret(Int32,GeometryBasics.faces(mesh2)))
    newfaces2 = faces2 .+ Int32(length(points1))
    newfaces = [faces1; newfaces2]
    newpoints = [points1; points2]
    GeometryBasics.Mesh(newpoints,newfaces,GeometryBasics.TriangleFace, 3)
end

"""
Return an emptymesh
"""
function zeromesh()
    vertices = Vector{SVector{3,Float32}}()
    faces = Vector{Int32}()
    GeometryBasics.Mesh(GeometryBasics.Point.(vertices),faces,GeometryBasics.TriangleFace, 3)
end

"""
Visualize vertices with points. Coloring based on the states of verteices.
"""
function drawvertices!(vis, membranes;scale::Real=1)
    for m ∈ membranes
        vertex_points = Vector{GeometryBasics.Point3f}()
        active_vertices = Vector{GeometryBasics.Point3f}()
        inactive_vertices = Vector{GeometryBasics.Point3f}()
        zerostate_vertices = Vector{GeometryBasics.Point3f}() 
        num_vertex_states = length(m.vertices)#use different colors to distinguish different vertexstates
        vertexcount = 0
        resize!(vertex_points, vertexcount + num_vertex_states)
        for vindex ∈ 1:num_vertex_states
            vertex_points[vertexcount + vindex] = convert(GeometryBasics.Point3f, m.vertices.attr.coord[vindex].*scale)#.* scale
            if m.vertices.attr.vertexstate[vindex] == 1
                push!(inactive_vertices, vertex_points[vindex])
            elseif m.vertices.attr.vertexstate[vindex] == 2
                push!(active_vertices, vertex_points[vindex])
            elseif m.vertices.attr.vertexstate[vindex] == 0
                push!(zerostate_vertices, vertex_points[vindex])
            end
        end
        vertexcount = length(vertex_points)
        setobject!(vis["inactive vertices"], PointCloud(inactive_vertices), PointsMaterial(size=0.01, color=RGBA(255,0,0,0.5), vertexColors=0))
        setobject!(vis["active vertices"], PointCloud(active_vertices), PointsMaterial(size=0.01, color=RGBA(0,255,0,0.5), vertexColors=0))
        setobject!(vis["zerostate vertices"], PointCloud(zerostate_vertices), PointsMaterial(size=0.01, color=RGBA(0,0,255,0.5), vertexColors=0))
    end
end

"""
Visualize possible cadherin sites with sitecount above 0 
"""
function drawpossiblecadherins!(vis, c::Context)
    scale=1000
    possiblecadherinsites = Vector{SVector{3,Float32}}()
    possiblecadherinsites_vertices = Vector{SVector{3,Float32}}()
    foreach(c.possiblecadherinsite_managers) do m
        system = m.system
        foreach(system.output.pairlists) do pairlist
            foreach(pairlist) do pair
                vertex_place, monomer_place = MEDYAN.index2vert_mononames(m, pair)
                vertex_coord = MEDYAN.get_position(c, vertex_place)./ scale
                monomer_coord = MEDYAN.get_position(c, monomer_place)./ scale
                push!(possiblecadherinsites_vertices,vertex_coord)
                push!(possiblecadherinsites,vertex_coord)
                push!(possiblecadherinsites,monomer_coord)
            end
        end
        # setobject!(vis["possible cadherin site vertices"], PointCloud(possiblecadherinsites_vertices), PointsMaterial(size=0.02, color=RGBA(255,255,0,0.5), vertexColors=0))
        setobject!(vis["possiblecadherinsites"], Object(PointCloud(possiblecadherinsites), LineBasicMaterial(color= RGBA(255,255,0,0.5)), "LineSegments"))
    end
end

end # module MEDYANVis
