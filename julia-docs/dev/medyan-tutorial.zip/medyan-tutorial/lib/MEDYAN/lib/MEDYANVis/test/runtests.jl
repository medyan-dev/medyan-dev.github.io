using MEDYAN
using MEDYANVis
using Test

@testset "draw_context! compiles" begin
    vis = Visualizer()
    c, systemdefs, = MEDYAN.example_all_sites_context(; check_sitecount_error=true)
    draw_context!(vis, c, systemdefs)
    MEDYANVis.drawdiffusing!(vis["diffusing"], c.grid, c.chemistryengine, systemdefs)
    MEDYANVis.draw_decimated_2mon_sites!(vis["decimated_2mon_sites"], c, systemdefs)
    # sleep(100.0)
    delete!(vis)
    vis = nothing
end

include("test_visualizecadherin.jl")