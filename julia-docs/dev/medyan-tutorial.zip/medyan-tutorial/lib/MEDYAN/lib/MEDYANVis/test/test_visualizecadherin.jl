using MEDYAN
using Test
using MEDYANVis
using StaticArrays
using Setfield

@testset "draw_context! with vertices and cadherins" begin
    grid= CubicGrid((3,1,1),500.0)
    corner = MEDYAN.cornerof(grid)
    agentnames = MEDYAN.AgentNames(
		filamentnames= [(:a,[
	                            :m,
                                :k,
                                :g,
	                        ]),
		],
        vertexnames = [:ver,:ver1,:ver2,:ver3],
        cadherinnames = [:filaver,]
	)
    s = MEDYAN.SysDef(agentnames)
    default_actin = MEDYAN.ACTIN_FIL_PARAMS
    add_filament_params!(s, :a, @set(default_actin.numpercylinder = 2)) #number of monomers in each cylinder 40 to 2
    # Initiate a membrane
    m = MEDYAN.create_membranemesh()
    trilist = [SA[1,2,3], SA[3,2,4]]
    vertlist = [SA[0,200,200], SA[300,0,0], SA[1000,500,500], SA[600,500,1]] .+ Ref(corner)
    id = [222,777,888,999]
    vertexstate = [s.vertex[1], s.vertex[2], s.vertex[1], s.vertex[3]]
    MEDYAN.initmesh!(m,(; vertlist, trilist, id, vertexstate))


    #Add cadherin to the the system
    cadherinstate = CadherinState((sitecount=0.0,),(;))
    addcadherin!(s,
        :filaver,
        cadherinstate,
        nothing,
    )
    
    #Add cadherinsites to system 
    site = MEDYAN.CadherinSiteSlipBond(f0=4.9,k0=2.0) #or CadherinSiteCount()
    addcadherinsite!(s,:filaver,:mycadsite,site)
    
    c = MEDYAN.Context(s,grid)
    push!(c.membranes, m)
    

    #Return compartment id by input Contex, Vertexname(membraneindex, vid)
    MEDYAN.helper_update_allverticesincompartments!(c)
    name1 = VertexName(1, 888)
    MEDYAN.get_compartment_id_byvertexname(c,name1)

    #Initiate filament
    nmon = 10
    monomerstates = zeros(MonomerState,10)
    monomerstates[1] = s.state.a.m
    monomerstates[end] = s.state.a.g
    monomerstates[2:end-1] .= s.state.a.k
    nodepositions = [SA[490.0, 200.0, 200.0],SA[502.0, 200.0, 200.0],SA[509.0, 200.0, 200.0]] .+ Ref(corner)
    node_mids = [0, 2, 10, ]
    MEDYAN.chem_newfilament!(c;
            ftid= 1, 
            monomerstates,
            node_mids,
            nodepositions,
        )
        
    @testset "visualization of vertices" begin
        vis = Visualizer()
        draw_context!(vis, c, s)
        num_filament_types= num_filtypes(c)
        setvisible!(vis["/meshcat/grid"],true)
        setvisible!(vis["/meshcat/vertex"],true)
        
        render(vis)
        # delete!(vis)
        # vis = nothing
    end

    @testset "visualization of cadherins" begin
        c1 = deepcopy(c)
        # Add three cadherins in different compartments
        name1 = VertexName(1,999)
        name2 = MonomerName(1,1,7)
        name3 = VertexName(1,222)
        name4 = MonomerName(1,1,0)
        name5 = VertexName(1,777)
        name6 = MonomerName(1,1,1)

        chem_newcadherin!(c1,s.cadherin.filaver,name1=>name2,cadherinstate)# cid = 2
        chem_newcadherin!(c1,s.cadherin.filaver,name3=>name4,cadherinstate)# cid = 1
        chem_newcadherin!(c1,s.cadherin.filaver,name5=>name6,cadherinstate)# cid = 1
        @test all(c1.chemistryengine.fixedcounts[1,:] == [4,2,0])

        # println(c1.cadherindata)
        # println(length(c1.cadherindata[1].states))

        vis1 = Visualizer()
        draw_context!(vis1, c1, s)
    end

end