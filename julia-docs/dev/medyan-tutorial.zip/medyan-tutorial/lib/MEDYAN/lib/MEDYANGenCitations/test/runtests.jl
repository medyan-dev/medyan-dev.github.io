using FileIO, Bibliography
using MEDYAN
using MEDYANGenCitations
using StaticArrays
using Test

@testset "citation generation" begin
    # Most number of citations.
    let
        s = MEDYAN.SysDef(MEDYAN.AgentNames())
        membranemechparams = [
            MEDYAN.MembraneMechParams(),
        ]
    
        c = MEDYAN.Context(s, MEDYAN.CubicGrid((1,1,1), 500.0);
            membranemechparams,
            sharedtypedconfigs = MEDYAN.SharedTypedConfigs(
                meshcurv = Val(MEDYAN.meshcurv_mem3dg),
                bending_mode = Val(:bashkirov),
            ),
        )
        MEDYAN.newmembrane!(c;
            type = 1,
            meshinit = (
                vertlist = [SA[0,0,0], SA[1,0,0], SA[0,1,0]],
                trilist = [SA[1,2,3]],
            ),
        )

        bib = gen_citation(c)
        num_citations = 4
        @test length(bib) == num_citations

        let fname = tempname()
            gen_citation(c; bibtex_file = fname)
            bib2 = load(FileIO.File{format"BIB"}(fname))
            @test length(bib2) == num_citations
            rm(fname)
        end
    end

    # Other conditions.
    let
        s = MEDYAN.SysDef(MEDYAN.AgentNames())
        membranemechparams = [
            MEDYAN.MembraneMechParams(),
        ]
    
        c = MEDYAN.Context(s, MEDYAN.CubicGrid((1,1,1), 500.0);
            membranemechparams,
            sharedtypedconfigs = MEDYAN.SharedTypedConfigs(
                meshcurv = Val(MEDYAN.meshcurv_se),
            ),
        )

        @test length(gen_citation(c)) == 1

        MEDYAN.newmembrane!(c;
            type = 1,
            meshinit = (
                vertlist = [SA[0,0,0], SA[1,0,0], SA[0,1,0]],
                trilist = [SA[1,2,3]],
            ),
        )
    
        @test length(gen_citation(c)) == 2
    end
end