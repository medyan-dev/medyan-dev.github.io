"""
A model for getting smooth 3d paths that look nice.

A path is a collection of 3d points with position linearly interpolated between points.
This model is used by `smoothpath_endpoints_diraway`
"""

using LinearAlgebra
using Random
using StaticArrays
using Flux
using MeshCat
using SmallZarrGroups

"""
Return a path from start to end points, minimum length, pointing ⟂ from start and end unit vectors.

The starting point is the origin,
The start unit vector is x̂ 
The ending position is always in the x,y plane, with positive x and y.
The minlength is 1.0
"""
function smoothpath_endpoints_diraway_loss(output,input)
    dim = 3
    kd = 1.0
    k∠ = 1.0
    endpos2d = input[1:2]
    end_dir = input[3:5]
    end_point = [endpos2d; 0]
    start_point = zero(end_point)
    start_dir = [1.0,0.0,0.0]
    outputpts = reshape(output,dim,:)
    posvect = [start_point outputpts end_point]
    n = size(posvect)[2]
    L0 = (norm(end_point) + 1.0) / (n - 1) 
    energy = 0.0
    #add length energy
    for i in 1:n-1
        pos = posvect[:,i]
        nextpos = posvect[:,i+1]
        L = norm(pos-nextpos)
        energy += 1//2*kd*(L-L0)^2
    end
    #add angle energy
    for i in 2:n-1
        prevpos = posvect[:,i-1]
        pos = posvect[:,i]
        nextpos = posvect[:,i+1]
        r2 = nextpos - pos
        r1 = prevpos - pos
        r̂1 = normalize(r1)
        r̂2 = normalize(r2)
        cosθ = r̂1 ⋅ r̂2
        energy += k∠*(cosθ+1)
    end
    #add boundary conditions to get path ⟂ from start and end unit vectors
    r̂start = normalize(posvect[:,1] - posvect[:,2])
    startcosθ = start_dir ⋅ r̂start
    energy += 1//2*k∠*(startcosθ)^2
    r̂end = normalize(posvect[:,end] - posvect[:,end-1])
    endcosθ = end_dir ⋅ r̂end
    energy += 10*k∠*(endcosθ)^2
    return energy
end

function getrandominput(r=5.0)
    randdir = normalize(randn(3))
    randpos = r*rand(2)
    vcat(randpos,randdir)
end

function main()
    model = Chain(Dense(5, 16, relu), Dense(16, 16, relu), Dense(16, 16, relu), Dense(16, 24))
    function loss(input)
        output = model(input)
        numinputs = size(input)[2]
        sum(1:numinputs) do i
            @views smoothpath_endpoints_diraway_loss(output[:,i],input[:,i])
        end
    end
    numfarinputs = 2*900
    numnearinputs = 2*100
    numinputs = numfarinputs + numnearinputs

    traininput = zeros(Float32, 5, numinputs)
    for i in 1:numfarinputs
        traininput[:,i] .= getrandominput()
    end
    for i in (numfarinputs+1):numinputs
        traininput[:,i] .= getrandominput(0.1)
    end
    opt = ADAM()

    data=[(traininput,)]

    parameters = Flux.params(model)

    for i in 1:2000
        for j in 1:10
            Flux.train!(loss,parameters,data,opt)
        end
        @show loss(traininput)
        @show i
    end
    return model
end



"""
draw a single input
"""
function drawinput!(vis,input,model)
    output = model(input)
    dim = 3
    kd = 1.0
    k∠ = 1.0
    endpos2d = input[1:2]
    end_dir = SVector{dim,eltype(output)}(input[3:5])
    end_point = SVector{dim,eltype(output)}([endpos2d; 0])
    start_point = zero(end_point)
    start_dir = SVector{dim,eltype(output)}([1.0,0.0,0.0])
    outputpts = reinterpret(SVector{dim,eltype(output)},output)
    posvect = [[start_point]; outputpts; [end_point]]
    setobject!(vis["line"], Object(PointCloud(posvect), LineBasicMaterial(), "Line"))
    setobject!(vis["end_dir"], Object(PointCloud([end_point-end_dir,end_point+end_dir]), LineBasicMaterial(), "Line"))
end


model = main()

g = ZGroup()
numarrays = 0
for (i, data) in enumerate(Flux.params(model))
    g["$i"] = convert.(Float32,data)
    global numarrays += 1
end
attrs(g)["Description"] = """
This group contains the Flux parameters for 
a chain of dense layers with relu activation and linear output layer.
""" # an attribute
attrs(g)["numarrays"] = numarrays # an attribute

SmallZarrGroups.save_dir(joinpath(@__DIR__,"model.zarr.zip"), g)

