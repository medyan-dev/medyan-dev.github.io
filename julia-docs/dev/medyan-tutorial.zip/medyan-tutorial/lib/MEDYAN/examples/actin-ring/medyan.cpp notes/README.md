## Email from Haoran

> Hi Nathan,
> 
> This is one pair of input files from actin ring simulations as an example.
> 
> This example is in config “2ring-arp232ff/120uM-lowM-longInit-thin”, and could form 2 thick rings from simulations using an old MEDYAN branch with commit “d55475ef2da574697d8ad4cc58fdac1c37ee17ae”.
> 
> Best,
> 
> Haoran

## Notes from discussion with Haoran

The simulation is in a 4000nm by 4000nm by 400nm grid.
The compartment sizes are 500nm by 500nm by 400nm.

There are different diffusing motor species so that they can be 
added in at two different times during the sim.

Formin acts like a type of monomer, it can disassociate with a depolymerization reaction.

Branching only happens within 500.0nm of the curved side of the bounding cylinder.

Nucleation can happen anywhere inside the bounding cylinder.

See <https://github.com/medyan-dev/medyan/blob/d55475ef2da574697d8ad4cc58fdac1c37ee17ae/src/FilamentInitializer.cpp>

For info on how the filaments are initialized.






