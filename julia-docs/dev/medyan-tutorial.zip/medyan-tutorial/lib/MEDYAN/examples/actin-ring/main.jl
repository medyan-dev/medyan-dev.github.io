import MEDYANSimRunner
using MEDYAN
using StaticArrays
using LinearAlgebra
using Random
using Setfield
using SmallZarrGroups
using OrderedCollections: OrderedDict
using MEDYAN: add_diffusing_count!, get_chem_state


#=
Replicating results of medyan.cpp actin ring simulations in MEDYAN.jl
=#

"Number of steps to take."
const NSTEPS = 1500

"Number of initial filaments"
const INIT_NUM_FILAMENTS = 300

const HEIGHT = 400.0 # nm
const RADIUS = 2000.0 # nm

jobs = ["1",]

global s::MEDYAN.SysDef

"""
Add a filament with type id `ftid` to the Context with random center position in compartment cid and direction.

Return the filament plus tip tag of a new filament.

`monomerstates` is a collection of the `MonomerState` of the monomers in the new filament.

The filament will be inside the mech boundary.

returns false if it fails to add a filament.
returns the new filament plus tip tag if succeeds

The monomer are spaced by the value in the filament type's mechanical parameters.
"""
function nucleate_filament!(c::MEDYAN.Context, cid, mono_states; iterations = 10^9, ftid = 1)
	#get random position in grid
    for i in 1:iterations
        center = MEDYAN.randompoint(c.grid,cid)
        dir = normalize(randn(SVector{3,Float64}))
        n = length(mono_states)
        spacing = c.filamentmechparams[ftid].spacing
        L = n*spacing
        startpos = center - (L/2)*dir
        endpos = center + (L/2)*dir

        inside = MEDYAN.insideboundary(c.mechboundary,startpos) && MEDYAN.insideboundary(c.mechboundary,endpos)
        if inside
            node_mids = [0,]
            node_positions = [startpos,endpos]
            return make_fila!(c;
                type=ftid,
                mono_states,
                node_mids,
                node_positions,
            )
        end
    end
    return false
end

"""
Return the header_dict and context.
This just sets up the empty system,
the initial filaments get added at step 1 in loop.
"""
function setup(job::String; kwargs...)
    agentnames = MEDYAN.AgentNames(
        diffusingspeciesnames= [
            :A, # actin
            :MD, # motor
            :LD, # crosslinker
            :BD, # brancher
            :FO, # formin
            :FOA, # formin actin nucleation intermediate
        ],
        fixedspeciesnames= [
            :branchingfactor, # set to zero to prevent branching, set to one to enable branching in a chemistry voxel.
        ],
        filamentnames= [(:actin,[
                                :AF, # middle actin
                                :PA, # plus end actin
                                :FP, # plus end formin
                                :MA, # minus end actin
                                :freeARP23, #arp23 on minus end of detached daughter filament
                                :boundARP23, #arp23 on minus end of attached daughter filament
                                :bound, # general bound actin
                            ]),
        ],
    )
    xy_grid = round(Int,RADIUS/400*2-0.1,RoundUp)
    z_grid = round(Int,HEIGHT/400-0.1,RoundUp)
    grid = CubicGrid(SA[xy_grid,xy_grid,z_grid],400.0)
    # make cylinder boundary 
    chemboundary = MEDYAN.boundary_cylinder(;
        center=MEDYAN.centerof(grid),
        axis=SA[0,0,HEIGHT],
        radius=RADIUS,
    )
    # offset chemboundary by 10.0 nm
    mechboundoffset = 10.0
    mechboundary = MEDYAN.boundary_cylinder(;
        center=MEDYAN.centerof(grid),
        axis=SA[0,0,HEIGHT-2mechboundoffset],
        radius=RADIUS-mechboundoffset,
        stiffness=100.0,
    )
    # add reactions
    monomerspacing = MEDYAN.ACTIN_FIL_PARAMS.spacing # nm
    begin
        global s= MEDYAN.SysDef(agentnames)

        add_diffusion_coeff!(s, :A,   100.0*0.25E6)
        add_diffusion_coeff!(s, :MD,  1.0*0.25E6  )
        add_diffusion_coeff!(s, :LD,  10.0*0.25E6 )
        add_diffusion_coeff!(s, :BD,  100.0*0.25E6)
        add_diffusion_coeff!(s, :FO,  10.0*0.25E6 )
        add_diffusion_coeff!(s, :FOA, 0.1*0.25E6  )

        add_filament_params!(s, 
            :actin,
            MEDYAN.ACTIN_FIL_PARAMS,
        )

        #motor stepping
        onrate = 0.2
        offrate = 1.7
        dutyratio = onrate/(onrate+offrate)
        motorstepsize = 10
        stepping_rate = MEDYAN.LinkRateMotorStall(
            fs = 90.0,
            k0 = 6.0/(108/4)*((1 - dutyratio) / dutyratio) * onrate,
        )
        function step_motor_affect!(c::MEDYAN.Context; link, place_idx, kwargs...)
            local t = link2tags(c, link)[place_idx]
            local old_place = tag2place(c, t)::FilaMonoIdx
            local new_place = FilaMonoIdx(c, old_place, +motorstepsize)
            # check if the new monomer exists
            place_exists(c, new_place) || return 0
            # check if the new monomer is in the right state
            get_chem_state(c, new_place).monomer_state == c.sys_def.state.actin.AF || return 0
            #set the new monomer states
            update_fila_mono_state!(c, old_place, :AF)
            update_fila_mono_state!(c, new_place, :bound)
            update_link!(c, link; places=@set((nothing, nothing)[place_idx]=new_place))
            1
        end

        MEDYAN.add_link_type!(s;
            name=:motor,
            description="non muscle myosin 2 motor filament",
            places=[MEDYAN.FilaMonoIdx(), MEDYAN.FilaMonoIdx()],
            state= (;numHeads=20,),
            bonds=[
                (;
                    bond=MEDYAN.DistanceRestraint(),
                    input=(1,2),
                    state=(;L0=NaN,),
                    param=(;k=55.0,),
                ),
            ],
            reactions=[
                [
                    (; # unbinding
                        affect! = (c::MEDYAN.Context; link, chem_voxel, kwargs...) -> let
                            local mt, pt = link2tags(c, link)
                            #set the new monomer states
                            update_fila_mono_state!(c, mt, :AF)
                            update_fila_mono_state!(c, pt, :AF)
                            remove_link!(c, link)
                            add_diffusing_count!(c; species=:MD, chem_voxel, amount=+1)
                            1
                        end,
                        rate= MEDYAN.LinkRateMotorCatch(),
                    ),
                    (; # stepping minus end
                        affect! = step_motor_affect!,
                        rate = stepping_rate,
                    ),
                ],
                [
                    (; # stepping plus end
                        affect! = step_motor_affect!,
                        rate = stepping_rate,
                    ),
                ],
            ],
        )

        #motor binding
        site = MEDYAN.Decimated2MonSiteMinAngleRange(
            s.filament.actin,
            s.filament.actin,
            motorstepsize,
            motorstepsize,
            s.state.actin.AF,
            s.state.actin.AF,
            175.0,
            225.0,
            cos(5*π/180),
        )
        add_decimated_2mon_site!(s, :motorbinding, site)
        bindcallback = MEDYAN.SimpleMotorBindCallback(
            s.decimated_2mon_site.motorbinding.id,
            s.link.motor.id,
            30, #max number of heads
            15, #min number of heads
            s.state.actin.bound,
            [s.diffusing.MD=>-1],
        )
        addreactioncallback!(
            s,
            "decimated_2mon_site.motorbinding + diffusing.MD",
            0.2*22*500^3/2,
            1,
            bindcallback,
        )

        MEDYAN.add_link_type!(s;
            name=:crosslinker,
            description="actin crosslinker",
            places=[MEDYAN.FilaMonoIdx(), MEDYAN.FilaMonoIdx()],
            bonds=[
                (;
                    bond=MEDYAN.DistanceRestraint(),
                    input=(1,2),
                    state=(;L0=NaN,),
                    param=(;k=8.0,),
                ),
            ],
            reactions=[
                [
                    (; # unbinding
                        affect! = (c::MEDYAN.Context; link, chem_voxel, kwargs...) -> let
                            local mt, pt = link2tags(c, link)
                            remove_link!(c, link)
                            #set the new monomer states
                            update_fila_mono_state!(c, mt, :AF)
                            update_fila_mono_state!(c, pt, :AF)
                            add_diffusing_count!(c; species=:LD, chem_voxel, amount=+1)
                            1
                        end,
                        rate= MEDYAN.LinkRateSlipBond(f0 = inv(0.24*MEDYAN.default_β), k0 = 0.3),
                    ),
                ],
            ],
        )

        MEDYAN.add_link_type!(s;
            name=:brancher,
            description="actin brancher",
            places=[MEDYAN.FilaMonoIdx(), MEDYAN.FilaMonoIdx()],
            bonds=[
                (;
                    bond=MEDYAN.BranchBendingCosine(),
                    input=(1,2),
                    param=(;kr=5.0, kbend=5.0, cos0=cos(1.22), sin0=sin(1.22)),
                    no_collide=true,
                ),
            ],
            reactions=[
                [
                    (; # unbinding
                        affect! = (c::MEDYAN.Context; link, chem_voxel, kwargs...) -> let
                            local mt, pt = link2tags(c, link)
                            #set the new monomer states
                            update_fila_mono_state!(c, mt, :AF)
                            update_fila_mono_state!(c, pt, :freeARP23)
                            remove_link!(c, link)
                            1
                        end,
                        rate= MEDYAN.LinkRateSlipBond(f0 = inv(0.24*MEDYAN.default_β), k0 = 0.01),
                    ),
                ],
            ],
        )

        #polymerization
        addfilamentend_reaction!(s, :actin, :pp, false,
            [:PA]=>[:AF,:PA], monomerspacing,
            "diffusing.A -->", 0.3852*1E8, 1,
        )
        addfilamentend_reaction!(s, :actin, :mp, true,
            [:MA]=>[:MA,:AF], monomerspacing,
            "diffusing.A -->", 0.0216*1E8, 1,
        )
        # addfilamentend_reaction!(s, :actin, :pfp, false,
        #     [:FP]=>[:AF,:FP], monomerspacing,
        #     "diffusing.A -->", 0.3852*1E8, 1,
        # )

        #depolymerization
        addfilamentend_reaction!(s, :actin, :dpp, false,
            [:AF,:PA]=>[:PA], 0.0,
            "--> diffusing.A", 1.4, 0,
        )
        #minus end depolymerization
        addfilamentend_reaction!(s, :actin, :dmp, true,
            [:MA,:AF]=>[:MA], 0.0,
            "--> diffusing.A", 1.6, 0,
        )



        #crosslinker binding site
        site = MEDYAN.Decimated2MonSiteMinAngleRange(
            s.filament.actin,
            s.filament.actin,
            10,
            10,
            s.state.actin.AF,
            s.state.actin.AF,
            30.0,
            40.0,
            cos(5*π/180)
        )
        add_decimated_2mon_site!(s,:crosslinkbinding,site)
        sitecallback = MEDYAN.SimpleCrosslinkBindCallback(
            s.decimated_2mon_site.crosslinkbinding.id,
            s.link.crosslinker.id,
            s.state.actin.bound,
            [s.diffusing.LD=>-1],
        )
        addreactioncallback!(s,
            "decimated_2mon_site.crosslinkbinding + diffusing.LD",
            0.01*500^3/2,
            1,
            sitecallback,
        )


        # Nucleation by formin
        #1. Generate the intermediate reactant FOA
        MEDYAN.addreaction!(s, "diffusing.A + diffusing.FO --> diffusing.FOA", 0.005*1E8, 1)
        #2. Generate new filament, assume to be fast
        formin_nucleation_callback = let 
            local monomerstates = [s.state.actin.MA,s.state.actin.AF,s.state.actin.FP]
            local ftid = s.filament.actin
            local diffusingids = (s.diffusing.A, s.diffusing.FOA)
            """
            Nucleate a filament
            """
            function formin_nucleation_callback(c::MEDYAN.Context,cid)
                result = nucleate_filament!(c, cid, monomerstates; iterations = 10^6, ftid)
                if result === false
                    return false
                else
                    # now remove diffusing species
                    for sid in diffusingids
                        chem_adddiffusingcount!(c, sid, cid, -1)
                    end
                    return true
                end
            end
        end
        MEDYAN.addreactioncallback!(s, "diffusing.A + diffusing.FOA", 1.0*1E8, 1, formin_nucleation_callback)
        #3. Formin dissociation, rate constant source 2016Fritzsche
        MEDYAN.addfilamentend_reaction!(
            s,
            :actin,
            :formin_end,
            false,
            [:AF, :FP] => [:PA],
            0.0,
            "--> diffusing.FO", 0.01, 0
        )

        #Destruction
        addfilamentendsite!(s,:actin,:destroy_actin_fil,
            MEDYAN.FilamentEndSiteGeneral(false,[s.state.actin.MA,s.state.actin.PA],0.0)
        )
        MEDYAN.addreactioncallback!(s, "filamentendsite.actin.destroy_actin_fil", 1.5, 0,
            MEDYAN.FilamentDestructionCallback(s.filament.actin, s.filamentendsite.actin.destroy_actin_fil.id, [s.diffusing.A=>2])
        )
        addfilamentendsite!(s,:actin,:destroy_actin_formin_fil,
            MEDYAN.FilamentEndSiteGeneral(false,[s.state.actin.MA,s.state.actin.FP],0.0)
        )
        MEDYAN.addreactioncallback!(s, "filamentendsite.actin.destroy_actin_formin_fil", 1.5, 0,
            MEDYAN.FilamentDestructionCallback(s.filament.actin, s.filamentendsite.actin.destroy_actin_formin_fil.id, [s.diffusing.A=>1, s.diffusing.FOA=>1])
        )
        addfilamentendsite!(s,:actin,:destroy_actin_arp23_fil,
            MEDYAN.FilamentEndSiteGeneral(false,[s.state.actin.freeARP23,s.state.actin.PA],0.0)
        )
        MEDYAN.addreactioncallback!(s, "filamentendsite.actin.destroy_actin_arp23_fil", 1.5, 0,
            MEDYAN.FilamentDestructionCallback(s.filament.actin, s.filamentendsite.actin.destroy_actin_arp23_fil.id, [s.diffusing.A=>1, s.diffusing.BD=>1])
        )

        #branching site
        site = MEDYAN.FilamentSiteGeneral(2,fill(s.state.actin.AF,3))
        addfilamentsite!(s, :actin, :branch, site)
        sitecallback = MEDYAN.GeneralFilamentSiteCallback(
            s.filament.actin,
            s.filamentsite.actin.branch.id,
            1,
            [s.state.actin.bound],
            [],
        )
        branchcallback = MEDYAN.FilamentSiteBranchingCallback(
            sitecallback,
            s.link.brancher.id,
            s.filament.actin,
            true,
            true,
            [s.state.actin.boundARP23,s.state.actin.PA],
            [s.diffusing.A=>-1, s.diffusing.BD=>-1],
        )
        addreactioncallback!(s,
            "filamentsite.actin.branch + diffusing.A + diffusing.BD + fixedspecies.branchingfactor",
            0.0001*1E8*1E8,
            2,
            branchcallback,
        )

    end
    c= MEDYAN.Context(s,grid;
        g_tol=1.0,
        max_cylinder_force = 5000.0,
        cylinder_skin_radius = 7.0,
        maxstep = 0.7,
        nthreads = 4,
    )
    set_chemboundary!(c, chemboundary)
    set_mechboundary!(c, mechboundary)

    # add branchingfactor so branching can only take place near the curved side.
    for cid in 1:length(grid)
        if norm(MEDYAN.centerof(grid,cid)[1:2]) > (RADIUS-500)
            chem_addfixedcount!(c,s.fixedspecies.branchingfactor,cid,1)
        end
    end

    header = OrderedDict([
        "medyan"=>MEDYAN.header(c),
    ])
    return header, c
end

"""
Save the context into a group
"""
function save(step::Int, c::MEDYAN.Context; kwargs...)::ZGroup
    group = ZGroup()
    group["medyan"] = MEDYAN.snapshot(c;
        filament_position_scale=5,
        membrane_position_scale=5,
    )
    group
end

"""
Load the context from a group
"""
function load(step::Int, group::ZGroup, c; kwargs...)
    MEDYAN.load_snapshot!(c, group["medyan"]::ZGroup)
    c
end

function done(step::Int, c)
    step ≥ NSTEPS, NSTEPS
end

"""
Move the simulation forward one second in time.
"""
function loop(step::Int, c; kwargs...)
    if step == 1
        #add initial filaments
        numinitmonomers = 9*40
        initmonomerstates = fill(s.state.actin.AF, numinitmonomers)
        initmonomerstates[begin] = s.state.actin.MA
        initmonomerstates[end] = s.state.actin.PA
        filamentCounter = 0
        while filamentCounter < INIT_NUM_FILAMENTS
            # rand filament parallel to the xy plane.
            # must be more than 125 nm away from boundary.
            # must be within 1000 nm of the cylinder curved side.
            #get random position in grid
            local center = MEDYAN.randompoint(c.grid)
            local dir = [normalize(randn(SVector{2,Float64})); 0.0]
            local n = length(initmonomerstates)
            local spacing = c.filamentmechparams[s.filament.actin].spacing
            local L = n*spacing
            local startpos = center - (L/2)*dir
            local endpos = center + (L/2)*dir
            function isinside(x)
                (
                    abs(x[3]) < HEIGHT/2-125 &&
                    norm(x[1:2]) < RADIUS-125 &&
                    norm(x[1:2]) > RADIUS-1000
                )
            end
            if isinside(startpos) && isinside(endpos)
                local node_mids = [0,]
                local node_positions = [startpos,endpos]
                make_fila!(c;
                    type = :actin,
                    mono_states = initmonomerstates,
                    node_mids,
                    node_positions,
                )
                filamentCounter += 1
            end
        end
        #add initial diffusing species
        adddiffusingcount_rand!(c,s.diffusing.A,85560)
        adddiffusingcount_rand!(c,s.diffusing.FO,50)
    elseif step == 101
        adddiffusingcount_rand!(c,s.diffusing.MD,90)
        adddiffusingcount_rand!(c,s.diffusing.LD,600)
        adddiffusingcount_rand!(c,s.diffusing.BD,151)
    elseif step == 501
        adddiffusingcount_rand!(c,s.diffusing.MD,210)
    end
    for j in 1:20
        MEDYAN.run_chemistry!(c,0.005)
        MEDYAN.minimize_energy!(c)
    end
    c
end

if abspath(PROGRAM_FILE) == @__FILE__
    MEDYANSimRunner.run(ARGS; jobs, setup, loop, load, save, done)
end