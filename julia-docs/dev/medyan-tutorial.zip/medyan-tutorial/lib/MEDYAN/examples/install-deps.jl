#!/bin/env julia
using Pkg: Pkg, PackageSpec
Pkg.activate(@__DIR__)
root = relpath(dirname(@__DIR__))
Pkg.develop([
    PackageSpec(path=root),
])
Pkg.instantiate()
# Pkg.build()