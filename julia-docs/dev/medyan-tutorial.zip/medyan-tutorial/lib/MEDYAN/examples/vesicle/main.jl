import MEDYANSimRunner
using MEDYAN
using StaticArrays
using LinearAlgebra
using Random
using Setfield
using OrderedCollections: OrderedDict
using SmallZarrGroups

"Number of steps to take."
const NSTEPS = 100

jobs = ["1"]

"""
Return the header_dict and context.
"""
function setup(job::String; kwargs...)
    agentnames = MEDYAN.AgentNames(
        diffusingspeciesnames = [:a,],
        filamentnames = [
            (:actin, [:plusend, :minusend, :middle, :restrained]),
        ],
        link_2mon_names = [:crosslinker],
    )

    grid = CubicGrid((6,6,6), 500.0)

    monomerspacing= MEDYAN.ACTIN_FIL_PARAMS.spacing

    # Get SysDef.
    s= MEDYAN.SysDef(agentnames)
    add_diffusion_coeff!(s, :a, 2E7)
    add_link_2mon!(s,
        :crosslinker,
        Link2MonState(),
        MEDYAN.DistanceRestraintMechParams(k=100.0),
    )
    #minus end polymerization
    addfilamentend_reaction!(s,
        :actin, #filament type name
        :pm, #new site name
        true, #is minus end
        [:minusend]=>[:minusend,:middle], #change in monomer states
        monomerspacing, #free space needed for reaction (nm)
        "diffusing.a -->", #reaction expression
        0.0173 * 500^3, #rate of reaction ((nm^3)^(invvolumepower)/s)
        1, #inverse volume power
    )
    #plus end polymerization
    addfilamentend_reaction!(s, :actin, :pp, false,
        [:plusend]=>[:middle,:plusend], monomerspacing,
        "diffusing.a -->", 0.154 * 500^3, 1,
    )
    #minus end depolymerization
    addfilamentend_reaction!(s, :actin, :dpm, true,
        [:minusend,:middle]=>[:minusend], 0.0,
        "--> diffusing.a", 0.8, 0,
    )
    #plus end depolymerization
    addfilamentend_reaction!(s, :actin, :dpp, false,
        [:middle,:plusend]=>[:plusend], 0.0,
        "--> diffusing.a", 1.4, 0,
    )
    

    add_filament_params!(s, 
        :actin,
        MEDYAN.ACTIN_FIL_PARAMS,
    )
    membranemechparams = [
        MEDYAN.MembraneMechParams(
            kbend = 100,
            tension = 0.02,
            eqvolume = (4/3) * π * 800^3,
            kvolume = 0.8,
        ),
    ]

    # Create context.
    @info "P build context"
    c= MEDYAN.Context(s,grid;
        membranemechparams,
        g_tol = 0.1,
        sharedtypedconfigs = MEDYAN.SharedTypedConfigs(
            meshcurv = Val(MEDYAN.meshcurv_mem3dg),
        ),
    )
    set_mechboundary!(c, MEDYAN.boundary_box(grid; stiffness=0.01^2))
    MEDYAN.adddiffusingcount_rand!(c, s.diffusing.a, 300000)

    # Initialize filaments.
    @info "P add fil"
    nummon = 30
    monomerstates = fill(s.state.actin.middle, nummon)
    monomerstates[1] = s.state.actin.minusend
    monomerstates[end] = s.state.actin.plusend
    nodepos1 = [SA[1600.0,1600,1600],SA[1600.0+nummon*monomerspacing,1600.0,1600.0]]
    nodepos2 = nodepos1 .+ (SA[0, 100, 100],)

    fid1= MEDYAN.chem_newfilament!(c;
        ftid= s.filament.actin, 
        monomerstates,
        nodepositions = nodepos1,
        node_mids=[0,]
    )
    fid2= MEDYAN.chem_newfilament!(c;
        ftid= s.filament.actin, 
        monomerstates,
        nodepositions = nodepos2,
        node_mids=[0,]
    )
    for i in 1:10
        nodepos2 = nodepos2 .+ (SA[0, 10, 0],)
        fid2= MEDYAN.chem_newfilament!(c;
        ftid= s.filament.actin, 
        monomerstates,
        nodepositions = nodepos2,
        node_mids=[0,]
    )
    end
    @info "P add membrane"
    m1 = newmembrane!(c; type=1, meshinit=MeshInitEllipsoid(center=SA[0,0,0], halfaxes=SA[800,800,800]))
    adapt_membranes!(c; params=MEDYAN.MeshAdaptParams(do_meshsmoothing=true))
    header = OrderedDict([
        "medyan"=>MEDYAN.header(c),
    ])
    return header, c
end

"""
Save the context into a group
"""
function save(step::Int, c::MEDYAN.Context; kwargs...)::ZGroup
    group = ZGroup()
    group["medyan"] = MEDYAN.snapshot(c;
        filament_position_scale=5,
        membrane_position_scale=5,
    )
    group
end

"""
Load the context from a group
"""
function load(step::Int, group::ZGroup, c; kwargs...)
    MEDYAN.load_snapshot!(c, group["medyan"]::ZGroup)
    c
end

function done(step::Int, c; kwargs...)
    step ≥ NSTEPS, NSTEPS
end

"""
Move the simulation forward one second in time.
"""
function loop(step::Int, c; kwargs...)
    MEDYAN.run_chemistry!(c, 0.05)
    @info "P update membrane geo"
    for m ∈ c.membranes
        MEDYAN.compute_geometry!_system(m)
    end
    @info "P build AABB"
    tree = MEDYAN.build_aabbtree_frommeshes(c.membranes)
    @info "P resolve fil-membrane crossing"
    MEDYAN.resolve_all_filament_mesh_crossing!(c, tree)
    @info "P start minimize"
    MEDYAN.minimize_energy!(c)
    @info "P remesh"
    MEDYAN.adapt_membranes!(c)
    c
end


if abspath(PROGRAM_FILE) == @__FILE__
    MEDYANSimRunner.run(ARGS; jobs, setup, loop, load, save, done)
end