# Example Simulations

This directory contains example MEDYAN.jl simulation projects.

The example projects have MEDYAN `dev`ed from the parent directory 

If you want to copy these examples to run a simulation outside of this repo,
make sure to add a specific git commit of MEDYAN.jl to the project. For example,

```
pkg> add "git@github.com:medyan-dev/MEDYAN.jl"#06c3796
```

Otherwise, your simulation may fail to run, or may be non-reproducible.

## Running Examples
Install MEDYANSimRunner.jl
```julia
import Pkg

Pkg.add(url="https://github.com/medyan-dev/MEDYANSimRunner.jl")
```

Then from command line on linux or macos:
```sh
medyansimrunner run examples/vesicle/input/ examples/vesicle/output 1
```

Or from julia:
```julia
import MEDYANSimRunner
MEDYANSimRunner.run("examples/vesicle/input/", "examples/vesicle/output", "1")
```

Visualizing outputs in Paraview:

```julia
using Pkg
pkg"dev lib/MEDYAN2Vtk"
using MEDYAN2Vtk
rm("examples/vesicle/out1.medyanvis"; force=true, recursive=true)
medyan2vtk("examples/vesicle/output/1", "examples/vesicle/out1.medyanvis")
# examples/vesicle/out1.medyanvis/full_simulation.pvd can be opened in paraview.
run(`paraview examples/vesicle/out1.medyanvis/full_simulation.pvd`)
```

## Creating New Example

1. Copy an existing example, and give it a new name.
1. In the `input` directory of the example modify `main.jl` and the local julia environment.
1. `SmallZarrGroups JSON3 LoggingExtras` are required libraries to run the simulation.
1. `main.jl` must define the following functions:
1. `setup(job_idx::String; kwargs...) -> header_dict, state`
2. `save_snapshot(step::Int, state; kwargs...) -> group::SmallZarrGroups.ZGroup`
3. `load_snapshot(step::Int, group::SmallZarrGroups.ZGroup, state; kwargs...) -> state`
4. `done(step::Int, state; kwargs...) -> done::Bool, expected_final_step::Int`
5. `loop(step::Int, state; kwargs...) -> state`

It may be helpful to run a JET analysis on your `main.jl` file to detect errors before running the full simulation.
For example from inside the `input` directory and in the `input` environment.
```julia
using JET
report_file("main.jl"; analyze_from_definitions = true, target_defined_modules=true)
```


