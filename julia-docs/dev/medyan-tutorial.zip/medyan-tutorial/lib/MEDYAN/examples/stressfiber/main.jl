import MEDYANSimRunner
using MEDYAN
using StaticArrays
using LinearAlgebra
using Random
using Setfield
using OrderedCollections: OrderedDict
using SmallZarrGroups


"Number of steps to take."
const NSTEPS = 600

jobs = ["1"]

"""
Return the header_dict and info.
"""
function setup(job::String; kwargs...)
    agentnames = MEDYAN.AgentNames(
        diffusingspeciesnames = [:a, :md, :ld],
        filamentnames = [
            (:actin, [:plusend, :minusend, :middle, :bound, :restrained]),
        ],
        link_2mon_names = [:m, :l],
    )

    grid = CubicGrid((2,2,12), 500.0)

    monomerspacing = MEDYAN.ACTIN_FIL_PARAMS.spacing
    numpercylinder = MEDYAN.ACTIN_FIL_PARAMS.numpercylinder

    # Create SysDef.
    s = MEDYAN.SysDef(agentnames)
    add_diffusion_coeff!(s, :a, 2E7)
    add_diffusion_coeff!(s, :md, 2E5)
    add_diffusion_coeff!(s, :ld, 2E6)

    add_filament_params!(s, 
        :actin,
        MEDYAN.ACTIN_FIL_PARAMS,
    )

    add_link_2mon!(s,
        :l,
        Link2MonState((;), (L0=NaN,)),
        MEDYAN.DistanceRestraintMechParams(k=8.0),
    )
    add_link_2mon!(s,
        :m,
        Link2MonState((numHeads=20,), (L0=NaN,)),
        MEDYAN.DistanceRestraintMechParams(k=2.5),
    )
    #minus end polymerization
    addfilamentend_reaction!(s,
        :actin, #filament type name
        :pm, #new site name
        true, #is minus end
        [:minusend]=>[:minusend,:middle], #change in monomer states
        monomerspacing, #free space needed for reaction (nm)
        "diffusing.a -->", #reaction expression
        0.0173 * 500^3, #rate of reaction ((nm^3)^(invvolumepower)/s)
        1, #inverse volume power
    )
    #plus end polymerization
    addfilamentend_reaction!(s, :actin, :pp, false,
        [:plusend]=>[:middle,:plusend], monomerspacing,
        "diffusing.a -->", 0.154 * 500^3, 1,
    )
    #minus end depolymerization
    addfilamentend_reaction!(s, :actin, :dpm, true,
        [:minusend,:middle]=>[:minusend], 0.0,
        "--> diffusing.a", 0.8, 0,
    )
    #plus end depolymerization
    addfilamentend_reaction!(s, :actin, :dpp, false,
        [:middle,:plusend]=>[:plusend], 0.0,
        "--> diffusing.a", 1.4, 0,
    )

    motorstepsize = 10

    #motor binding
    let
        site = MEDYAN.Decimated2MonSiteMinAngleRange(
            s.filament.actin,
            s.filament.actin,
            motorstepsize,
            motorstepsize,
            s.state.actin.middle,
            s.state.actin.middle,
            175.0,
            225.0,
            cos(5*π/180),
        )
        add_decimated_2mon_site!(s,:motorbinding,site)
    end
	bindcallback = MEDYAN.SimpleMotorBindCallback(
		s.decimated_2mon_site.motorbinding.id,
		s.link_2mon.m,
		30, #max number of heads
		15, #min number of heads
		s.state.actin.bound,
        [s.diffusing.md=>-1],
	)
	addreactioncallback!(
		s,
		"decimated_2mon_site.motorbinding + diffusing.md",
		0.2*22*500^3/2,
		1,
		bindcallback,
	)

	#motor unbinding
    let
    	site = MEDYAN.Link2MonSiteMotorCatch()
	    addunbindinglink_2mon_site!(s, 
            :m, :unbinding, site,
            :actin, :middle, :actin, :middle,
            "--> diffusing.md", 1.0, 0, 
        )
    end

    #motor stepping
    let
        onrate = 0.2
        offrate = 1.7
        dutyratio = onrate/(onrate+offrate)
        site1 = MEDYAN.Link2MonSiteMotorStall(
            fs = 90.0,
            k0 = 6.0/(108/4)*((1 - dutyratio) / dutyratio) * onrate,
            isminusend = true,
        )
        site2 = @set site1.isminusend = false
        add_link_2mon_site!(s,:m,:motorstepminus,site1)
        add_link_2mon_site!(s,:m,:motorstepplus,site2)
        stepcallback1 = MEDYAN.SimpleMotorStepCallback(
            lsid = s.link_2mon_site.m.motorstepminus.id,
            ltid = s.link_2mon.m,
            unboundstate = s.state.actin.middle,
            boundstate = s.state.actin.bound,
            stepsize = motorstepsize,
        )
        stepcallback2 = @set stepcallback1.lsid = s.link_2mon_site.m.motorstepplus.id
        addreactioncallback!(
            s,
            "link_2mon_site.m.motorstepminus",
            1.0,
            0,
            stepcallback1,
        )
        addreactioncallback!(
            s,
            "link_2mon_site.m.motorstepplus",
            1.0,
            0,
            stepcallback2,
        )
    end

    #crosslinker binding site
    let
        site = MEDYAN.Decimated2MonSiteMinAngleRange(
            s.filament.actin,
            s.filament.actin,
            10,
            10,
            s.state.actin.middle,
            s.state.actin.middle,
            30.0,
            40.0,
            cos(5*π/180)
        )
        add_decimated_2mon_site!(s,:crosslinkbinding,site)
        sitecallback = MEDYAN.SimpleCrosslinkBindCallback(
            s.decimated_2mon_site.crosslinkbinding.id,
            s.link_2mon.l,
            s.state.actin.bound,
            [s.diffusing.ld=>-1],
        )
        addreactioncallback!(s,
            "decimated_2mon_site.crosslinkbinding + diffusing.ld",
            0.01*500^3/2,
            1,
            sitecallback,
        )
    end

	#crosslinker unbinding
    let
    	site = MEDYAN.Link2MonSiteSlipBond(f0 = inv(0.24*MEDYAN.default_β) , k0 = 0.3)
	    addunbindinglink_2mon_site!(s, 
            :l, :unbinding, site,
            :actin, :middle, :actin, :middle,
            "--> diffusing.ld", 1.0, 0, 
        )
    end


    # Focal adhesion attachments.
    fids_bot::Vector{Int} = []
    fids_top::Vector{Int} = []
    z0_bot = Ref(250)
    z0_top = Ref(3000)
    xymid = SA[500,500]


    function external_energy_forces!(fc, x)
        local filinfo = fc.filamentindexinfo
        local f = fc.forces
        local energies = fc.energies
        local ftid = 1
        local xy_rmax = 50
        local k_xy = 1e-3
        local k_z = 1
        local k1_xyz = SA[1, 1, 0]
        for fid ∈ fids_bot
            info = filinfo[ftid][fid]
            endid = info.endid
            prange = SVector{3}(3endid-2:3endid)
            p1range = SVector{3}(3endid-5:3endid-3)
            p = x[prange]
            p1 = x[p1range]
            pdiff = p - SA[xymid..., z0_bot[]]
            p1diff = p1 - p
            energies[endid] += 1//2 * k_z * pdiff[3] * pdiff[3]
            f[prange[3]] -= k_z * pdiff[3]
            xy_r = norm(SA[pdiff[1], pdiff[2]])
            if xy_r > xy_rmax
                energies[endid] += 1//2 * k_xy * (xy_r - xy_rmax)^2
                fac = k_xy * (xy_r - xy_rmax) / xy_r
                f[prange[1]] -= fac * pdiff[1]
                f[prange[2]] -= fac * pdiff[2]
            end
            energies[endid] += 1//2 * sum(k1_xyz .* p1diff .* p1diff)
            f[p1range] .-= k1_xyz .* p1diff
            f[prange] .+= k1_xyz .* p1diff
        end
        for fid ∈ fids_top
            info = filinfo[ftid][fid]
            endid = info.endid
            prange = SVector{3}(3endid-2:3endid)
            p1range = SVector{3}(3endid-5:3endid-3)
            p = x[prange]
            p1 = x[p1range]
            pdiff = p - SA[xymid..., z0_top[]]
            p1diff = p1 - p
            energies[endid] += 1//2 * k_z * pdiff[3] * pdiff[3]
            f[prange[3]] -= k_z * pdiff[3]
            xy_r = norm(SA[pdiff[1], pdiff[2]])
            if xy_r > xy_rmax
                energies[endid] += 1//2 * k_xy * (xy_r - xy_rmax)^2
                fac = k_xy * (xy_r - xy_rmax) / xy_r
                f[prange[1]] -= fac * pdiff[1]
                f[prange[2]] -= fac * pdiff[2]
            end
            energies[endid] += 1//2 * sum(k1_xyz .* p1diff .* p1diff)
            f[p1range] .-= k1_xyz .* p1diff
            f[prange] .+= k1_xyz .* p1diff
        end
    end

    # Create context.
    @info "P build context"
    c= MEDYAN.Context(s,grid;
        g_tol = 1.0,
        external_energy_forces!,
    )
    set_mechboundary!(c, MEDYAN.boundary_box(grid; stiffness=5.0))
    MEDYAN.adddiffusingcount_rand!(c, s.diffusing.a, 15000)

    # Initialize filaments.
    @info "P add fil"
    numcyl = 6
    nummon = numpercylinder * numcyl
    monomerstates = fill(s.state.actin.middle, nummon)
    monomerstates[1] = s.state.actin.minusend
    monomerstates[end] = s.state.actin.plusend

    # Create bundle in z direction. Returns fid.
    function createfil(xyradius::Real, z0::Real, zdir::Int)
        eqlen = numpercylinder * monomerspacing
        xy_r = xyradius * sqrt(rand())
        xy_θ = rand() * 2π
        xy = xymid + xy_r * SA[cos(xy_θ), sin(xy_θ)]
        nodepositions = [SA[xy..., z0 + zdir * k * eqlen] for k ∈ numcyl:-1:0]
        node_mids = [numpercylinder * k for k ∈ 0:numcyl-1]
        MEDYAN.chem_newfilament!(c;
            ftid = s.filament.actin,
            monomerstates,
            nodepositions,
            node_mids,
        )
    end

    fids_bot = [createfil(50, z0_bot[], +1) for _ ∈ 1:20]
    fids_top = [createfil(50, z0_top[], -1) for _ ∈ 1:20]
    
    header = OrderedDict([
        "medyan"=>MEDYAN.header(c),
        "z0_bot"=>"Bottom z position in nm",
        "z0_top"=>"Top z position in nm",
    ])
    return header, (; c, s, z0_bot, z0_top)
end

"""
Save the state and context into a group
"""
function save(step::Int, info; kwargs...)::ZGroup
    (; c, s, z0_bot, z0_top) = info
    group = ZGroup()
    attrs(group)["z0_bot"] = z0_bot[]
    attrs(group)["z0_top"] = z0_top[]
    group["medyan"] = MEDYAN.snapshot(c;
        filament_position_scale=5,
        membrane_position_scale=5,
    )
    group
end

"""
Load the context from a group
"""
function load(step::Int, group::ZGroup, info; kwargs...)
    (; c, s, z0_bot, z0_top) = info
    z0_bot[] = attrs(group)["z0_bot"]
    z0_top[] = attrs(group)["z0_top"]
    MEDYAN.load_snapshot!(c, group["medyan"]::ZGroup)
    info
end

function done(step::Int, info)
    step ≥ NSTEPS, NSTEPS
end

"""
Move the simulation forward one second in time.
"""
function loop(step::Int, info; kwargs...)
    (; c, s, z0_bot, z0_top) = info
    time_step = 0.01
    nsteps_per_loop = 100
    link_2mon_added_time = 20.0
    link_2mon_added_substep = round(link_2mon_added_time/time_step)
    for j in 1:nsteps_per_loop
        substep = j-1+step*100
        if link_2mon_added_substep == substep
            MEDYAN.adddiffusingcount_rand!(c, s.diffusing.md, 48)
            MEDYAN.adddiffusingcount_rand!(c, s.diffusing.ld, 240)
        end
        if c.time[] >= 300 && z0_top[] < 3100
            z0_top[] += 5
        end
        MEDYAN.run_chemistry!(c,time_step)
        MEDYAN.minimize_energy!(c)
        yield()
    end
    info
end


if abspath(PROGRAM_FILE) == @__FILE__
    MEDYANSimRunner.run(ARGS; jobs, setup, loop, load, save, done)
end