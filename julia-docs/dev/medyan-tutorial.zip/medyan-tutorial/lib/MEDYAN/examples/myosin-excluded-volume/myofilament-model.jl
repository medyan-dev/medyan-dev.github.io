using MEDYAN
using StaticArrays
using LinearAlgebra
using Setfield
using Random
using OrderedCollections: OrderedDict
using MEDYAN:
    add_link_type!,
    FilaMonoIdx,
    BondConfig,
    bond_energy_force,
    update_link!,
    update_fila_mono_state!,
    make_link!,
    remove_link!,
    get_state,
    get_chem_state,
    get_tags,
    get_position,
    get_directions,
    LinkTag,
    get_link_mechanics

# First create a agent names with actin and myosin filaments
# Also include a myosin end link2mon and a myosin end to actin link
# The motor is the old motor model.
const agent_names = MEDYAN.AgentNames(;
    filamentnames=[
        (:actin, [:middle, :weak_bound, :strong_bound, :bound]),
        (:myo, [:myo,]),
    ],
)

const myo_spacing = 20.0

"""
Parameters for a model of non muscle myosin 2.
"""
@kwdef struct MyosinParameters
    number_of_monomers_per_side::Int
    load_force::Float64 # pN
    on_rate::Float64 # 1/s
    off_rate::Float64 # 1/s
    weak_off_rate::Float64 # 1/s
    weak_on_off_ratio::Float64 # unitless
    step_distance::Float64 # nm
    off_bell_distance::Float64 # nm
    step_bell_distance::Float64 # nm
    myo_motor_mech_params=(;
        k= 0.05,# pN/nm
        maxdist= 50.0, # nm
    )
end

function make_context(p::MyosinParameters; grid = CubicGrid((12,2,2),500.0), g_tol=0.1)

    # Create a SysDef
    s = MEDYAN.SysDef(agent_names)

    "net number of ATP used by myosin, just for tracking purposes"
    used_ATP::Base.RefValue{Int} = Ref(0)

    #define restraints
    add_link_type!(s;
        name=:restraint,
        description="harmonic position restraint",
        places=[FilaMonoIdx(),],
        bonds=[BondConfig(;
            bond=MEDYAN.PositionRestraint(),
            input=(1,),
            param=(;k=0.2),
            state=(;r0=SA[NaN,NaN,NaN]),
        )]
    )
    add_link_type!(s;
        name=:constforce,
        description="constant force",
        places=[FilaMonoIdx(),],
        bonds=[
            BondConfig(;
                bond=MEDYAN.ConstantForce(),
                input=(1,),
                param=(;),
                state=(;f=SA[NaN,NaN,NaN]),
            ),
        ]
    )

    # Add Actin filament parameters
    add_filament_params!(s, :actin, MEDYAN.ACTIN_FIL_PARAMS)

    actin_middle_state::UInt8 = s.state.actin.middle
    actin_weak_bound_state::UInt8 = s.state.actin.weak_bound
    actin_strong_bound_state::UInt8 = s.state.actin.strong_bound

    # Add Myosin filament parameters
    add_filament_params!(s, :myo, MEDYAN.FilamentMechParams(
        radius= 15.0,
        spacing= myo_spacing,
        klength= 10*100.0,
        kangle= 1,
        numpercylinder= 1000,
        max_num_unmin_end= 1,
    ))

    # Define a callback for the myo motor binding reaction
    function bind_motor(c::MEDYAN.Context; link_tag, place, kwargs...)
        if get_chem_state(c, place).monomer_state != actin_middle_state
            return 0 # the monomer is already bound
        end
        local link_state = get_state(c, link_tag)
        local numUnbound::Int = link_state.numUnbound
        local numBound::Int = link_state.numBound

        local new_translation = -p.step_distance/2
        local new_unbound_state = (numBound=numBound+1, numUnbound=numUnbound-1)

        local myo_end_tag = only(get_tags(c,link_tag))
        local m_pos = get_position(c, myo_end_tag)
        local a_pos = get_position(c, place)
        local a_plusvec = get_directions(c, place)[1]
        # get the forces and energies if the motor were to bind.
        E, junk = bond_energy_force(
            MEDYAN.MaxDistanceRestraint(),
            ((m_pos,), (a_pos, a_plusvec),),
            merge(p.myo_motor_mech_params, (translated=new_translation,)),
        )
        # TODO add catch-slip dynamics here. Or not.
        boltzmann_factor = exp(-c.β*E)
        if rand() < boltzmann_factor
            # update the myo_fil_end link2mon number of bound and unbound motors
            update_link!(c, link_tag; state = new_unbound_state)
            # update the state of the bound monomer, setting it to bound to the myo_fil_end link2mon
            update_fila_mono_state!(c, place, actin_weak_bound_state)
            # add a myo_motor link2mon between the monomer and the myo_fil_end link2mon myo filament monomer.
            # This will be used to apply a mechanical force to the myo filament monomer
            make_link!(c;
                link_type = :myo_motor,
                places = (myo_end_tag, place),
                state = (;parent_tag=link_tag,),
                bond_states = ((;translated=new_translation,),),
            )
            return 1
        else
            return 0
        end
    end

    weak_on_rate::Float64 = p.weak_off_rate*p.weak_on_off_ratio
    add_link_type!(s;
        name=:myo_fil_end,
        description="This has no mechanical force field but keeps track of the number of bound and unbound motors at the end of a myosin filament",
        places=[FilaMonoIdx(),],
        state= (;
            numBound = 0,
            numUnbound = 0,
        ),
        reactions=[[
            (; # binding to an actin filament
                affect! = bind_motor,
                rate = ((c::MEDYAN.Context; link_state, kwargs...) -> link_state.numUnbound*weak_on_rate),
                fila_cutoff = (:actin, 150.0), # this should be significantly larger than the myo_fil_end maxdist
            )
        ]]
    )

    # Add myo_motor parameters
    # This has a mechanical force field that is used to apply a force to the myo filament monomer
    add_link_type!(s;
        name = :myo_motor,
        description = "myosin motor",
        places = [FilaMonoIdx(), FilaMonoIdx()],
        state = (;
            parent_tag = LinkTag(),
        ),
        bonds = [
            BondConfig(;
                bond = MEDYAN.MaxDistanceRestraint(),
                input = (1,2,),
                param = p.myo_motor_mech_params,
                state = (translated=NaN,),
            ),
        ],
        reactions = [[
            (; # ADP unbinds, ATP binds, actin unbinds, and ATP hydrolyses
                # A⋅M⋅D
                # Assume Pi rebinding is impossible
                # Assume after ADP unbinds, ATP binding, actin unbinding, and ATP hydrolysis are instant and irreversible.
                # Force dependent unbinding rate.
                affect! = (c::MEDYAN.Context; link_tag, kwargs...) -> let
                    used_ATP[] += 1
                    local link_state = get_state(c, link_tag)
                    local parent_link_tag = link_state.parent_tag
                    local parent_link_state = get_state(c, parent_link_tag)
                    @assert parent_link_state.numBound > 0
                    update_link!(c, parent_link_tag; state = (numBound=parent_link_state.numBound-1, numUnbound=parent_link_state.numUnbound+1,))
                    local myo_end_tag, actin_tag = get_tags(c, link_tag)
                    update_fila_mono_state!(c, actin_tag, actin_middle_state)
                    remove_link!(c, link_tag)
                    1
                end,
                rate = (c::MEDYAN.Context; link_state, link_tag, link_data, kwargs...) -> let
                    # get force on the actin filament and the myosin projected on the positive actin filament direction.
                    local out = get_link_mechanics(c, link_tag, link_data)
                    local F = out.inputs[2][2] ⋅ out.forces[2]
                    p.off_rate*exp(c.β*F*p.off_bell_distance)
                end,
                enabled = false,
            ),
            (; # weak unbinding
                # A-M⋅D⋅Pi
                affect! = (c::MEDYAN.Context; link_tag, kwargs...) -> let
                    local link_state = get_state(c, link_tag)
                    local parent_link_tag = link_state.parent_tag
                    local parent_link_state = get_state(c, parent_link_tag)
                    @assert parent_link_state.numBound > 0
                    update_link!(c, parent_link_tag; state = (numBound=parent_link_state.numBound-1, numUnbound=parent_link_state.numUnbound+1,))
                    local myo_end_tag, actin_tag = get_tags(c, link_tag)
                    update_fila_mono_state!(c, actin_tag, actin_middle_state)
                    remove_link!(c, link_tag)
                    1
                end,
                rate = Returns(p.weak_off_rate),
                enabled = true,
            ),
            (; # power stroke
                # A-M⋅D⋅Pi
                affect! = (c::MEDYAN.Context; link_tag, kwargs...) -> let
                    update_link!(c, link_tag;
                        reaction_enabled = ((true, false, false,),),
                        bond_states = ((translated=p.step_distance/2,),),
                    )
                    update_fila_mono_state!(c, get_tags(c, link_tag)[2], actin_strong_bound_state)
                    1
                end,
                rate = (c::MEDYAN.Context; link_state, link_tag, link_data, kwargs...) -> let
                    local out = get_link_mechanics(c, link_tag, link_data)
                    local F = out.inputs[2][2] ⋅ out.forces[2]
                    p.on_rate*exp(c.β*F*p.step_bell_distance)
                end,
                enabled = true,
            ),
        ]]
    )

    used_ATP[] = 0
    c = MEDYAN.Context(s, grid; cylinder_skin_radius=7.0, g_tol)
    (;c, used_ATP)
end