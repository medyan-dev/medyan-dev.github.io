# run in the examples directory with:
# seq 150 | parallel -j 16 --bar JULIA_LOAD_PATH="@" julia --project --startup-file=no myosin-excluded-volume/main.jl --out=myosin-excluded-volume/output --continue --batch={}

import MEDYANSimRunner
using MEDYAN
using StaticArrays
using LinearAlgebra
using Random
using Setfield
using OrderedCollections: OrderedDict
using SmallZarrGroups
using MEDYAN:
    make_fila!,
    FilaTipIdx

include("myofilament-model.jl")

const NSTEPS = 1000
const Δt = 0.001 #s
const replicates = 50

jobs = String[]

for model in ("nonblocked", "blocked", "none")
    for i in 1:replicates
        push!(jobs, "$(model)/$(i)")
    end
end

"""
Return the header_dict and context.
"""
function setup(job::String; kwargs...)
    myo_params = MyosinParameters(;
        number_of_monomers_per_side=15,
        load_force=0.0,
        on_rate=0.5,
        off_rate=0.35,
        step_distance=6.0,
        off_bell_distance=20.0,
        step_bell_distance=-10.0,
        weak_off_rate=100.0,
        weak_on_off_ratio=1/10,
        myo_motor_mech_params=(;
            k= 0.04,# pN/nm
            maxdist= 30.0, # nm
        ),
    )
    (;c, used_ATP) = make_context(myo_params; grid = CubicGrid((8,8,8),500.0), g_tol=5.0)
    set_mechboundary!(c, MEDYAN.boundary_box(CubicGrid((8,8,8),500.0); stiffness=100.0))
    s = c.sys_def

    # Add an actin filaments
    num_monomers = 1000
    actin_len = num_monomers * MEDYAN.ACTIN_FIL_PARAMS.spacing
    fids = []
    push!(fids, make_fila!(c,
        type=:actin,
        mono_states=fill(s.state.actin.middle, num_monomers),
        node_mids=[0,],
        node_positions= [
            SA[-actin_len/2, 100.0, 0.0],
            SA[+actin_len/2, 100.0, 0.0],
        ]
    ))
    push!(fids, make_fila!(c,
        type=:actin,
        mono_states=fill(s.state.actin.middle, num_monomers),
        node_mids=[0,],
        node_positions= [
            SA[-actin_len/2, -100.0, 0.0],
            SA[+actin_len/2, -100.0, 0.0],
        ]
    ))
    if !startswith(job, "none")
        push!(fids, make_fila!(c,
            type=:actin,
            mono_states=(if startswith(job, "blocked")
                fill(s.state.actin.bound, num_monomers÷2)
            else
                fill(s.state.actin.middle, num_monomers÷2)
            end),
            node_mids=[0,],
            node_positions= [
                SA[0.0, 0.0, -actin_len/2/2],
                SA[0.0, 0.0, +actin_len/2/2],
            ]
        ))
    end
    # restrain filament end
    for fid in fids
        for monomer in (FilaMonoIdx(c, fid, -), FilaMonoIdx(c, fid, +))
            make_link!(c;
                type = :restraint,
                places = (monomer,),
                bond_states = ((;r0 = get_position(c, monomer),) ,),
            )
        end
    end

    # Number of fake myo monomers per myo filament.
    # spacing is 20 nm, this controls the length of the rigid part of the 
    # myo filament, and is independent of the number of heads.
    num_fake_myo_monomers = 3+5+3
    myo_fid = make_fila!(c,
        type = :myo,
        mono_states=fill(0x01, num_fake_myo_monomers),
        node_mids=[0,],
        node_positions= [
            SA[-actin_len/2,  80.0, 0.0],
            SA[-actin_len/2, -80.0, 0.0],
        ]
    )
    myo_minus_end = FilaMonoIdx(c, myo_fid, -)
    myo_plus_end = FilaMonoIdx(c, myo_fid, +)

    make_link!(c;
        type = :myo_fil_end,
        places = (myo_minus_end,),
        state = (;numUnbound=myo_params.number_of_monomers_per_side,),
    )
    make_link!(c;
        type = :myo_fil_end,
        places = (myo_plus_end,),
        state = (;numUnbound=myo_params.number_of_monomers_per_side,),
    )
    

    MEDYAN.minimize_energy!(c;check_closest_cylinders=false)
    header = OrderedDict([
        "medyan"=>MEDYAN.header(c),
    ])
    return header, c
end

"""
Save the context into a group
"""
function save(step::Int, c::MEDYAN.Context; kwargs...)::ZGroup
    group = ZGroup()
    group["medyan"] = MEDYAN.snapshot(c;
        filament_position_scale=8,
        membrane_position_scale=8,
    )
    group
end

"""
Load the context from a group
"""
function load(step::Int, group::ZGroup, c; kwargs...)
    MEDYAN.load_snapshot!(c, group["medyan"]::ZGroup)
    c
end

function done(step::Int, c)
    step ≥ NSTEPS, NSTEPS
end

"""
Move the simulation forward 100 ms in time.
"""
function loop(step::Int, c; output, kwargs...)
    for step in 1:100
        MEDYAN.minimize_energy!(c; brownian_motion_time=Δt)
        MEDYAN.run_chemistry!(c, Δt)
    end
    output["m_pos"] = get_myo_position(c)
    c
end

function get_myo_position(c::MEDYAN.Context)
    fids = filtype_fil_ids(c, c.sys_def.filament.myo)
    p = fil_node_positions(c, c.sys_def.filament.myo, only(fids))
    sum(p)/length(p)
end


if abspath(PROGRAM_FILE) == @__FILE__
    MEDYANSimRunner.run(ARGS; jobs, setup, loop, load, save, done)
end