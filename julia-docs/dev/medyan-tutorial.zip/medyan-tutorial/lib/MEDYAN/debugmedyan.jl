include("benchmarks/filamentbenchmark.jl")
sampleAtraj(10, 1)
