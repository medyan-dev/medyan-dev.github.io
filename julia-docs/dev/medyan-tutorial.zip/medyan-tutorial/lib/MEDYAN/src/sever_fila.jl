# Function to sever a filament


"""
    sever_fila!(c::Context, place::FilaMonoIdx)::Tag{FilaTipIdx}

Return the tag of the new filament plus end.

Calling this will invalidate the chem cache.

The split will happen between `place` 
and the monomer slightly towards the minus end.

The split cannot create a filament with less than 2 monomers.
"""
function sever_fila!(c::Context, place::FilaMonoIdx)::Tag{FilaTipIdx}
    defer_chem_caching!(c)
    ftid = Int64(place.fila_idx.typeid)
    fil_idx = Int64(place.fila_idx.idx)
    mid = place.mono_idx
    cylinders = c.chem_cylinders[ftid]
    new_fid = c.largestfilamentid[ftid]+1
    new_fil_idx = _sever_fila!(cylinders, fil_idx, mid, new_fid)
    c.largestfilamentid[ftid]= new_fid
    # move tag for filament minus tip
    _move_place!(
        _tag_manager(c.link_manager, FilaTipIdx()),
        FilaTipIdx(FilaIdx(ftid, fil_idx), true),
        FilaTipIdx(FilaIdx(ftid, new_fil_idx), true),
    )
    # Add tags for new tips
    new_ftag = tag!(c, FilaTipIdx(FilaIdx(ftid, new_fil_idx), false))
    tag!(c, FilaTipIdx(FilaIdx(ftid, fil_idx), true))
    # move tags for filament monomers
    mon_states = fil_mon_states(c, ftid, new_fid)
    for mono_idx in eachindex(mon_states)
        local t = _tag_manager(c.link_manager, FilaMonoIdx())
        local new_place = FilaMonoIdx(c, FilaIdx(ftid, new_fil_idx), mono_idx)
        local old_place = FilaMonoIdx(c, FilaIdx(ftid, fil_idx), mono_idx)
        _move_place!(
            t,
            old_place,
            new_place,
        )
    end
    foreach(c.cadherindata) do cdata
        for mon_id in eachindex(mon_states)
            local old_name = MonomerName(ftid, plus_fid, mon_id)
            local new_name = MonomerName(ftid, new_fid, mon_id)
            if old_name ∈ cdata.monname_to_cadidx
                change_monomer_name!(cdata, old_name, new_name)
            end
        end
    end
    new_ftag
end