"""
    $(FUNCTIONNAME)(c::Context;
        type=1,
        mono_states,
        node_mids,
        node_positions,
    )::Tag{FilaTipIdx}
Return the tag of the plus tip of the new filament.
Error if the filament isn't initially over 2 monomers long.
Newly added filaments can't be selected from nearby monomers until after minimization.

# Keyword Arguments
- `type=1`: filament type id or symbol.
- `mono_states`: Collection of the `MonomerState` of the monomers in the new filament. 
    In order from minus end to plus end. 
    `length(mono_states)>1`
- `node_positions`: Collection of `SVector{3,Float64}`. The positions of the nodes, monomers are between nodes.
- `node_mids`: Collection of `Integer`. The monomer ids at (slightly plus side of) the `node_positions`
                                     |
                          -----+-----|-----+-----
      minus end <----       M  |  M  | (M) |  M        ----> plus end
                          -----+-----|-----+-----
                                     |
                                     ^ A node_position is indicated by the line.
    
    The monomer id with parenthesis (M) will in `node_mids`
    `length(node_mids) == length(node_positions) - 1`
- `minus_end_mat_dir=nothing`: `SVector{3,Float64}`. The mat direction of the minus end node.
- `joint_twists=nothing`: `Collection of `Float64`. The extra material frame axial rotation at the joints between the cylinders.
- `tip_load_forces=(0.0=>0.0)`: tip load forces, 
    usually don't use this, because load forces will automatically get updated at the next minimization.
"""
function make_fila!(c::Context;
        type::Union{Symbol,Int}=1,
        mono_states,
        node_mids,
        node_positions,
        tip_load_forces=(0.0=>0.0),
        minus_end_mat_dir=nothing,
        joint_twists=nothing,
    )::Tag{FilaTipIdx}
    ftid::Int = _normalize_fila_type(c, type)
    c.stats.make_fila_count += 1
    cylinders = c.chem_cylinders[ftid]
    fil_idx = create_filament!(cylinders;
        monomerstates = mono_states,
        node_mids,
        nodepositions = node_positions,
        minus_end_mat_dir,
        joint_twists,
        endloadforces = tip_load_forces,
        minusend_num_notminimized= length(mono_states),
        plusend_num_notminimized= length(mono_states),
    )
    # add tags for filament tips
    fila_idx = FilaIdx(ftid, fil_idx)
    minus_tip = FilaTipIdx(c, fila_idx, true)
    plus_tip = FilaTipIdx(c, fila_idx, false)
    tag!(c, minus_tip)
    plus_tip_tag = tag!(c, plus_tip)
    if checkall(c.validflags, VFS_SEGMENTS)
        _addfilamentcache!(c, fila_idx)
    end
    helper_check_sitecount_error(c)
    return plus_tip_tag
end

"""
Create a filament and add it to `cylinders`.

The monomers are coarse grained such that every `cylinders.numpercylinder` monomer is a cylinder,
beads are between two monomers and monomers are linearly interpolated between beads.

chem beads are linearly interpolated between `nodepositions` 
    so that the monomers to the right of the beads have ids divisible by `cylinders.numpercylinder`,
    the first and last beads, can be extended from `nodepositions[begin]`, `nodepositions[end]`, so they won't change when a monomer is (de)polymerized.
"""
function create_filament!(cylinders::ChemCylinders;
        monomerstates,
        node_mids,
        nodepositions,
        minus_end_mat_dir=nothing,
        joint_twists=nothing,
        endloadforces=(0.0 => 0.0),
        minusend_num_notminimized=0,
        plusend_num_notminimized=0,
    )
    use_twist = is_twistable(cylinders)
    # If twist is being used, the twists and minus_end_mat_dir must be specified
    @argcheck !use_twist || !isnothing(minus_end_mat_dir)
    @argcheck length(monomerstates)>1 #must have at least 2 monomers
    @argcheck length(nodepositions) ≥ 2
    @argcheck length(node_mids) == length(nodepositions) - 1 || length(node_mids) == length(nodepositions)
    numpercylinder = cylinders.numpercylinder
    full_node_mids = if length(node_mids) == length(nodepositions) - 1
        [copy(node_mids) ; node_mids[begin] + length(monomerstates)]
    else
        @argcheck node_mids[end] == node_mids[begin] + length(monomerstates)
        copy(node_mids)
    end
    chembeadpositions = interpolate_chem_beads(
        full_node_mids,
        convert.(SVector{3, Float64}, nodepositions),
        numpercylinder,
    )
    chem_mat_dir= fill(NAN3, length(chembeadpositions) - 1)
    if use_twist
        let
            local _joint_twists = if isnothing(joint_twists)
                zeros(length(full_node_mids)-2)
            else
                convert.(Float64, joint_twists)
            end
            local chem_joint_twists = interpolate_twist(full_node_mids, _joint_twists, numpercylinder)
            @argcheck length(chem_joint_twists) == length(chembeadpositions) - 2 # first and last beads are not joints
            local t = normalize_fast(chembeadpositions[2] - chembeadpositions[1])
            local m1 = ortho_normalize(minus_end_mat_dir, t)
            # first we calculate how many monomers are between the first input node
            # and the center of the first chemical cylinder
            local mon_offset = numpercylinder/2 - mod(first(full_node_mids), numpercylinder)
            local θm = cylinders.twist_per_monomer
            m1 = rotate_around(m1, t, θm*mon_offset)
            chem_mat_dir[1] = m1
            local hθcyl = θm*numpercylinder/2
            for i in 2:length(chem_mat_dir)
                # rotate to the end of the cylinder
                m1 = rotate_around(m1, t, hθcyl)
                # get next tangent
                local next_t = normalize_fast(chembeadpositions[i+1] - chembeadpositions[i])
                # Discrete parallel transport vector around bend.
                # Discrete Elastic Rods: https://www.cs.columbia.edu/cg/pdfs/143-rods.pdf
                m1 = transport_vector(m1, t, next_t)
                t = next_t
                # now apply excess joint twist and rotate to half way
                m1 = rotate_around(m1, t, chem_joint_twists[i-1] + hθcyl)
                # make orthogonal again incase of rounding errors
                m1 = ortho_normalize(m1, t)
                chem_mat_dir[i] = m1
            end
        end
    end
    return push_new_filament!(cylinders;
        mon_id_first= full_node_mids[begin],
        mon_id_last= full_node_mids[end]-1,
        monomerstates= collect(monomerstates),
        chembeadpositions,
        chem_mat_dir,
        endloadforces,
        minusend_num_notminimized,
        plusend_num_notminimized,
    )
end

function push_new_filament!(cylinders::ChemCylinders;
        mon_id_first,
        mon_id_last,
        monomerstates,
        chembeadpositions,
        chem_mat_dir,
        endloadforces,
        minusend_num_notminimized,
        plusend_num_notminimized,
    )
    fil_idx = length(cylinders.per_fil) + 1
    num_new_cyl = length(chem_mat_dir)
    cyl_idxs = zeros(Int, num_new_cyl)
    for i in 1:num_new_cyl
        cyl_idx = length(cylinders.per_cyl) + 1
        push!(cylinders.per_cyl, DataPerCylinder(;fil_idx))
        cyl_idxs[i] = cyl_idx
    end 
    push!(cylinders.per_fil, DataPerFilament(;
        mon_id_first,
        mon_id_last,
        monomerstates,
        chembeadpositions,
        chem_mat_dir,
        cyl_idxs, 
        endloadforces,
        minusend_num_notminimized,
        plusend_num_notminimized,
    ))
    return fil_idx
end
