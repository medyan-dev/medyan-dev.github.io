"""
    $(FUNCTIONNAME)(c::Context;
        type=1,
        mono_states,
        node_mids,
        node_positions,
    )::Tag{FilaTipIdx}
Return the tag of the plus tip of the new filament.
Error if the filament isn't initially over 2 monomers long.
Newly added filaments can't be selected from nearby monomers until after minimization.

# Keyword Arguments
- `type=1`: filament type id or symbol.
- `mono_states`: Collection of the `MonomerState` of the monomers in the new filament. 
    In order from minus end to plus end. 
    `length(mono_states)>1`
- `node_positions`: Collection of `SVector{3,Float64}`. The positions of the nodes, monomers are between nodes.
- `node_mids`: Collection of `Integer`. The monomer ids at (slightly plus side of) the `node_positions`
                                     |
                          -----+-----|-----+-----
      minus end <----       M  |  M  | (M) |  M        ----> plus end
                          -----+-----|-----+-----
                                     |
                                     ^ A node_position is indicated by the line.
    
    The monomer id with parenthesis (M) will in `node_mids`
    `length(node_mids) == length(node_positions) - 1`
- `tip_load_forces=(0.0=>0.0)`: tip load forces, 
    usually don't use this, because load forces will automatically get updated at the next minimization.
"""
function make_fila!(c::Context;
        type::Union{Symbol,Int}=1,
        mono_states,
        node_mids,
        node_positions,
        tip_load_forces=(0.0=>0.0),
    )::Tag{FilaTipIdx}
    ftid::Int = _normalize_fila_type(c, type)
    c.stats.make_fila_count += 1
    fid = c.largestfilamentid[ftid]+1
    c.largestfilamentid[ftid]= fid
    cylinders = c.chem_cylinders[ftid]
    fil_idx = create_filament!(cylinders;
        fil_id=fid,
        monomerstates = mono_states,
        node_mids,
        nodepositions = node_positions,
        endloadforces = tip_load_forces,
        minusend_num_notminimized= length(mono_states),
        plusend_num_notminimized= length(mono_states),
    )
    # add tags for filament tips
    _fil_idx = FilaIdx(UInt32(ftid), UInt32(fil_idx))
    tag!(c, FilaTipIdx(c, _fil_idx, true))
    plus_tip_tag = tag!(c, FilaTipIdx(c, _fil_idx, false))
    
    if checkall(c.validflags, VFS_SEGMENTS)
        let # helper_resetsegments!(c) helper_resetfilamentsitecounts!(c)
            local monstates = _fil_mon_states(cylinders, fil_idx)
            local mid= firstindex(monstates)
            local cid= get_compartment_id(c, _mon_position(cylinders,fil_idx,mid))
            local seg= Segment(cid= cid,
                        ftid= ftid,
                        fid= fid,
                        midminusend= mid,
                        midplusend= mid,
                        plusend_cid= -1,#plus cid does not exist yet
                        minusend_cid= -1,#minus end does not exist
                        filamentsitecounts= zeros(length(c.filamentsites[ftid])),
                        filamentendsitecounts= zeros(length(c.filamentendsites[ftid])),
            )
            push!(c.compartments[cid].segments[ftid], seg)
            local last_seg= seg
            local last_cid= cid
            for mid in (firstindex(monstates)+1):lastindex(monstates)
                cid= get_compartment_id(c, _mon_position(cylinders,fil_idx,mid))
                if cid==last_cid
                    last_seg.midplusend= mid
                else
                    last_seg.plusend_cid= cid
                    #left last_cid, create new segment
                    #first save filament site counts of last_seg
                    helper_updatesegmentsitecounts!(c, last_seg)
                    seg= Segment(cid= cid,
                        ftid= ftid,
                        fid= fid,
                        midminusend= mid,
                        midplusend= mid,
                        plusend_cid= -1,#plus cid does not exist yet
                        minusend_cid= last_cid,
                        filamentsitecounts= zeros(length(c.filamentsites[ftid])),
                        filamentendsitecounts= zeros(length(c.filamentendsites[ftid])),
                    )
                    push!(c.compartments[cid].segments[ftid], seg)
                    last_seg= seg
                    last_cid= cid
                end
            end
            helper_updatesegmentsitecounts!(c, last_seg)
        end
    end
    helper_check_sitecount_error(c)
    return plus_tip_tag
end

"""
Create a filament and add it to `cylinders`.

The monomers are coarse grained such that every `cylinders.numpercylinder` monomer is a cylinder,
beads are between two monomers and monomers are linearly interpolated between beads.

chem beads are linearly interpolated between `nodepositions` 
    so that the monomers to the right of the beads have ids divisible by `cylinders.numpercylinder`,
    the first and last beads, can be extended from `nodepositions[begin]`, `nodepositions[end]`, so they won't change when a monomer is (de)polymerized.

The `node_mids` are the monomer ids at (slightly plus side of) the `nodepositions`

                                     |
                          -----+-----|-----+-----
      minus end <----       M  |  M  | (M) |  M        ----> plus end
                          -----+-----|-----+-----
                                     |
                                     ^ A nodeposition is indicated by the line.
    
The monomer id with parenthesis (M) will in `node_mids`
"""
function create_filament!(cylinders::ChemCylinders;
        fil_id=1,
        monomerstates,
        node_mids,
        nodepositions,
        endloadforces=(0.0 => 0.0),
        minusend_num_notminimized=0,
        plusend_num_notminimized=0,
    )
    @argcheck length(monomerstates)>1 #must have at least 2 monomers
    @argcheck length(nodepositions) ≥ 2
    @argcheck length(node_mids) == length(nodepositions) - 1 || length(node_mids) == length(nodepositions)
    numpercylinder = cylinders.numpercylinder
    full_node_mids = if length(node_mids) == length(nodepositions) - 1
        [copy(node_mids) ; node_mids[begin] + length(monomerstates)]
    else
        @argcheck node_mids[end] == node_mids[begin] + length(monomerstates)
        copy(node_mids)
    end
    chembeadpositions = interpolate_chem_beads(
        full_node_mids,
        convert.(SVector{3, Float64}, nodepositions),
        Int(numpercylinder),
    )
    fil_idx = length(cylinders.per_fil) + 1
    @argcheck !haskey(cylinders.fil_id_2_idx, fil_id)
    cylinders.fil_id_2_idx[fil_id] = fil_idx
    num_new_cyl = length(chembeadpositions) - 1
    cyl_idxs = zeros(Int, num_new_cyl)
    for i in 1:num_new_cyl
        cyl_idx = length(cylinders.per_cyl) + 1
        push!(cylinders.per_cyl, DataPerCylinder(;fil_id))
        cyl_idxs[i] = cyl_idx
    end 
    push!(cylinders.per_fil, DataPerFilament(;
        id= fil_id,
        mon_id_first= full_node_mids[begin],
        mon_id_last= full_node_mids[end]-1,
        monomerstates= collect(monomerstates),
        chembeadpositions,
        cyl_idxs, 
        endloadforces,
        minusend_num_notminimized,
        plusend_num_notminimized,
    ))
    return lastindex(cylinders.per_fil)
end
