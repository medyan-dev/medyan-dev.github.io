"""
    $(FUNCTIONNAME)(c::Context, p::FilaMonoIdx, state::Union{Symbol,MonomerState})

Update a monomer state.
"""
function update_fila_mono_state!(c::Context, p::FilaMonoIdx, _state::Union{Symbol,MonomerState})
    state::MonomerState = if _state isa Symbol
        c.sys_def.state[p.fila_idx.typeid][_state]
    else
        _state
    end
    c.stats.update_fila_mono_state_count += 1
    ftid = Int64(p.fila_idx.typeid)
    cylinders = c.chem_cylinders[ftid]
    fil_idx = Int64(p.fila_idx.idx)
    mid= p.mid
    _set_mon_state!(cylinders, fil_idx, mid, state)
    # if the segments aren't valid no point in keeping them valid
    if checkall(c.validflags, VFS_SEGMENTS)
        begin #helper_resetfilamentsitecounts!(c)
            fil_id = _get_fila_id(c, p.fila_idx)
            effected_segments = helper_get_filsite_effected_segments(c, ftid, fil_id, mid, mid)
            @assert length(effected_segments) > 0
            for segment in effected_segments
                helper_updatesegmentsitecounts!(c,segment)
            end
        end
        begin # reset links
            helper_reset_links_one_monomer!(c, p)
        end
    end
    helper_check_sitecount_error(c)
    return
end
function update_fila_mono_state!(c::Context, t::Tag{FilaMonoIdx}, state::Union{Symbol,MonomerState})
    update_fila_mono_state!(c, tag2place(c, t), state)
end

function _set_mon_state!(
        cylinders::ChemCylinders,
        fil_idx::Int,
        mon_id::Int,
        newstate::MonomerState,
    )
    mon_id_first = cylinders.per_fil.mon_id_first[fil_idx]
    cylinders.per_fil.monomerstates[fil_idx][mon_id - mon_id_first + 1] = newstate
end
