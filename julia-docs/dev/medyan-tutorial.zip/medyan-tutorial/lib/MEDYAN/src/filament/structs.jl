using StructArrays: StructVector
using ElasticArrays: ElasticArrays, ElasticMatrix

const MonomerState = UInt8

"""
Filament mechanical parameters

$(TYPEDFIELDS)
"""
Base.@kwdef struct FilamentMechParams
    "Cylinder radius (nm)"
    radius::Float64 = NaN

    "Monomer spacing length (nm)"
    spacing::Float64 = NaN

    "Length force constant (pN/nm)"
    klength::Float64 = NaN

    "Bending force constant (pN*nm/rad²)"
    kangle::Float64 = NaN

    "Twisting force constant (pN*nm/rad²)"
    ktwist::Float64 = NaN

    "Twist between monomers (rad)"
    twist_per_monomer::Float64 = NaN

    "Number of monomers per cylinder"
    numpercylinder::Int32 = -1

    "Maximum number of unminimized monomers that can be on an end.
    This should be less than the minimum `radius` of other filaments + `radius`
    divided by `spacing`."
    max_num_unmin_end::Int32 = -1
end

"""
The data indexed by fil_idx.

"""
Base.@kwdef struct DataPerFilament
    "start monomer id"
    mon_id_first::Int

    "last monomer id"
    mon_id_last::Int

    monomerstates::Vector{MonomerState}
    
    "Extend beyond the ends of the filament if the ending monomer id isn't divisible by 
    numpercylinder"
    chembeadpositions::Vector{SVector{3, Float64}}

    "The material direction associated with the center of each chem cylinder"
    chem_mat_dir::Vector{SVector{3, Float64}}

    "cylinder indexes on the filament"
    cyl_idxs::Vector{Int} = []

    "minus end load force => plus end load force"
    endloadforces::Pair{Float64,Float64} = 0.0 => 0.0

    "number of monomers on the minus end that are not tracked for decimated_2mon sites"
    minusend_num_notminimized::Int = 0

    "number of monomers on the plus end that are not tracked for decimated_2mon sites"
    plusend_num_notminimized::Int = 0

    # "starting monomer ids on cylinders on the filament"
    # cyl_start_mids::Vector{Int}
end

"""
The data indexed by cyl_idx.

$(TYPEDFIELDS)
"""
Base.@kwdef struct DataPerCylinder
    "filament idx"
    fil_idx::Int

    exists::Bool = true
end

"""
The data indexed by seg_idx.

A segment is a contiguous piece of a filament with all monomers in one chem voxel.
$(TYPEDFIELDS)
"""
Base.@kwdef struct DataPerSegment
    "filament index"
    fil_idx::Int

    "first monomer id, on minus end"
    midminusend::Int

    "last monomer id, on plus end"
    midplusend::Int

    "chem voxel of the previous segment on the minus end, -1 if no previous segment"
    minusend_chem_voxel::Int32

    "chem voxel of the next segment on the plus end, -1 if no next segment"
    plusend_chem_voxel::Int32
end

"""
Data about filament cylinders during chemistry

One of these exists per filament type.

$(TYPEDFIELDS)
"""
Base.@kwdef struct ChemCylinders
    "filament type id."
    ftid::Int

    "number of monomers per cylinder"
    numpercylinder::Int

    "Twist between monomers, NaN if the filaments don't have twist (rad)"
    twist_per_monomer::Float64

    per_cyl::typeof(StructVector(DataPerCylinder[])) = StructVector(DataPerCylinder[])

    "collection of unused cylinder indexes"
    holes::Vector{Int} = []

    "Indexed by fil_idx, to get data per filament"
    per_fil::typeof(StructVector(DataPerFilament[])) = StructVector(DataPerFilament[])

    # reaction cache
    "filament ends in each chem_voxel indexed by [chem_voxel], [ce_idx] -> fil_idx<<1 | isminusend"
    filamentends::Vector{Vector{UInt32}}

    "filament end site counts indexed by [chem_voxel], [filament end site id, ce_idx]"
    filamentendsitecounts::Vector{ElasticMatrix{Q31f32, Vector{Q31f32}}}

    "segment data indexed by [chem_voxel], [seg_idx]"
    per_seg::Vector{typeof(StructVector(DataPerSegment[]))}

    "filament site counts indexed by [chem_voxel], [filament site id, seg_idx]"
    filamentsitecounts::Vector{ElasticMatrix{Q31f32, Vector{Q31f32}}}
end

function ChemCylinders(
        ftid::Int,
        numpercylinder::Int,
        twist_per_monomer::Float64,
        num_chem_voxels::Int,
        num_fila_sites::Int,
        num_fila_end_sites::Int,
    )
    ChemCylinders(;
        ftid,
        numpercylinder,
        twist_per_monomer,
        filamentends = [UInt32[] for i in 1:num_chem_voxels],
        filamentendsitecounts = [ElasticMatrix{Q31f32}(undef, num_fila_end_sites, 0) for i in 1:num_chem_voxels],
        per_seg = [StructVector(DataPerSegment[]) for i in 1:num_chem_voxels],
        filamentsitecounts = [ElasticMatrix{Q31f32}(undef, num_fila_sites, 0) for i in 1:num_chem_voxels],
    )
end
