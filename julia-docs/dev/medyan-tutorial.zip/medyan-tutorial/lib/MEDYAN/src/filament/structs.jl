using StructArrays: StructVector

const MonomerState = UInt8

"""
The data indexed by fil_idx.

"""
Base.@kwdef struct DataPerFilament
    "filament id"
    id::Int

    "start monomer id"
    mon_id_first::Int

    "last monomer id"
    mon_id_last::Int

    monomerstates::Vector{MonomerState}
    
    "Extend beyond the ends of the filament if the ending monomer id isn't divisible by 
    numpercylinder"
    chembeadpositions::Vector{SVector{3, Float64}}

    "cylinder indexes on the filament"
    cyl_idxs::Vector{Int} = []

    "minus end load force => plus end load force"
    endloadforces::Pair{Float64,Float64} = 0.0 => 0.0

    "number of monomers on the minus end that are not tracked for decimated_2mon sites"
    minusend_num_notminimized::Int = 0

    "number of monomers on the plus end that are not tracked for decimated_2mon sites"
    plusend_num_notminimized::Int = 0

    # "starting monomer ids on cylinders on the filament"
    # cyl_start_mids::Vector{Int}
end

"""
The data indexed by cyl_idx.

$(TYPEDFIELDS)
"""
Base.@kwdef struct DataPerCylinder
    "filament idx"
    fil_idx::Int

    exists::Bool = true
end


"""
Data about filament cylinders during chemisty

One of these exists per filament type.

$(TYPEDFIELDS)
"""
Base.@kwdef struct ChemCylinders
    "filament type id."
    ftid::Int

    "number of monomers per cylinder"
    numpercylinder::Int

    per_cyl::typeof(StructVector(DataPerCylinder[])) = StructVector(DataPerCylinder[])

    "collection of unused cylinder indexes"
    holes::Vector{Int} = []

    fil_id_2_idx::Dict{Int,Int} = Dict()

    "Indexed by fil_idx, to get data per filament"
    per_fil::typeof(StructVector(DataPerFilament[])) = StructVector(DataPerFilament[])

end
