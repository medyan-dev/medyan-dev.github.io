"""
    sever_fila!(c::Context, place::FilaMonoIdx)::Tag{FilaTipIdx}

Return the tag of the new filament plus end.

Calling this will invalidate the chem cache.

The split will happen between `place` 
and the monomer slightly towards the minus end.

The split cannot create a filament with less than 2 monomers.
"""
function sever_fila!(c::Context, place::FilaMonoIdx)::Tag{FilaTipIdx}
    defer_chem_caching!(c)
    ftid = Int64(place.fila_idx.typeid)
    fil_idx = Int64(place.fila_idx.idx)
    mid = place.mid
    cylinders = c.chem_cylinders[ftid]
    new_fid = c.largestfilamentid[ftid]+1
    new_fil_idx = _sever_fila!(cylinders, fil_idx, mid, new_fid)
    c.largestfilamentid[ftid]= new_fid
    # move tag for filament minus tip
    _move_place!(
        _tag_manager(c.link_manager, FilaTipIdx()),
        FilaTipIdx(FilaIdx(ftid, fil_idx), true),
        FilaTipIdx(FilaIdx(ftid, new_fil_idx), true),
    )
    # Add tags for new tips
    new_ftag = tag!(c, FilaTipIdx(FilaIdx(ftid, new_fil_idx), false))
    tag!(c, FilaTipIdx(FilaIdx(ftid, fil_idx), true))
    # move tags for filament monomers
    mon_states = fila_mono_states(c, _get_fila_idx(c, ftid, new_fid))
    for mid in eachindex(mon_states)
        local t = _tag_manager(c.link_manager, FilaMonoIdx())
        local new_place = FilaMonoIdx(c, FilaIdx(ftid, new_fil_idx), mid)
        local old_place = FilaMonoIdx(c, FilaIdx(ftid, fil_idx), mid)
        _move_place!(
            t,
            old_place,
            new_place,
        )
    end
    new_ftag
end

"""
Split a filament, return the new `fil_idx`, .
`mon_id` is just to the plus end of the split.
`new_fil_id` is the filament id to assign to the new filament.
Existing filament `fil_idx` are not modified, the new filament is appended.
Monomers on the minus end of the split are added added to the new filament.
Both filaments are marked as not minimized.
"""
function _sever_fila!(cylinders::ChemCylinders, fil_idx, mon_id::Int, new_fil_id)
    numpercylinder = cylinders.numpercylinder
    fil = LazyRow(cylinders.per_fil, fil_idx)
    mon_id_first = fil.mon_id_first
    mon_id_last = fil.mon_id_last
    @argcheck mon_id > mon_id_first+1
    @argcheck mon_id < mon_id_last
    new_fil_idx = length(cylinders.per_fil) + 1
    @argcheck !haskey(cylinders.fil_id_2_idx, new_fil_id)
    cylinders.fil_id_2_idx[new_fil_id] = new_fil_idx
    fil_cyl_idx, mon_frac = get_fil_chem_cyl_idx_frac(
        mon_id,
        mon_id_first,
        mon_id_last,
        numpercylinder,
    )
    plus_cyl_idxs = fil.cyl_idxs[fil_cyl_idx:end]
    plus_chembeadpositions = fil.chembeadpositions[fil_cyl_idx:end]
    plus_monomerstates = fil.monomerstates[mon_id-mon_id_first+begin:end]
    minus_monomerstates = fil.monomerstates[begin:mon_id-mon_id_first+begin-1]
    if mod(mon_id, numpercylinder) == 0
        # no new cylinders are needed
        minus_cyl_idxs = fil.cyl_idxs[begin:fil_cyl_idx-1]
        minus_chembeadpositions = fil.chembeadpositions[begin:fil_cyl_idx]
    else
        # one new cylinder is needed
        new_cyl_idx = length(cylinders.per_cyl) + 1
        minus_cyl_idxs = [fil.cyl_idxs[begin:fil_cyl_idx-1]; new_cyl_idx;]
        minus_chembeadpositions = fil.chembeadpositions[begin:fil_cyl_idx+1]
        push!(cylinders.per_cyl, DataPerCylinder(;fil_id = new_fil_id))
    end
    for cyl_idx in minus_cyl_idxs
        cylinders.per_cyl.fil_id[cyl_idx] = new_fil_id
    end
    # add minus end filament
    push!(cylinders.per_fil, DataPerFilament(;
        id= new_fil_id,
        mon_id_first= mon_id_first,
        mon_id_last= mon_id-1,
        monomerstates= minus_monomerstates,
        chembeadpositions= minus_chembeadpositions,
        cyl_idxs= minus_cyl_idxs, 
        minusend_num_notminimized= length(minus_monomerstates),
        plusend_num_notminimized= length(minus_monomerstates),
    ))
    # update plus end filament
    fil.mon_id_first = mon_id
    fil.monomerstates = plus_monomerstates
    fil.chembeadpositions = plus_chembeadpositions
    fil.cyl_idxs = plus_cyl_idxs
    fil.minusend_num_notminimized = length(plus_monomerstates)
    fil.plusend_num_notminimized = length(plus_monomerstates)
    fil.endloadforces = cylinders.per_fil[new_fil_idx].endloadforces
    new_fil_idx
end
