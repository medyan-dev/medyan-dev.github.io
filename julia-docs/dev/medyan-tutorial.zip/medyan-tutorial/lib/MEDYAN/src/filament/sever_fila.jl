"""
    sever_fila!(c::Context, place::FilaMonoIdx)::Tag{FilaTipIdx}

Return the tag of the new filament plus end.

The split will happen between `place` 
and the monomer slightly towards the minus end.

The split cannot create a filament with less than 2 monomers.
"""
function sever_fila!(c::Context, place::FilaMonoIdx)::Tag{FilaTipIdx}
    plus_fila_idx = place.fila_idx
    ftid = Int64(plus_fila_idx.typeid)
    plus_fil_idx = Int64(plus_fila_idx.idx)
    mid = place.mid
    cylinders = c.chem_cylinders[ftid]
    # Delete segments and filament end caches for the severed filament
    if checkall(c.validflags, VFS_SEGMENTS)
        _deletefilamentcache!(c, plus_fila_idx)
    end
    minus_fil_idx = _sever_fila!(cylinders, plus_fil_idx, mid)
    minus_fila_idx = FilaIdx(ftid, minus_fil_idx)
    # move tag for filament minus tip
    _move_place!(
        _tag_manager(c.link_manager, FilaTipIdx()),
        FilaTipIdx(plus_fila_idx, true),
        FilaTipIdx(minus_fila_idx, true),
    )
    # Add tags for new tips
    new_ftag = tag!(c, FilaTipIdx(minus_fila_idx, false))
    tag!(c, FilaTipIdx(plus_fila_idx, true))
    # move tags for filament monomers
    for mid in fila_mono_ids(c, minus_fila_idx)
        _move_place!(
            _tag_manager(c.link_manager, FilaMonoIdx()),
            FilaMonoIdx(c, plus_fila_idx, mid),
            FilaMonoIdx(c, minus_fila_idx, mid),
        )
    end
    # Recreate segments and filament end caches for both filaments
    if checkall(c.validflags, VFS_SEGMENTS)
        for fila_idx in (minus_fila_idx, plus_fila_idx)
            _addfilamentcache!(c, fila_idx)
        end
        helper_reset_links_one_monomer!(c, FilaMonoIdx(c, plus_fila_idx, -))
        helper_reset_links_one_monomer!(c, FilaMonoIdx(c, minus_fila_idx, +))
    end
    helper_check_sitecount_error(c)
    new_ftag
end

"""
Split a filament, return the new `fil_idx`, .
`mon_id` is just to the plus end of the split.
`new_fil_id` is the filament id to assign to the new filament.
Existing filament `fil_idx` are not modified, the new filament is appended.
Monomers on the minus end of the split are added added to the new filament.
Both filaments are marked as not minimized.
"""
function _sever_fila!(cylinders::ChemCylinders, fil_idx, mon_id::Int)
    numpercylinder = cylinders.numpercylinder
    fil = LazyRow(cylinders.per_fil, fil_idx)
    mon_id_first = fil.mon_id_first
    mon_id_last = fil.mon_id_last
    @argcheck mon_id > mon_id_first+1
    @argcheck mon_id < mon_id_last
    new_fil_idx = length(cylinders.per_fil) + 1
    fil_cyl_idx, mon_frac = get_fil_chem_cyl_idx_frac(
        mon_id,
        mon_id_first,
        mon_id_last,
        numpercylinder,
    )
    plus_cyl_idxs = fil.cyl_idxs[fil_cyl_idx:end]
    plus_chem_mat_dir = fil.chem_mat_dir[fil_cyl_idx:end]
    plus_chembeadpositions = fil.chembeadpositions[fil_cyl_idx:end]
    plus_monomerstates = fil.monomerstates[mon_id-mon_id_first+begin:end]
    minus_monomerstates = fil.monomerstates[begin:mon_id-mon_id_first+begin-1]
    if mod(mon_id, numpercylinder) == 0
        # no new cylinders are needed
        minus_cyl_idxs = fil.cyl_idxs[begin:fil_cyl_idx-1]
        minus_chem_mat_dir = fil.chem_mat_dir[begin:fil_cyl_idx-1]
        minus_chembeadpositions = fil.chembeadpositions[begin:fil_cyl_idx]
    else
        # one new cylinder is needed
        new_cyl_idx = length(cylinders.per_cyl) + 1
        minus_cyl_idxs = [fil.cyl_idxs[begin:fil_cyl_idx-1]; new_cyl_idx;]
        minus_chem_mat_dir = fil.chem_mat_dir[begin:fil_cyl_idx]
        minus_chembeadpositions = fil.chembeadpositions[begin:fil_cyl_idx+1]
        push!(cylinders.per_cyl, DataPerCylinder(;fil_idx = new_fil_idx))
    end
    for cyl_idx in minus_cyl_idxs
        cylinders.per_cyl.fil_idx[cyl_idx] = new_fil_idx
    end
    # add minus end filament
    push!(cylinders.per_fil, DataPerFilament(;
        mon_id_first= mon_id_first,
        mon_id_last= mon_id-1,
        monomerstates= minus_monomerstates,
        chembeadpositions= minus_chembeadpositions,
        chem_mat_dir= minus_chem_mat_dir,
        cyl_idxs= minus_cyl_idxs, 
        minusend_num_notminimized= length(minus_monomerstates),
        plusend_num_notminimized= length(minus_monomerstates),
    ))
    # update plus end filament
    fil.mon_id_first = mon_id
    fil.monomerstates = plus_monomerstates
    fil.chembeadpositions = plus_chembeadpositions
    fil.chem_mat_dir = plus_chem_mat_dir
    fil.cyl_idxs = plus_cyl_idxs
    fil.minusend_num_notminimized = length(plus_monomerstates)
    fil.plusend_num_notminimized = length(plus_monomerstates)
    fil.endloadforces = cylinders.per_fil[new_fil_idx].endloadforces
    new_fil_idx
end
