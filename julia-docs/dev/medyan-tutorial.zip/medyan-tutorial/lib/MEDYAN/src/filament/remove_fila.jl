"""
    $(FUNCTIONNAME)(c::Context, filaidx::Union{FilaIdx, Tag})
Remove the filament.

Unlink any monomers or tips on the filament that are referenced by any links.
The links will not be removed, but will have a null reference.
"""
function remove_fila!(c::Context, fila_idx::FilaIdx)
    ftid = Int64(fila_idx.typeid)
    cylinders = c.chem_cylinders[ftid]
    fil_idx = Int64(fila_idx.idx)
    c.stats.remove_fila_count += 1
    monstates = fila_mono_states(c, fila_idx)
    # update links to remove references to the place
    for dir in (false, true)
        helper_removeplace!(c, FilaTipIdx(c, fila_idx, dir); warn_if_unlink=false)
    end
    for mid in eachindex(monstates)
        helper_removeplace!(c, FilaMonoIdx(c, fila_idx, mid); warn_if_unlink=false)
    end
    #Delete segments and filament end caches
    if checkall(c.validflags, VFS_SEGMENTS)
        for dir in (false, true)
            local tip = FilaTipIdx(c, fila_idx, dir)
            _pop_fila_end!(c, get_compartment_id(c, get_position(c, FilaMonoIdx(c, tip))), tip)
        end
        mid = firstindex(monstates)
        chem_voxel::Int = get_compartment_id(c, get_position(c, FilaMonoIdx(fila_idx, mid)))
        while true
            local per_seg = cylinders.per_seg[chem_voxel]
            local seg_idx = _find_segment(per_seg, FilaMonoIdx(fila_idx, mid))
            local seg = per_seg[seg_idx]
            helper_deletesegment!(c, chem_voxel, ftid, seg_idx)
            chem_voxel = seg.plusend_chem_voxel
            mid = seg.midplusend + 1
            chem_voxel == -1 && break
        end
    end
    changed_fil_idx = remove_filament!(cylinders, fil_idx)
    if !isnothing(changed_fil_idx)
        let changed_fil_idx = changed_fil_idx
            # move tags on filament that changed index
            local old_fil_idx, new_fil_idx = changed_fil_idx
            local old_fila_idx = FilaIdx(ftid, old_fil_idx)
            local new_fila_idx = FilaIdx(ftid, new_fil_idx)
            local monstates = fila_mono_states(c, new_fila_idx)
            # move tags for filament tips
            for dir in (false, true)
                _move_place!(
                    _tag_manager(c.link_manager, FilaTipIdx()),
                    FilaTipIdx(c, old_fila_idx, dir),
                    FilaTipIdx(c, new_fila_idx, dir),
                )
            end
            # move tags for filament monomers
            for mid in eachindex(monstates)
                local t = _tag_manager(c.link_manager, FilaMonoIdx())
                local new_place = FilaMonoIdx(c, new_fila_idx, mid)
                local old_place = FilaMonoIdx(c, old_fila_idx, mid)
                _move_place!(
                    t,
                    old_place,
                    new_place,
                )
            end
            # fix filamentends and segments
            if checkall(c.validflags, VFS_SEGMENTS)
                for dir in (false, true)
                    local chem_voxel = get_compartment_id(c, get_position(c, FilaMonoIdx(c, FilaTipIdx(new_fila_idx, dir))))
                    local ce_idx = _find_fila_end(cylinders, chem_voxel, FilaTipIdx(old_fila_idx, dir))
                    @assert cylinders.filamentends[chem_voxel][ce_idx] == old_fil_idx<<1 | dir
                    cylinders.filamentends[chem_voxel][ce_idx] = new_fil_idx<<1 | dir
                end
                local mid = firstindex(monstates)
                local chem_voxel::Int = get_compartment_id(c, get_position(c, FilaMonoIdx(new_fila_idx, mid)))
                while true
                    local per_seg = cylinders.per_seg[chem_voxel]
                    local seg_idx = _find_segment(per_seg, FilaMonoIdx(old_fila_idx, mid))
                    @assert per_seg.fil_idx[seg_idx] == old_fil_idx
                    per_seg.fil_idx[seg_idx] = new_fil_idx
                    chem_voxel = per_seg.plusend_chem_voxel[seg_idx]
                    mid = per_seg.midplusend[seg_idx] + 1
                    chem_voxel == -1 && break
                end
            end
        end
    end
    helper_check_sitecount_error(c)
    return
end
function remove_fila!(c::Context, fila_idx::Tag)
    remove_fila!(c, FilaIdx(c, fila_idx))
end

"""
Remove a filament and its cylinders.

Filament indexes can change from this.
"""
function remove_filament!(cylinders::ChemCylinders, fil_idx)
    fil_id = cylinders.per_fil.id[fil_idx]
    endfil_idx = length(cylinders.per_fil)
    cyl_idxs = cylinders.per_fil.cyl_idxs[fil_idx]
    for cyl_idx in cyl_idxs
        @assert cylinders.per_cyl.exists[cyl_idx]
        push!(cylinders.holes, cyl_idx)
        cylinders.per_cyl.exists[cyl_idx] = false
    end
    if fil_idx == endfil_idx
        # deleted filament is at end, so just pop
        pop!(cylinders.per_fil)
        delete!(cylinders.fil_id_2_idx, fil_id)
        nothing
    else
        # swap last filament in then pop
        endfil_id = cylinders.per_fil.id[endfil_idx]
        cylinders.per_fil[fil_idx] = cylinders.per_fil[endfil_idx]
        cylinders.fil_id_2_idx[endfil_id] = fil_idx
        pop!(cylinders.per_fil)
        delete!(cylinders.fil_id_2_idx, fil_id)
        swapped_cyl_idxs = cylinders.per_fil.cyl_idxs[fil_idx]
        for cyl_idx in swapped_cyl_idxs
            @assert cylinders.per_cyl.exists[cyl_idx]
            cylinders.per_cyl.fil_idx[cyl_idx] = fil_idx
        end
        endfil_idx => fil_idx
    end
end
