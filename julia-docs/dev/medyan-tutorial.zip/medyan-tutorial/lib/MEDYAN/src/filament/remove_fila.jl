"""
    $(FUNCTIONNAME)(c::Context, filaidx::Union{FilaIdx, Tag})
Remove the filament.

Unlink any monomers or tips on the filament are referenced by any links.
The links will not be removed, but will have a null reference.
"""
function remove_fila!(c::Context, fila_idx::FilaIdx)
    fid = _get_fila_id(c, fila_idx)
    ftid = fila_idx.typeid
    c.stats.remove_fila_count += 1
    monstates = fila_mono_states(c, fila_idx)
    # update links to remove references to the place
    for dir in (false, true)
        helper_removeplace!(c, FilaTipIdx(c, fila_idx, dir); warn_if_unlink=false)
    end
    for mid in eachindex(monstates)
        helper_removeplace!(c, FilaMonoIdx(c, fila_idx, mid); warn_if_unlink=false)
    end
    #Delete segments
    if checkall(c.validflags, VFS_SEGMENTS)
        firstname = MonomerName(ftid,fid,firstindex(monstates))
        cid = get_compartment_id(c,firstname)
        sid, seg = findsegment(c.compartments[cid],firstname)
        while !isplusendsegment(seg)
            nextcid = seg.plusend_cid
            comp = c.compartments[nextcid]
            name = MonomerName(ftid,fid,seg.midplusend+1)
            nextsid, seg = findsegment(comp,name)
            helper_deletesegment!(c, cid, ftid, sid)
            cid = nextcid
            sid = nextsid
        end
        helper_deletesegment!(c, cid, ftid, sid)
    end
    cylinders = c.chem_cylinders[ftid]
    changed_fil_idx = remove_filament!(cylinders, fid)
    if !isnothing(changed_fil_idx)
        let changed_fil_idx = changed_fil_idx
            # move tags on filament that changed index
            local old_fil_idx, new_fil_idx = changed_fil_idx
            local old_fila_idx = FilaIdx(ftid, old_fil_idx)
            local new_fila_idx = FilaIdx(ftid, new_fil_idx)
            # move tags for filament tips
            for dir in (false, true)
                _move_place!(
                    _tag_manager(c.link_manager, FilaTipIdx()),
                    FilaTipIdx(c, old_fila_idx, dir),
                    FilaTipIdx(c, new_fila_idx, dir),
                )
            end
            # move tags for filament monomers
            for mono_idx in eachindex(fila_mono_states(c, new_fila_idx))
                local t = _tag_manager(c.link_manager, FilaMonoIdx())
                local new_place = FilaMonoIdx(c, new_fila_idx, mono_idx)
                local old_place = FilaMonoIdx(c, old_fila_idx, mono_idx)
                _move_place!(
                    t,
                    old_place,
                    new_place,
                )
            end
        end
    end
    helper_check_sitecount_error(c)
    return
end
function remove_fila!(c::Context, fila_idx::Tag)
    remove_fila!(c, FilaIdx(c, fila_idx))
end

"""
Remove a filament and its cylinders.

Filament indexes can change from this.
"""
function remove_filament!(cylinders::ChemCylinders, fil_id)
    fil_idx = cylinders.fil_id_2_idx[fil_id]
    endfil_idx = length(cylinders.per_fil)
    cyl_idxs = cylinders.per_fil.cyl_idxs[fil_idx]
    for cyl_idx in cyl_idxs
        @assert cylinders.per_cyl.exists[cyl_idx]
        push!(cylinders.holes, cyl_idx)
        cylinders.per_cyl.exists[cyl_idx] = false
    end
    if fil_idx == endfil_idx
        # deleted filament is at end, so just pop
        pop!(cylinders.per_fil)
        delete!(cylinders.fil_id_2_idx, fil_id)
        nothing
    else
        # swap last filament in then pop
        endfil_id = cylinders.per_fil.id[endfil_idx]
        cylinders.per_fil[fil_idx] = cylinders.per_fil[endfil_idx]
        cylinders.fil_id_2_idx[endfil_id] = fil_idx
        pop!(cylinders.per_fil)
        delete!(cylinders.fil_id_2_idx, fil_id)
        endfil_idx => fil_idx
    end
end
