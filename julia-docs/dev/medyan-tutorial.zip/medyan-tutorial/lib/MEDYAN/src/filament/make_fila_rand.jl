"""
    $(FUNCTIONNAME)(c::Context, mono_states; iterations = 10^9, type = 1)::Tag{FilaTipIdx}
Add a filament to the Context with random center position and direction.

Return the tag of the plus tip of the new filament.

`mono_states` is a collection of the `MonomerState` of the monomers in the new filament.

The filament will be inside the mech boundary.

Errors if it fails to add a filament.

The monomer are spaced by the value in the filament type's mechanical parameters.

# Keyword Arguments
- `type=1`: filament type id or symbol.
- `iterations = 10^9`: number of positions to try before failing with an error.
"""
function make_fila_rand!(c::Context, mono_states; iterations = 10^9, type::Union{Symbol,Int}=1,)
    ftid::Int = _normalize_fila_type(c, type)
    #get random position in grid
    for i in 1:iterations
        center = randompoint(c.grid)
        dir = normalize_fast(randn(SVector{3,Float64}))
        n = length(mono_states)
        spacing = c.filamentmechparams[ftid].spacing
        L = n*spacing
        startpos = center - (L/2)*dir
        endpos = center + (L/2)*dir

        inside = insideboundary(c.mechboundary,startpos) && insideboundary(c.mechboundary,endpos)
        if inside
            node_mids = [0,]
            nodepositions = [startpos,endpos]
            return make_fila!(c;
                type=ftid,
                mono_states,
                node_mids,
                node_positions=nodepositions,
                minus_end_mat_dir=randn(SVector{3,Float64}),
            )
        end
    end
    error("failed to add new filament")
end
