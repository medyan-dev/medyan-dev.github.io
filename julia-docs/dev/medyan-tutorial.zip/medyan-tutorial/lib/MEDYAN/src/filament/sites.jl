"""
Commonly used filament sites
"""

import JET

"""
Test that a type follows the interface and check for basic errors
"""
function statictest_filamentsite(sitetype::Type)
    JET.report_call(
        (sitetype, Vector{MonomerState});
        # print_inference_success=false,
    ) do site, states
        getplusrange(site)::Integer
        getminusrange(site)::Integer
        filamentsitecount(site,states)::Float64
    end
end


"""$PUBLIC
General filament site just matches monomer states

$(TYPEDFIELDS)
"""
struct FilamentSiteGeneral
    "index of center monomer in states"
    center::Int

    "monomer states to match"
    states::Vector{MonomerState}
end

Base.:(==)(a::T,b::T) where T<:FilamentSiteGeneral = struct_equal(a, b)
Base.hash(x::FilamentSiteGeneral, h::UInt) = struct_hash(x,h)

getplusrange(site::FilamentSiteGeneral) = length(site.states) - site.center

getminusrange(site::FilamentSiteGeneral) = site.center-1

function filamentsitecount(site::FilamentSiteGeneral,states)::Float64
    if states==site.states
        return 1.0
    else
        return 0.0
    end
end