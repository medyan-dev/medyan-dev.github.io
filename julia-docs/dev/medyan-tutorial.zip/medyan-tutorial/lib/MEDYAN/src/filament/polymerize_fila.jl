"""
    $(FUNCTIONNAME)(c::Context, fila_tip_idx::FilaTipIdx, newstate::Union{Symbol,MonomerState})
Add a monomer with state `newstate` to the end of the filament.

This doesn't affect the other monomer states, positions, or change any of the monomer ids.
New monomers are not linkable until after minimization.
"""
function polymerize_fila!(c::Context, fila_tip_idx::FilaTipIdx, _state::Union{Symbol,MonomerState})
    newstate::MonomerState = if _state isa Symbol
        c.sys_def.state[fila_tip_idx.fila_idx.typeid][_state]
    else
        _state
    end
    fila_idx = fila_tip_idx.fila_idx
    ftid = Int64(fila_idx.typeid)
    fil_idx = Int64(fila_idx.idx)
    isminusend = fila_tip_idx.is_minus_end
    c.stats.polymerize_fila_count += 1
    cylinders::ChemCylinders = c.chem_cylinders[ftid]
    if !checkall(c.validflags, VFS_SEGMENTS)
        if isminusend
            polymerizeminusend!(cylinders, fil_idx, newstate)
        else
            polymerizeplusend!(cylinders, fil_idx, newstate)
        end
    else
        # get old tip position
        old_tip_pos = get_position(c, fila_tip_idx)
        old_fila_mono_idx = FilaMonoIdx(c, fila_tip_idx)
        old_chem_voxel = get_compartment_id(c, get_position(c, old_fila_mono_idx))
        if isminusend
            polymerizeminusend!(cylinders, fil_idx, newstate)
        else
            polymerizeplusend!(cylinders, fil_idx, newstate)
        end
        new_fila_mono_idx = FilaMonoIdx(c, fila_tip_idx)
        new_chem_voxel = get_compartment_id(c, get_position(c, new_fila_mono_idx))
        #helper_resetsegments!(c)
        old_per_seg = cylinders.per_seg[old_chem_voxel]
        old_seg_idx = _find_segment(old_per_seg, old_fila_mono_idx)
        newmid = new_fila_mono_idx.mid
        if isminusend
            if old_chem_voxel == new_chem_voxel
                # just modify segment
                old_per_seg.midminusend[old_seg_idx] -= 1
            else
                # create new segment
                old_per_seg.minusend_chem_voxel[old_seg_idx] = new_chem_voxel
                _push_segment!(cylinders, new_chem_voxel, DataPerSegment(;
                    fil_idx,
                    midminusend= newmid,
                    midplusend= newmid,
                    plusend_chem_voxel= old_chem_voxel,
                    minusend_chem_voxel= -1,
                ))
            end
        else
            if old_chem_voxel == new_chem_voxel
                # just modify segment
                old_per_seg.midplusend[old_seg_idx] += 1
            else
                # create new segment
                old_per_seg.plusend_chem_voxel[old_seg_idx] = new_chem_voxel
                _push_segment!(cylinders, new_chem_voxel, DataPerSegment(;
                    fil_idx,
                    midminusend= newmid,
                    midplusend= newmid,
                    plusend_chem_voxel= -1,
                    minusend_chem_voxel= old_chem_voxel,
                ))
            end
        end
        if new_chem_voxel != old_chem_voxel
            _pop_fila_end!(c, old_chem_voxel, fila_tip_idx)
            _push_fila_end!(cylinders, new_chem_voxel, fila_tip_idx)
        end
        # new monomers are not linkable, 
        # so decimated_2mon sites don't need to be updated.
        _update_filamentsitecounts!(c, fila_idx, new_fila_mono_idx.mid, new_fila_mono_idx.mid)
        new_tip_pos = get_position(c, fila_tip_idx)
        tip_tag = place2tag(c, fila_tip_idx)
        _update_tag_position!(c, tip_tag, old_tip_pos, new_tip_pos)
        helper_reset_links_one_monomer!(c, new_fila_mono_idx)
    end
    helper_check_sitecount_error(c)
    nothing
end
function polymerize_fila!(c::Context, t::Tag{FilaTipIdx}, state::Union{Symbol,MonomerState})
    polymerize_fila!(c, tag2place(c, t), state)
end

function polymerizeminusend!(cylinders::ChemCylinders, fil_idx::Int, newstate::MonomerState)
    fil = LazyRow(cylinders.per_fil, fil_idx)
    fil.minusend_num_notminimized += 1
    mon_id_first = fil.mon_id_first
    numpercylinder = cylinders.numpercylinder
    if mod(mon_id_first, numpercylinder) == 0
        #new cylinder in the same direction and length as the last one
        pushfirst!(fil.chembeadpositions,2*fil.chembeadpositions[begin]-fil.chembeadpositions[begin+1])
        θm = cylinders.twist_per_monomer
        if isfinite(θm)
            t = normalize_fast(fil.chembeadpositions[begin+1]-fil.chembeadpositions[begin])
            m1 = fil.chem_mat_dir[begin]
            m1 = rotate_around(m1, t, -θm*numpercylinder)
            # make orthogonal again incase of rounding errors
            pushfirst!(fil.chem_mat_dir, ortho_normalize(m1, t))
        else
            pushfirst!(fil.chem_mat_dir, NAN3)
        end
        cyl_idx = length(cylinders.per_cyl) + 1
        push!(cylinders.per_cyl, DataPerCylinder(;fil_idx))
        pushfirst!(fil.cyl_idxs, cyl_idx)
    end
    pushfirst!(fil.monomerstates, newstate)
    fil.mon_id_first -= 1
end

function polymerizeplusend!(cylinders::ChemCylinders, fil_idx::Int, newstate::MonomerState)
    fil = LazyRow(cylinders.per_fil, fil_idx)
    fil.plusend_num_notminimized += 1
    mon_id_last = fil.mon_id_last
    numpercylinder = cylinders.numpercylinder
    if mod(mon_id_last + 1, numpercylinder) == 0
        #new cylinder in the same direction and length as the last one
        push!(fil.chembeadpositions,2*fil.chembeadpositions[end]-fil.chembeadpositions[end-1])
        θm = cylinders.twist_per_monomer
        if isfinite(θm)
            t = normalize_fast(fil.chembeadpositions[end]-fil.chembeadpositions[end-1])
            m1 = fil.chem_mat_dir[end]
            m1 = rotate_around(m1, t, +θm*numpercylinder)
            # make orthogonal again incase of rounding errors
            push!(fil.chem_mat_dir, ortho_normalize(m1, t))
        else
            push!(fil.chem_mat_dir, NAN3)
        end
        cyl_idx = length(cylinders.per_cyl) + 1
        push!(cylinders.per_cyl, DataPerCylinder(;fil_idx))
        push!(fil.cyl_idxs, cyl_idx)
    end
    push!(fil.monomerstates, newstate)
    fil.mon_id_last += 1
end
