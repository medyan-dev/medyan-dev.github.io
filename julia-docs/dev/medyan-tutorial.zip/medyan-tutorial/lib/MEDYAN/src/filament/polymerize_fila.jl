"""
    $(FUNCTIONNAME)(c::Context, fila_tip_idx::FilaTipIdx, newstate::Union{Symbol,MonomerState})
Add a monomer with state `newstate` to the end of the filament.

This doesn't affect the other monomer states, positions, or change any of the monomer ids.
New monomers are not linkable until after minimization.
"""
function polymerize_fila!(c::Context, fila_tip_idx::FilaTipIdx, _state::Union{Symbol,MonomerState})
    newstate::MonomerState = if _state isa Symbol
        c.sys_def.state[fila_tip_idx.fila_idx.typeid][_state]
    else
        _state
    end
    fid = _get_fila_id(c, fila_tip_idx.fila_idx)
    ftid = Int64(fila_tip_idx.fila_idx.typeid)
    fil_idx = Int64(fila_tip_idx.fila_idx.idx)
    isminusend = fila_tip_idx.is_minus_end
    c.stats.polymerize_fila_count += 1
    cylinders::ChemCylinders = c.chem_cylinders[ftid]
    newmid::Int = -1
    # get old tip position
    tip_tag = tag!(c, fila_tip_idx)
    old_tip_pos = get_position(c, fila_tip_idx)
    if isminusend
        polymerizeminusend!(cylinders, fil_idx, newstate)
    else
        polymerizeplusend!(cylinders, fil_idx, newstate)
    end
    new_tip_pos = get_position(c, fila_tip_idx)
    if checkall(c.validflags, VFS_SEGMENTS)
        oldsegment::Union{Segment,Nothing} = nothing
        #helper_resetsegments!(c)
        if isminusend 
            newmid = cylinders.per_fil.mon_id_first[fil_idx]
            oldmid = newmid + 1
            oldcid = get_compartment_id(c, _mon_position(cylinders, fil_idx, oldmid))
            newcid = get_compartment_id(c, _mon_position(cylinders, fil_idx, newmid))
            if oldcid == newcid
                # just modify segment
                comp = c.compartments[newcid]
                sid, seg = findsegment(comp,MonomerName(ftid,fid,oldmid))
                seg.midminusend = newmid
            else
                # create new segment
                newcomp = c.compartments[newcid]
                oldcomp = c.compartments[oldcid]
                sid, seg = findsegment(oldcomp,MonomerName(ftid,fid,oldmid))
                oldsegment = seg
                seg.minusend_cid = newcid
                newseg = Segment(;
                    cid = newcid,
                    ftid,
                    fid,
                    midminusend = newmid,
                    midplusend = newmid,
                    plusend_cid = oldcid,
                    minusend_cid = -1,
                    filamentsitecounts= zeros(length(c.filamentsites[ftid])),
                    filamentendsitecounts= zeros(length(c.filamentendsites[ftid])),
                )
                push!(newcomp.segments[ftid],newseg)
            end
        else
            newmid = cylinders.per_fil.mon_id_last[fil_idx]
            oldmid = newmid - 1
            oldcid = get_compartment_id(c, _mon_position(cylinders, fil_idx, oldmid))
            newcid = get_compartment_id(c, _mon_position(cylinders, fil_idx, newmid))
            if oldcid == newcid
                # just modify segment
                comp = c.compartments[newcid]
                sid, seg = findsegment(comp,MonomerName(ftid,fid,oldmid))
                seg.midplusend = newmid
            else
                # create new segment
                newcomp = c.compartments[newcid]
                oldcomp = c.compartments[oldcid]
                sid, seg = findsegment(oldcomp,MonomerName(ftid,fid,oldmid))
                oldsegment = seg
                seg.plusend_cid = newcid
                newseg = Segment(;
                    cid = newcid,
                    ftid,
                    fid,
                    midminusend = newmid,
                    midplusend = newmid,
                    plusend_cid = -1,
                    minusend_cid = oldcid,
                    filamentsitecounts= zeros(length(c.filamentsites[ftid])),
                    filamentendsitecounts= zeros(length(c.filamentendsites[ftid])),
                )
                push!(newcomp.segments[ftid],newseg)
            end
        end
        new_fila_mono_idx = FilaMonoIdx(c, FilaIdx(ftid, fil_idx), newmid)
        begin #helper_resetfilamentsitecounts!(c)
            # first subtract update end sites on oldsegment 
            # oldsegment is nothing if the new monomer stayed in the same compartment.
            isnothing(oldsegment) || helper_updatesegment_filamentendsitecounts!(c, oldsegment)
            effected_segments = helper_get_filsite_effected_segments(c,ftid,fid,newmid,newmid)
            @assert length(effected_segments) > 0
            for segment in effected_segments
                helper_updatesegmentsitecounts!(c,segment)
            end
        end
        #new monomers are not linkable, 
        #so decimated_2mon sites don't need to be updated.
        #helper_resetdecimated_2mon_sitecounts!(c)
        _update_tag_position!(c, tip_tag, old_tip_pos, new_tip_pos)
        begin # helper_reset_links_one_monomer!
            helper_reset_links_one_monomer!(c, new_fila_mono_idx)
        end
    end
    helper_check_sitecount_error(c)
    nothing
end
function polymerize_fila!(c::Context, t::Tag{FilaTipIdx}, state::Union{Symbol,MonomerState})
    polymerize_fila!(c, tag2place(c, t), state)
end

function polymerizeminusend!(cylinders::ChemCylinders, fil_idx::Int, newstate::MonomerState)
    fil = LazyRow(cylinders.per_fil, fil_idx)
    fil.minusend_num_notminimized += 1
    mon_id_first = fil.mon_id_first
    numpercylinder = cylinders.numpercylinder
    if mod(mon_id_first, numpercylinder) == 0
        #new cylinder in the same direction and length as the last one
        pushfirst!(fil.chembeadpositions,2*fil.chembeadpositions[begin]-fil.chembeadpositions[begin+1])
        cyl_idx = length(cylinders.per_cyl) + 1
        push!(cylinders.per_cyl, DataPerCylinder(;fil_idx))
        pushfirst!(fil.cyl_idxs, cyl_idx)
    end
    pushfirst!(fil.monomerstates, newstate)
    fil.mon_id_first -= 1
end

function polymerizeplusend!(cylinders::ChemCylinders, fil_idx::Int, newstate::MonomerState)
    fil = LazyRow(cylinders.per_fil, fil_idx)
    fil.plusend_num_notminimized += 1
    mon_id_last = fil.mon_id_last
    numpercylinder = cylinders.numpercylinder
    if mod(mon_id_last + 1, numpercylinder) == 0
        #new cylinder in the same direction and length as the last one
        push!(fil.chembeadpositions,2*fil.chembeadpositions[end]-fil.chembeadpositions[end-1])
        cyl_idx = length(cylinders.per_cyl) + 1
        push!(cylinders.per_cyl, DataPerCylinder(;fil_idx))
        push!(fil.cyl_idxs, cyl_idx)
    end
    push!(fil.monomerstates, newstate)
    fil.mon_id_last += 1
end
