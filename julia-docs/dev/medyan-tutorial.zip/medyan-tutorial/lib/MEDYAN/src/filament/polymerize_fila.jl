"""
    $(FUNCTIONNAME)(c::Context, fila_tip_idx::FilaTipIdx, newstate::Union{Symbol,MonomerState})
Add a monomer with state `newstate` to the end of the filament.

This doesn't affect the other monomer states, positions, or change any of the monomer ids.
New monomers are not linkable until after minimization.
"""
function polymerize_fila!(c::Context, fila_tip_idx::FilaTipIdx, _state::Union{Symbol,MonomerState})
    newstate::MonomerState = if _state isa Symbol
        c.sys_def.state[fila_tip_idx.fila_idx.typeid][_state]
    else
        _state
    end
    fila_idx = fila_tip_idx.fila_idx
    ftid = Int64(fila_idx.typeid)
    fil_idx = Int64(fila_idx.idx)
    isminusend = fila_tip_idx.is_minus_end
    c.stats.polymerize_fila_count += 1
    cylinders::ChemCylinders = c.chem_cylinders[ftid]
    if !checkall(c.validflags, VFS_SEGMENTS)
        if isminusend
            polymerizeminusend!(cylinders, fil_idx, newstate)
        else
            polymerizeplusend!(cylinders, fil_idx, newstate)
        end
    else
        # get old tip position
        old_tip_pos = get_position(c, fila_tip_idx)
        old_fila_mono_idx = FilaMonoIdx(c, fila_tip_idx)
        old_chem_voxel = get_compartment_id(c, get_position(c, old_fila_mono_idx))
        if isminusend
            polymerizeminusend!(cylinders, fil_idx, newstate)
        else
            polymerizeplusend!(cylinders, fil_idx, newstate)
        end
        new_fila_mono_idx = FilaMonoIdx(c, fila_tip_idx)
        new_chem_voxel = get_compartment_id(c, get_position(c, new_fila_mono_idx))
        #helper_resetsegments!(c)
        fid = _get_fila_id(c, fila_idx)
        oldcomp = c.compartments[old_chem_voxel]
        oldseg_idx, oldsegment = findsegment(oldcomp, _get_monomer_name(c, old_fila_mono_idx))
        newmid = new_fila_mono_idx.mid
        if isminusend 
            if old_chem_voxel == new_chem_voxel
                # just modify segment
                oldsegment.midminusend = newmid
            else
                # create new segment
                newcomp = c.compartments[new_chem_voxel]
                oldsegment.minusend_cid = new_chem_voxel
                newseg = Segment(;
                    cid = new_chem_voxel,
                    ftid,
                    fid,
                    midminusend = newmid,
                    midplusend = newmid,
                    plusend_cid = old_chem_voxel,
                    minusend_cid = -1,
                    filamentsitecounts= zeros(length(c.filamentsites[ftid])),
                )
                push!(newcomp.segments[ftid], newseg)
            end
        else
            if old_chem_voxel == new_chem_voxel
                # just modify segment
                oldsegment.midplusend = newmid
            else
                # create new segment
                newcomp = c.compartments[new_chem_voxel]
                oldsegment.plusend_cid = new_chem_voxel
                newseg = Segment(;
                    cid = new_chem_voxel,
                    ftid,
                    fid,
                    midminusend = newmid,
                    midplusend = newmid,
                    plusend_cid = -1,
                    minusend_cid = old_chem_voxel,
                    filamentsitecounts= zeros(length(c.filamentsites[ftid])),
                )
                push!(newcomp.segments[ftid],newseg)
            end
        end
        if new_chem_voxel != old_chem_voxel
            _pop_fila_end!(c, old_chem_voxel, fila_tip_idx)
            _push_fila_end!(cylinders, new_chem_voxel, fila_tip_idx)
        end
        # new monomers are not linkable, 
        # so decimated_2mon sites don't need to be updated.
        _update_filamentsitecounts!(c, fila_idx, new_fila_mono_idx.mid, new_fila_mono_idx.mid)
        new_tip_pos = get_position(c, fila_tip_idx)
        tip_tag = place2tag(c, fila_tip_idx)
        _update_tag_position!(c, tip_tag, old_tip_pos, new_tip_pos)
        helper_reset_links_one_monomer!(c, new_fila_mono_idx)
    end
    helper_check_sitecount_error(c)
    nothing
end
function polymerize_fila!(c::Context, t::Tag{FilaTipIdx}, state::Union{Symbol,MonomerState})
    polymerize_fila!(c, tag2place(c, t), state)
end

function polymerizeminusend!(cylinders::ChemCylinders, fil_idx::Int, newstate::MonomerState)
    fil = LazyRow(cylinders.per_fil, fil_idx)
    fil.minusend_num_notminimized += 1
    mon_id_first = fil.mon_id_first
    numpercylinder = cylinders.numpercylinder
    if mod(mon_id_first, numpercylinder) == 0
        #new cylinder in the same direction and length as the last one
        pushfirst!(fil.chembeadpositions,2*fil.chembeadpositions[begin]-fil.chembeadpositions[begin+1])
        cyl_idx = length(cylinders.per_cyl) + 1
        push!(cylinders.per_cyl, DataPerCylinder(;fil_idx))
        pushfirst!(fil.cyl_idxs, cyl_idx)
    end
    pushfirst!(fil.monomerstates, newstate)
    fil.mon_id_first -= 1
end

function polymerizeplusend!(cylinders::ChemCylinders, fil_idx::Int, newstate::MonomerState)
    fil = LazyRow(cylinders.per_fil, fil_idx)
    fil.plusend_num_notminimized += 1
    mon_id_last = fil.mon_id_last
    numpercylinder = cylinders.numpercylinder
    if mod(mon_id_last + 1, numpercylinder) == 0
        #new cylinder in the same direction and length as the last one
        push!(fil.chembeadpositions,2*fil.chembeadpositions[end]-fil.chembeadpositions[end-1])
        cyl_idx = length(cylinders.per_cyl) + 1
        push!(cylinders.per_cyl, DataPerCylinder(;fil_idx))
        push!(fil.cyl_idxs, cyl_idx)
    end
    push!(fil.monomerstates, newstate)
    fil.mon_id_last += 1
end
