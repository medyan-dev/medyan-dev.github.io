"""
    $(FUNCTIONNAME)(c::Context, fila_tip_idx::FilaTipIdx)
Remove a monomer from the end of the filament.

This doesn't affect the other monomer states, positions, or change any of the monomer ids.

Error if the filament isn't initially over 2 monomers long.

Unlink any monomers on the filament that are referenced by any links.
The links will not be removed, but will have a null reference.
Links attached to the filament tip will remain attached.
"""
function depolymerize_fila!(c::Context, fila_tip_idx::FilaTipIdx)
    c.stats.depolymerize_fila_count += 1
    fid = _get_fila_id(c, fila_tip_idx.fila_idx)
    ftid = Int64(fila_tip_idx.fila_idx.typeid)
    fil_idx = Int64(fila_tip_idx.fila_idx.idx)
    isminusend = fila_tip_idx.is_minus_end
    cylinders::ChemCylinders = c.chem_cylinders[ftid]
    fil_data = LazyRow(cylinders.per_fil, fil_idx)
    oldname = if isminusend
        MonomerName(ftid,fid,fil_data.mon_id_first)
    else
        MonomerName(ftid,fid,fil_data.mon_id_last)
    end
    oldmid = oldname.mid
    if fil_data.mon_id_last - fil_data.mon_id_first < 2
        error("depolymerizing a filament that is too short. The filament must be over 2 monomers long")
    end
    # update links to remove references to the place
    old_fila_mono_idx = _get_fila_mono_idx(c, oldname)
    helper_removeplace!(c, old_fila_mono_idx; warn_if_unlink=false)
    # If the segments aren't valid just update cylinders::ChemCylinders,
    # Otherwise update both cylinders and segments to keep them valid.
    if !checkall(c.validflags, VFS_SEGMENTS)
        if isminusend
            depolymerizeminusend!(cylinders, fil_idx)
        else
            depolymerizeplusend!(cylinders, fil_idx)
        end
    else
        # get old tip position
        tip_place = FilaTipIdx(FilaIdx(ftid, fil_idx), isminusend)
        tip_tag = tag!(c, tip_place)
        old_tip_pos = get_position(c, tip_place)
        cid = get_compartment_id(c, _mon_position(cylinders, fil_idx, oldmid))
        comp = c.compartments[cid]
        if isminusend
            depolymerizeminusend!(cylinders, fil_idx)
            sid, seg = findsegment(comp,oldname)
            if seg.midplusend == oldmid
                newendcomp = c.compartments[seg.plusend_cid]
                newsid, newseg = findsegment(newendcomp,MonomerName(ftid,fid,oldmid+1))
                newseg.minusend_cid = -1
                helper_deletesegment!(c,cid,ftid,sid)
            else
                seg.midminusend += 1
            end   
        else
            depolymerizeplusend!(cylinders, fil_idx)
            sid, seg = findsegment(comp,oldname)
            if seg.midminusend == oldmid
                newendcomp = c.compartments[seg.minusend_cid]
                newsid, newseg = findsegment(newendcomp,MonomerName(ftid,fid,oldmid-1))
                newseg.plusend_cid = -1
                helper_deletesegment!(c,cid,ftid,sid)
            else
                seg.midplusend -= 1
            end  
        end
        new_tip_pos = get_position(c, tip_place)
        #helper_resetsegments!(c)
        #helper_reset_decimated_2mon_site_monomers!(c)
        begin #helper_resetfilamentsitecounts!(c)
            #search nearby mid as well, to catch new end sites
            effected_segments = helper_get_filsite_effected_segments(c,ftid,fid,oldmid-1,oldmid+1)
            @assert length(effected_segments) > 0
            for segment in effected_segments
                helper_updatesegmentsitecounts!(c,segment)
            end
        end
        _update_tag_position!(c, tip_tag, old_tip_pos, new_tip_pos)
        begin #helper_reset_links_one_monomer!(c)
            helper_reset_links_one_monomer!(c, old_fila_mono_idx)
        end
    end
    try
        helper_check_sitecount_error(c)
    catch
        @show ftid
        @show fid
        @show isminusend
        @show oldname
        rethrow()
    end
    nothing
end


function depolymerizeminusend!(cylinders::ChemCylinders, fil_idx::Int)
    fil = LazyRow(cylinders.per_fil, fil_idx)
    if !iszero(fil.minusend_num_notminimized)
        fil.minusend_num_notminimized -= 1
    end
    mon_id_first = fil.mon_id_first
    numpercylinder = cylinders.numpercylinder
    if mod(mon_id_first+1,numpercylinder)==0
        #remove cylinder
        popfirst!(fil.chembeadpositions)
        cyl_idx = popfirst!(fil.cyl_idxs)
        @assert cylinders.per_cyl.exists[cyl_idx]
        push!(cylinders.holes, cyl_idx)
        cylinders.per_cyl.exists[cyl_idx] = false
    end
    popfirst!(fil.monomerstates)
    fil.mon_id_first += 1
end

function depolymerizeplusend!(cylinders::ChemCylinders, fil_idx::Int)
    fil = LazyRow(cylinders.per_fil, fil_idx)
    if !iszero(fil.plusend_num_notminimized)
        fil.plusend_num_notminimized -= 1
    end
    mon_id_last = fil.mon_id_last
    numpercylinder = cylinders.numpercylinder
    if mod(mon_id_last,numpercylinder)==0
        #remove cylinder
        pop!(fil.chembeadpositions)
        cyl_idx = pop!(fil.cyl_idxs)
        @assert cylinders.per_cyl.exists[cyl_idx]
        push!(cylinders.holes, cyl_idx)
        cylinders.per_cyl.exists[cyl_idx] = false
    end
    pop!(fil.monomerstates)
    fil.mon_id_last -= 1
end
