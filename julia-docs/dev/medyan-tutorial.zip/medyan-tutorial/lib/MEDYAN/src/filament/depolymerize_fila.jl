"""
    $(FUNCTIONNAME)(c::Context, fila_tip_idx::FilaTipIdx)
Remove a monomer from the end of the filament.

This doesn't affect the other monomer states, positions, or change any of the monomer ids.

Error if the filament isn't initially over 2 monomers long.

Unlink any monomers on the filament that are referenced by any links.
The links will not be removed, but will have a null reference.
Links attached to the filament tip will remain attached.
"""
function depolymerize_fila!(c::Context, fila_tip_idx::FilaTipIdx)
    c.stats.depolymerize_fila_count += 1
    fila_idx = fila_tip_idx.fila_idx
    ftid = Int64(fila_idx.typeid)
    fil_idx = Int64(fila_idx.idx)
    isminusend = fila_tip_idx.is_minus_end
    cylinders::ChemCylinders = c.chem_cylinders[ftid]
    mono_states = fila_mono_states(c, fila_idx)
    if length(mono_states) ≤ 2
        error("depolymerizing a filament that is too short. The filament must be over 2 monomers long")
    end
    # update links to remove references to the place
    old_fila_mono_idx = FilaMonoIdx(c, fila_tip_idx)
    helper_removeplace!(c, old_fila_mono_idx; warn_if_unlink=false)
    # If the segments aren't valid just update cylinders::ChemCylinders,
    # Otherwise update both cylinders and segments to keep them valid.
    if !checkall(c.validflags, VFS_SEGMENTS)
        if isminusend
            depolymerizeminusend!(cylinders, fil_idx)
        else
            depolymerizeplusend!(cylinders, fil_idx)
        end
    else
        # get old tip position
        old_tip_pos = get_position(c, fila_tip_idx)
        old_chem_voxel = get_compartment_id(c, get_position(c, old_fila_mono_idx))
        comp = c.compartments[old_chem_voxel]
        oldmid = old_fila_mono_idx.mid
        fid = _get_fila_id(c, fila_idx)
        if isminusend
            depolymerizeminusend!(cylinders, fil_idx)
            sid, seg = findsegment(comp, _get_monomer_name(c, old_fila_mono_idx))
            if seg.midplusend == oldmid
                newendcomp = c.compartments[seg.plusend_cid]
                newsid, newseg = findsegment(newendcomp,MonomerName(ftid,fid,oldmid+1))
                newseg.minusend_cid = -1
                helper_deletesegment!(c,old_chem_voxel,ftid,sid)
            else
                seg.midminusend += 1
            end
        else
            depolymerizeplusend!(cylinders, fil_idx)
            sid, seg = findsegment(comp, _get_monomer_name(c, old_fila_mono_idx))
            if seg.midminusend == oldmid
                newendcomp = c.compartments[seg.minusend_cid]
                newsid, newseg = findsegment(newendcomp,MonomerName(ftid,fid,oldmid-1))
                newseg.plusend_cid = -1
                helper_deletesegment!(c,old_chem_voxel,ftid,sid)
            else
                seg.midplusend -= 1
            end
        end
        new_fila_mono_idx = FilaMonoIdx(c, fila_tip_idx)
        new_chem_voxel = get_compartment_id(c, get_position(c, new_fila_mono_idx))
        if new_chem_voxel != old_chem_voxel
            _pop_fila_end!(c, old_chem_voxel, fila_tip_idx)
            _push_fila_end!(cylinders, new_chem_voxel, fila_tip_idx)
        end
        _update_filamentsitecounts!(c, fila_idx, new_fila_mono_idx.mid, new_fila_mono_idx.mid)
        new_tip_pos = get_position(c, fila_tip_idx)
        tip_tag = place2tag(c, fila_tip_idx)
        _update_tag_position!(c, tip_tag, old_tip_pos, new_tip_pos)
        helper_reset_links_one_monomer!(c, old_fila_mono_idx)
    end
    helper_check_sitecount_error(c)
    nothing
end


function depolymerizeminusend!(cylinders::ChemCylinders, fil_idx::Int)
    fil = LazyRow(cylinders.per_fil, fil_idx)
    if !iszero(fil.minusend_num_notminimized)
        fil.minusend_num_notminimized -= 1
    end
    mon_id_first = fil.mon_id_first
    numpercylinder = cylinders.numpercylinder
    if mod(mon_id_first+1,numpercylinder)==0
        #remove cylinder
        popfirst!(fil.chembeadpositions)
        cyl_idx = popfirst!(fil.cyl_idxs)
        @assert cylinders.per_cyl.exists[cyl_idx]
        push!(cylinders.holes, cyl_idx)
        cylinders.per_cyl.exists[cyl_idx] = false
    end
    popfirst!(fil.monomerstates)
    fil.mon_id_first += 1
end

function depolymerizeplusend!(cylinders::ChemCylinders, fil_idx::Int)
    fil = LazyRow(cylinders.per_fil, fil_idx)
    if !iszero(fil.plusend_num_notminimized)
        fil.plusend_num_notminimized -= 1
    end
    mon_id_last = fil.mon_id_last
    numpercylinder = cylinders.numpercylinder
    if mod(mon_id_last,numpercylinder)==0
        #remove cylinder
        pop!(fil.chembeadpositions)
        cyl_idx = pop!(fil.cyl_idxs)
        @assert cylinders.per_cyl.exists[cyl_idx]
        push!(cylinders.holes, cyl_idx)
        cylinders.per_cyl.exists[cyl_idx] = false
    end
    pop!(fil.monomerstates)
    fil.mon_id_last -= 1
end
