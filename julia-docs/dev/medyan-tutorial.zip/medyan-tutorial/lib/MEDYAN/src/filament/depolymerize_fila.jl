"""
    $(FUNCTIONNAME)(c::Context, fila_tip_idx::FilaTipIdx)
Remove a monomer from the end of the filament.

This doesn't affect the other monomer states, positions, or change any of the monomer ids.

Error if the filament isn't initially over 2 monomers long.

Unlink any monomers on the filament that are referenced by any links.
The links will not be removed, but will have a null reference.
Links attached to the filament tip will remain attached.
"""
function depolymerize_fila!(c::Context, fila_tip_idx::FilaTipIdx)
    c.stats.depolymerize_fila_count += 1
    fila_idx = fila_tip_idx.fila_idx
    ftid = Int64(fila_idx.typeid)
    fil_idx = Int64(fila_idx.idx)
    isminusend = fila_tip_idx.is_minus_end
    cylinders::ChemCylinders = c.chem_cylinders[ftid]
    mono_ids = fila_mono_ids(c, fila_idx)
    if length(mono_ids) ≤ 2
        error("depolymerizing a filament that is too short. The filament must be over 2 monomers long")
    end
    # update links to remove references to the place
    old_fila_mono_idx = FilaMonoIdx(c, fila_tip_idx)
    helper_removeplace!(c, old_fila_mono_idx; warn_if_unlink=false)
    # If the segments aren't valid just update cylinders::ChemCylinders,
    # Otherwise update both cylinders and segments to keep them valid.
    if !checkall(c.validflags, VFS_SEGMENTS)
        if isminusend
            depolymerizeminusend!(cylinders, fil_idx)
        else
            depolymerizeplusend!(cylinders, fil_idx)
        end
    else
        # get old tip position
        old_tip_pos = get_position(c, fila_tip_idx)
        old_chem_voxel = get_compartment_id(c, get_position(c, old_fila_mono_idx))
        oldmid = old_fila_mono_idx.mid
        old_per_seg = cylinders.per_seg[old_chem_voxel]
        old_seg_idx = _find_segment(old_per_seg, old_fila_mono_idx)
        if isminusend
            depolymerizeminusend!(cylinders, fil_idx)
        else
            depolymerizeplusend!(cylinders, fil_idx)
        end
        new_fila_mono_idx = FilaMonoIdx(c, fila_tip_idx)
        new_chem_voxel = get_compartment_id(c, get_position(c, new_fila_mono_idx))
        if new_chem_voxel != old_chem_voxel
            _pop_fila_end!(c, old_chem_voxel, fila_tip_idx)
            _push_fila_end!(cylinders, new_chem_voxel, fila_tip_idx)
            new_per_seg = cylinders.per_seg[new_chem_voxel]
            new_seg_idx = _find_segment(new_per_seg, new_fila_mono_idx)
            if isminusend
                new_per_seg.minusend_chem_voxel[new_seg_idx] = -1
            else
                new_per_seg.plusend_chem_voxel[new_seg_idx] = -1
            end
            helper_deletesegment!(c, old_chem_voxel, ftid, old_seg_idx)
        else
            if isminusend
                old_per_seg.midminusend[old_seg_idx] += 1
            else
                old_per_seg.midplusend[old_seg_idx] -= 1
            end
        end
        _update_filamentsitecounts!(c, fila_idx, new_fila_mono_idx.mid, new_fila_mono_idx.mid)
        new_tip_pos = get_position(c, fila_tip_idx)
        tip_tag = place2tag(c, fila_tip_idx)
        _update_tag_position!(c, tip_tag, old_tip_pos, new_tip_pos)
        helper_reset_links_one_monomer!(c, old_fila_mono_idx)
    end
    helper_check_sitecount_error(c)
    nothing
end


function depolymerizeminusend!(cylinders::ChemCylinders, fil_idx::Int)
    fil = LazyRow(cylinders.per_fil, fil_idx)
    if !iszero(fil.minusend_num_notminimized)
        fil.minusend_num_notminimized -= 1
    end
    mon_id_first = fil.mon_id_first
    numpercylinder = cylinders.numpercylinder
    if mod(mon_id_first+1,numpercylinder)==0
        #remove cylinder
        popfirst!(fil.chembeadpositions)
        popfirst!(fil.chem_mat_dir)
        cyl_idx = popfirst!(fil.cyl_idxs)
        @assert cylinders.per_cyl.exists[cyl_idx]
        push!(cylinders.holes, cyl_idx)
        cylinders.per_cyl.exists[cyl_idx] = false
    end
    popfirst!(fil.monomerstates)
    fil.mon_id_first += 1
end

function depolymerizeplusend!(cylinders::ChemCylinders, fil_idx::Int)
    fil = LazyRow(cylinders.per_fil, fil_idx)
    if !iszero(fil.plusend_num_notminimized)
        fil.plusend_num_notminimized -= 1
    end
    mon_id_last = fil.mon_id_last
    numpercylinder = cylinders.numpercylinder
    if mod(mon_id_last,numpercylinder)==0
        #remove cylinder
        pop!(fil.chembeadpositions)
        pop!(fil.chem_mat_dir)
        cyl_idx = pop!(fil.cyl_idxs)
        @assert cylinders.per_cyl.exists[cyl_idx]
        push!(cylinders.holes, cyl_idx)
        cylinders.per_cyl.exists[cyl_idx] = false
    end
    pop!(fil.monomerstates)
    fil.mon_id_last -= 1
end
