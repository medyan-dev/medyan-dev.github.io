"""
    Cofilin Severing reaction related.
"""

using LinearAlgebra
using StaticArrays
using Random
using Setfield


"""
Callback that will change remove the part of a filament at a filamentendsite in the compartment
$(TYPEDFIELDS)
"""
struct FilamentSiteSeveringCallback
    "filament site callback"
    filamentsitecallback::GeneralFilamentSiteCallback

    "type of filament this acts on"
    ftid::Int

    "filament end site id to act on"
    fsid::Int

    "if depolymerized monomers recycle"
    mon_recycle::Bool

    "diffusing species id"
    dsid::Int
end

Base.:(==)(a::T,b::T) where T<:FilamentSiteSeveringCallback = struct_equal(a, b)
Base.hash(x::FilamentSiteSeveringCallback, h::UInt) = struct_hash(x,h)

function (g::FilamentSiteSeveringCallback)(c::MEDYAN.Context, cid)
    site = c.filamentendsites[g.ftid][g.fsid].site
    mono_place = pick_rand_fila_mono_site(c, cid, g.ftid, g.fsid)
    if isnothing(mono_place)
        return
    end
    fila_idx = mono_place.fila_idx
    mono_ftid = Int(fila_idx.typeid)
    if iffilaseverable(c.chem_cylinders[mono_ftid], mono_place) != (true, true)
        return
    end
    cylinders = c.chem_cylinders[mono_ftid]
    depolyed_mon_num::Int = chem_severfilament!(c; mono_place)
    if g.mon_recycle
        adddiffusingcount_rand!(c,g.dsid,depolyed_mon_num)
    end
    
end


# The range of depolymerization: from the chosen monomer to random point before minus end
function depoly_frommontominusend(c::Context, mono_place::FilaMonoIdx)
    depoly_range::Vector{FilaMonoIdx} = []
    mono_ftid = mono_place.fila_idx.typeid
    mono_fidx = mono_place.fila_idx.idx
    perfil = c.chem_cylinders[mono_ftid].per_fil[mono_fidx]
    chosen_pos = mono_place.mid 
    minusend_pos = perfil.mon_id_first
    chosen_pos_end = rand(minusend_pos:chosen_pos)

    for i in chosen_pos_end:chosen_pos
        mon_in_range = FilaMonoIdx(FilaIdx(mono_ftid, mono_fidx), i)
        push!(depoly_range, mon_in_range)
    end
    depoly_range
end



function chem_severfilament!(c::Context; mono_place::FilaMonoIdx)

    c.stats.chem_severfilament_count += 1 
    mono_ftid = mono_place.fila_idx.typeid
    mono_fidx = mono_place.fila_idx.idx
    chosenmono_places = depoly_frommontominusend(c, mono_place)
    cylinders = c.chem_cylinders[mono_ftid]
    old_fil = LazyRow(cylinders.per_fil, mono_fidx)
    old_fil_monplusstate = last(old_fil.monomerstates)
    old_fil_monminusstate = first(old_fil.monomerstates)
    depolyed_mon_num::Int = length(chosenmono_places)

    
    # sever from middle, filament with plus end keeps old fid, new filament with minus gets new fid  
    # for fila with plus end
    plus_mon_id = last(chosenmono_places).mid + 1
    plus_mid_first = last(chosenmono_places).mid + 1# reset to 0 or 1
    plus_mid_last = old_fil.mon_id_last # give it a plus end
    plus_monomerstates = old_fil.monomerstates[last(chosenmono_places).mid-old_fil.mon_id_first+2:end]
    # add cylinder if need
    plus_fil_cyl_idx, mon_frac = get_fil_chem_cyl_idx_frac(
        plus_mon_id,
        old_fil.mon_id_first,
        old_fil.mon_id_last,
        cylinders.numpercylinder, # change it to chosen monomers
    )
    plus_cyl_idxs = old_fil.cyl_idxs[plus_fil_cyl_idx:end]
    plus_chembeadpositions = old_fil.chembeadpositions[plus_fil_cyl_idx:end]    

    removealllinks!(c,chosenmono_places)
    

    # 2 is set to be the length of shortest filament
    minus_monomerstates = old_fil.monomerstates[begin:first(chosenmono_places).mid-old_fil.mon_id_first]    
    if !ifminusendincluded(c, chosenmono_places) && length(minus_monomerstates) >= 10
        minus_mon_id = first(chosenmono_places).mid - 1
        minus_fil_cyl_idx, mon_frac = get_fil_chem_cyl_idx_frac(
        minus_mon_id,
        old_fil.mon_id_first,
        old_fil.mon_id_last,
        cylinders.numpercylinder, )
       
        # for new fil with minus end
        minus_fil_idx = length(cylinders.per_fil) + 1
        minus_mid_first = old_fil.mon_id_first
        minus_mid_last = first(chosenmono_places).mid - 1
        minus_monomerstates[end] = old_fil_monplusstate

        if mod(minus_mid_last+1, cylinders.numpercylinder) == 0
            # no new cylinders are needed
            minus_cyl_idxs = old_fil.cyl_idxs[begin:minus_fil_cyl_idx]
            minus_chembeadpositions = old_fil.chembeadpositions[begin:minus_fil_cyl_idx+1]
        else
            # one new cylinder is needed
            minus_cyl_idx = length(cylinders.per_cyl) + 1
            minus_cyl_idxs = [old_fil.cyl_idxs[begin:minus_fil_cyl_idx-1]; minus_cyl_idx;]
            minus_chembeadpositions = old_fil.chembeadpositions[begin:minus_fil_cyl_idx+1]
            push!(cylinders.per_cyl, DataPerCylinder(;fil_idx = minus_fil_idx))
        end
        for cyl_idx in minus_cyl_idxs
            cylinders.per_cyl.fil_idx[cyl_idx] = minus_fil_idx
        end   
        push!(cylinders.per_fil, DataPerFilament(;
            mon_id_first= minus_mid_first,
            mon_id_last= minus_mid_last,
            monomerstates= minus_monomerstates,
            chembeadpositions= minus_chembeadpositions,
            cyl_idxs= minus_cyl_idxs, 
            minusend_num_notminimized= length(minus_monomerstates),
            plusend_num_notminimized= length(minus_monomerstates),
        ))
        old_fila_idx = FilaIdx(mono_ftid, mono_fidx)
        minus_fila_idx = FilaIdx(mono_ftid, minus_fil_idx)

        # Rename left links on newly generated filaments. 
        for mon_id in minus_mid_first:minus_mid_last # mid not from 0
            local old_place = FilaMonoIdx(old_fila_idx, mon_id)
            local new_place = FilaMonoIdx(minus_fila_idx, mon_id)
            # Find links
            t = _tag_manager(c.link_manager, FilaMonoIdx())
            _move_place!(
            t,
            old_place,
            new_place,
        )
        end 
        
        # change per_cyl
        if plus_fil_cyl_idx != minus_fil_cyl_idx && mod(minus_mid_last+1, cylinders.numpercylinder) != 0
            for cyl_num in minus_fil_cyl_idx : plus_fil_cyl_idx-1
                #remove cylinder
                cyl_idx = old_fil.cyl_idxs[cyl_num]
                @assert cylinders.per_cyl.exists[cyl_idx]
                push!(cylinders.holes, cyl_idx)
                cylinders.per_cyl.exists[cyl_idx] = false
            end
        elseif plus_fil_cyl_idx != minus_fil_cyl_idx && mod(minus_mid_last+1, cylinders.numpercylinder) == 0
            for cyl_num in minus_fil_cyl_idx+1 : plus_fil_cyl_idx-1
                #remove cylinder
                cyl_idx = old_fil.cyl_idxs[cyl_num]
                @assert cylinders.per_cyl.exists[cyl_idx]
                push!(cylinders.holes, cyl_idx)
                cylinders.per_cyl.exists[cyl_idx] = false
            end
        end
    else
        if plus_fil_cyl_idx > 1
            for cyl_num in 1 : plus_fil_cyl_idx-1
                #remove cylinder
                cyl_idx = old_fil.cyl_idxs[cyl_num]
                @assert cylinders.per_cyl.exists[cyl_idx]
                push!(cylinders.holes, cyl_idx)
                cylinders.per_cyl.exists[cyl_idx] = false  
            end
        end

        minusdepolymono_places::Vector{FilaMonoIdx} = []
        for mid in old_fil.mon_id_first:first(chosenmono_places).mid-1
            push!(minusdepolymono_places, FilaMonoIdx(old_fila_idx, mid))
        end
        depolyed_mon_num += length(minusdepolymono_places) 
        # Remove places and related links on chosen sequence. 
        removealllinks!(c,minusdepolymono_places)

    end
  
    old_fil.mon_id_first = plus_mid_first
    old_fil.monomerstates = plus_monomerstates
    old_fil.monomerstates[begin] = old_fil_monminusstate
    old_fil.chembeadpositions = plus_chembeadpositions
    old_fil.cyl_idxs = plus_cyl_idxs
    old_fil.minusend_num_notminimized = length(plus_monomerstates) 
    old_fil.plusend_num_notminimized = length(plus_monomerstates)
    
    helper_resetsegments!(c)
    helper_check_sitecount_error(c)

    return depolyed_mon_num
end


function ifminusendincluded(c::Context, chosenmono_places::Vector{FilaMonoIdx})::Bool
    ftid = chosenmono_places[1].fila_idx.typeid
    fidx = chosenmono_places[1].fila_idx.idx
    perfil = c.chem_cylinders[ftid].per_fil[fidx]
    chosenmons_states::Vector{UInt8} = []
    for mono_place in chosenmono_places
        mid = mono_place.mid
        chosenmon_state = perfil.monomerstates[mid-perfil.mon_id_first+1]
        push!(chosenmons_states, chosenmon_state)
    end 
    minusend_state::UInt8 = UInt8(3)
    minusend_state in chosenmons_states
end


"""
    Find a severable monomername on filaments. 
    If the length of severed filament is larger than or equal to 20 monomers, 
    this filament is severable. And the remained part of filament cannot be too short.
    Tuple{Bool, Bool} = (if filament severable, if the remain long enough)
    The least number of monomers in a filament is 2, including a plus end and a minus end.
    So the first severable monomer can least be one monomer away from the the plus end.
"""
function iffilaseverable(cylinders::ChemCylinders, mono_place::FilaMonoIdx)::Tuple{Bool, Bool}
    @assert cylinders.ftid == mono_place.fila_idx.typeid
    fidx = Int(mono_place.fila_idx.idx)
    mid = mono_place.mid
    length_fil = length(cylinders.per_fil.monomerstates[fidx])
    length_remain = length(cylinders.per_fil.monomerstates[fidx])-(mid+1)
    if mid < (cylinders.per_fil[fidx].mon_id_last - 1)
        if  length_fil >= 20 
            if length_remain >= 20
                (true,true)
            else
                (true,false)
            end
        else
            if length_remain >= 20 #length_file and leng_remain are not neccessary to be same.
                (false,true)
            else
                (false,false)
            end
        end
    else
        (false, false)
    end
end


function errorcheck_addcallback(g::FilamentSiteSeveringCallback,s::MEDYAN.SysDef)
    errorcheck_addcallback(g.filamentsitecallback,s)
end



function removealllinks!(c::Context, chosenmono_places::Vector{FilaMonoIdx})
    # remove attached link_2mons
    for place_idx in eachindex(chosenmono_places)
        old_place = chosenmono_places[place_idx]
        old_tags = place2links(c, old_place)
        if !isempty(old_tags) 
            for tag in old_tags 
                remove_link!(c, tag)
            end
        end
    end
end

# Add diffusing monomers from the severing
# record the number of current diffusing species in system.
function current_diffusing_mon_num(c::Context, dsid::Int)
    totaldiffusingmonomers::Int  = 0
    for cid in 1:length(c.compartments)
        totaldiffusingmonomers += c.chemistryengine.diffusingcounts[dsid,cid]
    end
    totaldiffusingmonomers
end