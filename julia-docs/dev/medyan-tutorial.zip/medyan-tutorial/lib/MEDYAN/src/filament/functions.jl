"""
    $(TYPEDSIGNATURES)
Return if the filament parameters support twisting.
"""
function is_twistable(p::FilamentMechParams)::Bool
    !isnan(p.twist_per_monomer)
end
function is_twistable(p::ChemCylinders)::Bool
    !isnan(p.twist_per_monomer)
end

"""
    $(TYPEDSIGNATURES)
Return the number of filament types.
"""
function num_fila_types(c::Context)::Int
    length(c.chem_cylinders)
end


function _normalize_fila_type(c::Context, type::Union{Symbol,Integer})::Int
    if type isa Symbol
        c.sys_def.filament[type]
    else
        type
    end
end


"""
    $(TYPEDSIGNATURES)
Return the number of filaments of a given type.
"""
function num_fila(c::Context; type::Union{Integer, Symbol}=1)::Int
    length(c.chem_cylinders[_normalize_fila_type(c, type)].per_fil)
end

"""
    $(TYPEDSIGNATURES)
Return a `UnitRange{Int64}` of monomer IDs on a filament.
"""
function fila_mono_ids(c::Context, f::FilaIdx)::UnitRange{Int64}
    cylinders::ChemCylinders = c.chem_cylinders[Int(f.typeid)]
    _fil_mon_ids(cylinders, Int(f.idx))
end
fila_mono_ids(c::Context, t::Tag) = fila_mono_ids(c, FilaIdx(c, t::Tag))


"""
    $(TYPEDSIGNATURES)
Return a read only `Vector` of monomer states on a filament.

This can be invalid after any mutations to context, so copy if needed.
"""
function fila_mono_states(c::Context, f::FilaIdx)::Vector{MonomerState}
    cylinders::ChemCylinders = c.chem_cylinders[Int(f.typeid)]
    _fil_mon_states(cylinders, Int(f.idx))
end
fila_mono_states(c::Context, t::Tag) = fila_mono_states(c, FilaIdx(c, t::Tag))


"""
    $(TYPEDSIGNATURES)
Return the number of mechanical node positions of a filament.
"""
function fila_num_nodes(c::Context, f::FilaIdx)::Int
    cylinders::ChemCylinders = c.chem_cylinders[Int(f.typeid)]
    length(cylinders.per_fil.chembeadpositions[Int(f.idx)])
end
fila_num_nodes(c::Context, t::Tag)::Int = fila_num_nodes(c, FilaIdx(c, t))


"""
    $(TYPEDSIGNATURES)
Return the `node_mids` of the filament.

The `node_mids` are the monomer ids at (slightly plus side of) the `node_positions`

                                     |
                          -----+-----|-----+-----
      minus end <----       M  |  M  | (M) |  M        ----> plus end
                          -----+-----|-----+-----
                                     |
                                     ^ A node position is indicated by the line.
    
    The monomer id with parenthesis (M) will in `node_mids`

The first monomer id is the first monomer id on the filament.
The last monomer id is the last monomer id on the filament + 1
"""
function fila_node_mids(c::Context, f::FilaIdx)::Vector{Int}
    cylinders::ChemCylinders = c.chem_cylinders[Int(f.typeid)]
    _fil_node_mon_ids(cylinders, Int(f.idx))
end
fila_node_mids(c::Context, t::Tag)::Vector{Int} = fila_node_mids(c, FilaIdx(c, t))


"""
    $(TYPEDSIGNATURES)
Return the mechanical node positions of the filament.
"""
function fila_node_positions(c::Context, f::FilaIdx)::Vector{SVector{3, Float64}}
    cylinders::ChemCylinders = c.chem_cylinders[Int(f.typeid)]
    _get_nodepositions(cylinders, Int(f.idx))
end
fila_node_positions(c::Context, t::Tag)::Vector{SVector{3, Float64}} = fila_node_positions(c, FilaIdx(c, t))


"""
    $(TYPEDSIGNATURES)
Return the pair of minus end, plus end filament tip tags.
"""
function fila_tip_tags(c::Context, f::FilaIdx)::Pair{Tag{FilaTipIdx}, Tag{FilaTipIdx}}
    # TODO optimize this by storing tags in chemcylinders
    # This will not error because all the tips are already be tagged
    place2tag(c, FilaTipIdx(f, true)) => place2tag(c, FilaTipIdx(f, false))
end
fila_tip_tags(c::Context, t::Tag)::Pair{Tag{FilaTipIdx}, Tag{FilaTipIdx}} = fila_tip_tags(c, FilaIdx(c, t))

"""
    $(TYPEDSIGNATURES)
Return a pair (minus => plus) of the number of unminimized monomers on the minus and plus end of a filament.

This will be reset to (0 => 0) by [`minimize_energy!`](@ref)

When an end is depolymerized this will decrease, but saturate at 0.
When an end is polymerized this will increase.

For example if after minimization a filament has a plus end depolymerization,
this function will return (0 => 0). Then if a plus end polymerization happens,
this function will return (0 => 1), even though the net change in filament length is zero.
"""
function fila_num_unmin_ends(c::Context, fila_idx::FilaIdx)::Pair{Int, Int}
    cylinders::ChemCylinders = c.chem_cylinders[fila_idx.typeid]
    fil_idx = fila_idx.idx
    minus = cylinders.per_fil.minusend_num_notminimized[fil_idx]
    plus = cylinders.per_fil.plusend_num_notminimized[fil_idx]
    (minus => plus)
end
fila_num_unmin_ends(c::Context, t::Tag) = fila_num_unmin_ends(c, FilaIdx(c, t))

"""
    $(FUNCTIONNAME)(c::Context, p::Union{FilaMonoIdx, FilaTipIdx, Tag})::Bool

Return true iff the monomer or tip has been minimized.
Throw an error if `p` doesn't exist.
"""
function is_minimized(c::Context, monomer::FilaMonoIdx)::Bool
    @argcheck place_exists(c, monomer)
    fila_idx = FilaIdx(c, monomer)
    mon_ids = fila_mono_ids(c, fila_idx)
    minusend_num_notminimized, plusend_num_notminimized = fila_num_unmin_ends(c, FilaIdx(c, monomer))
    startmid = first(mon_ids) + minusend_num_notminimized
    stopmid = last(mon_ids) - plusend_num_notminimized
    monomer.mid ∈ startmid:stopmid
end
is_minimized(c::Context, p::FilaTipIdx) = is_minimized(c, FilaMonoIdx(c, p))
is_minimized(c::Context, t::Tag) = is_minimized(c, tag2place(c, t))

"""
Mark all filaments and monomers as minimized, for testing,
    this is normally done in helper_unvectorize_filaments!
"""
function helper_mark_monomers_minimized!(c::Context)
    for cylinders in c.chem_cylinders
        for filament in LazyRows(cylinders.per_fil)
            filament.minusend_num_notminimized = 0
            filament.plusend_num_notminimized = 0
        end
    end
    unset!(c.validflags, VFS_SEGMENTS)
    return
end

"""
    $(FUNCTIONNAME)(c::Context, chem_voxel, fila_typeid, fsid)::Union{FilaMonoIdx, Nothing}

Return a `FilaMonoIdx` of a random fila_mono_site, or return nothing if rejected
weighted by counts, using the default RNG.
"""
function pick_rand_fila_mono_site(c::Context, chem_voxel, fila_typeid, fsid)::Union{FilaMonoIdx, Nothing}
    helper_warn_chem_cache_invalid!(c)
    fxsid= c.filamentsites[fila_typeid][fsid].fxsid
    totalsites= c.chemistryengine.fixedcounts[fxsid,chem_voxel]
    if iszero(totalsites)
        return
    end
    filamentsite= c.filamentsites[fila_typeid][fsid].site
    u::Q31f32= Q31f32(totalsites*rand())
    #go through each segment in the chem_voxel
    fs = c.chem_cylinders[fila_typeid].filamentsitecounts[chem_voxel]
    segments = c.chem_cylinders[fila_typeid].per_seg[chem_voxel]
    for (seg_idx, s) in enumerate(view(fs, fsid, :))
        u -= s
        if u ≤ 0
            #site is on this segment, go though all monomers
            segment = segments[seg_idx]
            u += s
            mon_ids = fila_mono_ids(c, FilaIdx(fila_typeid, segment.fil_idx))
            monstates = fila_mono_states(c, FilaIdx(fila_typeid, segment.fil_idx))
            for mid in segment.midminusend:segment.midplusend
                plusrange= getplusrange(filamentsite)
                minusrange= getminusrange(filamentsite)
                mmid= mid - minusrange
                pmid= mid + plusrange
                #make sure states are in bound
                if mmid ≥ first(mon_ids) && pmid ≤ last(mon_ids)
                    local states = view(monstates, mmid-first(mon_ids)+1:pmid-first(mon_ids)+1)
                    u -= Q31f32(filamentsitecount(filamentsite, states))
                    if u ≤ 0
                        return FilaMonoIdx(FilaIdx(fila_typeid, segment.fil_idx), mid)
                    end
                end
            end
        end
    end
    return
end


"""
    $(FUNCTIONNAME)(c::Context, chem_voxel, fila_typeid, fesid)::Union{FilaTipIdx, Nothing}

Return a `FilaTipIdx` of a random fila_end_site, or return nothing if rejected
weighted by counts, using the default RNG.
"""
function pick_rand_fila_tip_site(c::Context, chem_voxel, fila_typeid, fesid)::Union{FilaTipIdx, Nothing}
    helper_warn_chem_cache_invalid!(c)
    fxsid= c.filamentendsites[fila_typeid][fesid].fxsid
    totalsites= c.chemistryengine.fixedcounts[fxsid, chem_voxel]
    if iszero(totalsites)
        return
    end
    u::Q31f32= Q31f32(totalsites*rand())
    #go through each filament end in the chem voxel
    fes = c.chem_cylinders[fila_typeid].filamentendsitecounts[chem_voxel]
    filamentends = c.chem_cylinders[fila_typeid].filamentends[chem_voxel]
    for (ce_idx, s) in enumerate(view(fes, fesid, :))
        u -= s
        if u ≤ 0
            fend = filamentends[ce_idx]
            return FilaTipIdx(FilaIdx(fila_typeid, fend>>>1), isodd(fend))
        end
    end
end

function _push_fila_end!(cylinders::ChemCylinders, chem_voxel::Int, p::FilaTipIdx)
    @assert p.fila_idx.typeid == cylinders.ftid
    filamentends = cylinders.filamentends[chem_voxel]
    push!(filamentends, p.fila_idx.idx<<1 | p.is_minus_end)
    ce_idx = length(filamentends)
    fes = cylinders.filamentendsitecounts[chem_voxel]
    if !iszero(size(fes, 1))
        @assert size(fes, 2) == ce_idx - 1
        ElasticArrays.resize_lastdim!(fes, ce_idx)
        fes[:, end] .= 0
    end
    ce_idx
end

"""
Remove filament end cache and remove site counts from the chemistry engine.
"""
function _pop_fila_end!(c::Context, chem_voxel::Int, p::FilaTipIdx)
    ftid = Int64(p.fila_idx.typeid)
    cylinders = c.chem_cylinders[ftid]
    ce_idx = _find_fila_end(cylinders, chem_voxel, p)
    fes = cylinders.filamentendsitecounts[chem_voxel]
    filamentends = cylinders.filamentends[chem_voxel]
    # subtract the filament end site counts from the chemistry engine
    for siteinfo in c.filamentendsites[ftid]
        counts = fes[siteinfo.id, ce_idx]
        if !iszero(counts)
            addfixedspeciescount!(c.chemistryengine, siteinfo.fxsid, chem_voxel, -counts)
        end
    end
    # now delete
    last_ce_idx = length(filamentends)
    if !iszero(size(fes, 1))
        fes[:, ce_idx] .= @view(fes[:, last_ce_idx])
        ElasticArrays.resize_lastdim!(fes, last_ce_idx-1)
    end
    filamentends[ce_idx] = filamentends[last_ce_idx]
    pop!(filamentends)
    nothing
end

function _find_fila_end(cylinders::ChemCylinders, chem_voxel::Int, p::FilaTipIdx)::Int
    @assert p.fila_idx.typeid == cylinders.ftid
    filamentends = cylinders.filamentends[chem_voxel]
    fend = p.fila_idx.idx<<1 | p.is_minus_end
    findfirst(==(fend), filamentends)
end

function helper_filamentendsitecounts(c::Context, p::FilaTipIdx, filamentendsite)::Float64
    if isminusend(filamentendsite) != is_minus_end(p)
        return 0.0
    end
    ftid = Int64(p.fila_idx.typeid)
    cylinders = c.chem_cylinders[ftid]
    #check range
    n= getrange(filamentendsite)
    fila_idx = FilaIdx(c, p)
    monstates = fila_mono_states(c, fila_idx)
    if length(monstates)<n
        return 0.0
    end
    # ensure too many monomers aren't added between minimization.
    num_added = added_monomers(filamentendsite)
    if num_added > 0
        num_unmin = fila_num_unmin_ends(c, fila_idx)[1+!is_minus_end(p)]
        max_unmin = c.filamentmechparams[ftid].max_num_unmin_end
        @assert max_unmin ≥ 0
        if (num_added + num_unmin) > max_unmin
            return 0.0
        end
    end
    endloadforce = cylinders.per_fil.endloadforces[Int(fila_idx.idx)][1+!is_minus_end(p)]
    states = if isminusend(filamentendsite)
        @view(monstates[begin:begin+n-1])
    else
        @view(monstates[end-n+1:end])
    end
    ratefactor= exp(-c.β*spacing(filamentendsite)*endloadforce)
    return ratefactor * filamentendsitecount(filamentendsite, states)
end

"""
Reset link site counts effected by the change to one monomer state.
"""
function helper_reset_links_one_monomer!(c::Context, p::FilaMonoIdx)
    plus_end = FilaTipIdx(c, p, +)
    minus_end = FilaTipIdx(c, p, -)
    for offset in -1:+1
        mon = FilaMonoIdx(c, p, offset)
        for link in place2links(c, mon)
            _update_link_reactions!(c, link)
        end
        if mon == FilaMonoIdx(c, plus_end)
            for link in place2links(c, plus_end)
                _update_link_reactions!(c, link)
            end
        end
        if mon == FilaMonoIdx(c, minus_end)
            for link in place2links(c, minus_end)
                _update_link_reactions!(c, link)
            end
        end
    end
end

"""
Return the segment idx of segment with the monomer.
`per_seg` is a collection of `DataPerSegment`
"""
function _find_segment(per_seg, p::FilaMonoIdx)::Int
    fil_idx = p.fila_idx.idx
    mid = p.mid
    sidx = findfirst(per_seg) do seg
        seg.fil_idx == fil_idx && (mid ∈ seg.midminusend:seg.midplusend)
    end
    isnothing(sidx) && error("No segment found for $p")
    sidx
end

function _push_segment!(cylinders::ChemCylinders, chem_voxel::Int, seg::DataPerSegment)
    per_seg = cylinders.per_seg[chem_voxel]
    push!(per_seg, seg)
    seg_idx = length(cylinders.per_seg[chem_voxel])
    fs = cylinders.filamentsitecounts[chem_voxel]
    if !iszero(size(fs, 1))
        @assert size(fs, 2) == seg_idx - 1
        ElasticArrays.resize_lastdim!(fs, seg_idx)
        fs[:, end] .= 0
    end
    seg_idx
end

"""
Update chem voxel segment cache.
Doesn't update other compartmentdata or any reaction counts.
"""
function helper_resetsegments!(c::Context)
    for ftid in 1:num_fila_types(c)
        cylinders = c.chem_cylinders[ftid]
        for chem_voxel in 1:length(c.grid)
            if !iszero(size(cylinders.filamentsitecounts[chem_voxel], 1))
                ElasticArrays.resize_lastdim!(cylinders.filamentsitecounts[chem_voxel], 0)
            end
            empty!(cylinders.per_seg[chem_voxel])
        end
        for fil_idx in 1:num_fila(c; type= ftid)
            fila_idx = FilaIdx(ftid, fil_idx)
            last_chem_voxel = -1
            last_seg = nothing
            for mid in fila_mono_ids(c, fila_idx)
                chem_voxel = get_compartment_id(c, get_position(c, FilaMonoIdx(fila_idx, mid)))
                if chem_voxel == last_chem_voxel
                    last_seg.midplusend = mid
                else
                    #left last_chem_voxel, create new segment
                    if !isnothing(last_seg)
                        last_seg.plusend_chem_voxel = chem_voxel
                    end
                    local seg = DataPerSegment(;
                        fil_idx,
                        midminusend= mid,
                        midplusend= mid,
                        minusend_chem_voxel= last_chem_voxel,
                        plusend_chem_voxel= -1,#plus end does not exist
                    )
                    local seg_idx = _push_segment!(cylinders, chem_voxel, seg)
                    last_seg = LazyRow(cylinders.per_seg[chem_voxel], seg_idx)
                    last_chem_voxel = chem_voxel
                end
            end
        end
    end
end

"""
Update chem voxel filament end cache.
Doesn't update other compartmentdata or any reaction counts.
"""
function helper_resetfilamentends!(c::Context)
    for ftid in 1:num_fila_types(c)
        cylinders = c.chem_cylinders[ftid]
        for chem_voxel in 1:length(c.grid)
            if !iszero(size(cylinders.filamentendsitecounts[chem_voxel], 1))
                ElasticArrays.resize_lastdim!(cylinders.filamentendsitecounts[chem_voxel], 0)
            end
            empty!(cylinders.filamentends[chem_voxel])
        end
        for fil_idx in 1:num_fila(c; type= ftid)
            for isminus in (true, false)
                local tip = FilaTipIdx(FilaIdx(ftid, fil_idx), isminus)
                local chem_voxel = get_compartment_id(c, get_position(c, FilaMonoIdx(c, tip)))
                _push_fila_end!(cylinders, chem_voxel, tip)
            end
        end
    end
end

function _update_filament_end_sitecounts!(c::Context, p::FilaTipIdx, chem_voxel, ce_idx)
    ftid = Int64(p.fila_idx.typeid)
    fes = c.chem_cylinders[ftid].filamentendsitecounts[chem_voxel]
    for siteinfo in c.filamentendsites[ftid]
        newsitecount = Q31f32(helper_filamentendsitecounts(c, p, siteinfo.site))
        oldsitecount = fes[siteinfo.id, ce_idx]
        if newsitecount != oldsitecount
            addfixedspeciescount!(c.chemistryengine, siteinfo.fxsid, chem_voxel, newsitecount-oldsitecount)
            fes[siteinfo.id, ce_idx] = newsitecount
        end
    end
end
function _update_filament_end_sitecounts!(c::Context, p::FilaTipIdx)
    chem_voxel = get_compartment_id(c, get_position(c, FilaMonoIdx(c, p)))
    ce_idx = _find_fila_end(c.chem_cylinders[Int64(p.fila_idx.typeid)], chem_voxel, p)
    _update_filament_end_sitecounts!(c, p, chem_voxel, ce_idx)
end

function _updatesegmentsitecounts!(c::Context, cylinders::ChemCylinders, chem_voxel::Int, seg_idx::Int)
    requireall(c.validflags, VFS_SEGMENTS)
    ftid = cylinders.ftid
    per_seg = cylinders.per_seg[chem_voxel]
    fs = cylinders.filamentsitecounts[chem_voxel]
    seg = per_seg[seg_idx]::DataPerSegment
    filamentsitecounts= zeros(Q31f32,length(c.filamentsites[ftid]))
    fila_idx = FilaIdx(ftid, seg.fil_idx)
    mon_ids = fila_mono_ids(c, fila_idx)
    monstates = fila_mono_states(c, fila_idx)
    for mid in seg.midminusend:seg.midplusend
        for sitetuple in c.filamentsites[ftid]
            fsid = sitetuple.id
            filamentsite = sitetuple.site
            plusrange = getplusrange(filamentsite)
            minusrange = getminusrange(filamentsite)
            mmid = mid - minusrange
            pmid = mid + plusrange
            # make sure states are inbounds
            if mmid ≥ first(mon_ids) && pmid ≤ last(mon_ids)
                local states = view(monstates, mmid-first(mon_ids)+1:pmid-first(mon_ids)+1)
                filamentsitecounts[fsid] += Q31f32(filamentsitecount(filamentsite, states))
            end
        end
    end
    for fsid in eachindex(filamentsitecounts)
        newsitecount = filamentsitecounts[fsid]
        oldsitecount = fs[fsid, seg_idx]
        if newsitecount != oldsitecount
            fxsid= c.filamentsites[ftid][fsid].fxsid
            addfixedspeciescount!(c.chemistryengine,fxsid,chem_voxel,newsitecount-oldsitecount)
            fs[fsid, seg_idx] = newsitecount
        end
    end
end

"""
delete a segment and subtract all site counts
"""
function helper_deletesegment!(c::Context, chem_voxel::Int, ftid::Int, seg_idx::Int)
    requireall(c.validflags, VFS_SEGMENTS)
    cylinders = c.chem_cylinders[ftid]
    fs = cylinders.filamentsitecounts[chem_voxel]
    per_seg = cylinders.per_seg[chem_voxel]
    # subtract the filament site counts from the chemistry engine
    for siteinfo in c.filamentsites[ftid]
        counts = fs[siteinfo.id, seg_idx]
        if !iszero(counts)
            addfixedspeciescount!(c.chemistryengine, siteinfo.fxsid, chem_voxel, -counts)
        end
    end
    #now delete
    last_seg_idx = length(per_seg)
    if !iszero(size(fs, 1))
        fs[:, seg_idx] .= @view(fs[:, last_seg_idx])
        ElasticArrays.resize_lastdim!(fs, last_seg_idx-1)
    end
    per_seg[seg_idx] = per_seg[last_seg_idx]
    pop!(per_seg)
    nothing
end

"""
delete all segments and ends of a filament and subtract all site counts
"""
function _deletefilamentcache!(c::Context, fila_idx::FilaIdx)
    ftid = Int(fila_idx.typeid)
    cylinders = c.chem_cylinders[ftid]
    for dir in (false, true)
        local tip = FilaTipIdx(c, fila_idx, dir)
        _pop_fila_end!(c, get_compartment_id(c, get_position(c, FilaMonoIdx(c, tip))), tip)
    end
    mid = first(fila_mono_ids(c, fila_idx))
    chem_voxel::Int = get_compartment_id(c, get_position(c, FilaMonoIdx(fila_idx, mid)))
    while true
        local per_seg = cylinders.per_seg[chem_voxel]
        local seg_idx = _find_segment(per_seg, FilaMonoIdx(fila_idx, mid))
        local seg = per_seg[seg_idx]
        helper_deletesegment!(c, chem_voxel, ftid, seg_idx)
        chem_voxel = seg.plusend_chem_voxel
        mid = seg.midplusend + 1
        chem_voxel == -1 && break
    end
end

"""
add segments and ends of a filament and add all site counts
"""
function _addfilamentcache!(c::Context, fila_idx::FilaIdx)
    ftid = Int(fila_idx.typeid)
    cylinders = c.chem_cylinders[ftid]
    # update filament end sites
    for dir in (false, true)
        local tip = FilaTipIdx(c, fila_idx, dir)
        local chem_voxel = get_compartment_id(c, get_position(c, FilaMonoIdx(c, tip)))
        local ce_idx = _push_fila_end!(cylinders, chem_voxel, tip)
        _update_filament_end_sitecounts!(c, tip, chem_voxel, ce_idx)
    end
    # update filament sites
    let
        local last_chem_voxel = -1
        local last_seg = nothing
        local last_seg_idx = -1
        for mid in fila_mono_ids(c, fila_idx)
            local chem_voxel = get_compartment_id(c, get_position(c, FilaMonoIdx(fila_idx, mid)))
            if chem_voxel == last_chem_voxel
                last_seg.midplusend = mid
            else
                if !isnothing(last_seg)
                    last_seg.plusend_chem_voxel = chem_voxel
                    #left last_chem_voxel, create new segment
                    #first save filament site counts of last_seg
                    _updatesegmentsitecounts!(c, cylinders, last_chem_voxel, last_seg_idx)
                end
                local seg = DataPerSegment(;
                    fil_idx= Int(fila_idx.idx),
                    midminusend= mid,
                    midplusend= mid,
                    minusend_chem_voxel= last_chem_voxel,
                    plusend_chem_voxel= -1,#plus end does not exist
                )
                local seg_idx = _push_segment!(cylinders, chem_voxel, seg)
                last_seg = LazyRow(cylinders.per_seg[chem_voxel], seg_idx)
                last_seg_idx = seg_idx
                last_chem_voxel = chem_voxel
            end
        end
        _updatesegmentsitecounts!(c, cylinders, last_chem_voxel, last_seg_idx)
    end
end

"""
Update filament end and filament site counts affected by a change to mono states from midstart to midstop.
"""
function _update_filamentsitecounts!(c::Context, fila_idx::FilaIdx, midstart::Int, midstop::Int)
    ftid = Int64(fila_idx.typeid)
    cylinders::ChemCylinders = c.chem_cylinders[ftid]
    requireall(c.validflags, VFS_SEGMENTS)
    mon_ids = fila_mono_ids(c, fila_idx)
    midminusend = first(mon_ids)
    midplusend = last(mon_ids)
    midminusmaxrange = c.maxfilsite_minusrange[ftid]
    midplusmaxrange = c.maxfilsite_plusrange[ftid]
    midstarteffect = max(midstart-midplusmaxrange, midminusend)
    midstopeffect = min(midstop+midminusmaxrange, midplusend)
    let # filament end sites
        if midstarteffect == midminusend
            _update_filament_end_sitecounts!(c, FilaTipIdx(fila_idx, true))
        end
        if midstopeffect == midplusend
            _update_filament_end_sitecounts!(c, FilaTipIdx(fila_idx, false))
        end
    end
    let # filament sites
        local mid = midstarteffect
        local chem_voxel::Int = get_compartment_id(c, get_position(c, FilaMonoIdx(fila_idx, mid)))
        while true
            per_seg = cylinders.per_seg[chem_voxel]
            seg_idx = _find_segment(per_seg, FilaMonoIdx(fila_idx, mid))
            _updatesegmentsitecounts!(c, cylinders, chem_voxel, seg_idx)
            seg = per_seg[seg_idx]
            if midstopeffect > seg.midplusend
                chem_voxel = seg.plusend_chem_voxel
                mid = seg.midplusend + 1
            else
                return
            end
        end
    end
end

"""
Reset the filament site counts and fixedspecies number after segments are reset
"""
function helper_resetfilamentsitecounts!(c::Context)
    for chem_voxel in 1:length(c.grid)
        for ftid in 1:num_fila_types(c)
            fs = c.chem_cylinders[ftid].filamentsitecounts[chem_voxel]
            fill!(fs, 0)
            for (seg_idx, seg) in enumerate(c.chem_cylinders[ftid].per_seg[chem_voxel])
                mon_ids = fila_mono_ids(c, FilaIdx(ftid, seg.fil_idx))
                monstates = fila_mono_states(c, FilaIdx(ftid, seg.fil_idx))
                for mid in seg.midminusend:seg.midplusend
                    for sitetuple in c.filamentsites[ftid]
                        fsid= sitetuple.id
                        filamentsite= sitetuple.site
                        plusrange= getplusrange(filamentsite)
                        minusrange= getminusrange(filamentsite)
                        mmid= mid - minusrange
                        pmid= mid + plusrange
                        #make sure states are in bound
                        if mmid ≥ first(mon_ids) && pmid ≤ last(mon_ids)
                            local states = view(monstates, mmid-first(mon_ids)+1:pmid-first(mon_ids)+1)
                            fs[fsid, seg_idx] += Q31f32(filamentsitecount(filamentsite, states))
                        end
                    end
                end
            end
            for siteinfo in c.filamentsites[ftid]
                setfixedspeciescount!(c.chemistryengine, siteinfo.fxsid, chem_voxel, reduce(+, view(fs, siteinfo.id, :)))
            end
        end
    end
end

"""
Reset the filament end site counts and fixedspecies number after filament ends are reset
"""
function helper_resetfilamentendsitecounts!(c::Context)
    for chem_voxel in 1:length(c.grid)
        for ftid in 1:num_fila_types(c)
            fes = c.chem_cylinders[ftid].filamentendsitecounts[chem_voxel]
            fill!(fes, 0)
            for (ce_idx, fend) in enumerate(c.chem_cylinders[ftid].filamentends[chem_voxel])
                for siteinfo in c.filamentendsites[ftid]
                    fes[siteinfo.id, ce_idx] = Q31f32(helper_filamentendsitecounts(
                        c,
                        FilaTipIdx(FilaIdx(ftid, fend>>>1), isodd(fend)),
                        siteinfo.site,
                    ))
                end
            end
            for siteinfo in c.filamentendsites[ftid]
                setfixedspeciescount!(c.chemistryengine, siteinfo.fxsid, chem_voxel, reduce(+, view(fes, siteinfo.id, :)))
            end
        end
    end
end

function assert_invariants(cylinders::ChemCylinders)
    for hole in cylinders.holes
        @argcheck !cylinders.per_cyl.exists[hole]
    end
    num_cyl_exist = length(cylinders.per_cyl) - length(cylinders.holes)
    @argcheck sum(cylinders.per_cyl.exists) == num_cyl_exist
    num_cyl_in_filaments = 0
    for fil_idx in 1:length(cylinders.per_fil)
        fil = LazyRow(cylinders.per_fil, fil_idx)
        for cyl_idx in fil.cyl_idxs
            @argcheck cylinders.per_cyl.exists[cyl_idx]
            @argcheck fil_idx == cylinders.per_cyl.fil_idx[cyl_idx]
        end
        num_cyl_on_fil = length(fil.cyl_idxs)
        @argcheck num_cyl_on_fil > 0
        @argcheck num_cyl_on_fil == length(fil.chem_mat_dir)
        @argcheck num_cyl_on_fil == length(fil.chembeadpositions) - 1
        @argcheck fil.mon_id_last - fil.mon_id_first == length(fil.monomerstates) - 1
        num_cyl_in_filaments += num_cyl_on_fil
    end
    @argcheck num_cyl_in_filaments == num_cyl_exist
end

function statistically_equal(a::ChemCylinders, b::ChemCylinders)
    a.ftid == b.ftid || return false
    a.numpercylinder == b.numpercylinder || return false
    a.per_fil.mon_id_first == b.per_fil.mon_id_first || return false
    a.per_fil.monomerstates == b.per_fil.monomerstates || return false
    a.per_fil.chembeadpositions == b.per_fil.chembeadpositions || return false
    isequal(a.per_fil.chem_mat_dir, b.per_fil.chem_mat_dir) || return false
    a.per_fil.endloadforces == b.per_fil.endloadforces || return false
    a.per_fil.minusend_num_notminimized == b.per_fil.minusend_num_notminimized || return false
    a.per_fil.plusend_num_notminimized == b.per_fil.plusend_num_notminimized || return false
    return true
end

"""
Return mon_id_first, mon_id_last, numpercylinder
"""
function _mon_id_info(cylinders::ChemCylinders, fil_idx::Int)::NTuple{3, Int}
    mon_id_first::Int = cylinders.per_fil.mon_id_first[fil_idx]
    mon_id_last::Int = cylinders.per_fil.mon_id_last[fil_idx]
    numpercylinder::Int = cylinders.numpercylinder
    (
        mon_id_first,
        mon_id_last,
        numpercylinder,
    )
end


"""
    $(TYPEDSIGNATURES)
Return a `UnitRange{Int64}` of monomer IDs on a filament.
"""
function _fil_mon_ids(cylinders::ChemCylinders, fil_idx::Int)::UnitRange{Int64}
    mon_id_first = cylinders.per_fil.mon_id_first[fil_idx]
    n_mons = length(cylinders.per_fil.monomerstates[fil_idx])
    mon_id_first : mon_id_first+n_mons-1
end


"""
    $(TYPEDSIGNATURES)
Return a read only Vector of monomer states on a filament.

This can be invalid after any mutations to context, so copy if needed.
"""
function _fil_mon_states(cylinders::ChemCylinders, fil_idx::Int)::Vector{MonomerState}
    cylinders.per_fil.monomerstates[fil_idx]
end


function _mon_position(cylinders::ChemCylinders, fil_idx::Int, mon_id::Int)
    fil_cyl_idx, frac = @inline(get_fil_chem_cyl_idx_frac(
        mon_id,
        _mon_id_info(cylinders, fil_idx)...
    ))
    chembeadpositions = cylinders.per_fil.chembeadpositions[fil_idx]
    r1 = chembeadpositions[fil_cyl_idx]
    r2 = chembeadpositions[fil_cyl_idx + 1]
    frac*r2 + (1.0-frac)*r1
end


function _mon_position_plusvector(cylinders::ChemCylinders, fil_idx::Int, mon_id::Int)
    fil_cyl_idx, frac = get_fil_chem_cyl_idx_frac(
        mon_id,
        _mon_id_info(cylinders, fil_idx)...
    )
    chembeadpositions = cylinders.per_fil.chembeadpositions[fil_idx]
    r1 = chembeadpositions[fil_cyl_idx]
    r2 = chembeadpositions[fil_cyl_idx + 1]
    pos = frac*r2 + (1.0-frac)*r1
    plusv = normalize_fast(r2 - r1)
    pos, plusv
end


function _get_nodepositions(cylinders::ChemCylinders, fil_idx::Int)::Vector{SVector{3,Float64}}
    _get_nodepositions(
        cylinders.per_fil.chembeadpositions[fil_idx],
        _mon_id_info(cylinders, fil_idx)...
    )
end


"""
Return the number of monomers on the minus end cylinder
"""
function _get_nummonomersminusend(cylinders::ChemCylinders, fil_idx::Int)::Int
    if length(cylinders.per_fil.chembeadpositions[fil_idx])==2
        #just one cylinder
        return length(cylinders.per_fil.monomerstates[fil_idx])
    else
        return cylinders.numpercylinder - mod(cylinders.per_fil.mon_id_first[fil_idx], cylinders.numpercylinder)
    end
end


"""
Return the number of monomers on the plus end cylinder
"""
function _get_nummonomersplusend(cylinders::ChemCylinders, fil_idx::Int)::Int
    if length(cylinders.per_fil.chembeadpositions[fil_idx])==2
        #just one cylinder
        return length(cylinders.per_fil.monomerstates[fil_idx])
    else
        return mod(cylinders.per_fil.mon_id_last[fil_idx], cylinders.numpercylinder) + 1
    end
end


function _fil_node_mon_ids(cylinders::ChemCylinders, fil_idx::Int)::Vector{Int}
    _fil_node_mon_ids(
        _mon_id_info(cylinders, fil_idx)...
    )
end


function Base.empty!(cylinders::ChemCylinders)
    empty!(cylinders.per_cyl)
    empty!(cylinders.holes)
    empty!(cylinders.per_fil)
    for chem_voxel in 1:length(cylinders.filamentends)
        if !iszero(size(cylinders.filamentendsitecounts[chem_voxel], 1))
            ElasticArrays.resize_lastdim!(cylinders.filamentendsitecounts[chem_voxel], 0)
        end
        empty!(cylinders.filamentends[chem_voxel])
        if !iszero(size(cylinders.filamentsitecounts[chem_voxel], 1))
            ElasticArrays.resize_lastdim!(cylinders.filamentsitecounts[chem_voxel], 0)
        end
        empty!(cylinders.per_seg[chem_voxel])
    end
end


function Base.isempty(cylinders::ChemCylinders)
    isempty(cylinders.per_cyl)
end

"""
Rearrange cylinders to remove holes. After this all cylinders should exist.
"""
function fill_holes!(cylinders::ChemCylinders)
    currentsize = length(cylinders.per_cyl)
    finalsize = currentsize - length(cylinders.holes)
    hole_idx = 1
    for cyl_idx in (finalsize+1):currentsize
        if cylinders.per_cyl.exists[cyl_idx]
            while cylinders.holes[hole_idx] > finalsize
                hole_idx += 1
            end
            hole = cylinders.holes[hole_idx]
            hole_idx += 1
            # hole is an empty idx inside the final array 
            # to be filled by `cyl_idx`, a not empty element outside the final array.
            @assert !cylinders.per_cyl.exists[hole]
            @assert cylinders.per_cyl.exists[cyl_idx]
            cyl = cylinders.per_cyl[cyl_idx]
            cylinders.per_cyl[hole] = cyl
            fil_idx = cyl.fil_idx
            replace!(cylinders.per_fil.cyl_idxs[fil_idx], cyl_idx=>hole)
        end
    end
    resize!(cylinders.per_cyl, finalsize)
    empty!(cylinders.holes)
    @assert all(cylinders.per_cyl.exists)
end

"""
Returns the chem bead positions

The monomers are coarse grained such that every `numpercylinder` monomer is a cylinder,
beads are between two monomers and monomers are linearly interpolated between beads.

chem beads are linearly interpolated between `nodepositions` 
    so that the monomers to the right of the beads have ids divisible by `cylinders.numpercylinder`,
    the first and last beads, can be extended from `nodepositions[begin]`, `nodepositions[end]`, so they won't change when a monomer is (de)polymerized.

The `full_node_mids` are the monomer ids at (slightly plus side of) the `nodepositions`
`full_node_mids[end]` is the last monomer id + 1

                                     |
                          -----+-----|-----+-----
      minus end <----       M  |  M  | (M) |  M        ----> plus end
                          -----+-----|-----+-----
                                     |
                                     ^ A nodeposition is indicated by the line.

The monomer id with parenthesis (M) will in `full_node_mids`
"""
function interpolate_chem_beads(full_node_mids::Vector{Int}, nodepositions::Vector{SVector{3,Float64}}, numpercylinder::Int)::Vector{SVector{3,Float64}}
    @argcheck length(full_node_mids) == length(nodepositions)
    @argcheck numpercylinder > 0
    cyl_lengths = full_node_mids[begin+1:end] - full_node_mids[begin:end-1]
    @argcheck all(>(0), cyl_lengths)
    firstmonomerid = full_node_mids[begin]
    firstcylinderid = fld(firstmonomerid,numpercylinder)
    lastmonomerid = full_node_mids[end] - 1
    lastcylinderid= fld(lastmonomerid,numpercylinder)
    numbeads = lastcylinderid - firstcylinderid + 2
    chembeadpositions = fill(NAN3,numbeads)
    #first bead
    a = - mod(full_node_mids[begin],numpercylinder)
    b = full_node_mids[begin+1] - full_node_mids[begin]
    chembeadpositions[begin] = (1-a/b)*nodepositions[begin] + (a/b)*nodepositions[begin+1]
    #middle beads
    bead_idx = 2
    node_idx = 2
    targetmid = (firstcylinderid+1)*numpercylinder
    while bead_idx < numbeads
        while full_node_mids[node_idx] < targetmid
            node_idx += 1
        end
        a = full_node_mids[node_idx] - targetmid
        b = full_node_mids[node_idx] - full_node_mids[node_idx-1]
        chembeadpositions[bead_idx] = (1-a/b)*nodepositions[node_idx] + (a/b)*nodepositions[node_idx-1]
        bead_idx += 1
        targetmid += numpercylinder
    end
    #last bead
    a = -mod(-full_node_mids[end],numpercylinder)
    b = full_node_mids[end] - full_node_mids[end-1]
    chembeadpositions[end] = (1-a/b)*nodepositions[end] + (a/b)*nodepositions[end-1]
    chembeadpositions
end

"""
Returns the excess twist at each cylinder joint

Like `interpolate_chem_beads` but interpolates the excess twist.
"""
function interpolate_twist(full_node_mids::Vector{Int}, twists::Vector{Float64}, numpercylinder::Int)::Vector{Float64}
    @argcheck length(twists) == length(full_node_mids) - 2
    @argcheck numpercylinder > 0
    cyl_lengths = full_node_mids[begin+1:end] - full_node_mids[begin:end-1]
    @argcheck all(>(0), cyl_lengths)
    firstmonomerid = full_node_mids[begin]
    firstcylinderid = fld(firstmonomerid,numpercylinder)
    lastmonomerid = full_node_mids[end] - 1
    lastcylinderid= fld(lastmonomerid,numpercylinder)
    numjoints = lastcylinderid - firstcylinderid
    results = fill(NaN, numjoints)
    node_idx = 2
    targetmid = (firstcylinderid+1)*numpercylinder
    for joint_idx in 1:numjoints
        acc_twist = 0.0
        while full_node_mids[node_idx] ≤ targetmid
            acc_twist += twists[node_idx-1]
            node_idx += 1
        end
        results[joint_idx] = acc_twist
        targetmid += numpercylinder
    end
    results
end


"""
Return the node positions with the ends at the actual ends of the filament.

The length of the returned vector will be the same as the length of `chembeadpositions`

All positions will be the same except the first and last which may be moved in if the chem cylinder isn't full.
"""
function _get_nodepositions(chembeadpositions::Vector{SVector{3,Float64}}, mon_id_first::Int, mon_id_last::Int, numpercylinder::Int)::Vector{SVector{3,Float64}}
    nodepositions = copy(chembeadpositions)
    @argcheck mon_id_last > mon_id_first
    # get the expected number of beads based on the monomer ids and numpercylinder
    firstcylinderid = fld(mon_id_first, numpercylinder)
    lastcylinderid = fld(mon_id_last, numpercylinder)
    numbeads = lastcylinderid - firstcylinderid + 2
    @argcheck numbeads == length(chembeadpositions)
    #undo extended ends
    a = mod(mon_id_first,numpercylinder)
    b = numpercylinder
    nodepositions[begin] = (1-a/b)*chembeadpositions[begin] + (a/b)*chembeadpositions[begin+1]
    midlast = mon_id_last + 1
    a = mod(-midlast,numpercylinder)
    nodepositions[end] = (1-a/b)*chembeadpositions[end] + (a/b)*chembeadpositions[end-1]
    nodepositions
end


"""
Set `chembeadpositions` based on `nodepos`

The indexes of `chembeadpositions` and `nodepos` must match

All positions will be the same except the first and last which may be moved out if the chem cylinder isn't full.
"""
function set_nodepositions!(
        chembeadpositions::AbstractVector{SVector{3,Float64}},
        nodepos::AbstractVector{SVector{3,Float64}},
        mon_id_first::Int,
        mon_id_last::Int,
        numpercylinder::Int,
    )::Nothing
    @argcheck eachindex(chembeadpositions) == eachindex(nodepos)
    @argcheck mon_id_last > mon_id_first
    # get the expected number of beads based on the monomer ids and numpercylinder
    firstcylinderid = fld(mon_id_first, numpercylinder)
    lastcylinderid = fld(mon_id_last, numpercylinder)
    numbeads = lastcylinderid - firstcylinderid + 2
    @argcheck numbeads == length(chembeadpositions)
    chembeadpositions .= nodepos
    # Extend first bead to a full cylinder.
    midfirstbead = mon_id_first
    midnextbead = min(fld(midfirstbead,numpercylinder)*numpercylinder + numpercylinder, mon_id_last+1)
    a = - mod(midfirstbead, numpercylinder)
    b = midnextbead - midfirstbead
    chembeadpositions[begin] = (1-a/b)*nodepos[begin] + (a/b)*nodepos[begin+1]
    # Extend last bead to a full cylinder.
    midlastbead = mon_id_last + 1
    midprevbead = max(fld(midlastbead-1,numpercylinder)*numpercylinder, mon_id_first)
    a = - mod(-midlastbead,numpercylinder)
    b = midlastbead - midprevbead
    chembeadpositions[end] = (1-a/b)*nodepos[end] + (a/b)*nodepos[end-1]
    nothing
end


"""
Return the node monomer ids of the filament
"""
function _fil_node_mon_ids(mon_id_first::Int, mon_id_last::Int, numpercylinder::Int)::Vector{Int}
    invnumpercylinder = inv(numpercylinder)
    firstcylinderidfrac = (mon_id_first + 0.5)*invnumpercylinder
    firstcylinderid = Int(round(firstcylinderidfrac,RoundDown))
    nextbeadmid = (firstcylinderid + 1)*numpercylinder
    node_mids = [mon_id_first; nextbeadmid:numpercylinder:mon_id_last; mon_id_last+1]
    node_mids
end

"""
Return the full range of possible mon_ids on a cylinder,
"""
function _fil_cyl_mon_ids(fil_cyl_idx::Int, mon_id_first::Int, mon_id_last::Int, numpercylinder::Int)
    invnumpercylinder = inv(numpercylinder)
    firstcylinderidfrac = (mon_id_first + 0.5)*invnumpercylinder
    firstcylinderid = Int(round(firstcylinderidfrac,RoundDown))
    cyl_id = fil_cyl_idx + firstcylinderid - 1
    start_mid = cyl_id*numpercylinder
    stop_mid = (cyl_id + 1)*numpercylinder - 1
    start_mid:stop_mid
end




"""
Return chem cylinder index on a filament and chem cylinder frac of a monomer id
frac is a float, 0.0 if the monomer is at the chem bead on the minus end of the cylinder,
1.0 if it is at the chem bead on the plus end of the cylinder.
"""
function get_fil_chem_cyl_idx_frac(
        mon_id::Int,
        mon_id_first::Int,
        mon_id_last::Int,
        numpercylinder::Int,
    )
    @argcheck mon_id in mon_id_first:mon_id_last
    invnumpercylinder = inv(numpercylinder)
    cylinderidfrac = (mon_id + 0.5)*invnumpercylinder
    firstcylinderidfrac = (mon_id_first + 0.5)*invnumpercylinder
    firstcylinderid = unsafe_trunc(Int,round(firstcylinderidfrac,RoundDown))
    cylinderid = unsafe_trunc(Int,round(cylinderidfrac,RoundDown))
    cylinderidx= cylinderid - firstcylinderid + 1
    mon_id_on_cyl = mon_id - cylinderid*numpercylinder
    frac = (mon_id_on_cyl + 0.5)*invnumpercylinder
    return cylinderidx, frac
end


"""
Return mech cylinder index on a filament and mech cylinder frac of a monomer id
frac is a float, 0.0 if the monomer is at the mechanics node on the minus end of the cylinder,
1.0 if it is at the mechanics node on the plus end of the cylinder.
"""
function get_fil_mech_cyl_idx_frac(
        mon_id::Int,
        mon_id_first::Int,
        mon_id_last::Int,
        numpercylinder::Int,
    )
    @argcheck mon_id in mon_id_first:mon_id_last
    invnumpercylinder = inv(numpercylinder)
    cylinderidfrac = (mon_id + 0.5)*invnumpercylinder
    firstcylinderidfrac = (mon_id_first + 0.5)*invnumpercylinder
    firstcylinderid = unsafe_trunc(Int,round(firstcylinderidfrac,RoundDown))
    cylinderid = unsafe_trunc(Int,round(cylinderidfrac,RoundDown))
    cylinderidx= cylinderid - firstcylinderid + 1
    #The actual first and last monomer might be moved in if the cylinder isn't full.
    cyl_mon_id_first = max(cylinderid*numpercylinder, mon_id_first)
    cyl_mon_id_last = min(cylinderid*numpercylinder + numpercylinder - 1, mon_id_last)
    cyl_num_mons = cyl_mon_id_last - cyl_mon_id_first + 1
    mon_id_on_cyl = mon_id - cyl_mon_id_first
    frac = (mon_id_on_cyl + 0.5)*inv(cyl_num_mons)
    return cylinderidx, frac
end
