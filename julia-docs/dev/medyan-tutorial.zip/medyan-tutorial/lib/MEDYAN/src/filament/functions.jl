"""
    $(TYPEDSIGNATURES)
Return the number of filament types.
"""
function num_fila_types(c::Context)::Int
    length(c.chem_cylinders)
end


function _normalize_fila_type(c::Context, type::Union{Symbol,Integer})::Int
    if type isa Symbol
        c.sys_def.filament[type]
    else
        type
    end
end


"""
    $(TYPEDSIGNATURES)
Return the number of filaments of a given type.
"""
function num_fila(c::Context; type::Union{Integer, Symbol}=1)::Int
    length(c.chem_cylinders[_normalize_fila_type(c, type)].per_fil)
end


"""
    $(TYPEDSIGNATURES)
Return a read only `OffsetVector` of monomer states on a filament.

This can be invalid after any mutations to context, so copy if needed.
"""
function fila_mono_states(c::Context, f::FilaIdx)::OffsetVector{MonomerState, Vector{MonomerState}}
    cylinders::ChemCylinders = c.chem_cylinders[Int(f.typeid)]
    _fil_mon_states(cylinders, Int(f.idx))
end
fila_mono_states(c::Context, t::Tag) = fila_mono_states(c, FilaIdx(c, t::Tag))


"""
    $(TYPEDSIGNATURES)
Return the number of mechanical node positions of a filament.
"""
function fila_num_nodes(c::Context, f::FilaIdx)::Int
    cylinders::ChemCylinders = c.chem_cylinders[Int(f.typeid)]
    length(cylinders.per_fil.chembeadpositions[Int(f.idx)])
end
fila_num_nodes(c::Context, t::Tag)::Int = fila_num_nodes(c, FilaIdx(c, t))


"""
    $(TYPEDSIGNATURES)
Return the `node_mids` of the filament.

The `node_mids` are the monomer ids at (slightly plus side of) the `node_positions`

                                     |
                          -----+-----|-----+-----
      minus end <----       M  |  M  | (M) |  M        ----> plus end
                          -----+-----|-----+-----
                                     |
                                     ^ A node position is indicated by the line.
    
    The monomer id with parenthesis (M) will in `node_mids`

The first monomer id is the first monomer id on the filament.
The last monomer id is the last monomer id on the filament + 1
"""
function fila_node_mids(c::Context, f::FilaIdx)::Vector{Int}
    cylinders::ChemCylinders = c.chem_cylinders[Int(f.typeid)]
    _fil_node_mon_ids(cylinders, Int(f.idx))
end
fila_node_mids(c::Context, t::Tag)::Vector{Int} = fila_node_mids(c, FilaIdx(c, t))


"""
    $(TYPEDSIGNATURES)
Return the mechanical node positions of the filament.
"""
function fila_node_positions(c::Context, f::FilaIdx)::Vector{SVector{3, Float64}}
    cylinders::ChemCylinders = c.chem_cylinders[Int(f.typeid)]
    _get_nodepositions(cylinders, Int(f.idx))
end
fila_node_positions(c::Context, t::Tag)::Vector{SVector{3, Float64}} = fila_node_positions(c, FilaIdx(c, t))


"""
    $(TYPEDSIGNATURES)
Return the pair of minus end, plus end filament tip tags.
"""
function fila_tip_tags(c::Context, f::FilaIdx)::Pair{Tag{FilaTipIdx}, Tag{FilaTipIdx}}
    # TODO optimize this by storing tags in chemcylinders
    # This will not error because all the tips are already be tagged
    place2tag(c, FilaTipIdx(f, true)) => place2tag(c, FilaTipIdx(f, false))
end
fila_tip_tags(c::Context, t::Tag)::Pair{Tag{FilaTipIdx}, Tag{FilaTipIdx}} = fila_tip_tags(c, FilaIdx(c, t))

"""
Mark all filaments and monomers as minimized, for testing,
    this is normally done in helper_unvectorize_filaments!
"""
function helper_mark_monomers_minimized!(c::Context)
    for cylinders in c.chem_cylinders
        for filament in LazyRows(cylinders.per_fil)
            filament.minusend_num_notminimized = 0
            filament.plusend_num_notminimized = 0
        end
    end
    unset!(c.validflags, VFS_SEGMENTS)
    return
end

"""
Return a MonomerName of a random filamentsite, or return nothing if rejected
weighted by counts, using the default RNG
"""
function pickrandomfilamentsite(c::Context,cid,ftid,fsid)::Union{MonomerName,Nothing}
    helper_warn_chem_cache_invalid!(c)
    fxsid= c.filamentsites[ftid][fsid].fxsid
    totalsites= c.chemistryengine.fixedcounts[fxsid,cid]
    if iszero(totalsites)
        return
    end
    filamentsite= c.filamentsites[ftid][fsid].site
    u::Q31f32= Q31f32(totalsites*rand())
    #go through each segment in the compartment
    comp= c.compartments[cid]
    for segment in comp.segments[ftid]
        u -= segment.filamentsitecounts[fsid]
        if u ≤ 0
            #site is on this segment, go though all monomers
            u += segment.filamentsitecounts[fsid]
            monstates = fil_mon_states(c, segment.ftid, segment.fid)
            for mid in segment.midminusend:segment.midplusend
                plusrange= getplusrange(filamentsite)
                minusrange= getminusrange(filamentsite)
                mmid= mid - minusrange
                pmid= mid + plusrange
                #make sure states are in bound
                if mmid ≥ firstindex(monstates) && pmid ≤ lastindex(monstates)
                    states= monstates[mmid:pmid]
                    u -= Q31f32(filamentsitecount(filamentsite,states))
                    if u ≤ 0
                        return MonomerName(ftid,segment.fid,mid)
                    end
                end
            end
        end
    end
    return
end


"""
Return a MonomerName of the end monomer of a random filamentend site, or return nothing if rejected
weighted by counts, using the default RNG
"""
function pickrandomfilamentendsite(c::Context,cid,ftid,fesid)::Union{MonomerName,Nothing}
    helper_warn_chem_cache_invalid!(c)
    fxsid= c.filamentendsites[ftid][fesid].fxsid
    totalsites= c.chemistryengine.fixedcounts[fxsid,cid]
    if iszero(totalsites)
        return
    end
    filamentendsite= c.filamentendsites[ftid][fesid].site
    u::Q31f32= Q31f32(totalsites*rand())
    #go through each segment in the compartment
    comp= c.compartments[cid]
    for segment in comp.segments[ftid]
        u -= segment.filamentendsitecounts[fesid]
        if u ≤ 0
            if isminusend(filamentendsite)
                return MonomerName(ftid,segment.fid,segment.midminusend)
            else
                return MonomerName(ftid,segment.fid,segment.midplusend)
            end
        end
    end
end

function helper_filamentendsitecounts(c::Context,segment::Segment,filamentendsite)::Float64
    ftid = segment.ftid
    #minus end
    if isminusend(filamentendsite)
        if !isminusendsegment(segment)
            return 0.0
        end
        #check range
        n= getrange(filamentendsite)
        monstates = fil_mon_states(c, ftid, segment.fid)
        cylinders = c.chem_cylinders[ftid]
        fil_idx = cylinders.fil_id_2_idx[segment.fid]
        endloadforce = cylinders.per_fil.endloadforces[fil_idx][1]
        if length(monstates)<n
            return 0.0
        end
        # ensure too many monomers aren't added between minimization.
        num_added = added_monomers(filamentendsite)
        if num_added > 0
            num_unmin = cylinders.per_fil.minusend_num_notminimized[fil_idx]
            max_unmin = c.filamentmechparams[ftid].max_num_unmin_end
            @assert max_unmin ≥ 0
            if (num_added + num_unmin) > max_unmin
                return 0.0
            end
        end
        states= monstates[begin:begin+n-1]
        ratefactor= exp(-c.β*spacing(filamentendsite)*endloadforce)
        return ratefactor * filamentendsitecount(filamentendsite,states)
    #plus end
    else
        if !isplusendsegment(segment)
            return 0.0
        end
        #check range
        n= getrange(filamentendsite)
        monstates = fil_mon_states(c, segment.ftid, segment.fid)
        cylinders = c.chem_cylinders[segment.ftid]
        fil_idx = cylinders.fil_id_2_idx[segment.fid]
        endloadforce = cylinders.per_fil.endloadforces[fil_idx][2]
        if length(monstates)<n
            return 0.0
        end
        # ensure too many monomers aren't added between minimization.
        num_added = added_monomers(filamentendsite)
        if num_added > 0
            num_unmin = cylinders.per_fil.plusend_num_notminimized[fil_idx]
            max_unmin = c.filamentmechparams[ftid].max_num_unmin_end
            @assert max_unmin ≥ 0
            if (num_added + num_unmin) > max_unmin
                return 0.0
            end
        end
        states= monstates[end-n+1:end]
        ratefactor= exp(-c.β*spacing(filamentendsite)*endloadforce)
        return ratefactor * filamentendsitecount(filamentendsite,states)
    end
end

"""
Reset link site counts effected by the change to one monomer state.
"""
function helper_reset_links_one_monomer!(c::Context, p::FilaMonoIdx)
    plus_end = FilaTipIdx(c, p, +)
    minus_end = FilaTipIdx(c, p, -)
    for offset in -1:+1
        mon = FilaMonoIdx(c, p, offset)
        for link in place2links(c, mon)
            _update_link_reactions!(c, link)
        end
        if mon == FilaMonoIdx(c, plus_end)
            for link in place2links(c, plus_end)
                _update_link_reactions!(c, link)
            end
        end
        if mon == FilaMonoIdx(c, minus_end)
            for link in place2links(c, minus_end)
                _update_link_reactions!(c, link)
            end
        end
    end
end

"""
Update compartment segment data from filamentdata.
Doesn't update other compartmentdata or any reaction counts
"""
function helper_resetsegments!(c::Context)
    #clear current segments
    num_filament_types= num_fila_types(c)
    for comp in c.compartments
        for ftid in 1:num_filament_types
            empty!(comp.segments[ftid])
        end
    end
    #create segments
    for ftid in 1:num_filament_types
        cylinders = c.chem_cylinders[ftid]
        for fil_idx in eachindex(cylinders.per_fil)
            fid = cylinders.per_fil.id[fil_idx]
            monstates = _fil_mon_states(cylinders, fil_idx)
            mid= firstindex(monstates)
            cid= get_compartment_id(c, _mon_position(cylinders, fil_idx, mid))
            seg= Segment(cid= cid,
                        ftid= ftid,
                        fid= fid,
                        midminusend= mid,
                        midplusend= mid,
                        plusend_cid= -1,#plus cid does not exist yet
                        minusend_cid= -1,#minus end does not exist
                        filamentsitecounts= zeros(length(c.filamentsites[ftid])),
                        filamentendsitecounts= zeros(length(c.filamentendsites[ftid])),
                    )
            push!(c.compartments[cid].segments[ftid], seg)
            last_seg= seg
            last_cid= cid
            for mid in (firstindex(monstates)+1):lastindex(monstates)
                cid= get_compartment_id(c, _mon_position(cylinders, fil_idx, mid))
                if cid==last_cid
                    last_seg.midplusend= mid
                else
                    #left last_cid, create new segment
                    last_seg.plusend_cid= cid
                    seg= Segment(cid= cid,
                        ftid= ftid,
                        fid= fid,
                        midminusend= mid,
                        midplusend= mid,
                        plusend_cid= -1,#plus cid does not exist yet
                        minusend_cid= last_cid,
                        filamentsitecounts= zeros(length(c.filamentsites[ftid])),
                        filamentendsitecounts= zeros(length(c.filamentendsites[ftid])),
                    )
                    push!(c.compartments[cid].segments[ftid], seg)
                    last_seg= seg
                    last_cid= cid
                end
            end
        end
    end
end

"""
Update filament site and filament end site counts on a single segment.
Delta gets sent to chemistryengine
Make sure `segment.filamentsitecounts` is what it was before the state change,
Only updates filamentendsitecounts if the segment is at an end.
"""
function helper_updatesegmentsitecounts!(c::Context, segment::Segment)
    requireall(c.validflags, VFS_SEGMENTS)
    ftid = segment.ftid
    fid = segment.fid
    cid = segment.cid
    # check if segment is a filament end
    if isminusendsegment(segment) || isplusendsegment(segment)
        #go through all filamentendsites and add counts to chemistryengine
        for siteinfo in c.filamentendsites[ftid]
            newsitecount = Q31f32(helper_filamentendsitecounts(c,segment,siteinfo.site))
            oldsitecount = segment.filamentendsitecounts[siteinfo.id]
            if newsitecount != oldsitecount
                addfixedspeciescount!(c.chemistryengine,siteinfo.fxsid,cid,newsitecount-oldsitecount)
                segment.filamentendsitecounts[siteinfo.id] = newsitecount
            end
        end
    end
    filamentsitecounts= zeros(Q31f32,length(c.filamentsites[ftid]))
    monstates = fil_mon_states(c, ftid, fid)
    for mid in segment.midminusend:segment.midplusend
        for sitetuple in c.filamentsites[ftid]
            fsid= sitetuple.id
            filamentsite= sitetuple.site
            plusrange= getplusrange(filamentsite)
            minusrange= getminusrange(filamentsite)
            mmid= mid - minusrange
            pmid= mid + plusrange
            #make sure states are in bound
            if mmid ≥ firstindex(monstates) && pmid ≤ lastindex(monstates)
                states= monstates[mmid:pmid]
                s= Q31f32(filamentsitecount(filamentsite,states))
                filamentsitecounts[fsid] += s
            end
        end
    end
    for fsid in eachindex(filamentsitecounts)
        newsitecount = filamentsitecounts[fsid]
        oldsitecount = segment.filamentsitecounts[fsid]
        if newsitecount != oldsitecount
            fxsid= c.filamentsites[ftid][fsid].fxsid
            addfixedspeciescount!(c.chemistryengine,fxsid,cid,newsitecount-oldsitecount)
            segment.filamentsitecounts[fsid] = newsitecount
        end
    end
end

"""
delete a segment and subtract all site counts
"""
function helper_deletesegment!(c::Context, cid, ftid, sid)
    requireall(c.validflags, VFS_SEGMENTS)
    comp = c.compartments[cid]
    segs = comp.segments[ftid]
    seg = segs[sid]
    #go through all filamentendsites and add counts to chemistryengine
    for siteinfo in c.filamentendsites[ftid]
        counts = seg.filamentendsitecounts[siteinfo.id]
        if !iszero(counts)
            addfixedspeciescount!(c.chemistryengine,siteinfo.fxsid,cid,-counts)
        end
    end
    for siteinfo in c.filamentsites[ftid]
        counts = seg.filamentsitecounts[siteinfo.id]
        if !iszero(counts)
            addfixedspeciescount!(c.chemistryengine,siteinfo.fxsid,cid,-counts)
        end
    end
    #now delete
    segs[sid] = segs[end]
    pop!(segs)
    return
end


"""
Update filament end site counts on a single segment even if it no longer is an end.
Delta gets sent to chemistryengine
Make sure `segment.filamentendsitecounts` is what it was before the state change,
"""
function helper_updatesegment_filamentendsitecounts!(c::Context, segment::Segment)
    requireall(c.validflags, VFS_SEGMENTS)
    ftid = segment.ftid
    fid = segment.fid
    cid = segment.cid
    #go through all filamentendsites and add counts to chemistryengine
    for siteinfo in c.filamentendsites[ftid]
        newsitecount = Q31f32(helper_filamentendsitecounts(c,segment,siteinfo.site))
        oldsitecount = segment.filamentendsitecounts[siteinfo.id]
        if newsitecount != oldsitecount
            addfixedspeciescount!(c.chemistryengine,siteinfo.fxsid,cid,newsitecount-oldsitecount)
            segment.filamentendsitecounts[siteinfo.id] = newsitecount
        end
    end
end

"""
Return the segments that can have filament sites or filament end sites effected by a change to monomer states from midstart to midstop
"""
function helper_get_filsite_effected_segments(c::Context,ftid,fid,midstart,midstop)::Vector{Segment}
    requireall(c.validflags, VFS_SEGMENTS)
    monstates = fil_mon_states(c, ftid, fid)
    midminusend = firstindex(monstates)
    midplusend = lastindex(monstates)
    midminusmaxrange = c.maxfilsite_minusrange[ftid]
    midplusmaxrange = c.maxfilsite_plusrange[ftid]
    midstarteffect = max(midstart-midplusmaxrange,midminusend)
    midstopeffect = min(midstop+midminusmaxrange,midplusend)
    
    mid = midstarteffect
    cid = get_compartment_id(c, MonomerName(ftid,fid,mid))
    segments = Vector{Segment}()
    while true
        comp = c.compartments[cid]
        sid, seg = findsegment(comp,MonomerName(ftid,fid,mid))
        push!(segments,seg)
        if midstopeffect > seg.midplusend
            cid= seg.plusend_cid
            mid= seg.midplusend+1
        else
            return segments
        end
    end
end

"""
Reset the filament and filamentend site counts and fixedspecies number after segments are reset
"""
function helper_resetfilamentsitecounts!(c::Context)
    #go through segments and get the filament site counts
    for comp in c.compartments
        for ftid in 1:num_fila_types(c)
            filamentsitecounts= zeros(Q31f32,length(c.filamentsites[ftid]))
            filamentendsitecounts= zeros(Q31f32,length(c.filamentendsites[ftid]))
            for segment in comp.segments[ftid]
                monstates = fil_mon_states(c, ftid, segment.fid)
                segment.filamentsitecounts .= 0
                segment.filamentendsitecounts .= 0
                for mid in segment.midminusend:segment.midplusend
                    for sitetuple in c.filamentsites[ftid]
                        fsid= sitetuple.id
                        filamentsite= sitetuple.site
                        plusrange= getplusrange(filamentsite)
                        minusrange= getminusrange(filamentsite)
                        mmid= mid - minusrange
                        pmid= mid + plusrange
                        #make sure states are in bound
                        if mmid ≥ firstindex(monstates) && pmid ≤ lastindex(monstates)
                            states= monstates[mmid:pmid]
                            s= Q31f32(filamentsitecount(filamentsite,states))
                            segment.filamentsitecounts[fsid] += s
                            filamentsitecounts[fsid] += s
                        end
                    end
                end
                for fesid in eachindex(filamentendsitecounts)
                    s = Q31f32(helper_filamentendsitecounts(c,segment,c.filamentendsites[ftid][fesid].site))
                    segment.filamentendsitecounts[fesid] += s
                    filamentendsitecounts[fesid] += s
                end
            end
            for fsid in eachindex(filamentsitecounts)
                fxsid= c.filamentsites[ftid][fsid].fxsid
                setfixedspeciescount!(c.chemistryengine,fxsid,comp.id,filamentsitecounts[fsid])
            end
            for fesid in eachindex(filamentendsitecounts)
                fxsid= c.filamentendsites[ftid][fesid].fxsid
                setfixedspeciescount!(c.chemistryengine,fxsid,comp.id,filamentendsitecounts[fesid])
            end
        end
    end
end

function ChemCylinders(ftid::Integer, numpercylinder::Integer)
    ChemCylinders(;
        ftid,
        numpercylinder,
    )
end


function assert_invariants(cylinders::ChemCylinders)
    for hole in cylinders.holes
        @argcheck !cylinders.per_cyl.exists[hole]
    end
    num_cyl_exist = length(cylinders.per_cyl) - length(cylinders.holes)
    @argcheck sum(cylinders.per_cyl.exists) == num_cyl_exist
    num_cyl_in_filaments = 0
    @argcheck length(cylinders.per_fil) == length(keys(cylinders.fil_id_2_idx))
    for fil_idx in 1:length(cylinders.per_fil)
        fil = LazyRow(cylinders.per_fil, fil_idx)
        fil_id = fil.id
        @argcheck fil_idx == cylinders.fil_id_2_idx[fil_id]
        for cyl_idx in fil.cyl_idxs
            @argcheck cylinders.per_cyl.exists[cyl_idx]
            @argcheck fil_id == cylinders.per_cyl.fil_id[cyl_idx]
        end
        num_cyl_on_fil = length(fil.cyl_idxs)
        @argcheck num_cyl_on_fil > 0
        @argcheck num_cyl_on_fil == length(fil.chembeadpositions) - 1
        @argcheck fil.mon_id_last - fil.mon_id_first == length(fil.monomerstates) - 1
        num_cyl_in_filaments += num_cyl_on_fil
    end
    @argcheck num_cyl_in_filaments == num_cyl_exist
end


"""
Return mon_id_first, mon_id_last, numpercylinder
"""
function _mon_id_info(cylinders::ChemCylinders, fil_idx::Int)::NTuple{3, Int}
    mon_id_first::Int = cylinders.per_fil.mon_id_first[fil_idx]
    mon_id_last::Int = cylinders.per_fil.mon_id_last[fil_idx]
    numpercylinder::Int = cylinders.numpercylinder
    (
        mon_id_first,
        mon_id_last,
        numpercylinder,
    )
end


"""
    $(TYPEDSIGNATURES)
Return a read only OffsetVector of monomer states on a filament.

This can be invalid after any mutations to context, so copy if needed.
"""
function _fil_mon_states(cylinders::ChemCylinders, fil_idx::Int)::OffsetVector{MonomerState, Vector{MonomerState}}
    mon_id_first = cylinders.per_fil.mon_id_first[fil_idx]
    OffsetArrays.Origin(mon_id_first)(cylinders.per_fil.monomerstates[fil_idx])
end


function _mon_position(cylinders::ChemCylinders, fil_idx::Int, mon_id::Int)
    fil_cyl_idx, frac = @inline(get_fil_chem_cyl_idx_frac(
        mon_id,
        _mon_id_info(cylinders, fil_idx)...
    ))
    chembeadpositions = cylinders.per_fil.chembeadpositions[fil_idx]
    r1 = chembeadpositions[fil_cyl_idx]
    r2 = chembeadpositions[fil_cyl_idx + 1]
    frac*r2 + (1.0-frac)*r1
end


function _mon_plusvector(cylinders::ChemCylinders, fil_idx::Int, mon_id::Int)
    fil_cyl_idx, frac = get_fil_chem_cyl_idx_frac(
        mon_id,
        _mon_id_info(cylinders, fil_idx)...
    )
    chembeadpositions = cylinders.per_fil.chembeadpositions[fil_idx]
    r1 = chembeadpositions[fil_cyl_idx]
    r2 = chembeadpositions[fil_cyl_idx + 1]
    normalize_fast(r2 - r1)
end


function _mon_position_plusvector(cylinders::ChemCylinders, fil_idx::Int, mon_id::Int)
    fil_cyl_idx, frac = get_fil_chem_cyl_idx_frac(
        mon_id,
        _mon_id_info(cylinders, fil_idx)...
    )
    chembeadpositions = cylinders.per_fil.chembeadpositions[fil_idx]
    r1 = chembeadpositions[fil_cyl_idx]
    r2 = chembeadpositions[fil_cyl_idx + 1]
    pos = frac*r2 + (1.0-frac)*r1
    plusv = normalize_fast(r2 - r1)
    pos, plusv
end


function _get_nodepositions(cylinders::ChemCylinders, fil_idx::Int)::Vector{SVector{3,Float64}}
    _get_nodepositions(
        cylinders.per_fil.chembeadpositions[fil_idx],
        _mon_id_info(cylinders, fil_idx)...
    )
end


"""
Return the number of monomers on the minus end cylinder
"""
function _get_nummonomersminusend(cylinders::ChemCylinders, fil_idx::Int)::Int
    if length(cylinders.per_fil.chembeadpositions[fil_idx])==2
        #just one cylinder
        return length(cylinders.per_fil.monomerstates[fil_idx])
    else
        return cylinders.numpercylinder - mod(cylinders.per_fil.mon_id_first[fil_idx], cylinders.numpercylinder)
    end
end


"""
Return the number of monomers on the plus end cylinder
"""
function _get_nummonomersplusend(cylinders::ChemCylinders, fil_idx::Int)::Int
    if length(cylinders.per_fil.chembeadpositions[fil_idx])==2
        #just one cylinder
        return length(cylinders.per_fil.monomerstates[fil_idx])
    else
        return mod(cylinders.per_fil.mon_id_last[fil_idx], cylinders.numpercylinder) + 1
    end
end


function _fil_node_mon_ids(cylinders::ChemCylinders, fil_idx::Int)::Vector{Int}
    _fil_node_mon_ids(
        _mon_id_info(cylinders, fil_idx)...
    )
end


function Base.empty!(cylinders::ChemCylinders)
    empty!(cylinders.per_cyl)
    empty!(cylinders.holes)
    empty!(cylinders.fil_id_2_idx)
    empty!(cylinders.per_fil)
end


function Base.isempty(cylinders::ChemCylinders)
    isempty(cylinders.per_cyl)
end

"""
Rearrange cylinders to remove holes. After this all cylinders should exist.
"""
function fill_holes!(cylinders::ChemCylinders)
    assert_invariants(cylinders)
    currentsize = length(cylinders.per_cyl)
    finalsize = currentsize - length(cylinders.holes)
    hole_idx = 1
    for cyl_idx in (finalsize+1):currentsize
        if cylinders.per_cyl.exists[cyl_idx]
            while cylinders.holes[hole_idx] > finalsize
                hole_idx += 1
            end
            hole = cylinders.holes[hole_idx]
            hole_idx += 1
            # hole is an empty idx inside the final array 
            # to be filled by `cyl_idx`, a not empty element outside the final array.
            @assert !cylinders.per_cyl.exists[hole]
            @assert cylinders.per_cyl.exists[cyl_idx]
            cyl = cylinders.per_cyl[cyl_idx]
            cylinders.per_cyl[hole] = cyl
            fil_id = cyl.fil_id
            fil_idx = cylinders.fil_id_2_idx[fil_id]
            replace!(cylinders.per_fil.cyl_idxs[fil_idx], cyl_idx=>hole)
        end
    end
    resize!(cylinders.per_cyl, finalsize)
    empty!(cylinders.holes)
    @assert all(cylinders.per_cyl.exists)
    assert_invariants(cylinders)
end

"""
Returns the chem bead positions

The monomers are coarse grained such that every `numpercylinder` monomer is a cylinder,
beads are between two monomers and monomers are linearly interpolated between beads.

chem beads are linearly interpolated between `nodepositions` 
    so that the monomers to the right of the beads have ids divisible by `cylinders.numpercylinder`,
    the first and last beads, can be extended from `nodepositions[begin]`, `nodepositions[end]`, so they won't change when a monomer is (de)polymerized.

The `full_node_mids` are the monomer ids at (slightly plus side of) the `nodepositions`
`full_node_mids[end]` is the last monomer id + 1

                                     |
                          -----+-----|-----+-----
      minus end <----       M  |  M  | (M) |  M        ----> plus end
                          -----+-----|-----+-----
                                     |
                                     ^ A nodeposition is indicated by the line.
    
The monomer id with parenthesis (M) will in `full_node_mids`
"""
function interpolate_chem_beads(full_node_mids::Vector{Int}, nodepositions::Vector{SVector{3,Float64}}, numpercylinder::Int)::Vector{SVector{3,Float64}}
    @argcheck length(full_node_mids) == length(nodepositions)
    @argcheck numpercylinder > 0
    cyl_lengths = full_node_mids[begin+1:end] - full_node_mids[begin:end-1]
    @argcheck all(>(0), cyl_lengths)
    firstmonomerid = full_node_mids[begin]
    firstcylinderid = fld(firstmonomerid,numpercylinder)
    lastmonomerid = full_node_mids[end] - 1
    lastcylinderid= fld(lastmonomerid,numpercylinder)
    numbeads = lastcylinderid - firstcylinderid + 2
    chembeadpositions = fill(SA[NaN,NaN,NaN],numbeads)
    #first bead
    a = - mod(full_node_mids[begin],numpercylinder)
    b = full_node_mids[begin+1] - full_node_mids[begin]
    chembeadpositions[begin] = (1-a/b)*nodepositions[begin] + (a/b)*nodepositions[begin+1]
    #middle beads
    bead_idx = 2
    node_idx = 2
    targetmid = (firstcylinderid+1)*numpercylinder
    while bead_idx < numbeads
        while full_node_mids[node_idx] < targetmid
            node_idx += 1
        end
        a = full_node_mids[node_idx] - targetmid
        b = full_node_mids[node_idx] - full_node_mids[node_idx-1]
        chembeadpositions[bead_idx] = (1-a/b)*nodepositions[node_idx] + (a/b)*nodepositions[node_idx-1]
        bead_idx += 1
        targetmid += numpercylinder
    end
    #last bead
    a = -mod(-full_node_mids[end],numpercylinder)
    b = full_node_mids[end] - full_node_mids[end-1]
    chembeadpositions[end] = (1-a/b)*nodepositions[end] + (a/b)*nodepositions[end-1]
    chembeadpositions
end


"""
Return the node positions with the ends at the actual ends of the filament.

The length of the returned vector will be the same as the length of `chembeadpositions`

All positions will be the same except the first and last which may be moved in if the chem cylinder isn't full.
"""
function _get_nodepositions(chembeadpositions::Vector{SVector{3,Float64}}, mon_id_first::Int, mon_id_last::Int, numpercylinder::Int)::Vector{SVector{3,Float64}}
    nodepositions = copy(chembeadpositions)
    @argcheck mon_id_last > mon_id_first
    # get the expected number of beads based on the monomer ids and numpercylinder
    firstcylinderid = fld(mon_id_first, numpercylinder)
    lastcylinderid = fld(mon_id_last, numpercylinder)
    numbeads = lastcylinderid - firstcylinderid + 2
    @argcheck numbeads == length(chembeadpositions)
    #undo extended ends
    a = mod(mon_id_first,numpercylinder)
    b = numpercylinder
    nodepositions[begin] = (1-a/b)*chembeadpositions[begin] + (a/b)*chembeadpositions[begin+1]
    midlast = mon_id_last + 1
    a = mod(-midlast,numpercylinder)
    nodepositions[end] = (1-a/b)*chembeadpositions[end] + (a/b)*chembeadpositions[end-1]
    nodepositions
end


"""
Set `chembeadpositions` based on `nodepos`

The indexes of `chembeadpositions` and `nodepos` must match

All positions will be the same except the first and last which may be moved out if the chem cylinder isn't full.
"""
function set_nodepositions!(
        chembeadpositions::AbstractVector{SVector{3,Float64}},
        nodepos::AbstractVector{SVector{3,Float64}},
        mon_id_first::Int,
        mon_id_last::Int,
        numpercylinder::Int,
    )::Nothing
    @argcheck eachindex(chembeadpositions) == eachindex(nodepos)
    @argcheck mon_id_last > mon_id_first
    # get the expected number of beads based on the monomer ids and numpercylinder
    firstcylinderid = fld(mon_id_first, numpercylinder)
    lastcylinderid = fld(mon_id_last, numpercylinder)
    numbeads = lastcylinderid - firstcylinderid + 2
    @argcheck numbeads == length(chembeadpositions)
    chembeadpositions .= nodepos
    # Extend first bead to a full cylinder.
    midfirstbead = mon_id_first
    midnextbead = min(fld(midfirstbead,numpercylinder)*numpercylinder + numpercylinder, mon_id_last+1)
    a = - mod(midfirstbead, numpercylinder)
    b = midnextbead - midfirstbead
    chembeadpositions[begin] = (1-a/b)*nodepos[begin] + (a/b)*nodepos[begin+1]
    # Extend last bead to a full cylinder.
    midlastbead = mon_id_last + 1
    midprevbead = max(fld(midlastbead-1,numpercylinder)*numpercylinder, mon_id_first)
    a = - mod(-midlastbead,numpercylinder)
    b = midlastbead - midprevbead
    chembeadpositions[end] = (1-a/b)*nodepos[end] + (a/b)*nodepos[end-1]
    nothing
end


"""
Return the node monomer ids of the filament
"""
function _fil_node_mon_ids(mon_id_first::Int, mon_id_last::Int, numpercylinder::Int)::Vector{Int}
    invnumpercylinder = inv(numpercylinder)
    firstcylinderidfrac = (mon_id_first + 0.5)*invnumpercylinder
    firstcylinderid = Int(round(firstcylinderidfrac,RoundDown))
    nextbeadmid = (firstcylinderid + 1)*numpercylinder
    node_mids = [mon_id_first; nextbeadmid:numpercylinder:mon_id_last; mon_id_last+1]
    node_mids
end

"""
Return the full range of possible mon_ids on a cylinder,
"""
function _fil_cyl_mon_ids(fil_cyl_idx::Int, mon_id_first::Int, mon_id_last::Int, numpercylinder::Int)
    invnumpercylinder = inv(numpercylinder)
    firstcylinderidfrac = (mon_id_first + 0.5)*invnumpercylinder
    firstcylinderid = Int(round(firstcylinderidfrac,RoundDown))
    cyl_id = fil_cyl_idx + firstcylinderid - 1
    start_mid = cyl_id*numpercylinder
    stop_mid = (cyl_id + 1)*numpercylinder - 1
    start_mid:stop_mid
end




"""
Return chem cylinder index on a filament and chem cylinder frac of a monomer id
frac is a float, 0.0 if the monomer is at the chem bead on the minus end of the cylinder,
1.0 if it is at the chem bead on the plus end of the cylinder.
"""
function get_fil_chem_cyl_idx_frac(
        mon_id::Int,
        mon_id_first::Int,
        mon_id_last::Int,
        numpercylinder::Int,
    )
    @argcheck mon_id in mon_id_first:mon_id_last
    invnumpercylinder = inv(numpercylinder)
    cylinderidfrac = (mon_id + 0.5)*invnumpercylinder
    firstcylinderidfrac = (mon_id_first + 0.5)*invnumpercylinder
    firstcylinderid = unsafe_trunc(Int,round(firstcylinderidfrac,RoundDown))
    cylinderid = unsafe_trunc(Int,round(cylinderidfrac,RoundDown))
    cylinderidx= cylinderid - firstcylinderid + 1
    mon_id_on_cyl = mon_id - cylinderid*numpercylinder
    frac = (mon_id_on_cyl + 0.5)*invnumpercylinder
    return cylinderidx, frac
end


"""
Return mech cylinder index on a filament and mech cylinder frac of a monomer id
frac is a float, 0.0 if the monomer is at the mechanics node on the minus end of the cylinder,
1.0 if it is at the mechanics node on the plus end of the cylinder.
"""
function get_fil_mech_cyl_idx_frac(
        mon_id::Int,
        mon_id_first::Int,
        mon_id_last::Int,
        numpercylinder::Int,
    )
    @argcheck mon_id in mon_id_first:mon_id_last
    invnumpercylinder = inv(numpercylinder)
    cylinderidfrac = (mon_id + 0.5)*invnumpercylinder
    firstcylinderidfrac = (mon_id_first + 0.5)*invnumpercylinder
    firstcylinderid = unsafe_trunc(Int,round(firstcylinderidfrac,RoundDown))
    cylinderid = unsafe_trunc(Int,round(cylinderidfrac,RoundDown))
    cylinderidx= cylinderid - firstcylinderid + 1
    #The actual first and last monomer might be moved in if the cylinder isn't full.
    cyl_mon_id_first = max(cylinderid*numpercylinder, mon_id_first)
    cyl_mon_id_last = min(cylinderid*numpercylinder + numpercylinder - 1, mon_id_last)
    cyl_num_mons = cyl_mon_id_last - cyl_mon_id_first + 1
    mon_id_on_cyl = mon_id - cyl_mon_id_first
    frac = (mon_id_on_cyl + 0.5)*inv(cyl_num_mons)
    return cylinderidx, frac
end
