"""
    $(TYPEDSIGNATURES)
Return the number of filament types.
"""
function num_fila_types(c::Context)::Int
    length(c.chem_cylinders)
end


function _normalize_fila_type(c::Context, type::Union{Symbol,Integer})::Int
    if type isa Symbol
        c.sys_def.filament[type]
    else
        type
    end
end


"""
    $(TYPEDSIGNATURES)
Return the number of filaments of a given type.
"""
function num_fila(c::Context; type::Union{Integer, Symbol}=1)::Int
    length(c.chem_cylinders[_normalize_fila_type(c, type)].per_fil)
end


"""
    $(TYPEDSIGNATURES)
Return a read only `OffsetVector` of monomer states on a filament.

This can be invalid after any mutations to context, so copy if needed.
"""
function fila_mono_states(c::Context, f::FilaIdx)::OffsetVector{MonomerState, Vector{MonomerState}}
    cylinders::ChemCylinders = c.chem_cylinders[Int(f.typeid)]
    _fil_mon_states(cylinders, Int(f.idx))
end
fila_mono_states(c::Context, t::Tag) = fila_mono_states(c, FilaIdx(c, t::Tag))


"""
    $(TYPEDSIGNATURES)
Return the number of mechanical node positions of a filament.
"""
function fila_num_nodes(c::Context, f::FilaIdx)::Int
    cylinders::ChemCylinders = c.chem_cylinders[Int(f.typeid)]
    length(cylinders.per_fil.chembeadpositions[Int(f.idx)])
end
fila_num_nodes(c::Context, t::Tag)::Int = fila_num_nodes(c, FilaIdx(c, t))


"""
    $(TYPEDSIGNATURES)
Return the `node_mids` of the filament.

The `node_mids` are the monomer ids at (slightly plus side of) the `node_positions`

                                     |
                          -----+-----|-----+-----
      minus end <----       M  |  M  | (M) |  M        ----> plus end
                          -----+-----|-----+-----
                                     |
                                     ^ A node position is indicated by the line.
    
    The monomer id with parenthesis (M) will in `node_mids`

The first monomer id is the first monomer id on the filament.
The last monomer id is the last monomer id on the filament + 1
"""
function fila_node_mids(c::Context, f::FilaIdx)::Vector{Int}
    cylinders::ChemCylinders = c.chem_cylinders[Int(f.typeid)]
    _fil_node_mon_ids(cylinders, Int(f.idx))
end
fila_node_mids(c::Context, t::Tag)::Vector{Int} = fila_node_mids(c, FilaIdx(c, t))


"""
    $(TYPEDSIGNATURES)
Return the mechanical node positions of the filament.
"""
function fila_node_positions(c::Context, f::FilaIdx)::Vector{SVector{3, Float64}}
    cylinders::ChemCylinders = c.chem_cylinders[Int(f.typeid)]
    _get_nodepositions(cylinders, Int(f.idx))
end
fila_node_positions(c::Context, t::Tag)::Vector{SVector{3, Float64}} = fila_node_positions(c, FilaIdx(c, t))


"""
    $(TYPEDSIGNATURES)
Return the pair of minus end, plus end filament tip tags.
"""
function fila_tip_tags(c::Context, f::FilaIdx)::Pair{Tag{FilaTipIdx}, Tag{FilaTipIdx}}
    # TODO optimize this by storing tags in chemcylinders
    # This will not modify `c` because all the tips are already be tagged
    tag!(c, FilaTipIdx(f, true)) => tag!(c, FilaTipIdx(f, false))
end
fila_tip_tags(c::Context, t::Tag)::Pair{Tag{FilaTipIdx}, Tag{FilaTipIdx}} = fila_tip_tags(c, FilaIdx(c, t))

"""
Mark all filaments and monomers as minimized, for testing,
    this is normally done in helper_unvectorize_filaments!
"""
function helper_mark_monomers_minimized!(c::Context)
    for cylinders in c.chem_cylinders
        for filament in LazyRows(cylinders.per_fil)
            filament.minusend_num_notminimized = 0
            filament.plusend_num_notminimized = 0
        end
    end
    unset!(c.validflags, VFS_SEGMENTS)
    return
end

"""
Return a MonomerName of a random filamentsite, or return nothing if rejected
weighted by counts, using the default RNG
"""
function pickrandomfilamentsite(c::Context,cid,ftid,fsid)::Union{MonomerName,Nothing}
    helper_warn_chem_cache_invalid!(c)
    fxsid= c.filamentsites[ftid][fsid].fxsid
    totalsites= c.chemistryengine.fixedcounts[fxsid,cid]
    if iszero(totalsites)
        return
    end
    filamentsite= c.filamentsites[ftid][fsid].site
    u::Q31f32= Q31f32(totalsites*rand())
    #go through each segment in the compartment
    comp= c.compartments[cid]
    for segment in comp.segments[ftid]
        u -= segment.filamentsitecounts[fsid]
        if u ≤ 0
            #site is on this segment, go though all monomers
            u += segment.filamentsitecounts[fsid]
            monstates = fil_mon_states(c, segment.ftid, segment.fid)
            for mid in segment.midminusend:segment.midplusend
                plusrange= getplusrange(filamentsite)
                minusrange= getminusrange(filamentsite)
                mmid= mid - minusrange
                pmid= mid + plusrange
                #make sure states are in bound
                if mmid ≥ firstindex(monstates) && pmid ≤ lastindex(monstates)
                    states= monstates[mmid:pmid]
                    u -= Q31f32(filamentsitecount(filamentsite,states))
                    if u ≤ 0
                        return MonomerName(ftid,segment.fid,mid)
                    end
                end
            end
        end
    end
    return
end


"""
Return a MonomerName of the end monomer of a random filamentend site, or return nothing if rejected
weighted by counts, using the default RNG
"""
function pickrandomfilamentendsite(c::Context,cid,ftid,fesid)::Union{MonomerName,Nothing}
    helper_warn_chem_cache_invalid!(c)
    fxsid= c.filamentendsites[ftid][fesid].fxsid
    totalsites= c.chemistryengine.fixedcounts[fxsid,cid]
    if iszero(totalsites)
        return
    end
    filamentendsite= c.filamentendsites[ftid][fesid].site
    u::Q31f32= Q31f32(totalsites*rand())
    #go through each segment in the compartment
    comp= c.compartments[cid]
    for segment in comp.segments[ftid]
        u -= segment.filamentendsitecounts[fesid]
        if u ≤ 0
            if isminusend(filamentendsite)
                return MonomerName(ftid,segment.fid,segment.midminusend)
            else
                return MonomerName(ftid,segment.fid,segment.midplusend)
            end
        end
    end
end

function helper_filamentendsitecounts(c::Context,segment::Segment,filamentendsite)::Float64
    ftid = segment.ftid
    #minus end
    if isminusend(filamentendsite)
        if !isminusendsegment(segment)
            return 0.0
        end
        #check range
        n= getrange(filamentendsite)
        monstates = fil_mon_states(c, ftid, segment.fid)
        cylinders = c.chem_cylinders[ftid]
        fil_idx = cylinders.fil_id_2_idx[segment.fid]
        endloadforce = cylinders.per_fil.endloadforces[fil_idx][1]
        if length(monstates)<n
            return 0.0
        end
        # ensure too many monomers aren't added between minimization.
        num_added = added_monomers(filamentendsite)
        if num_added > 0
            num_unmin = cylinders.per_fil.minusend_num_notminimized[fil_idx]
            max_unmin = c.filamentmechparams[ftid].max_num_unmin_end
            @assert max_unmin ≥ 0
            if (num_added + num_unmin) > max_unmin
                return 0.0
            end
        end
        states= monstates[begin:begin+n-1]
        ratefactor= exp(-c.β*spacing(filamentendsite)*endloadforce)
        return ratefactor * filamentendsitecount(filamentendsite,states)
    #plus end
    else
        if !isplusendsegment(segment)
            return 0.0
        end
        #check range
        n= getrange(filamentendsite)
        monstates = fil_mon_states(c, segment.ftid, segment.fid)
        cylinders = c.chem_cylinders[segment.ftid]
        fil_idx = cylinders.fil_id_2_idx[segment.fid]
        endloadforce = cylinders.per_fil.endloadforces[fil_idx][2]
        if length(monstates)<n
            return 0.0
        end
        # ensure too many monomers aren't added between minimization.
        num_added = added_monomers(filamentendsite)
        if num_added > 0
            num_unmin = cylinders.per_fil.plusend_num_notminimized[fil_idx]
            max_unmin = c.filamentmechparams[ftid].max_num_unmin_end
            @assert max_unmin ≥ 0
            if (num_added + num_unmin) > max_unmin
                return 0.0
            end
        end
        states= monstates[end-n+1:end]
        ratefactor= exp(-c.β*spacing(filamentendsite)*endloadforce)
        return ratefactor * filamentendsitecount(filamentendsite,states)
    end
end

"""
Reset link site counts effected by the change to one monomer state.
"""
function helper_reset_links_one_monomer!(c::Context, p::FilaMonoIdx)
    plus_end = FilaTipIdx(c, p, +)
    minus_end = FilaTipIdx(c, p, -)
    for offset in -1:+1
        mon = FilaMonoIdx(c, p, offset)
        for link_tag in get_links(c, mon)
            _update_link_reactions!(c, link_tag)
        end
        if mon == FilaMonoIdx(c, plus_end)
            for link_tag in get_links(c, plus_end)
                _update_link_reactions!(c, link_tag)
            end
        end
        if mon == FilaMonoIdx(c, minus_end)
            for link_tag in get_links(c, minus_end)
                _update_link_reactions!(c, link_tag)
            end
        end
    end
end

"""
    $(FUNCTIONNAME)(c::Context, ftid, fid, isminusend::Bool, newstate::MonomerState)
Add a monomer with state `newstate` to the end of the filament 
with type id `ftid` and id `fid`.

If `isminusend` is `true` add the monomer to the minus end of the filament, 
if `false` add it to the plus end of the filament.

This doesn't affect the other monomer states, positions, or change any of the monomer names.
New monomers are not linkable until after minimization.
"""
function chem_polymerize!(c::Context, ftid::Int, fid::Int, isminusend::Bool, newstate::MonomerState)
    c.stats.chem_polymerize_count += 1
    cylinders::ChemCylinders = c.chem_cylinders[ftid]
    fil_idx = cylinders.fil_id_2_idx[fid]
    newmid::Int = -1
    # get old tip position
    tip_place = FilaTipIdx(FilaIdx(ftid, fil_idx), isminusend)
    tip_tag = tag!(c, tip_place)
    old_tip_pos = get_position(c, tip_place)
    if isminusend
        polymerizeminusend!(cylinders, fil_idx, newstate)
    else
        polymerizeplusend!(cylinders, fil_idx, newstate)
    end
    new_tip_pos = get_position(c, tip_place)
    if checkall(c.validflags, VFS_SEGMENTS)
        oldsegment::Union{Segment,Nothing} = nothing
        #helper_resetsegments!(c)
        if isminusend 
            newmid = cylinders.per_fil.mon_id_first[fil_idx]
            oldmid = newmid + 1
            oldcid = get_compartment_id(c, _mon_position(cylinders, fil_idx, oldmid))
            newcid = get_compartment_id(c, _mon_position(cylinders, fil_idx, newmid))
            if oldcid == newcid
                # just modify segment
                comp = c.compartments[newcid]
                sid, seg = findsegment(comp,MonomerName(ftid,fid,oldmid))
                seg.midminusend = newmid
            else
                # create new segment
                newcomp = c.compartments[newcid]
                oldcomp = c.compartments[oldcid]
                sid, seg = findsegment(oldcomp,MonomerName(ftid,fid,oldmid))
                oldsegment = seg
                seg.minusend_cid = newcid
                newseg = Segment(;
                    cid = newcid,
                    ftid,
                    fid,
                    midminusend = newmid,
                    midplusend = newmid,
                    plusend_cid = oldcid,
                    minusend_cid = -1,
                    filamentsitecounts= zeros(length(c.filamentsites[ftid])),
                    filamentendsitecounts= zeros(length(c.filamentendsites[ftid])),
                )
                push!(newcomp.segments[ftid],newseg)
            end
        else
            newmid = cylinders.per_fil.mon_id_last[fil_idx]
            oldmid = newmid - 1
            oldcid = get_compartment_id(c, _mon_position(cylinders, fil_idx, oldmid))
            newcid = get_compartment_id(c, _mon_position(cylinders, fil_idx, newmid))
            if oldcid == newcid
                # just modify segment
                comp = c.compartments[newcid]
                sid, seg = findsegment(comp,MonomerName(ftid,fid,oldmid))
                seg.midplusend = newmid
            else
                # create new segment
                newcomp = c.compartments[newcid]
                oldcomp = c.compartments[oldcid]
                sid, seg = findsegment(oldcomp,MonomerName(ftid,fid,oldmid))
                oldsegment = seg
                seg.plusend_cid = newcid
                newseg = Segment(;
                    cid = newcid,
                    ftid,
                    fid,
                    midminusend = newmid,
                    midplusend = newmid,
                    plusend_cid = -1,
                    minusend_cid = oldcid,
                    filamentsitecounts= zeros(length(c.filamentsites[ftid])),
                    filamentendsitecounts= zeros(length(c.filamentendsites[ftid])),
                )
                push!(newcomp.segments[ftid],newseg)
            end
        end
        new_fila_mono_idx = FilaMonoIdx(c, FilaIdx(ftid, fil_idx), newmid)
        begin #helper_resetfilamentsitecounts!(c)
            # first subtract update end sites on oldsegment 
            # oldsegment is nothing if the new monomer stayed in the same compartment.
            isnothing(oldsegment) || helper_updatesegment_filamentendsitecounts!(c, oldsegment)
            effected_segments = helper_get_filsite_effected_segments(c,ftid,fid,newmid,newmid)
            @assert length(effected_segments) > 0
            for segment in effected_segments
                helper_updatesegmentsitecounts!(c,segment)
            end
        end
        #new monomers are not linkable, 
        #so decimated_2mon sites don't need to be updated.
        #helper_resetdecimated_2mon_sitecounts!(c)
        _update_tag_position!(c, tip_tag, old_tip_pos, new_tip_pos)
        begin # helper_reset_links_one_monomer!
            helper_reset_links_one_monomer!(c, new_fila_mono_idx)
        end
    end
    helper_check_sitecount_error(c)
    return
end

"""
    $(FUNCTIONNAME)(c::Context, fila_tip_idx::FilaTipIdx, newstate::Union{Symbol,MonomerState})
Add a monomer with state `newstate` to the end of the filament.

This doesn't affect the other monomer states, positions, or change any of the monomer names.
New monomers are not linkable until after minimization.
"""
function polymerize_fila!(c::Context, fila_tip_idx::FilaTipIdx, _state::Union{Symbol,MonomerState})
    state::MonomerState = if _state isa Symbol
        c.sys_def.state[fila_tip_idx.fila_idx.typeid][_state]
    else
        _state
    end
    fid = _get_fila_id(c, fila_tip_idx.fila_idx)
    ftid = fila_tip_idx.fila_idx.typeid
    chem_polymerize!(c,
        Int(ftid),
        Int(fid),
        fila_tip_idx.is_minus_end,
        state,
    )
    nothing
end
function polymerize_fila!(c::Context, t::Tag{FilaTipIdx}, state::Union{Symbol,MonomerState})
    polymerize_fila!(c, get_place(c, t), state)
end

"""
    $(FUNCTIONNAME)(c::Context, ftid, fid, isminusend::Bool)
Remove a monomer from the end of the filament 
with type id `ftid` and id `fid`.

If `isminusend` is `true` remove the monomer from the minus end of the filament, 
if `false` remove it from the plus end of the filament.

This doesn't affect the other monomer states, positions, or change any of the monomer names.

Error if the filament isn't initially over 2 monomers long.

Warn if the old end monomer is referenced in a link, and remove the place from the link.

The warning can be disabled by passing keyword argument `warniflink_2mon_removed=false`
"""
function chem_depolymerize!(c::Context, ftid::Int, fid::Int, isminusend::Bool; warniflink_2mon_removed=true)
    c.stats.chem_depolymerize_count += 1
    cylinders::ChemCylinders = c.chem_cylinders[ftid]
    fil_idx = cylinders.fil_id_2_idx[fid]
    fil_data = LazyRow(cylinders.per_fil, fil_idx)
    oldname = if isminusend
        MonomerName(ftid,fid,fil_data.mon_id_first)
    else
        MonomerName(ftid,fid,fil_data.mon_id_last)
    end
    oldmid = oldname.mid
    if fil_data.mon_id_last - fil_data.mon_id_first < 2
        error("depolymerizing a filament that is too short. The filament must be over 2 monomers long")
    end
    # update links to remove references to the place
    old_fila_mono_idx = _get_fila_mono_idx(c, oldname)
    helper_removeplace!(c, old_fila_mono_idx; warn_if_unlink=warniflink_2mon_removed)
    # If the segments aren't valid just update cylinders::ChemCylinders,
    # Otherwise update both cylinders and segments to keep them valid.
    if !checkall(c.validflags, VFS_SEGMENTS)
        if isminusend
            depolymerizeminusend!(cylinders, fil_idx)
        else
            depolymerizeplusend!(cylinders, fil_idx)
        end
    else
        # get old tip position
        tip_place = FilaTipIdx(FilaIdx(ftid, fil_idx), isminusend)
        tip_tag = tag!(c, tip_place)
        old_tip_pos = get_position(c, tip_place)
        cid = get_compartment_id(c, _mon_position(cylinders, fil_idx, oldmid))
        comp = c.compartments[cid]
        if isminusend
            depolymerizeminusend!(cylinders, fil_idx)
            sid, seg = findsegment(comp,oldname)
            if seg.midplusend == oldmid
                newendcomp = c.compartments[seg.plusend_cid]
                newsid, newseg = findsegment(newendcomp,MonomerName(ftid,fid,oldmid+1))
                newseg.minusend_cid = -1
                helper_deletesegment!(c,cid,ftid,sid)
            else
                seg.midminusend += 1
            end   
        else
            depolymerizeplusend!(cylinders, fil_idx)
            sid, seg = findsegment(comp,oldname)
            if seg.midminusend == oldmid
                newendcomp = c.compartments[seg.minusend_cid]
                newsid, newseg = findsegment(newendcomp,MonomerName(ftid,fid,oldmid-1))
                newseg.plusend_cid = -1
                helper_deletesegment!(c,cid,ftid,sid)
            else
                seg.midplusend -= 1
            end  
        end
        new_tip_pos = get_position(c, tip_place)
        #helper_resetsegments!(c)
        #helper_reset_decimated_2mon_site_monomers!(c)
        begin #helper_resetfilamentsitecounts!(c)
            #search nearby mid as well, to catch new end sites
            effected_segments = helper_get_filsite_effected_segments(c,ftid,fid,oldmid-1,oldmid+1)
            @assert length(effected_segments) > 0
            for segment in effected_segments
                helper_updatesegmentsitecounts!(c,segment)
            end
        end
        _update_tag_position!(c, tip_tag, old_tip_pos, new_tip_pos)
        begin #helper_reset_links_one_monomer!(c)
            helper_reset_links_one_monomer!(c, old_fila_mono_idx)
        end
    end
    try
        helper_check_sitecount_error(c)
    catch
        @show ftid
        @show fid
        @show isminusend
        @show oldname
        rethrow()
    end
    return
end

"""
    $(FUNCTIONNAME)(c::Context, fila_tip_idx::FilaTipIdx)
Remove a monomer from the end of the filament.

This doesn't affect the other monomer states, positions, or change any of the monomer names.

Error if the filament isn't initially over 2 monomers long.

Warn if the old end monomer is referenced in a link, and remove the place from the link. 
Links attached to the filament tip will remain attached.

The warning can be disabled by passing keyword argument `warn_if_unlink=false`
"""
function depolymerize_fila!(c::Context, fila_tip_idx::FilaTipIdx; warn_if_unlink=true)
    fid = _get_fila_id(c, fila_tip_idx.fila_idx)
    ftid = fila_tip_idx.fila_idx.typeid
    chem_depolymerize!(c,
        Int(ftid),
        Int(fid),
        fila_tip_idx.is_minus_end;
        warniflink_2mon_removed=warn_if_unlink,
    )
    nothing
end


"""
    sever_fila!(c::Context, place::FilaMonoIdx)::Tag{FilaTipIdx}

Return the tag of the new filament plus end.

Calling this will invalidate the chem cache.

The split will happen between `place` 
and the monomer slightly towards the minus end.

The split cannot create a filament with less than 2 monomers.
"""
function sever_fila!(c::Context, place::FilaMonoIdx)::Tag{FilaTipIdx}
    defer_chem_caching!(c)
    ftid = Int64(place.fila_idx.typeid)
    fil_idx = Int64(place.fila_idx.idx)
    mid = place.mid
    cylinders = c.chem_cylinders[ftid]
    new_fid = c.largestfilamentid[ftid]+1
    new_fil_idx = _sever_fila!(cylinders, fil_idx, mid, new_fid)
    c.largestfilamentid[ftid]= new_fid
    # move tag for filament minus tip
    _move_place!(
        _tag_manager(c.link_manager, FilaTipIdx()),
        FilaTipIdx(FilaIdx(ftid, fil_idx), true),
        FilaTipIdx(FilaIdx(ftid, new_fil_idx), true),
    )
    # Add tags for new tips
    new_ftag = tag!(c, FilaTipIdx(FilaIdx(ftid, new_fil_idx), false))
    tag!(c, FilaTipIdx(FilaIdx(ftid, fil_idx), true))
    # move tags for filament monomers
    mon_states = fil_mon_states(c, ftid, new_fid)
    for mid in eachindex(mon_states)
        local t = _tag_manager(c.link_manager, FilaMonoIdx())
        local new_place = FilaMonoIdx(c, FilaIdx(ftid, new_fil_idx), mid)
        local old_place = FilaMonoIdx(c, FilaIdx(ftid, fil_idx), mid)
        _move_place!(
            t,
            old_place,
            new_place,
        )
    end
    foreach(c.cadherindata) do cdata
        for mon_id in eachindex(mon_states)
            local old_name = MonomerName(ftid, plus_fid, mon_id)
            local new_name = MonomerName(ftid, new_fid, mon_id)
            if old_name ∈ cdata.monname_to_cadidx
                change_monomer_name!(cdata, old_name, new_name)
            end
        end
    end
    new_ftag
end

"""
Update compartment segment data from filamentdata.
Doesn't update other compartmentdata or any reaction counts
"""
function helper_resetsegments!(c::Context)
    #clear current segments
    num_filament_types= num_fila_types(c)
    for comp in c.compartments
        for ftid in 1:num_filament_types
            empty!(comp.segments[ftid])
        end
    end
    #create segments
    for ftid in 1:num_filament_types
        cylinders = c.chem_cylinders[ftid]
        for fil_idx in eachindex(cylinders.per_fil)
            fid = cylinders.per_fil.id[fil_idx]
            monstates = _fil_mon_states(cylinders, fil_idx)
            mid= firstindex(monstates)
            cid= get_compartment_id(c, _mon_position(cylinders, fil_idx, mid))
            seg= Segment(cid= cid,
                        ftid= ftid,
                        fid= fid,
                        midminusend= mid,
                        midplusend= mid,
                        plusend_cid= -1,#plus cid does not exist yet
                        minusend_cid= -1,#minus end does not exist
                        filamentsitecounts= zeros(length(c.filamentsites[ftid])),
                        filamentendsitecounts= zeros(length(c.filamentendsites[ftid])),
                    )
            push!(c.compartments[cid].segments[ftid], seg)
            last_seg= seg
            last_cid= cid
            for mid in (firstindex(monstates)+1):lastindex(monstates)
                cid= get_compartment_id(c, _mon_position(cylinders, fil_idx, mid))
                if cid==last_cid
                    last_seg.midplusend= mid
                else
                    #left last_cid, create new segment
                    last_seg.plusend_cid= cid
                    seg= Segment(cid= cid,
                        ftid= ftid,
                        fid= fid,
                        midminusend= mid,
                        midplusend= mid,
                        plusend_cid= -1,#plus cid does not exist yet
                        minusend_cid= last_cid,
                        filamentsitecounts= zeros(length(c.filamentsites[ftid])),
                        filamentendsitecounts= zeros(length(c.filamentendsites[ftid])),
                    )
                    push!(c.compartments[cid].segments[ftid], seg)
                    last_seg= seg
                    last_cid= cid
                end
            end
        end
    end
end

"""
Update filament site and filament end site counts on a single segment.
Delta gets sent to chemistryengine
Make sure `segment.filamentsitecounts` is what it was before the state change,
Only updates filamentendsitecounts if the segment is at an end.
"""
function helper_updatesegmentsitecounts!(c::Context, segment::Segment)
    requireall(c.validflags, VFS_SEGMENTS)
    ftid = segment.ftid
    fid = segment.fid
    cid = segment.cid
    # check if segment is a filament end
    if isminusendsegment(segment) || isplusendsegment(segment)
        #go through all filamentendsites and add counts to chemistryengine
        for siteinfo in c.filamentendsites[ftid]
            newsitecount = Q31f32(helper_filamentendsitecounts(c,segment,siteinfo.site))
            oldsitecount = segment.filamentendsitecounts[siteinfo.id]
            if newsitecount != oldsitecount
                addfixedspeciescount!(c.chemistryengine,siteinfo.fxsid,cid,newsitecount-oldsitecount)
                segment.filamentendsitecounts[siteinfo.id] = newsitecount
            end
        end
    end
    filamentsitecounts= zeros(Q31f32,length(c.filamentsites[ftid]))
    monstates = fil_mon_states(c, ftid, fid)
    for mid in segment.midminusend:segment.midplusend
        for sitetuple in c.filamentsites[ftid]
            fsid= sitetuple.id
            filamentsite= sitetuple.site
            plusrange= getplusrange(filamentsite)
            minusrange= getminusrange(filamentsite)
            mmid= mid - minusrange
            pmid= mid + plusrange
            #make sure states are in bound
            if mmid ≥ firstindex(monstates) && pmid ≤ lastindex(monstates)
                states= monstates[mmid:pmid]
                s= Q31f32(filamentsitecount(filamentsite,states))
                filamentsitecounts[fsid] += s
            end
        end
    end
    for fsid in eachindex(filamentsitecounts)
        newsitecount = filamentsitecounts[fsid]
        oldsitecount = segment.filamentsitecounts[fsid]
        if newsitecount != oldsitecount
            fxsid= c.filamentsites[ftid][fsid].fxsid
            addfixedspeciescount!(c.chemistryengine,fxsid,cid,newsitecount-oldsitecount)
            segment.filamentsitecounts[fsid] = newsitecount
        end
    end
end

"""
delete a segment and subtract all site counts
"""
function helper_deletesegment!(c::Context, cid, ftid, sid)
    requireall(c.validflags, VFS_SEGMENTS)
    comp = c.compartments[cid]
    segs = comp.segments[ftid]
    seg = segs[sid]
    #go through all filamentendsites and add counts to chemistryengine
    for siteinfo in c.filamentendsites[ftid]
        counts = seg.filamentendsitecounts[siteinfo.id]
        if !iszero(counts)
            addfixedspeciescount!(c.chemistryengine,siteinfo.fxsid,cid,-counts)
        end
    end
    for siteinfo in c.filamentsites[ftid]
        counts = seg.filamentsitecounts[siteinfo.id]
        if !iszero(counts)
            addfixedspeciescount!(c.chemistryengine,siteinfo.fxsid,cid,-counts)
        end
    end
    #now delete
    segs[sid] = segs[end]
    pop!(segs)
    return
end


"""
Update filament end site counts on a single segment even if it no longer is an end.
Delta gets sent to chemistryengine
Make sure `segment.filamentendsitecounts` is what it was before the state change,
"""
function helper_updatesegment_filamentendsitecounts!(c::Context, segment::Segment)
    requireall(c.validflags, VFS_SEGMENTS)
    ftid = segment.ftid
    fid = segment.fid
    cid = segment.cid
    #go through all filamentendsites and add counts to chemistryengine
    for siteinfo in c.filamentendsites[ftid]
        newsitecount = Q31f32(helper_filamentendsitecounts(c,segment,siteinfo.site))
        oldsitecount = segment.filamentendsitecounts[siteinfo.id]
        if newsitecount != oldsitecount
            addfixedspeciescount!(c.chemistryengine,siteinfo.fxsid,cid,newsitecount-oldsitecount)
            segment.filamentendsitecounts[siteinfo.id] = newsitecount
        end
    end
end

"""
Return the segments that can have filament sites or filament end sites effected by a change to monomer states from midstart to midstop
"""
function helper_get_filsite_effected_segments(c::Context,ftid,fid,midstart,midstop)::Vector{Segment}
    requireall(c.validflags, VFS_SEGMENTS)
    monstates = fil_mon_states(c, ftid, fid)
    midminusend = firstindex(monstates)
    midplusend = lastindex(monstates)
    midminusmaxrange = c.maxfilsite_minusrange[ftid]
    midplusmaxrange = c.maxfilsite_plusrange[ftid]
    midstarteffect = max(midstart-midplusmaxrange,midminusend)
    midstopeffect = min(midstop+midminusmaxrange,midplusend)
    
    mid = midstarteffect
    cid = get_compartment_id(c, MonomerName(ftid,fid,mid))
    segments = Vector{Segment}()
    while true
        comp = c.compartments[cid]
        sid, seg = findsegment(comp,MonomerName(ftid,fid,mid))
        push!(segments,seg)
        if midstopeffect > seg.midplusend
            cid= seg.plusend_cid
            mid= seg.midplusend+1
        else
            return segments
        end
    end
end

"""
Reset the filament and filamentend site counts and fixedspecies number after segments are reset
"""
function helper_resetfilamentsitecounts!(c::Context)
    #go through segments and get the filament site counts
    for comp in c.compartments
        for ftid in 1:num_fila_types(c)
            filamentsitecounts= zeros(Q31f32,length(c.filamentsites[ftid]))
            filamentendsitecounts= zeros(Q31f32,length(c.filamentendsites[ftid]))
            for segment in comp.segments[ftid]
                monstates = fil_mon_states(c, ftid, segment.fid)
                segment.filamentsitecounts .= 0
                segment.filamentendsitecounts .= 0
                for mid in segment.midminusend:segment.midplusend
                    for sitetuple in c.filamentsites[ftid]
                        fsid= sitetuple.id
                        filamentsite= sitetuple.site
                        plusrange= getplusrange(filamentsite)
                        minusrange= getminusrange(filamentsite)
                        mmid= mid - minusrange
                        pmid= mid + plusrange
                        #make sure states are in bound
                        if mmid ≥ firstindex(monstates) && pmid ≤ lastindex(monstates)
                            states= monstates[mmid:pmid]
                            s= Q31f32(filamentsitecount(filamentsite,states))
                            segment.filamentsitecounts[fsid] += s
                            filamentsitecounts[fsid] += s
                        end
                    end
                end
                for fesid in eachindex(filamentendsitecounts)
                    s = Q31f32(helper_filamentendsitecounts(c,segment,c.filamentendsites[ftid][fesid].site))
                    segment.filamentendsitecounts[fesid] += s
                    filamentendsitecounts[fesid] += s
                end
            end
            for fsid in eachindex(filamentsitecounts)
                fxsid= c.filamentsites[ftid][fsid].fxsid
                setfixedspeciescount!(c.chemistryengine,fxsid,comp.id,filamentsitecounts[fsid])
            end
            for fesid in eachindex(filamentendsitecounts)
                fxsid= c.filamentendsites[ftid][fesid].fxsid
                setfixedspeciescount!(c.chemistryengine,fxsid,comp.id,filamentendsitecounts[fesid])
            end
        end
    end
end

function ChemCylinders(ftid::Integer, numpercylinder::Integer)
    ChemCylinders(;
        ftid,
        numpercylinder,
    )
end


function assert_invariants(cylinders::ChemCylinders)
    for hole in cylinders.holes
        @argcheck !cylinders.per_cyl.exists[hole]
    end
    num_cyl_exist = length(cylinders.per_cyl) - length(cylinders.holes)
    @argcheck sum(cylinders.per_cyl.exists) == num_cyl_exist
    num_cyl_in_filaments = 0
    @argcheck length(cylinders.per_fil) == length(keys(cylinders.fil_id_2_idx))
    for fil_idx in 1:length(cylinders.per_fil)
        fil = LazyRow(cylinders.per_fil, fil_idx)
        fil_id = fil.id
        @argcheck fil_idx == cylinders.fil_id_2_idx[fil_id]
        for cyl_idx in fil.cyl_idxs
            @argcheck cylinders.per_cyl.exists[cyl_idx]
            @argcheck fil_id == cylinders.per_cyl.fil_id[cyl_idx]
        end
        num_cyl_on_fil = length(fil.cyl_idxs)
        @argcheck num_cyl_on_fil > 0
        @argcheck num_cyl_on_fil == length(fil.chembeadpositions) - 1
        @argcheck fil.mon_id_last - fil.mon_id_first == length(fil.monomerstates) - 1
        num_cyl_in_filaments += num_cyl_on_fil
    end
    @argcheck num_cyl_in_filaments == num_cyl_exist
end


"""
Return mon_id_first, mon_id_last, numpercylinder
"""
function _mon_id_info(cylinders::ChemCylinders, fil_idx::Int)::NTuple{3, Int}
    mon_id_first::Int = cylinders.per_fil.mon_id_first[fil_idx]
    mon_id_last::Int = cylinders.per_fil.mon_id_last[fil_idx]
    numpercylinder::Int = cylinders.numpercylinder
    (
        mon_id_first,
        mon_id_last,
        numpercylinder,
    )
end


"""
    $(TYPEDSIGNATURES)
Return a read only OffsetVector of monomer states on a filament.

This can be invalid after any mutations to context, so copy if needed.
"""
function _fil_mon_states(cylinders::ChemCylinders, fil_idx::Int)::OffsetVector{MonomerState, Vector{MonomerState}}
    mon_id_first = cylinders.per_fil.mon_id_first[fil_idx]
    OffsetArrays.Origin(mon_id_first)(cylinders.per_fil.monomerstates[fil_idx])
end


function _mon_position(cylinders::ChemCylinders, fil_idx::Int, mon_id::Int)
    fil_cyl_idx, frac = @inline(get_fil_chem_cyl_idx_frac(
        mon_id,
        _mon_id_info(cylinders, fil_idx)...
    ))
    chembeadpositions = cylinders.per_fil.chembeadpositions[fil_idx]
    r1 = chembeadpositions[fil_cyl_idx]
    r2 = chembeadpositions[fil_cyl_idx + 1]
    frac*r2 + (1.0-frac)*r1
end


function _mon_plusvector(cylinders::ChemCylinders, fil_idx::Int, mon_id::Int)
    fil_cyl_idx, frac = get_fil_chem_cyl_idx_frac(
        mon_id,
        _mon_id_info(cylinders, fil_idx)...
    )
    chembeadpositions = cylinders.per_fil.chembeadpositions[fil_idx]
    r1 = chembeadpositions[fil_cyl_idx]
    r2 = chembeadpositions[fil_cyl_idx + 1]
    normalize_fast(r2 - r1)
end


function _mon_position_plusvector(cylinders::ChemCylinders, fil_idx::Int, mon_id::Int)
    fil_cyl_idx, frac = get_fil_chem_cyl_idx_frac(
        mon_id,
        _mon_id_info(cylinders, fil_idx)...
    )
    chembeadpositions = cylinders.per_fil.chembeadpositions[fil_idx]
    r1 = chembeadpositions[fil_cyl_idx]
    r2 = chembeadpositions[fil_cyl_idx + 1]
    pos = frac*r2 + (1.0-frac)*r1
    plusv = normalize_fast(r2 - r1)
    pos, plusv
end


function _get_nodepositions(cylinders::ChemCylinders, fil_idx::Int)::Vector{SVector{3,Float64}}
    _get_nodepositions(
        cylinders.per_fil.chembeadpositions[fil_idx],
        _mon_id_info(cylinders, fil_idx)...
    )
end


"""
Return the number of monomers on the minus end cylinder
"""
function _get_nummonomersminusend(cylinders::ChemCylinders, fil_idx::Int)::Int
    if length(cylinders.per_fil.chembeadpositions[fil_idx])==2
        #just one cylinder
        return length(cylinders.per_fil.monomerstates[fil_idx])
    else
        return cylinders.numpercylinder - mod(cylinders.per_fil.mon_id_first[fil_idx], cylinders.numpercylinder)
    end
end


"""
Return the number of monomers on the plus end cylinder
"""
function _get_nummonomersplusend(cylinders::ChemCylinders, fil_idx::Int)::Int
    if length(cylinders.per_fil.chembeadpositions[fil_idx])==2
        #just one cylinder
        return length(cylinders.per_fil.monomerstates[fil_idx])
    else
        return mod(cylinders.per_fil.mon_id_last[fil_idx], cylinders.numpercylinder) + 1
    end
end


function _fil_node_mon_ids(cylinders::ChemCylinders, fil_idx::Int)::Vector{Int}
    _fil_node_mon_ids(
        _mon_id_info(cylinders, fil_idx)...
    )
end


function Base.empty!(cylinders::ChemCylinders)
    empty!(cylinders.per_cyl)
    empty!(cylinders.holes)
    empty!(cylinders.fil_id_2_idx)
    empty!(cylinders.per_fil)
end


function Base.isempty(cylinders::ChemCylinders)
    isempty(cylinders.per_cyl)
end


function polymerizeminusend!(cylinders::ChemCylinders, fil_idx::Int, newstate::MonomerState)
    fil = LazyRow(cylinders.per_fil, fil_idx)
    fil.minusend_num_notminimized += 1
    mon_id_first = fil.mon_id_first
    numpercylinder = cylinders.numpercylinder
    if mod(mon_id_first, numpercylinder) == 0
        #new cylinder in the same direction and length as the last one
        pushfirst!(fil.chembeadpositions,2*fil.chembeadpositions[begin]-fil.chembeadpositions[begin+1])
        cyl_idx = length(cylinders.per_cyl) + 1
        push!(cylinders.per_cyl, DataPerCylinder(;fil_id = fil.id))
        pushfirst!(fil.cyl_idxs, cyl_idx)
    end
    pushfirst!(fil.monomerstates, newstate)
    fil.mon_id_first -= 1
end

function polymerizeplusend!(cylinders::ChemCylinders, fil_idx::Int, newstate::MonomerState)
    fil = LazyRow(cylinders.per_fil, fil_idx)
    fil.plusend_num_notminimized += 1
    mon_id_last = fil.mon_id_last
    numpercylinder = cylinders.numpercylinder
    if mod(mon_id_last + 1, numpercylinder) == 0
        #new cylinder in the same direction and length as the last one
        push!(fil.chembeadpositions,2*fil.chembeadpositions[end]-fil.chembeadpositions[end-1])
        cyl_idx = length(cylinders.per_cyl) + 1
        push!(cylinders.per_cyl, DataPerCylinder(;fil_id = fil.id))
        push!(fil.cyl_idxs, cyl_idx)
    end
    push!(fil.monomerstates, newstate)
    fil.mon_id_last += 1
end

function depolymerizeminusend!(cylinders::ChemCylinders, fil_idx::Int)
    fil = LazyRow(cylinders.per_fil, fil_idx)
    if !iszero(fil.minusend_num_notminimized)
        fil.minusend_num_notminimized -= 1
    end
    mon_id_first = fil.mon_id_first
    numpercylinder = cylinders.numpercylinder
    if mod(mon_id_first+1,numpercylinder)==0
        #remove cylinder
        popfirst!(fil.chembeadpositions)
        cyl_idx = popfirst!(fil.cyl_idxs)
        @assert cylinders.per_cyl.exists[cyl_idx]
        push!(cylinders.holes, cyl_idx)
        cylinders.per_cyl.exists[cyl_idx] = false
    end
    popfirst!(fil.monomerstates)
    fil.mon_id_first += 1
end

function depolymerizeplusend!(cylinders::ChemCylinders, fil_idx::Int)
    fil = LazyRow(cylinders.per_fil, fil_idx)
    if !iszero(fil.plusend_num_notminimized)
        fil.plusend_num_notminimized -= 1
    end
    mon_id_last = fil.mon_id_last
    numpercylinder = cylinders.numpercylinder
    if mod(mon_id_last,numpercylinder)==0
        #remove cylinder
        pop!(fil.chembeadpositions)
        cyl_idx = pop!(fil.cyl_idxs)
        @assert cylinders.per_cyl.exists[cyl_idx]
        push!(cylinders.holes, cyl_idx)
        cylinders.per_cyl.exists[cyl_idx] = false
    end
    pop!(fil.monomerstates)
    fil.mon_id_last -= 1
end


"""
Rearrange cylinders to remove holes. After this all cylinders should exist.
"""
function fill_holes!(cylinders::ChemCylinders)
    assert_invariants(cylinders)
    currentsize = length(cylinders.per_cyl)
    finalsize = currentsize - length(cylinders.holes)
    hole_idx = 1
    for cyl_idx in (finalsize+1):currentsize
        if cylinders.per_cyl.exists[cyl_idx]
            while cylinders.holes[hole_idx] > finalsize
                hole_idx += 1
            end
            hole = cylinders.holes[hole_idx]
            hole_idx += 1
            # hole is an empty idx inside the final array 
            # to be filled by `cyl_idx`, a not empty element outside the final array.
            @assert !cylinders.per_cyl.exists[hole]
            @assert cylinders.per_cyl.exists[cyl_idx]
            cyl = cylinders.per_cyl[cyl_idx]
            cylinders.per_cyl[hole] = cyl
            fil_id = cyl.fil_id
            fil_idx = cylinders.fil_id_2_idx[fil_id]
            replace!(cylinders.per_fil.cyl_idxs[fil_idx], cyl_idx=>hole)
        end
    end
    resize!(cylinders.per_cyl, finalsize)
    empty!(cylinders.holes)
    @assert all(cylinders.per_cyl.exists)
    assert_invariants(cylinders)
end


"""
Split a filament, return the new `fil_idx`, .
`mon_id` is just to the plus end of the split.
`new_fil_id` is the filament id to assign to the new filament.
Existing filament `fil_idx` are not modified, the new filament is appended.
Monomers on the minus end of the split are added added to the new filament.
Both filaments are marked as not minimized.
"""
function _sever_fila!(cylinders::ChemCylinders, fil_idx, mon_id::Int, new_fil_id)
    numpercylinder = cylinders.numpercylinder
    fil = LazyRow(cylinders.per_fil, fil_idx)
    mon_id_first = fil.mon_id_first
    mon_id_last = fil.mon_id_last
    @argcheck mon_id > mon_id_first+1
    @argcheck mon_id < mon_id_last
    new_fil_idx = length(cylinders.per_fil) + 1
    @argcheck !haskey(cylinders.fil_id_2_idx, new_fil_id)
    cylinders.fil_id_2_idx[new_fil_id] = new_fil_idx
    fil_cyl_idx, mon_frac = get_fil_chem_cyl_idx_frac(
        mon_id,
        mon_id_first,
        mon_id_last,
        numpercylinder,
    )
    plus_cyl_idxs = fil.cyl_idxs[fil_cyl_idx:end]
    plus_chembeadpositions = fil.chembeadpositions[fil_cyl_idx:end]
    plus_monomerstates = fil.monomerstates[mon_id-mon_id_first+begin:end]
    minus_monomerstates = fil.monomerstates[begin:mon_id-mon_id_first+begin-1]
    if mod(mon_id, numpercylinder) == 0
        # no new cylinders are needed
        minus_cyl_idxs = fil.cyl_idxs[begin:fil_cyl_idx-1]
        minus_chembeadpositions = fil.chembeadpositions[begin:fil_cyl_idx]
    else
        # one new cylinder is needed
        new_cyl_idx = length(cylinders.per_cyl) + 1
        minus_cyl_idxs = [fil.cyl_idxs[begin:fil_cyl_idx-1]; new_cyl_idx;]
        minus_chembeadpositions = fil.chembeadpositions[begin:fil_cyl_idx+1]
        push!(cylinders.per_cyl, DataPerCylinder(;fil_id = new_fil_id))
    end
    for cyl_idx in minus_cyl_idxs
        cylinders.per_cyl.fil_id[cyl_idx] = new_fil_id
    end
    # add minus end filament
    push!(cylinders.per_fil, DataPerFilament(;
        id= new_fil_id,
        mon_id_first= mon_id_first,
        mon_id_last= mon_id-1,
        monomerstates= minus_monomerstates,
        chembeadpositions= minus_chembeadpositions,
        cyl_idxs= minus_cyl_idxs, 
        minusend_num_notminimized= length(minus_monomerstates),
        plusend_num_notminimized= length(minus_monomerstates),
    ))
    # update plus end filament
    fil.mon_id_first = mon_id
    fil.monomerstates = plus_monomerstates
    fil.chembeadpositions = plus_chembeadpositions
    fil.cyl_idxs = plus_cyl_idxs
    fil.minusend_num_notminimized = length(plus_monomerstates)
    fil.plusend_num_notminimized = length(plus_monomerstates)
    fil.endloadforces = cylinders.per_fil[new_fil_idx].endloadforces
    new_fil_idx
end

"""
Returns the chem bead positions

The monomers are coarse grained such that every `numpercylinder` monomer is a cylinder,
beads are between two monomers and monomers are linearly interpolated between beads.

chem beads are linearly interpolated between `nodepositions` 
    so that the monomers to the right of the beads have ids divisible by `cylinders.numpercylinder`,
    the first and last beads, can be extended from `nodepositions[begin]`, `nodepositions[end]`, so they won't change when a monomer is (de)polymerized.

The `full_node_mids` are the monomer ids at (slightly plus side of) the `nodepositions`
`full_node_mids[end]` is the last monomer id + 1

                                     |
                          -----+-----|-----+-----
      minus end <----       M  |  M  | (M) |  M        ----> plus end
                          -----+-----|-----+-----
                                     |
                                     ^ A nodeposition is indicated by the line.
    
The monomer id with parenthesis (M) will in `full_node_mids`
"""
function interpolate_chem_beads(full_node_mids::Vector{Int}, nodepositions::Vector{SVector{3,Float64}}, numpercylinder::Int)::Vector{SVector{3,Float64}}
    @argcheck length(full_node_mids) == length(nodepositions)
    @argcheck numpercylinder > 0
    cyl_lengths = full_node_mids[begin+1:end] - full_node_mids[begin:end-1]
    @argcheck all(>(0), cyl_lengths)
    firstmonomerid = full_node_mids[begin]
    firstcylinderid = fld(firstmonomerid,numpercylinder)
    lastmonomerid = full_node_mids[end] - 1
    lastcylinderid= fld(lastmonomerid,numpercylinder)
    numbeads = lastcylinderid - firstcylinderid + 2
    chembeadpositions = fill(SA[NaN,NaN,NaN],numbeads)
    #first bead
    a = - mod(full_node_mids[begin],numpercylinder)
    b = full_node_mids[begin+1] - full_node_mids[begin]
    chembeadpositions[begin] = (1-a/b)*nodepositions[begin] + (a/b)*nodepositions[begin+1]
    #middle beads
    bead_idx = 2
    node_idx = 2
    targetmid = (firstcylinderid+1)*numpercylinder
    while bead_idx < numbeads
        while full_node_mids[node_idx] < targetmid
            node_idx += 1
        end
        a = full_node_mids[node_idx] - targetmid
        b = full_node_mids[node_idx] - full_node_mids[node_idx-1]
        chembeadpositions[bead_idx] = (1-a/b)*nodepositions[node_idx] + (a/b)*nodepositions[node_idx-1]
        bead_idx += 1
        targetmid += numpercylinder
    end
    #last bead
    a = -mod(-full_node_mids[end],numpercylinder)
    b = full_node_mids[end] - full_node_mids[end-1]
    chembeadpositions[end] = (1-a/b)*nodepositions[end] + (a/b)*nodepositions[end-1]
    chembeadpositions
end


"""
Return the node positions with the ends at the actual ends of the filament.

The length of the returned vector will be the same as the length of `chembeadpositions`

All positions will be the same except the first and last which may be moved in if the chem cylinder isn't full.
"""
function _get_nodepositions(chembeadpositions::Vector{SVector{3,Float64}}, mon_id_first::Int, mon_id_last::Int, numpercylinder::Int)::Vector{SVector{3,Float64}}
    nodepositions = copy(chembeadpositions)
    @argcheck mon_id_last > mon_id_first
    # get the expected number of beads based on the monomer ids and numpercylinder
    firstcylinderid = fld(mon_id_first, numpercylinder)
    lastcylinderid = fld(mon_id_last, numpercylinder)
    numbeads = lastcylinderid - firstcylinderid + 2
    @argcheck numbeads == length(chembeadpositions)
    #undo extended ends
    a = mod(mon_id_first,numpercylinder)
    b = numpercylinder
    nodepositions[begin] = (1-a/b)*chembeadpositions[begin] + (a/b)*chembeadpositions[begin+1]
    midlast = mon_id_last + 1
    a = mod(-midlast,numpercylinder)
    nodepositions[end] = (1-a/b)*chembeadpositions[end] + (a/b)*chembeadpositions[end-1]
    nodepositions
end


"""
Set `chembeadpositions` based on `nodepos`

The indexes of `chembeadpositions` and `nodepos` must match

All positions will be the same except the first and last which may be moved out if the chem cylinder isn't full.
"""
function set_nodepositions!(
        chembeadpositions::AbstractVector{SVector{3,Float64}},
        nodepos::AbstractVector{SVector{3,Float64}},
        mon_id_first::Int,
        mon_id_last::Int,
        numpercylinder::Int,
    )::Nothing
    @argcheck eachindex(chembeadpositions) == eachindex(nodepos)
    @argcheck mon_id_last > mon_id_first
    # get the expected number of beads based on the monomer ids and numpercylinder
    firstcylinderid = fld(mon_id_first, numpercylinder)
    lastcylinderid = fld(mon_id_last, numpercylinder)
    numbeads = lastcylinderid - firstcylinderid + 2
    @argcheck numbeads == length(chembeadpositions)
    chembeadpositions .= nodepos
    # Extend first bead to a full cylinder.
    midfirstbead = mon_id_first
    midnextbead = min(fld(midfirstbead,numpercylinder)*numpercylinder + numpercylinder, mon_id_last+1)
    a = - mod(midfirstbead, numpercylinder)
    b = midnextbead - midfirstbead
    chembeadpositions[begin] = (1-a/b)*nodepos[begin] + (a/b)*nodepos[begin+1]
    # Extend last bead to a full cylinder.
    midlastbead = mon_id_last + 1
    midprevbead = max(fld(midlastbead-1,numpercylinder)*numpercylinder, mon_id_first)
    a = - mod(-midlastbead,numpercylinder)
    b = midlastbead - midprevbead
    chembeadpositions[end] = (1-a/b)*nodepos[end] + (a/b)*nodepos[end-1]
    nothing
end


"""
Return the node monomer ids of the filament
"""
function _fil_node_mon_ids(mon_id_first::Int, mon_id_last::Int, numpercylinder::Int)::Vector{Int}
    invnumpercylinder = inv(numpercylinder)
    firstcylinderidfrac = (mon_id_first + 0.5)*invnumpercylinder
    firstcylinderid = Int(round(firstcylinderidfrac,RoundDown))
    nextbeadmid = (firstcylinderid + 1)*numpercylinder
    node_mids = [mon_id_first; nextbeadmid:numpercylinder:mon_id_last; mon_id_last+1]
    node_mids
end

"""
Return the full range of possible mon_ids on a cylinder,
"""
function _fil_cyl_mon_ids(fil_cyl_idx::Int, mon_id_first::Int, mon_id_last::Int, numpercylinder::Int)
    invnumpercylinder = inv(numpercylinder)
    firstcylinderidfrac = (mon_id_first + 0.5)*invnumpercylinder
    firstcylinderid = Int(round(firstcylinderidfrac,RoundDown))
    cyl_id = fil_cyl_idx + firstcylinderid - 1
    start_mid = cyl_id*numpercylinder
    stop_mid = (cyl_id + 1)*numpercylinder - 1
    start_mid:stop_mid
end




"""
Return chem cylinder index on a filament and chem cylinder frac of a monomer id
frac is a float, 0.0 if the monomer is at the chem bead on the minus end of the cylinder,
1.0 if it is at the chem bead on the plus end of the cylinder.
"""
function get_fil_chem_cyl_idx_frac(
        mon_id::Int,
        mon_id_first::Int,
        mon_id_last::Int,
        numpercylinder::Int,
    )
    @argcheck mon_id in mon_id_first:mon_id_last
    invnumpercylinder = inv(numpercylinder)
    cylinderidfrac = (mon_id + 0.5)*invnumpercylinder
    firstcylinderidfrac = (mon_id_first + 0.5)*invnumpercylinder
    firstcylinderid = unsafe_trunc(Int,round(firstcylinderidfrac,RoundDown))
    cylinderid = unsafe_trunc(Int,round(cylinderidfrac,RoundDown))
    cylinderidx= cylinderid - firstcylinderid + 1
    mon_id_on_cyl = mon_id - cylinderid*numpercylinder
    frac = (mon_id_on_cyl + 0.5)*invnumpercylinder
    return cylinderidx, frac
end


"""
Return mech cylinder index on a filament and mech cylinder frac of a monomer id
frac is a float, 0.0 if the monomer is at the mechanics node on the minus end of the cylinder,
1.0 if it is at the mechanics node on the plus end of the cylinder.
"""
function get_fil_mech_cyl_idx_frac(
        mon_id::Int,
        mon_id_first::Int,
        mon_id_last::Int,
        numpercylinder::Int,
    )
    @argcheck mon_id in mon_id_first:mon_id_last
    invnumpercylinder = inv(numpercylinder)
    cylinderidfrac = (mon_id + 0.5)*invnumpercylinder
    firstcylinderidfrac = (mon_id_first + 0.5)*invnumpercylinder
    firstcylinderid = unsafe_trunc(Int,round(firstcylinderidfrac,RoundDown))
    cylinderid = unsafe_trunc(Int,round(cylinderidfrac,RoundDown))
    cylinderidx= cylinderid - firstcylinderid + 1
    #The actual first and last monomer might be moved in if the cylinder isn't full.
    cyl_mon_id_first = max(cylinderid*numpercylinder, mon_id_first)
    cyl_mon_id_last = min(cylinderid*numpercylinder + numpercylinder - 1, mon_id_last)
    cyl_num_mons = cyl_mon_id_last - cyl_mon_id_first + 1
    mon_id_on_cyl = mon_id - cyl_mon_id_first
    frac = (mon_id_on_cyl + 0.5)*inv(cyl_num_mons)
    return cylinderidx, frac
end
