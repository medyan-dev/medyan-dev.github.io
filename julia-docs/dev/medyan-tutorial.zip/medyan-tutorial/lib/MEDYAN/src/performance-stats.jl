
"""
Holds various counters and other useful stats accumulated during a simulation

All fields must have a default value.

time is in nanoseconds

$(TYPEDFIELDS)

"""
Base.@kwdef mutable struct PerformanceStats
    "number of calls to minimize_energy!"
    minimize_energy_count::Int64 = 0
    minimize_energy_time::Int64 = 0

    "number of times the force/energy was evaluated during energy minimization"
    force_evals_count::Int64 = 0
    force_evals_time::Int64 = 0

    "number of reactions fired"
    reaction_count::Int64 = 0

    "number of times any reaction callback was called
    Note, callbacks are prepended when defining a system, 
    so `callback_reaction_count[end]` is the callback added first, and 
    `callback_reaction_count[1]` is the callback added last"
    callback_reaction_count::Vector{Int64} = []

    "number of calls to update_fila_mono_state!"
    update_fila_mono_state_count::Int64 = 0

    "number of calls to polymerize_fila!"
    polymerize_fila_count::Int64 = 0

    "number of calls to depolymerize_fila!"
    depolymerize_fila_count::Int64 = 0

    "number of calls to make_link!"
    make_link_count::Int64 = 0

    "number of calls to remove_link!"
    remove_link_count::Int64 = 0

    "number of calls to update_link!"
    update_link_count::Int64 = 0

    "number of calls to make_fila!"
    make_fila_count::Int64 = 0

    "number of calls to remove_fila!"
    remove_fila_count::Int64 = 0

    "Number of events of membrane species diffusing."
    chem_membranediffusing_count::Int64 = 0

    "Number of events of membrane site reactions."
    chem_membranesite_count::Int64 = 0

    "Number of events of membrane site reactions."
    chem_severfilament_count::Int64 = 0
end

"""
    stats_diff(new::PerformanceStats, old::PerformanceStats)::PerformanceStats
Return the change in performance stats.
"""
function stats_diff(new::PerformanceStats, old::PerformanceStats)
    PerformanceStats((getfield(new, k) - getfield(old, k) for k in fieldnames(PerformanceStats))...)
end

function prettytime(nanoseconds)::String
    value, units = if !(nanoseconds ≥ 0)
        (NaN, "")
    elseif nanoseconds < 1e3
        (nanoseconds / 1e0, "ns")
    elseif nanoseconds < 1e6
        (nanoseconds / 1e3, "μs")
    elseif nanoseconds < 1e9
        (nanoseconds / 1e6, "ms")
    elseif nanoseconds < 3600e9
        (nanoseconds / 1e9, "s")
    elseif nanoseconds < 86400e9
        (nanoseconds / 3600e9, "h")
    else
        (nanoseconds / 86400e9, "d")
    end
    value = if value ≥ 1000
        round(Int64, value, RoundDown)
    else
        round(value, RoundDown; sigdigits=4)
    end
    lpad("$(value)$(units)", 9)
end

function prettypercent(nominator, denominator)
    value = nominator / denominator * 100
    lpad("$(round(value; digits=1))%", 9, " ")
end

function prettycount(t::Integer)
    if t < 10^3
        return lpad(t, 9)
    end
    units = ("k", "M", "G", "T", "P", "E")
    i = 1
    while i < length(units) && t >= 10^7
        t = t ÷ 1000
        i += 1
    end
    s = string(t)
    lpad("$(s[1:end-3]).$(s[end-2:end])$(units[i])", 9)
end


"""
    prettystats(stats::PerformanceStats)::String

TimerOutputs.jl style table output
"""
function prettystats(stats::PerformanceStats)::String
    # TimerOutputs.jl style table output
    # https://github.com/KristofferC/TimerOutputs.jl
    min_en_c = prettycount(stats.minimize_energy_count)
    min_en_t = prettytime(stats.minimize_energy_time)
    min_en_a = prettytime(stats.minimize_energy_time/stats.minimize_energy_count)
    forces_c = prettycount(stats.force_evals_count)
    forces_t = prettytime(stats.force_evals_time)
    forces_a = prettytime(stats.force_evals_time/stats.force_evals_count)
    forces_p = prettypercent(stats.force_evals_time, stats.minimize_energy_time)
    forces_e = lpad(round(stats.force_evals_count/stats.minimize_energy_count; sigdigits=4), 9)
    reacti_c = prettycount(stats.reaction_count)
    """
    MEDYAN performance stats
     ──────────────────────────────────────────────────────────────────────
     Section                 ncalls      time  avg time      %par avg calls
     ──────────────────────────────────────────────────────────────────────
     minimize_energy      $min_en_c $min_en_t $min_en_a
       force_evals        $forces_c $forces_t $forces_a $forces_p $forces_e
     reactions            $reacti_c
     ──────────────────────────────────────────────────────────────────────
    """
end
