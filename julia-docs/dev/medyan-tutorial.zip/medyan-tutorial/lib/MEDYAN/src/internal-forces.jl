# Functions to help analyze the internal forces in a filament network
# The idea is that if the interactions in a network are cut on a plane
# the "negative" side of the plane will have some change in forces.
# This calculates the forces that are acting through the plane and assigns them
# a rough position on the plane.

struct StretchingEdge
    id1::Int
    id2::Int
    kd::Float64
    L0::Float64
end

function get_stretching_nl(fc::ForceContext, ftid::Int)::Vector{StretchingEdge}
    out = StretchingEdge[]
    filamentmechparam = fc.filamentmechparams[ftid]
    for info in fc.filamentindexinfo[ftid]
        startid = info.startid
        endid = info.endid
        # Precalculate stretching parameters for all types of cylinders
        L0minus = filamentmechparam.spacing * info.minusmonomerspercylinder
        kdminus = filamentmechparam.klength * inv(info.minusmonomerspercylinder)
        L0 = filamentmechparam.spacing * info.monomerspercylinder
        kd = filamentmechparam.klength * inv(info.monomerspercylinder)
        L0plus = filamentmechparam.spacing * info.plusmonomerspercylinder
        kdplus = filamentmechparam.klength * inv(info.plusmonomerspercylinder)
        # Handle first (minus end) cylinder
        push!(out, StretchingEdge(startid, startid+1, kdminus, L0minus))
        # Middle cylinders (if any)
        for i in (startid+1):(endid-2)
            push!(out, StretchingEdge(i, i+1, kd, L0))
        end
        # Handle last (plus end) cylinder if it's not the same as the first
        if startid + 1 < endid
            push!(out, StretchingEdge(endid-1, endid, kdplus, L0plus))
        end
    end
    out
end

function stretching_force!(force_energy::ForceEnergy, points, e::StretchingEdge)
    # Get positions of the two connected nodes
    pos = points[e.id1]
    nextpos = points[e.id2]
    
    # Calculate the vector between them
    r = nextpos - pos
    
    # Calculate the current length
    L = norm_fast(r)
    
    # Determine how much the length differs from rest length
    ΔL = e.L0 - L
    
    # Calculate unit direction vector
    invL = inv(L)
    r̂ = r*invL
    
    # Calculate energy (harmonic spring)
    Ed = 1//2*e.kd*(ΔL)^2
    
    # Calculate force (harmonic spring)
    F = e.kd*(ΔL)*r̂
    
    # Add energy and forces to the system
    add_energy!(force_energy, Ed)
    add_bead_force!(force_energy, e.id1, -F)
    add_bead_force!(force_energy, e.id2, +F)
end

struct BendingEdge
    id1::Int
    id2::Int
    id3::Int
    kangle::Float64
end

function get_bending_nl(fc::ForceContext, ftid)::Vector{BendingEdge}
    out = BendingEdge[]
    filamentmechparam = fc.filamentmechparams[ftid]
    for info in fc.filamentindexinfo[ftid]
        startid = info.startid
        endid = info.endid
        k∠ = filamentmechparam.kangle * inv(info.monomerspercylinder)
        for i in (startid+1):(endid-1)
            push!(out, BendingEdge(i-1, i, i+1, k∠))
        end
    end
    out
end

function bending_force!(force_energy::ForceEnergy, points, e::BendingEdge)
    # Get positions of the three connected nodes
    lastpos = points[e.id1]
    pos = points[e.id2]
    nextpos = points[e.id3]
    
    # Calculate the vectors between nodes
    r1 = lastpos - pos
    r2 = nextpos - pos
    
    # Calculate lengths and unit vectors
    L1 = norm_fast(r1)
    invL1 = inv(L1)
    r̂1 = r1 * invL1
    
    L2 = norm_fast(r2)
    invL2 = inv(L2)
    r̂2 = r2 * invL2
    
    # Calculate cosine of angle
    cosθ = r̂1 ⋅ r̂2
    
    # Calculate energy (1 + cosθ is 0 for straight filament, 2 for folded back)
    E∠ = e.kangle * (cosθ + 1)
    
    # Calculate forces
    F1∠ = e.kangle * invL1 * (r̂1 * cosθ - r̂2)
    F2∠ = e.kangle * invL2 * (r̂2 * cosθ - r̂1)
    
    # Add energy and forces to the system
    add_energy!(force_energy, E∠)
    add_bead_force!(force_energy, e.id1, F1∠)
    add_bead_force!(force_energy, e.id2, -(F1∠ + F2∠))
    add_bead_force!(force_energy, e.id3, F2∠)
end

"""
Return true if the point is on the negative side of the plane, other wise return false.
This is marked as noinline to prevent floating point reordering changing which side a point is on.

`normal` points to the positive side of the plane.
"""
@noinline function _get_side(normal::SVector{3, Float64}, offset::Float64, point::SVector{3, Float64})
    point ⋅ normal < offset
end

struct InternalForce
    f::SVector{3, Float64}
    r::SVector{3, Float64}
end

"""
Return net force on the negative side of a plane, and a point where
the line segment between centroids of points on either side intersect the plane.

`normal` points to the positive side of the plane.

Return nothing if all points are on the same side.
"""
function _get_tension(
        normal::SVector{3, Float64},
        offset::Float64,
        force_energy::DebugForceEnergy,
        points,
    )::Union{InternalForce, Nothing}
    @argcheck isempty(force_energy.added_dof_force)
    # number on minus side
    n_m = 0
    # number on plus side
    n_p = 0
    # minus side centroid
    m_c = zero(SVector{3, Float64})
    # plus side centroid
    p_c = zero(SVector{3, Float64})
    # minus side force
    f_m = zero(SVector{3, Float64})
    for (i, f) in force_energy.added_bead_force
        point = points[i]
        side = _get_side(normal, offset, point)
        if side
            f_m += f
            m_c += point
            n_m += 1
        else
            p_c += point
            n_p += 1
        end
    end
    if iszero(n_m) || iszero(n_p)
        return nothing
    end
    m_c *= inv(n_m)
    p_c *= inv(n_p)
    # Now get intersection between line seg between centroids and plane
    zm = m_c ⋅ normal
    zp = p_c ⋅ normal
    t = clamphhnan((offset - 1//2*(zm + zp)) / (zp - zm))
    force_point = p_c*(1//2 + t) + m_c*(1//2 - t)
    return InternalForce(f_m, force_point)
end

# This marked as mutating because it may update the neighbor lists in `fc`.
function get_cylinder_volume_exclusion_internal_forces!(
        normal::SVector{3, Float64},
        offset::Float64,
        fc::ForceContext,
        x0::AbstractVector{Float64},
    )::Vector{InternalForce}
    points = reinterpret(SVector{3, Float64}, x0)
    refresh_neighborlists!(fc, x0)
    out = InternalForce[]
    force_energy = DebugForceEnergy(length(x0))
    if fc.enable_cylinder_nl
        for i in eachindex(fc.cylinder_nl)
            set_zero_force_energy!(force_energy)
            MEDYAN.cylindervolume_exclusion_closest!(force_energy, x0, @view(fc.cylinder_nl[i:i]))
            res = _get_tension(normal, offset, force_energy, points)
            if !isnothing(res)
                push!(out, res)
            end
        end
    end
    out
end

function get_bond_internal_forces(
        normal::SVector{3, Float64},
        offset::Float64,
        fc::ForceContext,
        x0::AbstractVector{Float64},
        info::VectorBondInfo,
    )::Vector{InternalForce}
    points = reinterpret(SVector{3, Float64}, x0)
    out = InternalForce[]
    force_energy = DebugForceEnergy(length(x0))
    bnum = length(info.local_params)
    for i in 1:bnum
        set_zero_force_energy!(force_energy)
        bond_forces!(force_energy, x0, info; chunk=i, nthreads=bnum)
        res = _get_tension(normal, offset, force_energy, points)
        if !isnothing(res)
            push!(out, res)
        end
    end
    out
end

function get_stretching_internal_forces(
        normal::SVector{3, Float64},
        offset::Float64,
        fc::ForceContext,
        x0::AbstractVector{Float64},
        ftid::Int,
    )::Vector{InternalForce}
    points = reinterpret(SVector{3, Float64}, x0)
    out = InternalForce[]
    nl = get_stretching_nl(fc, ftid)
    force_energy = DebugForceEnergy(length(x0))
    for edge in nl
        set_zero_force_energy!(force_energy)
        stretching_force!(force_energy, points, edge)
        res = _get_tension(normal, offset, force_energy, points)
        if !isnothing(res)
            push!(out, res)
        end
    end
    out
end

function get_bending_internal_forces(
        normal::SVector{3, Float64},
        offset::Float64,
        fc::ForceContext,
        x0::AbstractVector{Float64},
        ftid::Int,
    )::Vector{InternalForce}
    points = reinterpret(SVector{3, Float64}, x0)
    out = InternalForce[]
    nl = get_bending_nl(fc, ftid)
    force_energy = DebugForceEnergy(length(x0))
    for edge in nl
        set_zero_force_energy!(force_energy)
        bending_force!(force_energy, points, edge)
        res = _get_tension(normal, offset, force_energy, points)
        if !isnothing(res)
            push!(out, res)
        end
    end
    out
end

function get_internal_forces!(
        normal::SVector{3, Float64},
        offset::Float64,
        fc::ForceContext,
        x0::AbstractVector{Float64}=fc.x0,
    )
    if !isempty(fc.smeshes)
        @warn "calculating internal membranes forces not supported yet. These will be skipped for now."
    end
    out = InternalForce[]
    append!(out, get_cylinder_volume_exclusion_internal_forces!(normal, offset, fc, x0))
    for info in fc.bond_info
        append!(out, get_bond_internal_forces(normal, offset, fc, x0, info))
    end
    for ftid in 1:length(fc.filamentmechparams)
        append!(out, get_stretching_internal_forces(normal, offset, fc, x0, ftid))
        append!(out, get_bending_internal_forces(normal, offset, fc, x0, ftid))
    end
    out
end
