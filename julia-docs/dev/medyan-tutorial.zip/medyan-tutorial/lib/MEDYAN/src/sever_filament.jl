# Function to sever a filament


"""
    sever_filament!(c::Context, mon_name::MonomerName)::Int

Return the new filament id of the minus end filament.

Calling this will invalidate the chem cache.

The split will happen between `mon_name` 
and the monomer slightly towards the minus end.

The plus end will keep the same `fil_id`, 
the minus end will get a new `fil_id`.

The split cannot create a filament with less than 2 monomers.
"""
function sever_filament!(c::Context, mon_name::MonomerName)::Int
    ftid = mon_name.ftid
    plus_fid = mon_name.fid
    mid = mon_name.mid
    cylinders = c.chem_cylinders[mon_name.ftid]
    fil_idx = cylinders.fil_id_2_idx[plus_fid]
    new_fid = c.largestfilamentid[ftid]+1
    new_fil_idx = _sever_filament!(cylinders, fil_idx, mid, new_fid)
    c.largestfilamentid[ftid]= new_fid
    defer_chem_caching!(c)
    # move tag for filament minus tip
    _move_place!(
        c.link_manager.fila_tip_tags,
        FilaTipIdx(FilaIdx(ftid, fil_idx), true),
        FilaTipIdx(FilaIdx(ftid, new_fil_idx), true),
    )
    # Add tags for new tips
    tag!(c, FilaTipIdx(FilaIdx(ftid, new_fil_idx), false))
    tag!(c, FilaTipIdx(FilaIdx(ftid, fil_idx), true))
    # move tags for filament monomers
    mon_states = fil_mon_states(c, ftid, new_fid)
    for mono_idx in eachindex(mon_states)
        local t = c.link_manager.fila_mono_tags
        local new_place = FilaMonoIdx(c, FilaIdx(ftid, new_fil_idx), mono_idx)
        local old_place = FilaMonoIdx(c, FilaIdx(ftid, fil_idx), mono_idx)
        _move_place!(
            t,
            old_place,
            new_place,
        )
    end
    # now update link_2mons
    linked_monomers = c.linked_monomers
    link_2mon_endnames_list = map(x->x.lidx_to_endnames, c.link_2mon_data)
    link_2mon_lid_to_lidx = map(x->x.lid_to_lidx, c.link_2mon_data)
    for mon_id in eachindex(mon_states)
        local old_name = MonomerName(ftid, plus_fid, mon_id)
        local new_name = MonomerName(ftid, new_fid, mon_id)
        local result = get(Returns(nothing), linked_monomers, old_name)
        if !isnothing(result)
            for (ltid, lids) in enumerate(result)
                local lid_to_lidx = link_2mon_lid_to_lidx[ltid]
                local endnames = link_2mon_endnames_list[ltid]
                for lid in lids
                    local lidx = lid_to_lidx[lid]
                    endnames[lidx] = Pair(replace(Tuple(endnames[lidx]), old_name=>new_name)...)
                end
            end
            insert!(linked_monomers, new_name, result)
            delete!(linked_monomers, old_name)
        end
    end
    foreach(c.cadherindata) do cdata
        for mon_id in eachindex(mon_states)
            local old_name = MonomerName(ftid, plus_fid, mon_id)
            local new_name = MonomerName(ftid, new_fid, mon_id)
            if old_name ∈ cdata.monname_to_cadidx
                change_monomer_name!(cdata, old_name, new_name)
            end
        end
    end
    new_fid
end