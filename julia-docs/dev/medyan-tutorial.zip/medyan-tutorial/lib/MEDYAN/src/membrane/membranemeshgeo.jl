using LinearAlgebra
using StaticArrays

@enum MeshCurvatureFormula begin
    # Signed curvature from surface evolver.
    #
    # The implementation is
    #         ⟨∇ Area, ∇ Vol⟩
    #   H = ------------------
    #        2 ⟨∇ Vol, ∇ Vol⟩
    #
    # where ∇ acts at the vertex of interest.
    #
    # The signed curvature will be stored in the curv variable, and their derivatives will be stored in curv related places.
    meshcurv_se

    # Square of curvature from surface evolver.
    #
    # The implementation is
    #           ⟨∇ Area, ∇ Area⟩
    #   H^2 = -------------------
    #           4 ⟨∇ Vol, ∇ Vol⟩
    #
    # The square of the curvature will be stored in the curv2 variable, and their derivatives will be stored related to curv2.
    meshcurv_se_sq

    # Method in Zhu et al. (2021) "Mem3DG: Modeling Membrane Mechanochemical Dynamics in 3D using Discrete Differential Geometry". https://doi.org/10.1101/2021.10.30.466618
    #
    # In equation (10) of the preprint,
    #                  l_ij ϕ_ij
    #   H_i = sum_ij  -----------
    #                    4 A_i
    #
    # where l_ij is the length of the edge ij, ϕ_ij is the dihedral angle between the two faces of the edge ij, and A_i is the area around vertex i.
    #
    # Using this policy should reproduce the credit of that paper.
    meshcurv_mem3dg
end

function compute_geometry!(m::StaticHalfedgeMesh, c::AbstractVector, ::Val{MeshCurv}) where MeshCurv

    "Auxiliary function to get an SVector from the coordinate array `c`, from index of x coordinate."
    function getc3(xcoordindex::Int)
        c[SVector{3}(xcoordindex:xcoordindex+2)]
    end

    Float = eltype(c)

    vs = m.vertices
    hs = m.halfedges
    es = m.edges
    ts = m.triangles

    # Compute edge length and dihedral angle.
    if MeshCurv == meshcurv_mem3dg
        for e ∈ eachindex(es)
            pt1, pt2 = es.conn[e].polygon_types
            if pt1 == pt_triangle && pt2 == pt_triangle
                t1, t2 = es.conn[e].polygon_indices
                x2, x1 = es.attr.cached_xcoordindices[e] # x2 is the target of halfedge.
                xs1 = ts.attr.cached_xcoordindices[t1]
                xs2 = ts.attr.cached_xcoordindices[t2]
                x3 = ⊻(xs1..., x1, x2) # Remaining index in xs1.
                x4 = ⊻(xs2..., x1, x2) # Remaining index in xs2.

                c1 = getc3(x1)
                c2 = getc3(x2)
                c3 = getc3(x3)
                c4 = getc3(x4)

                u1 = c2 - c3
                u2 = c1 - c2
                u3 = c4 - c1
                len = norm_fast(u2)
                m.edges.attr.length[e] = len
                cross23 = cross(u2, u3)
                cross12 = cross(u1, u2)
                m.edges.attr.normal_angle[e] = atan(len * dot(u1, cross23), -dot(cross12, cross23))
            end
        end
    end

    # Compute
    # - angles and triangle areas with derivatives.
    # - triangle cone volumes.
    for t ∈ 1:length(ts)
        xs = ts.attr.cached_xcoordindices[t]
        ihs = ts.conn[t].halfedge_indices
        cs = getc3.(xs)

        us = SA[
            cs[1] - cs[3],
            cs[2] - cs[1],
            cs[3] - cs[2],
        ]
        l2s = SA[dot(us[1], us[1]), dot(us[2], us[2]), dot(us[3], us[3])]
        dots = SA[-dot(us[2], us[1]), -dot(us[3], us[2]), -dot(us[1], us[3])]

        cp = -cross(us[2], us[1]) # Pointing outward.

        # Area.
        area = norm_fast(cp) / 2
        ts.attr.area[t] = area
        inva = 1 / area

        # Area gradients.
        hs.attr.g_triangle_area[ihs[1]] = (l2s[2]*us[1] - l2s[1]*us[2] + dots[1]*(us[2]-us[1])) * (inva / 4)
        hs.attr.g_triangle_area[ihs[2]] = (l2s[1]*us[2] + dots[1]*us[1]) * (inva / 4)
        hs.attr.g_triangle_area[ihs[3]] = (-l2s[2]*us[1] - dots[1]*us[2]) * (inva / 4)

        # cotθ and gradients.
        for ai ∈ 1:3
            hs.attr.cotθ[ihs[ai]] = dots[ai] * inva / 2

            ai_n = mod1(ai + 1, 3)
            ai_p = mod1(ai - 1, 3)

            g_area_fac = -dots[ai] * inva * inva / 2
            hs.attr.g_cotθ[ihs[ai]] = SA[
                us[ai_n] * (inva / 2) + g_area_fac * hs.attr.g_triangle_area[ihs[ai_p]],
                -(us[ai_n] - us[ai]) * (inva / 2) + g_area_fac * hs.attr.g_triangle_area[ihs[ai]],
                -us[ai] * (inva / 2) + g_area_fac * hs.attr.g_triangle_area[ihs[ai_n]],
            ]
        end

        # Cone volume.
        ts.attr.cone_volume[t] = dot(cs[1], cross(cs[2], cs[3])) / 6
    end

    # Compute
    # - vertex 1-ring area and curvature (se) with derivatives.
    # - derivative of volume on vertices.
    for v ∈ 1:length(vs)
        xmid = vs.attr.cached_xcoordindex[v]
        cmid = getc3(xmid)
        deg = vs.conn[v].degree

        # Clear data.
        vs.attr.astar[v] = 0
        vs.attr.g_astar[v] = SA[0,0,0]
        vs.attr.g_volume[v] = SA[0,0,0]

        #-----------------------------------------------------------------
        # Signed curvature implementation
        # (see star_perp_sq_mean_curvature of Surface Evolver):
        #         ⟨∇ Area, ∇ Vol⟩
        #   H = ------------------
        #        2 ⟨∇ Vol, ∇ Vol⟩
        #
        # Therefore (here G can operate on neighbor vertices, while ∇ only on center vertex),
        #
        #           G(∇ Area) ∇ Vol + G(∇ Vol) ∇ Area - 4H G(∇ Vol) ∇ Vol
        #   GH = -----------------------------------------------------------
        #                            2 ⟨∇ Vol, ∇ Vol⟩
        #
        # For intermediate variables, let
        #   t1 = G(∇ Area) ∇ Vol    (G on both central and neighbor vertices)
        #   t2 = G(∇ Vol) ∇ Area    (G on only neighbor vertices because G(∇ Vol) on center vertex is 0)
        #   t3 = G(∇ Vol) ∇ Vol     (G on only neighbor vertices because G(∇ Vol) on center vertex is 0)
        # then
        #
        #          t1 + t2 - 4H t3
        #   GH = --------------------
        #          2 ⟨∇ Vol, ∇ Vol⟩
        #
        #-----------------------------------------------------------------
        # Squared curvature implementation
        #
        #              G(∇ Area) ∇ Area - 4 H^2 G(∇ Vol) ∇ Vol
        #   G(H^2) = --------------------------------------------
        #                         2 ⟨∇ Vol, ∇ Vol⟩
        #
        # And G can operate on center or neighbor vertices.
        #
        # An additional intermediate variable would be
        #   t4 = G(∇ Area) ∇ Area  (G on both central and neighbor vertices)
        # then
        #
        #                t4 - 4 H^2 t3
        #   G(H^2) = ---------------------
        #               2 ⟨∇ Vol, ∇ Vol⟩
        #
        #-----------------------------------------------------------------

        # Compute
        # - astar and derivatives.
        # - volume derivatives on the vertex.
        for in ∈ 1:deg
            h_p = get_outer_halfedge(m, in, v)
            h_o = get_leaving_halfedge(m, in, v)
            h_n = get_leaving_halfedge(m, mod1(in-1, deg), v)
            h_on = get_outer_halfedge(m, mod1(in+1, deg), v)
            
            pi = get_polygon(m, in, v)
            pt = m.halfedges.conn[h_p].polygon_type
            pt_right = m.halfedges.conn[h_o].polygon_type

            x_n = vs.attr.cached_xcoordindex[get_neighbor_vertex(m, in, v)]
            x_right = vs.attr.cached_xcoordindex[get_neighbor_vertex(m, mod1(in+1, deg), v)]
            c_n = getc3(x_n)
            c_right = getc3(x_right)

            sumcotθ = (pt==pt_triangle ? hs.attr.cotθ[h_n] : zero(Float)) + (pt_right==pt_triangle ? hs.attr.cotθ[h_on] : zero(Float))
            diff = cmid - c_n

            if pt == pt_triangle
                vs.attr.astar[v] += ts.attr.area[pi]
            end
            vs.attr.g_astar[v] += (sumcotθ / 2) * diff

            # ∂_n astar.
            hs.attr.g_ontarget_sourceastar[h_o] = (
                (pt==pt_triangle ? hs.attr.g_triangle_area[h_p] : SA{Float64}[0,0,0]) +
                (pt_right==pt_triangle ? hs.attr.g_triangle_area[h_o] : SA{Float64}[0,0,0])
            )

            # Add to volume derivative.
            if pt_right == pt_triangle
                cp = cross(c_n, c_right)
                vs.attr.g_volume[v] += cp * (1/6)
            end
        end

        # SE curvatures and derivatives.
        if (MeshCurv == meshcurv_se || MeshCurv == meshcurv_se_sq) && !vs.conn[v].onborder
            gvol = vs.attr.g_volume[v]
            gastar = vs.attr.g_astar[v]
            gvol2 = dot(gvol, gvol)

            if MeshCurv == meshcurv_se
                vs.attr.curv[v] = dot(vs.attr.g_astar[v], vs.attr.g_volume[v]) / (gvol2 * 2)
            else
                vs.attr.curv2[v] = dot(vs.attr.g_astar[v], vs.attr.g_astar[v]) / (gvol2 * 4)
            end

            # Compute derivatives.

            ∇∇astar = @SMatrix zeros(3,3) # [i,j] -> ∂_i ∂_j astar
            for in ∈ 1:deg
                h_p = get_outer_halfedge(m, in, v)
                h_o = get_leaving_halfedge(m, in, v)
                h_n = get_leaving_halfedge(m, mod1(in-1, deg), v)
                h_on = get_outer_halfedge(m, mod1(in+1, deg), v)
                
                pt = m.halfedges.conn[h_p].polygon_type
                pt_right = m.halfedges.conn[h_o].polygon_type
    
                x_n = vs.attr.cached_xcoordindex[get_neighbor_vertex(m, in, v)]
                x_left = vs.attr.cached_xcoordindex[get_neighbor_vertex(m, mod1(in-1, deg), v)]
                x_right = vs.attr.cached_xcoordindex[get_neighbor_vertex(m, mod1(in+1, deg), v)]
                c_n = getc3(x_n)
                c_left = getc3(x_left)
                c_right = getc3(x_right)

                sumcotθ = (pt==pt_triangle ? hs.attr.cotθ[h_n] : 0.0) + (pt_right==pt_triangle ? hs.attr.cotθ[h_on] : 0.0)
                sum_g_cotθ_mid = (pt==pt_triangle ? hs.attr.g_cotθ[h_n][1] : SA{Float64}[0,0,0]) + (pt_right==pt_triangle ? hs.attr.g_cotθ[h_on][3] : SA{Float64}[0,0,0])
                sum_g_cotθ_n = (pt==pt_triangle ? hs.attr.g_cotθ[h_n][3] : SA{Float64}[0,0,0]) + (pt_right==pt_triangle ? hs.attr.g_cotθ[h_on][1] : SA{Float64}[0,0,0])

                diff = cmid - c_n
                diff_left = cmid - c_left
                diff_right = cmid - c_right
                g_cotθ_left = (pt==pt_triangle ? hs.attr.g_cotθ[h_p][2] : SA{Float64}[0,0,0])
                g_cotθ_right = (pt_right==pt_triangle ? hs.attr.g_cotθ[h_o][2] : SA{Float64}[0,0,0])

                # Accumulate ∇∇astar on cmid.
                ∇∇astar += @SMatrix [
                    (sum_g_cotθ_mid[i] / 2) * diff[j] + (i == j ? sumcotθ / 2 : 0.0)
                    for i ∈ 1:3, j ∈ 1:3
                ]

                # G∇astar on neighbor vertex c_n.
                Gn∇astar = @SMatrix [
                    (sum_g_cotθ_n[i] / 2) * diff[j] - (i == j ? sumcotθ / 2 : 0.0) + (g_cotθ_left[i] / 2) * diff_left[j] + (g_cotθ_right[i] / 2) * diff_right[j]
                    for i ∈ 1:3, j ∈ 1:3
                ]

                # Gn(∇ Vol) = (1/6) Gn (c_left x c_n + c_n x c_right)
                #           = (1/6) Gn (c_n x (c_right - c_left))
                # Then for any vector v,
                # [Gn (∇ Vol)] v = (1/6) (c_right - c_left) x v
                vec_lr = c_right - c_left
    
                # Compute t1_n, t2_n and t3_n.
                t3_n = (1/6) * cross(vec_lr, gvol)

                if MeshCurv == meshcurv_se
                    t1_n = Gn∇astar * gvol
                    t2_n = (1/6) * cross(vec_lr, gastar)

                    # Curvature derivative.
                    hs.attr.g_ontarget_sourcecurv[h_o] = (t1_n + t2_n - (4 * vs.attr.curv[v]) * t3_n) / (2 * gvol2)
                else
                    t4_n = Gn∇astar * gastar

                    # Curvature squared derivative.
                    hs.attr.g_ontarget_sourcecurv2[h_o] = (t4_n - (4 * vs.attr.curv2[v]) * t3_n) / (2 * gvol2)
                end
            end # End loop neighbor vertices.

            if MeshCurv == meshcurv_se
                t1 = ∇∇astar * gvol
                vs.attr.g_curv[v] = t1 * (1/(2 * gvol2))
            else
                t4 = ∇∇astar * gastar
                vs.attr.g_curv2[v] = t4 * (1/(2 * gvol2))
            end
        end # End of se curvature and derivatives.
    end # End looping all vertices.

    # Compute
    # - curvature (mem3dg) and derivatives.
    if MeshCurv == meshcurv_mem3dg

        # First pass: curvature only.
        for v ∈ 1:length(vs)
            if !vs.conn[v].onborder
                xmid = vs.attr.cached_xcoordindex[v]
                cmid = getc3(xmid)
                deg = vs.conn[v].degree

                wsum_dihedral = 0.0
                for in ∈ 1:deg
                    e = get_targeting_edge(m, in, v)
                    wsum_dihedral += es.attr.normal_angle[e] * es.attr.length[e]
                end
    
                vs.attr.curv[v] = wsum_dihedral * 3 / (4 * vs.attr.astar[v])
            end
        end # End looping all vertices.

        # Second pass: curvature derivatives.
        for v ∈ 1:length(vs)
            if !vs.conn[v].onborder
                xmid = vs.attr.cached_xcoordindex[v]
                cmid = getc3(xmid)
                deg = vs.conn[v].degree

                sumstuff = SA{Float64}[0,0,0]
                for in ∈ 1:deg
                    h = get_targeting_halfedge(m, in, v)
                    h_p = get_outer_halfedge(m, in, v)
                    h_o = get_leaving_halfedge(m, in, v)
                    h_n = get_leaving_halfedge(m, mod1(in-1, deg), v)
                    h_on = get_outer_halfedge(m, mod1(in+1, deg), v)
                    e = get_targeting_edge(m, in, v)
                    vn = get_neighbor_vertex(m, in, v)

                    xn = vs.attr.cached_xcoordindex[vn]
                    xl = vs.attr.cached_xcoordindex[get_neighbor_vertex(m, mod1(in-1, deg), v)]
                    xr = vs.attr.cached_xcoordindex[get_neighbor_vertex(m, mod1(in+1, deg), v)]
                    cn = getc3(xn)
                    cl = getc3(xl)
                    cr = getc3(xr)
    
                    nl = normalize_fast(cross(cmid - cn, cl - cmid))
                    nr = normalize_fast(cross(cn - cmid, cr - cn))
    
                    kvec = (es.attr.normal_angle[e] / (2*es.attr.length[e])) * (cmid - cn)
                    sumstuff += (
                        (1/2) * kvec +
                        (1/4) * (hs.attr.cotθ[h_o] * nr + hs.attr.cotθ[h_p] * nl)
                    )
    
                    # Derivative of this curvature on neighbor vertex vn.
                    hs.attr.g_ontarget_sourcecurv[h_o] = (
                        (
                            - kvec
                            - (1/2) * (hs.attr.cotθ[h_on] * nr + hs.attr.cotθ[h_n] * nl)
                        ) * (3 / (2 * vs.attr.astar[v]))
                        - (vs.attr.curv[v] / vs.attr.astar[v]) * hs.attr.g_ontarget_sourceastar[h_o]
                    )
                end
    
                # Derivative of curvature.
                vs.attr.g_curv[v] = sumstuff * (3 / vs.attr.astar[v]) - (vs.attr.curv[v] / vs.attr.astar[v]) * vs.attr.g_astar[v]
            end
        end # End looping all vertices.
    end # End of mem3dg curvature and derivatives.
end


"""
Compute triangle unit normal used in adaptive mesh algorithm.

Requires up-to-date vertex coordinates.
"""
function compute_triangle_normal_ada!(m::DynamicHalfedgeMesh, t::IT)
    h = halfedge(m, t)
    v1 = target(m, h)
    v2 = target(m, next(m, h))
    v3 = target(m, prev(m, h))
    c1 = m.vertices.attr.coord[v1.value]
    c2 = m.vertices.attr.coord[v2.value]
    c3 = m.vertices.attr.coord[v3.value]

    cp = cross(c2 - c1, c3 - c1)
    m.triangles.attr.unitnormal[t.value] = normalize_fast(cp)
end

function compute_all_triangle_normals_ada!(m::DynamicHalfedgeMesh)
    for t ∈ 1:length(m.triangles)
        compute_triangle_normal_ada!(m, IT(t))
    end
end


"""
Compute the angle and its cotangent value used in adaptive mesh.

Requires up-to-date vertex coordinates.
"""
function compute_angle_ada!(m::DynamicHalfedgeMesh, h::IH)
    v1 = target(m, prev(m, h))
    v2 = target(m, h)
    v3 = target(m, next(m, h))
    c1 = m.vertices.attr.coord[v1.value]
    c2 = m.vertices.attr.coord[v2.value]
    c3 = m.vertices.attr.coord[v3.value]

    cp = cross(c1 - c2, c3 - c2)
    dp = dot(c1 - c2, c3 - c2)
    ct = dp / norm_fast(cp)
    m.halfedges.attr.cotθ[h.value] = ct
    m.halfedges.attr.θ[h.value] = π/2 - atan(ct)
end

function compute_all_angles_ada!(m::DynamicHalfedgeMesh)
    for h ∈ 1:length(m.halfedges)
        compute_angle_ada!(m, IH(h))
    end
end

"""
Compute the vertex unit normal used in adaptive mesh.

Requires up-to-date
- triangle unit normals
- angles in halfedges
"""
function compute_vertex_normal_ada!(m::DynamicHalfedgeMesh, v::IV)
    un = SA{Float64}[0,0,0]

    for h ∈ HalfedgesTargetingVertex(m, v)
        if polygon(m, h).type == pt_triangle
            t = triangle(m, h)
            θ = m.halfedges.attr.θ[h.value]
            un += θ * m.triangles.attr.unitnormal[t.value]
        end
    end

    m.vertices.attr.ada_unitnormal[v.value] = normalize_fast(un)
end

function compute_all_vertex_normals_ada!(m::DynamicHalfedgeMesh)
    for v ∈ 1:length(m.vertices)
        compute_vertex_normal_ada!(m, IV(v))
    end
end


"""
    $(TYPEDSIGNATURES)

Updates geometries necessary for MEDYAN system, including
- (pseudo) unit normals                  -- compartment slicing / signed distance
- triangle areas                         -- compartment slicing
- vertex 1-ring areas                    -- membrane chemistry
- cotθ                                   -- membrane surface diffusion rate
- θ                                      -- pseudo unit normals
"""
function compute_geometry!_system(m::DynamicHalfedgeMesh)
    nv = length(m.vertices)
    nh = length(m.halfedges)
    ne = length(m.edges)
    nt = length(m.triangles)

    # Calculate angles stored in halfedges.
    for hindex ∈ 1:nh
        h = IH(hindex)
        # The angle is ∠123.
        c1 = m.vertices.attr.coord[(h |> prev(m) |> target(m)).value]
        c2 = m.vertices.attr.coord[(h |> target(m)).value]
        c3 = m.vertices.attr.coord[(h |> next(m) |> target(m)).value]

        r21 = c1 - c2
        r23 = c3 - c2
        cp = cross(r21, r23)
        dp = dot(r21, r23)
        cotθ = dp / norm_fast(cp)
        θ = π/2 - atan(cotθ)
        m.halfedges.attr.cotθ[hindex] = cotθ
        m.halfedges.attr.θ[hindex] = θ
    end

    # Calculate triangle unit normal and area.
    for tindex ∈ 1:nt
        t = IT(tindex)
        h = halfedge(m, t)
        hn = next(m, h)
        hp = prev(m, h)
        vs = SA[target(m, h), target(m, hn), target(m, hp)]
        cs = map(v -> m.vertices.attr.coord[v.value], vs)

        cp = cross(cs[2] - cs[1], cs[3] - cs[1])
        Ac = norm_fast(cp)

        # Unit normal.
        m.triangles.attr.unitnormal[tindex] = cp / Ac

        # Area.
        m.triangles.attr.area[tindex] = Ac / 2
    end

    # Calculate edge pesudo unit normal.
    for eindex ∈ 1:ne
        e = IE(eindex)
        h = halfedge(m, e)
        ho = oppo(m, h)

        ist1 = polygon(m, h).type == pt_triangle
        ist2 = polygon(m, ho).type == pt_triangle

        # Pseudo unit normal.
        if ist1 && ist2
            m.edges.attr.pseudo_unitnormal[eindex] = normalize_fast(
                m.triangles.attr.unitnormal[triangle(m, h).value] +
                m.triangles.attr.unitnormal[triangle(m, ho).value]
            )
        elseif ist1
            m.edges.attr.pseudo_unitnormal[eindex] = m.triangles.attr.unitnormal[triangle(m, h).value]
        elseif ist2
            m.edges.attr.pseudo_unitnormal[eindex] = m.triangles.attr.unitnormal[triangle(m, ho).value]
        end
    end

    # Calculate vertex pseudo unit normal.
    for vindex ∈ 1:nv
        v = IV(vindex)

        local pseudo_unitnormal::SVector{3,Float64} = SA[0,0,0]
        local astar::Float64 = 0

        for h ∈ HalfedgesTargetingVertex(m, v)
            if polygon(m, h).type == pt_triangle
                local t = triangle(m, h)
                local θ = m.halfedges.attr.θ[h.value]

                pseudo_unitnormal += θ * m.triangles.attr.unitnormal[t.value]
                astar += m.triangles.attr.area[t.value]
            end
        end
        m.vertices.attr.pseudo_unitnormal[vindex] = normalize_fast(pseudo_unitnormal)
        m.vertices.attr.astar[vindex] = astar
    end
end


"""
Ad-hoc way to compute vertex astar.
"""
function adhoc_astar(m::DynamicHalfedgeMesh, v::IV)
    astar::Float64 = 0
    c = m.vertices.attr.coord[v.value]
    for h ∈ HalfedgesTargetingVertex(m, v)
        if polygon(m, h).type == pt_triangle
            vo = h |> oppo(m) |> target(m)
            vn = h |> next(m) |> target(m)
            co = m.vertices.attr.coord[vo.value]
            cn = m.vertices.attr.coord[vn.value]
            cp = cross(c - co, cn - c)
            astar += norm_fast(cp) / 2
        end
    end
    astar
end


#---------------------------------------
# Signed distance field related functions.
#---------------------------------------

"""
    $(TYPEDSIGNATURES)

Given a point `p`, find the signed distance with respect to a triangle element in the mesh.

This function requires but does not verify up-to-date
- vertex coordinates
- (pseudo) unit normal for triangles, edges and vertices

This function works by
1. Find the projection of the point on the triangle plane, and determine which element (triangle/edge/vertex) is the closest to the point.
2. Find the unsigned distance with the closest element, and then the signed distance using the (pseudo) normal or pseudo normal
"""
function signed_distance_element(m::DynamicHalfedgeMesh, t::IT, p::AbstractVector)
    h1 = halfedge(m, t)
    h2 = next(m, h1)
    h3 = next(m, h2)
    vs = SA[target(m, h1), target(m, h2), target(m, h3)]
    cs = map(v -> m.vertices.attr.coord[v.value], vs)

    r12 = cs[2] - cs[1]
    r13 = cs[3] - cs[1]
    r1p = p - cs[1]
    cp = cross(r12, r13)
    invAc = 1 / dot(cp, cp)

    b2 = dot(cross(r1p, r13), cp) * invAc
    b3 = dot(cross(r12, r1p), cp) * invAc
    b1 = 1 - b2 - b3

    # Now p' = b1*v1 + b2*v2 + b3*v3
    # where p' is the projection of p in the plane of the triangle.
    if b1 >= 0 && b2 >= 0 && b3 >= 0
        # p' is inside the triangle.
        return dot(m.triangles.attr.unitnormal[t.value], r1p)
    else
        # p' is outside triangle.
        l2s = SA[sum(abs2, cs[2]-cs[3]), sum(abs2, cs[3]-cs[1]), sum(abs2, cs[1]-cs[2])]
        r2p = p - cs[2]
        r3p = p - cs[3]
        r23 = cs[3] - cs[2]
        dot_2p_23 = dot(r2p, r23)
        dot_3p_31 = -dot(r3p, r13)
        dot_1p_12 = dot(r1p, r12)

        if b1 < 0 && dot_2p_23 >= 0 && dot_2p_23 <= l2s[1]
            # Edge 23.
            d = sqrt(sum(abs2, cross(r2p, r23)) / l2s[1])
            if dot(m.edges.attr.pseudo_unitnormal[edge(m, h3).value], r2p) < 0
                d = -d
            end
            return d
        elseif b2 < 0 && dot_3p_31 >= 0 && dot_3p_31 <= l2s[2]
            # Edge 31.
            d = sqrt(sum(abs2, cross(r3p, r13)) / l2s[2])
            if dot(m.edges.attr.pseudo_unitnormal[edge(m, h1).value], r3p) < 0
                d = -d
            end
            return d
        elseif b3 < 0 && dot_1p_12 >= 0 && dot_1p_12 <= l2s[3]
            # Edge 12.
            d = sqrt(sum(abs2, cross(r1p, r12)) / l2s[3])
            if dot(m.edges.attr.pseudo_unitnormal[edge(m, h2).value], r1p) < 0
                d = -d
            end
            return d
        elseif dot_1p_12 < 0 && dot_3p_31 > l2s[2]
            # Vertex 1.
            d = norm_fast(cs[1] - p)
            if dot(m.vertices.attr.pseudo_unitnormal[vs[1].value], r1p) < 0
                d = -d
            end
            return d
        elseif dot_2p_23 < 0 && dot_1p_12 > l2s[3]
            # Vertex 2.
            d = norm_fast(cs[2] - p)
            if dot(m.vertices.attr.pseudo_unitnormal[vs[2].value], r2p) < 0
                d = -d
            end
            return d
        elseif dot_3p_31 < 0 && dot_2p_23 > l2s[1]
            # Vertex 3.
            d = norm_fast(cs[3] - p)
            if dot(m.vertices.attr.pseudo_unitnormal[vs[3].value], r3p) < 0
                d = -d
            end
            return d
        else
            error("Invalid case of point projection on the plane of triangle.")
        end
    end
end


"""
Find the triangle in the mesh that has the closest distance to a given point.
The returned triangle is represented by index with type IT.
The mesh must contain at least 1 triangle.
"""
function find_closest_triangle(m::DynamicHalfedgeMesh, p::AbstractVector; accel::Union{Nothing} = nothing)
    if length(m.triangles) == 0
        error("The mesh must contain at least 1 triangle.")
    end
end

"""
    signed_distance(mesh, point; accel=nothing)

Find the triangle in the mesh that has the closest distance to a given point.
The returned triangle is represented by index with type IT.
Requires:
- At least 1 triangle in the mesh.
- Up-to-date pseudo unit normal vectors on all elements in the mesh.

`accel`: the auxiliary data structure to accelerate computation. By default, it's nothing, which requires looping through all triangles.
"""
function signed_distance(m::DynamicHalfedgeMesh, p::AbstractVector; accel::Union{Nothing} = nothing)
    if length(m.triangles) == 0
        error("The mesh must contain at least 1 triangle.")
    end
    if isnothing(accel)
        # Loop through all triangles.
        d_minabs = Inf
        for tindex ∈ eachindex(m.triangles)
            d = signed_distance_element(m, IT(tindex), p)
            if abs(d) < abs(d_minabs)
                d_minabs = d
            end
        end
        return d_minabs
    end
end
