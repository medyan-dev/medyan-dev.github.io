using LinearAlgebra
using Meshing: isosurface, MarchingTetrahedra

"""
    $(TYPEDSIGNATURES)
Initialize dynamic halfedge mesh with vertex coordinates and list of triangles.

`initdata` contains the following fields:
    - `vertlist::Vector{SVector{3,F}} where {F<:Real}`
    - `trilist::Vector{SVector{3,Int}}`
    - Optional `copynumbers::StructArray`: Contains all copy number information in cells. Defaults to all 0.
    - Optional `id`: Contains vertex ID information. Defaults to unspecified unique ids.
    - Optional `vertexstate`: Vertex reactional activity. Defaults to one (can't bind with vertices).
"""
function initmesh!(m::DynamicHalfedgeMesh, initdata::NamedTuple)
    # Initialize vertices and triangles.
    (; vertlist, trilist) = initdata
    initmesh!_vertex_triangle(m, length(vertlist), trilist)
    # Set vertex coordinates.
    for i ∈ 1:length(vertlist)
        m.vertices.attr.coord[i] = vertlist[i]
    end
    # Store all copy numbers.
    if hasfield(typeof(initdata), :copynumbers)
        speciesnames = m |> get_speciesnames
        for name ∈ speciesnames
            getproperty(m.vertices.attr.copynumbers, name) .= getproperty(initdata.copynumbers, name)
        end
    elseif hasproperty(m.vertices.attr, :copynumbers)
        for speciesindex ∈ 1:get_numdiffusingspecies(m)
            getproperty(m.vertices.attr.copynumbers, speciesindex) .= 0
        end
    end
    # Setup vertex id map.
    if hasfield(typeof(initdata), :id)
        hasfield(typeof(m.metaattr), :id2index_vertex) || error("The mesh type does not have :id2index_vertex in meta attribute.")
        maxid = 0
        for vindex ∈ eachindex(vertlist)
            m.vertices.attr.id[vindex] = initdata.id[vindex]
            maxid = max(maxid, initdata.id[vindex])
        end
        # Adjust id2index_vertex structure.
        idmap = m.metaattr.id2index_vertex
        resize!(idmap.indices, maxid)
        fill!(idmap.indices, 0)
        for vindex ∈ eachindex(vertlist)
            idmap.indices[initdata.id[vindex]] = vindex
        end
        empty!(idmap.unused_ids)
        sizehint!(idmap.unused_ids, maxid - length(vertlist))
        for vid ∈ 1:maxid
            if idmap.indices[vid] == 0
                push!(idmap.unused_ids, vid)
            end
        end
    elseif hasfield(typeof(m.metaattr), :id2index_vertex)
        # Use indices as IDs.
        idmap = m.metaattr.id2index_vertex
        resize!(idmap.indices, length(vertlist))
        empty!(idmap.unused_ids)
        for vindex ∈ eachindex(vertlist)
            idmap.indices[vindex] = vindex
            m.vertices.attr.id[vindex] = vindex
        end
    end
    # Give vertices typename
    if hasfield(typeof(initdata), :vertexstate)
        for vidx ∈ eachindex(vertlist)
            m.vertices.attr.vertexstate[vidx] = initdata.vertexstate[vidx]
        end
    else
        for vidx ∈ eachindex(vertlist)
            m.vertices.attr.vertexstate[vidx] = UInt8(1)       
        end
    end
    # Zero-initialize propensities and site count contributions.
    let
        numspecies = get_numdiffusingspecies(m)
        for speciesindex ∈ 1:numspecies
            # Zero-initialize all propensities. Copy numbers do not matter. They just need to be consistent with total propensities, which should be zero by now.
            getproperty(m.halfedges.attr.diffusion_a, speciesindex) .= 0
        end
        m.vertices.attr.outdiffusion_a .= 0
        numsites = get_nummembranesites(m)
        for siteindex ∈ 1:numsites
            # Zero-initialize site count contributions.
            getproperty(m.vertices.attr.contrib_membranesitecount, siteindex) .= 0
        end
    end
end


Base.@kwdef struct MeshInitSurfaceFunc{V1<:AbstractVector, V2<:AbstractVector, Func}
    boxorigin::V1
    boxwidths::V2
    samples::SVector{3,Int} = SA[40,40,40]
    surfacefunc::Func
end

"""
    $(TYPEDSIGNATURES)
Generate surface mesh represented by vertex coordinates and the triangle list, given the bounding box and the surface function. Marching Tetrahedra is used.
"""
function genmesh(init::MeshInitSurfaceFunc)
    vertlist, trilist = old_isosurface(init.surfacefunc, MarchingTetrahedra(); origin=init.boxorigin, widths=init.boxwidths, samples=init.samples)
    (; vertlist, trilist)
end


Base.@kwdef struct MeshInitEllipsoid{V1<:AbstractVector, V2<:AbstractVector}
    center::V1
    "Vector of half the lengths of the x, y, z principal axes."
    halfaxes::V2
    samples::SVector{3,Int} = SA[40,40,40]
end

"""
    $(TYPEDSIGNATURES)
Generate surface mesh of an ellipsoid (aligned to x, y, z axes).
"""
function genmesh(init::MeshInitEllipsoid)
    halfwidths = 1.2 * init.halfaxes
    genmesh(MeshInitSurfaceFunc(
        boxorigin = init.center - halfwidths,
        boxwidths = halfwidths * 2,
        samples = init.samples,
        surfacefunc = v -> begin
            r = (v - init.center) ./ init.halfaxes
            r ⋅ r - 1
        end
    ))
end


Base.@kwdef struct MeshInitPlane{V1<:AbstractVector, V2<:AbstractVector, V3<:AbstractVector, N<:Number}
    boxorigin::V1
    boxwidths::V2
    "No need to be normalized. Its length affects plane distance from origin and must not be zero."
    normal::V3
    normal_multiplier_from_origin::N
    samples::SVector{3,Int} = SA[40,40,40]
end

"""
    $(TYPEDSIGNATURES)
Generate surface mesh of plane in a bounding box. Returns vertex coordinates and list of triangles.
"""
function genmesh(init::MeshInitPlane)
    invn2 = 1 / dot(init.normal, init.normal)
    genmesh(MeshInitSurfaceFunc(
        boxorigin = init.boxorigin,
        boxwidths = init.boxwidths,
        samples = init.samples,
        surfacefunc = v -> begin
            dot(v, init.normal) * invn2 - init.normal_multiplier_from_origin
        end
    ))
end



"""
    $(TYPEDSIGNATURES)
Initialize halfedge mesh using a shape initializer.

This function also sets all copy numbers to zero.
"""
function initmesh!(m::DynamicHalfedgeMesh, init)
    vertlist, trilist = genmesh(init)
    # initmesh! without a copynumbers field will initialize any copy numbers to zero 
    initmesh!(m, (; vertlist, trilist))
end

