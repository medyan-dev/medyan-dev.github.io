"""$PUBLIC
Allows up to 1 membrane diffusing species as reactants.
Also stores net stoich of membrane diffusing species.

$(TYPEDFIELDS)
"""
struct MembraneSiteDiffusing
    "Set to 0 if no membrane diffusing species is involved."
    id_membranediffusing_reactant::Int

    "Whether the reaction rate depends on reactant species potential energy."
    canchangerate_bypotentialenergy::Bool

    "Pairs of membrane diffusing species index => Δcount"
    membranediffusingnet_stoich::Vector{Pair{Int,Int}}
end
export MembraneSiteDiffusing

function get_reactantid(site::MembraneSiteDiffusing)
    site.id_membranediffusing_reactant
end
export get_reactantid
function get_canpotentialenergychangerate(site::MembraneSiteDiffusing)
    site.canchangerate_bypotentialenergy
end
export get_canpotentialenergychangerate
function get_stoich(site::MembraneSiteDiffusing)
    site.membranediffusingnet_stoich
end
export get_stoich
