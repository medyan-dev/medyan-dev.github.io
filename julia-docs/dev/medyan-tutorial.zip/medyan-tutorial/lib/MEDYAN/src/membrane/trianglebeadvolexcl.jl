using LinearAlgebra
using Setfield
using StaticArrays

"""
    $(TYPEDSIGNATURES)
Given 3D coordinates of a triangle and a point `x0`, compute the volume exclusion energy between them given by the following formula:
    E = ∫_{p ∈ triangle} (1 / |x0 - xp|^4) dp

Returns a tuple of (energy value, derivatives on triangle coordinates, derivatives on point coordinates).

# Arguments
- `coplanartol`: if the ratio between (squared distance from `x0` to the triangle) and (twice the triangle area) is smaller than this tolerance, the point is considered to be coplanar with the triangle.
- `colineartol`: in coplanar case, if the ratio between (distance from `x0` to an edge) and (the longer distance between `x0` and two ends of the edge) is smaller than this tolerance, the point is considered to be colinear with the edge.
- 'cutoff': if the nearest point between triangle and the bead gets greater than this value, the energy and forces are zeros.
"""
function triangle_bead_volexcl(xs, x0; coplanartol=1e-8, colineartol=3e-6, cutoff=Inf)
    FT = Float64
    ST = SVector{3, FT}
    gs = SVector(zero(ST), zero(ST), zero(ST))
    g0 = zero(ST)

    rs = (xs[3] - xs[2], xs[1] - xs[3], xs[2] - xs[1])
    r0s = (x0 - xs[1], x0 - xs[2], x0 - xs[3])
    l2s = map(r->dot(r,r), rs)
    ϵs = @SVector [
        begin
            i1 = mod1(i+1,3)
            l2s[i] * dot(rs[i1], r0s[i1]) - dot(rs[i], r0s[i1]) * dot(rs[i], rs[i1])
        end for i ∈ 1:3
    ]

    cp = cross(rs[1], rs[2])
    Ac2 = dot(cp, cp)
    Ac = sqrt(Ac2)
    Vc = dot(cp, r0s[1])
    h = Vc / Ac

    outcoplanar::Bool = h*h < Ac * coplanartol && (ϵs[1] < 0 || ϵs[2] < 0 || ϵs[3] < 0)

    closest_dist2 = if ϵs[1] >= 0 && ϵs[2] >= 0 && ϵs[3] >= 0
        h*h
    else
        let
            local dot_20_23 = dot(r0s[2], rs[1])
            local dot_30_31 = dot(r0s[3], rs[2])
            local dot_10_12 = dot(r0s[1], rs[3])
            if ϵs[1] < 0 && dot_20_23 >= 0 && dot_20_23 <= l2s[1]
                # Edge 23.
                sum(abs2, cross(r0s[2], rs[1])) / l2s[1]
            elseif ϵs[2] < 0 && dot_30_31 >= 0 && dot_30_31 <= l2s[2]
                # Edge 31.
                sum(abs2, cross(r0s[3], rs[2])) / l2s[2]
            elseif ϵs[3] < 0 && dot_10_12 >= 0 && dot_10_12 <= l2s[3]
                # Edge 12.
                sum(abs2, cross(r0s[1], rs[3])) / l2s[3]
            elseif dot_10_12 < 0 && dot_30_31 > l2s[2]
                # Vertex 1.
                dot(r0s[1], r0s[1])
            elseif dot_20_23 < 0 && dot_10_12 > l2s[3]
                # Vertex 2.
                dot(r0s[2], r0s[2])
            elseif dot_30_31 < 0 && dot_20_23 > l2s[1]
                # Vertex 3.
                dot(r0s[3], r0s[3])
            else
                error("Incorrect point projection: xs=$xs, x0=$x0")
            end
        end
    end

    energy::FT = 0
    if closest_dist2 < cutoff*cutoff

        for i ∈ 1:3
            i1 = mod1(i+1,3)
            i2 = mod1(i+2,3)
            local ζ1 = dot(r0s[i1], rs[i])
            local ζ2 = l2s[i] - ζ1

            local cpi = cross(rs[i], r0s[i1])
            local srδ = norm_fast(cpi)

            # Used in ϵ and its derivatives.
            local dot_ri1_r0i1 = dot(rs[i1], r0s[i1])
            local dot_ri_r0i1 = dot(rs[i], r0s[i1])
            local dot_ri_ri1 = dot(rs[i], rs[i1])
            local ∂0_ϵ  = l2s[i] * rs[i1] - dot_ri_ri1 * rs[i]
            local ∂i_ϵ  = l2s[i] * r0s[i1] - dot_ri_r0i1 * rs[i]
            local ∂i1_ϵ = (-2 * dot_ri1_r0i1 + dot_ri_ri1) * rs[i] + dot_ri_ri1 * r0s[i1] + (-l2s[i] + dot_ri_r0i1) * rs[i1]
            local ∂i2_ϵ = (2 * dot_ri1_r0i1 + dot_ri_r0i1) * rs[i] + (-l2s[i] - dot_ri_ri1) * r0s[i1] - dot_ri_r0i1 * rs[i1]

            local eachenergy = if outcoplanar
                # Set fixed srδ.
                local hvec = cp * (h/Ac)
                srδ = norm_fast(cross(rs[i], r0s[i1] - hvec))

                local outcolinear::Bool = ζ1 * ζ2 < 0 && srδ < colineartol * max(abs(ζ1), abs(ζ2))
                if outcolinear
                    local r4 = l2s[i]^2
                    local ζ13 = ζ1^3
                    local ζ23 = ζ2^3
                    local e = (r4 * (r4 - 3*ζ1*ζ2) * ϵs[i]) / (6 * ζ13 * ζ23 * Ac)

                    local ∂ζ1_e = (6*ζ13*ζ23*Ac*r4*ϵs[i] * (-3*ζ2) - r4*(r4-3*ζ1*ζ2)*ϵs[i] * 18*ζ1*ζ1*ζ23*Ac) / (6*ζ13*ζ23*Ac)^2
                    local ∂ζ2_e = (6*ζ13*ζ23*Ac*r4*ϵs[i] * (-3*ζ1) - r4*(r4-3*ζ1*ζ2)*ϵs[i] * 18*ζ2*ζ2*ζ13*Ac) / (6*ζ13*ζ23*Ac)^2
                    local ∂ϵ_e = (r4 * (r4 - 3*ζ1*ζ2)) / (6 * ζ13 * ζ23 * Ac)
                    local ∂Ac_e = -e/Ac
                    local ∂r4_e = ((2*r4 - 3*ζ1*ζ2) * ϵs[i]) / (6 * ζ13 * ζ23 * Ac)

                    # r4
                    gs = @set gs[i1] += ∂r4_e * (-4) * l2s[i] * rs[i]
                    gs = @set gs[i2] += ∂r4_e * 4 * l2s[i] * rs[i]

                    e
                else
                    local ∂2δ = 2 * l2s[i]
                    local inv_srδ = 1 / srδ
                    local atan1 = atan(ζ1 * inv_srδ)
                    local atan2 = atan(ζ2 * inv_srδ)
                    local deri1 = inv_srδ / (1+ ζ1*ζ1 * inv_srδ*inv_srδ)
                    local deri2 = inv_srδ / (1+ ζ2*ζ2 * inv_srδ*inv_srδ)
                    local mult = ϵs[i] * ∂2δ / (8*Ac * srδ^3)
                    local beef = -(atan1 + atan2) - (deri1 * ζ1 + deri2 * ζ2)
                    local e = mult * beef

                    local ∂ζ1_e = mult * (-deri1 - inv_srδ * (1 - ζ1*ζ1*inv_srδ*inv_srδ) / (1 + ζ1*ζ1*inv_srδ*inv_srδ)^2)
                    local ∂ζ2_e = mult * (-deri2 - inv_srδ * (1 - ζ2*ζ2*inv_srδ*inv_srδ) / (1 + ζ2*ζ2*inv_srδ*inv_srδ)^2)
                    local ∂ϵ_e = (∂2δ / (8*Ac * srδ^3)) * beef
                    local ∂∂2δ_e = (ϵs[i] / (8*Ac * srδ^3)) * beef
                    local ∂Ac_e = -(ϵs[i] * ∂2δ / (8*Ac*Ac * srδ^3)) * beef
                    local ∂srδ_e = -(3 * ϵs[i] * ∂2δ / (8*Ac * srδ^4)) * beef + mult * (
                        ζ1 / (srδ*srδ + ζ1*ζ1) + ζ2 / (srδ*srδ + ζ2*ζ2)
                        -ζ1 * (ζ1*ζ1 - srδ*srδ) / (srδ*srδ + ζ1*ζ1)^2
                        -ζ2 * (ζ2*ζ2 - srδ*srδ) / (srδ*srδ + ζ2*ζ2)^2
                    )

                    # ∂2δ
                    gs = @set gs[i1] += -∂∂2δ_e * 4 * rs[i]
                    gs = @set gs[i2] += ∂∂2δ_e * 4 * rs[i]
                    # srδ. Use normal srδ but remove perpendicular component.
                    local ∂0_srδ_raw = cross(cpi, rs[i]) / srδ
                    local ∂i1_srδ_raw = cross(cpi, r0s[i2]) / srδ
                    local ∂i2_srδ_raw = cross(cpi, -r0s[i1]) / srδ
                    g0 += ∂srδ_e * (∂0_srδ_raw - (dot(∂0_srδ_raw, cp) / (Ac*Ac)) * cp)
                    gs = @set gs[i1] += ∂srδ_e * (∂i1_srδ_raw - (dot(∂i1_srδ_raw, cp) / (Ac*Ac)) * cp)
                    gs = @set gs[i2] += ∂srδ_e * (∂i2_srδ_raw - (dot(∂i2_srδ_raw, cp) / (Ac*Ac)) * cp)

                    e
                end
            else
                # Reference:   cosϕ = ϵs[i] / (Ac * srδ).
                local mult = ϵs[i] * Ac / (2 * Vc * Vc * srδ)
                local inv_srδ = 1 / srδ
                local atan1 = atan(ζ1 * inv_srδ)
                local atan2 = atan(ζ2 * inv_srδ)
                local e = mult * (atan1 + atan2)

                local ∂ζ1_e = mult * (inv_srδ / (1 + ζ1*ζ1 * inv_srδ*inv_srδ))
                local ∂ζ2_e = mult * (inv_srδ / (1 + ζ2*ζ2 * inv_srδ*inv_srδ))
                local ∂ϵ_e = Ac / (2 * Vc * Vc * srδ) * (atan1 + atan2)
                local ∂Ac_e = ϵs[i] / (2 * Vc * Vc * srδ) * (atan1 + atan2)
                local ∂Vc_e = -ϵs[i] * Ac / (Vc * Vc * Vc * srδ) * (atan1 + atan2)
                local ∂srδ_e = -ϵs[i] * Ac / (2 * Vc * Vc * srδ) * (
                    inv_srδ * (atan1 + atan2) + ζ1 / (ζ1*ζ1 + srδ*srδ) + ζ2 / (ζ2*ζ2 + srδ*srδ)
                )

                # Vc
                g0 += ∂Vc_e * cp
                gs = @set gs[i] += ∂Vc_e * cross(r0s[i2], r0s[i1])
                gs = @set gs[i1] += ∂Vc_e * cross(r0s[i], r0s[i2])
                gs = @set gs[i2] += ∂Vc_e * cross(r0s[i1], r0s[i])
                # srδ
                g0 += ∂srδ_e / srδ * cross(cpi, rs[i])
                gs = @set gs[i1] += ∂srδ_e / srδ * cross(cpi, r0s[i2])
                gs = @set gs[i2] += ∂srδ_e / srδ * cross(cpi, -r0s[i1])

                e
            end

            # ζ1
            g0 += ∂ζ1_e * rs[i]
            gs = @set gs[i2] += ∂ζ1_e * r0s[i1]
            gs = @set gs[i1] += -∂ζ1_e * (r0s[i1] + rs[i])
            # ζ2
            g0 += -∂ζ2_e * rs[i]
            gs = @set gs[i1] += ∂ζ2_e * r0s[i2]
            gs = @set gs[i2] += ∂ζ2_e * (-r0s[i2] + rs[i])
            # ϵ
            g0     += ∂ϵ_e * ∂0_ϵ
            gs = @set gs[i]  += ∂ϵ_e * ∂i_ϵ
            gs = @set gs[i1] += ∂ϵ_e * ∂i1_ϵ
            gs = @set gs[i2] += ∂ϵ_e * ∂i2_ϵ
            # Ac
            gs = @set gs[i] += ∂Ac_e / Ac * cross(cp, rs[i])
            gs = @set gs[i1] += ∂Ac_e / Ac * cross(cp, rs[i1])
            gs = @set gs[i2] += ∂Ac_e / Ac * cross(cp, rs[i2])

            energy += eachenergy
        end
    end

    (; energy, gs, g0)
end


"""
    $(TYPEDSIGNATURES)
Triangle-bead volume exclusion given the coordinate array and indices of x coordinates in the array.
Forces and energy will be added to `force_energy`.
"""
function triangle_bead_volexcl!(kvol, ixtriangle, ixbead, x::AbstractVector, force_energy::ForceEnergy; coplanartol=1e-8, colineartol=3e-6, cutoff=Inf)
    getsvec(v, ix) = SVector{3}(view(v, ix:ix+2))
    xs = map(ix->getsvec(x, ix), ixtriangle)
    x0 = getsvec(x, ixbead)

    (energy, gs, g0) = triangle_bead_volexcl(xs, x0; coplanartol, colineartol, cutoff)
    for ti ∈ 1:3
        local ix = ixtriangle[ti]
        local g = gs[ti]
        for dim ∈ 1:3
            add_dof_force!(force_energy, ix-1+dim, -kvol * g[dim])
        end
    end
    for dim ∈ 1:3
        add_dof_force!(force_energy, ixbead-1+dim, -kvol * g0[dim])
    end

    add_energy!(force_energy, kvol * energy)
end
