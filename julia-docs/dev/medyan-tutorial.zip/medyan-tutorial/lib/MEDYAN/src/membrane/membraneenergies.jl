"""
Computes membrane mechanical energies using latest geometry values.
Add to the forces and energy in `force_energy`.

Requires latest geometry.

Some arguments:
- bending_mode:
    - Val(:normal) for normal mode.
    - Val(:bashkirov) for protein curvature energy as described in "Molecular shape solution for mesoscopic remodeling of cellular membranes" by PV Bashkirov et al (2022) Annual Review of biophysics. Notice the scale parameter is increased from 1/2 to 2 to match MEDYAN conventions.
        ```
                       1 - ∑ϕ_p              ϕ_p
        E_bend =  2 ( ---------- + ∑ ------------------ )^(-1)  (H - ∑ H_s ϕ_p - H_0 (1-∑ϕ_p))^2
                        k_lipid       k_lipid + k_prot
        ```
        where
        ```    
                           k_prot
        H_s = H_prot ------------------
                      k_lipid + k_prot
        ```
"""
function membrane_energies!(
        params,
        params_species,
        sm::StaticHalfedgeMesh,
        x,
        force_energy::ForceEnergy;
        bending_mode::Val{BendingMode} = Val(:normal),
        meshcurv::Val{MeshCurv} = Val(meshcurv_mem3dg),
    ) where {BendingMode, MeshCurv}

    e_bending = 0.0
    if BendingMode == :normal
        for i ∈ 1:length(sm.vertices)
            # Bending.
            if !onborder(sm, IV(i))
                dist = sm.vertices.attr.curv[i] - params.eqcurv
                area = sm.vertices.attr.astar[i] / 3
                e_bending += 2 * params.kbend * dist * dist * area

                deg = degree(sm, IV(i))
                coeff1 = -4 * params.kbend * dist * area
                coeff2 = -2 * params.kbend * dist * dist
                let
                    local xi = sm.vertices.attr.cached_xcoordindex[i]
                    local g_curv = sm.vertices.attr.g_curv[i]
                    local g_area = sm.vertices.attr.g_astar[i] / 3
                    local theforce = coeff1 * g_curv + coeff2 * g_area
                    add_dof_force!(force_energy, xi+0, theforce[1])
                    add_dof_force!(force_energy, xi+1, theforce[2])
                    add_dof_force!(force_energy, xi+2, theforce[3])
                end
                for in ∈ 1:deg
                    local h_o = get_leaving_halfedge(sm, in, i)
                    local vni = get_neighbor_vertex(sm, in, i)
                    local xni = sm.vertices.attr.cached_xcoordindex[vni]
                    local g_curv = sm.halfedges.attr.g_ontarget_sourcecurv[h_o]
                    local g_area = sm.halfedges.attr.g_ontarget_sourceastar[h_o] / 3
                    local theforce = coeff1 * g_curv + coeff2 * g_area
                    add_dof_force!(force_energy, xni+0, theforce[1])
                    add_dof_force!(force_energy, xni+1, theforce[2])
                    add_dof_force!(force_energy, xni+2, theforce[3])
                end
            end
        end
    elseif BendingMode == :bashkirov
        e_bending += membrane_energies!_bending_bashkirov(params, params_species, sm, x, force_energy)
    else
        error("Unrecognized bending mode: $BendingMode")
    end


    # Area.
    totarea = sum(sm.vertices.attr.astar) / 3

    # Volume.
    totvolume = params.offsetvolume
    for i ∈ 1:length(sm.triangles)
        totvolume += sm.triangles.attr.cone_volume[i]
    end

    # Area stretching / tension / volume conservation.
    local diffarea = totarea - params.eqarea
    local diffvolume = totvolume - params.eqvolume
    e_area = (params.karea / 2) * diffarea * diffarea / params.eqarea
    e_tension = params.tension * totarea
    e_volume = (params.kvolume / 2) * diffvolume * diffvolume / params.eqvolume
    # Some multipliers on vertex gradients.
    g_mult_astar = params.karea * diffarea / params.eqarea + params.tension
    g_mult_volume = params.kvolume * diffvolume / params.eqvolume
    for i ∈ 1:length(sm.vertices)
        local xi = sm.vertices.attr.cached_xcoordindex[i]
        local g_astar = sm.vertices.attr.g_astar[i]
        local g_volume = sm.vertices.attr.g_volume[i]
        local theg = g_mult_astar * g_astar + g_mult_volume * g_volume
        add_dof_force!(force_energy, xi+0, -theg[1])
        add_dof_force!(force_energy, xi+1, -theg[2])
        add_dof_force!(force_energy, xi+2, -theg[3])
    end

    # Vertex pinning.
    e_pinning::Float64 = 0
    for vindex ∈ eachindex(sm.vertices)
        if sm.vertices.attr.pinned[vindex]
            local xi = sm.vertices.attr.cached_xcoordindex[vindex]
            local c = x[SA[xi, xi+1, xi+2]]
            local Δc = c - sm.vertices.attr.pinned_coord[vindex]
            e_pinning += (params.kpinning / 2) * dot(Δc, Δc)
            add_dof_force!(force_energy, xi+0, -params.kpinning * Δc[1])
            add_dof_force!(force_energy, xi+1, -params.kpinning * Δc[2])
            add_dof_force!(force_energy, xi+2, -params.kpinning * Δc[3])
        end
    end

    # Edge length protection, only used in mem3dg mode.
    e_edgelengthprotect::Float64 = 0
    if MeshCurv == meshcurv_mem3dg && params.edgelength_mem3dg_k > 0
        inv_minlen = 1 / params.edgelength_mem3dg_min
        inv_minlen2 = inv_minlen * inv_minlen
        for eindex ∈ eachindex(sm.edges)
            if !onborder(sm, IE(eindex))
                x2, x1 = sm.edges.attr.cached_xcoordindices[eindex] # x2 is the target of halfedge.
                c1 = x[SA[x1, x1+1, x1+2]]
                c2 = x[SA[x2, x2+1, x2+2]]

                r21 = c1 - c2
                len2 = dot(r21, r21)
                rel2 = len2 * inv_minlen2
                if rel2 < 1
                    rel = sqrt(rel2)
                    invlen = inv_minlen / rel
                    diff = rel - 1
                    e_edgelengthprotect += -0.5 * params.edgelength_mem3dg_k * log(1 - diff * diff)
                    local fac = params.edgelength_mem3dg_k * invlen * inv_minlen * diff / (1 - diff * diff)
                    add_dof_force!(force_energy, x1+0, -fac * r21[1])
                    add_dof_force!(force_energy, x1+1, -fac * r21[2])
                    add_dof_force!(force_energy, x1+2, -fac * r21[3])
                    add_dof_force!(force_energy, x2+0, +fac * r21[1])
                    add_dof_force!(force_energy, x2+1, +fac * r21[2])
                    add_dof_force!(force_energy, x2+2, +fac * r21[3])
                end
            end
        end
    end

    add_energy!(force_energy,
        +(
            e_bending,
            e_area,
            e_tension,
            e_volume,
            e_pinning,
            e_edgelengthprotect
        )
    )

    nothing
end


"""
The membrane protein energy consists of two parts:
1. the potential energy of one protein as a result of membrane shape and other proteins. This is used to update reaction rates.
2. the total free energy of proteins in a cell. This is used in energy minimization.

If a cell already has N particles, and adding additional one requires V1(N) energy, then the total potential energy with M particles is V(M) = V1(0) + V1(1) + ... + V1(M-1).
Equivalently, V1(N) = V(N+1) - V(N).
The potential energy part in the total free energy must respect this relationship.

The functions should have the following signatures.
1. (membrane, vertex_index, species_index) -> potential_energy
2. (vectorize_result, membrane_index, x, forces) -> free_energy. Modifying forces.

Notes:
- MEDYAN calls the potential energy functions during chemistry, so the function can utilize local geometry values if they are updated right before chemistry.
- MEDYAN calls the free energy function during energy minimization, after calculating local geometry values, so the function can utilize them.
"""
function default_membranespeciespotentialenergy(m::DynamicHalfedgeMesh, v::IV, speciesindex::Integer)
    0.0
end


"""
Consider attractive pairwise interactions depending only on distance μ(|x_1 - x_2|). Repulsive core is not considered in this function.
- μ0 = ∫ μ(|x|) dV
- μ2 = (1/2d) ∫ μ(|x|) |x|^2 dV  where `d` is the dimension of the system (2).
"""
Base.@kwdef struct MembraneSpeciesPairwiseInteractionParams
    μ0::Float64
    μ2::Float64
end

"""
`params` are indexed by species index.
"""
struct MembraneSpeciesPotentialEnergy_PairwiseInteraction{ParamsType}
    params::ParamsType
end

function (inter::MembraneSpeciesPotentialEnergy_PairwiseInteraction)(m::DynamicHalfedgeMesh, v::IV, speciesindex::Integer)
    param = inter.params[speciesindex]
    copynumbers = getproperty(m.vertices.attr.copynumbers, speciesindex)
    copynumber = copynumbers[v.value]
    astar = m.vertices.attr.astar[v.value]
    n = 3 * copynumber / astar
    Δn::Float64 = 0
    for h ∈ HalfedgesTargetingVertex(m, v)
        ho = oppo(m, h)
        vn = target(m, ho)

        local sumcotθ::Float64 = 0
        if !onborder(m, h)
            hn = next(m, h)
            sumcotθ += m.halfedges.attr.cotθ[hn.value]
        end
        if !onborder(m, ho)
            hon = next(m, ho)
            sumcotθ += m.halfedges.attr.cotθ[hon.value]
        end

        copynumber_n = copynumbers[vn.value]
        astar_n = m.vertices.attr.astar[vn.value]
        nn = 3 * copynumber_n / astar_n
        # Mind the sign of Laplacian. Using Δf := div grad f.
        Δn += sumcotθ * (nn - n)
    end
    Δn *= 3 / (2 * astar)

    n * param.μ0 + Δn * param.μ2
end

"""
`params` are indexed by species index.
"""
struct MembraneSpeciesFreeEnergy!_PairwiseInteraction{ParamsType}
    params::ParamsType
end

function (inter!::MembraneSpeciesFreeEnergy!_PairwiseInteraction)(vectorize_result, mindex::Integer, x::AbstractVector, f::AbstractVector)

    "Auxiliary function to get an SVector from the coordinate array `c`, from index of x coordinate."
    function getc3(xcoordindex::Int)
        x[SVector{3}(xcoordindex:xcoordindex+2)]
    end

    (; smeshes,) = vectorize_result
    sm = smeshes[mindex]

    energy0::Float64 = 0
    energy2::Float64 = 0

    for vindex ∈ eachindex(sm.vertices)
        astar = sm.vertices.attr.astar[vindex]
        inv_astar = 1 / astar
        deg = degree(sm, IV(vindex))
        xi = sm.vertices.attr.cached_xcoordindex[vindex]
        g_astar = sm.vertices.attr.g_astar[vindex]

        for speciesindex ∈ eachindex(inter!.params)
            # E = (1/2) μ0 N^2 / A
            param = inter!.params[speciesindex]
            copynumber = getproperty(sm.vertices.attr.copynumbers, speciesindex)[vindex]

            # Intermediate variables.
            mid1 = 3 * param.μ0 * copynumber * copynumber / 2 * inv_astar
            mid2 = mid1 * inv_astar 
            energy0 += mid1

            # Forces.
            let
                local theforce = mid2 * g_astar
                f[xi] += theforce[1]
                f[xi+1] += theforce[2]
                f[xi+2] += theforce[3]
            end
            for in ∈ 1:deg
                local ho = get_leaving_halfedge(sm, in, vindex)
                local vni = get_neighbor_vertex(sm, in, vindex)
                local xni = sm.vertices.attr.cached_xcoordindex[vni]
                local gn_astar = sm.halfedges.attr.g_ontarget_sourceastar[ho]
                local theforce = mid2 * gn_astar
                f[xni] += theforce[1]
                f[xni+1] += theforce[2]
                f[xni+2] += theforce[3]
            end
        end
    end

    for tindex ∈ eachindex(sm.triangles)
        xis = sm.triangles.attr.cached_xcoordindices[tindex]
        cs = getc3.(xis)
        us = SA[
            cs[2] - cs[3],
            cs[3] - cs[1],
            cs[1] - cs[2],
        ]

        area = sm.triangles.attr.area[tindex]
        inv_area = inv(area)

        vindices = sm.triangles.conn[tindex].vertex_indices
        astars = sm.vertices.attr.astar[vindices]
        inv_astars = 1 ./ astars

        hindices = sm.triangles.conn[tindex].halfedge_indices
        g_areas = sm.halfedges.attr.g_triangle_area[hindices]


        for speciesindex ∈ eachindex(inter!.params)
            param = inter!.params[speciesindex]
            copynumbers = getproperty(sm.vertices.attr.copynumbers, speciesindex)[vindices]
            ns = 3 .* copynumbers .* inv_astars
            dns = SA[
                ns[2] - ns[3],
                ns[3] - ns[1],
                ns[1] - ns[2],
            ]

            # Intermediate variable.
            mid1 = ns[1] * us[1] + ns[2] * us[2] + ns[3] * us[3]
            mid2 = dot(mid1, mid1)
            mid3 = -param.μ2 * inv_area * mid2 / 8
            energy2 += mid3

            # Triangle area part.
            for tvi ∈ 1:3
                local theforce = (mid3 * inv_area) * g_areas[tvi]
                local xi = xis[tvi]
                f[xi] += theforce[1]
                f[xi+1] += theforce[2]
                f[xi+2] += theforce[3]
            end
            # Area of concentration part.
            for tvi ∈ 1:3
                local vindex = vindices[tvi]
                local ∂ni_mid2 = 2 * dot(mid1, us[tvi])
                local deg = degree(sm, IV(vindex))

                local forcefac_gastar = -param.μ2 * 3 / 8 * ∂ni_mid2 * inv_area * copynumbers[tvi] * inv_astars[tvi] * inv_astars[tvi]
                let
                    local theforce = forcefac_gastar * sm.vertices.attr.g_astar[vindex]
                    local xi = xis[tvi]
                    f[xi] += theforce[1]
                    f[xi+1] += theforce[2]
                    f[xi+2] += theforce[3]
                end
                for in ∈ 1:deg
                    local ho = get_leaving_halfedge(sm, in, vindex)
                    local vni = get_neighbor_vertex(sm, in, vindex)
                    local xni = sm.vertices.attr.cached_xcoordindex[vni]
                    local gn_astar = sm.halfedges.attr.g_ontarget_sourceastar[ho]
                    local theforce = forcefac_gastar * gn_astar
                    f[xni] += theforce[1]
                    f[xni+1] += theforce[2]
                    f[xni+2] += theforce[3]
                end
            end
            # Direct coordinate (us) part.
            for tvi ∈ 1:3
                local theforce = (-param.μ2 / 4 * inv_area * dns[tvi]) * mid1
                local xi = xis[tvi]
                f[xi] += theforce[1]
                f[xi+1] += theforce[2]
                f[xi+2] += theforce[3]
            end
        end
    end

    energy0 + energy2
end


"""
The parameters specified here must take the same values as in the actual context.
"""
Base.@kwdef struct MembraneSpeciesPotentialEnergy_BendingBashkirov{MemMechParams,NumMemSpecies,MemSpeciesParams}
    "A list of membrane mechanical parameters, indexed by membrane type."
    params_mech::MemMechParams
    "A list of membrane diffusing species parameters, indexed by species type."
    params_species::SVector{NumMemSpecies, MemSpeciesParams}
end

function (inter::MembraneSpeciesPotentialEnergy_BendingBashkirov)(m::DynamicHalfedgeMesh, v::IV, speciesindex::Integer)::Float64
    # Adding a new molecule changes the equilibrium curvature, as well as other stuff.
    (; params_mech, params_species) = inter
    params = params_mech[m.metaattr.membranetype]

    if params.kbend == 0
        return 0.0
    end
    if onborder(m, v)
        return 0.0
    end

    # Equilibrium curvatures for various protein-lipid mixtures.
    eqcurvs = map(params_species) do each_sp
        each_sp.eqcurv * (each_sp.kbend / (each_sp.kbend + params.kbend))
    end

    each_sp_areas = map(x->x.area, params_species)
    each_sp_kbends = map(x->x.kbend, params_species)

    area = m.vertices.attr.astar[v.value] / 3
    invarea = inv(area)
    copynumbers = map(enumerate_static(params_species)) do (each_speciesindex, each_sp)
        getproperty(m.vertices.attr.copynumbers, each_speciesindex)[v.value]
    end
    copynumbers_new = setindex(copynumbers, copynumbers[speciesindex]+1, speciesindex)
    ϕs = min.(each_sp_areas .* copynumbers .* invarea, 1.0)
    ϕs_new = min.(each_sp_areas .* copynumbers_new .* invarea, 1.0)
    sumϕ = min(sum(ϕs), 1)
    sumϕ_new = min(sum(ϕs_new), 1)

    invkeff = (1-sumϕ) / params.kbend + sum(ϕs ./ (params.kbend .+ each_sp_kbends))
    invkeff_new = (1-sumϕ_new) / params.kbend + sum(ϕs_new ./ (params.kbend .+ each_sp_kbends))

    eqcurv = (1-sumϕ) * params.eqcurv + sum(eqcurvs .* ϕs)
    eqcurv_new = (1-sumϕ_new) * params.eqcurv + sum(eqcurvs .* ϕs_new)
    dist = m.vertices.attr.curv[v.value] - eqcurv
    dist_new = m.vertices.attr.curv[v.value] - eqcurv_new

    e = 2 / invkeff * dist * dist * area
    e_new = 2 / invkeff_new * dist_new * dist_new * area

    return e_new - e
end

function membrane_energies!_bending_bashkirov(
        params,
        params_species::SVector,
        sm::StaticHalfedgeMesh,
        x,
        force_energy::ForceEnergy,
    )::Float64

    if params.kbend == 0
        return 0.0
    end

    # Find H_s where the protein exists.
    eqcurvs = map(params_species) do each_sp
        each_sp.eqcurv * (each_sp.kbend / (each_sp.kbend + params.kbend))
    end
    each_sp_areas = map(x->x.area, params_species)
    each_sp_kbends = map(x->x.kbend, params_species)

    e_bending = 0.0
    for i ∈ 1:length(sm.vertices)
        if !onborder(sm, IV(i))
            area = sm.vertices.attr.astar[i] / 3
            invarea = inv(area)
            copynumbers = map(enumerate_static(params_species)) do (each_speciesindex, each_sp)
                getproperty(sm.vertices.attr.copynumbers, each_speciesindex)[i]
            end
            ϕs_unmin = each_sp_areas .* copynumbers .* invarea
            ∂area_ϕs = ifelse.(ϕs_unmin .≤ 1, -ϕs_unmin .* invarea, 0.0)
            ϕs = min.(ϕs_unmin, 1.0)
            sumϕ::Float64 = sum(ϕs)
            ∂area_sumϕ::Float64 = sumϕ ≤ 1 ? sum(∂area_ϕs) : 0.0
            sumϕ = min(sumϕ, 1)

            invkeff = (1-sumϕ) / params.kbend + sum(ϕs ./ (params.kbend .+ each_sp_kbends))
            ∂area_invkeff = -∂area_sumϕ / params.kbend + sum(∂area_ϕs ./ (params.kbend .+ each_sp_kbends))
            keff = inv(invkeff)
            ∂area_keff = -keff * keff * ∂area_invkeff

            eqcurv = (1-sumϕ) * params.eqcurv + sum(eqcurvs .* ϕs)
            ∂area_eqcurv = -∂area_sumϕ * params.eqcurv + sum(eqcurvs .* ∂area_ϕs)

            dist = sm.vertices.attr.curv[i] - eqcurv
            e_bending += 2 * keff * dist * dist * area
            ∂area_e = 2 * (
                ∂area_keff * dist * dist * area +
                keff * 2 * dist * (-∂area_eqcurv) * area +
                keff * dist * dist
            )
            ∂curv_e = 4 * keff * dist * area

            deg = degree(sm, IV(i))
            let
                local xi = sm.vertices.attr.cached_xcoordindex[i]
                local g_curv = sm.vertices.attr.g_curv[i]
                local g_area = sm.vertices.attr.g_astar[i] / 3
                local theforce = -∂curv_e * g_curv - ∂area_e * g_area
                add_dof_force!(force_energy, xi+0, theforce[1])
                add_dof_force!(force_energy, xi+1, theforce[2])
                add_dof_force!(force_energy, xi+2, theforce[3])
            end
            for in ∈ 1:deg
                local h_o = get_leaving_halfedge(sm, in, i)
                local vni = get_neighbor_vertex(sm, in, i)
                local xni = sm.vertices.attr.cached_xcoordindex[vni]
                local g_curv = sm.halfedges.attr.g_ontarget_sourcecurv[h_o]
                local g_area = sm.halfedges.attr.g_ontarget_sourceastar[h_o] / 3
                local theforce = -∂curv_e * g_curv - ∂area_e * g_area
                add_dof_force!(force_energy, xni+0, theforce[1])
                add_dof_force!(force_energy, xni+1, theforce[2])
                add_dof_force!(force_energy, xni+2, theforce[3])
            end
        end
    end

    e_bending
end
