using LinearAlgebra
using Setfield


Base.@kwdef struct MeshAdaptParams
    #-----------------------------------
    # Connectivity.
    #-----------------------------------
    min_degree       ::Int = 4
    max_degree       ::Int = 9
    # If cos(angle_normal) is too small, the edge will not be flipped.
    edge_flip_min_dot_normal              ::Float64 = 0.9
    edge_collapse_min_quality_improvement ::Float64 = 0.6
    edge_collapse_min_dot_normal          ::Float64 = 0.85

    #-----------------------------------
    # Relaxation.
    #-----------------------------------
    relaxation_max_iter_reloc    ::Int = 10
    # 1 iteration includes vertex relocation with edge flipping.
    relaxation_max_iter_total    ::Int = 3

    #-----------------------------------
    # Size diffusion.
    #-----------------------------------
    # (max size of edge) = resolution * (radius of curvature)
    # cos(resolution) should be bigger than `edge_flip_min_dot_normal`.`
    curvature_resolution   ::Float64 = 0.3
    max_size               ::Float64 = 60
    min_size               ::Float64 = 8
    diffuse_iter           ::Int     = 4

    #-----------------------------------
    # Mesh smoothing.
    #-----------------------------------
    do_meshsmoothing       ::Bool = false
    meshsmoothing_dt       ::Float64 = 0.01
    meshsmoothing_iter     ::Int = 5

    #-----------------------------------
    # Main loop
    #-----------------------------------
    # Max times of scanning all edges for adjustment.
    max_adjust_iter        ::Int = 10
    max_soft_mainloop_iter ::Int = 7
    max_hard_mainloop_iter ::Int = 14
end


struct TriangleQualityRadiusRatio
    value ::Float64
end

const trianglequality_radiusratio_best = TriangleQualityRadiusRatio(0.0)
const trianglequality_radiusratio_worst = TriangleQualityRadiusRatio(Inf64)

better(q1::TriangleQualityRadiusRatio, q2::TriangleQualityRadiusRatio) = q1.value < q2.value
thebetter(q1::TriangleQualityRadiusRatio, q2::TriangleQualityRadiusRatio) = better(q1, q2) ? q1 : q2
worse(q1::TriangleQualityRadiusRatio, q2::TriangleQualityRadiusRatio) = q1.value > q2.value
theworse(q1::TriangleQualityRadiusRatio, q2::TriangleQualityRadiusRatio) = worse(q1, q2) ? q1 : q2
improvement(q0::TriangleQualityRadiusRatio, q1::TriangleQualityRadiusRatio) = q0.value / q1.value

"""
Compute triangle quality using radius ratio method:

    quality = circumradius / (2 * inradius)   ∈ [1, +∞)
"""
function trianglequality_radiusratio_fromlengths(l1::Real, l2::Real, l3::Real)
    p = (l1 + l2 + l3) / 2
    # abs is used to avoid negative results, which may happen due to numerical errors.
    q = abs(l1 * l2 * l3 / (8 * (p-l1) * (p-l2) * (p-l3)))
    TriangleQualityRadiusRatio(q)
end

function trianglequality_radiusratio_fromcoords(p1::AbstractVector, p2::AbstractVector, p3::AbstractVector)
    trianglequality_radiusratio_fromlengths(norm_fast(p1-p2), norm_fast(p2-p3), norm_fast(p3-p1))
end

"""
Find appropriate coordinates to insert a vertex on an edge.

This function requires but does not check the up-to-date
- vertex coordinates
- vertex unit normal
"""
function edge_mid_vertex_coordinate(m::DynamicHalfedgeMesh, v1::IV, v2::IV)
    max_radius_distance_ratio = 1e6
    max_radius_distance_ratio2 = max_radius_distance_ratio * max_radius_distance_ratio

    c1 = m.vertices.attr.coord[v1.value]
    c2 = m.vertices.attr.coord[v2.value]
    un1 = m.vertices.attr.ada_unitnormal[v1.value]
    un2 = m.vertices.attr.ada_unitnormal[v2.value]

    r = c2 - c1
    rdotr = dot(r, r)

    # Compute radius of curvature for both vertices. positive: convex; negative: concave.
    r1 = -rdotr / (2 * dot(un1, r))
    r2 = rdotr / (2 * dot(un2, r))

    if abs(r1 * r1) > max_radius_distance_ratio2 * rdotr
        res1 = (c1 + c2) / 2
    else
        # Compute vector from center of sphere to midpoint.
        ro1 = r/2 + r1 * un1
        magro1 = norm_fast(ro1)
        if magro1 == 0
            error("Unit normal $un1 is parallel to edge.")
        end
        res1 = c1 - r1 * un1 + ro1*(abs(r1) / magro1)
    end

    if abs(r2 * r2) > max_radius_distance_ratio2 * rdotr
        res2 = (c1 + c2) / 2
    else
        ro2 = -r/2 + r2 * un2
        magro2 = norm_fast(ro2)
        if magro2 == 0
            error("Unit normal $un2 is parallel to edge.")
        end
        res2 = c2 - r2 * un2 + ro2*(abs(r2) / magro2)
    end

    (res1 + res2) / 2
end

"""
Try to insert a vertex on an edge.
`splitfunc!`: (mesh, edgeindex, newcoord) -> change_info
`flipfunc!`: (mesh, edgeindex) -> change_info
Returns the state of the operation. Only `:success` indicates that the edge was splitted.

This function requires but does not check the up-to-date
- vertex coordinates
- vertex unit normal
"""
function try_split_edge!(splitfunc!, flipfunc!, m::DynamicHalfedgeMesh, e::IE, p::MeshAdaptParams)::Symbol
    # Cannot insert on border edges.
    if onborder(m, e)
        return :border
    end

    h = halfedge(m, e)
    h_o = oppo(m, h)
    h_n = next(m, h)
    h_p = prev(m, h)
    h_on = next(m, h_o)
    h_op = prev(m, h_o)

    v1 = target(m, h)
    v2 = target(m, h_n)
    v3 = target(m, h_o)
    v4 = target(m, h_on)

    e1 = edge(m, h_n) # v1 <-> v2
    e2 = edge(m, h_p) # v2 <-> v3
    e3 = edge(m, h_on) # v3 <-> v4
    e4 = edge(m, h_op) # v4 <-> v1

    # A new vertex with degree 4 will always be introduced.
    if degree(m, v2) >= p.max_degree || degree(m, v4) >= p.max_degree
        return :invalid_degree
    end

    c1 = m.vertices.attr.coord[v1.value]
    c2 = m.vertices.attr.coord[v2.value]
    c3 = m.vertices.attr.coord[v3.value]
    c4 = m.vertices.attr.coord[v4.value]
    l2_0 = sum(abs2, c1 - c3)
    l2_1 = sum(abs2, c1 - c2)
    l2_2 = sum(abs2, c2 - c3)
    l2_3 = sum(abs2, c3 - c4)
    l2_4 = sum(abs2, c4 - c1)
    if l2_0 < max(l2_1, l2_2, l2_3, l2_4)
        return :not_longest_edge
    end

    eqlength = m.edges.attr.ada_eqlength[e.value]

    # All checks passed. Do the splitting and set the new coordinates.
    change = splitfunc!(m, e, edge_mid_vertex_coordinate(m, v1, v3))

    # Update local geometries.
    for nh ∈ HalfedgesTargetingVertex(m, change.vnew)
        nt = triangle(m, nh)
        ne = edge(m, nh)
        
        compute_triangle_normal_ada!(m, nt)
        for nnh ∈ HalfedgesInTriangle(m, nt)
            compute_angle_ada!(m, nnh)
        end
        # Set preferrable length of edges to be the same as before.
        m.edges.attr.ada_eqlength[ne.value] = eqlength
    end

    compute_vertex_normal_ada!(m, change.vnew)
    for nh ∈ HalfedgesTargetingVertex(m, change.vnew)
        compute_vertex_normal_ada!(m, nh |> oppo(m) |> target(m))
    end

    # Propose edge flipping on surrounding quad edges.
    try_flip_edge!(flipfunc!, m, e1, p)
    try_flip_edge!(flipfunc!, m, e2, p)
    try_flip_edge!(flipfunc!, m, e3, p)
    try_flip_edge!(flipfunc!, m, e4, p)

    :success
end


"""
Try to collapse an edge into one vertex.
`collapsefunc!`: (mesh, halfedgeindex, newcoord) -> change_info
Returns the state of the operation. Only `:success` indicates that the edge was collapsed.

This function requires but does not check the up-to-date
- vertex coordinates
- vertex unit normal
- triangle unit normal
"""
function try_collapse_edge!(collapsefunc!, m::DynamicHalfedgeMesh, e::IE, p::MeshAdaptParams)::Symbol
    # Cannot collapse on border edges.
    if onborder(m, e)
        return :border
    end

    h = halfedge(m, e)
    h_o = oppo(m, h)
    h_n = next(m, h)
    h_on = next(m, h_o)

    v1 = target(m, h)
    v2 = target(m, h_n)
    v3 = target(m, h_o)
    v4 = target(m, h_on)
    # Currently, the edge connects v1 and v3.
    # After collapse, v1 and v3 would become one point.

    # Whether a vertex is irremovable. Could be dependent on whether it is on border, has attachments, etc.
    irremovable(v::IV) = onborder(m, v) || m.vertices.attr.irremovable[v.value]
    ir1 = irremovable(v1)
    ir3 = irremovable(v3)

    if ir1 && ir3
        return :irremovable_vertices
    end

    newdegree = degree(m, v1) + degree(m, v3) - 4
    if newdegree > p.max_degree || (newdegree < p.min_degree && !onborder(m,v1) && !onborder(m,v3)) || (degree(m,v2) <= p.min_degree && !onborder(m,v2)) || (degree(m,v4) <= p.min_degree && !onborder(m,v4))
        return :invalid_degree
    end

    c1 = m.vertices.attr.coord[v1.value]
    c3 = m.vertices.attr.coord[v3.value]

    cnew = if ir1 
        c1
    elseif ir3
        c3
    else #non on boarder 
        edge_mid_vertex_coordinate(m, v1, v3)
    end
    

    # Prequalify the collapse, using triangle quality improvement and new dihedral angles.
    t1 = triangle(m, h)
    t2 = triangle(m, h_o)
    let
        qoldworst = trianglequality_radiusratio_best
        qnewworst = trianglequality_radiusratio_best
        for nh ∈ HalfedgesTargetingVertex(m, v1)
            if polygon(m, nh).type == pt_triangle
                # Triangle quality.
                t = triangle(m, nh)
                vn = nh |> next(m) |> target(m)
                vp = nh |> prev(m) |> target(m)
                cn = m.vertices.attr.coord[vn.value]
                cp = m.vertices.attr.coord[vp.value]
                q = trianglequality_radiusratio_fromcoords(cp, c1, cn)
                qoldworst = theworse(qoldworst, q)
                if t != t1 && t != t2
                    qnew = trianglequality_radiusratio_fromcoords(cp, cnew, cn)
                    qnewworst = theworse(qnewworst, qnew)
                end
            end
        end
        for nh ∈ HalfedgesTargetingVertex(m, v3)
            if polygon(m, nh).type == pt_triangle
                # Triangle quality.
                t = triangle(m, nh)
                if t != t1 && t != t2
                    vn = nh |> next(m) |> target(m)
                    vp = nh |> prev(m) |> target(m)
                    cn = m.vertices.attr.coord[vn.value]
                    cp = m.vertices.attr.coord[vp.value]
                    q = trianglequality_radiusratio_fromcoords(cp, c3, cn)
                    qoldworst = theworse(qoldworst, q)
                    qnew = trianglequality_radiusratio_fromcoords(cp, cnew, cn)
                    qnewworst = theworse(qnewworst, qnew)
                end
            end
        end

        if improvement(qoldworst, qnewworst) < p.edge_collapse_min_quality_improvement
            return :bad_quality
        end
    end

    let
        mindotnormal::Float64 = 1.0 # Coplanar case (best).
        lastunitnormal::Union{Nothing,SVector{3,Float64}} = nothing
        function upmindot(nh::IH)
            if polygon(m, nh).type == pt_triangle
                vn = nh |> next(m) |> target(m)
                vp = nh |> prev(m) |> target(m)
                cn = m.vertices.attr.coord[vn.value]
                cp = m.vertices.attr.coord[vp.value]
                un = normalize_fast(cross(cn - cnew, cp - cnew))
                if !isnothing(lastunitnormal)
                    mindotnormal = min(mindotnormal, dot(un, lastunitnormal))
                end
                let nnh = nh |> next(m) |> oppo(m)
                    if polygon(m, nnh).type == pt_triangle
                        nt = triangle(m, nnh)
                        mindotnormal = min(mindotnormal, dot(un, m.triangles.attr.unitnormal[nt.value]))
                    end
                end
                lastunitnormal = un
            else
                lastunitnormal = nothing
            end
        end

        upmindot(oppo(m, h_on))
        nh = h_o |> prev(m) |> oppo(m) |> prev(m)
        while nh != h
            upmindot(nh)
            nh = nh |> oppo(m) |> prev(m)
        end
        nh = h |> prev(m) |> oppo(m) |> prev(m)
        while nh != h_o
            upmindot(nh)
            nh = nh |> oppo(m) |> prev(m)
        end

        if mindotnormal < p.edge_collapse_min_dot_normal
            return :bad_dihedral
        end
    end

    # Do the collapse.
    change = collapsefunc!(m, ir1 ? h : h_o, cnew)

    # Update local geometries.
    for nh ∈ HalfedgesTargetingVertex(m, change.vto)
        if polygon(m, nh).type == pt_triangle
            nt = triangle(m, nh)
            compute_triangle_normal_ada!(m, nt)
            for nnh ∈ HalfedgesInTriangle(m, nt)
                compute_angle_ada!(m, nnh)
            end
        end
    end
    compute_vertex_normal_ada!(m, change.vto)
    for nh ∈ HalfedgesTargetingVertex(m, change.vto)
        nv = nh |> oppo(m) |> target(m)
        compute_vertex_normal_ada!(m, nv)
    end

    :success
end


"""
Try to flip the edge specified.
`flipfunc!`: (mesh, edgeindex) -> nothing
Returns the state of the operation. Only `:success` indicates that the edge was flipped.

This function requires but does not check the up-to-date
- vertex degrees
- vertex coordinates
- triangle unit normal
"""
function try_flip_edge!(flipfunc!, m::DynamicHalfedgeMesh, e::IE, p::MeshAdaptParams)::Symbol
    # Cannot flip border edges.
    if onborder(m, e)
        return :border
    end

    h = halfedge(m, e)
    h_o = oppo(m, h)
    h_n = next(m, h)
    h_on = next(m, h_o)

    v1 = target(m, h)
    v2 = target(m, h_n)
    v3 = target(m, h_o)
    v4 = target(m, h_on)
    # Currently the edge connects v1 and v3.
    # If the edge flips, the connection would be between v2 and v4.

    t1 = triangle(m, h)
    t2 = triangle(m, h_o)

    if (!onborder(m,v1) && degree(m, v1) <= p.min_degree) || (!onborder(m,v3) && degree(m, v3) <= p.min_degree) || degree(m, v2) >= p.max_degree || degree(m, v4) >= p.max_degree
        return :invalid_degree
    end

    n1 = m.triangles.attr.unitnormal[t1.value]
    n2 = m.triangles.attr.unitnormal[t2.value]
    if dot(n1, n2) < p.edge_flip_min_dot_normal
        return :non_coplanar
    end

    # Check if the target triangles are coplanar.
    c1 = m.vertices.attr.coord[v1.value]
    c2 = m.vertices.attr.coord[v2.value]
    c3 = m.vertices.attr.coord[v3.value]
    c4 = m.vertices.attr.coord[v4.value]
    normal124 = cross(c2 - c1, c4 - c1)
    normal124mag = norm_fast(normal124)
    normal342 = cross(c4 - c3, c2 - c3)
    normal342mag = norm_fast(normal342)
    # Degenerate case.
    if normal124mag == 0 || normal342mag == 0
        return :degenerate
    end
    if dot(normal124, normal342) < p.edge_flip_min_dot_normal * normal124mag * normal342mag
        return :non_coplanar
    end

    # Check whethe triangle quality can be improved.
    q123 = trianglequality_radiusratio_fromcoords(c1, c2, c3)
    q341 = trianglequality_radiusratio_fromcoords(c3, c4, c1)
    qbefore = theworse(q123, q341)
    q124 = trianglequality_radiusratio_fromcoords(c1, c2, c4)
    q342 = trianglequality_radiusratio_fromcoords(c3, c4, c2)
    qafter = theworse(q124, q342)
    if !better(qafter, qbefore)
        return :bad_quality
    end

    # Flip the edge.
    flipfunc!(m, e)

    # Set attributes.
    function updateattr(t::IT)
        compute_triangle_normal_ada!(m, t)
        for h ∈ HalfedgesInTriangle(m, t)
            compute_angle_ada!(m, h)
        end
    end
    updateattr(t1)
    updateattr(t2)

    function updateattr(v::IV)
        compute_vertex_normal_ada!(m, v)
    end
    updateattr(v1)
    updateattr(v2)
    updateattr(v3)
    updateattr(v4)

    :success
end


"""
Find coordinates `c1`, such that `(c1, c2, c3)` is equilateral and `un` is the unit normal of the triangle.
"""
function coord_tocomplete_equilateraltriangle(c2::AbstractVector, c3::AbstractVector, un::AbstractVector)
    (c2 + c3) / 2 + cross(un, c3-c2) * (sqrt(3) / 2)
end

"""
Find the optimal location of a vertex at the barycenter of points that form equilateral triangles with oppositing edges.

This function requires but does not check the up-to-date
- vertex coordinates
- vertex unit normal
- triangle unit normal
"""
function coord_optimalvertex_barycenter(m::DynamicHalfedgeMesh, v::IV)
    thetarget = SA{Float64}[0,0,0]
    numtriangles::Int = 0
    for h ∈ HalfedgesTargetingVertex(m, v)
        if polygon(m, h).type == pt_triangle
            cn = m.vertices.attr.coord[(h |> next(m) |> target(m)).value]
            cp = m.vertices.attr.coord[(h |> prev(m) |> target(m)).value]
            un = m.triangles.attr.unitnormal[triangle(m, h).value]
            thetarget += coord_tocomplete_equilateraltriangle(cn, cp, un)
            numtriangles += 1
        end
    end
    thetarget *= 1 / numtriangles

    # Project onto tangent plane.
    ci = m.vertices.attr.coord[v.value]
    un = m.vertices.attr.ada_unitnormal[v.value]
    thetarget -= un * dot(un, thetarget - ci)

    thetarget
end

"""
Iteratively move vertices to optimal positions.
`relocfunc!`: (mesh, vertexindex, newcoord) -> nothing
`flipfunc!`: (mesh, edgeindex) -> nothing
"""
function movevertices!_coordoptimal(relocfunc!, flipfunc!, m::DynamicHalfedgeMesh, p::MeshAdaptParams)
    function tryflipalledges()::Int
        res = 0
        for eindex ∈ 1:length(m.edges)
            if try_flip_edge!(flipfunc!, m, IE(eindex), p) == :success
                res += 1
            end
        end
        res
    end

    # Is vertex immovable?
    immovable(v::IV) = false

    iter = 0
    function eachiter()
        iter += 1
        # Move vertices.
        for iter_relo ∈ 1:p.relaxation_max_iter_reloc
            for vindex ∈ 1:length(m.vertices)
                v = IV(vindex)
                if !onborder(m, v) && !immovable(v)
                    relocfunc!(m, v, coord_optimalvertex_barycenter(m, v))
                end
            end
        end

        # Update normals.
        compute_all_triangle_normals_ada!(m)
        compute_all_angles_ada!(m)
        compute_all_vertex_normals_ada!(m)

        # Try flipping.
        return tryflipalledges()
    end

    flipcount = eachiter()
    while flipcount > 0 && iter < p.relaxation_max_iter_total
        flipcount = eachiter()
    end
end


"""
Implements the vertex smoothing algorithm by flow toward smaller surface area.

Reference:
    Mark Meyer et al. (2003)
    Discrete Differential-Geometry Operators for Triangulated 2-Manifolds
    Page 18: "An Anisotropic Smoothing Technique"
Since the surface mesh is mainly for membranes, which should not preserve
any sharp features, we use iostropic mesh smoothing.
Therefore, the velocity of a vertex i is
    ∂_t x_i = -Δx_i
where Δ is the (integrated) discretized Laplace operator (the cotangent formula).

Note:
- This function helps denoising the initial mesh, but should not be used during simulation, because this WILL change energies.
- As a result, mechanical/chemical attributes will not be updated during the process.
- Only non-border vertices take part in curvature flow.
- dt is dimensionless.
- Requires but does not check for latest
    - vertex coordinates
"""
function meshsmoothing_curvatureflowstep!(m::DynamicHalfedgeMesh, dt::Float64)
    nv = length(m.vertices)

    # Step 1.1. Calculate all angles.
    compute_all_angles_ada!(m)

    # Step 1.2. Calculate curvature and normal direction.
    curvs = zeros(SVector{3,Float64}, nv)

    for vindex ∈ 1:nv
        v = IV(vindex)
        if !onborder(m, v)
            c = m.vertices.attr.coord[vindex]
            d2x = SA{Float64}[0,0,0]
            for h ∈ HalfedgesTargetingVertex(m, v)
                local h_o = oppo(m, h)
                local h_n = next(m, h)
                local h_on = next(m, h_o)
                local c_n = m.vertices.attr.coord[target(m, h_o).value]

                local sumcotθ = m.halfedges.attr.cotθ[h_n.value] + m.halfedges.attr.cotθ[h_on.value]
                d2x += (sumcotθ/2) * (c - c_n)
            end

            curvs[vindex] = d2x
        end
    end

    # Step 2. Move vertices along curvature vector (times dt).
    for vindex ∈ 1:nv
        m.vertices.attr.coord[vindex] -= dt * curvs[vindex]
    end
end

function meshsmoothing!(m::DynamicHalfedgeMesh, dt::Float64, numiter::Int)
    for _ ∈ 1:numiter
        meshsmoothing_curvatureflowstep!(m, dt)
    end
end


"""
Find mesh desired edge size (on vertices) based on simple curvature computation.

Requires
- vertex coordinates
- vertex unit normal
"""
function compute_vertexsize_curvature(m::DynamicHalfedgeMesh, v::IV, p::MeshAdaptParams)
    minradius = Inf64
    un = m.vertices.attr.ada_unitnormal[v.value]
    c = m.vertices.attr.coord[v.value]
    for h ∈ HalfedgesTargetingVertex(m, v)
        local cn = m.vertices.attr.coord[(h |> oppo(m) |> target(m)).value]
        local r = cn - c
        minradius = min(minradius, abs(dot(r,r) / (2*dot(un,r))))
    end
    p.curvature_resolution * minradius
end

"""
Find mesh desired edge size (on vertices) based on whether it is on border.
"""
function compute_vertexsize_border(m::DynamicHalfedgeMesh, v::IV)
    ret = Inf64
    if onborder(m, v)
        c = m.vertices.attr.coord[v.value]
        # Use shortest border edge length.
        for h ∈ HalfedgesTargetingVertex(m, v)
            local h_o = oppo(m, h)
            if polygon(m, h).type != pt_triangle || polygon(m, h_o).type != pt_triangle
                local cn = m.vertices.attr.coord[target(m, h_o).value]
                ret = min(ret, norm_fast(c - cn))
            end
        end
    end
    ret
end

"""
Find desired edge sizes on all vertices and edges.
"""
function compute_sizemeasure!(m::DynamicHalfedgeMesh, p::MeshAdaptParams)
    nv = length(m.vertices)
    adasize = Vector{Float64}(undef, nv)
    sizeaux = Vector{Float64}(undef, nv)

    # Compute sizes on each vertex.
    for vindex ∈ 1:nv
        v = IV(vindex)
        adasize[vindex] = clamp(
            min(
                compute_vertexsize_curvature(m, v, p),
                compute_vertexsize_border(m, v),
            ),
            p.min_size,
            p.max_size
        )
    end

    # Diffuse, with D * Δt = 0.5, and uniformly weighted Laplace operator.
    # l_new = l_old /2 + (sum neighbor l_old) / (2 * num neighbors)
    for _ ∈ 1:p.diffuse_iter
        for vindex ∈ 1:nv
            v = IV(vindex)
            deg = degree(m, v)
            sumsizeneighbor = 0.0
            for h ∈ HalfedgesTargetingVertex(m, v)
                sumsizeneighbor += adasize[(h |> oppo(m) |> target(m)).value]
            end

            sizeaux[vindex] = clamp(
                adasize[vindex] /2 + sumsizeneighbor / (2 * deg),
                p.min_size,
                p.max_size
            )
        end
        for vindex ∈ 1:nv
            adasize[vindex] = sizeaux[vindex]
        end
    end

    # Update sizes on edges.
    for eindex ∈ 1:length(m.edges)
        local sz = 0.0
        for h ∈ HalfedgesInEdge(m, IE(eindex))
            sz += adasize[target(m, h).value] / 2
        end
        m.edges.attr.ada_eqlength[eindex] = sz
    end
end

"""
Adapt mesh.
"""
function adaptmesh!(splitfunc!, collapsefunc!, flipfunc!, relocfunc!, m::DynamicHalfedgeMesh, p::MeshAdaptParams)
    iter_mainloop = 0
    while true
        # This outer loop does the following in sequence:
        #
        # 1. Update the desired sizes of all the edges, based on the size criteria.
        # 2. Perform vertex insertion/deletion operations according to the desired size. The geometry should be updated.
        # 3. Relocate the vertices to local optimum iteratively. The geometry should be updated.

        if p.do_meshsmoothing
            meshsmoothing!(m, p.meshsmoothing_dt, p.meshsmoothing_iter)
        end

        compute_all_triangle_normals_ada!(m)
        compute_all_angles_ada!(m)
        compute_all_vertex_normals_ada!(m)
        compute_sizemeasure!(m, p)

        sizesatisfied = true
        n_modified = 114514
        iter = 0
        while n_modified > 0 && iter < p.max_adjust_iter
            n_modified = 0
            eindex = 1
            while eindex < length(m.edges)
                local e = IE(eindex)
                local h = halfedge(m, e)
                local v1 = target(m, h)
                local v2 = target(m, oppo(m, h))
                local c1 = m.vertices.attr.coord[v1.value]
                local c2 = m.vertices.attr.coord[v2.value]
                local len2 = sum(abs2, c1 - c2)

                local eqlen = m.edges.attr.ada_eqlength[eindex]
                local eqlen2 = eqlen * eqlen

                if len2 > 2 * eqlen2
                    # Too long.
                    sizesatisfied = false
                    if try_split_edge!(splitfunc!, flipfunc!, m, e, p) == :success
                        n_modified += 1
                    else
                        eindex += 1
                    end
                elseif 2 * len2 < eqlen2
                    # Too short.
                    sizesatisfied = false
                    if try_collapse_edge!(collapsefunc!, m, e, p) == :success
                        n_modified += 1
                    else
                        eindex += 1
                    end
                else
                    eindex += 1
                end
            end
            iter += 1
        end

        if sizesatisfied || (n_modified == 0 && iter_mainloop >= p.max_soft_mainloop_iter) || (iter_mainloop >= p.max_hard_mainloop_iter)
            break
        end

        movevertices!_coordoptimal(relocfunc!, flipfunc!, m, p)

        iter_mainloop += 1
    end
end

"""
Return the number of vertices with state 2. 
Check the number of vertices with state 2. The number should be constant.
"""
function num_vertexwithstate(m::DynamicHalfedgeMesh, vertexstate::UInt8)
    num_vertexstate = 0
    for vidx in eachindex(m.vertices.attr.vertexstate)
        if m.vertices.attr.vertexstate[vidx] == vertexstate
            num_vertexstate += 1
        end
    end
    return num_vertexstate
end