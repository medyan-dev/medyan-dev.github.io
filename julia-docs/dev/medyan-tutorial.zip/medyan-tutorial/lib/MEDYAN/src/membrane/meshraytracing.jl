using MutatePlainDataArray
using StaticArrays

"""
Build an AABB tree of all triangles in the meshes.
"""
function build_aabbtree_frommeshes(ms)
    ntotal = sum(m -> length(m.triangles), ms)

    # Create data.
    DT = @NamedTuple{
        coords::SVector{3,SVector{3,Float64}},
        mindex::Int,
        tindex::Int,
    }
    data = DT[]
    sizehint!(data, ntotal)

    for mindex ∈ eachindex(ms)
        m = ms[mindex]
        for tindex ∈ eachindex(m.triangles)
            t = IT(tindex)
            h = halfedge(m, t)
            hn = next(m, h)
            hp = prev(m, h)
            vs = SA[target(m,h), target(m,hn), target(m,hp)]
            cs = map(v->m.vertices.attr.coord[v.value], vs)
            push!(data, (; coords=cs, mindex, tindex))
        end
    end

    # Create function that gets box information.
    function getboxinfo(data, i::Int)
        local d = data[i]
        local xmin = @SVector [
            minimum(i->d.coords[i][dim], 1:3)
            for dim ∈ 1:3
        ]
        local xmax = @SVector [
            maximum(i->d.coords[i][dim], 1:3)
            for dim ∈ 1:3
        ]
        (offset = xmin, size = xmax-xmin)
    end

    build_binary_aabbtree(getboxinfo, data)
end


const LineMeshAABBIntersectResType = @NamedTuple{
    mindex::Int,
    tindex::Int,
    t::Float64,
}

"""
Returns a list of intersection results.

For a new intersect `t'`, if ∃`t` in existing intersects, such that `|t'-t| < atol`, it will be ignored.
If `sorting` is true, the result will be sorted in non-decreasing order.
If `resbuffer` is provided, the results will be written to the provided buffer (and returned).
"""
function line_meshaabb_intersect!(tree, o, d; atol=1e-9, sorting=false, tinterval=(-Inf,Inf), resbuffer::Vector{LineMeshAABBIntersectResType}=LineMeshAABBIntersectResType[])
    empty!(resbuffer)

    function rayelement(data, index, o, d, tinterval, res)
        local cs = data[index].coords
        local intersect_result = moller_trumbore_intersect(o, d, cs[1], cs[2], cs[3]; tinterval)
        if intersect_result.intersect
            if all(eachres -> abs(eachres.t - intersect_result.t) >= atol, res)
                push!(res, (;
                    mindex = data[index].mindex,
                    tindex = data[index].tindex,
                    t = intersect_result.t,
                ))
            end
        end
        res
    end

    resbuffer .= trace_line(rayelement, tree, o, d, resbuffer; tinterval)
    if sorting
        sort!(resbuffer; by = eachres->eachres.t)
    end
    resbuffer
end
