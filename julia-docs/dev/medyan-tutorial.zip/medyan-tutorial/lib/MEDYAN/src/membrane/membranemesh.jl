"""
`CopyNumberType` should be a named tuple, with species names as names and Int as types.
"""
@kwdef struct MembraneMeshVA{CopyNumbersType, ContribMembraneSiteCountType}
    # Cache.
    cached_xcoordindex::Int = 0
    "Pinned vertices will experience a force if they are away from the pinned coordinates. Pinning info is updated during vectorization."
    pinned::Bool = false
    pinned_coord::SVector{3, Float64} = SA[NaN,NaN,NaN]

    # Index tracker.
    "A vertex has a unique ID in the mesh, which should not change throughout its lifetime."
    id::Int = 0
    "Vertex type"
    vertexstate::UInt8 = 0
    "Vertex should not be removed during mesh adapt"
    irremovable::Bool = false
    "The compartment ID this vertex is in. Valid when VFS_VERTEX_IN_COMPARTMENT is set."
    cid::Int = 0

    # Geometry.
    coord::SVector{3, Float64} = SA[NaN, NaN, NaN]
    astar::Float64 = NaN
    g_astar::SVector{3, Float64} = SA[NaN, NaN, NaN]
    g_volume::SVector{3, Float64} = SA[NaN, NaN, NaN]
    curv::Float64 = NaN
    curv2::Float64 = NaN
    g_curv::SVector{3, Float64} = SA[NaN, NaN, NaN]
    g_curv2::SVector{3, Float64} = SA[NaN, NaN, NaN]
    ada_unitnormal::SVector{3, Float64} = SA[NaN, NaN, NaN]
    "Used in signed distance."
    pseudo_unitnormal::SVector{3, Float64} = SA[NaN, NaN, NaN]

    # Species.
    """
    Copy number of each species in each vertex.
    This must be serialized in output.
    """
    copynumbers::CopyNumbersType
    """
    Sum of outward diffusion propensities.
    Do not serialize this in output.
    """
    outdiffusion_a::Q31f32 = 0
    """
    Individual vertex contribution to site counts. The total count is consistently stored in fixed species.
    It should be a struct or NamedTuple with membrane site names as keys.
    Used and updated by chemistry engine (for membrane). Must be filled with zero outside chemistry.
    Do not serialize this in output.
    """
    contrib_membranesitecount::ContribMembraneSiteCountType
end

function gettype_copynumbers(::Type{MembraneMeshVA{CopyNumbersType, ContribMembraneSiteCountType}}) where {CopyNumbersType, ContribMembraneSiteCountType}
    CopyNumbersType
end
function gettype_contrib_membranesitecount(::Type{MembraneMeshVA{CopyNumbersType, ContribMembraneSiteCountType}}) where {CopyNumbersType, ContribMembraneSiteCountType}
    ContribMembraneSiteCountType
end

"Expand both membrane mesh vertex attribute and substructs such as copy numbers."
function func_attr_unwrap(::Type{MembraneMeshVA{CopyNumbersType, ContribMembraneSiteCountType}}) where {CopyNumbersType, ContribMembraneSiteCountType}
    t -> t <: MembraneMeshVA{CopyNumbersType} ||
        (fieldcount(CopyNumbersType) > 0 && t <: CopyNumbersType) ||
        (fieldcount(ContribMembraneSiteCountType) > 0 && t <: ContribMembraneSiteCountType)
end


@kwdef struct MembraneMeshHA{SpeciesFixedNamedTuple}
    # Geometry.
    g_triangle_area::SVector{3, Float64} = SA[NaN, NaN, NaN]
    θ::Float64 = NaN
    cotθ::Float64 = NaN
    g_cotθ::SVector{3, SVector{3, Float64}} = nan_3vectors(3)
    "Derivative of astar of source vertex on target vertex."
    g_ontarget_sourceastar::SVector{3, Float64} = SA[NaN, NaN, NaN]
    "Derivative of curv of source vertex on target vertex."
    g_ontarget_sourcecurv::SVector{3, Float64} = SA[NaN, NaN, NaN]
    "Derivative of curv2 of source vertex on target vertex."
    g_ontarget_sourcecurv2::SVector{3, Float64} = SA[NaN, NaN, NaN]

    # Species related.
    "Hopping propensity from source vertex to target vertex (1/s). Indexed by species name. Managed by chemistry."
    diffusion_a::SpeciesFixedNamedTuple
end

"Expand both membrane mesh halfedge attribute and substructs such as diffusion rates."
function func_attr_unwrap(::Type{MembraneMeshHA{SpeciesFixedNamedTuple}}) where {SpeciesFixedNamedTuple}
    t -> begin
        t <: MembraneMeshHA{SpeciesFixedNamedTuple} ||
        (fieldcount(SpeciesFixedNamedTuple) > 0 && t <: SpeciesFixedNamedTuple)
    end
end

@kwdef struct MembraneMeshEA
    # Cache.
    cached_xcoordindices::SVector{2, Int} = SA[0, 0]

    # Geometry.
    length::Float64 = NaN
    normal_angle::Float64 = NaN
    ada_eqlength::Float64 = NaN
    "Used in signed distance."
    pseudo_unitnormal::SVector{3, Float64} = SA[NaN, NaN, NaN]
end

@kwdef struct MembraneMeshTA
    # Cache.
    cached_xcoordindices::SVector{3, Int} = SA[0, 0, 0]

    # Geometry.
    area::Float64 = NaN
    cone_volume::Float64 = NaN
    unitnormal::SVector{3, Float64} = SA[NaN, NaN, NaN]
end

@kwdef mutable struct MembraneMeshMA
    membranetype::Int = 1

    # Membrane diffusion related.
    "Total membrane diffusion propensity (1/s). Managed by chemistry."
    total_membranediffusion_a::Q31f32 = 0
    "Maximum vertex outward diffusion propensity (1/s). Managed by chemistry."
    max_vertexoutdiffusion_a::Q31f32 = 0

    "Map vertex ID to vertex index."
    id2index_vertex::StableIndex = StableIndex()
end

"""
    create_membranemesh(::Val{SpeciesNames}, ::Val{MembraneSiteNames}; kws...)

Creates a membrane mesh with given species names and membrane site names.
All related data structures will be initialized, but no vertex or triangle is created.
"""
function create_membranemesh(::Val{SpeciesNames}=Val(()), ::Val{MembraneSiteNames}=Val(()); kws...) where {SpeciesNames, MembraneSiteNames}
    numspecies = length(SpeciesNames)
    copynumbers = NamedTuple{SpeciesNames}(ntuple(Returns(0), numspecies))
    diffusion_a = NamedTuple{SpeciesNames, NTuple{numspecies, Q31f32}}(ntuple(Returns(zero(Q31f32)), numspecies))
    num_membranesites = length(MembraneSiteNames)
    contrib_membranesitecount = NamedTuple{MembraneSiteNames}(ntuple(Returns(zero(Q31f32)), num_membranesites))

    DynamicHalfedgeMesh(
        MembraneMeshVA{typeof(copynumbers),typeof(contrib_membranesitecount)}(;copynumbers, contrib_membranesitecount),
        MembraneMeshHA{typeof(diffusion_a)}(;diffusion_a),
        MembraneMeshEA(),
        MembraneMeshTA(),
        DefaultHalfedgeMeshElementAttr(),
        MembraneMeshMA(; kws...),
    )
end

@generated function gettype_membranemesh(::Val{SpeciesNames}=Val(()), ::Val{MembraneSiteNames}=Val(())) where {SpeciesNames, MembraneSiteNames}
    typeof(create_membranemesh(Val(SpeciesNames), Val(MembraneSiteNames)))
end
"Given membrane mesh type, find species names."
@generated function get_speciesnames(::Type{T}) where {T<:DynamicHalfedgeMesh}
    T |> attrtype_vertex |> gettype_copynumbers |> fieldnames
end
"Given a membrane mesh, find species names."
@generated function get_speciesnames(m::DynamicHalfedgeMesh)
    get_speciesnames(m)
end
"Given membrane mesh type, find species names as Val."
@generated function getval_speciesnames(::Type{T}) where {T<:DynamicHalfedgeMesh}
    Val(get_speciesnames(T))
end
"Given a membrane mesh, find species names as Val."
@generated function getval_speciesnames(m::DynamicHalfedgeMesh)
    Val(get_speciesnames(m))
end
"Given membrane mesh type, find number of diffusing species."
@generated function get_numdiffusingspecies(::Type{T}) where {T<:DynamicHalfedgeMesh}
    T |> attrtype_vertex |> gettype_copynumbers |> fieldcount
end
"Given a membrane mesh, find number of diffusing species."
@generated function get_numdiffusingspecies(m::DynamicHalfedgeMesh)
    get_numdiffusingspecies(m)
end

"Given a membrane mesh type, find membrane site names."
@generated function get_membranesitenames(::Type{T}) where {T<:DynamicHalfedgeMesh}
    T |> attrtype_vertex |> gettype_contrib_membranesitecount |> fieldnames
end
"Given a membrane mesh, find membrane site names."
@generated function get_membranesitenames(m::DynamicHalfedgeMesh)
    get_membranesitenames(m)
end
"Given a membrane mesh type, find membrane site names as Val."
@generated function getval_membranesitenames(::Type{T}) where {T<:DynamicHalfedgeMesh}
    Val(get_membranesitenames(T))
end
"Given a membrane mesh, find membrane site names as Val."
@generated function getval_membranesitenames(m::DynamicHalfedgeMesh)
    Val(get_membranesitenames(m))
end
"Given a membrane mesh type, find number of membrane sites."
@generated function get_nummembranesites(::Type{T}) where {T<:DynamicHalfedgeMesh}
    T |> attrtype_vertex |> gettype_contrib_membranesitecount |> fieldcount
end
"Given a membrane mesh, find number of membrane sites."
@generated function get_nummembranesites(m::DynamicHalfedgeMesh)
    get_nummembranesites(m)
end

"Given a membrane mesh and a triangle index, find the coordinates of the vertices."
function get_coords(m::DynamicHalfedgeMesh, t::IT)
    h = halfedge(m, t)
    hn = next(m, h)
    hnn = next(m, hn)
    v1 = target(m, h)
    v2 = target(m, hn)
    v3 = target(m, hnn)
    SA[
        m.vertices.attr.coord[v1.value],
        m.vertices.attr.coord[v2.value],
        m.vertices.attr.coord[v3.value],
    ]
end


const default_initmembraneattr! = begin
    tmp = default_initattr!
    tmp = @set tmp.vertex = (m::DynamicHalfedgeMesh, v::IV) -> begin
        # Obtain new ID.
        local id = push!(m.metaattr.id2index_vertex, v.value)
        m.vertices.attr.id[v.value] = id
        # Default copy number should be zero.
        for speciesindex ∈ eachindex(propertynames(m.vertices.attr.copynumbers))
            getproperty(m.vertices.attr.copynumbers, speciesindex)[v.value] = 0
        end
        # Out diffusion propensity must be zero.
        m.vertices.attr.outdiffusion_a[v.value] = 0
        # Membrane site count contribution must be zero.
        for siteindex ∈ eachindex(propertynames(m.vertices.attr.contrib_membranesitecount))
            getproperty(m.vertices.attr.contrib_membranesitecount, siteindex)[v.value] = 0
        end
        # Vertex state initialized with 1
        m.vertices.attr.vertexstate[v.value] = UInt8(1)
        m.vertices.attr.irremovable[v.value] = false
    end
    tmp = @set tmp.halfedge = (m::DynamicHalfedgeMesh, h::IH) -> begin
        # Diffusion propensity must be zero.
        for speciesindex ∈ eachindex(propertynames(m.halfedges.attr.diffusion_a))
            getproperty(m.halfedges.attr.diffusion_a, speciesindex)[h.value] = 0
        end
    end
    tmp
end

"""
Membrane mesh modification function: split an edge at a given coordinate.
"""
function membranemesh_splitfunc!(m::DynamicHalfedgeMesh, e::IE, newcoord::AbstractVector)
    nspecies = m |> get_numdiffusingspecies

    # Record states.
    #-----------------------------------
    h = halfedge(m, e)
    ho = oppo(m, h)
    v1 = target(m, h)
    v3 = target(m, ho)
    area1_old = adhoc_astar(m, v1) / 3
    area3_old = adhoc_astar(m, v3) / 3

    # Do the vertex insertion and set coordinate.
    #-----------------------------------
    # Only new element insertion during the operation, so all indices are still valid after it.
    change = insert_vertex_onedge!(default_initmembraneattr!, m, e)

    # Set new states.
    #-----------------------------------
    # Set coordinates.
    m.vertices.attr.coord[change.vnew.value] = newcoord

    area1_new = adhoc_astar(m, v1) / 3
    area3_new = adhoc_astar(m, v3) / 3
    # Reset copy numbers of diffusing species.
    p1 = min(1, area1_new / area1_old)
    p3 = min(1, area3_new / area3_old)
    for speciesindex ∈ 1:nspecies
        # Get copy number vector for this species.
        local ss = getproperty(m.vertices.attr.copynumbers, speciesindex)
        # Get original copy numbers.
        local n1_old = ss[v1.value]
        local n3_old = ss[v3.value]
        # Set new copy numbers.
        local n1_new = floor(Int, n1_old * p1)
        local n3_new = floor(Int, n3_old * p3)
        local nn_new = n1_old + n3_old - n1_new - n3_new
        ss[v1.value] = n1_new
        ss[v3.value] = n3_new
        ss[change.vnew.value] = nn_new
    end

    change
end

"""
Membrane mesh modification function: flip an edge.
"""
function membranemesh_flipfunc!(m, e::IE)
    # Do the edge flip.
    #-----------------------------------
    flip_edge!(m, e)

    # This function does not redistribute species.
end

"""
Membrane mesh modification function: collapse a halfedge.

The target preserved vertex will be moved to `newcoord`.
"""
function membranemesh_collapsefunc!(m, h::IH, newcoord::AbstractVector)
    nspecies = m |> get_numdiffusingspecies

    # Record states.
    #-----------------------------------
    ho = oppo(m, h)
    v_preserve = target(m, h)
    v_remove = target(m, ho)
    area_preserve_old = adhoc_astar(m, v_preserve) / 3
    area_remove_old = adhoc_astar(m, v_remove) / 3

    # Move all species from v_remove to v_preserve.
    for speciesindex ∈ 1:nspecies
        local ss = getproperty(m.vertices.attr.copynumbers, speciesindex)
        ss[v_preserve.value] += ss[v_remove.value]
    end

    id_remove_old = m.vertices.attr.id[v_remove.value]

    # Do the edge collapse.
    #-----------------------------------
    # Since elements are deleted, indices before this function will be invalidated.
    # Previous vertex indices can still be obtained via removal information.
    change = collapse_halfedge!(m, h)

    # Set ids
    delete!(m.metaattr.id2index_vertex, id_remove_old)
    # The removed vertex may have been replaced with the last vertex.
    # If so correct id2index_vertex
    if v_remove.value in eachindex(m.vertices.attr.id)
        local id = m.vertices.attr.id[v_remove.value]
        m.metaattr.id2index_vertex[id] = v_remove.value
    end

    # Set new states.
    #-----------------------------------
    # Set coordinates.
    m.vertices.attr.coord[change.vto.value] = newcoord

    # Set copy numbers.
    area_preserve_new = adhoc_astar(m, change.vto) / 3
    p_area = min(1, area_preserve_new / (area_preserve_old + area_remove_old))
    for speciesindex ∈ 1:nspecies
        local ss = getproperty(m.vertices.attr.copynumbers, speciesindex)
        local n_old = ss[change.vto.value]
        local n_new = floor(Int, p_area * n_old)
        local n_excess = n_old - n_new # Should be ≥ 0.
        # Give excess species to neighbors.
        local deg = degree(m, change.vto)
        n_new += mod(n_excess, deg)
        n_excess_each = n_excess ÷ deg
        # Actually set copy numbers.
        ss[change.vto.value] = n_new
        if n_excess_each > 0
            for h1 ∈ HalfedgesTargetingVertex(m, change.vto)
                vn = h1 |> oppo(m) |> target(m)
                ss[vn.value] += n_excess_each
            end
        end
    end

    change
end

"""
Membrane mesh modification function: reset vertex coordinate.
"""
function membranemesh_relocfunc!(m, v::IV, c::AbstractVector)
    m.vertices.attr.coord[v.value] = c

    # Does not change copy numbers.
end

"""
Given a halfedge mesh, cache all 3D coordinate indices starting from offset + 1.
Also caches the same information in other structures such as edges and triangles.

vertex index                1        2        3        ...
coord index     offset +    1  2  3  4  5  6  7  8  9  ...
"""
function cachecoordindices!(sm::StaticHalfedgeMesh, offset::Integer=0)
    for iv ∈ 1:length(sm.vertices)
        sm.vertices.attr.cached_xcoordindex[iv] = 3*iv - 2 + offset
    end
    for ie ∈ 1:length(sm.edges)
        sm.edges.attr.cached_xcoordindices[ie] = map(iv->sm.vertices.attr.cached_xcoordindex[iv], sm.edges.conn[ie].vertex_indices)
    end
    for it ∈ 1:length(sm.triangles)
        sm.triangles.attr.cached_xcoordindices[it] = map(iv->sm.vertices.attr.cached_xcoordindex[iv], sm.triangles.conn[it].vertex_indices)
    end
end

"""
Given a halfedge mesh, pin vertices based on border vicinity.
"""
function updatevertexpinning!(m::DynamicHalfedgeMesh, ::Val{PinningMode}) where PinningMode
    m.vertices.attr.pinned .= false
    if PinningMode == :border1 || PinningMode == :border2
        for vindex ∈ eachindex(m.vertices)
            if onborder(m, IV(vindex))
                m.vertices.attr.pinned[vindex] = true
                m.vertices.attr.pinned_coord[vindex] = m.vertices.attr.coord[vindex]
                if PinningMode == :border2
                    # Pin neighbors of border vertices.
                    for h ∈ HalfedgesTargetingVertex(m, IV(vindex))
                        ho = oppo(m, h)
                        vn = target(m, ho)
                        m.vertices.attr.pinned[vn.value] = true
                        m.vertices.attr.pinned_coord[vn.value] = m.vertices.attr.coord[vn.value]
                    end
                end
            end
        end
    end
end
