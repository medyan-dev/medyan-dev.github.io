
"""
Update membrane diffusion reaction rates for a certain species type going in/out of a vertex.
The results will be recorded in associated halfedges corresponding to the species.
Will update sum of all out-diffusion propensities on affected vertices.

`Direction` should be `:outward`, `:inward` or `:bi`, indicating the direction of diffusion to be updated on the vertex.

Returns
- the original maximum of out-diffusion propensities on affected vertices.
- the maximum of all updated out-diffusion propensities on vertices.
- the total change in membrane diffusion propensities.

Requires up-to-date
- Membrane (system) geometry, including cotθ and astar.
- Other attributes required to compute species potential energies.

Note:
- After this function, all outgoing diffusing propensities and, in turn, all affected propensity sums, are invalidated.
"""
function update_membranediffusionpropensity!(
        β::Real,
        membrane_species_params,
        m::DynamicHalfedgeMesh,
        v::IV,
        speciesindex::Int,
        func_membranespeciespotentialenergy,
        ::Val{Direction}
    ) where Direction

    outward::Bool = Direction === :outward || Direction === :bi
    inward::Bool = Direction === :inward || Direction === :bi
    if !outward && !inward
        error("Direction must be :outward, :inward or :bi")
    end
    
    vec_vertex_copynumbers = getproperty(m.vertices.attr.copynumbers, speciesindex)
    vec_halfedge_diffusion_a = getproperty(m.halfedges.attr.diffusion_a, speciesindex)
    cellinvarea = 3 / m.vertices.attr.astar[v.value]
    copynumber = vec_vertex_copynumbers[v.value]
    diffcoeff = membrane_species_params[speciesindex].diffusion_coeff
    speciesarea = membrane_species_params[speciesindex].area

    max_old_outdiffusion_a::Q31f32 = 0
    max_updated_outdiffusion_a::Q31f32 = 0
    Δ_outdiffusion_a::Q31f32 = 0

    if outward
        max_old_outdiffusion_a = m.vertices.attr.outdiffusion_a[v.value]
        energy_v_outward = func_membranespeciespotentialenergy(m, v, speciesindex)
    end
    if inward
        # Get copy number and area in target vertex.
        copynumber_v = getproperty(m.vertices.attr.copynumbers, speciesindex)[v.value]
        astar_v = m.vertices.attr.astar[v.value]
        canflow_v = (copynumber_v + 1) * speciesarea * 3 <= astar_v
        energy_v_inward = func_membranespeciespotentialenergy(m, v, speciesindex)
    end

    for h ∈ HalfedgesTargetingVertex(m, v)
        ho = oppo(m, h) # This is the direction of the outward cell hopping.
        hn = next(m, h)
        hp = prev(m, h)
        hon = next(m, ho)
        hop = prev(m, ho)
        vn = target(m, ho)

        h_border = onborder(m, h)
        ho_border = onborder(m, ho)

        cotθ_hn::Float64 = 0
        cotθ_hon::Float64 = 0
        if !h_border
            vn2 = target(m, hn)
            energy_vn2 = func_membranespeciespotentialenergy(m, vn2, speciesindex)
            cotθ_hn = m.halfedges.attr.cotθ[hn.value]
        end
        if !ho_border
            vn1 = target(m, hon)
            energy_vn1 = func_membranespeciespotentialenergy(m, vn1, speciesindex)
            cotθ_hon = m.halfedges.attr.cotθ[hon.value]
        end
        sumcotθ = cotθ_hn + cotθ_hon


        # Compute propensity.
        if outward
            energy_vn_outward = func_membranespeciespotentialenergy(m, vn, speciesindex)
            bias_comp = 0.0
            if !h_border
                bias_comp += (energy_vn_outward - energy_v_outward) * cotθ_hn + (energy_vn_outward - energy_vn2) * m.halfedges.attr.cotθ[h.value]
            end
            if !ho_border
                bias_comp += (energy_vn_outward - energy_v_outward) * cotθ_hon + (energy_vn_outward - energy_vn1) * m.halfedges.attr.cotθ[hop.value]
            end
            bias_comp /= 6

            # Get copy number and area in target vertex.
            copynumber_vn = getproperty(m.vertices.attr.copynumbers, speciesindex)[vn.value]
            astar_vn = m.vertices.attr.astar[vn.value]
            canflow_vn = (copynumber_vn + 1) * speciesarea * 3 <= astar_vn

            newa_out::Q31f32 = (
                # Diffusion coefficient.
                diffcoeff
                # Shape and bias factor.
                * max(0, sumcotθ / 2 - bias_comp * β)
                # Volume factor.
                * cellinvarea
                # Copy number.
                * copynumber
                # Target vertex full?
                * ifelse(canflow_vn, 1, 0)
            )
            olda_out = vec_halfedge_diffusion_a[ho.value]
            vec_halfedge_diffusion_a[ho.value] = newa_out

            # Update out-diffusion total propensity of vertex v.
            m.vertices.attr.outdiffusion_a[v.value] += newa_out - olda_out
            # Update return values.
            max_updated_outdiffusion_a = max(max_updated_outdiffusion_a, m.vertices.attr.outdiffusion_a[v.value])
            Δ_outdiffusion_a += newa_out - olda_out
        end

        if inward
            energy_vn_inward = func_membranespeciespotentialenergy(m, vn, speciesindex)
            bias_comp = 0.0
            if !h_border
                bias_comp += (energy_v_inward - energy_vn_inward) * cotθ_hn + (energy_v_inward - energy_vn2) * m.halfedges.attr.cotθ[hp.value]
            end
            if !ho_border
                bias_comp += (energy_v_inward - energy_vn_inward) * cotθ_hon + (energy_v_inward - energy_vn1) * m.halfedges.attr.cotθ[ho.value]
            end
            bias_comp /= 6

            newa_in::Q31f32 = (
                # Diffusion coefficient.
                diffcoeff
                # Shape and bias factor.
                * max(0, sumcotθ / 2 - bias_comp * β)
                # Volume factor.
                * (3 / m.vertices.attr.astar[vn.value])
                # Copy number.
                * vec_vertex_copynumbers[vn.value]
                # Target vertex full?
                * ifelse(canflow_v, 1, 0)
            )
            olda_in = vec_halfedge_diffusion_a[h.value]
            vec_halfedge_diffusion_a[h.value] = newa_in

            # Update affected parameters, since this vertex is used only once.
            max_old_outdiffusion_a = max(max_old_outdiffusion_a, m.vertices.attr.outdiffusion_a[vn.value])
            # Update out-diffusion total propensity of vertex vn.
            m.vertices.attr.outdiffusion_a[vn.value] += newa_in - olda_in
            # Update return values.
            max_updated_outdiffusion_a = max(max_updated_outdiffusion_a, m.vertices.attr.outdiffusion_a[vn.value])
            Δ_outdiffusion_a += newa_in - olda_in
        end
    end

    (; max_old_outdiffusion_a, max_updated_outdiffusion_a, Δ_outdiffusion_a)
end


"""
This function should be called once before chemistry simulation, such as during initialization or after energy minimization.

Update membrane diffusion propensities for the entire membrane.
Will also update the total diffusion propensity and the max vertex-wise out-diffusion propensity in the membrane.

Returns the total membrane diffusion propensity.

Requires
- All requirements by `update_membranediffusionpropensity!` of one vertex and one species.
"""
function update_membranediffusionpropensity!(β::Real, membrane_species_params, m::DynamicHalfedgeMesh, func_membranespeciespotentialenergy::Func) where {Func}
    nspecies = get_numdiffusingspecies(m)

    # Reset diffusion propensites and sums.
    for speciesindex ∈ 1:nspecies
        fill!(getproperty(m.halfedges.attr.diffusion_a, speciesindex), 0)
    end
    fill!(m.vertices.attr.outdiffusion_a, 0)

    totala::Q31f32 = 0
    maxa::Q31f32 = 0
    for vindex ∈ eachindex(m.vertices)
        v = IV(vindex)
        for speciesindex ∈ 1:nspecies
            update_membranediffusionpropensity!(β, membrane_species_params, m, v, speciesindex, func_membranespeciespotentialenergy, Val(:outward))
        end

        maxa = max(maxa, m.vertices.attr.outdiffusion_a[vindex])
        totala += m.vertices.attr.outdiffusion_a[vindex]
    end

    m.metaattr.total_membranediffusion_a = totala
    m.metaattr.max_vertexoutdiffusion_a = maxa
    return totala
end

"""
Resets all membrane diffusion propensities to zero.
Also resets maximum/total propensities of a membrane to zero.
"""
function clear_membranediffusionpropensity!(m::DynamicHalfedgeMesh)
    nspecies = get_numdiffusingspecies(m)
    # Reset diffusion propensites and sums.
    for speciesindex ∈ 1:nspecies
        fill!(getproperty(m.halfedges.attr.diffusion_a, speciesindex), 0)
    end
    fill!(m.vertices.attr.outdiffusion_a, 0)

    m.metaattr.total_membranediffusion_a = 0
    m.metaattr.max_vertexoutdiffusion_a = 0
end


"""
Same as `update_membranediffusionpropensity!` but also updates related variables in the RDME sampler.
This function has an additional requirement, that the original membrane total propensity must be a correct portion of total propensity in RDME sampler.
Should not be called during chemistry sampling.
"""
function update_membranediffusionpropensity!(s::RDMESampler, memdiff_bulks_index::Integer, β::Real, membrane_species_params, m::DynamicHalfedgeMesh, func_membranespeciespotentialenergy::Func) where {Func}
    old_membranediffusion_a = m.metaattr.total_membranediffusion_a
    new_membranediffusion_a = update_membranediffusionpropensity!(β, membrane_species_params, m, func_membranespeciespotentialenergy)
    addbulkspeciescount!(s, memdiff_bulks_index, new_membranediffusion_a - old_membranediffusion_a)
end


"""
Clearing all propensities related to membrane diffusion.
Doing so ensures that further membrane operations will not silently break total propensity consistency.
However, before calling this function, the total propensities must be consistent.
Should not be called during chemistry sampling.
"""
function clear_membranediffusionpropensity!(s::RDMESampler, memdiff_bulks_index::Integer, m::DynamicHalfedgeMesh)
    old_membranediffusion_a = m.metaattr.total_membranediffusion_a
    clear_membranediffusionpropensity!(m)
    addbulkspeciescount!(s, memdiff_bulks_index, -old_membranediffusion_a)
end


"""
Given a vertex and a membrane site, update the vertex contribution to the total site count.
Returns the increased site count contribution.

Requires:
- Correct old site count contribution.
- Up-to-date areas of cells.

Note:
- This function does not update total site count, thus breaking consistency between individual contributions and the total site count.
"""
function update_contrib_membranesitecount!(;
        β::Real,
        membrane_species_params,
        mesh::DynamicHalfedgeMesh,
        v::IV,
        membranesites,
        siteindex::Integer,
        func_membranespeciespotentialenergy::Func
    ) where {Func}

    contrib_old = getproperty(mesh.vertices.attr.contrib_membranesitecount, siteindex)[v.value]
    @assert contrib_old isa Q31f32

    site = membranesites[siteindex].site
    speciesindex = get_reactantid(site) # Can be 0.
    area = mesh.vertices.attr.astar[v.value] / 3

    # For reactions M1 + M2 + ... + C1 + C2 + ... -> ...
    #
    #     base_rate = Π_i [Mi] Π_j [Cj] A,
    #
    # where [Mi] is area concentration of Mi, [Cj] is volume concentration of Cj, and A is the area of the cell.
    # Therefore, the site count contribution is Π_i [Mi] A.
    #
    # The potential energy results in a multiplicative factor
    #
    #     fac(E) = exp(βE)
    #
    sitecount_float::Float64 = if speciesindex == 0
        area
    else
        getproperty(mesh.vertices.attr.copynumbers, speciesindex)[v.value] |> Float64
    end

    if get_canpotentialenergychangerate(site)
        sitecount_float *= exp(β * func_membranespeciespotentialenergy(mesh, v, speciesindex))
    end

    # If any target membrane diffusing species reaches max copy number, reset the site count to 0.
    for (speciesindex, Δcount) ∈ get_stoich(site)
        if Δcount > 0
            local copynumber = getproperty(mesh.vertices.attr.copynumbers, speciesindex)[v.value]
            if (copynumber + Δcount) * membrane_species_params[speciesindex].area >= area
                sitecount_float = 0
                break
            end
        end
    end

    # Prevent weird site counts.
    sitecount_float = ifelse(isnan(sitecount_float), zero(sitecount_float), clamp(sitecount_float, 0, 1e8))

    contrib_new = Q31f32(sitecount_float)
    getproperty(mesh.vertices.attr.contrib_membranesitecount, siteindex)[v.value] = contrib_new

    return contrib_new - contrib_old
end

"""
Updates all site counts and related variables in the RDME sampler.
The original sum of site count contributions must be equal to the original site counts in each compartment.

Should not be called during chemistry sampling.
Requires that vertices correctly assigned to compartments.
"""
function update_membranesitecount!(;
        rdme::RDMESampler,
        β::Real,
        membrane_species_params,
        mesh::DynamicHalfedgeMesh,
        membranesites,
        siteindex::Integer,
        func_membranespeciespotentialenergy::Func
    ) where {Func}

    fxsid = membranesites[siteindex].fxsid
    for vindex ∈ eachindex(mesh.vertices)
        Δcount = update_contrib_membranesitecount!(; β, membrane_species_params, mesh, v = IV(vindex), membranesites, siteindex, func_membranespeciespotentialenergy)
        cid = mesh.vertices.attr.cid[vindex]
        addfixedspeciescount!(rdme, fxsid, cid, Δcount)
    end
end


"""
Clear all site count contributions and related variables in the RDME sampler.
Doing so ensures that further membrane operations will not silently break total propensity consistency.
However, before calling this function, the total site counts must be consistent.

Should not be called during chemistry sampling.
Requires that vertices correctly assigned to compartments.
"""
function clear_membranesitecount!(;
        rdme::RDMESampler,
        mesh::DynamicHalfedgeMesh,
        membranesites,
        siteindex::Integer,
    )

    fxsid = membranesites[siteindex].fxsid
    contribs = getproperty(mesh.vertices.attr.contrib_membranesitecount, siteindex)
    for vindex ∈ eachindex(mesh.vertices)
        old_count = contribs[vindex]
        contribs[vindex] = 0
        cid = mesh.vertices.attr.cid[vindex]
        addfixedspeciescount!(rdme, fxsid, cid, -old_count)
    end
end




"""
This function is called during chemistry. It should not be used during initialization.

Sets the diffusing species count of a certain species in a vertex to the specified value. All affected propensites, including all sums/maxima, is updated as well.

Some parameters:
- map_speciesindex_membranesites: maps a membrane diffusing species index to a list of membrane sites using this index.

Notes:
- Requires up-to-date compartment IDs in vertices.
"""
function set_membranediffusingspeciescount!(;
        rdme::RDMESampler,
        memdiff_bulks_index::Integer,
        map_speciesindex_membranesites,
        β::Real,
        membrane_species_params,
        mesh::DynamicHalfedgeMesh,
        v::IV,
        speciesindex::Int,
        membranesites,
        newcount::Integer,
        func_membranespeciespotentialenergy::Func
    ) where {Func}

    @assert newcount≥0 "counts must be non-negative."
    @inbounds getproperty(mesh.vertices.attr.copynumbers, speciesindex)[v.value] = newcount

    # Update all affected reaction propensities.
    #-----------------------------------
    # On membrane diffusion reactions:
    # - Changes outward diffusion propensities.
    # - May change potential energy for this species in current cell, thus changing bi-directional diffusion propensities with this vertex.
    (; max_old_outdiffusion_a, max_updated_outdiffusion_a, Δ_outdiffusion_a) = update_membranediffusionpropensity!(β, membrane_species_params, mesh, v, speciesindex, func_membranespeciespotentialenergy, Val(:bi))
    mesh.metaattr.total_membranediffusion_a += Δ_outdiffusion_a
    if max_updated_outdiffusion_a >= mesh.metaattr.max_vertexoutdiffusion_a
        mesh.metaattr.max_vertexoutdiffusion_a = max_updated_outdiffusion_a
    elseif max_old_outdiffusion_a == mesh.metaattr.max_vertexoutdiffusion_a
        # Reset max out-diffusion propensity.
        mesh.metaattr.max_vertexoutdiffusion_a = maximum(mesh.vertices.attr.outdiffusion_a)
    end
    # Update total diffusion propensity.
    addbulkspeciescount!(rdme, memdiff_bulks_index, Δ_outdiffusion_a)

    # On membrane site reactions:
    # - Changes all membrane site reactions using this species as reactants.
    cid = mesh.vertices.attr.cid[v.value]
    for siteindex ∈ map_speciesindex_membranesites[speciesindex]
        contrib_Δ = update_contrib_membranesitecount!(;
            β,
            membrane_species_params, mesh, v,
            membranesites, siteindex,
            func_membranespeciespotentialenergy
        )

        # Update membrane site count.
        addfixedspeciescount!(rdme, membranesites[siteindex].fxsid, cid, contrib_Δ)
    end

end

function change_membranediffusingspeciescount!(;
        rdme::RDMESampler,
        memdiff_bulks_index::Integer,
        map_speciesindex_membranesites,
        β::Real,
        membrane_species_params,
        mesh::DynamicHalfedgeMesh,
        v::IV,
        speciesindex::Int,
        membranesites,
        Δcount::Integer,
        func_membranespeciespotentialenergy::Func
    ) where {Func}
    set_membranediffusingspeciescount!(;
        rdme,
        memdiff_bulks_index,
        map_speciesindex_membranesites,
        β,
        membrane_species_params,
        mesh, v, speciesindex,
        membranesites,
        newcount = getproperty(mesh.vertices.attr.copynumbers, speciesindex)[v.value] + Δcount,
        func_membranespeciespotentialenergy
    )
end

"""
Do a diffusion reaction, return the reaction info.
"""
function do_membranediffusionreaction!(;
        rdme::RDMESampler,
        memdiff_bulks_index::Integer,
        map_speciesindex_membranesites,
        β::Real,
        membrane_species_params,
        mesh::DynamicHalfedgeMesh,
        h::IH,
        membranesites,
        speciesindex::Int,
        func_membranespeciespotentialenergy::Func
    )::ReactionInfo where {Func}

    vfrom = target(mesh, oppo(mesh, h))
    vto = target(mesh, h)
    change_membranediffusingspeciescount!(; rdme, memdiff_bulks_index, map_speciesindex_membranesites, β, membrane_species_params, mesh, v = vfrom, speciesindex, membranesites, Δcount = -1, func_membranespeciespotentialenergy)
    change_membranediffusingspeciescount!(; rdme, memdiff_bulks_index, map_speciesindex_membranesites, β, membrane_species_params, mesh, v = vto,   speciesindex, membranesites, Δcount = +1, func_membranespeciespotentialenergy)
    ReactionInfo(reactiontype=:membranediffusion)
end

"""
Do a membrane site reaction, return the reaction info.

Note:
- Any other (compartment) diffusing species involved will be updated in main RDME sampler, not here.
"""
function do_membranesitereaction!(;
        rdme::RDMESampler,
        memdiff_bulks_index::Integer,
        map_speciesindex_membranesites,
        β::Real,
        membrane_species_params,
        mesh::DynamicHalfedgeMesh,
        v::IV,
        membranesites,
        siteindex::Integer,
        func_membranespeciespotentialenergy::Func
    )::ReactionInfo where {Func}

    stoichs = get_stoich(membranesites[siteindex].site)
    for (speciesindex, Δcount) ∈ stoichs
        if Δcount != 0
            change_membranediffusingspeciescount!(; rdme, memdiff_bulks_index, map_speciesindex_membranesites, β, membrane_species_params, mesh, v, speciesindex, membranesites, Δcount, func_membranespeciespotentialenergy)
        end
    end
    ReactionInfo(reactiontype=:membranesite)
end



"""
Full but slow check of membrane diffusion propensity consistency.
"""
function fullcheck_membranediffusion_consistency(m::DynamicHalfedgeMesh)
    msg::String = ""

    nv = length(m.vertices)
    nspecies = m |> get_numdiffusingspecies

    # Report at most x inconsistencies.
    max_nvertex_inconsistent_report = 10
    nvertex_inconsistent = 0
    for vindex ∈ 1:nv
        v = IV(vindex)

        local out_a_total::Q31f32 = 0
        for h ∈ HalfedgesTargetingVertex(m, v)
            ho = oppo(m, h)
            for sindex ∈ 1:nspecies
                out_a_total += getproperty(m.halfedges.attr.diffusion_a, sindex)[ho.value]
            end
        end

        local out_a_total_recorded = m.vertices.attr.outdiffusion_a[vindex]
        if out_a_total != out_a_total_recorded
            nvertex_inconsistent += 1
            if nvertex_inconsistent <= max_nvertex_inconsistent_report
                msg *= "Vertex $(v.value) records outward diffusion propensity $out_a_total_recorded, but the actual sum in halfedges is $out_a_total.\n"
            end
        end
    end
    if nvertex_inconsistent > max_nvertex_inconsistent_report
        msg *= "... and $(max_nvertex_inconsistent_report - nvertex_inconsistent) more inconsistencies.\n"
    end

    diffu_total_a::Q31f32 = 0
    diffu_max_a::Q31f32 = 0
    for vindex ∈ 1:nv
        local outdiffu = m.vertices.attr.outdiffusion_a[vindex]
        diffu_total_a += outdiffu
        diffu_max_a = max(diffu_max_a, outdiffu)
    end
    if diffu_total_a != m.metaattr.total_membranediffusion_a
        msg *= "Membrane diffusion total propensity record is $(m.metaattr.total_membranediffusion_a), but the sum from vertex records is actually $diffu_total_a.\n"
    end
    if diffu_max_a != m.metaattr.max_vertexoutdiffusion_a
        msg *= "Membrane vertex out-diffusion max propensity record is $(m.metaattr.max_vertexoutdiffusion_a), but the max from vertex records is actually $diffu_max_a.\n"
    end

    msg
end

"""
The membrane diffusion is interfaced as one bulk reaction callback.
Total propensity is the reactant count, so it is not registered in the callback.
"""
struct MembraneDiffusionBulkCallback
end

# `c` is context.
function (cb::MembraneDiffusionBulkCallback)(c)
    nspecies = c.membranes |> eltype |> get_numdiffusingspecies
    u = c.chemistryengine.bulkcounts[c.memdiff_bulks_index] * rand()
    for m ∈ c.membranes
        u -= m.metaattr.total_membranediffusion_a
        if u <= 0
            while true
                # Pick a random vertex.
                vindex = rand(1:length(m.vertices))
                u2 = m.metaattr.max_vertexoutdiffusion_a * rand()
                a = m.vertices.attr.outdiffusion_a[vindex]
                # Reject and repeat.
                if u2 <= a
                    for h ∈ HalfedgesTargetingVertex(m, IV(vindex))
                        ho = oppo(m, h)
                        for speciesindex ∈ 1:nspecies
                            u2 -= getproperty(m.halfedges.attr.diffusion_a, speciesindex)[ho.value]
                            if u2 <= 0
                                c.stats.chem_membranediffusing_count += 1
                                return do_membranediffusionreaction!(;
                                    rdme = c.chemistryengine,
                                    c.memdiff_bulks_index,
                                    map_speciesindex_membranesites = c.map_membranediffusingspeciesindex_membranesiteindices,
                                    c.β,
                                    c.membrane_species_params,
                                    mesh = m,
                                    h = ho,
                                    c.membranesites,
                                    speciesindex,
                                    c.func_membranespeciespotentialenergy
                                )
                            end
                        end
                    end
                end
            end
        end
    end

    error("No membrane reaction filed, but one should have.")
end

"""
The membrane diffusion interface is one bulk reaction as well as its callback in the main system.
This function adds that bulk reaction.
"""
function add_membranediffusion_asbulkreaction!(s::SysDef)
    # Get mock bulk species index.
    if :__MEDYAN_MEMDIFF_BULK ∈ keys(s.bulkspecies_indexmap)
        error(":__MEDYAN_MEMDIFF_BULK already exists as a bulk species name.")
    end
    memdiff_bulks_index = length(s.bulkspecies_indexmap)+1
    insert!(s.bulkspecies_indexmap, :__MEDYAN_MEMDIFF_BULK, memdiff_bulks_index)

    # Add mock bulk reaction.
    addreactioncallback!(
        s,
        BulkReaction(
            [(id=memdiff_bulks_index, amount=1)],
            [],
            1.0
        ),
        MembraneDiffusionBulkCallback()
    )
end

"""
The membrane site reaction is interfaced as a compartment reaction callback.

When this callback is invoked, the following up-to-date data is required:
- Correct individual site count contribution, matching the total site count.
- Vertices are correctly assigned to various compartments.
- Membrane geometries, as it is needed by energy computation function.
"""
struct MembraneSiteReactionCallbackDiffusion
    siteindex::Int

    "pairs of id and net change amount"
    diffusing_net_stoich::Vector{Pair{Int,Int}}
end

# `c` is context.
function (cb::MembraneSiteReactionCallbackDiffusion)(c, cid)
    # Find fixed species ID where the site count is stored.
    fxsid = c.membranesites[cb.siteindex].fxsid

    # Sample based on contribution to the total site count.
    u = c.chemistryengine.fixedcounts[fxsid, cid] * rand()
    for vertexname ∈ c.compartments[cid].vertexnames
        local m = c.membranes[vertexname.membraneindex]
        local vindex = m.metaattr.id2index_vertex[vertexname.vid]
        # Get contribution of site count in this vertex.
        contrib = getproperty(m.vertices.attr.contrib_membranesitecount, cb.siteindex)[vindex]
        u -= contrib
        if u <= 0
            # Found the actual site.
            c.stats.chem_membranesite_count += 1
            for (id, amount) in cb.diffusing_net_stoich
                chem_adddiffusingcount!(c, id, cid, amount)
            end
            return do_membranesitereaction!(;
                rdme = c.chemistryengine,
                c.memdiff_bulks_index,
                map_speciesindex_membranesites = c.map_membranediffusingspeciesindex_membranesiteindices,
                c.β,
                c.membrane_species_params,
                mesh = m,
                v = IV(vindex),
                c.membranesites,
                cb.siteindex,
                c.func_membranespeciespotentialenergy
            )
        end
    end

    error("No membrane reaction filed, but one should have.")
end


function errorcheck_addcallback(cb::MembraneSiteReactionCallbackDiffusion,s::MEDYAN.SysDef)
    s.membranesite[cb.siteindex]
    errorcheck_diffusing_species_exist(cb.diffusing_net_stoich,s)
end