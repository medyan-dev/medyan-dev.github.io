using Setfield
using StaticArrays
using StructArrays
using MutatePlainDataArray


struct MeshElementIndex{T}
    value::Int64
end

const IV = MeshElementIndex{:vertex}
const IH = MeshElementIndex{:halfedge}
const IE = MeshElementIndex{:edge}
const IT = MeshElementIndex{:triangle}
const IB = MeshElementIndex{:border}

@enum PolygonType pt_triangle pt_border

"""
Default mesh attributes for debug purpose. At least one field must be defined for `StructArrays` to unwrap it properly.
"""
struct DefaultHalfedgeMeshElementAttr
    placeholder::Nothing
end


"""
Given an attribute type, return the unwrap function used in StructArrays.
"""
function func_attr_unwrap(::Type{AttrType}) where AttrType
    t -> t <: AttrType
end


struct DynamicHalfedgeMeshConnectionVertex
    "A halfedge targeting the vertex."
    halfedge_index ::IH
    "Number of neighbors."
    degree         ::Int64
    "0: vertex is inside, 1: vertex is on the border, >=2: pathological."
    num_targeting_border_halfedges ::Int8
end
struct DynamicHalfedgeMeshConnectionHalfedge
    polygon_type            ::PolygonType
    polygon_index           ::Int64
    target_vertex_index     ::IV
    opposite_halfedge_index ::IH
    next_halfedge_index     ::IH
    prev_halfedge_index     ::IH
    edge_index              ::IE
end
struct DynamicHalfedgeMeshConnectionEdge
    halfedge_index ::IH
    "0: edge is inside, 1: edge is on the border, 2: pathological."
    num_border_halfedges ::Int8
end
struct DynamicHalfedgeMeshConnectionTriangle
    halfedge_index ::IH
end
struct DynamicHalfedgeMeshConnectionBorder
    halfedge_index ::IH
end


"""
Halfedge based mesh that can be changed dynamically.
"""
struct DynamicHalfedgeMesh{SAV, SAH, SAE, SAT, SAB, MA}

    vertices  :: SAV
    halfedges :: SAH
    edges     :: SAE
    triangles :: SAT
    borders   :: SAB

    metaattr  :: MA
end

"Create empty mesh. Meta attribute must be initialized."
function DynamicHalfedgeMesh(::Type{VA}, ::Type{HA}, ::Type{EA}, ::Type{TA}, ::Type{BA}, ma::MA) where {VA, HA, EA, TA, BA, MA}
    DynamicHalfedgeMesh(
        StructArray(@NamedTuple{conn::DynamicHalfedgeMeshConnectionVertex,   attr::VA}[], unwrap = func_attr_unwrap(VA)),
        StructArray(@NamedTuple{conn::DynamicHalfedgeMeshConnectionHalfedge, attr::HA}[], unwrap = func_attr_unwrap(HA)),
        StructArray(@NamedTuple{conn::DynamicHalfedgeMeshConnectionEdge,     attr::EA}[], unwrap = func_attr_unwrap(EA)),
        StructArray(@NamedTuple{conn::DynamicHalfedgeMeshConnectionTriangle, attr::TA}[], unwrap = func_attr_unwrap(TA)),
        StructArray(@NamedTuple{conn::DynamicHalfedgeMeshConnectionBorder,   attr::BA}[], unwrap = func_attr_unwrap(BA)),
        ma,
    )
end


# Obtain element types.
function attrtype_vertex(::Type{DynamicHalfedgeMesh{SAV,SAH,SAE,SAT,SAB,MA}}) where {SAV,SAH,SAE,SAT,SAB,MA}
    fieldtypes(eltype(SAV))[2]
end
function attrtype_halfedge(::Type{DynamicHalfedgeMesh{SAV,SAH,SAE,SAT,SAB,MA}}) where {SAV,SAH,SAE,SAT,SAB,MA}
    fieldtypes(eltype(SAH))[2]
end
function attrtype_edge(::Type{DynamicHalfedgeMesh{SAV,SAH,SAE,SAT,SAB,MA}}) where {SAV,SAH,SAE,SAT,SAB,MA}
    fieldtypes(eltype(SAE))[2]
end
function attrtype_triangle(::Type{DynamicHalfedgeMesh{SAV,SAH,SAE,SAT,SAB,MA}}) where {SAV,SAH,SAE,SAT,SAB,MA}
    fieldtypes(eltype(SAT))[2]
end
function attrtype_border(::Type{DynamicHalfedgeMesh{SAV,SAH,SAE,SAT,SAB,MA}}) where {SAV,SAH,SAE,SAT,SAB,MA}
    fieldtypes(eltype(SAB))[2]
end
function attrtype_meta(::Type{DynamicHalfedgeMesh{SAV,SAH,SAE,SAT,SAB,MA}}) where {SAV,SAH,SAE,SAT,SAB,MA}
    MA
end

attrtype_vertex(m::DynamicHalfedgeMesh) = attrtype_vertex(typeof(m))
attrtype_halfedge(m::DynamicHalfedgeMesh) = attrtype_halfedge(typeof(m))
attrtype_edge(m::DynamicHalfedgeMesh) = attrtype_edge(typeof(m))
attrtype_triangle(m::DynamicHalfedgeMesh) = attrtype_triangle(typeof(m))
attrtype_border(m::DynamicHalfedgeMesh) = attrtype_border(typeof(m))
attrtype_meta(m::DynamicHalfedgeMesh) = attrtype_meta(typeof(m))


function Base.show(io::IO, ::Type{<:MEDYAN.DynamicHalfedgeMesh})
    print(io, "MEDYAN.DynamicHalfedgeMesh{A bunch of type parameters}")
end
function Base.show(io::IO, ::Type{MEDYAN.DynamicHalfedgeMesh})
    print(io, "MEDYAN.DynamicHalfedgeMesh")
end

"""
Helper to register triangle.
"""
Base.@propagate_inbounds function register_triangle!(m::DynamicHalfedgeMesh, ti::IT, hi1::IH, hi2::IH, hi3::IH)
    ts = m.triangles
    hs = m.halfedges
    aref(ts.conn)[ti.value].halfedge_index[] = hi1
    aref(hs.conn)[hi1.value].next_halfedge_index[] = hi2
    aref(hs.conn)[hi1.value].prev_halfedge_index[] = hi3
    aref(hs.conn)[hi1.value].polygon_index[] = ti.value
    aref(hs.conn)[hi1.value].polygon_type[] = pt_triangle
    aref(hs.conn)[hi2.value].next_halfedge_index[] = hi3
    aref(hs.conn)[hi2.value].prev_halfedge_index[] = hi1
    aref(hs.conn)[hi2.value].polygon_index[] = ti.value
    aref(hs.conn)[hi2.value].polygon_type[] = pt_triangle
    aref(hs.conn)[hi3.value].next_halfedge_index[] = hi1
    aref(hs.conn)[hi3.value].prev_halfedge_index[] = hi2
    aref(hs.conn)[hi3.value].polygon_index[] = ti.value
    aref(hs.conn)[hi3.value].polygon_type[] = pt_triangle
end

"""
Helper to register edge.
"""
Base.@propagate_inbounds function register_edge!(m::DynamicHalfedgeMesh, ei::IE, hi1::IH, hi2::IH)
    es = m.edges
    hs = m.halfedges
    aref(es.conn)[ei.value].halfedge_index[] = hi1
    aref(es.conn)[ei.value].num_border_halfedges[] = (hs.conn[hi1.value].polygon_type == pt_border ? 1 : 0) + (hs.conn[hi2.value].polygon_type == pt_border ? 1 : 0)
    aref(hs.conn)[hi1.value].opposite_halfedge_index[] = hi2
    aref(hs.conn)[hi1.value].edge_index[] = ei
    aref(hs.conn)[hi2.value].opposite_halfedge_index[] = hi1
    aref(hs.conn)[hi2.value].edge_index[] = ei
end

"Get target vertex index of halfedge."
target(m::DynamicHalfedgeMesh, i::IH) = m.halfedges.conn[i.value].target_vertex_index
"Get edge index of halfedge."
edge(m::DynamicHalfedgeMesh, i::IH)   = m.halfedges.conn[i.value].edge_index
"Get next halfedge index of halfedge."
next(m::DynamicHalfedgeMesh, i::IH)   = m.halfedges.conn[i.value].next_halfedge_index
"Get prev halfedge index of halfedge."
prev(m::DynamicHalfedgeMesh, i::IH)   = m.halfedges.conn[i.value].prev_halfedge_index
"Get opposite halfedge index of halfedge."
oppo(m::DynamicHalfedgeMesh, i::IH)   = m.halfedges.conn[i.value].opposite_halfedge_index
"Get (type=<polygon-type>, index=<polygon-index>) of a given halfedge."
function polygon(m::DynamicHalfedgeMesh, i::IH)
    (type = m.halfedges.conn[i.value].polygon_type, index = m.halfedges.conn[i.value].polygon_index)
end
"Get triangle index of halfedge."
function triangle(m::DynamicHalfedgeMesh, i::IH)
    poly = polygon(m, i)
    @assert poly.type == pt_triangle
    IT(poly.index)
end
"Get border index of halfedge."
function border(m::DynamicHalfedgeMesh, i::IH)
    poly = polygon(m, i)
    @assert poly.type == pt_border
    IB(poly.index)
end

"Get halfedge record."
function halfedge(m::DynamicHalfedgeMesh, i::IV)
    m.vertices.conn[i.value].halfedge_index
end
"Get halfedge record."
function halfedge(m::DynamicHalfedgeMesh, i::IE)
    m.edges.conn[i.value].halfedge_index
end
"Get halfedge record."
function halfedge(m::DynamicHalfedgeMesh, i::IT)
    m.triangles.conn[i.value].halfedge_index
end
"Get halfedge record."
function halfedge(m::DynamicHalfedgeMesh, i::IB)
    m.borders.conn[i.value].halfedge_index
end

"Whether a vertex is on border."
function onborder(m::DynamicHalfedgeMesh, i::IV)
    m.vertices.conn[i.value].num_targeting_border_halfedges > 0
end
"Whether an edge is on border."
function onborder(m::DynamicHalfedgeMesh, i::IE)
    m.edges.conn[i.value].num_border_halfedges > 0
end
"Whether a halfedge is on border."
function onborder(m::DynamicHalfedgeMesh, i::IH)
    m.halfedges.conn[i.value].polygon_type == pt_border
end

"Get degree of vertex."
function degree(m::DynamicHalfedgeMesh, i::IV)
    m.vertices.conn[i.value].degree
end

# Partial applications.
target(m::DynamicHalfedgeMesh) = i -> target(m, i)
edge(m::DynamicHalfedgeMesh) = i -> edge(m, i)
next(m::DynamicHalfedgeMesh) = i -> next(m, i)
prev(m::DynamicHalfedgeMesh) = i -> prev(m, i)
oppo(m::DynamicHalfedgeMesh) = i -> oppo(m, i)
polygon(m::DynamicHalfedgeMesh) = i -> polygon(m, i)
triangle(m::DynamicHalfedgeMesh) = i -> triangle(m, i)
border(m::DynamicHalfedgeMesh) = i -> border(m, i)

halfedge(m::DynamicHalfedgeMesh) = i -> halfedge(m, i)

onborder(m::DynamicHalfedgeMesh) = i -> onborder(m, i)
degree(m::DynamicHalfedgeMesh) = i -> degree(m, i)



"""
Iterator of all halfedges targeting a vertex.
$(TYPEDFIELDS)
"""
struct HalfedgesTargetingVertex{Mesh}
    m::Mesh
    i::IV
end
function Base.iterate(hs::HalfedgesTargetingVertex)
    h0 = hs.m.vertices.conn[hs.i.value].halfedge_index
    (h0, (; h0, h = h0 |> oppo(hs.m) |> prev(hs.m)))
end
function Base.iterate(hs::HalfedgesTargetingVertex, state)
    if state.h != state.h0
        (state.h, (; state.h0, h = state.h |> oppo(hs.m) |> prev(hs.m)))
    else
        nothing
    end
end


"""
Iterator of all halfedges in a triangle.
$(TYPEDFIELDS)
"""
struct HalfedgesInTriangle{Mesh}
    m::Mesh
    i::IT
end
function Base.iterate(hs::HalfedgesInTriangle)
    h0 = hs.m.triangles.conn[hs.i.value].halfedge_index
    (h0, (; h0, h = h0 |> next(hs.m)))
end
function Base.iterate(hs::HalfedgesInTriangle, state)
    if state.h != state.h0
        (state.h, (; state.h0, h = state.h |> next(hs.m)))
    else
        nothing
    end
end


"""
Iterator of all halfedges in a border.
$(TYPEDFIELDS)
"""
struct HalfedgesInBorder{Mesh}
    m::Mesh
    i::IB
end
function Base.iterate(hs::HalfedgesInBorder)
    h0 = hs.m.borders.conn[hs.i.value].halfedge_index
    (h0, (; h0, h = h0 |> next(hs.m)))
end
function Base.iterate(hs::HalfedgesInBorder, state)
    if state.h != state.h0
        (state.h, (; state.h0, h = state.h |> next(hs.m)))
    else
        nothing
    end
end


"""
Iterator of both halfedges on an edge.
$(TYPEDFIELDS)
"""
struct HalfedgesInEdge{Mesh}
    m::Mesh
    i::IE
end
function Base.iterate(hs::HalfedgesInEdge)
    h0 = hs.m.edges.conn[hs.i.value].halfedge_index
    (h0, (; h0, used=false))
end
function Base.iterate(hs::HalfedgesInEdge, state)
    if state.used
        nothing
    else
        (state.h0 |> oppo(hs.m), (; state.h0, used=true))
    end
end


"""
Slow utility function. Should not be used in core.
Finds the halfedge from vertex 1 to vertex 2.
If no such halfedge is found, returns nothing.
"""
function halfedge(m::DynamicHalfedgeMesh, vfrom::IV, vto::IV)::Union{Nothing, IH}
    for h ∈ HalfedgesTargetingVertex(m, vfrom)
        # Candidate halfedge.
        ho = oppo(m, h)
        vo = target(m, ho)
        if vo == vto
            return ho
        end
    end
    nothing
end

"""
Slow utility function. Should not be used in core.
Finds the edge connecting vertex 1 and vertex 2.
If no such edge is found, returns nothing.
"""
function edge(m::DynamicHalfedgeMesh, v1::IV, v2::IV)::Union{Nothing, IE}
    h = halfedge(m, v1, v2)
    isnothing(h) ? nothing : edge(m, h)
end



"""
Does NOT initialize any attributes.

`trilist` contains 1-based vertex indices.
"""
function initmesh!_vertex_triangle(m::DynamicHalfedgeMesh, nv::Int64, trilist::Vector{SVector{3, Int}})
    vs = m.vertices
    ts = m.triangles
    hs = m.halfedges
    es = m.edges
    bs = m.borders

    nt = length(trilist)
    resize!(vs, nv)
    resize!(ts, nt)

    estimated_nh = 3 * nt
    empty!(hs)
    empty!(es)
    empty!(bs)
    sizehint!(hs, estimated_nh)
    sizehint!(es, estimated_nh ÷ 2)

    # Vertex additional info.
    vai = [
        (
            has_targeting_halfedge = false,
            leaving_halfedge_indices = IH[],
        )
        for vi ∈ 1:nv
    ]
    # Halfedge additional info.
    hai = @NamedTuple{atborder::Bool, opposite_border_created::Bool}[]
    sizehint!(hai, estimated_nh)

    # Reset targeting border halfedge counter.
    for vi ∈ 1:nv
        aref(vs.conn)[vi].num_targeting_border_halfedges[] = 0
    end

    # Build connection info by inserting new halfedges.
    # The newly added halfedges are always in triangle, but might be at the border if no opposite halfedge is found.
    for ti ∈ 1:nt
        tris = trilist[ti]
        # Set halfedge index to be the next inserted.
        aref(ts.conn)[ti].halfedge_index[] = IH(length(hs) + 1)

        for i ∈ 1:3
            # Insert a new halfedge.
            resize!(hs, length(hs) + 1)
            hi = length(hs)
            vi = tris[i]
            push!(hai, (atborder=true, opposite_border_created=false))

            aref(hs.conn)[hi].polygon_type[] = pt_triangle
            aref(hs.conn)[hi].polygon_index[] = ti
            aref(hs.conn)[hi].target_vertex_index[] = IV(vi)
            aref(hs.conn)[hi].next_halfedge_index[] = IH(i == 3 ? hi - 2 : hi + 1)
            aref(hs.conn)[hi].prev_halfedge_index[] = IH(i == 1 ? hi + 2 : hi - 1)
            aref(vs.conn)[vi].num_targeting_border_halfedges[] += 1

            # Remember this edge in the vertices.
            left_vertex_index = tris[i == 1 ? 3 : i - 1]
            push!(vai[left_vertex_index].leaving_halfedge_indices, IH(hi))

            # Search in the target vertex whether there's an opposite halfedge leaving.
            let
                hio_index = findfirst(vai[vi].leaving_halfedge_indices) do leaving_hi
                    target(m, leaving_hi) == IV(left_vertex_index)
                end
                if isnothing(hio_index)
                    # Opposite not found.
                    resize!(es, length(es) + 1)
                    new_ei = length(es)
                    aref(es.conn)[new_ei].halfedge_index[] = IH(hi)
                    aref(es.conn)[new_ei].num_border_halfedges[] = 1
                    aref(hs.conn)[hi].edge_index[] = IE(new_ei)
                else
                    # Opposite found.
                    hio = vai[vi].leaving_halfedge_indices[hio_index].value
                    aref(hai)[hi].atborder[] = false
                    aref(hs.conn)[hi].opposite_halfedge_index[] = IH(hio)
                    aref(hs.conn)[hi].edge_index[] = edge(m, IH(hio))

                    aref(hai)[hio].atborder[] = false
                    aref(hs.conn)[hio].opposite_halfedge_index[] = IH(hi)

                    aref(es.conn)[edge(m, IH(hi)).value].num_border_halfedges[] = 0
                    aref(vs.conn)[vi].num_targeting_border_halfedges[] -= 1
                    aref(vs.conn)[target(m, IH(hio)).value].num_targeting_border_halfedges[] -= 1
                end
            end

            # Set vertex halfedge index.
            if !vai[vi].has_targeting_halfedge
                aref(vs.conn)[vi].halfedge_index[] = IH(hi)
                aref(vai)[vi].has_targeting_halfedge[] = true                        
            end
        end # End loop halfedges.
    end # End loop triangles.

    # Check for pathological vertices where number of border halfedges targeting this edge is more than 1.
    let patho_vs = Tuple{Int, Int8}[]
        for vi ∈ 1:nv
            if vs.conn[vi].num_targeting_border_halfedges > 1
                push!(patho_vs, (vi, vs.conn[vi].num_targeting_border_halfedges))
            end
        end
        if length(patho_vs) > 0
            error("The following vertices have more than one targeting border halfedge:\n$(join(["$(v[1]):$(v[2])" for v ∈ patho_vs], ' '))\n")
        end
    end

    # Make borders.
    let
        """
        Method of finding the next halfedge inside border.
        """
        function findnextin(hi_b_cur::IH)
            hi_in = hi_b_cur |> oppo(m) |> prev(m)
            while !hai[hi_in.value].atborder
                hi_in = hi_in |> oppo(m) |> prev(m)
            end
            hi_in
        end

        """
        Method of associating a new border halfedge with vertices, edges and the border.
        """
        function register_border_halfedge(hi_b::IH, hi_in::IH, bi::IB)
            aref(hs.conn)[hi_b.value].polygon_type[] = pt_border
            aref(hs.conn)[hi_b.value].polygon_index[] = bi.value
            aref(hs.conn)[hi_b.value].target_vertex_index[] = hi_in |> prev(m) |> target(m)
            register_edge!(m, edge(m, hi_in), hi_in, hi_b)
            push!(vai[target(m, hi_in).value].leaving_halfedge_indices, hi_b)
        end

        """
        Method of associating 2 consecutive halfedges.
        """
        function connect_border_halfedge(hi_b_cur::IH, hi_b_last::IH)
            aref(hs.conn)[hi_b_cur.value].prev_halfedge_index[] = hi_b_last
            aref(hs.conn)[hi_b_last.value].next_halfedge_index[] = hi_b_cur
        end

        cur_nh = length(hs)
        for hi ∈ 1:cur_nh
            if hai[hi].atborder && !hai[hi].opposite_border_created
                hi_in_cur = IH(hi)

                # Create first border halfedge.
                resize!(hs, length(hs) + 1)
                hi_b_first = IH(length(hs))
                aref(hai)[hi_in_cur.value].opposite_border_created[] = true
                hi_b_cur = hi_b_first
                hi_b_last = hi_b_first

                # Create a border object.
                resize!(bs, length(bs) + 1)
                bi = IB(length(bs))
                aref(bs.conn)[bi.value].halfedge_index[] = hi_b_first
                register_border_halfedge(hi_b_first, hi_in_cur, bi)

                # Sequentially create border halfedges.
                hi_in_cur = findnextin(hi_b_cur)
                while hi_in_cur != IH(hi)
                    resize!(hs, length(hs) + 1)
                    hi_b_cur = IH(length(hs))
                    aref(hai)[hi_in_cur.value].opposite_border_created[] = true

                    register_border_halfedge(hi_b_cur, hi_in_cur, bi)
                    connect_border_halfedge(hi_b_cur, hi_b_last)

                    hi_b_last = hi_b_cur
                    hi_in_cur = findnextin(hi_b_cur)
                end
                connect_border_halfedge(hi_b_first, hi_b_last)
            end
        end # End loop halfedges for making borders.
    end # End making border.

    # Register vertex degrees and check for vertex connection.
    unused_vs = Int[]
    for vi ∈ 1:nv
        aref(vs.conn)[vi].degree[] = length(vai[vi].leaving_halfedge_indices)
        if vs.conn[vi].degree == 0
            push!(unused_vs, vi)
        end
    end
    if length(unused_vs) > 0
        error("The following vertices are unused:\n$(join(unused_vs, ' '))\n")
    end

end


# Mesh modification functions, which breaks the mesh structural consistency.
# These functions are used in the mesh modification functions, which then reconnect the mesh.
function inconsistent_newvertex!(initattr!_vertex, m::DynamicHalfedgeMesh)
    resize!(m.vertices, length(m.vertices)+1)
    i = IV(length(m.vertices))
    initattr!_vertex(m, i)
    i
end
function inconsistent_newedge!(initattr!_edge, m::DynamicHalfedgeMesh)
    resize!(m.edges, length(m.edges)+1)
    i = IE(length(m.edges))
    initattr!_edge(m, i)
    i
end
function inconsistent_newhalfedge!(initattr!_halfedge, m::DynamicHalfedgeMesh)
    resize!(m.halfedges, length(m.halfedges)+1)
    i = IH(length(m.halfedges))
    initattr!_halfedge(m, i)
    i
end
function inconsistent_newtriangle!(initattr!_triangle, m::DynamicHalfedgeMesh)
    resize!(m.triangles, length(m.triangles)+1)
    i = IT(length(m.triangles))
    initattr!_triangle(m, i)
    i
end
function inconsistent_newborder!(initattr!_border, m::DynamicHalfedgeMesh)
    resize!(m.borders, length(m.borders)+1)
    i = IB(length(m.borders))
    initattr!_border(m, i)
    i
end

function inconsistent_retargetvertex!(m::DynamicHalfedgeMesh, from::IV, to::IV)
    for h ∈ HalfedgesTargetingVertex(m, to)
        aref(m.halfedges.conn)[h.value].target_vertex_index[] = to
    end
end
function inconsistent_retargetedge!(m::DynamicHalfedgeMesh, from::IE, to::IE)
    for h ∈ HalfedgesInEdge(m, to)
        aref(m.halfedges.conn)[h.value].edge_index[] = to
    end
end
function inconsistent_retargethalfedge!(m::DynamicHalfedgeMesh, from::IH, to::IH)
    aref(m.halfedges.conn)[oppo(m, to).value].opposite_halfedge_index[] = to

    pt = polygon(m, to).type
    if pt == pt_triangle
        let t = triangle(m, to)
            if m.triangles.conn[t.value].halfedge_index == from
                aref(m.triangles.conn)[t.value].halfedge_index[] = to
            end
        end
    else
        let b = border(m, to)
            if m.borders.conn[b.value].halfedge_index == from
                aref(m.borders.conn)[b.value].halfedge_index[] = to
            end
        end
    end

    let v = target(m, to)
        if m.vertices.conn[v.value].halfedge_index == from
            aref(m.vertices.conn)[v.value].halfedge_index[] = to
        end
    end
    let e = edge(m, to)
        if m.edges.conn[e.value].halfedge_index == from
            aref(m.edges.conn)[e.value].halfedge_index[] = to
        end
    end
    aref(m.halfedges.conn)[next(m, to).value].prev_halfedge_index[] = to
    aref(m.halfedges.conn)[prev(m, to).value].next_halfedge_index[] = to
end
function inconsistent_retargettriangle!(m::DynamicHalfedgeMesh, from::IT, to::IT)
    for h ∈ HalfedgesInTriangle(m, to)
        aref(m.halfedges.conn)[h.value].polygon_index[] = to.value
    end
end
function inconsistent_retargetborder!(m::DynamicHalfedgeMesh, from::IB, to::IB)
    for h ∈ HalfedgesInBorder(m, to)
        aref(m.halfedges.conn)[h.value].polygon_index[] = to.value
    end
end


function inconsistent_removevertices!(m::DynamicHalfedgeMesh, i::Vararg{IV,N}) where N
    swaperase!(m.vertices, getproperty.(i, :value)...) do ifrom, ito
        inconsistent_retargetvertex!(m, IV(ifrom), IV(ito))
    end
end
function inconsistent_removeedges!(m::DynamicHalfedgeMesh, i::Vararg{IE,N}) where N
    swaperase!(m.edges, getproperty.(i, :value)...) do ifrom, ito
        inconsistent_retargetedge!(m, IE(ifrom), IE(ito))
    end
end
function inconsistent_removehalfedges!(m::DynamicHalfedgeMesh, i::Vararg{IH,N}) where N
    swaperase!(m.halfedges, getproperty.(i, :value)...) do ifrom, ito
        inconsistent_retargethalfedge!(m, IH(ifrom), IH(ito))
    end
end
function inconsistent_removetriangles!(m::DynamicHalfedgeMesh, i::Vararg{IT,N}) where N
    swaperase!(m.triangles, getproperty.(i, :value)...) do ifrom, ito
        inconsistent_retargettriangle!(m, IT(ifrom), IT(ito))
    end
end
function inconsistent_removeborders!(m::DynamicHalfedgeMesh, i::Vararg{IB,N}) where N
    swaperase!(m.borders, getproperty.(i, :value)...) do ifrom, ito
        inconsistent_retargetborder!(m, IB(ifrom), IB(ito))
    end
end



"""
Insert a vertex on an edge.

`initattr!` is a named tuple of functions that can initialize attributes of new elements.

Returns a named tuple with the following items:
- vnew: The index of the new vertex.
- told[2]: Old indices of 2 triangles.
- tnew[4]: New indices of 4 triangles.
- hnew[4]: New indices of 4 halfedges.
    - told[1] -> tnew[1], tnew[2]
    - told[2] -> tnew[3], tnew[4]
    - New triangles are arranged in ccw direction.
    - If the insertion happens on the border, the border side triangle info is undefined.
"""
function insert_vertex_onedge!(initattr!, m::DynamicHalfedgeMesh, e::IE)
    res = (
        vnew = IV(0),
        told = @SVector(fill(IT(0), 2)),
        tnew = @SVector(fill(IT(0), 4)),
    )

    # Get index of current elements.
    oh       = m.edges.conn[e.value].halfedge_index
    oh_n     = next(m, oh)
    oh_p     = prev(m, oh)
    oh_o     = oppo(m, oh)
    oh_on    = next(m, oh_o)
    oh_op    = prev(m, oh_o)

    op1      = polygon(m, oh)
    op3      = polygon(m, oh_o)
    ist1     = op1.type == pt_triangle
    ist3     = op3.type == pt_triangle

    if !ist1 && !ist3
        error("During vertex insertion on edge, neither side of the edge is a triangle.")
    end

    # Create new elements.
    v0       = inconsistent_newvertex!(initattr!.vertex, m)
    e3       = inconsistent_newedge!(initattr!.edge, m) # New edge created by splitting.
    h1_o     = inconsistent_newhalfedge!(initattr!.halfedge, m) # Targeting new vertex, oppositing oh.
    h3_o     = inconsistent_newhalfedge!(initattr!.halfedge, m) # Targeting new vertex, oppositing oh_o.

    aref(m.vertices.conn)[v0.value].degree[] = 2
    aref(m.vertices.conn)[v0.value].num_targeting_border_halfedges[] = 0

    if ist1
        ot1   = IT(op1.index)
        v2    = target(m, oh_n)

        e2    = inconsistent_newedge!(initattr!.edge, m) # New edge cutting t1.
        h2    = inconsistent_newhalfedge!(initattr!.halfedge, m) # Leaving new vertex.
        h2_o  = inconsistent_newhalfedge!(initattr!.halfedge, m) # Targeting new vertex.
        t2    = inconsistent_newtriangle!(initattr!.triangle, m)

        aref(m.halfedges.conn)[h2_o.value].target_vertex_index[] = v0
        aref(m.halfedges.conn)[h2_o.value].polygon_type[] = pt_triangle
        aref(m.halfedges.conn)[h2.value].target_vertex_index[] = v2
        aref(m.halfedges.conn)[h2.value].polygon_type[] = pt_triangle

        aref(m.vertices.conn)[v0.value].degree[] += 1
        aref(m.vertices.conn)[v2.value].degree[] += 1

        register_triangle!(m, ot1, oh, oh_n, h2_o)
        register_triangle!(m, t2,  h2, oh_p, h3_o)
        register_edge!(m, e2, h2, h2_o)

        res = @set res.told[1] = ot1
        res = @set res.tnew[1] = ot1
        res = @set res.tnew[2] = t2
    else
        aref(m.halfedges.conn)[oh_p.value].next_halfedge_index[] = h3_o
        aref(m.halfedges.conn)[h3_o.value].next_halfedge_index[] = oh
        aref(m.halfedges.conn)[oh.value].prev_halfedge_index[] = h3_o
        aref(m.halfedges.conn)[h3_o.value].prev_halfedge_index[] = oh_p

        aref(m.halfedges.conn)[h3_o.value].polygon_index[] = op1.index

        aref(m.vertices.conn)[v0.value].num_targeting_border_halfedges[] += 1
    end

    if ist3
        ot3   = IT(op3.index)
        v4    = target(m, oh_on)

        e4    = inconsistent_newedge!(initattr!.edge, m) # New edge cutting t3.
        h4    = inconsistent_newhalfedge!(initattr!.halfedge, m) # Leaving new vertex.
        h4_o  = inconsistent_newhalfedge!(initattr!.halfedge, m) # Targeting new vertex.
        t4    = inconsistent_newtriangle!(initattr!.triangle, m)

        aref(m.halfedges.conn)[h4_o.value].target_vertex_index[] = v0
        aref(m.halfedges.conn)[h4_o.value].polygon_type[] = pt_triangle
        aref(m.halfedges.conn)[h4.value].target_vertex_index[] = v4
        aref(m.halfedges.conn)[h4.value].polygon_type[] = pt_triangle

        aref(m.vertices.conn)[v0.value].degree[] += 1
        aref(m.vertices.conn)[v4.value].degree[] += 1

        register_triangle!(m, ot3, oh_o, oh_on, h4_o)
        register_triangle!(m, t4,  h4,   oh_op, h1_o)
        register_edge!(m, e4, h4, h4_o)

        res = @set res.told[2] = ot3
        res = @set res.tnew[3] = ot3
        res = @set res.tnew[4] = t4
    else
        aref(m.halfedges.conn)[oh_op.value].next_halfedge_index[] = h1_o
        aref(m.halfedges.conn)[h1_o.value].next_halfedge_index[] = oh_o
        aref(m.halfedges.conn)[oh_o.value].prev_halfedge_index[] = h1_o
        aref(m.halfedges.conn)[h1_o.value].prev_halfedge_index[] = oh_op

        aref(m.halfedges.conn)[h1_o.value].polygon_index[] = op3.index

        aref(m.vertices.conn)[v0.value].num_targeting_border_halfedges[] += 1
    end

    # Adjust vertex and new halfedges.
    aref(m.vertices.conn)[v0.value].halfedge_index[] = h1_o

    aref(m.halfedges.conn)[h1_o.value].target_vertex_index[] = v0
    aref(m.halfedges.conn)[h3_o.value].target_vertex_index[] = v0
    aref(m.halfedges.conn)[h1_o.value].polygon_type[] = op3.type
    aref(m.halfedges.conn)[h3_o.value].polygon_type[] = op1.type

    # Adjust edge.
    register_edge!(m, e,  oh,   h1_o)
    register_edge!(m, e3, oh_o, h3_o)

    res = @set res.vnew = v0
    res
end


"""
Collapse an edge along halfedge.

Returns a named tuple with the following items:
- vto: The index of preserved vertex after swapping (target of halfedge).
- vrm: The deletion result of vertex (source of halfedge).

Notes:
- If the edge is not border, at most one vertex can lie on the border.
- Only triangle facing halfedge can initiate the collapse.
"""
function collapse_halfedge!(m::DynamicHalfedgeMesh, oh::IH)
    function collapse_inner!(oe::IE, oh::IH, oh_o::IH)
        oh_n  = next(m, oh)
        oh_p  = prev(m, oh)
        oh_on = next(m, oh_o)
        oh_op = prev(m, oh_o)

        ot1 = triangle(m, oh)
        ot2 = triangle(m, oh_o)
        ov1 = target(m, oh) # Will collapse to this vertex
        ov2 = target(m, oh_o) # Will be removed
        oe1 = edge(m, oh_n) # Will collapse to this edge
        oe2 = edge(m, oh_p) # Will be removed
        oe3 = edge(m, oh_op) # Will collapse on this edge
        oe4 = edge(m, oh_on) # Will be removed

        # Retarget all halfedges pointing v2 to v1.
        let
            hbegin = oppo(m, oh_on) # Changed halfedge begin
            h1 = hbegin
            while h1 != oh_p
                aref(m.halfedges.conn)[h1.value].target_vertex_index[] = ov1
                h1 = h1 |> next(m) |> oppo(m)
            end
            aref(m.vertices.conn)[ov1.value].halfedge_index[] = hbegin
            aref(m.vertices.conn)[target(m, oh_n).value].halfedge_index[] = oppo(m, oh_p)
            aref(m.vertices.conn)[target(m, oh_on).value].halfedge_index[] = oppo(m, oh_op)
        end

        # Collapse edges.
        register_edge!(m, oe1, oppo(m, oh_n), oppo(m, oh_p))
        register_edge!(m, oe3, oppo(m, oh_op), oppo(m, oh_on))

        # Adjust vertex degrees.
        aref(m.vertices.conn)[ov1.value].degree[] += degree(m, ov2) - 4
        aref(m.vertices.conn)[ov1.value].num_targeting_border_halfedges[] += m.vertices.conn[ov2.value].num_targeting_border_halfedges
        aref(m.vertices.conn)[target(m, oh_n).value].degree[] -= 1
        aref(m.vertices.conn)[target(m, oh_on).value].degree[] -= 1

        # Remove elements.
        vrm = inconsistent_removevertices!(m, ov2)
        inconsistent_removeedges!(m, oe, oe2, oe4)
        inconsistent_removehalfedges!(m, oh, oh_n, oh_p,
                                      oh_o, oh_on, oh_op)
        inconsistent_removetriangles!(m, ot1, ot2)

        # Record change info.
        (vto = IV(swaperase_track(vrm, ov1.value)[1]), vrm = vrm)
    end

    function collapse_border!(oe::IE, oh_t::IH, oh_b::IH)
        oh_tn = next(m, oh_t)
        oh_tp = prev(m, oh_t)
        oh_bn = next(m, oh_b)
        oh_bp = prev(m, oh_b)

        ot1 = triangle(m, oh_t)
        ob2 = border(m, oh_b)

        # Edge collapse cannot be done, if the border has only 3 edges.
        if next(m, oh_bn) == oh_bp
            error("In edge collapse, border $(ob2.value) has only 3 edges.")
        end

        ov1 = target(m, oh_t) # Will collapse to this vertex.
        ov2 = target(m, oh_b) # Will be removed.
        oe1 = edge(m, oh_tn) # Will collapse to this edge.
        oe2 = edge(m, oh_tp) # Will be removed.

        # Retarget all halfedges pointing v2 to v1.
        let
            hbegin = oppo(m, oh_bn) # Changed halfedge begin
            h1 = hbegin
            while h1 != oh_tp
                aref(m.halfedges.conn)[h1.value].target_vertex_index[] = ov1
                h1 = h1 |> next(m) |> oppo(m)
            end
            aref(m.vertices.conn)[ov1.value].halfedge_index[] = hbegin
            aref(m.vertices.conn)[target(m, oh_tn).value].halfedge_index[] = oppo(m, oh_tp)
        end

        # Collapse edges.
        register_edge!(m, oe1, oppo(m, oh_tn), oppo(m, oh_tp))

        # Connect borders.
        aref(m.borders.conn)[ob2.value].halfedge_index[] = oh_bn
        aref(m.halfedges.conn)[oh_bn.value].prev_halfedge_index[] = oh_bp
        aref(m.halfedges.conn)[oh_bp.value].next_halfedge_index[] = oh_bn

        # Adjust vertex degrees.
        aref(m.vertices.conn)[ov1.value].degree[] += degree(m, ov2) - 3
        aref(m.vertices.conn)[target(m, oh_tn).value].degree[] -= 1

        # Remove elements.
        vrm = inconsistent_removevertices!(m, ov2)
        inconsistent_removeedges!(m, oe, oe2)
        inconsistent_removehalfedges!(m, oh_t, oh_tn, oh_tp, oh_b)
        inconsistent_removetriangles!(m, ot1)

        # Record change info.
        (vto = IV(swaperase_track(vrm, ov1.value)[1]), vrm = vrm)
    end

    oe = edge(m, oh)
    oh_o = oppo(m, oh)
    ist = polygon(m, oh).type == pt_triangle
    ist_o = polygon(m, oh_o).type == pt_triangle

    if ist
        if ist_o
            return collapse_inner!(oe, oh, oh_o)
        else
            return collapse_border!(oe, oh, oh_o)
        end
    else
        error("During edge collapse, halfedge $(oh.value) does not face a triangle.")
    end
end


"""
Flips an edge.
Note: border edges cannot be flipped.
"""
function flip_edge!(m::DynamicHalfedgeMesh, e::IE)
    oh = halfedge(m, e)
    oh_n = next(m, oh)
    oh_p = prev(m, oh)
    oh_o = oppo(m, oh)
    oh_on = next(m, oh_o)
    oh_op = prev(m, oh_o)
    ov1 = target(m, oh)
    ov2 = target(m, oh_n)
    ov3 = target(m, oh_o)
    ov4 = target(m, oh_on)
    ot1 = triangle(m, oh)
    ot2 = triangle(m, oh_o)

    # Retarget vertices.
    aref(m.halfedges.conn)[oh.value].target_vertex_index[] = ov2
    aref(m.halfedges.conn)[oh_o.value].target_vertex_index[] = ov4
    aref(m.vertices.conn)[ov1.value].halfedge_index[] = oh_op
    aref(m.vertices.conn)[ov3.value].halfedge_index[] = oh_p

    aref(m.vertices.conn)[ov1.value].degree[] -= 1
    aref(m.vertices.conn)[ov3.value].degree[] -= 1
    aref(m.vertices.conn)[ov2.value].degree[] += 1
    aref(m.vertices.conn)[ov4.value].degree[] += 1

    # Remake triangles.
    register_triangle!(m, ot1, oh, oh_p, oh_on)
    register_triangle!(m, ot2, oh_o, oh_op, oh_n)
end


# Default attribute functions for test purpose.
default_initattr! = (
    vertex   = Returns(nothing),
    edge     = Returns(nothing),
    halfedge = Returns(nothing),
    triangle = Returns(nothing),
    border   = Returns(nothing),
)


"""
A thorough but slow check of the consistency of the mesh connections.
"""
function fullcheck_mesh_consistency(m::DynamicHalfedgeMesh)
    msg = ""

    nv = length(m.vertices)
    nh = length(m.halfedges)
    ne = length(m.edges)
    nt = length(m.triangles)
    nb = length(m.borders)

    if ne * 2 != nh
        msg *= "Unmatched: ne=$ne, nh=$nh\n"
    end
    if nb == 0 && (ne * 2 != nt * 3)
        msg *= "Unmatched: in closed mesh, ne=$ne, nt=$nt\n"
    end

    # Check vertices.
    for vindex ∈ 1:nv
        v = IV(vindex)

        # Halfedge record.
        let h = m.vertices.conn[v.value].halfedge_index
            vback = target(m, h)
            if v != vback
                msg *= "Vertex $(v.value) should be targeted by halfedge $(h.value), but it is targeting $(vback.value).\n"
            end
        end

        # Degree record.
        degree = m.vertices.conn[v.value].degree
        degree_border = m.vertices.conn[v.value].num_targeting_border_halfedges
        degree_actual = 0
        degree_border_actual = 0
        for h ∈ HalfedgesTargetingVertex(m, v)
            degree_actual += 1
            if m.halfedges.conn[h.value].polygon_type == pt_border
                degree_border_actual += 1
            end
        end
        if degree != degree_actual
            msg *= "Vertex $(v.value) should have degree $(degree), but it has $(degree_actual).\n"
        end
        if degree_border != degree_border_actual
            msg *= "Vertex $(v.value) should have border degree $(degree_border), but it has $(degree_border_actual).\n"
        end
        if degree_border > 1
            msg *= "Too many border halfedges ($(degree_border)) targeting vertex $(v.value).\n"
        end
    end

    # Check edges.
    for eindex ∈ 1:ne
        e = IE(eindex)

        # Halfedge record.
        let h = m.edges.conn[e.value].halfedge_index
            eback = edge(m, h)
            if e != eback
                msg *= "Edge $(e.value) should be used by halfedge $(h.value), but it is using $(eback.value).\n"
            end
        end

        # Border record.
        nborder = m.edges.conn[e.value].num_border_halfedges
        nborder_actual = 0
        for h ∈ HalfedgesInEdge(m, e)
            if m.halfedges.conn[h.value].polygon_type == pt_border
                nborder_actual += 1
            end
        end
        if nborder != nborder_actual
            msg *= "Edge $(e.value) should have $(nborder) border halfedges, but it has $(nborder_actual).\n"
        end
        if nborder > 1
            msg *= "Too many border halfedges ($(nborder)) on edge $(e.value).\n"
        end
    end

    # Check triangles.
    for tindex ∈ 1:nt
        t = IT(tindex)

        # Halfedge record.
        let h = m.triangles.conn[t.value].halfedge_index
            tback = triangle(m, h)
            if t != tback
                msg *= "Triangle $(t.value) should be used by halfedge $(h.value), but it is using $(tback.value).\n"
            end
        end
    end

    # Check borders.
    for bindex ∈ 1:nb
        b = IB(bindex)

        # Halfedge record.
        let h = m.borders.conn[b.value].halfedge_index
            bback = border(m, h)
            if b != bback
                msg *= "Border $(b.value) should be used by halfedge $(h.value), but it is using $(bback.value).\n"
            end
        end
    end

    # Check halfedges.
    for hindex ∈ 1:nh
        h = IH(hindex)

        # Opposite.
        let ho = oppo(m, h), e = edge(m, h)
            hback = oppo(m, ho)
            if h != hback
                msg *= "Halfedge $(h.value) should be opposite to halfedge $(ho.value), but that is opposite to $(hback.value).\n"
            end

            eo = edge(m, ho)
            if e != eo
                msg *= "Unmatched: $(h.value) uses edge $(e.value), but its opposite $(ho.value) uses edge $(eo.value).\n"
            end
        end

        # Next.
        let hn = next(m, h)
            hback = prev(m, hn)
            if h != hback
                msg *= "Halfedge $(h.value) should have the next halfedge $(hn.value), but that has a prev of $(hback.value).\n"
            end
        end

        # Prev.
        let hp = prev(m, h)
            hback = next(m, hp)
            if h != hback
                msg *= "Halfedge $(h.value) should have the prev halfedge $(hp.value), but that has a next of $(hback.value).\n"
            end
        end
    end

    # Check attributes.
    if length(m.vertices.conn) != length(m.vertices.attr)
        msg *= "Unmatched: vertices has $(length(m.vertices.conn)) connections, but $(length(m.vertices.attr)) attributes.\n"
    end
    if length(m.halfedges.conn) != length(m.halfedges.attr)
        msg *= "Unmatched: halfedges has $(length(m.halfedges.conn)) connections, but $(length(m.halfedges.attr)) attributes.\n"
    end
    if length(m.edges.conn) != length(m.edges.attr)
        msg *= "Unmatched: edges has $(length(m.edges.conn)) connections, but $(length(m.edges.attr)) attributes.\n"
    end
    if length(m.triangles.conn) != length(m.triangles.attr)
        msg *= "Unmatched: triangles has $(length(m.triangles.conn)) connections, but $(length(m.triangles.attr)) attributes.\n"
    end
    if length(m.borders.conn) != length(m.borders.attr)
        msg *= "Unmatched: borders has $(length(m.borders.conn)) connections, but $(length(m.borders.attr)) attributes.\n"
    end

    msg
end


struct StaticHalfedgeMeshConnectionVertex
    "Number of neighbors."
    degree         ::Int64
    onborder       ::Bool
end
struct StaticHalfedgeMeshConnectionHalfedge
    "[source, target, next target]"
    vertex_indices          ::SVector{3, Int}
    polygon_type            ::PolygonType
end
struct StaticHalfedgeMeshConnectionEdge
    "[target of halfedge, opposite target]"
    vertex_indices          ::SVector{2, Int}
    polygon_types           ::SVector{2, PolygonType}
    polygon_indices         ::SVector{2, Int}
end
struct StaticHalfedgeMeshConnectionTriangle
    "[target of halfedge, next target, prev target]"
    vertex_indices          ::SVector{3, Int}
    "[halfedge, next, prev]"
    halfedge_indices        ::SVector{3, Int}
    "[edge of halfedge, next edge, prev edge]"
    edge_indices            ::SVector{3, Int}
end
struct StaticHalfedgeMeshConnectionBorder
end

struct StaticHalfedgeMeshConnectionMeta
    max_vertex_degree       ::Int64

    # A vertex has undetermined number of neighbors, so the cache structure needs to be determined at run-time.
    #
    # The matrix has size #indices x #vertices, where #indices dependes on max_vertex_degree.
    # See accessor functions for the precise meaning of each index.
    indices_nearvertex      ::Matrix{Int}
end

# Notes:
# - The outer halfedge targets the corresponding "neighbor vertex", and is the "prev" of the targeting half edge.
# - The polygon corresponds to the targeting half edge.
function indices_nearvertex_stride(max_vertex_degree::Int)
    max_vertex_degree * 6
end
function mindex_neighbor_vertex(cm::StaticHalfedgeMeshConnectionMeta, in::Int, iv::Int)
    CartesianIndex(in, iv)
end
function mindex_targeting_halfedge(cm::StaticHalfedgeMeshConnectionMeta, in::Int, iv::Int)
    CartesianIndex(in + cm.max_vertex_degree, iv)
end
function mindex_leaving_halfedge(cm::StaticHalfedgeMeshConnectionMeta, in::Int, iv::Int)
    CartesianIndex(in + cm.max_vertex_degree * 2, iv)
end
function mindex_outer_halfedge(cm::StaticHalfedgeMeshConnectionMeta, in::Int, iv::Int)
    CartesianIndex(in + cm.max_vertex_degree * 3, iv)
end
function mindex_targeting_edge(cm::StaticHalfedgeMeshConnectionMeta, in::Int, iv::Int)
    CartesianIndex(in + cm.max_vertex_degree * 4, iv)
end
function mindex_polygon(cm::StaticHalfedgeMeshConnectionMeta, in::Int, iv::Int)
    CartesianIndex(in + cm.max_vertex_degree * 5, iv)
end

"""
Halfedge based mesh that should not be changed dynamically.
"""
struct StaticHalfedgeMesh{SAV, SAH, SAE, SAT, SAB, MA}

    vertices  :: SAV
    halfedges :: SAH
    edges     :: SAE
    triangles :: SAT
    borders   :: SAB

    metaconn  :: StaticHalfedgeMeshConnectionMeta
    metaattr  :: MA
end

function get_neighbor_vertex(m::StaticHalfedgeMesh, in::Int, iv::Int)
    m.metaconn.indices_nearvertex[mindex_neighbor_vertex(m.metaconn, in, iv)]
end
function set_neighbor_vertex!(m::StaticHalfedgeMesh, in::Int, iv::Int, value::Int)
    m.metaconn.indices_nearvertex[mindex_neighbor_vertex(m.metaconn, in, iv)] = value
end
function get_targeting_halfedge(m::StaticHalfedgeMesh, in::Int, iv::Int)
    m.metaconn.indices_nearvertex[mindex_targeting_halfedge(m.metaconn, in, iv)]
end
function set_targeting_halfedge!(m::StaticHalfedgeMesh, in::Int, iv::Int, value::Int)
    m.metaconn.indices_nearvertex[mindex_targeting_halfedge(m.metaconn, in, iv)] = value
end
function get_leaving_halfedge(m::StaticHalfedgeMesh, in::Int, iv::Int)
    m.metaconn.indices_nearvertex[mindex_leaving_halfedge(m.metaconn, in, iv)]
end
function set_leaving_halfedge!(m::StaticHalfedgeMesh, in::Int, iv::Int, value::Int)
    m.metaconn.indices_nearvertex[mindex_leaving_halfedge(m.metaconn, in, iv)] = value
end
function get_outer_halfedge(m::StaticHalfedgeMesh, in::Int, iv::Int)
    m.metaconn.indices_nearvertex[mindex_outer_halfedge(m.metaconn, in, iv)]
end
function set_outer_halfedge!(m::StaticHalfedgeMesh, in::Int, iv::Int, value::Int)
    m.metaconn.indices_nearvertex[mindex_outer_halfedge(m.metaconn, in, iv)] = value
end
function get_targeting_edge(m::StaticHalfedgeMesh, in::Int, iv::Int)
    m.metaconn.indices_nearvertex[mindex_targeting_edge(m.metaconn, in, iv)]
end
function set_targeting_edge!(m::StaticHalfedgeMesh, in::Int, iv::Int, value::Int)
    m.metaconn.indices_nearvertex[mindex_targeting_edge(m.metaconn, in, iv)] = value
end
function get_polygon(m::StaticHalfedgeMesh, in::Int, iv::Int)
    m.metaconn.indices_nearvertex[mindex_polygon(m.metaconn, in, iv)]
end
function set_polygon!(m::StaticHalfedgeMesh, in::Int, iv::Int, value::Int)
    m.metaconn.indices_nearvertex[mindex_polygon(m.metaconn, in, iv)] = value
end


# Obtain element types.
function attrtype_vertex(::Type{StaticHalfedgeMesh{SAV,SAH,SAE,SAT,SAB,MA}}) where {SAV,SAH,SAE,SAT,SAB,MA}
    fieldtypes(eltype(SAV))[2]
end
function attrtype_halfedge(::Type{StaticHalfedgeMesh{SAV,SAH,SAE,SAT,SAB,MA}}) where {SAV,SAH,SAE,SAT,SAB,MA}
    fieldtypes(eltype(SAH))[2]
end
function attrtype_edge(::Type{StaticHalfedgeMesh{SAV,SAH,SAE,SAT,SAB,MA}}) where {SAV,SAH,SAE,SAT,SAB,MA}
    fieldtypes(eltype(SAE))[2]
end
function attrtype_triangle(::Type{StaticHalfedgeMesh{SAV,SAH,SAE,SAT,SAB,MA}}) where {SAV,SAH,SAE,SAT,SAB,MA}
    fieldtypes(eltype(SAT))[2]
end
function attrtype_border(::Type{StaticHalfedgeMesh{SAV,SAH,SAE,SAT,SAB,MA}}) where {SAV,SAH,SAE,SAT,SAB,MA}
    fieldtypes(eltype(SAB))[2]
end
function attrtype_meta(::Type{StaticHalfedgeMesh{SAV,SAH,SAE,SAT,SAB,MA}}) where {SAV,SAH,SAE,SAT,SAB,MA}
    MA
end

attrtype_vertex(m::StaticHalfedgeMesh) = attrtype_vertex(typeof(m))
attrtype_halfedge(m::StaticHalfedgeMesh) = attrtype_halfedge(typeof(m))
attrtype_edge(m::StaticHalfedgeMesh) = attrtype_edge(typeof(m))
attrtype_triangle(m::StaticHalfedgeMesh) = attrtype_triangle(typeof(m))
attrtype_border(m::StaticHalfedgeMesh) = attrtype_border(typeof(m))
attrtype_meta(m::StaticHalfedgeMesh) = attrtype_meta(typeof(m))

function Base.show(io::IO, ::Type{<:MEDYAN.StaticHalfedgeMesh})
    print(io, "MEDYAN.StaticHalfedgeMesh{A bunch of type parameters}")
end
function Base.show(io::IO, ::Type{MEDYAN.StaticHalfedgeMesh})
    print(io, "MEDYAN.StaticHalfedgeMesh")
end


"Get degree of vertex."
function degree(m::StaticHalfedgeMesh, i::IV)
    m.vertices.conn[i.value].degree
end
"Whether the vertex is on border."
function onborder(m::StaticHalfedgeMesh, i::IV)
    m.vertices.conn[i.value].onborder
end
"Whether the edge is on border."
function onborder(m::StaticHalfedgeMesh, e::IE)
    m.edges.conn[e.value].polygon_types != SA[pt_triangle, pt_triangle]
end


"Static mesh can only be created using dynamic mesh."
function StaticHalfedgeMesh(dm::DynamicHalfedgeMesh)
    maxdegree::Int = 0
    for v ∈ 1:length(dm.vertices)
        maxdegree = max(maxdegree, degree(dm, IV(v)))
    end

    sm = StaticHalfedgeMesh(
        StructArray((conn = Vector{StaticHalfedgeMeshConnectionVertex  }(undef, length(dm.vertices )), attr = dm.vertices.attr)),
        StructArray((conn = Vector{StaticHalfedgeMeshConnectionHalfedge}(undef, length(dm.halfedges)), attr = dm.halfedges.attr)),
        StructArray((conn = Vector{StaticHalfedgeMeshConnectionEdge    }(undef, length(dm.edges    )), attr = dm.edges.attr)),
        StructArray((conn = Vector{StaticHalfedgeMeshConnectionTriangle}(undef, length(dm.triangles)), attr = dm.triangles.attr)),
        StructArray((conn = Vector{StaticHalfedgeMeshConnectionBorder  }(undef, length(dm.borders  )), attr = dm.borders.attr)),
        StaticHalfedgeMeshConnectionMeta(maxdegree, Matrix{Int}(undef, indices_nearvertex_stride(maxdegree), length(dm.vertices))),
        dm.metaattr,
    )

    for h ∈ 1:length(dm.halfedges)
        v1 = IH(h) |> prev(dm) |> target(dm)
        v2 = IH(h) |> target(dm)
        v3 = IH(h) |> next(dm) |> target(dm)
        aref(sm.halfedges.conn)[h].vertex_indices[] = SA[v1.value, v2.value, v3.value]
        aref(sm.halfedges.conn)[h].polygon_type[] = polygon(dm, IH(h)).type
    end

    for t ∈ 1:length(dm.triangles)
        h = halfedge(dm, IT(t))
        h_n = next(dm, h)
        h_p = prev(dm, h)
        v1 = target(dm, h)
        v2 = target(dm, h_n)
        v3 = target(dm, h_p)

        aref(sm.triangles.conn)[t].vertex_indices[] = SA[v1.value, v2.value, v3.value]
        aref(sm.triangles.conn)[t].halfedge_indices[] = SA[h.value, h_n.value, h_p.value]
        aref(sm.triangles.conn)[t].edge_indices[] = SA[edge(dm, h).value, edge(dm, h_n).value, edge(dm, h_p).value]
    end

    for e ∈ 1:length(dm.edges)
        h = halfedge(dm, IE(e))
        h_o = oppo(dm, h)
        v1 = target(dm, h)
        v2 = target(dm, h_o)

        aref(sm.edges.conn)[e].vertex_indices[] = SA[v1.value, v2.value]
        aref(sm.edges.conn)[e].polygon_types[] = SA[polygon(dm, h).type, polygon(dm, h_o).type]
        aref(sm.edges.conn)[e].polygon_indices[] = SA[polygon(dm, h).index, polygon(dm, h_o).index]
    end

    for v ∈ 1:length(dm.vertices)
        aref(sm.vertices.conn)[v].degree[] = degree(dm, IV(v))
        aref(sm.vertices.conn)[v].onborder[] = onborder(dm, IV(v))

        in::Int = 1 # Neighbor index.
        for h ∈ HalfedgesTargetingVertex(dm, IV(v))
            h_o = oppo(dm, h)
            vn = target(dm, h_o)

            set_neighbor_vertex!(sm, in, v, vn.value)
            set_targeting_halfedge!(sm, in, v, h.value)
            set_leaving_halfedge!(sm, in, v, h_o.value)
            set_outer_halfedge!(sm, in, v, prev(dm, h).value)
            set_targeting_edge!(sm, in, v, edge(dm, h).value)
            set_polygon!(sm, in, v, polygon(dm, h).index)

            in += 1
        end
    end

    sm
end


function Base.show(io::IO, m::Union{DynamicHalfedgeMesh,StaticHalfedgeMesh})
    print(io, "$DynamicHalfedgeMesh{$(length(m.vertices)) vertices, $(length(m.halfedges)) halfedges, $(length(m.edges)) edges, $(length(m.triangles)) triangles, $(length(m.borders)) borders}")
end
function Base.show(io::IO, mime::MIME"text/plain", m::Union{DynamicHalfedgeMesh,StaticHalfedgeMesh})
    simpletypename = Base.typename(typeof(m)).wrapper
    print(io, simpletypename)
    print(io, " with\n")
    lenstr = string.(length.((m.vertices, m.halfedges, m.edges, m.triangles, m.borders)))
    maxlen = maximum(length, lenstr)
    function printelement(io::IO, thelenstr, maxlen, name, attrtype)
        print(io, "  ")
        print(io, thelenstr)
        print(io, ' ' ^ (maxlen - length(thelenstr) + 1))
        print(io, name)
        print(io, " (attr type: $(attrtype))\n")
    end
    printelement(io, lenstr[1], maxlen, "vertices ", attrtype_vertex(m))
    printelement(io, lenstr[2], maxlen, "halfedges", attrtype_halfedge(m))
    printelement(io, lenstr[3], maxlen, "edges    ", attrtype_edge(m))
    printelement(io, lenstr[4], maxlen, "triangles", attrtype_triangle(m))
    printelement(io, lenstr[5], maxlen, "borders  ", attrtype_border(m))
    print(io, "  metaattr: ")
    show(io, mime, m.metaattr)
end
