"""
Represents temporarily valid references.
"""

struct FilaIdx
    typeid::UInt32
    idx::UInt32
end


struct FilaTipIdx <: Place
    fila_idx::FilaIdx
    is_minus_end::Bool
end
FilaTipIdx() = FilaTipIdx(FilaIdx(0,0), false)

"""
    $(FUNCTIONNAME)(::Union{Place, Type{<:Place}})::Int

Return the number of directions associated with a place.
"""
num_directions(::Type{FilaTipIdx}) = 2
struct FilaTipChemState <: PlaceChemState
    tip_monomer_state::UInt8
    next_monomer_state::UInt8
end
FilaTipChemState() = FilaTipChemState(0x00, 0x00)
chem_state_type(::Type{FilaTipIdx}) = FilaTipChemState


struct FilaMonoIdx <: Place
    fila_idx::FilaIdx
    mid::Int64
end
FilaMonoIdx() = FilaMonoIdx(FilaIdx(0,0), 0)
num_directions(::Type{FilaMonoIdx}) = 2
struct FilaMonoChemState <: PlaceChemState
    prev_monomer_state::UInt8
    monomer_state::UInt8
    next_monomer_state::UInt8
end
FilaMonoChemState() = FilaMonoChemState(0x00, 0x00, 0x00)
chem_state_type(::Type{FilaMonoIdx}) = FilaMonoChemState


struct MembVertIdx <: Place
    "membrane index"
    memb_idx::UInt32

    "vertex idx"
    vert_idx::UInt32
end
MembVertIdx() = MembVertIdx(0, 0)
num_directions(::Type{MembVertIdx}) = 0 # TODO support membrane normals
struct MembVertChemState <: PlaceChemState
    vertex_state::UInt8
end
MembVertChemState() = MembVertChemState(0x00)
chem_state_type(::Type{MembVertIdx}) = MembVertChemState

"""
    Anchor <: Place

A position and directions fixed in the simulation frame. Useful for creating links to a point
that doesn't move with any dynamic elements.

# Constructors

- `Anchor()`: Creates a null anchor with NaN position, NaN directions, and state 0
- `Anchor(pos::SVector{3, Float64})`: Creates an anchor at the given position with NaN directions and state 0
- `Anchor(pos::SVector{3, Float64}, dirs::SVector{2, SVector{3, Float64}})`: Creates an anchor at the given position with specified directions and state 0
- `Anchor(pos::SVector{3, Float64}, dirs::SVector{2, SVector{3, Float64}}, state::Int64)`: Full constructor with position, directions, and state

# Fields

- `pos::SVector{3, Float64}`: 3D position coordinates
- `dirs::SVector{2, SVector{3, Float64}}`: Two direction vectors
- `state::Int64`: State identifier for chemical reactions
"""
struct Anchor <: Place
    pos::SVector{3, Float64}
    dirs::SVector{2, SVector{3, Float64}}
    state::Int64
end
Anchor() = Anchor(NAN3, nan_3vectors(2), 0)
Anchor(pos::SVector{3, Float64}) = Anchor(pos, nan_3vectors(2), 0)
Anchor(pos::SVector{3, Float64}, dirs::SVector{2, SVector{3, Float64}}) = Anchor(pos, dirs, 0)
num_directions(::Type{Anchor}) = 2
struct AnchorChemState <: PlaceChemState
    state::Int64
end
AnchorChemState() = AnchorChemState(0)
chem_state_type(::Type{Anchor}) = AnchorChemState