using ArgCheck: @argcheck

abstract type Place end

struct LinkTag
    type_id::Int64
    id::Int64
end
function LinkTag()
    LinkTag(0, 0)
end

struct Tag{P<:Place}
    idx::UInt32
    generation::UInt32
end

function Tag{P}() where {P<:Place}
    Tag{P}(UInt32(0), UInt32(0))
end
is_null(x::Tag) = isequal(x, typeof(x)())

nan_3vectors(n::Integer) = @SVector(fill(SA[NaN,NaN,NaN], n))

# default constructor gets a null place
is_null(x::Place) = isequal(x, typeof(x)())
num_directions(x::Place) = num_directions(typeof(x))
chem_state_type(x::Place) = chem_state_type(typeof(x))

abstract type PlaceChemState end

# slots with this generation are empty and used up.
const MAXGENERATION = typemax(UInt32) - UInt32(1)
const EMPTY_REFLINKS = LinkTag[]

@kwdef struct TagManager{P<:Place}
    place2idx::Dict{P,UInt32} = Dict{P,UInt32}()
    idx2place::Vector{P} = P[]
    idx2reflinks::Vector{Vector{LinkTag}} = Vector{LinkTag}[]
    idx2generation::Vector{UInt32} = UInt32[]
    free_idxs::Vector{UInt32} = UInt32[]
end

function Base.empty!(t::TagManager)
    empty!(t.place2idx)
    empty!(t.idx2place)
    empty!(t.idx2reflinks)
    empty!(t.idx2generation)
    empty!(t.free_idxs)
    t
end

function assert_invariants(t::TagManager{P}) where {P}
    n = length(t.idx2place)
    @argcheck n == length(t.idx2generation)
    @argcheck n == length(t.idx2reflinks)
    @argcheck isempty(EMPTY_REFLINKS)
    n_existing = length(keys(t.place2idx))
    acc_n = 0
    acc_free_n = 0
    @argcheck !haskey(t.place2idx, P())
    for i in 1:n
        p = t.idx2place[i]
        g = t.idx2generation[i]
        @argcheck g ≤ MAXGENERATION
        if isodd(g)
            acc_n += 1
            @argcheck t.place2idx[p] == i
            @argcheck !is_null(p)
            @argcheck i ∉ t.free_idxs
            @argcheck allunique(t.idx2reflinks[i])
        else
            @argcheck is_null(p)
            @argcheck isempty(t.idx2reflinks[i])
            if g != MAXGENERATION
                @argcheck i ∈ t.free_idxs
                acc_free_n += 1
            end
        end
    end
    @argcheck acc_free_n == length(t.free_idxs)
    @argcheck acc_n == n_existing
    t
end

"""
Check if two `TagManager` are statistically equal, the internal free lists may be different
"""
function statistically_equal(a::TagManager{P}, b::TagManager{P}) where {P}
    assert_invariants(a)
    assert_invariants(b)
    a.idx2generation == b.idx2generation || return false
    a.idx2place == b.idx2place || return false
    isequal(a.idx2reflinks, b.idx2reflinks) || return false
    return true
end

# Iterates through valid Tags in the TagManager.
Base.length(t::TagManager) = length(t.place2idx)
function Base.iterate(t::TagManager{P}, state::NamedTuple) where {P}
    gens = t.idx2generation
    nextidx = findnext(isodd, gens, state.curidx + 1)
    if isnothing(nextidx)
        nothing
    else
        (Tag{P}(nextidx, gens[nextidx]), (; curidx = Int64(nextidx)))
    end
end
Base.iterate(t::TagManager) = iterate(t, (; curidx=Int64(0)))
Base.eltype(::Type{TagManager{P}}) where {P} = Tag{P}

function _try_get_idx(t::TagManager{P}, id::Tag{P})::Union{UInt32,Nothing} where {P}
    idx = id.idx
    idx ∈ eachindex(t.idx2generation) || return nothing
    generation = t.idx2generation[idx]
    isodd(generation) || return nothing
    generation == id.generation || return nothing
    idx
end
function _get_idx(t::TagManager{P}, id::Tag{P})::UInt32 where {P}
    something(_try_get_idx(t, id))
end

function _get_place(t::TagManager{P}, id::Tag{P})::P where {P}
    idx = _get_idx(t, id)
    t.idx2place[idx]
end

function _tag!(
        t::TagManager{P},
        place::P,
    )::Tag{P} where {P}
    @argcheck !is_null(place)
    local idx::UInt32
    local generation::UInt32
    if !haskey(t.place2idx, place)
        if isempty(t.free_idxs)
            # idx must be a UInt32, so avoid overflowing here
            @argcheck length(t.idx2generation) < typemax(UInt32)
            push!(t.idx2place, place)
            idx = length(t.idx2place)
            t.place2idx[place] = idx
            push!(t.idx2generation, UInt32(1))
            generation = UInt32(1)
            push!(t.idx2reflinks, EMPTY_REFLINKS)
            @assert length(t.idx2reflinks) == idx
            @assert length(t.idx2generation) == idx
        else
            idx = pop!(t.free_idxs)
            @assert isempty(t.idx2reflinks[idx])
            @assert is_null(t.idx2place[idx])
            t.place2idx[place] = idx
            t.idx2place[idx] = place
            t.idx2generation[idx] += UInt32(1)
            generation = t.idx2generation[idx]
        end
    else
        idx = t.place2idx[place]
        generation = t.idx2generation[idx]
    end
    @assert isodd(generation)
    @assert generation != typemax(UInt32)
    Tag{P}(idx, generation)
end

function _force_remove_idx!(t::TagManager{P}, idx::UInt32) where {P}
    place = t.idx2place[idx]
    @assert t.place2idx[place] == idx
    t.idx2place[idx] = P()
    delete!(t.place2idx, place)
    t.idx2reflinks[idx] = EMPTY_REFLINKS
    g = t.idx2generation[idx]
    g += UInt32(1)
    t.idx2generation[idx] = g
    @assert iseven(g)
    # MAXGENERATION is unusable
    if g != MAXGENERATION
        push!(t.free_idxs, idx)
    end
    t
end

# Removes all tags that aren't referenced
function _free_unreferenced_tags!(t::TagManager{P}) where {P}
    for (idx, gen) in enumerate(t.idx2generation)
        id = Tag{P}(idx, gen)
        _free_tag!(t, id)
    end
    t
end

# Removes tag if it has no references
function _free_tag!(t::TagManager{P}, id::Tag{P}) where {P}
    idx = _try_get_idx(t, id)
    isnothing(idx) && return t # tag isn't there, do nothing
    isempty(t.idx2reflinks[idx]) || return t # tag is referenced by a link, do nothing
    _force_remove_idx!(t, idx)
end

function _remove_place!(t::TagManager{P}, place::P) where {P}
    @argcheck !is_null(place)
    if haskey(t.place2idx, place)
        idx = t.place2idx[place]
        @assert t.idx2place[idx] == place
        _force_remove_idx!(t, idx)
    end
    t
end

function _move_place!(t::TagManager{P}, oldplace::P, newplace::P) where {P}
    @argcheck !is_null(oldplace)
    @argcheck !is_null(newplace)
    if haskey(t.place2idx, oldplace)
        idx = t.place2idx[oldplace]
        @assert t.idx2place[idx] == oldplace
        @argcheck !haskey(t.place2idx, newplace)
        t.idx2place[idx] = newplace
        delete!(t.place2idx, oldplace)
        t.place2idx[newplace] = idx
    end
    t
end
