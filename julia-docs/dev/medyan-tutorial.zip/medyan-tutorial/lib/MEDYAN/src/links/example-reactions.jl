"""
Returns 1.0 if the monomer states match, otherwise, returns 0.0.

$(TYPEDFIELDS)
"""
struct LinkRateMonomerStateMatch
    "monomer states"
    state1::FilaMonoChemState

    "monomer states"
    state2::FilaMonoChemState
end
function (g::LinkRateMonomerStateMatch)(c; link_tag, link_data, kwargs...)
    tags = get_tags(c, link_tag, link_data)
    if any(is_null, tags)
        0.0
    elseif g.state1 == get_chem_state(c, tags[1]) && g.state2 == get_chem_state(c, tags[2])
        1.0
    else
        0.0
    end
end

"""
Models unbinding rates based on the
following exponential form of Bell et al, 1978:
    min(k0*exp(f/f0), kmax)
Where f is the magnitude of the force.
So as to exponetially increase the unbinding with more force.

Returns the unbinding rate in units of 1/s
It returns k0 if the link hasn't been minimized yet.

$(TYPEDFIELDS)
"""
Base.@kwdef struct LinkRateSlipBond
    "The charicteristic force magnitude. Units of pN"
    f0::Float64

    "Unbinding rate at zero force. Units of 1/s"
    k0::Float64

    "Maximum rate. Units of 1/s"
    kmax::Float64=Inf
end
function (g::LinkRateSlipBond)(c; link_tag, link_data, kwargs...)
    if get_is_minimized(c, link_tag)
        # get tension force
        out = get_link_mechanics(c, link_tag, link_data)
        Fext = max(norm_fast(out.forces[1]), norm_fast(out.forces[2]))
        min(g.k0 * exp(Fext * inv(g.f0)), g.kmax)
    else
        #assume zero force if not yet minimized
        g.k0
    end
end

"""
The catch-bond nature of myosin unbinding with multiple heads.
    Adopted from the results of Erdmann et al. 2013. The parallel cluster model.

As the force increases, the motor unbinding rate decreases to a minimum of k0/10

returns the unbinding rate in units of 1/s
It returns k0 if the link hasn't been minimized yet.
It assumes link_state.numHeads exists for the link.

$(TYPEDFIELDS)
"""
Base.@kwdef struct LinkRateMotorCatch
    "single head characteristic unbinding force, units of pN/head"
    f0::Float64 = 12.62 #default MEDYAN example

    "single head binding rate, units of 1/s"
    onRate::Float64 = 0.2 #default MEDYAN example

    "single head unbinding rate, units of 1/s"
    offRate::Float64 = 1.7 #default MEDYAN example

    "slope of head binding, units of (head)/(pN/head)"
    β::Float64 = 2.0 #default MEDYAN example
end
function (g::LinkRateMotorCatch)(c; link_tag, link_data, link_state, kwargs...)
    numHeads = link_state.numHeads
    #dutyRatio
    ρ = g.onRate / (g.onRate + g.offRate)
    #unbinding rate at zero force
    k0 = g.onRate * numHeads / ((1 - ρ)^-numHeads - 1)
    if get_is_minimized(c, link_tag)
        # get tension force
        out = get_link_mechanics(c, link_tag, link_data)
        Fext = max(norm_fast(out.forces[1]), norm_fast(out.forces[2]))
        #number of bound heads
        numBoundHeads = min(numHeads, ρ * numHeads + g.β * Fext / numHeads)
        k0 * max(0.1, exp(-Fext / (numBoundHeads * g.f0)))
    else
        #assume zero force if not yet minimized
        k0
    end
end

"""
Models myosin walking rates 
    from the results of Erdmann et al. 2013. The parallel cluster model.

As the motor work per step increases, its walking rate goes to zero.

Returns the walking rate of one end.

$(TYPEDFIELDS)
"""
Base.@kwdef struct LinkRateMotorStall
    "The stall force magnitude. Units of pN"
    fs::Float64

    "Walking rate of one end at zero force. Units of 1/s"
    k0::Float64

    "Positive dimensionless parameter defining the steepness of the curve,
    smaller is more steep, if α is inf, the curve is linear"
    α::Float64 = 0.2

    "Motor walking direction, +1 is towards plus end, -1 is towards minus end"
    walking_direction::Int32 = +1
end
function (g::LinkRateMotorStall)(c::Context; link_tag, link_data, place_idx, kwargs...)
    #get drag force
    out = get_link_mechanics(c, link_tag, link_data)
    Fdrag = -(g.walking_direction) * (out.inputs[place_idx][2] ⋅ out.forces[place_idx])
    Fdrag = max(0.0, Fdrag)
    g.k0 * max(0.0, (g.fs - Fdrag) / (g.fs + Fdrag / g.α))
end