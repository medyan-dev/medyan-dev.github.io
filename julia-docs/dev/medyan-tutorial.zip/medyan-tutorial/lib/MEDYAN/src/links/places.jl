using ArgCheck: @argcheck

# helper functions during transition period
function _get_fila_id(c::Context, f::FilaIdx)
    c.chem_cylinders[f.typeid].per_fil[f.idx].id
end
function _get_fila_idx(c::Context, ftid, fid)
    fidx = c.chem_cylinders[ftid].fil_id_2_idx[fid]
    FilaIdx(ftid, fidx)
end
function _get_fila_mono_idx(c::Context, name::MonomerName)
    FilaMonoIdx(_get_fila_idx(c, name.ftid, name.fid), name.mid)
end
function _get_monomer_name(c::Context, p::FilaMonoIdx)
    MonomerName(p.fila_idx.typeid, _get_fila_id(c, p.fila_idx), p.mono_idx)
end

"""
    $(TYPEDSIGNATURES)
Return a read only OffsetVector of monomer states on a filament.

This can be invalid after any mutations to context, so copy if needed.
"""
function fila_mono_states(c::Context, f::FilaIdx)::OffsetVector{MonomerState, Vector{MonomerState}}
    cylinders::ChemCylinders = c.chem_cylinders[Int(f.typeid)]
    _fil_mon_states(cylinders, Int(f.idx))
end

"""
    $(TYPEDSIGNATURES)
Return the node positions of the filament
"""
function fila_node_positions(c::Context, f::FilaIdx)
    cylinders::ChemCylinders = c.chem_cylinders[Int(f.typeid)]
    _get_nodepositions(cylinders, Int(f.idx))
end

FilaTipIdx(c::Context, f::FilaIdx, is_minus_end::Bool) = FilaTipIdx(f, is_minus_end)
FilaTipIdx(c::Context, f::FilaIdx, ::typeof(-)) = FilaTipIdx(f, true)
FilaTipIdx(c::Context, f::FilaIdx, ::typeof(+)) = FilaTipIdx(f, false)
FilaTipIdx(c::Context, f::FilaTipIdx) = f
FilaIdx(c::Context, ft::FilaTipIdx) = ft.fila_idx
FilaIdx(c::Context, t::Tag) = FilaIdx(c, get_place(c, t))
is_minus_end(ft::FilaTipIdx) = ft.is_minus_end


_pack_fila_idx(p::FilaIdx) = (UInt64(p.typeid) << 32) | UInt64(p.idx << 1)
_unpack_fila_idx(i::UInt64) = FilaIdx((i >> 32)%UInt32, (i%UInt32) >> 1)

_pack_fila_tip_idx(p::FilaTipIdx) = _pack_fila_idx(p.fila_idx) | UInt64(p.is_minus_end)
_unpack_fila_tip_idx(i::UInt64) = FilaTipIdx(_unpack_fila_idx(i), isodd(i))

_pack_version(p::FilaTipIdx) = 1
_pack_name(p::FilaTipIdx) = "fila_tip"
function _pack_places(ps::Vector{FilaTipIdx})
    _pack_fila_tip_idx.(ps)
end
function _unpack_places!(ps::Vector{FilaTipIdx}, data::Vector{UInt64})
    ps .= _unpack_fila_tip_idx.(data)
    nothing
end


function place_exists(c::Context, p::FilaTipIdx)::Bool
    ftid = Int(p.fila_idx.typeid)
    fil_idx = Int(p.fila_idx.idx)
    ftid ∈ eachindex(c.chem_cylinders) || return false
    cylinders = c.chem_cylinders[ftid]
    fil_idx ∈ eachindex(cylinders.per_fil) || return false
    return true
end

# no inline is to prevent fastmath shenanigans
@noinline function get_position(c::Context, p::FilaTipIdx)::SVector{3, Float64}
    ftid = Int(p.fila_idx.typeid)
    fil_idx = Int(p.fila_idx.idx)
    cylinders = c.chem_cylinders[ftid]
    chembeadpositions = cylinders.per_fil.chembeadpositions[fil_idx]
    mon_id_first, mon_id_last, numpercylinder = _mon_id_info(cylinders, fil_idx)
    #undo extended ends
    b = numpercylinder
    if p.is_minus_end
        a = mod(mon_id_first, numpercylinder)
        (1-a/b)*chembeadpositions[begin] + (a/b)*chembeadpositions[begin+1]
    else
        midlast = mon_id_last + 1
        a = mod(-midlast, numpercylinder)
        (1-a/b)*chembeadpositions[end] + (a/b)*chembeadpositions[end-1]
    end
end

@noinline function get_directions(c::Context, p::FilaTipIdx)::SVector{1, SVector{3, Float64}}
    ftid = Int(p.fila_idx.typeid)
    fil_idx = Int(p.fila_idx.idx)
    cylinders = c.chem_cylinders[ftid]
    chembeadpositions = cylinders.per_fil.chembeadpositions[fil_idx]
    if p.is_minus_end
        SA[normalize_fast(chembeadpositions[begin+1] - chembeadpositions[begin])]
    else
        SA[normalize_fast(chembeadpositions[end] - chembeadpositions[end-1])]
    end
end

function get_chem_state(c::Context, p::FilaTipIdx)::FilaTipChemState
    mono_states = fila_mono_states(c, p.fila_idx)
    if p.is_minus_end
        FilaTipChemState(
            mono_states[begin],
            mono_states[begin+1]
        )
    else
        FilaTipChemState(
            mono_states[end],
            mono_states[end-1]
        )
    end
end


function place_exists(c::Context, p::FilaMonoIdx)::Bool
    ftid = Int(p.fila_idx.typeid)
    fil_idx = Int(p.fila_idx.idx)
    (ftid ∈ eachindex(c.chem_cylinders)) || return false
    cylinders = c.chem_cylinders[ftid]
    (fil_idx ∈ eachindex(cylinders.per_fil)) || return false
    (p.mono_idx ∈ eachindex(fila_mono_states(c, p.fila_idx))) || return false
    return true
end

FilaMonoIdx(c::Context, f::FilaIdx, m::Integer) = FilaMonoIdx(f, Int64(m))
FilaMonoIdx(c::Context, f::FilaIdx, ::typeof(-), offset::Integer=0) = FilaMonoIdx(f, firstindex(fila_mono_states(c, f)) + offset)
FilaMonoIdx(c::Context, f::FilaIdx, ::typeof(+), offset::Integer=0) = FilaMonoIdx(f, lastindex(fila_mono_states(c, f)) + offset)
function FilaMonoIdx(c::Context, ft::FilaTipIdx, offset::Integer=0)
    f = ft.fila_idx
    if ft.is_minus_end
        FilaMonoIdx(f, firstindex(fila_mono_states(c, f)) + offset)
    else
        FilaMonoIdx(f, lastindex(fila_mono_states(c, f)) + offset)
    end
end
function FilaMonoIdx(c::Context, fm::FilaMonoIdx, offset::Integer=0)
    FilaMonoIdx(fm.fila_idx, fm.mono_idx + offset)
end
FilaIdx(c::Context, fm::FilaMonoIdx) = fm.fila_idx

# Convert to zigzag encoding for better compression
_zigzag_encode(i::Union{Int128, Int64, Int32, Int16, Int8}) = unsigned((i >> (sizeof(i)*8-1)) ⊻ (i << 1))
_zigzag_decode(u::Union{UInt128, UInt64, UInt32, UInt16, UInt8}) = signed((u >>> 1) ⊻ -(u & one(u)))
_pack_version(p::FilaMonoIdx) = 1
_pack_name(p::FilaMonoIdx) = "fila_mono"
function _pack_places(ps::Vector{FilaMonoIdx})
    n = length(ps)
    out = zeros(UInt64, 2*n)
    for i in 1:n
        out[i] = _pack_fila_idx(ps[i].fila_idx)
        out[i+n] = _zigzag_encode(ps[i].mono_idx)
    end
    out
end
function _unpack_places!(ps::Vector{FilaMonoIdx}, data::Vector{UInt64})
    n = length(ps)
    @argcheck length(data) == 2*n
    for i in 1:n
        ps[i] = FilaMonoIdx(_unpack_fila_idx(data[i]), _zigzag_decode(data[i+n]))
    end
end

@noinline function get_position(c::Context, p::FilaMonoIdx)::SVector{3, Float64}
    cylinders::ChemCylinders = c.chem_cylinders[p.fila_idx.typeid]
    _mon_position(cylinders, Int64(p.fila_idx.idx), p.mono_idx)
end

@noinline function get_directions(c::Context, p::FilaMonoIdx)::SVector{1, SVector{3, Float64}}
    cylinders::ChemCylinders = c.chem_cylinders[p.fila_idx.typeid]
    SA[_mon_plusvector(cylinders, Int64(p.fila_idx.idx), p.mono_idx)]
end

function get_chem_state(c::Context, p::FilaMonoIdx)::FilaMonoChemState
    mono_states = fila_mono_states(c, p.fila_idx)
    mon_id = p.mono_idx
    m = ntuple(3) do i
        i = i - 2
        if mon_id + i in eachindex(mono_states)
            mono_states[mon_id + i]
        else
            zero(MonomerState)
        end
    end
    FilaMonoChemState(m...)
end

