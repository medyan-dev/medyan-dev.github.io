using ArgCheck: @argcheck

# helper functions during transition period
function _get_vertex_name(c::Context, p::MembVertIdx)
    VertexName(p.memb_idx, m.vertices.attr.id[p.vert_idx])
end
function _get_memb_vert_idx(c::Context, name::VertexName)
    MembVertIdx(name.membraneindex, c.membranes[name.membraneindex].metaattr.id2index_vertex[name.vid])
end

FilaTipIdx(c::Context, x, ::typeof(-)) = FilaTipIdx(c, x, true)
FilaTipIdx(c::Context, x, ::typeof(+)) = FilaTipIdx(c, x, false)
FilaTipIdx(c::Context, f::FilaTipIdx) = f
FilaTipIdx(c::Context, t::Tag{FilaTipIdx}) = tag2place(c, t)
function FilaTipIdx(
        c::Context,
        x::Union{FilaIdx, FilaTipIdx, FilaMonoIdx, Tag},
        is_minus_end::Bool,
    )
    FilaTipIdx(FilaIdx(c, x), is_minus_end)
end
FilaMonoIdx(c::Context, f::FilaIdx, m::Integer) = FilaMonoIdx(f, Int64(m))
function FilaMonoIdx(c::Context, ft::FilaTipIdx, offset::Integer=0)
    f = ft.fila_idx
    if ft.is_minus_end
        FilaMonoIdx(f, first(fila_mono_ids(c, f)) + offset)
    else
        FilaMonoIdx(f, last(fila_mono_ids(c, f)) + offset)
    end
end
function FilaMonoIdx(c::Context, fm::FilaMonoIdx, offset::Integer=0)
    FilaMonoIdx(fm.fila_idx, fm.mid + offset)
end
FilaMonoIdx(c::Context, x, y::Union{typeof(-), typeof(+)}, offset::Integer=0) = FilaMonoIdx(c, FilaTipIdx(c, x, y), offset)
FilaMonoIdx(c::Context, t::Tag, offset::Integer=0) = FilaMonoIdx(c, tag2place(c, t), offset)
FilaIdx(c::Context, f::FilaIdx) = f
FilaIdx(c::Context, ft::FilaTipIdx) = ft.fila_idx
FilaIdx(c::Context, t::Tag) = FilaIdx(c, tag2place(c, t))
FilaIdx(c::Context, fm::FilaMonoIdx) = fm.fila_idx
is_minus_end(ft::FilaTipIdx) = ft.is_minus_end


_pack_fila_idx(p::FilaIdx) = (UInt64(p.typeid) << 32) | UInt64(p.idx << 1)
_unpack_fila_idx(i::UInt64) = FilaIdx((i >> 32)%UInt32, (i%UInt32) >> 1)

_pack_fila_tip_idx(p::FilaTipIdx) = _pack_fila_idx(p.fila_idx) | UInt64(p.is_minus_end)
_unpack_fila_tip_idx(i::UInt64) = FilaTipIdx(_unpack_fila_idx(i), isodd(i))

_pack_version(p::FilaTipIdx) = 1
_pack_name(p::FilaTipIdx) = "fila_tip"
function _pack_places(ps::Vector{FilaTipIdx})
    _pack_fila_tip_idx.(ps)
end
function _unpack_places!(ps::Vector{FilaTipIdx}, data::Vector{UInt64})
    ps .= _unpack_fila_tip_idx.(data)
    nothing
end

"""
    $(FUNCTIONNAME)(c::Context, p::Place)::Bool

Return true iff place `p` exists in context `c`.
Otherwise return false.
"""
function place_exists(c::Context, p::FilaTipIdx)::Bool
    ftid = Int(p.fila_idx.typeid)
    fil_idx = Int(p.fila_idx.idx)
    ftid ∈ eachindex(c.chem_cylinders) || return false
    cylinders = c.chem_cylinders[ftid]
    fil_idx ∈ eachindex(cylinders.per_fil) || return false
    return true
end

# no inline is to prevent fastmath shenanigans
@noinline function get_position(c::Context, p::FilaTipIdx)::SVector{3, Float64}
    ftid = Int(p.fila_idx.typeid)
    fil_idx = Int(p.fila_idx.idx)
    cylinders = c.chem_cylinders[ftid]
    chembeadpositions = cylinders.per_fil.chembeadpositions[fil_idx]
    mon_id_first, mon_id_last, numpercylinder = _mon_id_info(cylinders, fil_idx)
    #undo extended ends
    b = numpercylinder
    if p.is_minus_end
        a = mod(mon_id_first, numpercylinder)
        (1-a/b)*chembeadpositions[begin] + (a/b)*chembeadpositions[begin+1]
    else
        midlast = mon_id_last + 1
        a = mod(-midlast, numpercylinder)
        (1-a/b)*chembeadpositions[end] + (a/b)*chembeadpositions[end-1]
    end
end

@noinline function get_directions(c::Context, p::FilaTipIdx)::SVector{1, SVector{3, Float64}}
    ftid = Int(p.fila_idx.typeid)
    fil_idx = Int(p.fila_idx.idx)
    cylinders = c.chem_cylinders[ftid]
    chembeadpositions = cylinders.per_fil.chembeadpositions[fil_idx]
    if p.is_minus_end
        SA[normalize_fast(chembeadpositions[begin+1] - chembeadpositions[begin])]
    else
        SA[normalize_fast(chembeadpositions[end] - chembeadpositions[end-1])]
    end
end

function get_chem_state(c::Context, p::FilaTipIdx)::FilaTipChemState
    mono_states = fila_mono_states(c, p.fila_idx)
    if p.is_minus_end
        FilaTipChemState(
            mono_states[begin],
            mono_states[begin+1]
        )
    else
        FilaTipChemState(
            mono_states[end],
            mono_states[end-1]
        )
    end
end


function place_exists(c::Context, p::FilaMonoIdx)::Bool
    ftid = Int(p.fila_idx.typeid)
    fil_idx = Int(p.fila_idx.idx)
    (ftid ∈ eachindex(c.chem_cylinders)) || return false
    cylinders = c.chem_cylinders[ftid]
    (fil_idx ∈ eachindex(cylinders.per_fil)) || return false
    (p.mid ∈ fila_mono_ids(c, p.fila_idx)) || return false
    return true
end

# Convert to zigzag encoding for better compression
_zigzag_encode(i::Union{Int128, Int64, Int32, Int16, Int8}) = unsigned((i >> (sizeof(i)*8-1)) ⊻ (i << 1))
_zigzag_decode(u::Union{UInt128, UInt64, UInt32, UInt16, UInt8}) = signed((u >>> 1) ⊻ -(u & one(u)))

_pack_version(p::FilaMonoIdx) = 1
_pack_name(p::FilaMonoIdx) = "fila_mono"
function _pack_places(ps::Vector{FilaMonoIdx})
    n = length(ps)
    out = zeros(UInt64, 2*n)
    for i in 1:n
        out[i] = _pack_fila_idx(ps[i].fila_idx)
        out[i+n] = _zigzag_encode(ps[i].mid)
    end
    out
end
function _unpack_places!(ps::Vector{FilaMonoIdx}, data::Vector{UInt64})
    n = length(ps)
    @argcheck length(data) == 2*n
    for i in 1:n
        ps[i] = FilaMonoIdx(_unpack_fila_idx(data[i]), _zigzag_decode(data[i+n]))
    end
end

@noinline function get_position(c::Context, p::FilaMonoIdx)::SVector{3, Float64}
    cylinders::ChemCylinders = c.chem_cylinders[p.fila_idx.typeid]
    _mon_position(cylinders, Int64(p.fila_idx.idx), p.mid)
end

@noinline function get_directions(c::Context, p::FilaMonoIdx)::SVector{1, SVector{3, Float64}}
    cylinders::ChemCylinders = c.chem_cylinders[p.fila_idx.typeid]
    SA[_mon_plusvector(cylinders, Int64(p.fila_idx.idx), p.mid)]
end

function get_chem_state(c::Context, p::FilaMonoIdx)::FilaMonoChemState
    mono_states = fila_mono_states(c, p.fila_idx)
    mono_ids = fila_mono_ids(c, p.fila_idx)
    mon_id = p.mid
    @argcheck p.mid ∈ mono_ids
    m = ntuple(3) do i
        idx = i - 2 + mon_id - first(mono_ids) + 1
        if (idx) ∈ eachindex(mono_states)
            mono_states[idx]
        else
            zero(MonomerState)
        end
    end
    FilaMonoChemState(m...)
end


MembVertIdx(c::Context, memb_idx::Integer, vert_idx::Integer) = MembVertIdx(memb_idx, vert_idx)

function place_exists(c::Context, p::MembVertIdx)::Bool
    mindex = Int(p.memb_idx)
    vindex = Int(p.vert_idx)
    (mindex ∈ eachindex(c.membranes)) || return false
    m = c.membranes[mindex]
    (vindex ∈ eachindex(m.vertices)) || return false
    return true
end

_pack_version(p::MembVertIdx) = 1
_pack_name(p::MembVertIdx) = "memb_vert"
function _pack_places(ps::Vector{MembVertIdx})
    n = length(ps)
    out = zeros(UInt64, n)
    for i in 1:n
        out[i] = (UInt64(ps[i].memb_idx) << 32) | UInt64(ps[i].vert_idx)
    end
    out
end
function _unpack_places!(ps::Vector{MembVertIdx}, data::Vector{UInt64})
    n = length(ps)
    @argcheck length(data) == n
    for i in 1:n
        ps[i] = MembVertIdx((data[i] >> 32)%UInt32, (data[i])%UInt32)
    end
end

@noinline function get_position(c::Context, p::MembVertIdx)::SVector{3, Float64}
    mindex = Int(p.memb_idx)
    vidx = Int(p.vert_idx)
    m = c.membranes[mindex]
    m.vertices.attr.coord[vidx]
end

@noinline function get_directions(c::Context, p::MembVertIdx)::SVector{0, SVector{3, Float64}}
    # TODO support membrane normals
    SVector{0, SVector{3, Float64}}
end

function get_chem_state(c::Context, p::MembVertIdx)::MembVertChemState
    mindex = Int(p.memb_idx)
    vidx = Int(p.vert_idx)
    m = c.membranes[mindex]
    MembVertChemState(m.vertices.attr.vertexstate[vidx])
end

