# Structs for managing links
using ConcreteStructs: @concrete

@concrete struct DataPerLink{N_BONDS}
    generation::UInt32
    tags
    is_minimized::Bool
    state
    bond_states
    bond_enabled::NTuple{N_BONDS, Bool}
    bond_no_collide::NTuple{N_BONDS, Bool}
end

@concrete struct LinkData{BOND_INPUTS}
    name::Symbol
    id::UInt32
    "null places"
    places
    param
    "default state"
    state
    bonds # NTuple{N_BONDS, BondConfig}
    free_idxs::Vector{UInt32}
    per_link # struct array of DataPerLink
end

function LinkData(;
        name::Symbol,
        id::UInt32,
        places::NTuple{N_PLACES, Place},
        param::NamedTuple,
        state::NamedTuple,
        bonds::NTuple{N_BONDS, BondConfig},
    ) where {N_BONDS, N_PLACES}
    TAGS = typeof(map(places) do p
        Tag{typeof(p)}(UInt32(0), UInt32(0))
    end)
    STATE = typeof(state)
    BOND_STATES = typeof(getfield.(bonds, (:state,)))
    per_link = StructVector(DataPerLink{N_BONDS, TAGS, STATE, BOND_STATES}[]; unwrap = T -> (T<:Tuple))
    bond_inputs = getfield.(bonds, (:input,))
    LinkData{bond_inputs}(
        name,
        id,
        places,
        param,
        state,
        bonds,
        UInt32[],
        per_link,
    )
end


@kwdef struct LinkManager
    link_data::Vector{LinkData}

    # Tags
    "Filament tip tags"
    fila_tip_tags::TagManager{FilaTipIdx} = TagManager{FilaTipIdx}()

    "Filament monomer tags"
    fila_mono_tags::TagManager{FilaMonoIdx} = TagManager{FilaMonoIdx}()
end

function LinkManager(link_configs::Vector{LinkConfig})
    link_data::Vector{LinkData} = map(link_configs) do c
        LinkData(;
            c.name,
            c.id,
            places = Tuple(c.places),
            param = c.param,
            state = c.state,
            bonds = Tuple(c.bonds)
        )
    end
    LinkManager(;link_data)

end