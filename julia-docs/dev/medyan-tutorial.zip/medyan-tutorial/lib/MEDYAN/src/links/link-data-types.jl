# Structs for managing links
using ConcreteStructs: @concrete

@concrete struct DataPerLink{N_PLACES, N_BONDS}
    generation::UInt32
    tags::NTuple{N_PLACES, UInt64}
    is_minimized::Bool
    state
    bond_states
    bond_enabled::NTuple{N_BONDS, Bool}
    bond_no_collide::NTuple{N_BONDS, Bool}
end

@concrete struct LinkData{BOND_INPUTS}
    null_places
    param
    default_state
    bonds
    bond_params
    default_bond_states
    free_idxs::Vector{UInt32}
    per_link # struct array of DataPerLink
end

function LinkData(;
        null_places::NTuple{N_PLACES, Place},
        param::NamedTuple,
        default_state::NamedTuple,
        bonds::NTuple{N_BONDS, Bond},
        bond_inputs::NTuple{N_BONDS, Tuple{Vararg{Int}}},
        bond_params::NTuple{N_BONDS, NamedTuple},
        default_bond_states::NTuple{N_BONDS, NamedTuple},
    ) where {N_BONDS, N_PLACES}
    STATE = typeof(default_state)
    BOND_STATES = typeof(default_bond_states)
    per_link = StructVector(DataPerLink{N_PLACES, N_BONDS, STATE, BOND_STATES}[]; unwrap = T -> (T<:Tuple))
    LinkData{bond_inputs}(
        null_places,
        param,
        default_state,
        bonds,
        bond_params,
        default_bond_states,
        UInt32[],
        per_link,
    )
end


@kwdef struct LinkManager
    link_data::Vector{LinkData} = LinkData[]

    # Tags
    "Filament tip tags"
    fila_tip_tags::typeof(TagManager(FilaTipIdx)) = TagManager(FilaTipIdx)

    "Filament monomer tags"
    fila_mono_tags::typeof(TagManager(FilaMonoIdx)) = TagManager(FilaMonoIdx)
end