# Structs for managing links
using ConcreteStructs: @concrete

function _default_unwrap(t)
    !(
        iszero(sizeof(t)) ||
        !isbitstype(t) ||
        !isstructtype(t)
    )
end

@concrete struct DataPerLink{N_BONDS}
    tags
    is_minimized::Bool
    state
    bond_states
    bond_enabled::NTuple{N_BONDS, Bool}
end

@concrete struct LinkData{BOND_INPUTS}
    name::Symbol
    id::Int64
    "null places"
    places
    param
    "default state"
    state
    bonds # NTuple{N_BONDS, BondConfig}
    "Next link_2mon id, always greater than other lids"
    next_lid::Ref{Int64}
    "map from link id to index (lidx)
    link indexes can change whenever a link is added or removed, but id's are stable"
    lid2lidx::Dict{Int64, UInt32}
    "map from link index (lidx) to lid"
    lidx2lid::Vector{Int64}
    per_link_template # default value for per_link
    per_link # struct array of DataPerLink
end

function LinkData(;
        name::Symbol,
        id::Int64,
        places::NTuple{N_PLACES, Place},
        param::NamedTuple,
        state::NamedTuple,
        bonds::NTuple{N_BONDS, BondConfig},
    ) where {N_BONDS, N_PLACES}
    null_tags = map(places) do p
        Tag{typeof(p)}(UInt32(0), UInt32(0))
    end
    per_link_template = DataPerLink{N_BONDS}(
        null_tags,
        false,
        state,
        getfield.(bonds, :state),
        getfield.(bonds, :enabled),
    )
    per_link = StructVector(typeof(per_link_template)[]; unwrap = _default_unwrap)
    bond_inputs = getfield.(bonds, (:input,))
    LinkData{bond_inputs}(
        name,
        id,
        places,
        param,
        state,
        bonds,
        Ref(Int64(1)),
        Dict{Int64, UInt32}(), #lid_to_lidx
        Int64[], #lidx_to_lid
        per_link_template,
        per_link,
    )
end


@kwdef struct LinkManager
    link_data::Vector{LinkData}

    # Tags
    "Filament tip tags"
    fila_tip_tags::TagManager{FilaTipIdx} = TagManager{FilaTipIdx}()

    "Filament monomer tags"
    fila_mono_tags::TagManager{FilaMonoIdx} = TagManager{FilaMonoIdx}()
end

function LinkManager(link_configs::Vector{LinkConfig})
    link_data::Vector{LinkData} = map(link_configs) do c
        LinkData(;
            c.name,
            c.id,
            places = Tuple(c.places),
            param = c.param,
            state = c.state,
            bonds = Tuple(c.bonds)
        )
    end
    LinkManager(;link_data)

end