# Structs for managing links
using ConcreteStructs: @concrete



function _default_unwrap(t)
    !(
        iszero(sizeof(t)) ||
        !isbitstype(t) ||
        !isstructtype(t)
    )
end

@concrete struct DataPerLink{N_BONDS}
    tags
    is_minimized::Bool
    state
    bond_states
    bond_enabled::NTuple{N_BONDS, Bool}
    reaction_enabled # # NTuple{N_PLACES, Tuple{Bool...}}
end

@concrete struct LinkData{BOND_INPUTS}
    id::Int64
    place_offset::Int64
    "null places"
    places
    param
    "default state"
    state
    bonds # NTuple{N_BONDS, BondConfig}
    reaction_infos # NTuple{N_PLACES, NTuple{N, LinkReactionInfo}}
    "Next link id, always greater than other lids"
    next_lid::Ref{Int64}
    "map from link id to index (lidx)
    link indexes can change whenever a link is added or removed, but id's are stable"
    lid2lidx::Dict{Int64, UInt32}
    "map from link index (lidx) to lid"
    lidx2lid::Vector{Int64}
    per_link_template # default value for per_link
    per_link # struct array of DataPerLink
end

function LinkData(;
        id::Int64,
        place_offset::Int64,
        places::NTuple{N_PLACES, Place},
        param::NamedTuple,
        state::NamedTuple,
        bonds::NTuple{N_BONDS, BondConfig},
        reaction_infos::NTuple{N_PLACES, Tuple},
        reaction_enabled::NTuple{N_PLACES, Tuple},
    ) where {N_BONDS, N_PLACES}
    null_tags = map(places) do p
        Tag{typeof(p)}()
    end
    per_link_template = DataPerLink{N_BONDS}(
        null_tags,
        false,
        state,
        getfield.(bonds, :state),
        getfield.(bonds, :enabled),
        reaction_enabled,
    )
    per_link = StructVector(typeof(per_link_template)[]; unwrap = _default_unwrap)
    bond_inputs = getfield.(bonds, (:input,))
    LinkData{bond_inputs}(
        id,
        place_offset,
        places,
        param,
        state,
        bonds,
        reaction_infos,
        Ref(Int64(1)),
        Dict{Int64, UInt32}(), #lid_to_lidx
        Int64[], #lidx_to_lid
        per_link_template,
        per_link,
    )
end

Base.show(io::IO, ::Type{<:MEDYAN.LinkData}) = print(io, "MEDYAN.LinkData{A bunch of type parameters}")

Base.show(io::IO, ::Type{MEDYAN.LinkData}) = print(io, "MEDYAN.LinkData")


@kwdef struct LinkManager
    names::Vector{Symbol}

    link_data::Vector{LinkData}

    # Tags
    "Filament tip tags"
    fila_tip_tags::TagManager{FilaTipIdx} = TagManager{FilaTipIdx}()

    "Filament monomer tags"
    fila_mono_tags::TagManager{FilaMonoIdx} = TagManager{FilaMonoIdx}()

    # reaction cache
    "True if the cached info is valid"
    cache_valid::typeof(Ref(true)) = Ref(true)

    "cache indexes that store reaction rates per link place"
    reaction_rate_cache_idxs::Vector{UnitRange{Int64}}

    "cache indexes that store nearby monomer counts per link place"
    monomer_count_cache_idxs::Vector{UnitRange{Int64}}

    "cached info indexed by [chem_voxel, total_place_idx], [cache_idx, clpidx].
    Used to pick a random links for a reaction in a chem_voxel"
    chem_voxel_cache::Matrix{ElasticMatrix{Int64,Vector{Int64}}}

    "cached info indexed by [total_place_idx], [lidx] to get (chem_voxel, clpidx)
    If the tag is null, the entry is (0,0)"
    cache_idxs::Vector{Vector{Tuple{Int32, Int32}}}
end

function LinkManager(link_configs::Vector{LinkConfig}, num_chem_voxels::Int64)
    n_total_places = sum(x->length(x.places), link_configs; init=0)
    names = map(x->x.name, link_configs)
    @argcheck allunique(names)
    link_data::Vector{LinkData} = map(link_configs) do config
        @assert length(config.reactions) == length(config.places)
        local reaction_infos = ntuple(length(config.reaction_infos)) do i
            ntuple(length(config.reaction_infos[i])) do j
                config.reaction_infos[i][j]
            end
        end
        local reaction_enabled = ntuple(length(config.reactions)) do i
            ntuple(length(config.reactions[i])) do j
                config.reactions[i][j].enabled
            end
        end
        LinkData(;
            config.id,
            config.place_offset,
            places = Tuple(config.places),
            param = config.param,
            state = config.state,
            bonds = Tuple(config.bonds),
            reaction_enabled,
            reaction_infos,
        )
    end
    # reaction rates and monomer counts at each place
    reaction_rate_cache_idxs = fill(-2:-1, n_total_places)
    monomer_count_cache_idxs = fill(-2:-1, n_total_places)
    for config in link_configs
        for (i, place_reactions) in enumerate(config.reactions)
            reaction_rate_cache_idx = 1 .+ (1:length(place_reactions))
            monomer_count_cache_idx = last(reaction_rate_cache_idx) .+ (1:count(r->!isnothing(r.fila_cutoff), place_reactions))
            reaction_rate_cache_idxs[i+config.place_offset] = reaction_rate_cache_idx
            monomer_count_cache_idxs[i+config.place_offset] = monomer_count_cache_idx
        end
    end

    chem_voxel_cache = ElasticMatrix{Int64,Vector{Int64}}[
        let
            local cache_size = last(monomer_count_cache_idxs[i])
            ElasticArray{Int64}(undef, cache_size, 0)
        end
        for j in 1:num_chem_voxels, i in 1:n_total_places
    ]
    cache_idxs = [Tuple{Int32, Int32}[] for i in 1:n_total_places]
    LinkManager(;names, link_data, reaction_rate_cache_idxs, monomer_count_cache_idxs, chem_voxel_cache, cache_idxs)
end

# cache views

# View the link ids in the voxel
function _cached_lid(m::LinkManager, total_place_idx, chem_voxel)
    view(m.chem_voxel_cache[chem_voxel, total_place_idx], 1, :)
end

# View the reaction rates in the voxel
function _cached_reaction_rates(m::LinkManager, total_place_idx, chem_voxel)
    reinterpret(Q31f32, view(m.chem_voxel_cache[chem_voxel, total_place_idx], m.reaction_rate_cache_idxs[total_place_idx], :))
end

# View the reaction monomer counts in the voxel
function _cached_monomer_counts(m::LinkManager, total_place_idx, chem_voxel)
    view(m.chem_voxel_cache[chem_voxel, total_place_idx], m.monomer_count_cache_idxs[total_place_idx], :)
end