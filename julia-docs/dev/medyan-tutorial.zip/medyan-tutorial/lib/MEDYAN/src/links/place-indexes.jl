"""
Represents temporarily valid references.
"""

struct FilaIdx
    typeid::UInt32
    idx::UInt32
end


struct FilaTipIdx <: Place
    fila_idx::FilaIdx
    is_minus_end::Bool
end
FilaTipIdx() = FilaTipIdx(FilaIdx(0,0), false)
num_directions(::Type{FilaTipIdx}) = 1
struct FilaTipChemState <: PlaceChemState
    tip_monomer_state::UInt8
    next_monomer_state::UInt8
end
FilaTipChemState() = FilaTipChemState(0x00, 0x00)
chem_state_type(::Type{FilaTipIdx}) = FilaTipChemState


struct FilaMonoIdx <: Place
    fila_idx::FilaIdx
    mid::Int64
end
FilaMonoIdx() = FilaMonoIdx(FilaIdx(0,0), 0)
num_directions(::Type{FilaMonoIdx}) = 1
struct FilaMonoChemState <: PlaceChemState
    prev_monomer_state::UInt8
    monomer_state::UInt8
    next_monomer_state::UInt8
end
FilaMonoChemState() = FilaMonoChemState(0x00, 0x00, 0x00)
chem_state_type(::Type{FilaMonoIdx}) = FilaMonoChemState


struct MembVertIdx <: Place
    "membrane index"
    memb_idx::UInt32

    "vertex idx"
    vert_idx::UInt32
end
MembVertIdx() = MembVertIdx(0, 0)
num_directions(::Type{MembVertIdx}) = 0 # TODO support membrane normals
struct MembVertChemState <: PlaceChemState
    vertex_state::UInt8
end
MembVertChemState() = MembVertChemState(0x00)
chem_state_type(::Type{MembVertIdx}) = MembVertChemState
