"""
Represents temporarily valid references.
"""

struct FilaIdx
    typeid::UInt32
    idx::UInt32
end


struct FilaTipIdx <: Place
    fila_idx::FilaIdx
    is_minus_end::Bool
end
FilaTipIdx() = FilaTipIdx(FilaIdx(0,0), false)
num_directions(::Type{FilaTipIdx}) = 1
struct FilaTipChemState <: PlaceChemState
    tip_monomer_state::UInt8
    next_monomer_state::UInt8
end
FilaTipChemState() = FilaTipChemState(0x00, 0x00)
chem_state_type(::Type{FilaTipIdx}) = FilaTipChemState


struct FilaMonoIdx <: Place
    fila_idx::FilaIdx
    mono_idx::Int64
end
FilaMonoIdx() = FilaMonoIdx(FilaIdx(0,0), 0)
num_directions(::Type{FilaMonoIdx}) = 1
struct FilaMonoChemState <: PlaceChemState
    prev_monomer_state::UInt8
    monomer_state::UInt8
    next_monomer_state::UInt8
end
FilaMonoChemState() = FilaMonoChemState(0x00, 0x00, 0x00)
chem_state_type(::Type{FilaMonoIdx}) = FilaMonoChemState