using StaticArrays
using LinearAlgebra
using Random
import ForwardDiff
using Setfield: @set
using ArgCheck: @argcheck
using Rotations: AngleAxis

"""
The `Bond` type is the supertype of all bond force types.
Subtypes should implement `bond_param`, `num_input_directions`, and `bond_energy_force`
"""
abstract type Bond end

"""
    num_input_directions(::Bond)::Vararg{Int}

Return a tuple of the number of additional direction vectors each input has.
"""
function num_input_directions end

"""
    bond_param(::Bond)::Vararg{Symbol}

Return a tuple of the parameter names.
"""
function bond_param end

"""
    bond_energy_force(::Bond, inputs, params) -> (energy, forces)

Return the energy, forces, and torques on the inputs.
`forces[i][1]` is the force on input `i` `forces[i][2]` is the torque on input `i`
if input `i` contains directions.
# Arguments
- `inputs::Tuple{Vararg{Tuple{Vararg{AbstractVector}}}}`: Input vectors.
- `params::NamedTuple`: Parameters.
"""
function bond_energy_force end


#=
Functions to help test Bond implementations.
=#

"""
Test bond_energy_force against the result from ForwardDiff

ArgumentError gets thrown if anything fails.
"""
function test_bond_energy_force_forward_diff(bond::Bond, inputs, params;
        gtol=1E-9
    )
    E0, fs = bond_energy_force(bond, inputs, params)
    for i in eachindex(inputs)
        # force is negative grad of U with position
        g = ForwardDiff.gradient(inputs[i][1]) do x
            local E, fs = bond_energy_force(bond, @set(inputs[i][1]=x), params)
            E
        end
        @argcheck maximum(abs,fs[i][1] + g) ≤ gtol
        # check torque if there are direction inputs
        if length(inputs[i]) > 1
            # torque is grad of U with position × position
            torque = zero(SVector{3, Float64})
            for j in eachindex(inputs[i])[begin+1:end]
                g = ForwardDiff.gradient(inputs[i][j]) do x
                    local E, fs = bond_energy_force(bond, @set(inputs[i][j]=x), params)
                    return E
                end
                torque += g × inputs[i][j]
            end
            @argcheck maximum(abs,fs[i][2] - torque) ≤ gtol
        end
    end
    return true
end

"""
Test bond_energy_force is at a local minimum energy.

ArgumentError gets thrown if not at a local min.
"""
function test_bond_energy_force_at_min(bond::Bond, inputs, params;
        gtol=1E-5, ftol=1E-10, rstd=1E-3, θstd=1E-3, seed=1234, trials=100000)
    #check forces are small
    E0, fs = bond_energy_force(bond, inputs, params)
    for i in eachindex(inputs)
        for j in eachindex(inputs[i])
            @argcheck maximum(abs, fs[i][j]) < gtol
        end
    end
    #check no nearby positions have lower energy
    rng= Random.Xoshiro(seed)
    for t in 1:trials
        local new_inputs = inputs
        for i in eachindex(inputs)
            new_inputs = @set(new_inputs[i][1]+=rstd*randn(rng,SVector{3,Float64}))
            rand_rot = AngleAxis(θstd*randn(), normalize(randn(rng,SVector{3,Float64}))...)
            for j in 2:length(inputs[i])
                new_inputs = @set(
                    new_inputs[i][j] = rand_rot*new_inputs[i][j]
                )
            end
        end
        Etest, fstest = bond_energy_force(bond, new_inputs, params)
        @argcheck Etest-E0 > -ftol
    end
    return true
end

struct ZeroBond{N} <: Bond end
num_input_directions(::ZeroBond{N}) where N = ntuple(Returns(0), N)
bond_param(::ZeroBond) = ()
function bond_energy_force(::ZeroBond{N}, inputs, params) where N
    f = zero(inputs[1][1])
    E = zero(eltype(f))
    E, ntuple(Returns((f,)), N)
end

struct PositionRestraint <: Bond end
num_input_directions(::PositionRestraint) = (0,)
bond_param(::PositionRestraint) = (:k, :r0,)
function bond_energy_force(::PositionRestraint, inputs, params)
    Δr = inputs[1][1] - params.r0
    E = 1//2*params.k*(Δr⋅Δr)
    f = -params.k*Δr
    E, ((f,),)
end

struct ConstantForce <: Bond end
num_input_directions(::ConstantForce) = (0,)
bond_param(::ConstantForce) = (:f,)
function bond_energy_force(::ConstantForce, inputs, params)
    E = -(params.f ⋅ inputs[1][1])
    f = params.f
    E, ((f,),)
end

struct DistanceRestraint <: Bond end
num_input_directions(::DistanceRestraint) = (0,0,)
bond_param(::DistanceRestraint) = (:k, :L0,)
function bond_energy_force(::DistanceRestraint, inputs, params)
    r = inputs[2][1] - inputs[1][1]
    L = norm_fast(r)
    ΔL = L - params.L0
    E = 1//2*params.k*ΔL^2
    pf_sim = -params.k*ΔL*r/L
    E, ((-pf_sim,),(pf_sim,),)
end

struct BranchBendingCosine <: Bond end
num_input_directions(::BranchBendingCosine) = (1,1,)
bond_param(::BranchBendingCosine) = (:kr, :kbend, :cos0, :sin0,)
function bond_energy_force(::BranchBendingCosine, inputs, params)
    Δr = inputs[2][1] - inputs[1][1]
    mv̂ = inputs[1][2]
    pv̂ = inputs[2][2]
    Epos = 1//2 * params.kr * (Δr ⋅ Δr)
    mf = params.kr * Δr
    cosθ = mv̂ ⋅ pv̂
    sinθ = norm_fast(mv̂ × pv̂)
    cosθminus0 = cosθ*params.cos0 + sinθ*params.sin0
    Eθ = params.kbend*(1-cosθminus0)
    k = params.kbend*(params.cos0 - params.sin0*cosθ*inv(sinθ))
    mτ⃗ = k * (mv̂ × pv̂)
    E = Epos + Eθ
    E, ((mf, mτ⃗),(-mf, -mτ⃗),)
end

struct PositionDirectionRestraint <: Bond end
num_input_directions(::PositionDirectionRestraint) = (1,)
bond_param(::PositionDirectionRestraint) = (:kr, :kbend, :r0, :v̂0,)
function bond_energy_force(::PositionDirectionRestraint, inputs, params)
    Δr = inputs[1][1] - params.r0
    v̂ = inputs[1][2]
    E = 1//2*params.kr*(Δr⋅Δr) + params.kbend*(1 - params.v̂0 ⋅ v̂)
    f = -params.kr*Δr
    τ⃗ = -params.kbend*(params.v̂0 × v̂)
    E, ((f, τ⃗),)
end