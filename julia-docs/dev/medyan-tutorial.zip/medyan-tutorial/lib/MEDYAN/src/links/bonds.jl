using StaticArrays
using LinearAlgebra
using Rotations: RotMatrix, Rotations, RodriguesParam

"""
The `Bond` type is the supertype of all bond force types.
Subtypes should implement `bond_param`, `num_input_directions`, and `bond_energy_force`
"""
abstract type Bond end

"""
    num_input_directions(::Bond)::Vararg{Int}

Return a tuple of the number of additional direction vectors each input has.
"""
function num_input_directions end

"""
    bond_param(::Bond)::Vararg{Symbol}

Return a tuple of the parameter names.
"""
function bond_param end

"""
    bond_energy_force(::Bond, inputs, params) -> (energy, forces)

Return the energy, forces, and torques on the inputs.
`forces[i][1]` is the force on input `i` `forces[i][2]` is the torque on input `i`
if input `i` contains directions.
# Arguments
- `inputs::Tuple{Vararg{Tuple{Vararg{AbstractVector}}}}`: Input vectors.
- `params::NamedTuple`: Parameters.
"""
function bond_energy_force end

struct ZeroBond{N} <: Bond end
num_input_directions(::ZeroBond{N}) where N = ntuple(Returns(0), N)
bond_param(::ZeroBond) = ()
function bond_energy_force(::ZeroBond{N}, inputs, params) where N
    f = zero(inputs[1][1])
    E = zero(eltype(f))
    E, ntuple(Returns((f,)), N)
end

struct PositionRestraint <: Bond end
num_input_directions(::PositionRestraint) = (0,)
bond_param(::PositionRestraint) = (:k, :r0,)
function bond_energy_force(::PositionRestraint, inputs, params)
    Δr = inputs[1][1] - params.r0
    E = 1//2*params.k*(Δr⋅Δr)
    f = -params.k*Δr
    E, ((f,),)
end

struct ConstantForce <: Bond end
num_input_directions(::ConstantForce) = (0,)
bond_param(::ConstantForce) = (:f,)
function bond_energy_force(::ConstantForce, inputs, params)
    E = -(params.f ⋅ inputs[1][1])
    f = params.f
    E, ((f,),)
end

struct DistanceRestraint <: Bond end
num_input_directions(::DistanceRestraint) = (0,0,)
bond_param(::DistanceRestraint) = (:k, :L0,)
function bond_energy_force(::DistanceRestraint, inputs, params)
    r = inputs[2][1] - inputs[1][1]
    L = norm_fast(r)
    ΔL = L - params.L0
    E = 1//2*params.k*ΔL^2
    pf_sim = -params.k*ΔL*r*inv(L)
    E, ((-pf_sim,),(pf_sim,),)
end

struct MaxDistanceRestraint <: Bond end
num_input_directions(::MaxDistanceRestraint) = (0,1,)
bond_param(::MaxDistanceRestraint) = (:k, :maxdist, :translated)
function bond_energy_force(::MaxDistanceRestraint, inputs, params)
    # mechstate.translated is how far (in nm) the force on the plus end of the link
    # is translated towards the plus end of the filament
    t = params.translated
    r = (inputs[2][1] + t*inputs[2][2]) - inputs[1][1]
    L = norm_fast(r)
    ΔL = Base.FastMath.max_fast(L - params.maxdist, zero(L))
    E = 1//2*params.k*ΔL^2
    pf_sim = -params.k*ΔL*r*inv(L)
    p_torque = (t*inputs[2][2]) × pf_sim
    E, ((-pf_sim,),(pf_sim, p_torque),)
end

struct BranchBendingCosine <: Bond end
num_input_directions(::BranchBendingCosine) = (1,1,)
bond_param(::BranchBendingCosine) = (:kr, :kbend, :cos0, :sin0,)
function bond_energy_force(::BranchBendingCosine, inputs, params)
    Δr = inputs[2][1] - inputs[1][1]
    mv̂ = inputs[1][2]
    pv̂ = inputs[2][2]
    Epos = 1//2 * params.kr * (Δr ⋅ Δr)
    mf = params.kr * Δr
    cosθ = mv̂ ⋅ pv̂
    sinθ = norm_fast(mv̂ × pv̂)
    cosθminus0 = cosθ*params.cos0 + sinθ*params.sin0
    Eθ = params.kbend*(1-cosθminus0)
    k = params.kbend*(params.cos0 - params.sin0*cosθ*inv(sinθ))
    mτ⃗ = k * (mv̂ × pv̂)
    E = Epos + Eθ
    E, ((mf, mτ⃗),(-mf, -mτ⃗),)
end

struct PositionDirectionRestraint <: Bond end
num_input_directions(::PositionDirectionRestraint) = (1,)
bond_param(::PositionDirectionRestraint) = (:kr, :kbend, :r0, :v̂0,)
function bond_energy_force(::PositionDirectionRestraint, inputs, params)
    Δr = inputs[1][1] - params.r0
    v̂ = inputs[1][2]
    E = 1//2*params.kr*(Δr⋅Δr) + params.kbend*(1 - params.v̂0 ⋅ v̂)
    f = -params.kr*Δr
    τ⃗ = -params.kbend*(params.v̂0 × v̂)
    E, ((f, τ⃗),)
end

struct Position2DirectionRestraint <: Bond end
num_input_directions(::Position2DirectionRestraint) = (2,)
bond_param(::Position2DirectionRestraint) = (:kr, :ktbend, :km1bend, :r0, :t0, :m10)
function bond_energy_force(::Position2DirectionRestraint, inputs, params)
    Δr = inputs[1][1] - params.r0
    t = inputs[1][2]
    m1 = inputs[1][3]
    E = 1//2*params.kr*(Δr⋅Δr) + params.ktbend*(1 - params.t0 ⋅ t) + params.km1bend*(1 - params.m10 ⋅ m1)
    f = -params.kr*Δr
    τ⃗ = -params.ktbend*(params.t0 × t) + -params.km1bend*(params.m10 × m1)
    E, ((f, τ⃗),)
end

"""
    BranchTwisting <: Bond

A bond that models the twisting and bending energy between two connected elements with 
orientational degrees of freedom. This bond type accounts for both positional separation 
and rotational misalignment between the two inputs.

# Input Structure

The bond requires two inputs, each with position and two direction vectors:
- `inputs[1]`: Parent element with `(position, tangent_vector, m1_vector)`  
- `inputs[2]`: Child element with `(position, tangent_vector, m1_vector)`

The tangent vectors (`tp`, `tc`) define the primary orientation, while the `m1` vectors 
define a secondary orientation. The third direction (`m2`) is computed as `tangent × m1` 
to form a complete orthonormal basis for each element.

# Parameters

- `kr::Real`: Spring constant for positional restraint (pN/nm)
- `kbend::Real`: Bending/twisting stiffness constant (pN·nm/rad²)  
- `eq_p_c::RotMatrix{3}`: Equilibrium rotation matrix from parent to child frame.
  The columns represent the equilibrium orientation of the child's basis vectors 
  expressed in the parent frame: `[tangent_child, m1_child, m2_child]`

# Energy Calculation

The total energy consists of two components:

1. **Positional Energy**: `Epos = ½ kr |Δr|²` where `Δr = r_child - r_parent`

2. **Rotational Energy**: Uses Rodrigues parameters to measure angular deviation from 
   equilibrium. The rotational energy is `Eθ = kbend * 2 * tan²(Δθ/2)` where `Δθ` is the 
   angular deviation.
"""
struct BranchTwisting <: Bond end
num_input_directions(::BranchTwisting) = (2,2,)
bond_param(::BranchTwisting) = (:kr, :kbend, :eq_p_c)
function bond_energy_force(::BranchTwisting, inputs, params)
    Δr = inputs[2][1] - inputs[1][1]
    tp = inputs[1][2]
    m1p = inputs[1][3]
    tc = inputs[2][2]
    m1c = inputs[2][3]
    Epos = 1//2 * params.kr * (Δr ⋅ Δr)
    pf = params.kr * Δr
    m2p = tp × m1p
    m2c = tc × m1c
    A_s_p = RotMatrix{3}([tp m1p m2p])
    A_s_c = RotMatrix{3}([tc m1c m2c])
    A_c_s = inv(A_s_c)
    A_c_ce = A_c_s * A_s_p * RotMatrix{3}(params.eq_p_c)
    # Note because of Rotations.jl conventions this is
    # negative of what you might expect.
    RP_c = Rotations.params(RodriguesParam(A_c_ce))
    RP_s = A_s_c * RP_c
    tan²hθ = RP_c ⋅ RP_c
    k = 2*params.kbend
    Eθ = k*tan²hθ
    cτ⃗ = RP_s * (k + Eθ)
    E = Epos + Eθ
    E, ((pf, -cτ⃗),(-pf, cτ⃗),)
end
