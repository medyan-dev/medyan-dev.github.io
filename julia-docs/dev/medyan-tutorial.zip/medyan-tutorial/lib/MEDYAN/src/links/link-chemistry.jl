"""
Callback that will sample a link and do the link reaction affect.
"""
struct LinkReactionCallback{A}
    "type of link this acts on"
    ltid::Int64

    "reaction id"
    reaction_id::Int64

    "index of place in total list of link types places"
    total_place_idx::Int64

    "index of place in `ltid`'s places"
    place_idx::Int64

    "fixed species id"
    fxsid::Int64

    affect!::A
end
function (g::LinkReactionCallback)(c::Context, chem_voxel)::Int64
    totalsites= c.chemistryengine.fixedcounts[g.fxsid, chem_voxel]
    link = _pickrandomlink_reaction(
        c.link_manager,
        totalsites,
        chem_voxel,
        g.ltid,
        g.total_place_idx,
        g.reaction_id,
    )::Union{LinkTag, Nothing}
    if isnothing(link)
        0
    else
        g.affect!(c; chem_voxel, link_tag, reaction_id, place_idx)
    end
end

"""
Return a link tag, or return nothing if rejected
weighted by counts, using the default RNG
"""
function _pickrandomlink_reaction(
        m::LinkManager,
        totalsites::Q31f32,
        chem_voxel::Int64,
        ltid::Int64,
        total_place_idx::Int64,
        reaction_id::Int64,
    )::Union{LinkTag, Nothing}
    @assert m.cache_valid[]
    if iszero(totalsites)
        return
    end
    sitecounts = @view(_cached_reaction_rates(m, total_place_idx, chem_voxel)[reaction_id,:])
    u::Q31f32= Q31f32(totalsites*rand())
    for clpidx in 1:length(sitecounts)
        u -= sitecounts[clpidx]
        if u ≤ 0
            lid = _cached_lid(m, total_place_idx, chem_voxel)[clpidx]
            return LinkTag(ltid, lid)
        end
    end
    return
end

"""
Reset cached data, based on `c`.
reset c.chemistryengine based on the new site counts
"""
function reset_link_cache!(m::LinkManager, c::Context)
    chem_voxel_cache = m.chem_voxel_cache
    cache_idxs = m.cache_idxs
    # wipe all cache
    ElasticArrays.resize_lastdim!.(chem_voxel_cache, 0)
    fill!.(cache_idxs, ((0,0),))
    # go through all places and set the chem voxel it belongs to
    foreach(m.link_data) do d
        foreach(enumerate(d.places)) do (place_idx, nullplace)
            local tags = getproperty(d.per_link.tags, place_idx)
            for (lidx, tag) in enumerate(tags)
                if !is_null(tag)
                    _add_tag_cache!(c, m, d, tag, place_idx, lidx)
                end
            end
        end
    end
    # reset _cached_reaction_rates and chemistryengine
    foreach(m.link_data) do d
        foreach(enumerate(d.reaction_rates)) do (place_idx, rrs)
            local total_place_idx = d.place_offset + place_idx
            foreach(enumerate(rrs)) do (reaction_id, fxsid_rate)
                local fxsid, rate = fxsid_rate
                for chem_voxel in 1:size(chem_voxel_cache, 1)
                    local totalcount = zero(Q31f32)
                    local cached_reaction_rates = _cached_reaction_rates(m, total_place_idx, chem_voxel)
                    for (clpidx, lid) in enumerate(_cached_lid(m, total_place_idx, chem_voxel))
                        local link_tag = LinkTag(d.id, lid)
                        local lidx = _get_idx(d, link_tag)
                        if getproperty(getproperty(d.per_link.reaction_enabled, place_idx), reaction_id)[lidx]
                            local s = Q31f32(rate(c;
                                link_tag,
                                link_data=d,
                                place_idx,
                                link_state=d.per_link.state[lidx],
                            ))
                            cached_reaction_rates[reaction_id,clpidx] = s
                            totalcount += s
                        end
                    end
                    setfixedspeciescount!(c.chemistryengine, fxsid, chem_voxel, totalcount)
                end
            end
        end
    end
    m.cache_valid[] = true
    nothing
end

# remove a tag cache and adjust the site counts in the chem engine
function _remove_tag_cache!(chemistryengine, m::LinkManager, d::LinkData, old_t::Tag, place_idx, lidx)
    @assert m.cache_valid[]
    total_place_idx = d.place_offset + place_idx
    chem_voxel, clpidx = m.cache_idxs[total_place_idx][lidx]
    # remove fixed species
    cached_reaction_rates = _cached_reaction_rates(m, total_place_idx, chem_voxel)
    foreach(enumerate(d.reaction_rates[place_idx])) do (reaction_id, fxsid_rate)
        local fxsid, rate = fxsid_rate
        removeds = cached_reaction_rates[reaction_id, clpidx]
        if !iszero(removeds)
            addfixedspeciescount!(chemistryengine, fxsid, chem_voxel, -removeds)
        end
    end
    # relocate last_clpidx to clpidx
    cache = m.chem_voxel_cache[chem_voxel, total_place_idx]
    last_clpidx = size(cache, 2)
    last_lidx = d.lid2lidx[_cached_lid(m, total_place_idx, chem_voxel)[last_clpidx]]
    m.cache_idxs[total_place_idx][last_lidx] = (chem_voxel, clpidx)
    cache[:, clpidx] .= @view(cache[:, last_clpidx])
    ElasticArrays.resize_lastdim!(cache, last_clpidx - 1)
    m.cache_idxs[total_place_idx][lidx] = (0,0)
    nothing
end

# add space for a tag cache, don't adjust the site counts in the chem engine
function _add_tag_cache!(c::Context, m::LinkManager, d::LinkData, new_t::Tag, place_idx, lidx)
    total_place_idx = d.place_offset + place_idx
    chem_voxel = get_compartment_id(c, get_position(c, new_t))
    cache = m.chem_voxel_cache[chem_voxel, total_place_idx]
    n_cl = size(cache, 2)
    m.cache_idxs[total_place_idx][lidx] = (chem_voxel, n_cl+1)
    ElasticArrays.resize_lastdim!(cache, n_cl+1)
    cache[:, end] .= 0
    cache[1, end] = d.lidx2lid[lidx]
    nothing
end

# update link reactions
function _update_link_reactions!(c::Context, link_tag::LinkTag)
    m = c.link_manager
    _update_link_reactions!(c, m, m.link_data[link_tag.type_id], link_tag)
end
function _update_link_reactions!(c::Context, m::LinkManager, d::LinkData, link_tag::LinkTag)
    @assert m.cache_valid[]
    lidx = _get_idx(d, link_tag)
    foreach(enumerate(d.reaction_rates)) do (place_idx, rrs)
        total_place_idx = d.place_offset + place_idx
        chem_voxel, clpidx = m.cache_idxs[total_place_idx][lidx]
        if !iszero(clpidx) # if this is zero the tag is null
            cached_reaction_rates = _cached_reaction_rates(m, total_place_idx, chem_voxel)
            foreach(enumerate(rrs)) do (reaction_id, fxsid_rate)
                local fxsid, rate = fxsid_rate
                olds = cached_reaction_rates[reaction_id, clpidx]
                news = if getproperty(getproperty(d.per_link.reaction_enabled, place_idx), reaction_id)[lidx]
                    Q31f32(rate(c;
                        link_tag,
                        link_data=d,
                        place_idx,
                        link_state=d.per_link.state[lidx],
                    ))
                else
                    zero(Q31f32)
                end
                Δs = news-olds
                if !iszero(Δs)
                    cached_reaction_rates[reaction_id, clpidx] = news
                    addfixedspeciescount!(c.chemistryengine, fxsid, chem_voxel, Δs)
                end
            end
        end
    end
end


function get_link_mechanics(c::Context, link_tag::LinkTag, d::LinkData=c.link_manager.link_data[link_tag.type_id])
    lidx = _get_idx(d, link_tag)
    tags = d.per_link.tags[lidx]
    inputs = map(tags) do tag
        if is_null(tag)
            nan_3vectors(3)
        else
            local pos = get_position(c, tag)::SVector{3, Float64}
            local dirs = get_directions(c, tag)
            if length(dirs) == 0
                [SA[pos]; nan_3vectors(2)]
            elseif length(dirs) == 1
                [SA[pos]; dirs; nan_3vectors(1)]
            else
                [SA[pos]; dirs]
            end
        end::SVector{3, SVector{3, Float64}}
    end
    energy::Float64 = 0.0
    forces = @SVector zeros(SVector{3,Float64}, length(tags))
    torques = @SVector zeros(SVector{3,Float64}, length(tags))
    bond_states = d.per_link.bond_states[lidx]
    for (bi, bond) in enumerate(d.bonds)
        if d.per_link.bond_enabled[lidx][bi]
            if all(i->!is_null(tags[i]), bond.input)
                local_params = bond_states[bi]
                shared_params = bond.param
                params = merge(shared_params, local_params)
                pos_dirs = map(bond.input) do place_idx
                    inputs[place_idx]
                end
                E, fs = bond_energy_force(bond.bond, pos_dirs, params)
                energy += E
                for (i, place_idx) in enumerate(bond.input)
                    local f = fs[i][1]
                    local τ = if length(fs[i]) == 1
                        zero(SVector{3,Float64})
                    else
                        fs[i][2]
                    end
                    forces = @set(forces[place_idx] += f)
                    torques = @set(torques[place_idx] += τ)
                end
            end
        end
    end
    (;energy, inputs, forces, torques)
end