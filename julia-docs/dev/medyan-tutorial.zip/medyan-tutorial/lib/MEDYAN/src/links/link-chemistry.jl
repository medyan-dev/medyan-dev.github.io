"""
Callback that will sample a link and do the link reaction affect.
"""
struct LinkPlainReactionCallback
    "type of link this acts on"
    ltid::Int64

    "reaction id"
    reaction_id::Int64

    "index of place in total list of link types places"
    total_place_idx::Int64

    "index of place in `ltid`'s places"
    place_idx::Int64

    "fixed species id"
    fxsid::Int64

    affect!
end
function (g::LinkPlainReactionCallback)(c::Context, chem_voxel)::Int64
    totalsites = c.chemistryengine.fixedcounts[g.fxsid, chem_voxel]
    if iszero(totalsites)
        return 0
    end
    m = c.link_manager
    @assert m.cache_valid[]
    sitecounts = @view(_cached_reaction_rates(m, g.total_place_idx, chem_voxel)[g.reaction_id,:])
    u::Q31f32= Q31f32(totalsites*rand())
    for clpidx in 1:length(sitecounts)
        u -= sitecounts[clpidx]
        if u ≤ 0
            link_tag = LinkTag(g.ltid, _cached_lid(m, g.total_place_idx, chem_voxel)[clpidx])
            return g.affect!(c; chem_voxel, link_tag, g.reaction_id, g.place_idx)
        end
    end
    return 0
end

"""
Callback that will sample a link and do the link reaction affect.
"""
struct LinkFilaReactionCallback
    "type of link this acts on"
    ltid::Int64

    "reaction id"
    reaction_id::Int64

    "filament reaction id"
    fila_reaction_id::Int64

    fila_typeid::Int64

    cutoff::Float64

    "index of place in total list of link types places"
    total_place_idx::Int64

    "index of place in `ltid`'s places"
    place_idx::Int64

    "fixed species id"
    fxsid::Int64

    affect!
end
function (g::LinkFilaReactionCallback)(c::Context, chem_voxel)::Int64
    totalsites = c.chemistryengine.fixedcounts[g.fxsid, chem_voxel]
    if iszero(totalsites)
        return 0
    end
    m = c.link_manager
    @assert m.cache_valid[]
    sitecounts = @view(_cached_reaction_rates(m, g.total_place_idx, chem_voxel)[g.reaction_id,:])
    monomercounts = @view(_cached_monomer_counts(m, g.total_place_idx, chem_voxel)[g.fila_reaction_id,:])
    u::Q31f32= Q31f32(totalsites*rand())
    for clpidx in 1:length(sitecounts)
        monomercount = monomercounts[clpidx]
        sitecount::Q31f32 = monomercount * sitecounts[clpidx]
        u -= sitecount
        if u ≤ 0
            link_tag = LinkTag(g.ltid, _cached_lid(m, g.total_place_idx, chem_voxel)[clpidx])
            maybe_other_place = random_nearby_monomer(
                c,
                get_position(c, get_tags(c, link_tag)[g.place_idx]),
                g.fila_typeid,
                g.cutoff,
                monomercount,
            )
            if isnothing(maybe_other_place)
                return 0
            else
                place = maybe_other_place
                return g.affect!(c; chem_voxel, link_tag, g.reaction_id, g.place_idx, place)
            end
        end
    end
    return 0
end

"""
Reset cached data, based on `c`.
reset c.chemistryengine based on the new site counts
"""
function reset_link_cache!(m::LinkManager, c::Context)
    chem_voxel_cache = m.chem_voxel_cache
    cache_idxs = m.cache_idxs
    # wipe all cache
    ElasticArrays.resize_lastdim!.(chem_voxel_cache, 0)
    fill!.(cache_idxs, ((0,0),))
    # go through all places and set the chem voxel it belongs to
    foreach(m.link_data) do d
        foreach(enumerate(d.places)) do (place_idx, nullplace)
            local tags = getproperty(d.per_link.tags, place_idx)
            for (lidx, tag) in enumerate(tags)
                if !is_null(tag)
                    _add_tag_cache!(c, m, d, tag, place_idx, lidx)
                end
            end
        end
    end
    # reset _cached_reaction_rates and chemistryengine
    for d in m.link_data
        for (place_idx, rrs) in enumerate(d.reaction_infos)
            local tags = getproperty(d.per_link.tags, place_idx)
            for (reaction_id, r_info::LinkReactionInfo) in enumerate(rrs)
                _reset_reaction_all_links!(c, m, d, tags, place_idx, reaction_id, r_info)
            end
        end
    end
    m.cache_valid[] = true
    nothing
end

function _reset_reaction_all_links!(
        c::Context,
        m::LinkManager,
        d::LinkData,
        tags,
        place_idx::Int64,
        reaction_id::Int64,
        r_info::LinkPlainReactionInfo,
    )
    total_place_idx = d.place_offset + place_idx
    rate = r_info.rate
    n_chem_voxels = size(m.chem_voxel_cache, 1)
    for chem_voxel in 1:n_chem_voxels
        totalcount = zero(Q31f32)
        cached_reaction_rates = _cached_reaction_rates(m, total_place_idx, chem_voxel)
        for (clpidx, lid) in enumerate(_cached_lid(m, total_place_idx, chem_voxel))
            link_tag = LinkTag(d.id, lid)
            lidx = _get_idx(d, link_tag)
            if getproperty(getproperty(d.per_link.reaction_enabled, place_idx), reaction_id)[lidx]
                s = Q31f32(rate(c;
                    link_tag,
                    link_data=d,
                    place_idx,
                    link_state=d.per_link.state[lidx],
                ))
                cached_reaction_rates[reaction_id,clpidx] = s
                totalcount += s
            end
        end
        setfixedspeciescount!(c.chemistryengine, r_info.fxsid, chem_voxel, totalcount)
    end
end
function _reset_reaction_all_links!(
        c::Context,
        m::LinkManager,
        d::LinkData,
        tags,
        place_idx::Int64,
        reaction_id::Int64,
        r_info::LinkFilaReactionInfo,
    )
    total_place_idx = d.place_offset + place_idx
    rate = r_info.rate
    n_chem_voxels = size(m.chem_voxel_cache, 1)
    for chem_voxel in 1:n_chem_voxels
        totalcount = zero(Q31f32)
        cached_monomer_counts = _cached_monomer_counts(m, total_place_idx, chem_voxel)
        cached_reaction_rates = _cached_reaction_rates(m, total_place_idx, chem_voxel)
        for (clpidx, lid) in enumerate(_cached_lid(m, total_place_idx, chem_voxel))
            link_tag = LinkTag(d.id, lid)
            lidx = _get_idx(d, link_tag)
            if getproperty(getproperty(d.per_link.reaction_enabled, place_idx), reaction_id)[lidx]
                sitecount_mult = Q31f32(rate(c;
                    link_tag,
                    link_data=d,
                    place_idx,
                    link_state=d.per_link.state[lidx],
                ))
                monomer_count = num_nearby_monomers(
                    c,
                    get_position(c, tags[lidx]),
                    r_info.fila_typeid,
                    r_info.cutoff, # Maybe this should have an added eps.
                )
                cached_reaction_rates[reaction_id, clpidx] = sitecount_mult
                cached_monomer_counts[r_info.fila_reaction_id, clpidx] = monomer_count
                totalcount += Q31f32(monomer_count*sitecount_mult)
            end
        end
        setfixedspeciescount!(c.chemistryengine, r_info.fxsid, chem_voxel, totalcount)
    end
end

# remove a tag cache and adjust the site counts in the chem engine
function _remove_tag_cache!(chemistryengine, m::LinkManager, d::LinkData, old_t::Tag, place_idx, lidx)
    @assert m.cache_valid[]
    total_place_idx = d.place_offset + place_idx
    chem_voxel, clpidx = m.cache_idxs[total_place_idx][lidx]
    # remove fixed species
    cached_reaction_rates = _cached_reaction_rates(m, total_place_idx, chem_voxel)
    cached_monomer_counts = _cached_monomer_counts(m, total_place_idx, chem_voxel)
    foreach(enumerate(d.reaction_infos[place_idx])) do (reaction_id, r_info)
        removeds::Q31f32 = if r_info isa LinkPlainReactionInfo
            cached_reaction_rates[reaction_id, clpidx]
        elseif r_info isa LinkFilaReactionInfo
            cached_monomer_counts[r_info.fila_reaction_id, clpidx] * cached_reaction_rates[reaction_id, clpidx]
        else
            error("$(typeof(r_info)) not supported yet")
        end
        if !iszero(removeds)
            addfixedspeciescount!(chemistryengine, r_info.fxsid, chem_voxel, -removeds)
        end
    end
    # relocate last_clpidx to clpidx
    cache = m.chem_voxel_cache[chem_voxel, total_place_idx]
    last_clpidx = size(cache, 2)
    last_lidx = d.lid2lidx[_cached_lid(m, total_place_idx, chem_voxel)[last_clpidx]]
    m.cache_idxs[total_place_idx][last_lidx] = (chem_voxel, clpidx)
    cache[:, clpidx] .= @view(cache[:, last_clpidx])
    ElasticArrays.resize_lastdim!(cache, last_clpidx - 1)
    m.cache_idxs[total_place_idx][lidx] = (0,0)
    nothing
end

# add space for a tag cache, don't adjust the site counts in the chem engine
function _add_tag_cache!(c::Context, m::LinkManager, d::LinkData, new_t::Tag, place_idx, lidx)
    total_place_idx = d.place_offset + place_idx
    chem_voxel = get_compartment_id(c, get_position(c, new_t))
    cache = m.chem_voxel_cache[chem_voxel, total_place_idx]
    n_cl = size(cache, 2)
    m.cache_idxs[total_place_idx][lidx] = (chem_voxel, n_cl+1)
    ElasticArrays.resize_lastdim!(cache, n_cl+1)
    cache[:, end] .= 0
    cache[1, end] = d.lidx2lid[lidx]
    nothing
end

# update link reactions
function _update_link_reactions!(c::Context, link_tag::LinkTag)
    m = c.link_manager
    d = m.link_data[link_tag.typeid]
    @assert m.cache_valid[]
    for (place_idx, rrs) in enumerate(d.reaction_infos)
        lidx = _get_idx(d, link_tag)
        total_place_idx = d.place_offset + place_idx
        chem_voxel, clpidx = m.cache_idxs[total_place_idx][lidx]
        if !iszero(clpidx) # if this is zero the tag is null
            cached_reaction_rates = _cached_reaction_rates(m, total_place_idx, chem_voxel)
            cached_monomer_counts = _cached_monomer_counts(m, total_place_idx, chem_voxel)
            foreach(enumerate(rrs)) do (reaction_id, r_info)
                rate = r_info.rate
                olds = cached_reaction_rates[reaction_id, clpidx]
                news = if getproperty(getproperty(d.per_link.reaction_enabled, place_idx), reaction_id)[lidx]
                    Q31f32(rate(c;
                        link_tag,
                        link_data=d,
                        place_idx,
                        link_state=d.per_link.state[lidx],
                    ))
                else
                    zero(Q31f32)
                end
                Δs = news-olds
                if !iszero(Δs)
                    full_Δs::Q31f32 = if r_info isa LinkPlainReactionInfo
                        Δs
                    elseif r_info isa LinkFilaReactionInfo
                        cached_monomer_counts[r_info.fila_reaction_id, clpidx] * Δs
                    else
                        error("$(typeof(r_info)) not supported yet")
                    end
                    cached_reaction_rates[reaction_id, clpidx] = news
                    addfixedspeciescount!(c.chemistryengine, r_info.fxsid, chem_voxel, full_Δs)
                end
            end
        end
    end
end

function get_link_mechanics(c::Context, link_tag::LinkTag, d::LinkData=c.link_manager.link_data[link_tag.typeid])
    lidx = _get_idx(d, link_tag)
    tags = d.per_link.tags[lidx]
    inputs = map(tags) do tag
        if is_null(tag)
            nan_3vectors(3)
        else
            local pos = get_position(c, tag)::SVector{3, Float64}
            local dirs = get_directions(c, tag)
            if length(dirs) == 0
                [SA[pos]; nan_3vectors(2)]
            elseif length(dirs) == 1
                [SA[pos]; dirs; nan_3vectors(1)]
            else
                [SA[pos]; dirs]
            end
        end::SVector{3, SVector{3, Float64}}
    end
    energy::Float64 = 0.0
    forces = @SVector zeros(SVector{3,Float64}, length(tags))
    torques = @SVector zeros(SVector{3,Float64}, length(tags))
    bond_states = d.per_link.bond_states[lidx]
    for (bi, bond) in enumerate(d.bonds)
        if d.per_link.bond_enabled[lidx][bi]
            if all(i->!is_null(tags[i]), bond.input)
                local_params = bond_states[bi]
                shared_params = bond.param
                params = merge(shared_params, local_params)
                pos_dirs = map(bond.input) do place_idx
                    inputs[place_idx]
                end
                E, fs = bond_energy_force(bond.bond, pos_dirs, params)
                energy += E
                for (i, place_idx) in enumerate(bond.input)
                    local f = fs[i][1]
                    local τ = if length(fs[i]) == 1
                        zero(SVector{3,Float64})
                    else
                        fs[i][2]
                    end
                    forces = @set(forces[place_idx] += f)
                    torques = @set(torques[place_idx] += τ)
                end
            end
        end
    end
    (;energy, inputs, forces, torques)
end