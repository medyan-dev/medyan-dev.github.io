"""
    $(FUNCTIONNAME)(c::Context, p::Anchor)::Tag{Anchor}

Return the new tagged anchor.

This represents a fixed position and frame in the simulation.
"""
function make_anchor!(c::Context, p::Anchor)::Tag{Anchor}
    if has_tag(c, p)
        throw(ArgumentError("p already exists as an anchor"))
    end
    tag!(c, p)
end

"""
    $(FUNCTIONNAME)(c::Context, anchor::Union{Anchor, Tag{Anchor}})::Nothing

Remove an anchor. Any attached links will be unlinked.
"""
function remove_anchor!(c::Context, anchor::Anchor)::Nothing
    helper_removeplace!(c, anchor; warn_if_unlink=false)
end
function remove_anchor!(c::Context, t::Tag{Anchor})::Nothing
    helper_removetag!(c, t; warn_if_unlink=false)
end

"""
    $(FUNCTIONNAME)(c::Context, tag::Tag{Anchor}, new_anchor::Anchor)::Nothing

Update an anchor associated with a tag.
"""
function update_anchor!(c::Context, tag::Tag{Anchor}, new_anchor::Anchor)::Nothing
    _move_place!(_tag_manager(c.link_manager, Anchor()), tag2place(c, tag), new_anchor)
    if is_chem_cache_valid(c)
        for link in tag2links(c, tag)
            _update_link_reactions!(c, link)
        end
    end
    nothing
end
