


function assert_invariants(l::LinkManager)
    @argcheck isempty(l.link_data) # link data not supported yet
    assert_invariants(l.fila_tip_tags)
    assert_invariants(l.fila_mono_tags)
    l
end

function statistically_equal(a::LinkManager, b::LinkManager)
    assert_invariants(a)
    assert_invariants(b)
    statistically_equal(a.fila_tip_tags, b.fila_tip_tags)
    statistically_equal(a.fila_mono_tags, b.fila_mono_tags)
end

function Base.empty!(l::LinkManager)
    foreach(l.link_data) do linkdata
        empty!(linkdata)
    end
    empty!(l.fila_tip_tags)
    empty!(l.fila_mono_tags)
    l
end

# Get the tag manager for each type of place
_tag_manager(l::LinkManager, ::FilaTipIdx) = l.fila_tip_tags
_tag_manager(l::LinkManager, ::FilaMonoIdx) = l.fila_mono_tags

# Set of available places
_all_place_types() = (FilaTipIdx, FilaMonoIdx)