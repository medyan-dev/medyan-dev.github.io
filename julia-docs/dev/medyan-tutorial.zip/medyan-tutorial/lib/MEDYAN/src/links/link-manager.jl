num_link_types(c::Context) = length(c.link_manager.link_data)

function get_tags(c::Context, link_tag::LinkTag)
    error("not implemented yet")
end

function get_links(c::Context, p::Place)
    error("not implemented yet")
end

function get_links(c::Context, link_type::Union{Symbol,Int})
    error("not implemented yet")
end

function make_link!(c::Context;
        link_type::Union{Symbol,Int},
        places::NTuple{N, Place},
    )::LinkTag where {N}
    error("not implemented yet")
end

function remove_link!(c::Context, link_tag::LinkTag)
    error("not implemented yet")
end



function assert_invariants(m::LinkManager)
    assert_invariants(m.fila_tip_tags)
    assert_invariants(m.fila_mono_tags)
    @argcheck allunique((d.name for d in m.link_data))
    @argcheck all((d.id == i for (i, d) in enumerate(m.link_data)))
    m
end

function statistically_equal(a::LinkManager, b::LinkManager)
    assert_invariants(a)
    assert_invariants(b)
    statistically_equal(a.fila_tip_tags, b.fila_tip_tags)
    statistically_equal(a.fila_mono_tags, b.fila_mono_tags)
end

function Base.empty!(l::LinkManager)
    foreach(l.link_data) do linkdata
        empty!(linkdata)
    end
    empty!(l.fila_tip_tags)
    empty!(l.fila_mono_tags)
    l
end

function Base.empty!(d::LinkData)
    empty!(d.free_idxs)
    empty!(d.per_link)
    d
end

# Get the tag manager for each type of place
_tag_manager(l::LinkManager, ::FilaTipIdx) = l.fila_tip_tags
_tag_manager(l::LinkManager, ::FilaMonoIdx) = l.fila_mono_tags

# Set of available places
_all_place_types() = (FilaTipIdx, FilaMonoIdx)