"""
    $(FUNCTIONNAME)(c::Context)::Int

Return the number of link types.
"""
function num_link_types(c::Context)
    length(c.link_manager.link_data)
end

"""
    $(FUNCTIONNAME)(c::Context, link::Link)::Symbol
    $(FUNCTIONNAME)(c::Context, link_typeid::Integer)::Symbol

Return the name of the `link`'s type, or the name associated with `link_typeid`
"""
function link_type_name(c::Context, link_typeid::Integer)::Symbol
    c.link_manager.names[link_typeid]
end
function link_type_name(c::Context, link::Link)::Symbol
    link_type_name(c, link.typeid)
end


"""
    $(FUNCTIONNAME)(c::Context, p::Place)::Tag

Return the tag of the place.
Throw an error if `!has_tag(p)`.
"""
function place2tag(c::Context, p::P)::Tag{P} where {P <: Place}
    @argcheck has_tag(c, p)
    tag!(c, p)
end

"""
    $(FUNCTIONNAME)(c::Context, p::Place)::Tag

Return the tag of the place.
Throw an error if `!place_exists(p)`.
Create a new tag if `!has_tag(p)`.
"""
function tag!(c::Context, p::P)::Tag{P} where {P <: Place}
    @argcheck place_exists(c, p)
    _tag!(_tag_manager(c.link_manager, p), p)
end

"""
    $(FUNCTIONNAME)(c::Context, p::Place)::Bool

Return true iff `p` has a tag.
Otherwise return false.
If `!place_exists(c, p)` return false.
"""
function has_tag(c::Context, p::Place)::Bool
    tm = _tag_manager(c.link_manager, p)
    haskey(tm.place2idx, p)
end

"""
    $(FUNCTIONNAME)(c::Context, t::Tag)::Place

Return the place of the tag.
Throw an error if `!tag_exists(t)`.
"""
function tag2place(c::Context, t::Tag{P}) where {P}
    _get_place(_tag_manager(c.link_manager, P()), t)
end

"""
    $(FUNCTIONNAME)(c::Context, x::Union{Tag, Place})::SVector{3, Float64}

Return the position of `x`.
Throw an error if `x` doesn't exist.
"""
get_position(c::Context, id::Tag)::SVector{3, Float64} = get_position(c, tag2place(c, id))

"""
    $(FUNCTIONNAME)(c::Context, x::Union{Tag, Place})::SVector{N, SVector{3, Float64}}

Return the directions of `x`.
`N` is from [`num_directions`](@ref).
Throw an error if `x` doesn't exist.
"""
get_directions(c::Context, id::Tag) = get_directions(c, tag2place(c, id))

"""
    $(FUNCTIONNAME)(c::Context, x::Union{Tag, Place})

Return the chemical state of `x`.
Each type of place has a different type of chemical state.
If the chemical state of a place changes, any attached links will have their
reaction rates recalculated.
Throw an error if `x` doesn't exist.
"""
get_chem_state(c::Context, id::Tag) = get_chem_state(c, tag2place(c, id))

"""
    $(FUNCTIONNAME)(c::Context, t::Tag)::Bool

Return true iff tag `t` exists in context `c`.
Otherwise return false.
"""
function tag_exists(c::Context, id::Tag{P})::Bool where {P}
    !isnothing(_try_get_idx(_tag_manager(c.link_manager, P()), id))
end

"""
    $(FUNCTIONNAME)(c::Context, p::Place) -> Tag{typeof(p)} iterator

Return an iterator of existing tags for the type of p.
"""
function get_all_tags(c::Context, p::P)::TagManager{P} where {P <: Place}
    _tag_manager(c.link_manager, p)
end

"""
    $(FUNCTIONNAME)(c::Context, link::Link, [d::LinkData]) -> Tag tuple

Return a tuple of tags of places that `link` is attached to.
If one of the places of `link` is not attached that tag will be null.
Throw an error if `link` doesn't exist.
"""
function link2tags(c::Context, link::Link, d::LinkData=c.link_manager.link_data[link.typeid])
    idx = _get_idx(d, link)
    d.per_link.tags[idx]
end

"""
    $(FUNCTIONNAME)(c::Context, link::Link, [d::LinkData])

Return the state of the link.
Throw an error if `link` doesn't exist.
"""
function get_state(c::Context, link::Link, d = c.link_manager.link_data[link.typeid])
    idx = _get_idx(d, link)
    d.per_link.state[idx]
end

"""
    $(FUNCTIONNAME)(c::Context, link::Link, [d::LinkData])

Return the bond_states of the link.
Throw an error if `link` doesn't exist.
"""
function get_bond_states(c::Context, link::Link, d = c.link_manager.link_data[link.typeid])
    idx = _get_idx(d, link)
    d.per_link.bond_states[idx]
end

"""
    $(FUNCTIONNAME)(c::Context, link::Link, [d::LinkData])

Return the bond_enabled flags of the link.
Throw an error if `link` doesn't exist.
"""
function get_bond_enabled(c::Context, link::Link, d = c.link_manager.link_data[link.typeid])
    idx = _get_idx(d, link)
    d.per_link.bond_enabled[idx]
end

"""
    $(FUNCTIONNAME)(c::Context, link::Link, [d::LinkData])

Return the reaction_enabled flags of the link.
Throw an error if `link` doesn't exist.
"""
function get_reaction_enabled(c::Context, link::Link, d = c.link_manager.link_data[link.typeid])
    idx = _get_idx(d, link)
    d.per_link.reaction_enabled[idx]
end

"""
    $(FUNCTIONNAME)(c::Context, link::Link, [d::LinkData])::Bool

Return the is_minimized flag of the link.
Throw an error if `link` doesn't exist.
"""
function is_minimized(c::Context, link::Link, d = c.link_manager.link_data[link.typeid])
    idx = _get_idx(d, link)
    d.per_link.is_minimized[idx]
end

function _try_get_idx(d::LinkData, id::Link)::Union{UInt32,Nothing}
    id.typeid == d.id || return nothing
    get(Returns(nothing), d.lid2lidx, id.id)
end
function _get_idx(d::LinkData, id::Link)::UInt32
    something(_try_get_idx(d, id))
end

"""
    $(FUNCTIONNAME)(c::Context, link::Link)::Bool

Return true iff `link` exists in context `c`.
Otherwise return false.
"""
function link_exists(c::Context, link::Link)::Bool
    link.typeid ∈ eachindex(c.link_manager.link_data) || return false
    d = c.link_manager.link_data[link.typeid]
    haskey(d.lid2lidx, link.id)
end

"""
    $(FUNCTIONNAME)(c::Context, p::Place) -> Link iterator

Return an iterator of `Link`s attached to `p`.
If `!place_exists(c, p)` return an empty iterator.
"""
function place2links(c::Context, p::Place)::Vector{Link}
    if has_tag(c, p)
        tm = _tag_manager(c.link_manager, p)
        idx = tm.place2idx[p]
        tm.idx2reflinks[idx]
    else
        Link[]
    end
end

"""
    $(FUNCTIONNAME)(c::Context, t::Tag) -> Link iterator

Return an iterator of `Link`s attached to `t`.
If `!tag_exists(c, t)` return an empty iterator.
"""
function tag2links(c::Context, t::Tag{P})::Vector{Link} where {P}
    tm = _tag_manager(c.link_manager, P())
    idx = _try_get_idx(tm, t)
    if !isnothing(idx)
        tm.idx2reflinks[idx]
    else
        Link[]
    end
end

const LINK_UPDATE_DOCS = """
- `places=()`: places or tags to attach to the link.

  Set an element to `nothing` not change the attached place.
  Set an element to a null place or tag to detach that place.
- `state=(;)`: state properties to change.

  A `NamedTuple` of changes. For example, `state = (;k1 = 3.6, k7 = 2.0,)` to change `state.k1` to `3.6` and `state.k7` to `2.0`.
- `bond_states=()`: bond state properties to change.

  A `Tuple` of changes. If an element in the tuple is `nothing`, the corresponding bond state isn't changed. For example, `bond_states = (nothing, (;L0 = 3.6,))` to change `bond_states[2].L0` to `3.6`.
- `bond_enabled=()`: bond enable flags to change.

  A `Tuple` of `Union{Bool, Nothing}. If an element in the tuple is `nothing`, the corresponding bond enable flag isn't changed. For example, `bond_enabled = (nothing, true, false)` to not change bond 1, enable bond 2, and disable bond 3.
- `reaction_enabled=()`: reaction enable flags to change.

  A `Tuple` of `Tuple` of `Union{Bool, Nothing}. If an element in the tuple is `nothing`, the corresponding reaction enable flag or flags aren't changed. For example, `reaction_enabled = (nothing, (true, nothing, false))` to not change any reactions on place 1, enable reaction 1 on place 2, and disable reaction 3 on place 2.
- `is_minimized::Bool=false`: is the link marked as minimized.

  By default links are marked as minimized at the end of mechanics when updated.
"""

"""
    $(FUNCTIONNAME)(c::Context; kwargs...)::Link

Return the new link.

The `type` keyword argument is required.

The other keyword arguments can be used to change the link from default.

# Keyword Arguments

- `type::Union{Symbol,Integer}`: the link type id or symbol.
$(LINK_UPDATE_DOCS)
"""
function make_link!(c::Context;
        type::Union{Symbol,Integer},
        places=(),
        state=(;),
        bond_states=(),
        bond_enabled=(),
        reaction_enabled=(),
        is_minimized::Bool=false,
    )::Link
    link_typeid::UInt32 = _normalize_link_type(c.link_manager, type)
    d = c.link_manager.link_data[link_typeid]
    _make_link!(
        c,
        c.link_manager,
        d,
        places,
        state,
        bond_states,
        bond_enabled,
        reaction_enabled,
        is_minimized,
    )
end
function _make_link!(
        c::Context,
        m::LinkManager,
        d::LinkData,
        places,
        state,
        bond_states,
        bond_enabled,
        reaction_enabled,
        is_minimized::Bool,
    )::Link
    c.stats.make_link_count += 1
    per_link = d.per_link
    lid = d.next_lid[]
    link = Link(d.id, lid)
    @assert lid ∉ keys(d.lid2lidx)
    lidx = UInt32(length(per_link) + 1)
    next_lid = Base.checked_add(lid, Int64(1))
    # prepare states, use default for now
    push!(per_link, d.per_link_template)
    n_places = length(d.places)
    place_offset = d.place_offset
    for total_place_idx in place_offset+1:place_offset+n_places
        push!(m.cache_idxs[total_place_idx], (0,0))
    end
    # Update state, undo push if this fails
    try
        d.lid2lidx[lid] = lidx
        push!(d.lidx2lid, lid)
        _update_link!(
            c,
            m,
            d,
            link,
            places,
            state,
            bond_states,
            bond_enabled,
            reaction_enabled,
            is_minimized,
        )
    catch
        pop!(per_link)
        pop!(d.lidx2lid)
        delete!(d.lid2lidx, lid)
        for total_place_idx in place_offset+1:place_offset+n_places
            pop!(m.cache_idxs[total_place_idx])
        end
        rethrow()
    end
    d.next_lid[] = next_lid
    link
end

"""
    $(FUNCTIONNAME)(c::Context, link::Link)::Nothing

Remove the link.
"""
function remove_link!(c::Context, link::Link)
    _remove_link!(
        c,
        c.link_manager,
        c.link_manager.link_data[link.typeid],
        link.id,
    )
    nothing
end
function _remove_link!(c::Context, m::LinkManager, d::LinkData, lid::Int64)
    c.stats.remove_link_count += 1
    removed_link = Link(d.id, lid)
    @argcheck haskey(d.lid2lidx, lid)
    lidx = d.lid2lidx[lid]
    # remove references in tags
    n_places = length(d.places)
    place_offset = d.place_offset
    foreach(enumerate(d.per_link.tags[lidx])) do (place_idx, tag)
        if !is_null(tag)
            local tm = _tag_manager(m, tag)
            local t_idx = _get_idx(tm, tag)
            local reflinks = tm.idx2reflinks[t_idx]
            if removed_link ∈ reflinks
                tm.idx2reflinks[t_idx] = filter(!=(removed_link), reflinks)
            end
            # Update cache
            if m.cache_valid[]
                # remove tag cached data
                if !is_null(tag)
                    _remove_tag_cache!(c.chemistryengine, m, d, tag, place_idx, lidx)
                end
            end
        end
    end
    last_lid = d.lidx2lid[end]
    d.per_link[lidx] = d.per_link[end]
    pop!(d.per_link)

    d.lid2lidx[last_lid] = lidx
    delete!(d.lid2lidx, lid)

    d.lidx2lid[lidx] = last_lid
    pop!(d.lidx2lid)

    for total_place_idx in place_offset+1:place_offset+n_places
        m.cache_idxs[total_place_idx][lidx] = m.cache_idxs[total_place_idx][end]
        pop!(m.cache_idxs[total_place_idx])
    end
    nothing
end

"""
    $(FUNCTIONNAME)(c::Context, link::Link; kwargs...)::Nothing

Update the link.

# Keyword Arguments

$(LINK_UPDATE_DOCS)
"""
function update_link!(c::Context,
        link::Link;
        places=(),
        state=(;),
        bond_states=(),
        bond_enabled=(),
        reaction_enabled=(),
        is_minimized::Bool=false,
    )
    _update_link!(
        c,
        c.link_manager,
        c.link_manager.link_data[link.typeid],
        link,
        places,
        state,
        bond_states,
        bond_enabled,
        reaction_enabled,
        is_minimized,
    )
    nothing
end
function _update_link!(
        c::Context,
        m::LinkManager,
        d::LinkData,
        updated_link::Link,
        places,
        state,
        bond_states,
        bond_enabled,
        reaction_enabled,
        is_minimized::Bool,
    )
    c.stats.update_link_count += 1
    per_link = d.per_link
    lidx = _get_idx(d, updated_link)
    # update tags
    foreach(enumerate(places)) do (place_idx, p)
        total_place_idx = d.place_offset + place_idx
        isnothing(p) && return
        local old_t = getproperty(per_link.tags, place_idx)[lidx]
        local new_t = if p isa Tag
            p
        elseif is_null(p)
            Tag{typeof(p)}()
        else
            tag!(c, p)
        end::typeof(old_t)
        if old_t != new_t
            getproperty(per_link.tags, place_idx)[lidx] = new_t
            local tags = per_link.tags[lidx]
            local tm = _tag_manager(m, old_t)
            # one of the other tags might be old_t
            if !is_null(old_t) && old_t ∉ tags
                local old_t_idx = _get_idx(tm, old_t)
                local old_reflinks = tm.idx2reflinks[old_t_idx]
                tm.idx2reflinks[old_t_idx] = filter(!=(updated_link), old_reflinks)
            end
            _patch_new_reflink!(m, new_t, updated_link)
            # Update cache
            if m.cache_valid[]
                # remove tag cached data
                if !is_null(old_t)
                    _remove_tag_cache!(c.chemistryengine, m, d, old_t, place_idx, lidx)
                end
                # add tag cached data space
                if !is_null(new_t)
                    _add_tag_cache!(c, m, d, new_t, total_place_idx, lidx)
                end
            end
        end
    end
    for (k, v) in pairs(state)
        getproperty(per_link.state, k)[lidx] = v
    end
    for (bi, bond_state) in enumerate(bond_states)
        if !isnothing(bond_state)
            for (k, v) in pairs(bond_state)
                getproperty(getproperty(per_link.bond_states, bi), k)[lidx] = v
            end
        end
    end
    for (bi, x) in enumerate(bond_enabled)
        if !isnothing(x)
            getproperty(per_link.bond_enabled, bi)[lidx] = x
        end
    end
    for (place_idx, xs) in enumerate(reaction_enabled)
        if !isnothing(xs)
            for (reaction_id, x) in enumerate(xs)
                if !isnothing(x)
                    getproperty(getproperty(per_link.reaction_enabled, place_idx), reaction_id)[lidx] = x
                end
            end
        end
    end
    per_link.is_minimized[lidx] = is_minimized
    if m.cache_valid[]
        _update_link_reactions!(c, updated_link)
    end
    nothing
end

function _patch_new_reflink!(m::LinkManager, new_t::Tag, updated_link::Link)
    if !is_null(new_t)
        tm = _tag_manager(m, new_t)
        new_t_idx = _get_idx(tm, new_t)
        new_reflinks = tm.idx2reflinks[new_t_idx]
        # avoid multiple copies of link tag,
        # incase tag is a repeat
        if updated_link ∉ new_reflinks
            tm.idx2reflinks[new_t_idx] = [new_reflinks; updated_link]
        end
    end
    nothing
end

# Set all is_minimized to true
function _set_all_minimized!(m::LinkManager)
    foreach(m.link_data) do d
        d.per_link.is_minimized .= true
    end
end

function _normalize_link_type(m::LinkManager, type::Union{Symbol,Integer})::UInt32
    if type isa Symbol
        @something(
            findfirst(==(type), m.names),
            throw(ArgumentError("$(type) not found"))
        )
    else
        @argcheck type ∈ eachindex(m.link_data)
        type
    end
end

# Iterable interface
"""
    $(FUNCTIONNAME)(c::Context; type::Union{Symbol,Integer}) -> Link iterator

Return an iterator of all `Link`s of `type` type.
"""
function get_all_links(c::Context; type::Union{Symbol,Integer})::LinkData
    link_typeid::UInt32 = _normalize_link_type(c.link_manager, type)
    c.link_manager.link_data[link_typeid]
end
# Iterates through valid Links in the LinkData.
Base.length(d::LinkData)::Int64 = length(d.lidx2lid)
function Base.iterate(d::LinkData, state::NamedTuple)
    nextidx = state.curidx + 1
    if nextidx ∈ eachindex(d.lidx2lid)
        (Link(d.id, d.lidx2lid[nextidx]), (; curidx = Int64(nextidx)))
    else
        nothing
    end
end
Base.iterate(d::LinkData) = iterate(d, (; curidx=Int64(0)))
Base.eltype(::Type{<:LinkData}) = Link



function assert_invariants(m::LinkManager)
    foreach(_all_place_types(m)) do P
        assert_invariants(_tag_manager(m, P()))
    end
    @argcheck allunique(m.names)
    @argcheck length(m.names) == length(m.link_data)
    @argcheck all((d.id == i for (i, d) in enumerate(m.link_data)))
    foreach(assert_invariants, m.link_data)
    # check place_offset
    for i in 1:length(m.link_data)
        local d = m.link_data[i]
        if isone(i)
            @argcheck iszero(d.place_offset)
        else
            @argcheck d.place_offset == m.link_data[i-1].place_offset + length(m.link_data[i-1].places)
        end
    end
    # check cache idxs
    total_n_places = sum(d->length(d.places), m.link_data; init=0)
    @argcheck length(m.reaction_rate_cache_idxs) == total_n_places
    @argcheck length(m.monomer_count_cache_idxs) == total_n_places
    foreach(m.link_data) do d
        @argcheck length(d.reaction_infos) == length(d.places)
        for place_idx in 1:length(d.places)
            @argcheck m.reaction_rate_cache_idxs[d.place_offset + place_idx] === 2:1+length(d.reaction_infos[place_idx])
            local n_moncounts = count(r -> r isa LinkFilaReactionInfo, d.reaction_infos[place_idx])
            @argcheck m.monomer_count_cache_idxs[d.place_offset + place_idx] === 2+length(d.reaction_infos[place_idx]):1+length(d.reaction_infos[place_idx])+n_moncounts
        end
    end
    # check place cache idx spot
    @argcheck length(m.cache_idxs) == total_n_places
    foreach(m.link_data) do d
        for total_place_idx in d.place_offset+1:d.place_offset+length(d.places)
            @argcheck length(m.cache_idxs[total_place_idx]) == length(d.per_link)
        end
    end
    # check ref links in tags match
    foreach(m.link_data) do d
        for (lidx, tags) in enumerate(d.per_link.tags)
            local l_tag = Link(d.id, d.lidx2lid[lidx])
            for t in unique(tags)
                if !is_null(t)
                    local tm = _tag_manager(m, t)
                    local idx = _get_idx(tm, t)
                    @argcheck l_tag ∈ tm.idx2reflinks[idx]
                end
            end
        end
    end
    foreach(_all_place_types(m)) do P
        local tm = _tag_manager(m, P())
        for t in tm
            local idx = _get_idx(tm, t)
            local reflinks = tm.idx2reflinks[idx]
            @argcheck allunique(reflinks)
            for l_tag in reflinks
                local d = m.link_data[l_tag.typeid]
                local lidx = _get_idx(d, l_tag)
                @argcheck t ∈ d.per_link.tags[lidx]
            end
        end
    end
    # check cache
    if m.cache_valid[]
        foreach(m.link_data) do d
            for lidx in 1:length(d)
                for place_idx in 1:length(d.places)
                    local total_place_idx = d.place_offset + place_idx
                    local chem_voxel, clpidx = m.cache_idxs[total_place_idx][lidx]
                    local tag = d.per_link.tags[lidx][place_idx]
                    if iszero(clpidx)
                        @argcheck is_null(tag)
                        @argcheck iszero(chem_voxel)
                    else
                        @argcheck !is_null(tag)
                        @argcheck !iszero(chem_voxel)
                        @argcheck _cached_lid(
                            m,
                            d.place_offset + place_idx,
                            chem_voxel,
                        )[clpidx] == d.lidx2lid[lidx]
                    end
                end
            end
            for place_idx in 1:length(d.places)
                local total_place_idx = d.place_offset + place_idx
                for chem_voxel in 1:size(m.chem_voxel_cache, 1)
                    for (clpidx, lid) in enumerate(_cached_lid(m, total_place_idx, chem_voxel))
                        local lidx = _get_idx(d, Link(d.id, lid))
                        @argcheck m.cache_idxs[total_place_idx][lidx] == (chem_voxel, clpidx)
                    end
                end
            end
        end
    end
    m
end

function assert_invariants(d::LinkData)
    n = length(d)
    @argcheck n == length(d.per_link)
    @argcheck n == length(d.lid2lidx)
    @argcheck n == length(d.lidx2lid)
    @argcheck d.next_lid[] > maximum(d.lidx2lid; init=Int64(0))
    @argcheck all(>(0), d.lidx2lid)
    for lidx in UInt32(1):UInt32(n)
        lid = d.lidx2lid[lidx]
        @argcheck lidx === d.lid2lidx[lid]
    end
    d
end

"""
Check if two `LinkManager` are statistically equal, the internal free lists may be different
"""
function statistically_equal(a::LinkManager, b::LinkManager)
    assert_invariants(a)
    assert_invariants(b)
    @assert a.cache_valid[]
    @assert b.cache_valid[]
    a.names == b.names || return false
    _all_place_types(a) == _all_place_types(b) || return false
    all(_all_place_types(a)) do P
        statistically_equal(_tag_manager(a, P()), _tag_manager(b, P()))
    end || return false
    length(a.link_data) == length(b.link_data) || return false
    for i in eachindex(a.link_data)
        statistically_equal(a.link_data[i], b.link_data[i]) || return false
    end
    # check caches are equivalent, but possible in different orders
    for link_typeid in eachindex(a.link_data)
        local d = a.link_data[link_typeid]
        for place_idx in 1:length(d.places)
            local total_place_idx = d.place_offset + place_idx
            for lidx in 1:length(d)
                local a_chem_voxel, a_clpidx = a.cache_idxs[total_place_idx][lidx]
                local b_chem_voxel, b_clpidx = b.cache_idxs[total_place_idx][lidx]
                a_chem_voxel == b_chem_voxel || return false
                if !iszero(a_chem_voxel)
                    @assert _cached_lid(a, total_place_idx, a_chem_voxel)[a_clpidx] == _cached_lid(b, total_place_idx, b_chem_voxel)[b_clpidx]
                    _cached_reaction_rates(a, total_place_idx, a_chem_voxel)[:, a_clpidx] == _cached_reaction_rates(b, total_place_idx, b_chem_voxel)[:, b_clpidx] || return false
                end
            end
        end
    end
    return true
end

function statistically_equal(a::LD, b::LD) where {LD <: LinkData}
    isequal(a.id, b.id) || return false
    isequal(a.place_offset, b.place_offset) || return false
    isequal(a.places, b.places) || return false
    isequal(a.param, b.param) || return false
    isequal(a.state, b.state) || return false
    isequal(a.bonds, b.bonds) || return false
    isequal(a.lid2lidx, b.lid2lidx) || return false
    isequal(a.lidx2lid, b.lidx2lid) || return false
    isequal(a.next_lid[], b.next_lid[]) || return false
    isequal(a.per_link, b.per_link) || return false
    isequal(a.reaction_infos, b.reaction_infos) || return false
    return true
end

#remove all links.
#does not reset c.chemistryengine based on the new site counts
function Base.empty!(m::LinkManager)
    foreach(m.link_data) do linkdata
        empty!(linkdata)
    end
    foreach(_all_place_types(m)) do P
        empty!(_tag_manager(m, P()))
    end
    ElasticArrays.resize_lastdim!.(m.chem_voxel_cache, 0)
    empty!.(m.cache_idxs)
    m.cache_valid[] = true
    m
end

function Base.empty!(d::LinkData)
    empty!(d.per_link)
    empty!(d.lid2lidx)
    empty!(d.lidx2lid)
    d.next_lid[] = 1
    d
end
