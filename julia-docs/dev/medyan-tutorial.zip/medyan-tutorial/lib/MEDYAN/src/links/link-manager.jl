num_link_types(c::Context) = length(c.link_manager.link_data)

function tag!(c::Context, p::Place)
    @argcheck place_exists(c, p)
    _tag!(_tag_manager(c.link_manager, p), p)
end

function has_tag(c::Context, p::Place)
    tm = _tag_manager(c.link_manager, p)
    haskey(tm.place2idx, p)
end

function get_place(c::Context, id::Tag{P}) where {P}
    _get_place(_tag_manager(c.link_manager, P()), id)
end

# Return if a tag exists
function tag_exists(c::Context, id::Tag{P})::Bool where {P}
    !isnothing(_try_get_idx(_tag_manager(c.link_manager, P()), id))
end

# Return an iterator of valid tags for the type of p
function get_tags(c::Context, p::Place)
    _tag_manager(c.link_manager, p)
end

function get_tags(c::Context, link_tag::LinkTag)
    d = c.link_manager.link_data[link_tag.type_id]
    idx = _get_idx(d, link_tag)
    d.per_link.tags[idx]
end

function _try_get_idx(d::LinkData, id::LinkTag)::Union{UInt32,Nothing}
    id.type_id == d.id || return nothing
    get(Returns(nothing), d.lid2lidx, id.id)
end
function _get_idx(d::LinkData, id::LinkTag)::UInt32
    something(_try_get_idx(d, id))
end

function get_links(c::Context, p::Place)::Vector{LinkTag}
    if has_tag(c, p)
        tm = _tag_manager(c.link_manager, p)
        idx = tm.place2idx[p]
        tm.idx2reflinks[idx]
    else
        LinkTag[]
    end
end
function get_links(c::Context, id::Tag{P})::Vector{LinkTag} where {P}
    tm = _tag_manager(c.link_manager, P())
    idx = _try_get_idx(tm, id)
    if !isnothing(idx)
        tm.idx2reflinks[idx]
    else
        LinkTag[]
    end
end

function make_link!(c::Context;
        link_type::Union{Symbol,Integer},
        places::NTuple{N, Place},
    )::LinkTag where {N}
    link_typeid::UInt32 = _normalize_link_type(c.link_manager, link_type)
    tags = ntuple(N) do i
        local p = places[i]
        if is_null(p)
            Tag{typeof(p)}()
        else
            tag!(c, p)
        end
    end
    d = c.link_manager.link_data[link_typeid]
    @argcheck typeof(d.places) == typeof(places)
    _make_link!(c.link_manager, d, tags)
end
function _make_link!(
        m::LinkManager,
        d::LinkData,
        tags::NTuple{N, Tag}
    )::LinkTag where {N}
    per_link = d.per_link
    lid = d.next_lid[]
    @assert lid ∉ keys(d.lid2lidx)
    lidx = UInt32(length(per_link) + 1)
    next_lid = Base.checked_add(lid, Int64(1))
    # prepare states, use default for now
    push!(per_link, d.per_link_template)
    per_link.tags[lidx] = tags
    push!(d.lidx2lid, lid)
    d.lid2lidx[lid] = lidx
    link_tag = LinkTag(d.id, lid)
    # Add references to tags
    # Possibly change this to avoid allocations in the future
    foreach(tags) do tag
        if !is_null(tag)
            local tm = _tag_manager(m, tag)
            local t_idx = _get_idx(tm, tag)
            local reflinks = tm.idx2reflinks[t_idx]
            # avoid multiple copies of link tag,
            # incase tag is a repeat
            if link_tag ∉ reflinks
                tm.idx2reflinks[t_idx] = [reflinks; link_tag]
            end
        end
    end
    d.next_lid[] = next_lid
    link_tag
end

function remove_link!(c::Context, link_tag::LinkTag)
    _remove_link!(
        c,
        c.link_manager,
        c.link_manager.link_data[link_tag.type_id],
        link_tag.id,
    )
    nothing
end
function _remove_link!(c::Context, m::LinkManager, d::LinkData, lid::Int64)
    removed_link = LinkTag(d.id, lid)
    @argcheck haskey(d.lid2lidx, lid)
    lidx = d.lid2lidx[lid]
    # remove references in tags
    foreach(d.per_link.tags[lidx]) do tag
        if !is_null(tag)
            local tm = _tag_manager(m, tag)
            local t_idx = _get_idx(tm, tag)
            local reflinks = tm.idx2reflinks[t_idx]
            if removed_link ∈ reflinks
                tm.idx2reflinks[t_idx] = filter(!=(removed_link), reflinks)
            end
        end
    end
    last_lid = d.lidx2lid[end]
    d.per_link[lidx] = d.per_link[end]
    pop!(d.per_link)

    d.lid2lidx[last_lid] = lidx
    delete!(d.lid2lidx, lid)

    d.lidx2lid[lidx] = last_lid
    pop!(d.lidx2lid)
    nothing
end

function _normalize_link_type(m::LinkManager, link_type::Union{Symbol,Integer})::UInt32
    if link_type isa Symbol
        @something(
            findfirst(==(link_type), getfield.(m.link_data, :name)),
            throw(ArgumentError("$(link_type) not found"))
        )
    else
        @argcheck link_type ∈ eachindex(m.link_data)
        link_type
    end
end

# Iterable interface
function get_links(c::Context, link_type::Union{Symbol,Integer})::LinkData
    link_typeid::UInt32 = _normalize_link_type(c.link_manager, link_type)
    c.link_manager.link_data[link_typeid]
end
# Iterates through valid LinkTags in the LinkData.
Base.length(d::LinkData)::Int64 = length(d.lidx2lid)
function Base.iterate(d::LinkData, state::NamedTuple)
    nextidx = state.curidx + 1
    if nextidx ∈ eachindex(d.lidx2lid)
        (LinkTag(d.id, d.lidx2lid[nextidx]), (; curidx = Int64(nextidx)))
    else
        nothing
    end
end
Base.iterate(d::LinkData) = iterate(d, (; curidx=Int64(0)))
Base.eltype(::Type{<:LinkData}) = LinkTag



function assert_invariants(m::LinkManager)
    foreach(_all_place_types()) do P
        assert_invariants(_tag_manager(m, P()))
    end
    @argcheck allunique((d.name for d in m.link_data))
    @argcheck all((d.id == i for (i, d) in enumerate(m.link_data)))
    foreach(assert_invariants, m.link_data)
    # check ref links in tags match
    foreach(m.link_data) do d
        for (lidx, tags) in enumerate(d.per_link.tags)
            local l_tag = LinkTag(d.id, d.lidx2lid[lidx])
            for t in unique(tags)
                if !is_null(t)
                    local tm = _tag_manager(m, t)
                    local idx = _get_idx(tm, t)
                    @argcheck l_tag ∈ tm.idx2reflinks[idx]
                end
            end
        end
    end
    foreach(_all_place_types()) do P
        local tm = _tag_manager(m, P())
        for t in tm
            local idx = _get_idx(tm, t)
            local reflinks = tm.idx2reflinks[idx]
            @argcheck allunique(reflinks)
            for l_tag in reflinks
                local d = m.link_data[l_tag.type_id]
                local lidx = _get_idx(d, l_tag)
                @argcheck t ∈ d.per_link.tags[lidx]
            end
        end
    end
    m
end

function assert_invariants(d::LinkData)
    n = length(d)
    @argcheck n == length(d.per_link)
    @argcheck n == length(d.lid2lidx)
    @argcheck n == length(d.lidx2lid)
    @argcheck d.next_lid[] > maximum(d.lidx2lid; init=Int64(0))
    @argcheck all(>(0), d.lidx2lid)
    for lidx in UInt32(1):UInt32(n)
        lid = d.lidx2lid[lidx]
        @argcheck lidx === d.lid2lidx[lid]
    end
    d
end

"""
Check if two `LinkManager` are statistically equal, the internal free lists may be different
"""
function statistically_equal(a::LinkManager, b::LinkManager)
    assert_invariants(a)
    assert_invariants(b)
    statistically_equal(a.fila_tip_tags, b.fila_tip_tags) || return false
    statistically_equal(a.fila_mono_tags, b.fila_mono_tags) || return false
    length(a.link_data) == length(b.link_data) || return false
    for i in eachindex(a.link_data)
        statistically_equal(a.link_data[i], b.link_data[i]) || return false
    end
    return true
end

function statistically_equal(a::LD, b::LD) where {LD <: LinkData}
    isequal(a.name, b.name) || return false
    isequal(a.id, b.id) || return false
    isequal(a.places, b.places) || return false
    isequal(a.param, b.param) || return false
    isequal(a.state, b.state) || return false
    isequal(a.bonds, b.bonds) || return false
    isequal(a.lid2lidx, b.lid2lidx) || return false
    isequal(a.lidx2lid, b.lidx2lid) || return false
    isequal(a.next_lid[], b.next_lid[]) || return false
    isequal(a.per_link, b.per_link) || return false
    return true
end

function Base.empty!(m::LinkManager)
    foreach(m.link_data) do linkdata
        empty!(linkdata)
    end
    empty!(m.fila_tip_tags)
    empty!(m.fila_mono_tags)
    m
end

function Base.empty!(d::LinkData)
    empty!(d.per_link)
    empty!(d.lid2lidx)
    empty!(d.lidx2lid)
    d.next_lid[] = 1
    d
end

# Get the tag manager for each type of place or tag
_tag_manager(m::LinkManager, ::Tag{P}) where P = _tag_manager(m, P())
_tag_manager(m::LinkManager, ::FilaTipIdx) = m.fila_tip_tags
_tag_manager(m::LinkManager, ::FilaMonoIdx) = m.fila_mono_tags

# Set of available places
_all_place_types() = (FilaTipIdx, FilaMonoIdx)