

"""$PUBLIC
The names of the agents in a simulation

$(TYPEDFIELDS)
"""
Base.@kwdef struct AgentNames 
    diffusingspeciesnames::Vector{Symbol} = []
    bulkspeciesnames::Vector{Symbol} = []
    membranediffusingspeciesnames::Vector{Symbol} = []
    fixedspeciesnames::Vector{Symbol} = []
    filamentnames::Vector{Tuple{Symbol,Vector{Symbol}}}= []
    vertexnames::Vector{Symbol}= []
end

"""
$(TYPEDFIELDS)
"""
struct VertexName
    "membrane index"
    membraneindex::Int

    "vertex id"
    vid::Int
end

"""
Stores the configuration options for a bond in a type of link.

$(TYPEDFIELDS)
"""
struct BondConfig{
        BOND_TYPE <: Bond,
        INPUT_TYPE <: Tuple{Int, Vararg{Int}},
        PARAM_TYPE <: NamedTuple,
        STATE_TYPE <: NamedTuple,
    }
    bond::BOND_TYPE
    input::INPUT_TYPE
    enabled::Bool
    param::PARAM_TYPE
    state::STATE_TYPE
    no_collide::Bool
    function BondConfig(;
            bond::Bond,
            input::Tuple{Int, Vararg{Int}},
            enabled::Bool=true,
            param::NamedTuple=(;),
            state::NamedTuple=(;),
            no_collide::Bool=false,
        )
        @argcheck length(num_input_directions(bond)) == length(input)
        param_names = bond_param(bond)
        @argcheck issetequal(keys(param) ∪ keys(state), collect(param_names))
        @argcheck isdisjoint(keys(param), keys(state))
        @argcheck allunique(input)
        new{
            typeof(bond),
            typeof(input),
            typeof(param),
            typeof(state),
        }(
            bond,
            input,
            enabled,
            param,
            state,
            no_collide,
        )
    end
end

function Base.show(io::IO, x::BondConfig)
    print(io,"$(BondConfig)(;bond=$(x.bond), input=$(x.input), enabled=$(x.enabled), param=$(x.param), state=$(x.state), no_collide=$(x.no_collide))")
end

# unlike BondConfig, this is not used to represent the 
# reaction during the simulation, it is just used to collect
# all the link reaction options.
"""
Stores the configuration options for a link reaction in a type of link.

$(TYPEDFIELDS)
"""
@kwdef struct LinkReactionConfig
    name::Symbol
    affect!::Any # -> Int64
    rate::Any # -> Float64
    invvolumepower::Int64 = 0
    enabled::Bool = true
    place::Int64 = 1
    fila_cutoff::Union{Tuple{Symbol, Float64}, Nothing} = nothing
    reactants_extra::AbstractString = ""
end

function Base.show(io::IO, x::LinkReactionConfig)
    print(io,"$(LinkReactionConfig)(;name=$(x.name), affect!=$(x.affect!), rate=$(x.rate), enabled=$(x.enabled), place=$(x.place), fila_cutoff=$(x.fila_cutoff), reactants_extra=$(repr(x.reactants_extra)), invvolumepower=$(x.invvolumepower))")
end

abstract type LinkReactionInfo end
struct LinkPlainReactionInfo{RATE} <: LinkReactionInfo
    fxsid::Int64
    rate::RATE
end
struct LinkFilaReactionInfo{RATE} <: LinkReactionInfo
    fxsid::Int64
    rate::RATE
    fila_reaction_id::Int64
    fila_typeid::Int64
    cutoff::Float64
end

"""
Stores configuration options for a type of link.

$(TYPEDFIELDS)
"""
struct LinkConfig
    name::Symbol
    id::Int64
    "count of total number of link type places before this link type"
    place_offset::Int64
    description::String
    places::Vector{Place}
    bonds::Vector{BondConfig}
    reactions::Vector{Vector{LinkReactionConfig}}
    reaction_infos::Vector{Vector{LinkReactionInfo}}
    param::NamedTuple
    state::NamedTuple
end

"""
$(TYPEDFIELDS)
"""
struct SiteData{SITETYPE}
    id::Int
    site::SITETYPE
    "Fixed species id"
    fxsid::Int
end

"""$PUBLIC
    SysDef(agent_names::AgentNames)

A mutable struct mapping names to id numbers in a simulation

$(TYPEDFIELDS)
"""
@kwdef mutable struct SysDef
    agent_names::AgentNames
    diffusing::PropDictionary
    diffusing_coeff::PropDictionary
    bulkspecies_indexmap::PropDictionary
    membranediffusing::PropDictionary
    fixedspecies::PropDictionary
    filament::PropDictionary
    filament_params::PropDictionary
    vertex::PropDictionary
    state::PropDictionary
    filamentsite::PropDictionary
    filamentendsite::PropDictionary
    "Each membrane site represents the membrane patches in each compartment together with some membrane diffusing species."
    membranesite::PropDictionary
    decimated_2mon_site::PropDictionary
    possiblecadherinsite::PropDictionary
    allfixedspeciesnames::Vector{String}
    compartmentreactions::Vector{CompartmentReaction}
    compartmentreactioncallbacks::Vector{Any}
    bulkreactions::Vector{BulkReaction}
    "Context -> Nothing"
    bulkreactioncallbacks::Vector{Any}
    link::PropDictionary #Vector{LinkConfig}
    total_num_link_types_places::Int64
    link_reaction_site::PropDictionary
end


function SysDef(agent_names::AgentNames)
    diffusing= helper_indexify(agent_names.diffusingspeciesnames)
    diffusing_coeff= map(i->0.0,diffusing)
    bulkspecies_indexmap = helper_indexify(agent_names.bulkspeciesnames)
    membranediffusing = helper_indexify(agent_names.membranediffusingspeciesnames)
    fixedspecies= helper_indexify(agent_names.fixedspeciesnames)
    allfixedspeciesnames = map(i->"fixedspecies.$i",agent_names.fixedspeciesnames)
    filament= helper_indexify(getindex.(agent_names.filamentnames,1))
    filament_params= map(i->FilamentMechParams(),filament)
    vertex = helper_indexify(agent_names.vertexnames, VertexState)
    state= map(i->helper_indexify(agent_names.filamentnames[i][2],MonomerState),filament)
    filamentsite= map(i->PropDictionary(),filament)
    filamentendsite= map(i->PropDictionary(),filament)
    membranesite = PropDictionary()
    decimated_2mon_site= PropDictionary()
    possiblecadherinsite = PropDictionary()
    SysDef(;
        agent_names,
        diffusing,
        diffusing_coeff,
        bulkspecies_indexmap,
        membranediffusing,
        fixedspecies,
        filament,
        filament_params,
        vertex,
        state,
        filamentsite,
        filamentendsite,
        membranesite,
        decimated_2mon_site,
        possiblecadherinsite,
        allfixedspeciesnames,
        compartmentreactions=[],
        compartmentreactioncallbacks=[],
        bulkreactions=[],
        bulkreactioncallbacks=[],
        link=PropDictionary(),
        link_reaction_site=PropDictionary(),
        total_num_link_types_places = 0,
    )
end


function Base.show(io::IO, ::MIME"text/plain", s::SysDef)
    println(io,"$(typeof(s))")
    if !isempty(s.diffusing)
        println(io," Diffusing species:")
        for speciesname in s.agent_names.diffusingspeciesnames
            println(io,"  $(speciesname): $(s.diffusing_coeff[speciesname]) nm²/s")
        end
    end
    if !isempty(s.membranediffusing)
        println(io," Membrane diffusing: $(s.agent_names.membranediffusingspeciesnames)")
    end
    if !isempty(s.fixedspecies)
        println(io," Fixed species: $(s.agent_names.fixedspeciesnames)")
    end
    if !isempty(s.filament)
        println(io," Filaments:")
        for (filamentname,monomerstatenames) in s.agent_names.filamentnames
            println(io,"  $(filamentname):")
            println(io,"   monomer states: $(monomerstatenames)")
            println(io,"   params: $(s.filament_params[filamentname])")
            if !isempty(s.filamentsite[filamentname])
                println(io,"   filament sites:")
                for (sitename,site) in pairs(s.filamentsite[filamentname])
                    println(io,"    $sitename: $(site.site)")
                end
            end
            if !isempty(s.filamentendsite[filamentname])
                println(io,"   filament end sites:")
                for (sitename,site) in pairs(s.filamentendsite[filamentname])
                    println(io,"    $sitename: $(site.site)")
                end
            end  
        end
    end
    if !isempty(s.decimated_2mon_site)
        println(io," decimated_2mon_sites:")
        for (sitename,site) in pairs(s.decimated_2mon_site)
            println(io,"  $sitename: $(site.site)")
        end
    end
    if !isempty(s.link)
        println(io," Link types:")
        for (name, config) in pairs(s.link)
            println(io,"  $name: $(config)")
        end
    end

    numcallbacks = length(s.compartmentreactioncallbacks)
    numreactions = length(s.compartmentreactions)
    if numcallbacks > 0
        println(io," Compartment reactions with callbacks:")
        for i in 1:numcallbacks
            reaction = s.compartmentreactions[i]
            callback = s.compartmentreactioncallbacks[i]
            numberstr = "  $i. "
            print(io,numberstr)
            printreaction(io, s, reaction)
            println(io)
            print(io, repeat(" ",length(numberstr)+2))
            println(io,"$callback")
        end
    end
    if numreactions > numcallbacks
        println(io," Compartment reactions without callbacks:")
        for i in (numcallbacks+1):numreactions
            reaction = s.compartmentreactions[i]
            print(io,"  ")
            printreaction(io, s, reaction)
            println(io)
        end
    end
    numcallbacks = length(s.bulkreactioncallbacks)
    numreactions = length(s.bulkreactions)
    if numcallbacks > 0
        println(io," Bulk reactions with callbacks:")
        for i in 1:numcallbacks
            reaction = s.bulkreactions[i]
            callback = s.bulkreactioncallbacks[i]
            numberstr = "  $i. "
            print(io,numberstr)
            printreaction(io, s, reaction)
            println(io)
            print(io, repeat(" ",length(numberstr)+2))
            println(io,"$callback")
        end
    end
    if numreactions > numcallbacks
        println(io," Bulk reactions without callbacks:")
        for i in (numcallbacks+1):numreactions
            reaction = s.bulkreactions[i]
            print(io,"  ")
            printreaction(io, s, reaction)
            println(io)
        end
    end
end


"""
return a namedtuple of DefaultOrderedDict{Int, Int}(0)
with names:
    diffusingreactants
    fixedreactants
    bulkreactants
    diffusingproducts
    fixedproducts
    bulkproducts
used for show
"""
function helper_reactionunparser(reaction::CompartmentReaction)
    diffusingreactants= DataStructures.DefaultOrderedDict{Int, Int}(0)
    fixedreactants= DataStructures.DefaultOrderedDict{Int, Int}(0)
    bulkreactants= DataStructures.DefaultOrderedDict{Int, Int}(0)
    diffusingproducts= DataStructures.DefaultOrderedDict{Int, Int}(0)
    fixedproducts= DataStructures.DefaultOrderedDict{Int, Int}(0)
    bulkproducts= DataStructures.DefaultOrderedDict{Int, Int}(0)
    dr1, dr2 = reaction.diffusingreactants
    diffusingreactants[dr1] += 1
    diffusingreactants[dr2] += 1
    diffusingproducts[dr1] += 1
    diffusingproducts[dr2] += 1
    for reactant in reaction.fixedreactants
        fixedreactants[reactant.id] += reactant.amount
        fixedproducts[reactant.id] += reactant.amount
    end
    for reactant in reaction.bulkreactants
        bulkreactants[reactant.id] += reactant.amount
        bulkproducts[reactant.id] += reactant.amount
    end
    # add netstoich
    netpairs = [
        (reaction.diffusingnet_stoich, diffusingproducts),
        (reaction.fixednet_stoich, fixedproducts),
        (reaction.bulknet_stoich, bulkproducts),
    ]
    for (net_stoich,products) in netpairs
        for netsp in net_stoich
            products[netsp.id] += netsp.amount
        end
    end
    results = (;
        diffusingreactants, fixedreactants, bulkreactants,
        diffusingproducts, fixedproducts, bulkproducts,
    )
    map(results) do d
        # remove id 0
        delete!(d,0)
        # remove values with zero count
        filter!(p->(p[2]!=0),d)
    end
end

"""
return a NamedTuple of DefaultOrderedDict{Int, Int}(0)
with names:
    reactants
    products
used to display a bulk reaction.
"""
function helper_reactionunparser(reaction::BulkReaction)
    reactants= DataStructures.DefaultOrderedDict{Int, Int}(0)
    products= DataStructures.DefaultOrderedDict{Int, Int}(0)
    for reactant in reaction.reactants
        reactants[reactant.id] += reactant.amount
        products[reactant.id] += reactant.amount
    end
    # add netstoich
    for netsp in reaction.net_stoich
        products[netsp.id] += netsp.amount
    end
    results = (;
        reactants,
        products,
    )
    map(results) do d
        # remove id 0
        delete!(d,0)
        # remove values with zero count
        filter!(p->(p[2]!=0),d)
    end
end

function helper_dict_2_string(speciesnames,idpairs)::String
    idpairs = collect(idpairs)
    join(map(idpairs) do p
        id = p[1]
        amount = p[2]
            if amount == 0
                ""
            elseif amount == 1
                speciesnames[id]
            else
                repr(amount)*speciesnames[id]
            end
        end,
        " + "
    )
end

function printreaction(io::IO, s::SysDef, reaction::CompartmentReaction)
    rp= helper_reactionunparser(reaction)
    diffusingnames = "diffusing.".* String.(s.agent_names.diffusingspeciesnames)
    fixednames = s.allfixedspeciesnames
    bulknames = "bulk." .* String.(propertynames(s.bulkspecies_indexmap))
    print(io, "\"")
    join(io, filter(!isempty, [
        helper_dict_2_string(diffusingnames,rp.diffusingreactants),
        helper_dict_2_string(fixednames,rp.fixedreactants),
        helper_dict_2_string(bulknames,rp.bulkreactants)
    ])," + ")
    print(io, " --> ")
    join(io, filter(!isempty, [
        helper_dict_2_string(diffusingnames,rp.diffusingproducts),
        helper_dict_2_string(fixednames,rp.fixedproducts),
        helper_dict_2_string(bulknames,rp.bulkproducts)
    ]), " + ")
    print(io, "\"")
    print(io, " $(reaction.rate) ")
    if reaction.invvolumepower == 0
        print(io, "1/s")
    elseif reaction.invvolumepower == 1
        print(io, "nm³/s")
    elseif reaction.invvolumepower == -1
        print(io, "1/(nm³*s)")
    else
        print(io, "(nm³)^$(reaction.invvolumepower)/s")
    end
end
function printreaction(io::IO, s::SysDef, reaction::BulkReaction)
    rp= helper_reactionunparser(reaction)
    bulknames = "bulk." .* String.(propertynames(s.bulkspecies_indexmap))
    print(io, "\"")
    join(io, filter(!isempty, [
        helper_dict_2_string(bulknames,rp.reactants),
    ])," + ")
    print(io, " --> ")
    join(io, filter(!isempty, [
        helper_dict_2_string(bulknames,rp.products),
    ]), " + ")
    print(io, "\"")
    print(io, " $(reaction.rate) ")
    print(io, "1/s")
end