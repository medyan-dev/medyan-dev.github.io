"""
Functions to save and load the state of a context.
"""

using SmallZarrGroups

const SNAPSHOT_VERSION = v"0.7.1"

const SNAPSHOT_UUID = "37eee81f-88ae-4d11-b6b3-d38e1ccf0a08"

"""
    snapshot(c::Context)::ZGroup
Return snapshot in a `ZGroup`.

See Snapshot group for more details.

# Keywords
- `filament_position_scale::Int = 3`: Filament positions are rounded to the nearest `2^-filament_position_scale` nm.
- `membrane_position_scale::Int = 3`: Membrane vertex positions are rounded to the nearest `2^-membrane_position_scale` nm.
"""
function snapshot(c::Context; filament_position_scale::Int=3, membrane_position_scale::Int=3)::ZGroup
    group = ZGroup()
    snapshot_filaments(c::Context,group,filament_position_scale)
    snapshot_membranes(c::Context,group,membrane_position_scale)
    snapshot_link_2mons(c::Context,group)
    snapshot_diffusingcounts(c::Context,group)
    snapshot_fixedcounts(c::Context,group)
    snapshot_chemboundary(c::Context,group)
    snapshot_mechboundary(c::Context,group)
    attrs(group)["time (s)"] = c.time[]
    attrs(group)["version"] = string(SNAPSHOT_VERSION)
    attrs(group)["uuid"] = SNAPSHOT_UUID
    return group
end


"""
    load_snapshot!(c::Context,group::ZGroup)
Empty the context and load the state saved in the snapshot `group`.

`c` should be constructed with the same `SysDef` and parameters as 
the `Context` used to create the snapshot.
Trying to load a snapshot into a `Context` constructed with a 
different system or parameters may lead to unexpected results.

See Snapshot group for more details.
"""
function load_snapshot!(c::Context, group::ZGroup)
    string(get(Returns(""), attrs(group), "uuid")) == SNAPSHOT_UUID || error("snapshot group isn't a MEDYAN snapshot")
    haskey(attrs(group), "version") || error("snapshot group missing attribute \"version\"")
    version = parse(VersionNumber, (attrs(group)["version"]))
    if version.major > SNAPSHOT_VERSION.major
        error("snapshot was written in snapshot version $(version),
        Currently in snapshot version $(SNAPSHOT_VERSION). Update MEDYAN.jl to load this snapshot correctly.")
    elseif version == SNAPSHOT_VERSION
        load_snapshot_current_version!(c::Context, group)
    elseif version < v"1.0.0"
        error("snapshot was written in snapshot version $(version). 
        Currently in snapshot version $(SNAPSHOT_VERSION). 
        snapshot backwards compatibility not implemented for pre 1.0.0 snapshot versions")
    else
        error("snapshot backwards compatibility not implemented yet")
    end
    return
end

function load_snapshot_current_version!(c::Context, group::ZGroup)
    empty!(c)
    set_time!(c,Float64(get(Returns(c.time[]), attrs(group),"time (s)")))
    load_snapshot_chemboundary!(c,group)
    load_snapshot_mechboundary!(c,group)
    load_snapshot_filaments!(c,group)
    load_snapshot_membranes!(c,group)
    load_snapshot_link_2mons!(c,group)
    load_snapshot_diffusingcounts!(c,group)
    load_snapshot_fixedcounts!(c,group)
    compartmentalize!(c)
end



"""
Add filament data to group.
Subgroup "filaments" is added if the context has any filaments.

position_scale: Filament positions are rounded to the nearest 2^-position_scale nm.
"""
function snapshot_filaments(c::Context, group::SmallZarrGroups.ZGroup, position_scale)
    if all(isempty,c.chem_cylinders)
        return
    end
    filgroup = group["filaments"] = ZGroup()
    attrs(filgroup)["position_scale"] = position_scale
    for ftid in 1:num_filtypes(c)
        cylinders::ChemCylinders = c.chem_cylinders[ftid]
        if !isempty(cylinders)
            filament_type_group = filgroup["$ftid"] = ZGroup()
            # collect all filament data

            # Fixed data per filament

            "filament ids"
            fids = Int32[]

            "Number of monomers in the filament"
            num_monomers = Int32[]

            "Number of cylinders in the filament"
            num_cylinders = Int32[]

            "Minus, Plus end load forces (pN)"
            endloadforces = SVector{2,Float64}[]

            "Number of untracked monomers on minusend"
            minusend_num_notminimized = Int32[]

            "Number of untracked monomers on plusend"
            plusend_num_notminimized = Int32[]

            # Fixed data per bead

            nodepositions = SVector{3,Float64}[]

            # Fixed data per cylinder
            """
            The monomer ids at the minus ends of the cylinders.

                                            |
                                 -----+-----|-----+-----
             minus end <----       M  |  M  | (M) |  M        ----> plus end
                                 -----+-----|-----+-----
                                            |
                                            ^ A nodeposition is indicated by the line.
            
            The monomer id with parenthesis (M) will in `node_mids`
            """
            node_mids = Int32[]

            # Fixed data per monomer

            monomerstates = MonomerState[]

            for fil_idx in eachindex(cylinders.per_fil)
                # Fixed data per filament
                nodepos = map(r -> round.(r; digits = position_scale, base=2), _get_nodepositions(cylinders, fil_idx))
                fil_data = LazyRow(cylinders.per_fil, fil_idx)
                fid = fil_data.id
                push!(fids, fid)
                push!(num_monomers, length(fil_data.monomerstates))
                push!(num_cylinders, length(nodepos)-1)
                push!(endloadforces, Tuple(fil_data.endloadforces))
                push!(minusend_num_notminimized, fil_data.minusend_num_notminimized)
                push!(plusend_num_notminimized, fil_data.plusend_num_notminimized)
                # Fixed data per bead
                append!(nodepositions,nodepos)
                # Fixed data per cylinder
                append!(node_mids, _fil_node_mon_ids(cylinders, fil_idx)[begin:end-1])
                # Fixed data per monomer
                append!(monomerstates, fil_data.monomerstates)
            end
            # Add datasets to group
            filament_type_group["fids"] = fids
            filament_type_group["num_monomers"] = num_monomers
            filament_type_group["num_cylinders"] = num_cylinders
            filament_type_group["endloadforces"] = transpose(reinterpret(reshape,eltype(eltype(endloadforces)),endloadforces))
            filament_type_group["minusend_num_notminimized"] = minusend_num_notminimized
            filament_type_group["plusend_num_notminimized"] = plusend_num_notminimized
            filament_type_group["nodepositions"] = transpose(reinterpret(reshape,eltype(eltype(nodepositions)),nodepositions))
            filament_type_group["node_mids"] = node_mids
            filament_type_group["monomerstates"] = monomerstates
        end
    end
end

"""
Load "filaments" subgroup from group if it exists
"""
function load_snapshot_filaments!(c::Context, group::ZGroup)
    if haskey(group,"filaments")
        filgroup = group["filaments"]
        for ftidstr in keys(filgroup)
            filament_type_group = filgroup[ftidstr]
            ftid::Int = parse(Int,ftidstr)
            @argcheck ftid in 1:num_filtypes(c)
            fids::Vector{Int32} = collect(filament_type_group["fids"])
            num_monomers::Vector{Int32} = collect(filament_type_group["num_monomers"])
            num_cylinders::Vector{Int32} = collect(filament_type_group["num_cylinders"])
            endloadforces::Array{Float64,2} = copy(transpose(collect(filament_type_group["endloadforces"])))
            minusend_num_notminimized::Vector{Int32} = collect(filament_type_group["minusend_num_notminimized"])
            plusend_num_notminimized::Vector{Int32} = collect(filament_type_group["plusend_num_notminimized"])
            num_fils = length(fids)
            @argcheck length(num_monomers) == num_fils
            @argcheck length(num_cylinders) == num_fils
            @argcheck size(endloadforces) == (2,num_fils)
            @argcheck length(minusend_num_notminimized) == num_fils
            @argcheck length(plusend_num_notminimized) == num_fils
            total_num_cylinders = sum(num_cylinders)
            total_num_nodes = total_num_cylinders + num_fils # add on last node
            nodepositions::Array{Float64,2} = copy(transpose(collect(filament_type_group["nodepositions"])))
            @argcheck size(nodepositions) == (3,total_num_nodes)
            nodeposition_vec = reinterpret(reshape,SVector{3,Float64},nodepositions)
            node_mids::Vector{Int32} = collect(filament_type_group["node_mids"])
            @argcheck length(node_mids) == total_num_cylinders
            total_num_monomers = sum(num_monomers)
            monomerstates::Vector{MonomerState} = collect(filament_type_group["monomerstates"])
            @argcheck length(monomerstates) == total_num_monomers
            monomerstate_ptr = 0
            nodestate_ptr = 0
            cylstate_ptr = 0
            cylinders = c.chem_cylinders[ftid]
            foreach(enumerate(fids)) do (fidx,fid)
                num_monomer = num_monomers[fidx]
                num_cyl = num_cylinders[fidx]
                num_node = num_cyl+1
                create_filament!(cylinders;
                    fil_id= fid,
                    monomerstates= monomerstates[1+monomerstate_ptr:monomerstate_ptr+num_monomer],
                    node_mids= node_mids[1+cylstate_ptr:cylstate_ptr+num_cyl],
                    nodepositions= nodeposition_vec[1+nodestate_ptr:nodestate_ptr+num_node],
                    endloadforces= (endloadforces[1,fidx]=>endloadforces[2,fidx]),
                    minusend_num_notminimized= minusend_num_notminimized[fidx],
                    plusend_num_notminimized= plusend_num_notminimized[fidx],
                )
                monomerstate_ptr += num_monomer
                nodestate_ptr += num_node
                cylstate_ptr += num_cyl
            end
            assert_invariants(cylinders)
            c.largestfilamentid[ftid] = maximum(fids)
        end
    end
    return
end


"""
Add membrane data to group.
Subgroup "membranes" is added if the context has any membranes.

position_scale: membrane vertex positions are rounded to the nearest 2^-position_scale nm.
"""
function snapshot_membranes(c::Context, group::ZGroup, position_scale)
    if isempty(c.membranes)
        return
    end
    nspecies = c.membranes |> eltype |> get_numdiffusingspecies

    memsgroup = group["membranes"] = ZGroup()
    attrs(memsgroup)["num_membranes"] = length(c.membranes)
    attrs(memsgroup)["position_scale"] = position_scale
    for memindex in 1:length(c.membranes)
        memgroup = memsgroup["$memindex"] = ZGroup()
        m = c.membranes[memindex]
        attrs(memgroup)["type_id"] = m.metaattr.membranetype
        ntris = length(m.triangles)
        coords::Vector{SVector{3, Float64}} = map(r -> round.(r; digits = position_scale, base=2), m.vertices.attr.coord)
        triangles = Matrix{Int}(undef,3,ntris)
        for tindex in 1:ntris
            local fi = 0
            for h in MEDYAN.HalfedgesInTriangle(m, MEDYAN.IT(tindex))
                fi += 1
                triangles[fi,tindex] = target(m, h).value
            end
        end
        memgroup["vertlist"] = reinterpret(reshape,eltype(eltype(coords)),coords)
        memgroup["trilist"] = triangles

        # Store copy numbers.
        if nspecies > 0
            copynumbers::Vector{SVector{nspecies, Int}} = map(thiscopynumber->SA[thiscopynumber...], m.vertices.attr.copynumbers)
            memgroup["copynumbers"] = reinterpret(reshape, eltype(eltype(copynumbers)), copynumbers)
        end
        # Store vertex IDs.
        memgroup["id"] = m.vertices.attr.id
    end

    # Store mesh index for chem boundary.
    attrs(memsgroup)["meshindex_as_chemboundary"] = c.meshindex_as_chemboundary[]
end

"""
Load "membranes" subgroup from group if it exists
"""
function load_snapshot_membranes!(c::Context, group::ZGroup)
    speciesnames = c.membranes |> eltype |> get_speciesnames
    nspecies = length(speciesnames)

    if haskey(group,"membranes")
        memsgroup = group["membranes"]
        num_mems::Int = attrs(memsgroup)["num_membranes"]
        @argcheck num_mems ≥ 0
        for memindex in 1:num_mems
            memgroup = memsgroup["$memindex"]
            typeid::Int = attrs(memgroup)["type_id"]
            coords::Matrix{Float64} = collect(memgroup["vertlist"])
            tris::Matrix{Int} = collect(memgroup["trilist"])
            vertlist = copy(reinterpret(reshape,SVector{3,Float64},coords))
            trilist = copy(reinterpret(reshape,SVector{3,Int},tris))
            id::Vector{Int} = collect(memgroup["id"])
            meshinit = (;vertlist, trilist, id)
            if haskey(memgroup, "copynumbers")
                copynumbers_raw::Matrix{Int} = collect(memgroup["copynumbers"])
                copynumbers = StructArray(reinterpret(reshape, NamedTuple{speciesnames, NTuple{nspecies,Int}}, copynumbers_raw))
                meshinit = (;meshinit..., copynumbers)
            end
            newmembrane!(c; type = typeid, meshinit)
        end
        compute_all_membrane_geometry!_system(c)

        meshindex_as_chemboundary = get(Returns(0), attrs(memsgroup), "meshindex_as_chemboundary")
        set_meshindex_as_chemboundary!(c, meshindex_as_chemboundary)
    end
end


"""
Add link_2mon data to group.
Subgroup "link_2mons" is added if the context has any link_2mons.
"""
function snapshot_link_2mons(c::Context, group::ZGroup)
    if all(iszero∘num_link_2mons,c.link_2mon_data)    
        return
    end
    link_2mon_group = group["link_2mons"] = ZGroup()
    foreach(c.link_2mon_data) do link_2mon_data
        n = num_link_2mons(link_2mon_data)
        if !iszero(n)
            link_2mon_type_group = link_2mon_group["$(link_2mon_data.id)"] = ZGroup()
            attrs(link_2mon_type_group)["num_link_2mons"]=n
            attrs(link_2mon_type_group)["next_lid"]=link_2mon_data.next_lid[]
            # 
            states_soa = StructArray(link_2mon_data.states, unwrap = t-> (t<:AbstractArray || t<:NamedTuple && sizeof(t)!=0))
            link_2mon_type_group["state"] = SmallZarrGroups.write_nested_struct_array(states_soa)
            link_2mon_type_group["endnames"] = transpose(reinterpret(reshape, Int64, link_2mon_data.lidx_to_endnames))
            link_2mon_type_group["lids"] = link_2mon_data.lidx_to_lid
        end
    end
end

"""
Load "link_2mons" subgroup from group if it exists
"""
function load_snapshot_link_2mons!(c::Context, group::ZGroup)
    if haskey(group,"link_2mons")
        link_2mon_group = group["link_2mons"]
        savedltids = parse.(Int,keys(link_2mon_group))
        @argcheck all(in(1:length(c.link_2mon_data)),savedltids)
        foreach(c.link_2mon_data) do link_2mon_data
            ltid = link_2mon_data.id
            if haskey(link_2mon_group,"$ltid")
                link_2mon_type_group = link_2mon_group["$ltid"]
                n = attrs(link_2mon_type_group)["num_link_2mons"]
                raw_endnames::Matrix{Int64} = copy(transpose(collect(link_2mon_type_group["endnames"])))
                @argcheck size(raw_endnames) == (6,n)
                endnames = reinterpret(reshape, Pair{MonomerName,MonomerName}, raw_endnames)
                lids::Vector{Int64}, next_lid::Int64 = if haskey(link_2mon_type_group, "lids")
                    collect(Int64, link_2mon_type_group["lids"]), attrs(link_2mon_type_group)["next_lid"]
                else
                    1:n, n+1
                end
                @argcheck length(lids) == n
                states_soa = StructArray((link_2mon_data.params.defaultstate for i = 1:n);unwrap = t-> t<:AbstractArray || t<:NamedTuple && sizeof(t)!=0)
                SmallZarrGroups.read_nested_struct_array!(states_soa,link_2mon_type_group["state"])
                link_2mon_data.next_lid[] = next_lid
                for i in 1:n
                    chem_newlink_2mon!(c, ltid, endnames[i], states_soa[i]; new_lid=lids[i])
                end
            end
        end
    end
    return
end


"""
Add diffusing species counts to group.
Dataset "diffusingcounts" is added, it is indexed by [sid,cid] to give count
"""
function snapshot_diffusingcounts(c::Context, group::ZGroup)
    numdiffusingspecies = length(c.agentnames.diffusingspeciesnames)
    if numdiffusingspecies == 0 
        return
    end
    group["diffusingcounts"] = c.chemistryengine.diffusingcounts
    return
end

"""
Load "diffusingcounts" from group if it exists.
TODO allow translation of cid and sid.
"""
function load_snapshot_diffusingcounts!(c::Context, group::ZGroup)
    if haskey(group,"diffusingcounts")
        data = collect(group["diffusingcounts"])
        nsid, ncid = size(data)
        for cid in 1:ncid
            for sid in 1:nsid
                chem_adddiffusingcount!(c, sid, cid, data[sid,cid])
            end
        end
    end
    return
end


"""
Add fixed species counts to group.
Dataset "fixedcounts" is added, it is indexed by [sid,cid] to give count
"""
function snapshot_fixedcounts(c::Context, group::ZGroup)
    numrealfixedspecies = length(c.agentnames.fixedspeciesnames)
    if numrealfixedspecies == 0 
        return
    end
    group["fixedcounts"] = Float64.(c.chemistryengine.fixedcounts[1:numrealfixedspecies,:])
    return
end

"""
Load "fixedcounts" from group if it exists.
TODO allow translation of cid and sid.
"""
function load_snapshot_fixedcounts!(c::Context, group::ZGroup)
    if haskey(group,"fixedcounts")
        data = collect(group["fixedcounts"])
        nsid, ncid = size(data)
        for cid in 1:ncid
            for sid in 1:nsid
                chem_addfixedcount!(c, sid, cid, data[sid,cid])
            end
        end
    end
    return
end


"""
Add chemboundary to group
group "chemboundary" is added if its not empty.
"""
function snapshot_chemboundary(c::Context, group::ZGroup)
    foreach(fieldnames(Boundary)) do k
        stringname = string(k)
        @assert isascii(stringname) "$k not ascii, not allowed in Zarr paths"
        data = getfield(c.chemboundary,k)
        @assert data isa Vector{<:SVector} "$k must be a Vector of SVector"
        if isempty(data)
            return
        end
        group["chemboundary/$stringname"] = reinterpret(reshape,eltype(eltype(data)),data)
        return
    end
end

"""
Load "chemboundary" from group if it exists.
"""
function load_snapshot_chemboundary!(c::Context, group::ZGroup)
    if haskey(group,"chemboundary")
        subgroup = group["chemboundary"]
        planes = if haskey(subgroup,"planes")
            planedata::Matrix{Float64} = collect(subgroup["planes"])
            copy(reinterpret(reshape,SVector{4,Float64},planedata))
        else
            SVector{4,Float64}[]
        end
        capsules = if haskey(subgroup,"capsules")
            capsuledata::Matrix{Float64} = collect(subgroup["capsules"])
            copy(reinterpret(reshape,SVector{8,Float64},capsuledata))
        else
            SVector{8,Float64}[]
        end
        set_chemboundary!(c, Boundary(;planes, capsules))
    end
    return
end


"""
Add mechboundary to group
group "mechboundary" is added if its not empty.
"""
function snapshot_mechboundary(c::Context, group::ZGroup)
    foreach(fieldnames(Boundary)) do k
        stringname = string(k)
        @assert isascii(stringname) "$k not ascii, not allowed in Zarr paths"
        data = getfield(c.mechboundary,k)
        @assert data isa Vector{<:SVector} "$k must be a Vector of SVector"
        if isempty(data)
            return
        end
        group["mechboundary/$stringname"] = reinterpret(reshape,eltype(eltype(data)),data)
        return
    end
end

"""
Load "mechboundary" from group if it exists.
"""
function load_snapshot_mechboundary!(c::Context, group::ZGroup)
    if haskey(group,"mechboundary")
        subgroup = group["mechboundary"]
        planes = if haskey(subgroup,"planes")
            planedata::Matrix{Float64} = collect(subgroup["planes"])
            copy(reinterpret(reshape,SVector{4,Float64},planedata))
        else
            SVector{4,Float64}[]
        end
        capsules = if haskey(subgroup,"capsules")
            capsuledata::Matrix{Float64} = collect(subgroup["capsules"])
            copy(reinterpret(reshape,SVector{8,Float64},capsuledata))
        else
            SVector{8,Float64}[]
        end
        set_mechboundary!(c, Boundary(;planes, capsules))
    end
    return
end
