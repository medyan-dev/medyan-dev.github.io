"""
Functions to save a trajectory header json file describing the state of a system
"""

const HEADER_VERSION = v"0.1.0"

using DataStructures: OrderedDict


"""
    header(c::Context, io) -> OrderedDict

Return the trajectory header as an OrderedDict.

"""
function header(c::Context)
    data = OrderedDict([
        "version" => HEADER_VERSION,
        "medyanInfo" => OrderedDict([
            "title" => "MEDYAN.jl",
            "version" => v"0.1.0", #TODO automatically get MEDYAN version
            "sourceCodeUrl" => "https://github.com/medyan-dev/MEDYAN.jl",
        ]),
        "size" => OrderedDict([
            "x(nm)" => c.grid.n[1] * c.grid.compartmentsize,
            "y(nm)" => c.grid.n[2] * c.grid.compartmentsize,
            "z(nm)" => c.grid.n[3] * c.grid.compartmentsize,
        ]),
        "chem_grid_size" => OrderedDict([
            "nx" => c.grid.n[1],
            "ny" => c.grid.n[2],
            "nz" => c.grid.n[3],
            "voxel_x(nm)" => c.grid.compartmentsize,
            "voxel_y(nm)" => c.grid.compartmentsize,
            "voxel_z(nm)" => c.grid.compartmentsize,
        ]),
    ])
    if !isempty(c.agent_names.diffusingspeciesnames)
        data["diffusing_species"] = map(eachindex(c.agent_names.diffusingspeciesnames)) do id
            OrderedDict([
                "name" => c.agent_names.diffusingspeciesnames[id],
            ])
        end
    end
    if !isempty(c.agent_names.bulkspeciesnames)
        data["bulk_species"] = map(eachindex(c.agent_names.bulkspeciesnames)) do id
            OrderedDict([
                "name" => c.agent_names.bulkspeciesnames[id],
            ])
        end
    end
    if !isempty(c.agent_names.membranediffusingspeciesnames)
        data["membrane_diffusing_species"] = map(eachindex(c.agent_names.membranediffusingspeciesnames)) do id
            OrderedDict([
                "name" => c.agent_names.membranediffusingspeciesnames[id],
            ])
        end
    end
    if !isempty(c.agent_names.fixedspeciesnames)
        data["fixed_species"] = map(eachindex(c.agent_names.fixedspeciesnames)) do id
            OrderedDict([
                "name" => c.agent_names.fixedspeciesnames[id],
            ])
        end
    end
    if !isempty(c.agent_names.filamentnames)
        data["filaments"] = map(eachindex(c.agent_names.filamentnames)) do id
            OrderedDict([
                "name" => c.agent_names.filamentnames[id][1],
                "radius(nm)" => c.filamentmechparams[id].radius,
                "monomerstates" => c.agent_names.filamentnames[id][2],
            ])
        end
    end
    if !isempty(c.agent_names.link_2mon_names)
        data["link_2mons"] = map(eachindex(c.agent_names.link_2mon_names)) do id
            OrderedDict([
                "name" => c.agent_names.link_2mon_names[id],
            ])
        end
    end
    data
end