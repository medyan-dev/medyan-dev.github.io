"""
Functions to save a trajectory header json file describing the state of a system
"""

const HEADER_VERSION = v"0.1.0"

using DataStructures: OrderedDict
import JSON3


"""
    header(c::Context, io) -> OrderedDict

Return the trajectory header as an OrderedDict.

"""
function header(c::Context)
    data = OrderedDict([
        "version" => HEADER_VERSION,
        "medyanInfo" => OrderedDict([
            "title" => "MEDYAN.jl",
            "version" => v"0.1.0", #TODO automatically get MEDYAN version
            "sourceCodeUrl" => "https://github.com/medyan-dev/MEDYAN.jl",
        ]),
        "size" => OrderedDict([
            "x(nm)" => c.grid.n[1] * c.grid.compartmentsize,
            "y(nm)" => c.grid.n[2] * c.grid.compartmentsize,
            "z(nm)" => c.grid.n[3] * c.grid.compartmentsize,
        ]),
        "chem_grid_size" => OrderedDict([
            "nx" => c.grid.n[1],
            "ny" => c.grid.n[2],
            "nz" => c.grid.n[3],
            "voxel_x(nm)" => c.grid.compartmentsize,
            "voxel_y(nm)" => c.grid.compartmentsize,
            "voxel_z(nm)" => c.grid.compartmentsize,
        ]),
    ])
    if !isempty(c.agentnames.diffusingspeciesnames)
        data["diffusing_species"] = map(eachindex(c.agentnames.diffusingspeciesnames)) do id
            OrderedDict([
                "name" => c.agentnames.diffusingspeciesnames[id],
            ])
        end
    end
    if !isempty(c.agentnames.bulkspeciesnames)
        data["bulk_species"] = map(eachindex(c.agentnames.bulkspeciesnames)) do id
            OrderedDict([
                "name" => c.agentnames.bulkspeciesnames[id],
            ])
        end
    end
    if !isempty(c.agentnames.membranediffusingspeciesnames)
        data["membrane_diffusing_species"] = map(eachindex(c.agentnames.membranediffusingspeciesnames)) do id
            OrderedDict([
                "name" => c.agentnames.membranediffusingspeciesnames[id],
            ])
        end
    end
    if !isempty(c.agentnames.fixedspeciesnames)
        data["fixed_species"] = map(eachindex(c.agentnames.fixedspeciesnames)) do id
            OrderedDict([
                "name" => c.agentnames.fixedspeciesnames[id],
            ])
        end
    end
    if !isempty(c.agentnames.filamentnames)
        data["filaments"] = map(eachindex(c.agentnames.filamentnames)) do id
            OrderedDict([
                "name" => c.agentnames.filamentnames[id][1],
                "radius(nm)" => c.filamentmechparams[id].radius,
                "monomerstates" => c.agentnames.filamentnames[id][2],
            ])
        end
    end
    if !isempty(c.agentnames.link_2mon_names)
        data["link_2mons"] = map(eachindex(c.agentnames.link_2mon_names)) do id
            OrderedDict([
                "name" => c.agentnames.link_2mon_names[id],
            ])
        end
    end
    data
end