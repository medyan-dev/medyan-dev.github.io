"""
    abstract type ForceEnergy

Type to represent different strategies for summing energies and forces.
"""
abstract type ForceEnergy end

function get_grad!(force_energy::ForceEnergy, grad_out)
    get_force!(force_energy, grad_out)
    grad_out .= .- grad_out
    nothing
end
function check_len_force_energy(force_energy::ForceEnergy, ndof::Int64)
    @argcheck get_ndof(force_energy) == ndof
end
function get_force(force_energy::ForceEnergy)
    force_out = zeros(get_ndof(force_energy))
    get_force!(force_energy, force_out)
    force_out
end


struct ForceEnergyFloat64 <: ForceEnergy
    forces::Vector{Float64}
    energy::Base.RefValue{Float64}
end
function ForceEnergyFloat64(ndof::Integer)
    ForceEnergyFloat64(zeros(ndof), Ref(0.0))
end
Base.@propagate_inbounds function add_dof_force!(force_energy::ForceEnergyFloat64, i::Integer, force::Number)
    force_energy.forces[i] += force
    nothing
end
Base.@propagate_inbounds function add_energy!(force_energy::ForceEnergyFloat64, energy::Number)
    force_energy.energy[] += energy
    nothing
end
Base.@propagate_inbounds function add_bead_force!(force_energy::ForceEnergyFloat64, i::Integer, force)
    for j in 1:3
        force_energy.forces[3(i-1) + j] += force[j]
    end
    nothing
end
function get_grad!(force_energy::ForceEnergyFloat64, grad_out)
    grad_out .= .- force_energy.forces
    nothing
end
function get_force!(force_energy::ForceEnergyFloat64, force_out)
    force_out .= force_energy.forces
    nothing
end
function get_energy(force_energy::ForceEnergyFloat64)
    force_energy.energy[]
end
function set_zero_force_energy!(force_energy::ForceEnergyFloat64)
    force_energy.forces .= 0
    force_energy.energy[] = 0
    nothing
end
function get_ndof(force_energy::ForceEnergyFloat64)
    length(force_energy.forces)
end


@inline convert_to_fixed_point(x, fbits) = unsafe_trunc(Int64, x*(oftype(x, 2)^fbits))
@inline convert_to_floating_point(T, x, fbits) = T(x)*(convert(T, 2)^-fbits)

struct ForceEnergyFixedPoint{F_FBITS, E_FBITS} <: ForceEnergy
    forces::Vector{Int64}
    energy::Base.RefValue{Int64}
end
function ForceEnergyFixedPoint{F_FBITS, E_FBITS}(ndof::Integer) where {F_FBITS, E_FBITS}
    ForceEnergyFixedPoint{F_FBITS, E_FBITS}(zeros(Int64, ndof), Ref(Int64(0)))
end
Base.@propagate_inbounds function add_dof_force!(force_energy::ForceEnergyFixedPoint{F_FBITS, E_FBITS}, i::Integer, force::Number) where {F_FBITS, E_FBITS}
    force_energy.forces[i] += convert_to_fixed_point(force, F_FBITS)
    nothing
end
Base.@propagate_inbounds function add_energy!(force_energy::ForceEnergyFixedPoint{F_FBITS, E_FBITS}, energy::Number) where {F_FBITS, E_FBITS}
    force_energy.energy[] += convert_to_fixed_point(energy, E_FBITS)
    nothing
end
Base.@propagate_inbounds function add_bead_force!(force_energy::ForceEnergyFixedPoint{F_FBITS, E_FBITS}, i::Integer, force) where {F_FBITS, E_FBITS}
    for j in 1:3
        force_energy.forces[3(i-1) + j] += convert_to_fixed_point(force[j], F_FBITS)
    end
    nothing
end
function get_grad!(force_energy::ForceEnergyFixedPoint{F_FBITS, E_FBITS}, grad_out) where {F_FBITS, E_FBITS}
    @argcheck eachindex(grad_out) == eachindex(force_energy.forces)
    @inbounds for i in eachindex(grad_out)
        grad_out[i] = -convert_to_floating_point(eltype(grad_out), force_energy.forces[i], F_FBITS)
    end
    nothing
end
function get_force!(force_energy::ForceEnergyFixedPoint{F_FBITS, E_FBITS}, force_out) where {F_FBITS, E_FBITS}
    @argcheck eachindex(force_out) == eachindex(force_energy.forces)
    @inbounds for i in eachindex(force_out)
        force_out[i] = convert_to_floating_point(eltype(force_out), force_energy.forces[i], F_FBITS)
    end
    nothing
end
function get_energy(force_energy::ForceEnergyFixedPoint{F_FBITS, E_FBITS}) where {F_FBITS, E_FBITS}
    convert_to_floating_point(Float64, force_energy.energy[], E_FBITS)
end
function set_zero_force_energy!(force_energy::ForceEnergyFixedPoint)
    force_energy.forces .= 0
    force_energy.energy[] = 0
    nothing
end
function get_ndof(force_energy::ForceEnergyFixedPoint)
    length(force_energy.forces)
end


struct DebugForceEnergy <: ForceEnergy
    ndof::Int64
    added_dof_force::Vector{Tuple{Int64, Float64}}
    added_energy::Vector{Float64}
    added_bead_force::Vector{Tuple{Int64, SVector{3, Float64}}}
end
function DebugForceEnergy(ndof::Integer)
    DebugForceEnergy(ndof, [], [], [])
end
function add_dof_force!(force_energy::DebugForceEnergy, i::Integer, force::Number)
    checkbounds(1:force_energy.ndof, i)
    push!(force_energy.added_dof_force, (i, force))
    nothing
end
function add_energy!(force_energy::DebugForceEnergy, energy::Number)
    push!(force_energy.added_energy, energy)
    nothing
end
function add_bead_force!(force_energy::DebugForceEnergy, i::Integer, force)
    checkbounds(1:force_energy.ndof, 3i)
    checkbounds(1:force_energy.ndof, 3i-2)
    push!(force_energy.added_bead_force, (i, force))
    nothing
end
function get_force!(force_energy::DebugForceEnergy, force_out)
    force_out .= 0
    for (i, f) in force_energy.added_dof_force
        force_out[i] += f
    end
    for (i, f) in force_energy.added_bead_force
        for j in 1:3
            force_out[3(i-1) + j] += f[j]
        end
    end
    nothing
end
function get_energy(force_energy::DebugForceEnergy)
    sum(force_energy.added_energy; init=0.0)
end
function set_zero_force_energy!(force_energy::DebugForceEnergy)
    empty!(force_energy.added_dof_force)
    empty!(force_energy.added_energy)
    empty!(force_energy.added_bead_force)
    nothing
end
function get_ndof(force_energy::DebugForceEnergy)
    force_energy.ndof
end
