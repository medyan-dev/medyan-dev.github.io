"""
    abstract type ForceEnergy

Type to represent different strategies for summing energies and forces.
"""
abstract type ForceEnergy end

struct ForceEnergyFloat64 <: ForceEnergy
    forces::Vector{Float64}
    energy::Base.RefValue{Float64}
end
function ForceEnergyFloat64(ndof::Integer)
    ForceEnergyFloat64(zeros(ndof), Ref(0.0))
end
Base.@propagate_inbounds function add_dof_force!(force_energy::ForceEnergyFloat64, i::Integer, force::Number)
    force_energy.forces[i] += force
    nothing
end
Base.@propagate_inbounds function add_energy!(force_energy::ForceEnergyFloat64, energy::Number)
    force_energy.energy[] += energy
    nothing
end
Base.@propagate_inbounds function add_bead_force!(force_energy::ForceEnergyFloat64, i::Integer, force)
    for j in 1:3
        force_energy.forces[3(i-1) + j] += force[j]
    end
    nothing
end
function get_grad!(force_energy::ForceEnergyFloat64, grad_out)
    grad_out .= .- force_energy.forces
    nothing
end
function get_force(force_energy::ForceEnergyFloat64)
    copy(force_energy.forces)
end
function get_force!(force_energy::ForceEnergyFloat64, force_out)
    force_out .= force_energy.forces
    nothing
end
function get_energy(force_energy::ForceEnergyFloat64)
    force_energy.energy[]
end
function set_zero_force_energy!(force_energy::ForceEnergyFloat64)
    force_energy.forces .= 0
    force_energy.energy[] = 0
    nothing
end
function check_len_force_energy(force_energy::ForceEnergyFloat64, ndof::Int64)
    @argcheck length(force_energy.forces) == ndof
end
