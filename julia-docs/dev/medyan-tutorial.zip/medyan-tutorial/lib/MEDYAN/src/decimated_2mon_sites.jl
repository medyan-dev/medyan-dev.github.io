"""
Commonly used decimated_2mon sites
"""

using LinearAlgebra
using StaticArrays
import JET

"""
Test that a type follows the interface and check for basic errors
"""
function statictest_decimated_2mon_site(sitetype::Type)
    JET.report_call((sitetype,MonomerState,MonomerState,SVector{3,Float64},SVector{3,Float64},SVector{3,Float64},SVector{3,Float64});
        # print_inference_success=false,
    ) do site,minusstate,plusstate,m_pos,p_pos,m_plusv,p_plusv
        getmidsteps(site)::Tuple{Integer,Integer}
        cutoff_distance(site)::Float64
        max_decimated_2mon_sitecount(site)::Float64
        getftids(site)::Tuple{Integer,Integer}
        in_linking_range(site,m_pos,p_pos,m_plusv,p_plusv)::Tuple{Bool,Bool}
        decimated_2mon_sitecount(site,minusstate,plusstate,m_pos,p_pos,m_plusv,p_plusv)::Float64
    end
end



"""$PUBLIC
Any pair within max to min range are linkable 
if they have matching state with `minusstate` and `plusstate`.

$(TYPEDFIELDS)

"""
struct Decimated2MonSiteRange
    minusftid::Int
    plusftid::Int
    minusskip::Int
    plusskip::Int
    minusstate::MonomerState
    plusstate::MonomerState
    minrange::Float64
    maxrange::Float64
end

getmidsteps(site::Decimated2MonSiteRange) = (site.minusskip,site.plusskip)

cutoff_distance(site::Decimated2MonSiteRange) = site.maxrange

max_decimated_2mon_sitecount(site::Decimated2MonSiteRange)::Float64 = 1.0

function in_linking_range(site::Decimated2MonSiteRange, m_pos,p_pos,m_plusv,p_plusv)::Tuple{Bool,Bool}
    distance = norm_fast(m_pos - p_pos)
    return if distance < site.minrange || distance > site.maxrange
        (false,false)
    else
        (true,true)
    end
end

getftids(site::Decimated2MonSiteRange) = (site.minusftid, site.plusftid)

function decimated_2mon_sitecount(site::Decimated2MonSiteRange,minusstate,plusstate,m_pos,p_pos,m_plusv,p_plusv)::Float64
    if minusstate == site.minusstate && plusstate == site.plusstate
        return 1.0
    else
        return 0.0
    end
end


"""$PUBLIC
Any pair within max to min range are linkable 
if they have matching state with `minusstate` and `plusstate` and 
if both the angles between the filaments and line between the pair are greater than `acos(cosminangle)`
    for example if cosminangle is 1, all angles are ok, 
        if cosminangle is sqrt(2)/2, and the line between the pair of monomers 
        is parallel or anti parallel to either filament, it won't be linkable.

This can be used to prevent link_2mons from binding both ends to the same filament.

$(TYPEDFIELDS)
"""
struct Decimated2MonSiteMinAngleRange
    minusftid::Int
    plusftid::Int
    minusskip::Int
    plusskip::Int
    minusstate::MonomerState
    plusstate::MonomerState
    minrange::Float64
    maxrange::Float64
    cosminangle::Float64
end

getmidsteps(site::Decimated2MonSiteMinAngleRange) = (site.minusskip,site.plusskip)

cutoff_distance(site::Decimated2MonSiteMinAngleRange) = site.maxrange

max_decimated_2mon_sitecount(site::Decimated2MonSiteMinAngleRange)::Float64 = 1.0

function in_linking_range(site::Decimated2MonSiteMinAngleRange, m_pos,p_pos,m_plusv,p_plusv)::Tuple{Bool,Bool}
    r = p_pos - m_pos
    distance = norm_fast(r)
    r̂ = r/distance
    m_cosθ = abs(r̂ ⋅ m_plusv)
    p_cosθ = abs(r̂ ⋅ p_plusv)
    return if distance < site.minrange || distance > site.maxrange || m_cosθ > site.cosminangle || p_cosθ > site.cosminangle
        (false,false)
    else
        (true,true)
    end
end

getftids(site::Decimated2MonSiteMinAngleRange) = (site.minusftid, site.plusftid)

function decimated_2mon_sitecount(site::Decimated2MonSiteMinAngleRange,minusstate,plusstate,m_pos,p_pos,m_plusv,p_plusv)::Float64
    if minusstate == site.minusstate && plusstate == site.plusstate
        return 1.0
    else
        return 0.0
    end
end