"""
Simple example Context generators useful for testing.
"""

"""
Typical actin filament parameters.
"""
const ACTIN_FIL_PARAMS = MEDYAN.FilamentMechParams(
    radius= 3.0, # nm
    spacing= 2.7, # nm
    klength= 40*100.0, # pN/nm
    kangle= 40*672.0, # pN*nm/rad²
    numpercylinder= 40, # number of monomers
    max_num_unmin_end= 1,
    # Maximum number of unminimized monomers that can be on an end.
    # This should be less than the minimum `radius` of other 
    # filaments + `radius` divided by `spacing`.
)

"""
Filament parameters where everything is 1, useful for testing.
"""
const UNITY_FIL_PARAMS = MEDYAN.FilamentMechParams(
    radius= 1,
    spacing= 1,
    klength= 1,
    kangle= 1,
    numpercylinder= 1,
    max_num_unmin_end= 1,
)



"""
Return a Context for testing the mechanics of simple actin filaments, no chemistry.
"""
function example_actin_mech_context(grid::CubicGrid; kwarg...)
    agent_names = AgentNames(
        filamentnames= [(:actin,[
                                :a,
                                :restrained,
                            ]),
        ],
        link_2mon_names= [:restraint]
    )

    s= SysDef(agent_names)
    add_link_2mon!(s,
        :restraint,
        Link2MonState((;),(mr0 = zero(SVector{3,Float64}),mv̂0 = zero(SVector{3,Float64}))),
        MEDYAN.RestraintMechParams(kr=10.0,kv̂=2.0),
    )

    add_filament_params!(s, 
        :actin,
        ACTIN_FIL_PARAMS,
    )

    c = MEDYAN.Context(s,grid;
            kwarg...)
    set_mechboundary!(c, MEDYAN.boundary_box(grid; stiffness=100.0))
    c
end


"""
Return a Context and SysDef with multiple filament types and all types of sites for testing site counts. 
"""
function example_all_sites_context(; kwarg...)
    agent_names = AgentNames(
        diffusingspeciesnames= [:b,:c,],
        membranediffusingspeciesnames = [:ma, :mb, :mc],
        fixedspeciesnames= [:d,:a,],
        filamentnames= [
            (:a,[
                :me,
                :a,
                :b,
                :c,
                :pe,
            ]),
            (:b,[
                :me,
                :a,
                :b,
                :c,
                :pe,
            ]),
        ],
        link_2mon_names= [
            :a,
            :b,
            :c,
            :d,
        ]
    )

    s = SysDef(agent_names)
    #filament related sites
    for ftname = (:a,:b)
        addfilament_reaction!(s,ftname,:ba2bb2,[:b,:a]=>[:b,:b],2,"-->",1.75,0)
        addfilament_reaction!(s,ftname,:ba2bb1,[:b,:a]=>[:b,:b],1,"-->",1.75,0)
        addfilament_reaction!(s,ftname,:ab2bb2,[:a,:b]=>[:b,:b],2,"-->",1.75,0)
        addfilament_reaction!(s,ftname,:ab2bb1,[:a,:b]=>[:b,:b],1,"-->",1.75,0)
        addfilament_reaction!(s,ftname,:a,[:a]=>[:a],1,"-->",1.75,0)
        addfilament_reaction!(s,ftname,:me,[:me]=>[:me],1,"-->",1.75,0)
        addfilament_reaction!(s,ftname,:pe,[:pe]=>[:pe],1,"-->",1.75,0)
        addfilamentend_reaction!(s,ftname,:pm,true,[:me]=>[:me,:a],1.3,"-->",1.75,0)
        addfilamentend_reaction!(s,ftname,:pp,false,[:pe]=>[:a,:pe],1.3,"-->",1.75,0)
        addfilamentend_reaction!(s,ftname,:pmb,true,[:me,:b]=>[:me,:a,:b],1.3,"-->",1.75,0)
        addfilamentend_reaction!(s,ftname,:ppb,false,[:b,:pe]=>[:b,:a,:pe],1.3,"-->",1.75,0)
    end
    #diffusing species
    add_diffusion_coeff!(s, :b, 1.0)
    add_diffusion_coeff!(s, :c, 1.0)
    #link_2mon sites
    add_link_2mon!(s, :a, Link2MonState((a=1,b=0.3,),(â=SA[1.0f0,NaN32,3.0f0],k=nothing,)), nothing,)
    add_link_2mon!(s, :b, Link2MonState((;),(;)), nothing,)
    add_link_2mon!(s, :c, Link2MonState((;),(;)), nothing,)
    add_link_2mon!(s, :d, Link2MonState((;),(;)), nothing,)
    add_link_2mon_site!(s,:a,:mysite,MEDYAN.Link2MonSiteOne())
    add_link_2mon_site!(s,:c,:mysite,MEDYAN.Link2MonSiteOne())
    add_link_2mon_site!(s,:c,:matchsite1,MEDYAN.Link2MonSiteMonomerStateMatch((1,2,3),(1,2,3)))
    add_link_2mon_site!(s,:c,:matchsite2,MEDYAN.Link2MonSiteMonomerStateMatch((2,2,2),(2,2,2)))
    add_link_2mon_site!(s,:c,:matchsite3,MEDYAN.Link2MonSiteMonomerStateMatch((0,1,2),(1,2,2)))
    #decimated_2mon sites
    site = MEDYAN.Decimated2MonSiteRange(s.filament.a,s.filament.a,1,1,s.state.a.a,s.state.a.a,15.0,35.0)
    add_decimated_2mon_site!(s,:s,site)
    sitestep3 = MEDYAN.Decimated2MonSiteRange(s.filament.a,s.filament.a,3,3,s.state.a.a,s.state.a.a,15.0,35.0)
    add_decimated_2mon_site!(s,:step3,sitestep3)
    siteab = MEDYAN.Decimated2MonSiteRange(s.filament.a,s.filament.b,1,1,s.state.a.a,s.state.a.a,15.0,35.0)
    add_decimated_2mon_site!(s,:ab,siteab)
    siteba = MEDYAN.Decimated2MonSiteRange(s.filament.b,s.filament.a,1,1,s.state.a.a,s.state.a.a,15.0,35.0)
    add_decimated_2mon_site!(s,:ba,siteba)
    siteb3a2 = MEDYAN.Decimated2MonSiteRange(s.filament.b,s.filament.a,3,2,s.state.a.a,s.state.a.a,15.0,35.0)
    add_decimated_2mon_site!(s,:b3a2,siteb3a2)

    monomerspacing= 10.0

    add_filament_params!(s, 
        :a,
        @set(ACTIN_FIL_PARAMS.spacing = monomerspacing),
    )
    add_filament_params!(s, 
        :b,
        @set(ACTIN_FIL_PARAMS.spacing = monomerspacing),
    )
    

    membranemechparams = [
		MEDYAN.MembraneMechParams(
			kbend = 100,
			tension = 0.02,
			eqvolume = (4/3) * π * 800^3,
			kvolume = 0.8,
		),
	]
    grid = CubicGrid((4,1,1),500.0)
    o = MEDYAN.cornerof(grid)
    boundingplanes = MEDYAN.boundary_box(grid; offset=0.0, stiffness=100.0)
    boundingcapsules = MEDYAN.boundary_capsule(;radius=10000.0)
    c= Context(s,grid;
            membrane_species_params=SVector(fill(MembraneSpeciesParams(diffusion_coeff=1.0), 3)...),
            membranemechparams,
            kwarg...)
    set_mechboundary!(c, boundingplanes ∩ boundingcapsules)
    set_chemboundary!(c, boundingplanes ∩ boundingcapsules)
    chem_adddiffusingcount!(c::Context, 1, 2, 100)
    chem_adddiffusingcount!(c::Context, 1, 4, 40)
    chem_adddiffusingcount!(c::Context, 2, 2, 1000)
    chem_adddiffusingcount!(c::Context, 2, 4, 400)
    chem_addfixedcount!(c, 1, 1, 10.25)
    chem_addfixedcount!(c, 2, 4, 20.25)
    nummonomers= 9
    monomerstates= zeros(MonomerState,nummonomers)
    monomerstates[1]= s.state.a.me
    monomerstates[2:end-1].= s.state.a.a
    monomerstates[end]= s.state.a.pe
    nodepositions1 = [SA[470.0,200.0,200.0], SA[470.0+9*10.0,200.0,200.0]] .+ Ref(o)
    nodepositions2 = [SA[480.0,201.0,200.0], SA[480.0+9*10.0,201.0,200.0]] .+ Ref(o)
    fida1 = chem_newfilament!(c; ftid=s.filament.a,monomerstates,nodepositions=nodepositions1,node_mids=[1,])
    helper_mark_monomers_minimized!(c)
    compartmentalize!(c)
    fida2 = chem_newfilament!(c; ftid=s.filament.a,monomerstates,nodepositions=nodepositions2,node_mids=[1,])
    helper_mark_monomers_minimized!(c)
    compartmentalize!(c)
    fidb1 = chem_newfilament!(c; ftid=s.filament.b,monomerstates,nodepositions=nodepositions1,node_mids=[1,])
    helper_mark_monomers_minimized!(c)
    compartmentalize!(c)
    fila_idxb2 = make_fila!(c;
        fila_type=:b,
        mono_states=monomerstates,
        node_mids=[1,],
        node_positions = nodepositions2
    )
    fidb2 = _get_fila_id(c, fila_idxb2)
    helper_mark_monomers_minimized!(c)
    compartmentalize!(c)
    chem_newlink_2mon!(c, s.link_2mon.a, MonomerName(s.filament.a,fida1,2)=>MonomerName(s.filament.a,fida1,2))
    chem_newlink_2mon!(c, s.link_2mon.b, MonomerName(s.filament.a,fida1,2)=>MonomerName(s.filament.a,fida1,2))
    chem_newlink_2mon!(c, s.link_2mon.c, MonomerName(s.filament.a,fida1,2)=>MonomerName(s.filament.a,fida1,2))
    chem_newlink_2mon!(c, s.link_2mon.a, MonomerName(s.filament.a,fida1,2)=>MonomerName(s.filament.a,fida2,2);
        changedmechstate=(â=SA[4.0f0,2.0f0,3.0f0],),
        changedchemstate=(a=5,),
    )
    chem_newlink_2mon!(c, s.link_2mon.b, MonomerName(s.filament.b,fidb1,4)=>MonomerName(s.filament.b,fidb1,5))
    chem_newlink_2mon!(c, s.link_2mon.c, MonomerName(s.filament.a,fida1,1)=>MonomerName(s.filament.a,fida1,9))
    chem_newlink_2mon!(c, s.link_2mon.c, MonomerName(s.filament.a,fida1,1)=>MonomerName(s.filament.a,fida1,2);
        is_minimized = true,
    )
    fila_mono_tag_m_b2 = tag!(c, FilaMonoIdx(c, fila_idxb2, -))
    fila_mono_tag_p_b2 = tag!(c, FilaMonoIdx(c, fila_idxb2, +))
    # A spherical membrane touching 3 of the 4 compartments.
    m1 = newmembrane!(c; type=1, meshinit=MeshInitEllipsoid(center=SA[-250,0,0], halfaxes=SA[500,500,500]))
    adapt_membranes!(c; params=MEDYAN.MeshAdaptParams(do_meshsmoothing=true))
    compute_all_membrane_geometry!_system(c)
    addmembranediffusingcount_rand!(c, 1, 2, 20)
    # Set the 1st mesh as a part of the chem boundary.
    set_meshindex_as_chemboundary!(c, 1)

    c, s, fida1, fida2, fidb1, fidb2
end
    

