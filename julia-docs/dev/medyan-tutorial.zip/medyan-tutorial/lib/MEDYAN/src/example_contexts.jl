"""
Simple example Context generators useful for testing.
"""

"""
Typical actin filament parameters.
"""
const ACTIN_FIL_PARAMS = MEDYAN.FilamentMechParams(
    radius= 3.0, # nm
    spacing= 2.7, # nm
    klength= 40*100.0, # pN/nm
    kangle= 40*672.0, # pN*nm/rad²
    numpercylinder= 40, # number of monomers
    max_num_unmin_end= 1,
    # Maximum number of unminimized monomers that can be on an end.
    # This should be less than the minimum `radius` of other 
    # filaments + `radius` divided by `spacing`.
)

"""
Filament parameters where everything is 1, useful for testing.
"""
const UNITY_FIL_PARAMS = MEDYAN.FilamentMechParams(
    radius= 1,
    spacing= 1,
    klength= 1,
    kangle= 1,
    numpercylinder= 1,
    max_num_unmin_end= 1,
)



"""
Return a Context for testing the mechanics of simple actin filaments, no chemistry.
"""
function example_actin_mech_context(grid::CubicGrid; kwarg...)
    agent_names = AgentNames(
        filamentnames= [(:actin,[
                                :a,
                                :restrained,
                            ]),
        ],
    )
    s= SysDef(agent_names)
    add_filament_params!(s, 
        :actin,
        ACTIN_FIL_PARAMS,
    )
    MEDYAN.add_link_type!(s;
        name=:fila_tip_restraint,
        description="restraint for filament tips",
        places=[MEDYAN.FilaTipIdx()],
        bonds=[
            MEDYAN.BondConfig(;
                bond=MEDYAN.PositionDirectionRestraint(),
                input=(1,),
                state=(;kr=10.0, kbend=2.0, r0=SA[NaN,NaN,NaN], v̂0=SA[NaN,NaN,NaN],),
                param=(;),
            ),
        ],
    )
    MEDYAN.add_link_type!(s;
        name=:fila_mono_restraint,
        description="restraint for filament monomers",
        places=[MEDYAN.FilaMonoIdx()],
        bonds=[
            MEDYAN.BondConfig(;
                bond=MEDYAN.PositionDirectionRestraint(),
                input=(1,),
                state=(;kr=10.0, kbend=2.0, r0=SA[NaN,NaN,NaN], v̂0=SA[NaN,NaN,NaN],),
                param=(;),
            ),
        ]
    )

    MEDYAN.add_link_type!(s;
        name=:fila_mono_2forces,
        description="constant force on two filament monomers for testing rates",
        places=[MEDYAN.FilaMonoIdx(), MEDYAN.FilaMonoIdx(),],
        bonds=[
            MEDYAN.BondConfig(;
                bond=MEDYAN.ConstantForce(),
                input=(1,),
                state=(;f=SA[NaN,NaN,NaN],),
                param=(;),
            ),
            MEDYAN.BondConfig(;
                bond=MEDYAN.ConstantForce(),
                input=(2,),
                state=(;f=SA[NaN,NaN,NaN],),
                param=(;),
            ),
        ]
    )

    MEDYAN.add_link_type!(s;
        name=:fila_mono_distance,
        description="distance restraint on two filament monomers for testing",
        places=[MEDYAN.FilaMonoIdx(), MEDYAN.FilaMonoIdx(),],
        bonds=[
            MEDYAN.BondConfig(;
                bond=MEDYAN.DistanceRestraint(),
                input=(1,2),
                state=(;k=10.0, L0=NaN),
                param=(;),
            ),
        ]
    )

    c = MEDYAN.Context(s,grid;
            kwarg...)
    set_mechboundary!(c, MEDYAN.boundary_box(grid; stiffness=100.0))
    c
end


"""
Return a Context and SysDef with multiple filament types and all types of sites for testing site counts. 
"""
function example_all_sites_context(; kwarg...)
    agent_names = AgentNames(
        diffusingspeciesnames= [:b,:c,],
        membranediffusingspeciesnames = [:ma, :mb, :mc],
        fixedspeciesnames= [:d,:a,],
        filamentnames= [
            (:a,[
                :me,
                :a,
                :b,
                :c,
                :pe,
            ]),
            (:b,[
                :me,
                :a,
                :b,
                :c,
                :pe,
            ]),
        ],
    )

    s = SysDef(agent_names)
    #filament related sites
    for ftname = (:a,:b)
        addfilament_reaction!(s,ftname,:ba2bb2,[:b,:a]=>[:b,:b],2,"-->",1.75,0)
        addfilament_reaction!(s,ftname,:ba2bb1,[:b,:a]=>[:b,:b],1,"-->",1.75,0)
        addfilament_reaction!(s,ftname,:ab2bb2,[:a,:b]=>[:b,:b],2,"-->",1.75,0)
        addfilament_reaction!(s,ftname,:ab2bb1,[:a,:b]=>[:b,:b],1,"-->",1.75,0)
        addfilament_reaction!(s,ftname,:a,[:a]=>[:a],1,"-->",1.75,0)
        addfilament_reaction!(s,ftname,:me,[:me]=>[:me],1,"-->",1.75,0)
        addfilament_reaction!(s,ftname,:pe,[:pe]=>[:pe],1,"-->",1.75,0)
        addfilamentend_reaction!(s,ftname,:pm,true,[:me]=>[:me,:a],1.3,"-->",1.75,0)
        addfilamentend_reaction!(s,ftname,:pp,false,[:pe]=>[:a,:pe],1.3,"-->",1.75,0)
        addfilamentend_reaction!(s,ftname,:pmb,true,[:me,:b]=>[:me,:a,:b],1.3,"-->",1.75,0)
        addfilamentend_reaction!(s,ftname,:ppb,false,[:b,:pe]=>[:b,:a,:pe],1.3,"-->",1.75,0)
    end
    #diffusing species
    add_diffusion_coeff!(s, :b, 1.0)
    add_diffusion_coeff!(s, :c, 1.0)
    # links
    MEDYAN.add_link_type!(s;
        name=:fila_tip_restraint,
        description="restraint for filament tips",
        places=[MEDYAN.FilaTipIdx()],
        bonds=[
            MEDYAN.BondConfig(;
                bond=MEDYAN.PositionDirectionRestraint(),
                input=(1,),
                state=(;kr=10.0, kbend=2.0, r0=SA[NaN,NaN,NaN], v̂0=SA[NaN,NaN,NaN],),
                param=(;),
            ),
        ],
        reactions=[[
            (;
                affect! = Returns(1),
                rate = Returns(1.0),
            ),
            (;
                affect! = Returns(1),
                rate = (c; link, link_data, kwargs...) -> let
                    local tags = link2tags(c, link, link_data)
                    if any(is_null, tags)
                        0.0
                    else
                        norm(get_position(c, tags[1]))
                    end
                end
            ),
        ]],
    )
    MEDYAN.add_link_type!(s;
        name=:fila_mono_restraint,
        description="restraint for filament monomers",
        places=[MEDYAN.FilaMonoIdx()],
        bonds=[
            MEDYAN.BondConfig(;
                bond=MEDYAN.PositionDirectionRestraint(),
                input=(1,),
                state=(;kr=10.0, kbend=2.0, r0=SA[NaN,NaN,NaN], v̂0=SA[NaN,NaN,NaN],),
                param=(;),
            ),
        ]
    )
    MEDYAN.add_link_type!(s;
        name=:fila_mono_dummy,
        description="does nothing",
        places=[MEDYAN.FilaMonoIdx()],
    )
    MEDYAN.add_link_type!(s;
        name=:fila_mono_2bonds,
        description="has two bonds",
        places=[MEDYAN.FilaMonoIdx()],
        bonds=[
            MEDYAN.BondConfig(;
                bond=MEDYAN.PositionDirectionRestraint(),
                input=(1,),
                state=(;kr=10.0, kbend=2.0, r0=SA[NaN,NaN,NaN], v̂0=SA[NaN,NaN,NaN],),
                param=(;),
            ),
            MEDYAN.BondConfig(;
                bond=MEDYAN.PositionRestraint(),
                input=(1,),
                state=(;k=1.0,),
                param=(r0=SA[NaN,NaN,NaN],),
            ),
        ],
    )
    MEDYAN.add_link_type!(s;
        name=:fila_mono_distance_bond,
        description="restrain distance between two monomers",
        places=[MEDYAN.FilaMonoIdx(), MEDYAN.FilaMonoIdx()],
        bonds=[
            MEDYAN.BondConfig(;
                bond=MEDYAN.DistanceRestraint(),
                input=(1,2),
                state=(;k=1.0, L0=2.0,),
                param=(;),
            ),
        ],
        reactions=[
            [ # reactions at the first place
                (;
                    # required
                    affect! = (c; link, chem_voxel) -> begin
                        add_diffusing_count!(c; species=:b, chem_voxel, amount=-1)
                        add_diffusing_count!(c; species=:c, chem_voxel, amount=+1)
                        MEDYAN.update_link!(c, link; reaction_enabled=(false,))
                        1
                    end,
                    rate= (c; kwargs...) -> begin
                        # x.context
                        # x.link
                        4.5
                    end,
                    # optional
                    reactants_extra="diffusing.b + fixedspecies.d",
                    enabled=true,
                    invvolumepower=1,
                ),
                (;
                    # required
                    affect! = Returns(1),
                    rate = Returns(100.3),
                    # optional
                    reactants_extra="",
                    enabled=false,
                    invvolumepower=0,
                ),
            ],
        ],
    )
    MEDYAN.add_link_type!(s;
        name=:a,
        description="chemistry test link a",
        state = (;a=1,b=0.3,),
        places=[MEDYAN.FilaMonoIdx(), MEDYAN.FilaMonoIdx()],
        reactions=[
            [
                (;
                    affect! = Returns(1),
                    rate = Returns(1.0),
                ),
            ],
        ],
    )
    MEDYAN.add_link_type!(s;
        name=:b,
        description="chemistry test link b",
        places=[MEDYAN.FilaMonoIdx(), MEDYAN.FilaMonoIdx()],
    )
    MEDYAN.add_link_type!(s;
        name=:c,
        description="chemistry test link c",
        state = (;a=1,b=0.3,),
        places=[MEDYAN.FilaMonoIdx(), MEDYAN.FilaMonoIdx()],
        bonds=[
            MEDYAN.BondConfig(;
                bond=MEDYAN.DistanceRestraint(),
                input=(1,2),
                state=(;k=1.0, L0=2.0,),
                param=(;),
            ),
        ],
        reactions=[
            [
                (;
                    affect! = Returns(1),
                    rate = Returns(1.0),
                ),
                (;
                    affect! = Returns(1),
                    rate = LinkRateMonomerStateMatch(FilaMonoChemState(1,2,3), FilaMonoChemState(1,2,3)),
                ),
                (;
                    affect! = Returns(1),
                    rate = LinkRateMonomerStateMatch(FilaMonoChemState(2,2,2), FilaMonoChemState(2,2,2)),
                ),
                (;
                    affect! = Returns(1),
                    rate = LinkRateMonomerStateMatch(FilaMonoChemState(0,1,2), FilaMonoChemState(1,2,2)),
                ),
                (;
                    affect! = Returns(1),
                    rate = Returns(1.0),
                    fila_cutoff = (:a, 40.0)
                ),
                (;
                    affect! = Returns(1),
                    rate = Returns(1.0),
                    fila_cutoff = (:b, 2.0)
                ),
            ],
        ],
    )
    MEDYAN.add_link_type!(s;
        name = :memb_vert_restraint,
        description="restraint for membrane vertex",
        places=[MembVertIdx()],
        bonds=[
            MEDYAN.BondConfig(;
                bond=MEDYAN.PositionRestraint(),
                input=(1,),
                state=(;k=10.0, r0=SA[NaN,NaN,NaN],),
                param=(;),
            ),
        ],
    )
    #decimated_2mon sites
    site = MEDYAN.Decimated2MonSiteRange(s.filament.a,s.filament.a,1,1,s.state.a.a,s.state.a.a,15.0,35.0)
    add_decimated_2mon_site!(s,:s,site)
    sitestep3 = MEDYAN.Decimated2MonSiteRange(s.filament.a,s.filament.a,3,3,s.state.a.a,s.state.a.a,15.0,35.0)
    add_decimated_2mon_site!(s,:step3,sitestep3)

    monomerspacing= 10.0

    add_filament_params!(s, 
        :a,
        @set(ACTIN_FIL_PARAMS.spacing = monomerspacing),
    )
    add_filament_params!(s, 
        :b,
        @set(ACTIN_FIL_PARAMS.spacing = monomerspacing),
    )
    

    membranemechparams = [
		MEDYAN.MembraneMechParams(
			kbend = 100,
			tension = 0.02,
			eqvolume = (4/3) * π * 800^3,
			kvolume = 0.8,
		),
	]
    grid = CubicGrid((4,1,1),500.0)
    o = MEDYAN.cornerof(grid)
    boundingplanes = MEDYAN.boundary_box(grid; offset=0.0, stiffness=100.0)
    boundingcapsules = MEDYAN.boundary_capsule(;radius=10000.0)
    c= Context(s,grid;
            membrane_species_params=SVector(fill(MembraneSpeciesParams(diffusion_coeff=1.0), 3)...),
            membranemechparams,
            kwarg...)
    set_mechboundary!(c, boundingplanes ∩ boundingcapsules)
    set_chemboundary!(c, boundingplanes ∩ boundingcapsules)
    chem_adddiffusingcount!(c::Context, 1, 2, 100)
    chem_adddiffusingcount!(c::Context, 1, 4, 40)
    chem_adddiffusingcount!(c::Context, 2, 2, 1000)
    chem_adddiffusingcount!(c::Context, 2, 4, 400)
    chem_addfixedcount!(c, 1, 1, 10.25)
    chem_addfixedcount!(c, 2, 4, 20.25)
    nummonomers= 9
    monomerstates= zeros(MonomerState,nummonomers)
    monomerstates[1]= s.state.a.me
    monomerstates[2:end-1].= s.state.a.a
    monomerstates[end]= s.state.a.pe
    nodepositions1 = [SA[470.0,200.0,200.0], SA[470.0+9*10.0,200.0,200.0]] .+ Ref(o)
    nodepositions2 = [SA[480.0,201.0,200.0], SA[480.0+9*10.0,201.0,200.0]] .+ Ref(o)
    fila_plus_tag_a1 = make_fila!(c;
        type=:a,
        mono_states=monomerstates,
        node_mids=[1,],
        node_positions = nodepositions1,
    )
    fila_idxa1 = FilaIdx(c, fila_plus_tag_a1)
    helper_mark_monomers_minimized!(c)
    refresh_chem_cache!(c)
    fila_plus_tag_a2 = make_fila!(c;
        type=:a,
        mono_states=monomerstates,
        node_mids=[1,],
        node_positions = nodepositions2,
    )
    fila_idxa2 = FilaIdx(c, fila_plus_tag_a2)
    helper_mark_monomers_minimized!(c)
    refresh_chem_cache!(c)
    fila_plus_tag_b1 = make_fila!(c;
        type=:b,
        mono_states=monomerstates,
        node_mids=[1,],
        node_positions = nodepositions1,
    )
    fila_idxb1 = FilaIdx(c, fila_plus_tag_b1)
    helper_mark_monomers_minimized!(c)
    refresh_chem_cache!(c)
    fila_plus_tag_b2 = make_fila!(c;
        type=:b,
        mono_states=monomerstates,
        node_mids=[1,],
        node_positions = nodepositions2,
    )
    fila_idxb2 = FilaIdx(c, fila_plus_tag_b2)
    helper_mark_monomers_minimized!(c)
    refresh_chem_cache!(c)
    make_link!(c;
        type=:a,
        places=(FilaMonoIdx(fila_idxa1, 2), FilaMonoIdx(fila_idxa1, 2)),
    )
    make_link!(c;
        type=:b,
        places=(FilaMonoIdx(fila_idxa1, 2), FilaMonoIdx(fila_idxa1, 2)),
    )
    make_link!(c;
        type=:c,
        places=(FilaMonoIdx(fila_idxa1, 2), FilaMonoIdx(fila_idxa1, 2)),
    )
    make_link!(c;
        type=:a,
        places=(FilaMonoIdx(fila_idxa1, 2), FilaMonoIdx(fila_idxa2, 2)),
        state = (;a=5),
    )
    make_link!(c;
        type=:b,
        places=(FilaMonoIdx(fila_idxb1, 4), FilaMonoIdx(fila_idxb1, 5)),
    )
    make_link!(c;
        type=:c,
        places=(FilaMonoIdx(fila_idxa1, 1), FilaMonoIdx(fila_idxa1, 9)),
    )
    make_link!(c;
        type=:c,
        places=(FilaMonoIdx(), FilaMonoIdx(fila_idxa1, 9)),
    )
    make_link!(c;
        type=:c,
        places=(FilaMonoIdx(fila_idxa1, 1), FilaMonoIdx(fila_idxa1, 2)),
        is_minimized = true,
    )
    fila_mono_tag_m_b2 = tag!(c, FilaMonoIdx(c, fila_idxb2, -))
    fila_mono_tag_p_b2 = tag!(c, FilaMonoIdx(c, fila_idxb2, +))
    make_link!(c;
        type=:fila_mono_restraint,
        places=(fila_mono_tag_m_b2,)
    )
    make_link!(c;
        type=:fila_mono_restraint,
        places=(fila_mono_tag_p_b2,)
    )
    make_link!(c;
        type=:fila_mono_dummy,
        places=(fila_mono_tag_p_b2,)
    )
    make_link!(c;
        type=:fila_mono_2bonds,
        places=(fila_mono_tag_p_b2,)
    )
    make_link!(c;
        type=:fila_tip_restraint,
        places=(FilaTipIdx(c, fila_idxb2, +),)
    )
    make_link!(c;
        type=:fila_tip_restraint,
        places=(FilaTipIdx(c, fila_idxa1, +),)
    )
    make_link!(c;
        type=:fila_tip_restraint,
        places=(FilaTipIdx(c, fila_idxa1, -),)
    )
    # A spherical membrane touching 3 of the 4 compartments.
    m1 = newmembrane!(c; type=1, meshinit=MeshInitEllipsoid(center=SA[-250,0,0], halfaxes=SA[500,500,500]))
    last_vertex = tag!(c, MembVertIdx(1, length(m1.vertices))) # last vertex
    make_link!(c;
        type = :memb_vert_restraint,
        places = (last_vertex,),
        bond_states = ((;r0 = get_position(c, last_vertex)),),
    )
    adapt_membranes!(c; params=MEDYAN.MeshAdaptParams(do_meshsmoothing=true))
    compute_all_membrane_geometry!_system(c)
    addmembranediffusingcount_rand!(c, 1, 2, 20)
    # Set the 1st mesh as a part of the chem boundary.
    set_meshindex_as_chemboundary!(c, 1)
    refresh_chem_cache!(c)

    c, s, fila_plus_tag_a1, fila_plus_tag_a2, fila_plus_tag_b1, fila_plus_tag_b2
end
    

