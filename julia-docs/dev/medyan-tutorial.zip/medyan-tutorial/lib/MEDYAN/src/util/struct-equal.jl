function struct_equal(a::T, b::T) where T
    all((isequal(getfield(a, k),getfield(b, k)) for k ∈ fieldnames(T)))
end

function struct_hash(x::T, h::UInt)::UInt where T
    foldr((k, _h)->hash(getfield(x, k), _h), fieldnames(T); init=h)
end