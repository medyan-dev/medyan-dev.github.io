using StaticArrays

"""
Remove several items at once from a vector and relocate items at the back to fill the gaps.
Returns a list of values indicating new indices of the elements if the previous indices are greater than the final size, or 0 otherwise. The i-th value indicates the new index of previously (finalsize + i)-th element.

Invalidates any indices bigger than the final size.

The algorithm works as follows:
- Computes the final size.
- Removes to-be-deleted items with indices > final size.
- Moves the not-to-be-deleted items with indices > final size to the to-be-deleted items with indices <= final size.
- Adjust the size to the final size.
"""
function swaperase!(v::AbstractVector, indices::Vararg{T,N}) where {T<:Integer, N}
    swaperase!(Returns(nothing), v, indices...)
end

"""
The retargeter is a function of signature (fromindex, toindex) -> void, and is called if the deleted element is not the last.
"""
function swaperase!(retargeter, v::AbstractVector, indices::Vararg{T, n}) where {T <: Integer, n}
    newindices = zeros(SVector{n, T})

    # isdeleted[i] is true if (finalsize + i)-th element should be deleted.
    isdeleted = zeros(SVector{n, Bool})
    cursize = length(v)
    finalsize = cursize - n

    # Mark to-be-deleted items.
    for i ∈ 1:n
        if indices[i] > finalsize
            isdeleted = setindex(isdeleted, true, indices[i] - finalsize)
        end
    end

    # Move not-to-be-deleted items with bigger indices to the to-be-deleted items with small indices.
    i = 1
    for indexafterfinal ∈ 1:n
        if !isdeleted[indexafterfinal]
            # Find (including current i) the next i with small index.
            while i <= n && indices[i] > finalsize
                i += 1
            end
            if i <= n
                # Found. This should always be true.
                v[indices[i]] = v[finalsize + indexafterfinal]
                retargeter(finalsize + indexafterfinal, indices[i])
                newindices = setindex(newindices, indices[i], indexafterfinal)
            end
            i += 1
        end
    end

    # Remove garbage.
    resize!(v, finalsize)
    
    (newsize = finalsize, newindices = newindices)
end

"""
Given the swaperase! result, map all given old indices to new indices.
"""
function swaperase_track(swaperase_result, old_indices::Vararg{T,N}) where {T<:Integer, N}
    map(old_indices) do oi
        oi <= swaperase_result.newsize ? oi : swaperase_result.newindices[oi - swaperase_result.newsize]
    end
end
