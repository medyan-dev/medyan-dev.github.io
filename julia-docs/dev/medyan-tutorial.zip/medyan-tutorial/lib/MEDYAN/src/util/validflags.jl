using StaticBitSets: SBitSet

const SBSType = SBitSet{1, UInt64}

mutable struct ValidFlags
    value::SBSType
end
function ValidFlags()
    ValidFlags(SBSType())
end

"""
    @gen_validflagconstants DESC begin
        A => "flag A description"
        B => "flag B description"
        C => "flag C description"
    end

Doing the above creates
- constants named `VF_A`, `VF_B` and `VF_C` with values 1, 2 and 3.
- constants named `VFS_A`, `VFS_B` and `VFS_C` but with type SBSType.
- a constant string vector `DESC` using constant values as indices.

There are a max of 64 flags that can be created.
"""
macro gen_validflagconstants(desc_name::Symbol, names::Expr)
    if names.head != :block
        error("Must wrap constant names in begin end block.")
    end
    max_numflags = 8 * sizeof(SBSType)
    nextflag::Int = 1
    exprs = Expr[]
    used = Set{Symbol}()
    desc_exprs = String[]
    for arg ∈ names.args
        if arg isa Expr
            if arg.head != :call || length(arg.args) != 3 || arg.args[1] != :(=>) || !isa(arg.args[2], Symbol) || !isa(arg.args[3], String)
                error("Each line must have the form  symbol => description.")
            end
            if nextflag > max_numflags
                error("Number of symbols exceed max number allowed: $max_numflags.")
            end
            symb = arg.args[2]
            if symb ∈ used
                error("Symbol $symb exists multiple times.")
            end
            symb_int = Symbol("VF_" * string(symb))
            symb_sbs = Symbol("VFS_" * string(symb))
            val_sbs = Expr(:call, :SBSType, nextflag)
            push!(exprs, esc(:(const $symb_int = $nextflag)))
            push!(exprs, esc(:(const $symb_sbs = $val_sbs)))
            push!(desc_exprs, arg.args[3])
            push!(used, symb)
            nextflag += 1
        end
    end
    # Add description.
    desc_vec = Expr(:vect, desc_exprs...)
    push!(exprs, esc(:(const $desc_name = $desc_vec)))

    Expr(:block, exprs...)
end

@gen_validflagconstants VF_DESC begin
    SEGMENTS => 
    """
    Filament segments in compartments. 
    This includes all of `c.compartments` `segments` fields, and 
    Any site count in `c.chemistryengine` that relies on filament positions.
    Cached data in `c.link_manager`.
    Cached data in all `c.decimated_2mon_site_managers`.
    Cached data in all `c.cadherindata`.
    Cached data in all `c.possiblecadherinsite_managers`.
    """

    VERTEX_IN_COMPARTMENT => "vertex in compartments"
    MEMBRANE_GEOMETRY_FF => "membrane geometries in force fields"
    MEMBRANE_GEOMETRY_SYSTEM => "membrane geometries used in other system computations"
    TEST_1 => "test 1"
    TEST_2 => "test 2"
    TEST_3 => "test 3"
end

"Moving vertex coordinates will break the following consistencies."
const VFS_DEP_VERTEX_COORD = VFS_VERTEX_IN_COMPARTMENT ∪ VFS_MEMBRANE_GEOMETRY_FF ∪ VFS_MEMBRANE_GEOMETRY_SYSTEM

"The following are valid for empty contexts."
const VFS_EMPTY = VFS_SEGMENTS ∪ VFS_VERTEX_IN_COMPARTMENT ∪ VFS_MEMBRANE_GEOMETRY_FF ∪ VFS_MEMBRANE_GEOMETRY_SYSTEM


@inline function checkall(vf::ValidFlags, f::SBSType)::Bool
    f ⊆ vf.value
end

@inline function requireall(vf::ValidFlags, f::SBSType)::Nothing
    if !checkall(vf, f)
        msg = ""
        for x ∈ (f ~ vf.value)
            msg *= VF_DESC[x] * " consistency flag is unset.\n"
        end
        error(msg)
    end
    nothing
end

@inline function set!(vf::ValidFlags, f::SBSType)
    vf.value = vf.value ∪ f
end
@inline function unset!(vf::ValidFlags, f::SBSType)
    vf.value = vf.value ~ f
end
