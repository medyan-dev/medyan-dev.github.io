"""
Useful functions for handling 3d paths. 

A path is a collection of 3d points with position linearly interpolated between points.
"""

using LinearAlgebra
using StaticArrays
using Statistics

const NAN3 = SA[NaN,NaN,NaN]

# clamp between 0 and 1, return 0 if NaN
clamp01nan(x) = ifelse(isnan(x), zero(x), clamp(x,zero(x),one(x)))

# clamp between -1/2 and 1/2, return 0 if NaN
clamphhnan(x) = ifelse(isnan(x), zero(x), clamp(x, oftype(x, -1//2), oftype(x, 1//2)))

# version of min that favors values over NaN
function minnan(x::T, y::T) where T
    ifelse((y < x) | (signbit(y) > signbit(x)),
    ifelse(isnan(y), x, y),
    ifelse(isnan(x), y, x))
end

# version of max that favors values over NaN
function maxnan(x::T, y::T) where T
    ifelse((y > x) | (signbit(y) < signbit(x)),
    ifelse(isnan(y), x, y),
    ifelse(isnan(x), y, x))
end

# Faster norm functions, these may be worse for floating point error.
# See https://github.com/JuliaArrays/StaticArrays.jl/pull/975#issuecomment-1436115140

@inline norm_fast(v) = Base.FastMath.sqrt_fast(sum(abs2, v))

@inline normalize_fast(v) = v * inv(norm_fast(v))

"""
    ortho_normalize(v, r)
Subtract out the part of v that isn't perpendicular to unit vector r and normalize
"""
function ortho_normalize(v, r)
    normalize_fast(v - dot(v,r)*r)
end

"""
    rotate_around(v, t, θ)
Rotate unit vector v around perpendicular unit vector t, using RHR
"""
function rotate_around(v, t, θ)
    w = t × v
    sθ, cθ = sincos(θ)
    cθ*v + sθ*w
end

"""
    transport_vector(v, t1, t2)
Rotate vector v along the rotation that transforms t1 to t2 with the smallest motion.
This is undefined if t1 and t2 are anti-parallel.
"""
function transport_vector(v, t1, t2)
    se = t1 × t2
    c = t1 ⋅ t2
    c * v + se × v + (inv(1 + c) * (se ⋅ v)) * se
end


"""
    linesegment_linesegment_dist2(P0,P1,Q0,Q1)

Return the squared distance between two line segments.
Using the simple algorithm and some comments from
https://www.geometrictools.com/Documentation/DistanceLine3Line3.pdf
// David Eberly, Geometric Tools, Redmond WA 98052
// Copyright (c) 1998-2022
// Distributed under the Boost Software License, Version 1.0.
// https://www.boost.org/LICENSE_1_0.txt
// https://www.geometrictools.com/License/Boost/LICENSE_1_0.txt
// Version: 6.0.2022.01.06
Ignores the case of degenerate line segments.
"""
function linesegment_linesegment_dist2(P0,P1,Q0,Q1)
    P = P1-P0
    Q = Q1-Q0
    P0mQ0 = P0 - Q0
    a = P ⋅ P
    b = P ⋅ Q
    c = Q ⋅ Q
    d = P ⋅ P0mQ0
    e = Q ⋅ P0mQ0
    f = P0mQ0 ⋅ P0mQ0
    Δ = a*c - b^2
    invΔ = inv(Δ)
    #assuming both segments are not zero length
    #critical points
    s0 = clamp01nan(-d/a)
    s1 = clamp01nan((b-d)/a)
    t0 = clamp01nan(e/c)
    t1 = clamp01nan((b+e)/c)
    sbar = clamp01nan((b*e - c*d)*invΔ)
    tbar = clamp01nan((a*e - b*d)*invΔ)
    r(s,t) = a*s^2 - 2b*s*t + c*t^2 + 2d*s - 2e*t
    return Base.FastMath.max_fast(zero(s0),f+Base.FastMath.min_fast(
        r(s0,0),
        r(s1,1),
        r(0,t0),
        r(1,t1),
        r(sbar,tbar),
    ))
end

"""
Return minimum distance from a point p to a line segment between points b1 and b2.
"""
function point_linesegment_mindistance(p,b1,b2)
    b= b2-b1
    a= p-b1
    c= p-b2
    #first figure out if the point is closer to the center, b1 or b2
    if (a ≈ c) || a⋅b ≤ 0 
        #closest to b1
        return norm_fast(a)
    elseif c⋅b ≥ 0
        #closest to b2
        return norm_fast(c)
    else
        #in center
        b̂ = normalize_fast(b) # note previous if takes care of case where b is close to 0
        return norm_fast(a - (a⋅b̂)*b̂)
    end
end

"""
Return minimum distance from a point p to `path`.
`path` is a collection of 2 or more points.
"""
function point_path_mindistance(p,path)
    minimum(point_linesegment_mindistance(p,path[i],path[i+1]) for i in firstindex(path):(lastindex(path)-1))
end

"""
Return the length of a path.
`path` is a collection of 2 or more points.
"""
function pathlength(path)
    sum(norm_fast(path[i]-path[i+1]) for i in firstindex(path):(lastindex(path)-1))
end


"""
Return the min, max, average, distance between two paths.
Sampling points on both paths, evenly distributed by length. 
Return the min, max, average of the minimum distance of each of the sampled points to the other path.
Return types are Float64

`path1` and `path2` are collections of 2 or more points.
`pointspersegment` is how many points to sample per segment.
"""
function min_max_avg_pathdistance(path1,path2;pointspersegment=100)
    @assert length(path1)>1
    @assert length(path2)>1
    l1= pathlength(path1)
    l2= pathlength(path2)
    totall= l1+l2
    mind::Float64= Inf
    maxd::Float64= 0.0
    avgd::Float64= 0.0
    for (patha,pathb) in ((path1,path2),(path2,path1))
        for i in firstindex(patha):(lastindex(patha)-1)
            weight= norm_fast(patha[i] - patha[i+1])/pointspersegment/totall
            for p in LinRange(patha[i], patha[i+1], pointspersegment)
                d= point_path_mindistance(p,pathb)
                mind= min(mind,d)
                maxd= max(maxd,d)
                avgd= +(avgd,weight*d)
            end
        end
    end
    return mind,maxd,avgd
end


"""
Return a vector of points evenly distributed on a path.
`path` is a collection of 2 or more points.
The end points of the path are not included 
and are half distance from the first and last points.
"""
function evenpathpoints(numpoints,path)
    l= pathlength(path)
    d= l/numpoints
    lenleft= d/2
    nodeindex = firstindex(path)
    segmentl = norm_fast(path[nodeindex]-path[nodeindex+1])
    leninseg = 0.0
    points= [zero(first(path)) for i in 1:numpoints]
    for i in 1:numpoints
        while lenleft>(segmentl-leninseg)
            lenleft -= (segmentl-leninseg)
            nodeindex += 1
            segmentl = norm_fast(path[nodeindex]-path[nodeindex+1])
            leninseg = 0.0
        end
        leninseg += lenleft
        λ = leninseg/segmentl
        points[i] = (1-λ)*path[nodeindex] + (λ)*path[nodeindex+1]
        lenleft = d
    end
    points
end


"""
Return a measure of the difference of the shapes of two filaments.
Ignores translation, and rotation.
Doesn't ignore path direction or chirality.
`numpoints` points are sampled evenly from each path 
then the RMSD is returned after centroids are aligned and
rotation is aligned using the Kabsch algorithm.
"""
function path_rmsd(path1,path2;numpoints=10000)
    #convert paths to points
    points1= evenpathpoints(numpoints,path1)
    points2= evenpathpoints(numpoints,path2)
    kabsch_rmsd(points1, points2)
end


"""
Returns the rotation matrix of P into Q.
P and Q are collections of 3d points with centroid at the origin.
https://en.wikipedia.org/wiki/Kabsch_algorithm
"""
function kabsch(P,Q)
    H = reduce(hcat,P) * reduce(hcat,Q)'
    F = svd(H)
    d = sign(det(F.U*F.Vt))
    U = F.U
    V = F.V
    V[:,end] .*= d
    #the rotation of P into Q
    V*U'
end

"""
P and Q are collections of 3d points
"""
function kabsch_rmsd(P,Q)
    #translate so centroids are at the origin
    P = P .- Ref(mean(P))
    Q = Q .- Ref(mean(Q))
    #get rotation
    R = kabsch(P,Q)
    @assert det(R) ≈ 1
    Prot= Ref(R) .* P
    displacement = Prot .- Q
    √(mean(p->p⋅p,displacement))
end
