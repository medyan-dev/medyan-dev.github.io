# Chemical unit conversion functions and constants.
const mol = big"602214076" * big"10" ^ 15
const μM⁻¹_per_nm³ = 6.02214076E-7