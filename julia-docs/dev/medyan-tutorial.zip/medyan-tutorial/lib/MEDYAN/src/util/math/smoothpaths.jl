"""
Useful functions for getting smooth 3d paths that look nice.

A path is a collection of 3d points with position linearly interpolated between points.
"""

using LinearAlgebra
using Random
import Random123
using StaticArrays
import Optim
import NNlib
import SmallZarrGroups

const smoothpath_endpoints_diraway_nn_model = let
    modelpath = joinpath(@__DIR__, "../../../trained-models/smoothpaths/model.zarr.zip")
    modelfile = SmallZarrGroups.load_dir(modelpath)
    # @show modelpath

    w1= collect(modelfile["1"])
    w1s = SMatrix{size(w1)...}(w1)
    b1= collect(modelfile["2"])
    b1s = SVector{length(b1)}(b1)

    w2= collect(modelfile["3"])
    w2s = SMatrix{size(w2)...}(w2)
    b2= collect(modelfile["4"])
    b2s = SVector{length(b2)}(b2)

    w3= collect(modelfile["5"])
    w3s = SMatrix{size(w3)...}(w3)
    b3= collect(modelfile["6"])
    b3s = SVector{length(b3)}(b3)

    w4= collect(modelfile["7"])
    w4s = SMatrix{size(w4)...}(w4)
    b4= collect(modelfile["8"])
    b4s = SVector{length(b4)}(b4)
    σ = NNlib.relu
    function model(x1)
        x2 = σ.(w1s * x1 .+ b1s)
        x3 = σ.(w2s * x2 .+ b2s)
        x4 = σ.(w3s * x3 .+ b3s)
        (w4s * x4 .+ b4s)
    end 
end

"""
Return a 10 point path from start to end points, minimum length, pointing ⟂ from start and end unit vectors.
uses trained artificial neural network model
"""
function smoothpath_endpoints_diraway(start_point,start_dir,end_point,end_dir,minlength, seed)
    rng = Random123.Philox2x(seed)#Xoshiro(seed)
    # start unit vector is x̂ 
    x_nn_sim = start_dir
    # The ending position is always in the x,y plane, with positive x and y.
    Δr_sim = end_point - start_point
    realL = norm_fast(Δr_sim)
    #scale to trained range
    scale = if realL < 5minlength
        1/minlength
    else
        5/realL
    end
    # add random number to end_point to avoid divide by zero later
    scaledΔr_sim = scale*Δr_sim + 1E-6*randn(rng,SVector{3,Float32})
    #ensure scaledΔr_nn has positive x.
    end_point_nn_x = scaledΔr_sim ⋅ x_nn_sim
    if end_point_nn_x < 0
        x_nn_sim *= -1
        end_point_nn_x *= -1
    end
    #ensure scaledΔr_nn has positive y.
    z_nn_sim = normalize_fast(cross(x_nn_sim,scaledΔr_sim))
    all(isfinite,z_nn_sim) || error("non finite z_nn_sim")
    y_nn_sim = cross(z_nn_sim,x_nn_sim)
    dcm_sim_nn = hcat(x_nn_sim,y_nn_sim,z_nn_sim)
    dcm_nn_sim = dcm_sim_nn'
    end_dir_nn = dcm_nn_sim*end_dir
    end_point_nn_y = scaledΔr_sim ⋅ y_nn_sim
    x1 = SA[end_point_nn_x, end_point_nn_y, end_dir_nn...]
    output = smoothpath_endpoints_diraway_nn_model(x1)
    scaled_path_nn = reinterpret(SVector{3,eltype(output)},[output])
    path_sim = Ref(dcm_sim_nn) .* scaled_path_nn
    path_sim .*= (1/scale)
    path_sim .+= Ref(start_point)
    [[start_point]; path_sim; [end_point]]
end


"""
Old version without trained artificial neural network
Return a path from start to end points, minimum length, pointing ⟂ from start and end unit vectors.
"""
function smoothpath_endpoints_diraway_slow(start_point,start_dir,end_point,end_dir,minlength, seed, numpoints=10)
    L0 = (norm_fast(end_point - start_point) + minlength) / (numpoints - 1) 
    function fg!(F,G,x)
        dim = 3
        kd = 1.0
        k∠ = 1.0
        posvect = [ [start_point] ; reinterpret(SVector{dim,eltype(x)},x) ; [end_point] ]
        mnum = length(posvect)
        forcesvect = zero(posvect)
        energy = 0.0
        #add initial length bond force and Energy
        pos = posvect[1]
        nextpos = posvect[2]
        r2 = nextpos - pos
        L2 = norm_fast(r2)
        ΔL2 = L0 - L2
        invL2 = inv(L2)
        r̂2 = r2*invL2
        Ed = 1//2*kd*(ΔL2)^2
        F2d = kd*(ΔL2)*r̂2
        r̂1 = start_dir
        cosθ = r̂1'*r̂2
        E∠ = 1//2*k∠*(cosθ)^2
        F2∠ = k∠*cosθ*invL2*(r̂2*cosθ - r̂1)
        energy += Ed + E∠
        forcesvect[2] += F2∠ + F2d
        for i in 2:(mnum-1)
            lastpos = posvect[i-1]
            pos = posvect[i]
            nextpos = posvect[i+1]
            r1 = lastpos-pos
            L1 = norm_fast(r1)
            invL1 = inv(L1)
            r̂1 = r1*invL1
            r2 = nextpos - pos
            L2 = norm_fast(r2)
            invL2 = inv(L2)
            r̂2 = r2*invL2
            cosθ = r̂1'*r̂2
            ΔL2 = L0 - L2
            Ed = 1//2*kd*(ΔL2)^2
            F2d = kd*(ΔL2)*r̂2
            E∠ = k∠*(cosθ+1)
            F1∠ = k∠*invL1*(r̂1*cosθ - r̂2)
            F2∠ = k∠*invL2*(r̂2*cosθ - r̂1)
            #Store forces and energies
            forcesvect[i-1] +=  F1∠
            forcesvect[i] -= F2d + F2∠ + F1∠
            forcesvect[i+1] += F2∠ + F2d
            energy += Ed + E∠ 
        end
        #add final angle bond force and Energy
        pos = posvect[end]
        lastpos = posvect[end-1]
        r1 = lastpos-pos
        L1 = norm_fast(r1)
        invL1 = inv(L1)
        r̂1 = r1*invL1
        r̂2 = end_dir
        cosθ = r̂1'*r̂2
        E∠ = 1//2*k∠*(cosθ)^2
        F1∠ = k∠*cosθ*invL1*(r̂1*cosθ - r̂2)
        energy += E∠
        forcesvect[end-1] += F1∠
        if !isnothing(G)
            gvec = reinterpret(SVector{dim,eltype(G)},G)
            gvec .= .- @view(forcesvect[2:(end-1)])
        end
        if !isnothing(F)
            return energy
        end
    end
    x0 = collect(LinRange(start_point, end_point, numpoints)[2:(end-1)])
    rng = MersenneTwister(seed)
    x0 .+= randn(rng,SVector{3,Float64},numpoints-2)
    x0flat = collect(reinterpret(eltype(eltype(x0)),x0))
    res= Optim.optimize(Optim.only_fg!(fg!), x0flat, 
            Optim.Options(iterations=10000,g_tol=1E-5))
    xmin= Optim.minimizer(res)
    [[start_point]; reinterpret(SVector{3,eltype(xmin)},xmin); [end_point]]
end



