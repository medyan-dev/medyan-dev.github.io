"""
Manages Axis-Aligned Bounding Box (AABB) tree structure for objects.
"""

using DocStringExtensions
using StaticArrays


"""
`N` indicates dimension.
`T` is the real type of coordinates.
"""
struct AABB{N,T<:Real}
    offset::SVector{N,T}
    size::SVector{N,T}
    "Index in the data array. 0 indicates that this is not a leaf node."
    dataindex::Int
end
function isleaf(aabb::AABB)
    aabb.dataindex != 0
end

"""
`N` is the dimension.
`T` is the real type of coordinates.
`DT` is the data type associated with leaf.
"""
struct BinaryAABBTree{N, T, DT}
    nodes::Vector{AABB{N,T}}
    data::Vector{DT}
end

function Base.isempty(tree::BinaryAABBTree)
    isempty(tree.data)
end


"""
Build binary AABB tree.

- `getboxinfo`: (auxdata, index) -> NamedTuple{offset, size}
"""
function build_binary_aabbtree(getboxinfo, data)
    nobj = length(data)

    tempboxes = map(eachindex(data)) do i
        offset, size = getboxinfo(data, i)
        (; offset, size, mid=offset+size/2)
    end
    perm = collect(eachindex(data))

    CoordType = fieldtype(eltype(tempboxes), :offset)
    N = length(CoordType)
    T = eltype(CoordType)
    NT = AABB{N,T}

    # Create nodes.
    nnodes = nobj == 0 ? 0 : nextpow(2, nobj) * 2 - 1
    nodes = Vector{NT}(undef, nnodes)
    if nobj != 0
        build_binary_aabbtree_aux!(tempboxes, perm, nodes, 1)
    end

    BinaryAABBTree(nodes, data)
end

function build_binary_aabbtree_aux!(tempboxes, vperm, nodes::Vector{AABB{N,T}}, nodeindex) where {N,T}
    nperm = length(vperm)
    ibox1 = vperm[1]
    if nperm == 1
        # This is a leaf node.
        nodes[nodeindex] = AABB(tempboxes[ibox1].offset, tempboxes[ibox1].size, ibox1)
    else
        # Find outer bounding box.
        xmin::SVector{N,T} = tempboxes[ibox1].offset
        xmax::SVector{N,T} = xmin + tempboxes[ibox1].size
        for iperm ∈ 2:nperm
            local ibox = vperm[iperm]
            xmin = min.(xmin, tempboxes[ibox].offset)
            xmax = max.(xmax, tempboxes[ibox].offset + tempboxes[ibox].size)
        end
        thesize = xmax - xmin
        nodes[nodeindex] = AABB(xmin, thesize, 0)

        # Find axis of maximum size. Then sort and divide along that axis.
        maxdim = argmax(dim -> thesize[dim], 1:N)
        sort!(vperm; by = ibox -> tempboxes[ibox].mid[maxdim])
        mid = length(vperm) ÷ 2

        # Build children.
        build_binary_aabbtree_aux!(tempboxes, view(vperm, 1:mid), nodes, 2*nodeindex)
        build_binary_aabbtree_aux!(tempboxes, view(vperm, mid+1:nperm), nodes, 2*nodeindex+1)
    end
    nothing
end


"""
Check consistency of AABBTree.
"""
function check_binary_aabbtree_consistency(t::BinaryAABBTree)
    msg = ""

    nobj = length(t.data)
    expected_nnode = nobj == 0 ? 0 : nextpow(2, nobj) * 2 - 1
    if length(t.nodes) != expected_nnode
        msg *= "Invalid size of nodes $(length(t.nodes)), expected $expected_nnode.\n"
    end

    # Returns the number of leaf nodes traversed.
    function traverse_and_check!(nodeindex)::Int
        node = t.nodes[nodeindex]
        if isleaf(node)
            return 1
        else
            # Check that the box includes all children.
            xmin_children = min.(
                t.nodes[2*nodeindex  ].offset,
                t.nodes[2*nodeindex+1].offset,
            )
            xmax_children = max.(
                t.nodes[2*nodeindex  ].offset + t.nodes[2*nodeindex  ].size,
                t.nodes[2*nodeindex+1].offset + t.nodes[2*nodeindex+1].size,
            )
            if any(node.offset .> xmin_children)
                msg *= "At node index $nodeindex, offset $(node.offset) does not enclose the children minimum $(xmin_children).\n"
            end
            if any(node.offset + node.size .< xmax_children)
                msg *= "At node index $nodeindex, offset $(node.offset) does not enclose the children maximum $(xmin_children).\n"
            end
            return traverse_and_check!(2*nodeindex) + traverse_and_check!(2*nodeindex+1)
        end
    end

    if !isempty(t)
        nleaves_traversed = traverse_and_check!(1)
        if nleaves_traversed != nobj
            msg *= "Traversed leaf node number $nleaves_traversed does not match the number of objects $nobj.\n"
        end
    end

    msg
end

"""
Given a ray specified by origin `o` and element-wise inversed director `invd`, find the range of parameter `t` on the line of ray that intersects an AABB box.
The point on the ray can be represented as `p(t) = o + t * d` and `invd = 1 ./ d`. Note that `t` can be negative.

Returns intersection parameter range represented as tuple `(tmin, tmax)`, or `nothing` if there is no intersection.
Additionally, `tinterval` can be passed as a closed interval. The result interval will be confined within the specified interval. For example, for ray intersections, `tinterval` should be `(0,Inf)`.

Reference: https://tavianator.com/2011/ray_box.html
"""
function line_intersect(aabb::AABB{N}, o::AbstractVector, invd::AbstractVector, tinterval::Tuple{<:Real,<:Real}) where N
    tmin::Float64 = tinterval[1]
    tmax::Float64 = tinterval[2]

    for i ∈ 1:N
        t1 = (aabb.offset[i]                - o[i]) * invd[i]
        t2 = (aabb.offset[i] + aabb.size[i] - o[i]) * invd[i]
        # If t1 or t2 is nan, normally d[i] = 0 and o lies in either plane. We consider both cases as intersecting, so no update on tmin and tmax.
        if !isnan(t1) && !isnan(t2)
            tmin = max(tmin, min(t1, t2))
            tmax = min(tmax, max(t1, t2))
        end
    end

    tmin <= tmax ? (tmin, tmax) : nothing
end



"""
    $(TYPEDSIGNATURES)

Perform ray tracing with an AABB tree.

# Arguments
- `func_rayelement`: (data, index, ray_origin, ray_director, tinterval, output) -> output
- `tree`: the AABB tree object.
- `o`: The origin of the ray.
- `d`: The direction of the ray.
- `output`: The external states to be returned. Modifying output in `func_rayelement` is allowed.
- `tinterval`: The closed interval for line segment.
"""
function trace_line(func_rayelement, tree::BinaryAABBTree, o::AbstractVector, d::AbstractVector, output; tinterval=(-Inf,Inf))
    if isempty(tree)
        output
    else
        invd = 1 ./ d
        trace_line_aux(func_rayelement, tree.nodes, 1, tree.data, o, d, invd, tinterval, output)
    end
end

function trace_line_aux(func_rayelement, nodes, nodeindex, data, o, d, invd, tinterval, output)
    if !isnothing(line_intersect(nodes[nodeindex], o, invd, tinterval))
        if isleaf(nodes[nodeindex])
            # Perform actual ray tracing with the element.
            output = func_rayelement(data, nodes[nodeindex].dataindex, o, d, tinterval, output)
        else
            # Find in children.
            output = trace_line_aux(func_rayelement, nodes, 2*nodeindex, data, o, d, invd, tinterval, output)
            output = trace_line_aux(func_rayelement, nodes, 2*nodeindex+1, data, o, d, invd, tinterval, output)
        end
    end
    output
end
