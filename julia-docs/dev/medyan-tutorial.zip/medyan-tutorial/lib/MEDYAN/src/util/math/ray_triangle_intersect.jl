using DocStringExtensions
using LinearAlgebra


"""
Given point O, ray vector D, and a triangle with points (A,B,C), test whether the ray intersects the triangle.
If there is an intersection P. Then P can be represented as

    P = A + u(B-A) + v(C-A) = O + tD

If there is not an intersection, `t`, `u` and `v` are undefined.
"""
struct RayTriangleIntersectResult{Float}
    intersect::Bool
    t::Float
    u::Float
    v::Float
end
const ray_triangle_no_intersect = RayTriangleIntersectResult(false, 0.0, 0.0, 0.0)

"""
    $(TYPEDSIGNATURES)

A fast ray-triangle intersection algorithm by Moller and Trumbore.
Ref: Tomas Möller and Ben Trumbore, "Fast, minimum storage ray-triangle intersection" (1997) Journal of Graphics Tools.
"""
function moller_trumbore_intersect(o, d, a, b, c; tinterval=(-Inf,Inf), eps=1e-9)::RayTriangleIntersectResult{Float64}
    rab = b - a
    rac = c - a
    cross_d_rac = cross(d, rac)
    det = dot(cross_d_rac, rab)

    if abs(det) <= eps
        return ray_triangle_no_intersect
    end

    invdet = 1 / det;
    rao = o - a
    u = dot(cross_d_rac, rao) * invdet
    if u < 0 || u > 1
        return ray_triangle_no_intersect
    end

    cross_rao_rab = cross(rao, rab)
    v = dot(cross_rao_rab, d) * invdet
    if v < 0 || u + v > 1
        return ray_triangle_no_intersect
    end

    t = dot(cross_rao_rab, rac) * invdet
    if t < tinterval[1] || t > tinterval[2]
        return ray_triangle_no_intersect
    end

    RayTriangleIntersectResult{Float64}(true, t, u, v)
end
