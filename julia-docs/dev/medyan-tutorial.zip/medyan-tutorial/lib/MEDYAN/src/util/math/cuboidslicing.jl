using StaticArrays
using ArgCheck
using Meshing: isosurface, MarchingTetrahedra
using LinearAlgebra

"""
Most of the following code is translated from the medyan.cpp file:

  src/Util/Math/CuboidSlicing.hpp originally written by Haoran Ni (drelatgithub) haoranni@umd.edu

The function_box_slice related code is not in medyan.cpp.
"""

"""

$(TYPEDFIELDS)

"""
struct PlaneCuboidSlicingResult{Float<:Real}

    "New volume in the cuboid"
    volumeIn::Float

    """
    New area of each face of the cuboid
    in the order of
    x = x_min, 
    x = x_max,
    y = y_min, 
    y = y_max,
    z = z_min, 
    z = z_max
    """
    areaIn::SVector{6,Float}
end

"""
scale the volume and area
"""
function Base.:*(x::PlaneCuboidSlicingResult, a::Real)::PlaneCuboidSlicingResult
    a2 = a*a
    volumeIn = x.volumeIn*a2*a
    areaIn = x.areaIn .* a2
    PlaneCuboidSlicingResult(volumeIn,areaIn)
end

"""
scale the volume and area by different amounts in each direction
"""
function Base.:*(x::PlaneCuboidSlicingResult, a::AbstractVector)::PlaneCuboidSlicingResult
    otherinds = SA[
            SA[2,3],
            SA[3,1],
            SA[1,2],
        ]
    areascaling = @SVector [prod(a[otherinds[i>>1 + 1]]) for i in 0:5]
    areaIn = x.areaIn .* areascaling
    volumeIn = x.volumeIn*prod(a)
    PlaneCuboidSlicingResult(volumeIn,areaIn)
end

"""
coords (0-7) in binary is zyx 
"""
function flip(x::PlaneCuboidSlicingResult, flippedCoords)::PlaneCuboidSlicingResult
    areaIn = @SVector [x.areaIn[i⊻(flippedCoords>>(i>>1) & 1) + 1] for i in 0:5]
    PlaneCuboidSlicingResult(x.volumeIn,areaIn)
end

"""
shift is number of backwards rotations
 0 is xyz
 1 is yzx
 2 is zxy
 3 is xyz
"""
function coordcircshift(x::PlaneCuboidSlicingResult, shift)::PlaneCuboidSlicingResult
    areaIn = SVector(circshift(x.areaIn,-2shift))
    PlaneCuboidSlicingResult(x.volumeIn,areaIn)
end

"""
a is cube size
"""
function reverseresult(x::PlaneCuboidSlicingResult, a::Real)::PlaneCuboidSlicingResult
    a2 = a*a
    volumeIn = a2 * a - x.volumeIn;
    areaIn = a2 .- x.areaIn
    PlaneCuboidSlicingResult(volumeIn,areaIn)
end

"""
    plane_unitcube_slice(point,normal)::PlaneCuboidSlicingResult
- `point`: A point on the plane.
- `normal`: Unit normal of the plane pointing outwards.
"""
function plane_unitcube_slice(point,normal)::PlaneCuboidSlicingResult
    Float = eltype(point)
    @argcheck eltype(point) == eltype(normal)
    @argcheck length(point) == length(normal) == 3

    # First consider the case where normal has only non-neg components
    flippedPoint = MVector{3}(point)
    flippedNormal = MVector{3}(normal)
    flippedCoords = 0x00
    for idx in 0:2
        if signbit(normal[idx+1])
            flippedCoords += (1 << idx)
            flippedPoint[idx+1] = 1 - flippedPoint[idx+1]
            flippedNormal[idx+1] = -flippedNormal[idx+1]
        end
    end

    signedDist = dot(flippedPoint, flippedNormal)
    signedDistMax = sum(flippedNormal)

    reverse = false

    shift = 0

    res::PlaneCuboidSlicingResult{Float} = if signedDist <= 0 
        # do nothing because everything is zero
        PlaneCuboidSlicingResult{Float}(zero(Float),zeros(SVector{6,Float}))
    elseif signedDist >= signedDistMax
        PlaneCuboidSlicingResult{Float}(one(Float),ones(SVector{6,Float}))
    else
        if signedDist > 1//2 * signedDistMax
            # Doing a full flip, plus swapping inside/outside,
            # which leaves the normal unchanged.
            reverse = true
            flippedCoords ⊻= 0x07 #full flip
            flippedPoint .= 1 .- flippedPoint

            signedDist = signedDistMax - signedDist
        end

        # Now the signedDist should be within [0, 0.5 signedDistMax]

        # Find the intersections on the axis. The values should be within [0, +inf]
        intercepts = signedDist ./ flippedNormal
        invintercepts = flippedNormal .* (1/signedDist)
        # println("")
        # @show intercepts

        numGT1 = count(>(1),intercepts)

        # @show numGT1

        otherinds = SA[
            SA[2,3],
            SA[3,1],
            SA[1,2],
        ]
        
        if numGT1==0
            PlaneCuboidSlicingResult{Float}(
                1//6*prod(intercepts),
                vcat((SA[1//2*prod(intercepts[otherinds[i]]), zero(Float)] for i in 1:3)...)
            )
        elseif numGT1==1
            GT1ind = findfirst(>(1),intercepts)
            # circshift so GT1ind is at index 1
            x,y,z = intercepts[GT1ind], intercepts[mod1(GT1ind+1,3)], intercepts[mod1(GT1ind+2,3)]
            shift = GT1ind-1
            invx = invintercepts[GT1ind]
            Ab = 1//2 * y * z
            r = 1 - invx
            y1 = y * r
            z1 = z * r
            PlaneCuboidSlicingResult{Float}(
                1//3*Ab*(3- 3invx + invx^2),
                SA[
                    Ab,
                    1//2 * y1 * z1,
                    1//2 * (z + z1),
                    0,
                    1//2 * (y + y1),
                    0,
                ],
            )
        elseif numGT1==2
            LTE1ind = findfirst(≤(1),intercepts)
            # circshift so LTE1ind is at index 1
            x,y,z = intercepts[LTE1ind], intercepts[mod1(LTE1ind+1,3)], intercepts[mod1(LTE1ind+2,3)]
            invy, invz =  invintercepts[mod1(LTE1ind+1,3)], invintercepts[mod1(LTE1ind+2,3)]
            shift = LTE1ind-1
            r1 = 1-invy
            r2 = 1-invz
            r3 = 1-invy-invz
            z1 = clamp(z*r1,0,1)
            y1 = clamp(y*r2,0,1)
            x3 = x*r3
            x1 = x*r1
            x2 = x*r2
            if r3<0
                PlaneCuboidSlicingResult{Float}(
                    1//2*(x+x3) - 1//6*x3*(1-y1)*(1-z1),
                    SA[
                        1 - 1//2*(1-y1)*(1-z1),
                        0,
                        1//2*(x+x2),
                        1//2*x1*z1,
                        1//2*(x+x1),
                        1//2*x2*y1,
                    ]
                )
            else
                PlaneCuboidSlicingResult{Float}(
                    1//2*(x+x3),
                    SA[
                        1,
                        0,
                        1//2*(x+x2),
                        1//2*(x1+x3),
                        1//2*(x+x1),
                        1//2*(x2+x3),
                    ]
                )
            end
        elseif numGT1==3
            MAXind = argmax(intercepts)
            # circshift so MAXind is at index 1
            # Only x can be huge now.
            x,y,z = intercepts[MAXind], intercepts[mod1(MAXind+1,3)], intercepts[mod1(MAXind+2,3)]
            invx, invy, invz =  invintercepts[MAXind], invintercepts[mod1(MAXind+1,3)], invintercepts[mod1(MAXind+2,3)]
            shift = MAXind-1
            x01 = clamp(x*(1-invz),0,1)
            x10 = clamp(x*(1-invy),0,1)
            y10 = clamp(y*(1-invz),0,1)
            y01 = clamp(y*(1-invx),0,1)
            z01 = clamp(z*(1-invy),0,1)
            z10 = clamp(z*(1-invx),0,1)
            PlaneCuboidSlicingResult{Float}(
                # Uses the formula from case 1 incase x is huge, then subtracts out the side tetrahedrons.
                #1//6*(y*z*x - y01*z10*(x-1) - x01*y10*(z-1) - z01*x10*(y-1)),
                1//6*(y*z*(3 - 3invx + invx^2) - x01*y10*(z-1) - z01*x10*(y-1)),
                SA[
                    1 - 1//2*(1-y10)*(1-z01),
                    1//2*y01*z10,
                    1 - 1//2*(1-z10)*(1-x01),
                    1//2*z01*x10,
                    1 - 1//2*(1-x10)*(1-y01),
                    1//2*x01*y10,
                ]
            )
        end     
    end
    # Finally restore the circshift
    res= coordcircshift(res,-shift)
    # Finally restore the flipping
    res= flip(res,flippedCoords);
    if reverse
        res= reverseresult(res,one(Float))
    end
    return res
end

"""
    plane_box_slice(point,normal,r0,a)::PlaneCuboidSlicingResult
- `point`: A point on the plane.
- `normal`: Unit normal of the plane pointing outwards.
- `r0`: (x_min, y_min, z_min) of the cube.

`a` determines the box shape.
1. A Real is a Cube length
1. A Vector is a box aligned with the x,y,z axes, with corresponding x,y,z lengths.

"""
function plane_box_slice(point,normal,r0,a::Real)::PlaneCuboidSlicingResult
    @argcheck eltype(point) == eltype(normal) == eltype(r0) == typeof(a)
    @argcheck length(point) == length(normal) == length(r0) == 3
    plane_unitcube_slice((point - r0) / a, normal) * a
end

function plane_box_slice(point,normal,r0,a::AbstractVector)::PlaneCuboidSlicingResult
    @argcheck eltype(point) == eltype(normal) == eltype(r0) == eltype(a)
    @argcheck length(point) == length(normal) == length(r0) == length(a) == 3
    plane_unitcube_slice((point - r0) ./ a, normalize_fast(normal .* a)) * a
end


"""
    function_box_slice(f,r0,a)::PlaneCuboidSlicingResult
- `f`: A function that is positive outside and negative inside.
- `r0`: (x_min, y_min, z_min) of the cube.

`a` determines the box shape.
1. A Real is a Cube length
1. A Vector is a box aligned with the x,y,z axes, with corresponding x,y,z lengths.

# Keyword Args
- `samples = SVector(20,20,20)`: How many samples of the function in each axis to use.
- `largeval = 1E10`: A value larger than any function value in the box.
- `eps=1E-3`: Passed to `Meshing.MarchingTetrahedra`: "`eps` is the tolerence around a voxel corner to ensure manifold mesh generation". 

"""
function function_box_slice(f,r0,a; kwargs...)::PlaneCuboidSlicingResult
    @argcheck eltype(r0) == eltype(a)
    @argcheck length(r0) == length(a) == 3
    fprime(r) = f((r.*a)+r0)
    function_unitcube_slice(fprime; kwargs...) * a
end

function function_box_slice(f,r0,a::Real; kwargs...)::PlaneCuboidSlicingResult
    function_box_slice(f,r0,SA[a,a,a]; kwargs...)
end

function function_unitcube_slice(f; samples = SVector(20,20,20), largeval = 1E10, eps=1E-3)
    points, triangles = isocap(f; samples, largeval, eps, widths=SVector(1.0,1.0,1.0), origin=SVector(0.0,0.0,0.0))
    volume::Float64 = 0.0
    areas = zero(MVector{6,Float64})
    for triangle in triangles
        for face_index in 0:5
            area = is_triangle_on_unitcube_face(face_index, points, triangle, eps)
            if !isnothing(area)
                areas[face_index+1] += area
            end
        end
        volume += triangle_volume_on_unitcube(points, triangle)
    end
    PlaneCuboidSlicingResult{Float64}(volume,areas)  
end

"""
Return the area of the triangle if a triangle is on a cube face, and points out of the cube. 
Face index is the following
    0 = x_min, 
    1 = x_max,
    2 = y_min, 
    3 = y_max,
    4 = z_min, 
    5 = z_max
Otherwise return nothing
"""
function is_triangle_on_unitcube_face(face_index, allpoints, triangle, eps)
    coordid = face_index>>1
    ismax = face_index%Bool
    points = map(i->allpoints[i],triangle)
    if ismax
        if any(map(r->(r[coordid+1]<(1-eps)),points))
            return nothing
        end
        normal = cross(points[2]-points[1],points[3]-points[1])
        if signbit(normal[coordid+1])
            return nothing
        end
    else
        if any(map(r->(r[coordid+1]>(eps)),points))
            return nothing
        end
        normal = cross(points[2]-points[1],points[3]-points[1])
        if !signbit(normal[coordid+1])
            return nothing
        end
    end
    return 1//2*abs(normal[coordid+1])
end

"""
Return signed volume of triange to origin
"""
function triangle_volume_on_unitcube(allpoints, triangle)
    points = map(i->allpoints[i],triangle)
    1//6*det(hcat(points...))
end


"""
Return the points and triange faces of the the iso surface with the ends intersecting the bounding box capped off.

Uses hack described here.
https://discourse.julialang.org/t/visualizing-a-3d-volume-in-makie-lighting-smoothness/35263/7?u=dalarev
"""
function isocap(f; widths=SVector(1.0,1.0,1.0), origin=SVector(0.0,0.0,0.0), samples = SVector(20,20,20), largeval = 1E10, eps=1E-3)
    Δ = widths ./ (samples .- 1)
    newo = origin - Δ
    neww = widths + 2Δ
    news = samples .+ 2
    xr,yr,zr = ntuple(i->LinRange(newo[i],newo[i] + neww[i], news[i]),3)
    sdf = fill(largeval, news[1], news[2], news[3])
    for k in 1:samples[3]
        for j in 1:samples[2]
            for i in 1:samples[1]
                sdf[i+1, j+1, k+1] = f(SA[xr[i+1], yr[j+1], zr[k+1]])
            end
        end
    end
    points, triangles = isosurface(sdf, MarchingTetrahedra(;eps), xr,yr,zr)
    SVector.(points), SVector.(triangles)
end

function old_isosurface(f::Function, alg; origin::SVector{3}, widths::SVector{3}, samples::SVector{3,<:Integer})
    xr,yr,zr = ntuple(i->LinRange(origin[i],origin[i] + widths[i], samples[i]),3)
    sdf = [f(SA[x,y,z]) for x in xr, y in yr, z in zr]
    points, triangles = isosurface(sdf, alg, xr, yr, zr)
    SVector.(points), SVector.(triangles)
end
