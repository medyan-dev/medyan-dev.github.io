"""
Functions for calculating the force between two cylinders.
"""

using LinearAlgebra
using StaticArrays

function cylinder_repulsion1(P0,P1,Q0,Q1,k,L0P,L0Q)
    krepscaled = k*L0P*L0Q
    P = P1 - P0
    Q = Q1 - Q0
    P0mQ0 = P0 - Q0
    Q1mP0 = Q1 - P0
    P1mQ0 = P1 - Q0
    a = P ⋅ P
    b = Q ⋅ Q
    c = P0mQ0 ⋅ P0mQ0
    d = P ⋅ Q
    e = P ⋅ P0mQ0
    f = Q ⋅ P0mQ0
    g = P ⋅ Q1mP0
    h = Q ⋅ P1mQ0
    i = Q ⋅ Q1mP0
    sqmag_D = Q1mP0 ⋅ Q1mP0
    sqmag_E = P1mQ0 ⋅ P1mQ0
    vec_A = P0 - P1
    vec_B = Q0 - Q1
    vec_C = Q0 - P0
    
    ac = sqrt(a*c)
    bc = sqrt(b*c)
    aD = sqrt(a*sqmag_D)
    bE = sqrt(b*sqmag_E)

    AA = sqrt(max(0,(ac+e)*(ac-e)))
    BB = sqrt(max(0,(bc+f)*(bc-f)))

    CC = d*e - a*f
    DD = b*e - d*f

    EE = sqrt(max(0,(aD+g)*(aD-g)))
    FF = sqrt(max(0,(bE+h)*(bE-h)))

    GG = d*g - a*i
    HH = CC + GG - DD
    JJ = -(cross(vec_A,vec_B) ⋅ vec_C)^2
    ATG1 = atan( (a + e)/AA) - atan(e/AA)
    ATG2 = atan((a + e - d)/EE) - atan((e - d)/EE)
    ATG3 = atan((f)/BB) - atan((f - b)/BB)
    ATG4 = atan((d + f)/FF) - atan((d + f - b)/FF)
    U_i = (1//2) * krepscaled / JJ * ( CC/AA*ATG1 + GG/EE*ATG2 + DD/BB*ATG3 + HH/FF*ATG4)
    return U_i
end

function cylinder_repulsion2(P0,P1,Q0,Q1,k,r)
    Ps = LinRange(P0,P1,20)
    Qs = LinRange(Q0,Q1,20)
    E = 0
    for P in Ps, Q in Qs
        d = norm(P-Q)
        E += max(0,r^2 - d^2)
    end
    return 1//2*k*E
end

function cylinder_repulsion3(P0,P1,Q0,Q1,k,r)
    Ps = LinRange(P0,P1,20)
    Qs = LinRange(Q0,Q1,20)
    E = 0
    for P in Ps, Q in Qs
        d = norm(P-Q)
        E += max(0,r - d)^2
    end
    return 1//2*k*E
end

function cylinder_repulsion4(P0,P1,Q0,Q1,k,r)
    Ps = LinRange(P0,P1,20)
    Qs = LinRange(Q0,Q1,20)
    E = 0
    for P in Ps, Q in Qs
        d = norm(P-Q)
        E += max(0,r - d)
    end
    return 1//2*k*E
end

function cylinder_repulsion5(P0,P1,Q0,Q1,k,radius,s)
    P = P1-P0
    Q = Q1-Q0
    P0mQ0 = P0 - Q0
    a = P ⋅ P
    b = P ⋅ Q
    c = Q ⋅ Q
    d = P ⋅ P0mQ0
    e = Q ⋅ P0mQ0
    f = P0mQ0 ⋅ P0mQ0
    Δ = a*c - b^2
    #assuming both segments are not zero length
    #critical points
    s0 = clamp(-d/a,0,1)
    s1 = clamp((b-d)/a,0,1)
    t0 = clamp(e/c,0,1)
    t1 = clamp((b+e)/c,0,1)
    sbar = clamp((b*e - c*d)/(Δ+eps(one(Δ))),0,1)
    tbar = clamp((a*e - b*d)/(Δ+eps(one(Δ))),0,1)
    r(s,t) = a*s^2 - 2b*s*t + c*t^2 + 2d*s - 2e*t
    cl = max(0,f+min(
        r(s0,0),
        r(s1,1),
        r(0,t0),
        r(1,t1),
        r(sbar,tbar),
    ))
    switchover = tanh(Δ*s)
    u(distsq) = 1//2*k*max(0,-sqrt(distsq) + radius)^2
    E = switchover*u(cl) + 1//2*(1-switchover)*sum(u,(
        f+r(s0,0),
        f+r(s1,1),
        f+r(0,t0),
        f+r(1,t1),
    ))
    return E
end


function cylinder_repulsion6(P0,P1,Q0,Q1,k,radius,s)
    P = P1-P0
    Q = Q1-Q0
    P0mQ0 = P0 - Q0
    a = P ⋅ P
    b = P ⋅ Q
    c = Q ⋅ Q
    d = P ⋅ P0mQ0
    e = Q ⋅ P0mQ0
    f = P0mQ0 ⋅ P0mQ0
    Δ = a*c - b^2
    #assuming both segments are not zero length
    #critical points
    s0 = clamp(-d/a,0,1)
    s1 = clamp((b-d)/a,0,1)
    t0 = clamp(e/c,0,1)
    t1 = clamp((b+e)/c,0,1)
    sbar = clamp((b*e - c*d)/(Δ+eps(one(Δ))),0,1)
    tbar = clamp((a*e - b*d)/(Δ+eps(one(Δ))),0,1)
    r(s,t) = a*s^2 - 2b*s*t + c*t^2 + 2d*s - 2e*t
    cl = max(0,f+min(
        r(s0,0),
        r(s1,1),
        r(0,t0),
        r(1,t1),
        r(sbar,tbar),
    ))
    switchover = tanh(Δ*s)
    u(distsq) = 1//2*k*max(0,-sqrt(max(0,distsq)) + radius)^2
    E = switchover*u(f+r(sbar,tbar)) + sum(u,(
        f+r(s0,0),
        f+r(s1,1),
        f+r(0,t0),
        f+r(1,t1),
    ))
    return E
end

function cylinder_repulsion7(P0,P1,Q0,Q1,k,radius,s)
    P = P1-P0
    Q = Q1-Q0
    P0mQ0 = P0 - Q0
    a = P ⋅ P
    b = P ⋅ Q
    c = Q ⋅ Q
    d = P ⋅ P0mQ0
    e = Q ⋅ P0mQ0
    f = P0mQ0 ⋅ P0mQ0
    Δ = a*c - b^2
    #assuming both segments are not zero length
    #critical points
    s0 = clamp(-d/a,0,1)
    s1 = clamp((b-d)/a,0,1)
    t0 = clamp(e/c,0,1)
    t1 = clamp((b+e)/c,0,1)
    sbar = clamp((b*e - c*d)/(Δ+eps(one(Δ))),0,1)
    tbar = clamp((a*e - b*d)/(Δ+eps(one(Δ))),0,1)
    r(s,t) = a*s^2 - 2b*s*t + c*t^2 + 2d*s - 2e*t
    cl = max(0,f+min(
        r(s0,0),
        r(s1,1),
        r(0,t0),
        r(1,t1),
        r(sbar,tbar),
    ))
    switchover = tanh(Δ*s)
    function u(distsq)
        dist = sqrt(max(0,distsq))
        σ = radius*2^(-1/6)
        if dist < radius
            4k*((σ/dist)^12 - (σ/dist)^6) + k
        else
            zero(dist)
        end
    end
    E = switchover*u(f+r(sbar,tbar)) + sum(u,(
        f+r(s0,0),
        f+r(s1,1),
        f+r(0,t0),
        f+r(1,t1),
    ))
    return E
end


function cylinder_repulsion8(P0,P1,Q0,Q1,kr)
    P = P1-P0
    Q = Q1-Q0
    P0mQ0 = P0 - Q0
    a = P ⋅ P
    b = P ⋅ Q
    c = Q ⋅ Q
    d = P ⋅ P0mQ0
    e = Q ⋅ P0mQ0
    f = P0mQ0 ⋅ P0mQ0
    Δ = a*c - b^2
    #assuming both segments are not zero length
    #critical points
    s0 = clamp(-d/a,0,1)
    s1 = clamp((b-d)/a,0,1)
    t0 = clamp(e/c,0,1)
    t1 = clamp((b+e)/c,0,1)
    sbar = clamp((b*e - c*d)/(Δ+eps(one(Δ))),0,1)
    tbar = clamp((a*e - b*d)/(Δ+eps(one(Δ))),0,1)
    r(s,t) = a*s^2 - 2b*s*t + c*t^2 + 2d*s - 2e*t
    cl = max(0,f+min(
        r(s0,0),
        r(s1,1),
        r(0,t0),
        r(1,t1),
        r(sbar,tbar),
    ))
    u(distsq) = 1//2*max(0,1-sqrt(distsq)*kr)^2
    E = u(cl)
    return E
end

"Like 8 but with switchover"
function cylinder_repulsion9(P0,P1,Q0,Q1,kr)
    P = P1-P0
    Q = Q1-Q0
    P0mQ0 = P0 - Q0
    a = P ⋅ P
    b = P ⋅ Q
    c = Q ⋅ Q
    d = P ⋅ P0mQ0
    e = Q ⋅ P0mQ0
    f = P0mQ0 ⋅ P0mQ0
    Δ = a*c - b^2
    #assuming both segments are not zero length
    #critical points
    s0 = clamp(-d/a,0,1)
    s1 = clamp((b-d)/a,0,1)
    t0 = clamp(e/c,0,1)
    t1 = clamp((b+e)/c,0,1)
    sbar = clamp((b*e - c*d)/(Δ+eps(one(Δ))),0,1)
    tbar = clamp((a*e - b*d)/(Δ+eps(one(Δ))),0,1)
    r(s,t) = a*s^2 - 2b*s*t + c*t^2 + 2d*s - 2e*t
    cl = max(0,f+min(
        r(s0,0),
        r(s1,1),
        r(0,t0),
        r(1,t1),
        r(sbar,tbar),
    ))
    switchover = tanh(Δ/sqrt(a*c)*(0.1f0))
    u(distsq) = 1//2*max(0,1-sqrt(distsq)*kr)^2
    E = switchover*u(cl) + 1//2*(1-switchover)*sum(u,(
        f+r(s0,0),
        f+r(s1,1),
        f+r(0,t0),
        f+r(1,t1),
    ))
    return E
end