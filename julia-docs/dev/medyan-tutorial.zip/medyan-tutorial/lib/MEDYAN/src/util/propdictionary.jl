using Dictionaries
import StructTypes

# Dictionaries compatible (mostly) version of PropDicts.jl

struct PropDictionary <: AbstractDictionary{Symbol,Any}
    d::Dictionary{Symbol,Any}
    k::Vector{Symbol}

    PropDictionary() = new(Dictionary{Symbol,Any}(),[])
    function PropDictionary(x...;y...)
        d = Dictionary{Symbol,Any}(x...;y...)
        new(d,collect(keys(d)))
    end
end

StructTypes.StructType(::Type{PropDictionary}) = StructTypes.DictType()

prop_dictionary(pairs) = PropDictionary(dictionary(pairs))

unwrap(d::PropDictionary) = getfield(d, :d)

_keys(d::PropDictionary) = getfield(d, :k)

function Base.show(io::IO, d::PropDictionary)
    print(io,"MEDYAN.prop_dictionary(")
    print(io,"$(collect(pairs(d)))")
    print(io,")")
end

Base.getproperty(d::PropDictionary, n::Symbol) = getindex(d, n)

Base.setproperty!(d::PropDictionary, n::Symbol, x) = setindex!(d, x, n)

Base.propertynames(d::PropDictionary, private::Bool=false) = _keys(d)

# AbstractDictionary interface

Base.getindex(d::PropDictionary, n::Symbol) = getindex(unwrap(d), n)

Base.getindex(d::PropDictionary, n::Integer) = getindex(unwrap(d), _keys(d)[n])

Base.keys(d::PropDictionary) = keys(unwrap(d))

Base.isassigned(d::PropDictionary, n::Symbol) = isassigned(unwrap(d), n)

Dictionaries.issettable(::PropDictionary) = true

function Base.setindex!(d::PropDictionary, x, n::Symbol)
    setindex!(unwrap(d), x, n)
    d
end

Dictionaries.isinsertable(::PropDictionary) = true

function Base.insert!(d::PropDictionary, n::Symbol, x)
    insert!(unwrap(d), n, x)
    push!(_keys(d),n)
    d
end

function Base.delete!(d::PropDictionary, n::Symbol)
    delete!(unwrap(d), n)
    id = findfirst(isequal(n), _keys(d))
    deleteat!(_keys(d),id)
    d
end

Dictionaries.istokenizable(::PropDictionary) = true

Dictionaries.gettokenvalue(d::PropDictionary, token) = gettokenvalue(unwrap(d), token)

Dictionaries.istokenassigned(d::PropDictionary, token) = istokenassigned(unwrap(d), token)

function Dictionaries.settokenvalue!(d::PropDictionary, token, x)
    settokenvalue!(unwrap(d), token, x)
    d
end

Dictionaries.gettoken!(d::PropDictionary, i::Symbol) = gettoken!(unwrap(d), i)

Base.similar(d::PropDictionary, ::Type) = deepcopy(d)

Base.similar(d::PropDictionary) =  deepcopy(d)
