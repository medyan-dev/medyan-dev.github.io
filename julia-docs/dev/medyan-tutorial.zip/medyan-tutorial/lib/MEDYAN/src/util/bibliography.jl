using FileIO, Bibliography

const citations_all_bibtex = """
@article{bashkirov2022molecular,
    title={Molecular shape solution for mesoscopic remodeling of cellular membranes},
    author={Bashkirov, Pavel V and Kuzmin, Peter I and Vera Lillo, Javier and Frolov, Vadim A},
    journal={Annual review of biophysics},
    volume={51},
    pages={473--497},
    year={2022},
    publisher={Annual Reviews}
}

@article{ni2021membrane,
    title={Membrane-medyan: Simulating deformable vesicles containing complex cytoskeletal networks},
    author={Ni, Haoran and Papoian, Garegin A},
    journal={The Journal of Physical Chemistry B},
    volume={125},
    number={38},
    pages={10710--10719},
    year={2021},
    publisher={ACS Publications}
}

@article{popov2016medyan,
    title={MEDYAN: mechanochemical simulations of contraction and polarity alignment in actomyosin networks},
    author={Popov, Konstantin and Komianos, James and Papoian, Garegin A},
    journal={PLoS computational biology},
    volume={12},
    number={4},
    pages={e1004877},
    year={2016},
    publisher={Public Library of Science}
}

@article{Zhu2021.10.30.466618,
    author = {Zhu, C. and Lee, C. T. and Rangamani, P.},
    title = {Mem3DG: Modeling Membrane Mechanochemical Dynamics in 3D using Discrete Differential Geometry},
    elocation-id = {2021.10.30.466618},
    year = {2022},
    doi = {10.1101/2021.10.30.466618},
    publisher = {Cold Spring Harbor Laboratory},
    abstract = {Biomembranes adopt varying morphologies that are vital to cellular functions. Many studies use computational modeling to understand how various mechanochemical factors contribute to membrane shape transformations. Compared to approximation-based methods (e.g., finite element method), the class of discrete mesh models offers greater flexibility to simulate complex physics and shapes in three dimensions; its formulation produces an efficient algorithm while maintaining coordinate-free geometric descriptions. However, ambiguities in geometric definitions in the discrete context have led to a lack of consensus on which discrete mesh model is theoretically and numerically optimal; a bijective relationship between the terms contributing to both the energy and forces from the discrete and smooth geometric theories remains to be established. We address this and present an extensible framework, Mem3DG, for modeling 3D mechanochemical dynamics of membranes based on Discrete Differential Geometry (DDG) on triangulated meshes. The formalism of DDG resolves the inconsistency and provides a unifying perspective on how to relate the smooth and discrete energy and forces. To demonstrate, Mem3DG is used to model a sequence of examples with increasing mechanochemical complexity: recovering classical shape transformations such as 1) biconcave disk, dumb-bell, and unduloid and 2) spherical bud on spherical, flat-patch membrane; investigating how the coupling of membrane mechanics with protein mobility jointly affects phase and shape transformation. As high-resolution 3D imaging of membrane ultrastructure becomes more readily available, we envision Mem3DG to be applied as an end-to-end tool to simulate realistic cell geometry under user-specified mechanochemical conditions.Why it matters Cellular membranes have shapes and shape changes which characterize cells/organelles, and support nutrient trafficking among other critical processes. Modeling membrane shape changes using mechanical principles can provide insight into how cells robustly bend membranes to support life. Mathematical and computational strategies to solve the equations describing membrane shape evolution can be complex and challenging without simplifying assumptions. Here, we present a new, general, numerical approach to model arbitrary 3D membrane shapes in response to interaction with curvature sensing and generating membrane proteins. The accompanying implementation, Mem3DG, is a software tool to make computational membrane mechanics accessible to the general researcher.HighlightsIntroduces a discrete theory for membrane mechanics which connects with smooth theoryDiscrete energy/force are functions of basic geometric quantitiesRecipes for extending the discrete framework with additional physics are providedDescribes a user-friendly software implementation called Mem3DGMem3DG is designed to facilitate modeling in tandem with experimental studiesSignificance and novelty Helfrich Hamiltonian is widely used to model biomembranes. Many numerical methods have been developed to solve the geometric PDE. Compared to approximation-based methods, discrete-mesh-based models have many advantages when incorporating multiphysics in 3D due to their flexibility, efficiency, and straightforward implementation. However, there is no consensus on which mesh-based model is optimal, and a connection between the discrete and smooth geometric theory remains obscure. In this work, we provide a unifying perspective by identifying fundamental geometric invariants of the discrete force derived from a discrete energy. As a demonstration of generality of the framework to various physics, we follow a formulaic procedure to derive additional physics such as interfacial line tension, surface-bulk adsorption, protein lateral diffusion, and curvature-dependent protein aggregation.Competing Interest StatementThe authors have declared no competing interest.},
    URL = {https://www.biorxiv.org/content/early/2022/03/17/2021.10.30.466618},
    eprint = {https://www.biorxiv.org/content/early/2022/03/17/2021.10.30.466618.full.pdf},
    journal = {bioRxiv}
}
""" |> IOBuffer |> FileIO.Stream{format"BIB"} |> load


"""
    gen_citation(C::Context; ...)

Given a context, generate the citations from used components.

Keyword arguments:
- bibtex_file: If specified, will also save to this file using bibtex format.
"""
function gen_citation(c; bibtex_file::Union{Nothing,AbstractString}=nothing)
    res = similar(citations_all_bibtex)
    push!(res, "popov2016medyan" => citations_all_bibtex["popov2016medyan"])

    if !isempty(c.membranes)
        push!(res, "ni2021membrane" => citations_all_bibtex["ni2021membrane"])

        if c.sharedtypedconfigs.meshcurv == Val(meshcurv_mem3dg)
            push!(res, "Zhu2021.10.30.466618" => citations_all_bibtex["Zhu2021.10.30.466618"])
        end
        if c.sharedtypedconfigs.bending_mode == Val(:bashkirov)
            push!(res, "bashkirov2022molecular" => citations_all_bibtex["bashkirov2022molecular"])
        end
    end

    if !isnothing(bibtex_file)
        save(FileIO.File{format"BIB"}(bibtex_file), res)
    end

    res
end
export gen_citation
