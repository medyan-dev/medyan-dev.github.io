using ArgCheck: @argcheck

abstract type Place end
null_place(x::Place) = null_place(typeof(x))
is_null(x::Place) = x == null_place(x)

# slots with this generation are empty and used up.
const MAXGENERATION = typemax(UInt32) - UInt32(1)


@kwdef struct TagManager{P<:Place}
    place2idx::Dict{P,UInt32} = Dict{P,UInt32}()
    idx2place::Vector{P} = P[]
    idx2refcount::Vector{UInt32} = UInt32[]
    idx2generation::Vector{UInt32} = UInt32[]
    free_idxs::Vector{UInt32} = UInt32[]
end

function Base.empty!(t::TagManager)
    empty!(t.place2idx)
    empty!(t.free_idxs)
    empty!(t.idx2generation)
    empty!(t.idx2place)
    empty!(t.idx2refcount)
    t
end
function Base.isempty(t::TagManager)
    isempty(t.idx2place)
end

function assert_invariants(t::TagManager{P}) where {P}
    n = length(t.idx2place)
    @argcheck n == length(t.idx2generation)
    @argcheck n == length(t.idx2refcount)
    n_existing = length(keys(t.place2idx))
    acc_n = 0
    acc_free_n = 0
    @argcheck !haskey(t.place2idx, null_place(P))
    for i in 1:n
        p = t.idx2place[i]
        g = t.idx2generation[i]
        @argcheck g ≤ MAXGENERATION
        rc = t.idx2refcount[i]
        if isodd(g)
            acc_n += 1
            @argcheck t.place2idx[p] == i
            @argcheck !is_null(p)
            @argcheck !iszero(rc)
            @argcheck i ∉ t.free_idxs
        else
            @argcheck is_null(p)
            @argcheck iszero(rc)
            if g != MAXGENERATION
                @argcheck i ∈ t.free_idxs
                acc_free_n += 1
            end
        end
    end
    @argcheck acc_free_n == length(t.free_idxs)
    @argcheck acc_n == n_existing
    t
end

"""
Check if two `TagManager` are statistically equal, the internal free lists may be different
"""
function statistically_equal(a::TagManager{P}, b::TagManager{P}) where {P}
    assert_invariants(a)
    assert_invariants(b)
    a.idx2generation == b.idx2generation || return false
    a.idx2place == b.idx2place || return false
    a.idx2refcount == b.idx2refcount || return false
    return true
end

struct Tag{P<:Place}
    idx::UInt32
    generation::UInt32
end

function _try_get_idx(t::TagManager{P}, id::Tag{P})::Union{UInt32,Nothing} where {P}
    idx = id.idx
    idx ∈ eachindex(t.idx2generation) || return nothing
    generation = t.idx2generation[idx]
    isodd(generation) || return nothing
    generation == id.generation || return nothing
    idx
end
function _get_idx(t::TagManager{P}, id::Tag{P})::UInt32 where {P}
    something(_try_get_idx(t, id))
end

function _get_place(t::TagManager{P}, id::Tag{P})::P where {P}
    idx = _get_idx(t, id)
    t.idx2place[idx]
end

function _tag!(t::TagManager{P}, place::P)::Tag{P} where {P}
    local idx::UInt32
    local generation::UInt32
    if !haskey(t.place2idx, place)
        if isempty(t.free_idxs)
            push!(t.idx2place, place)
            idx = length(t.idx2place)
            t.place2idx[place] = idx
            push!(t.idx2generation, UInt32(1))
            generation = UInt32(1)
            push!(t.idx2refcount, UInt32(1))
            @assert length(t.idx2generation) == idx
            @assert length(t.idx2refcount) == idx
        else
            idx = pop!(t.free_idxs)
            t.place2idx[place] = idx
            t.idx2place[idx] = place
            t.idx2generation[idx] += UInt32(1)
            generation = t.idx2generation[idx]
            @assert t.idx2refcount[idx] == 0
            t.idx2refcount[idx] = UInt32(1)
        end
    else
        idx = t.place2idx[place]
        r = t.idx2refcount[idx]
        t.idx2refcount[idx] = Base.checked_add(r, UInt32(1))
        generation = t.idx2generation[idx]
    end
    @assert isodd(generation)
    Tag{P}(idx, generation)
end

# function _ref_tag!(t::TagManager{P}, id::Tag{P}) where {P}
#     idx = _get_idx(t, id)
#     r = t.idx2refcount[idx]
#     t.idx2refcount[idx] = Base.checked_add(r, UInt32(1))
#     t
# end

# function _untag!(t::TagManager{P}, id::Tag{P}) where {P}
#     idx = @something _try_get_idx(t, id) return t
#     r = t.idx2refcount[idx]
#     t.idx2refcount[idx] = Base.checked_sub(r, UInt32(1))
#     if iszero(t.idx2refcount[idx])
#         g = t.idx2generation[idx]
#         g += UInt32(1)
#         @assert iseven(g)
#         # typemax(UInt32) - UInt32(1) is unusable
#         if g != typemax(UInt32) - UInt32(1)
#             push!(t.free_idxs, idx)
#         end
#         place = t.idx2place[idx]
#         t.idx2place[idx] = null_place(t.idx2place[idx])
#         delete!(t.place2idx, place)
#     end
#     t
# end

function _remove_place!(t::TagManager{P}, place::P) where {P}
    if haskey(t.place2idx, place)
        idx = t.place2idx[place]
        @assert t.idx2place[idx] == place
        t.idx2place[idx] = null_place(P)
        delete!(t.place2idx, place)
        t.idx2refcount[idx] = UInt32(0)
        g = t.idx2generation[idx]
        g += UInt32(1)
        t.idx2generation[idx] = g
        @assert iseven(g)
        # typemax(UInt32) - UInt32(1) is unusable
        if g != typemax(UInt32) - UInt32(1)
            push!(t.free_idxs, idx)
        end
    end
    t
end

function _move_place!(t::TagManager{P}, oldplace::P, newplace::P) where {P}
    if haskey(t.place2idx, oldplace)
        idx = t.place2idx[oldplace]
        @assert t.idx2place[idx] == oldplace
        @argcheck !haskey(t.place2idx, newplace)
        t.idx2place[idx] = newplace
        delete!(t.place2idx, oldplace)
        t.place2idx[newplace] = idx
    end
    t
end
