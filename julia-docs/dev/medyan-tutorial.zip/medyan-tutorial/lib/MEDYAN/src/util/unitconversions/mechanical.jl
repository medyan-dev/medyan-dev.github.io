# Mechanics unit conversion functions and constants.

const kboltzmann = 1.380649E-2 # pN*nm/K
const default_temperature = 310.0 # K
const default_β = 1/(kboltzmann*default_temperature)

"""
Return bending force constant from Young’s modulus*geometric moment and monomer spacing.

-`EI` (pN*nm²)
-`spacing`(nm)
- return (pN*nm/rad²)
"""
EI_spacing_to_k∠(EI,spacing) = EI/spacing

"""
Return Young’s modulus*geometric moment from bending force constant and monomer spacing.

-`k∠` (pN*nm/rad²)
-`spacing`(nm)
- return (pN*nm²)
"""
k∠_spacing_to_EI(k∠,spacing) = k∠*spacing

"""
Return Young’s modulus*geometric moment from persistence length and β AKA 1/kT.

-`lp` (nm)
-`β` (1/(pN*nm))
- return (pN*nm²)
"""
lp_β_to_EI(lp,β=default_β) = lp/β

"""
Return persistence length from Young’s modulus*geometric moment and β AKA 1/kT.

-`EI` (pN*nm²)
-`β` (1/(pN*nm))
- return (nm)
"""
EI_β_to_lp(EI,β=default_β) = EI*β
