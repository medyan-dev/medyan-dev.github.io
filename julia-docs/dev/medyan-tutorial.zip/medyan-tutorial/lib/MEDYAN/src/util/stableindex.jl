"""
A structure used to map IDs that are stable, to indices that are volatile.
"""
struct StableIndex
    "Map IDs to 1-based indices. 0 indicates unused indices."
    indices::Vector{Int}
    "Unused IDs."
    unused_ids::Vector{Int}
end

function StableIndex()
    StableIndex(Vector{Int}(), Vector{Int}())
end

"""
Whether an ID is in use.
"""
function Base.haskey(si::StableIndex, id::Integer)
    id ∈ eachindex(si.indices) && si.indices[id] > 0
end

"""
Total number of IDs in use.
"""
function Base.length(si::StableIndex)
    length(si.indices) - length(si.unused_ids)
end

function Base.isempty(si::StableIndex)
    length(si) == 0
end

"""
Get index at ID.
"""
function Base.getindex(si::StableIndex, id::Integer)
    si.indices[id]
end

"""
Map ID to a new index.
The ID must be in use.
"""
function Base.setindex!(si::StableIndex, newindex::Integer, id::Integer)
    @boundscheck begin
        if !haskey(si, id)
            throw(KeyError(id))
        end
    end
    si.indices[id] = newindex
end

function Base.sizehint!(si::StableIndex, sz::Integer)
    sizehint!(si.indices, sz)
end


"""
Add a new index. Returns its ID.
"""
function Base.push!(si::StableIndex, index::Integer)
    if isempty(si.unused_ids)
        push!(si.indices, index)
        return length(si.indices)
    else
        id = last(si.unused_ids)
        pop!(si.unused_ids)
        si.indices[id] = index
        return id
    end
end

"""
Remove a recorded index at ID.
"""
function Base.delete!(si::StableIndex, id::Integer)
    @boundscheck begin
        if !haskey(si, id)
            throw(KeyError(id))
        end
    end
    si.indices[id] = 0
    push!(si.unused_ids, id)
end

"""
Clear all index records.
"""
function Base.empty!(si::StableIndex)
    empty!(si.indices)
    empty!(si.unused_ids)
end

"""
Iterates through valid IDs in the StableIndex.
"""
function Base.iterate(si::StableIndex, state::NamedTuple)
    nextid::Int = state.curid + 1
    while nextid <= length(si.indices) && si.indices[nextid] == 0
        nextid += 1
    end
    if nextid <= length(si.indices)
        (nextid => si.indices[nextid], (; curid = nextid))
    else
        nothing
    end
end
function Base.iterate(si::StableIndex)
    iterate(si, (; curid=0))
end
