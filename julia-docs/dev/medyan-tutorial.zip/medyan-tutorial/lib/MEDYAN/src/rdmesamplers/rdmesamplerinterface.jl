"""
A general RDME sampler interface
"""

using StaticArrays
using Distributions
using FixedPointNumbers
using AutoHashEquals
import Base.show

"""
$(TYPEDFIELDS)
"""
@auto_hash_equals struct BulkReaction
    reactants::Vector{NamedTuple{(:id, :amount), Tuple{Int, Int}}}
    net_stoich::Vector{NamedTuple{(:id, :amount), Tuple{Int, Int}}}
    rate::Float64
end

function propensity(reaction::BulkReaction, count)
    nways= 1.0
    for reactant in reaction.reactants
        @inbounds n= count[reactant.id]
        a= reactant.amount
        if a==1
            nways*= n
        elseif a==2
            nways*= (n*(n-1))/2
        elseif a==3
            nways*= (n*(n-1)*(n-2))/6
        else
            error("too many reactant copies")
        end
    end
    return nways*reaction.rate
end

"""
$(TYPEDFIELDS)
"""
@auto_hash_equals struct CompartmentReaction
    #set to zero if no diffusing reactant is needed
    diffusingreactants::Tuple{Int, Int}
    diffusingnet_stoich::Vector{NamedTuple{(:id, :amount), Tuple{Int, Int}}}
    fixedreactants::Vector{NamedTuple{(:id, :amount), Tuple{Int, Int}}}
    fixednet_stoich::Vector{NamedTuple{(:id, :amount), Tuple{Int, Int}}}
    bulkreactants::Vector{NamedTuple{(:id, :amount), Tuple{Int, Int}}}
    bulknet_stoich::Vector{NamedTuple{(:id, :amount), Tuple{Int, Int}}}
    rate::Float64

    "Power to raise inverse volume to when calculating rates"
    invvolumepower::Int
end

function Base.show(io::IO, s::CompartmentReaction)
    print(io, "$(typeof(s))($(s.diffusingreactants), ")
    print(io, "[")
    for r in s.diffusingnet_stoich
        print(io, "(id=$(r.id), amount=$(r.amount)),")
    end
    print(io, "], ")
    print(io, "[")
    for r in s.fixedreactants
        print(io, "(id=$(r.id), amount=$(r.amount)),")
    end
    print(io, "], ")
    print(io, "[")
    for r in s.fixednet_stoich
        print(io, "(id=$(r.id), amount=$(r.amount)),")
    end
    print(io, "], ")
    print(io, "[")
    for r in s.bulkreactants
        print(io, "(id=$(r.id), amount=$(r.amount)),")
    end
    print(io, "], ")
    print(io, "[")
    for r in s.bulknet_stoich
        print(io, "(id=$(r.id), amount=$(r.amount)),")
    end
    print(io, "], ")
    print(io, "$(s.rate), $(s.invvolumepower))")
end

"""
Return 0.0 if invvolume isn't finite
"""
function propensity(reaction::CompartmentReaction, diffusingcount, fixedcount, bulkcount, invvolume)
    isfinite(invvolume) || return 0.0
    nways= 1.0
    dr1, dr2 = reaction.diffusingreactants
    if !iszero(dr1)
        nways*= diffusingcount[dr1]
        if !iszero(dr2)
            if(dr1 != dr2)
                nways*= diffusingcount[dr2]
            else
                nways*= (diffusingcount[dr1]-1)
                nways/=2
            end
        end
    end
    for reactant in reaction.fixedreactants
        @inbounds n= fixedcount[reactant.id]
        a= reactant.amount
        if a==1
            nways*= n
        elseif a==2
            nways*= (n*(n-1))/2
        elseif a==3
            nways*= (n*(n-1)*(n-2))/6
        else
            error("too many reactant copies")
        end
    end
    for reactant in reaction.bulkreactants
        @inbounds n= bulkcount[reactant.id]
        a= reactant.amount
        if a==1
            nways*= n
        elseif a==2
            nways*= (n*(n-1))/2
        elseif a==3
            nways*= (n*(n-1)*(n-2))/6
        else
            error("too many reactant copies")
        end
    end
    return nways*reaction.rate*(invvolume^(reaction.invvolumepower))
end

abstract type RDMESampler{NumDiffusingSpecies,NumFixedSpecies} end
#Things to impliment
#contruct empty sampler

#compartment setters

#addcompartments! x
#setinvvolume! x
#setdiffusionrate!
#setneighbor!
#setdiffusingspeciescount!
#adddiffusingspeciescount!
#incdiffusingspeciescount!
#decdiffusingspeciescount!
#setfixedspeciescount!

#bulkspecies setters

#addbulkspecies!
#setbulkspeciescount! x
#addbulkspeciescount!

#reaction setters

#addbulkreaction!
#removebulkreaction!
#replacebulkreaction!
#addcompartmentreaction! x
#removecompartmentreaction! x
#replacecompartmentreaction! x

#main operation

#makestep! 

function getnumdiffusingspecies(s::RDMESampler{NDS,NCS}) where {NDS,NCS}
    return NDS
end

function getnumfixedspecies(s::RDMESampler{NDS,NCS}) where {NDS,NCS}
    return NCS
end

function addfixedspeciescount!(s::RDMESampler,sid,cid,inccount)
    newcount= s.fixedcounts[sid,cid] + eltype(s.fixedcounts)(inccount)
    setfixedspeciescount!(s,sid,cid,newcount)
end

"""
add empty compartments from grid and mobilitydata
"""
function addgrid!(s::RDMESampler,grid,diffusioncoeff)
    @assert s.numcompartments==0
    nds= length(diffusioncoeff)
    @assert nds==getnumdiffusingspecies(s)
    nc = length(grid)
    #add empty compartments
    addcompartments!(s,nc,1.0)
    #set diffusion rates, invvolumes, neighbors
    for cid in 1:nc
        invv= invvolume(grid,cid)
        setinvvolume!(s,cid,invv)
        for side in 1:6
            a= area(grid,cid,side)
            invd= invdistance(grid,cid,side)
            setneighbor!(s,side,cid,adjacentgridid(grid,cid,side))
            for dsid in 1:nds
                m= diffusioncoeff[dsid]
                rate= m*a*invv*invd
                setdiffusionrate!(s,side,dsid,cid,rate)
            end
        end
    end
end

"""
$(TYPEDFIELDS)
"""
Base.@kwdef struct ReactionInfo
    reactiontype::Symbol = :none
    reactionid::Int32 = 0
    diffusingspeciesid::Int32 = 0
    side::Int32 = 0
    compartmentid::Int32 = 0
end

"""
do a diffusion reaction return the reaction info
"""
function dodiffusionreaction!(s::RDMESampler,side,dsid,cid)::ReactionInfo
    #just move stuff
    destid= s.neighbors[side,cid]
    decdiffusingspeciescount!(s,dsid,cid)
    incdiffusingspeciescount!(s,dsid,destid)
    ReactionInfo(reactiontype= :diffusion,
        diffusingspeciesid=dsid,
        side= side,
        compartmentid=cid)
end

"""
do a bulk reaction return the reaction info
"""
function dobulkreaction!(s::RDMESampler,brid)::ReactionInfo
    reaction= s.bulkreactions[brid]
    for net in reaction.net_stoich
        addbulkspeciescount!(s,net.id,net.amount)
    end
    ReactionInfo(reactiontype= :bulk, reactionid= brid)
end

"""
do a compartment reaction return the reaction info
"""
function docompartmentreaction!(s::RDMESampler,crid,cid)::ReactionInfo
    reaction = s.compartmentreactions[crid]
    for net in reaction.diffusingnet_stoich
        adddiffusingspeciescount!(s,net.id,cid,net.amount)
    end
    for net in reaction.fixednet_stoich
        addfixedspeciescount!(s,net.id,cid,net.amount)
    end
    for net in reaction.bulknet_stoich
        addbulkspeciescount!(s,net.id,net.amount)
    end
    ReactionInfo(reactiontype= :compartment, reactionid= crid, compartmentid= cid)
end

function Base.show(io::IO, s::RDMESampler)
    print(io, "$(typeof(s))")
    if !get(io, :compact, false)
        println(io, " with\n  $(s.numcompartments) compartments")
        println(io, "  $(length(s.bulkcounts)) bulk species")
        println(io, "  $(length(s.bulkreactions)) bulk reactions")
        println(io, "  $(length(s.compartmentreactions)) compartment reactions")
    end
end


abstract type RDMEPropensity{NumDiffusingSpecies,MaxNumSpecies} <: RDMESampler{NumDiffusingSpecies,MaxNumSpecies} end
#Additional things
#gettotal_a
#dorandomreaction!

"""
Return the time taken to do the step, return maxtime if no reactions happened
"""
function makestep!(s::RDMEPropensity, maxtime::Float64=Inf)
    total_a = gettotal_a(s)
    noreaction= (reactionhappened= false, time= maxtime, info= ReactionInfo())
    #no reaction can happen, return maxtime
    if total_a ≤ 0
        return noreaction
    end
    #get time of next reaction
    tau= rand(Exponential())/total_a
    #no reactions
    if tau ≥ maxtime
        return noreaction
    end
    reactioninfo= dorandomreaction!(s)
    return (reactionhappened= true, time= tau, info= reactioninfo)
end

"""
Reference RDME Sampler showing the interface

$(TYPEDFIELDS)
"""
mutable struct RDMEReferenceImpl{NumDiffusingSpecies,NumFixedSpecies} <: RDMEPropensity{NumDiffusingSpecies,NumFixedSpecies}
    numcompartments::Int32

    "Indexed by diffusing species id, compartment id"
    diffusingcounts::Matrix{Int32}

    "Indexed by fixed species id, compartment id"
    fixedcounts::Matrix{Q31f32}

    "The diffusion rates.
    Indexed by side id, species id, compartment id
    side id key:
    1: x+
    2: x-
    3: y+
    4: y-
    5: z+
    6: z-"
    diffusionrates::Array{Q31f32,3}

    "neighboring compartment ids.
    Indexed by side id, compartment id
     0 is no neighbor in that direction"
    neighbors::Matrix{Int32}

    invvolumes::Vector{Float64}

    "Counts of bulk species"
    bulkcounts::Vector{Q31f32}

    "Bulk reactions, indexed by bulk reaction id"
    bulkreactions::Vector{BulkReaction}

    "Compartment reactions, indexed by compartment reaction id"
    compartmentreactions::Vector{CompartmentReaction}
end

"""
create an empty system
"""
function RDMEReferenceImpl{NDS,NCS}() where {NDS,NCS}
    RDMEReferenceImpl{NDS,NCS}(0,zeros(NDS,0),zeros(NCS,0),zeros(6,NDS,0),zeros(6,0),[],[],[],[])
end

#compartment setters

"""
add empty compartments with inverse volume invvolume
"""
function addcompartments!(s::RDMEReferenceImpl, num::Integer, invvolume)
    s.numcompartments+=num
    ncs= getnumfixedspecies(s)
    nds= getnumdiffusingspecies(s)
    s.diffusingcounts= [s.diffusingcounts zeros(eltype(s.diffusingcounts),nds,num)]
    s.fixedcounts= [s.fixedcounts zeros(eltype(s.fixedcounts),ncs,num)]
    s.diffusionrates= cat(s.diffusionrates,zeros(eltype(s.diffusionrates),6,nds,num); dims=3)
    s.neighbors= cat(s.neighbors,zeros(eltype(s.neighbors),6,num); dims=2)
    append!(s.invvolumes,fill(invvolume,num))
end

function setinvvolume!(s::RDMEReferenceImpl,cid,invvolume)
    s.invvolumes[cid]= invvolume
end

function setdiffusionrate!(s::RDMEReferenceImpl,side,dsid,cid,rate)
    s.diffusionrates[side,dsid,cid]= rate
end

function setneighbor!(s::RDMEReferenceImpl,side,cid,neighborcid)
    s.neighbors[side,cid]= neighborcid
end

function setfixedspeciescount!(s::RDMEReferenceImpl,sid,cid,newcount)
    @assert newcount≥0 "counts must be positive"
    s.fixedcounts[sid,cid]= newcount
end

function setdiffusingspeciescount!(s::RDMEReferenceImpl,sid,cid,newcount)
    @assert newcount≥0 "counts must be positive"
    s.diffusingcounts[sid,cid]= newcount
end

function adddiffusingspeciescount!(s::RDMEReferenceImpl,sid,cid,inccount)
    s.diffusingcounts[sid,cid]+= eltype(s.diffusingcounts)(inccount)
    @assert s.diffusingcounts[sid,cid]≥0 "counts must be positive"
end

function incdiffusingspeciescount!(s::RDMEReferenceImpl,sid,cid)
    s.diffusingcounts[sid,cid]+= 1
end

function decdiffusingspeciescount!(s::RDMEReferenceImpl,sid,cid)
    s.diffusingcounts[sid,cid]-= 1
    @assert s.diffusingcounts[sid,cid]≥0 "counts must be positive"
end

function addbulkspecies!(s::RDMEReferenceImpl,initcount)
    @assert initcount≥0 "counts must be positive"
    push!(s.bulkcounts,initcount)
end

function setbulkspeciescount!(s::RDMEReferenceImpl,bsid,newcount)
    @assert newcount≥0 "counts must be positive"
    s.bulkcounts[bsid]= newcount
end

function addbulkspeciescount!(s::RDMEReferenceImpl,bsid,inccount)
    s.bulkcounts[bsid]+= eltype(s.bulkcounts)(inccount)
    @assert s.bulkcounts[bsid]≥0 "counts must be positive"
end

function addbulkreaction!(s::RDMEReferenceImpl,bulkreaction)
    push!(s.bulkreactions,deepcopy(bulkreaction))
end

"""
remove bulk reaction with id brid,
 and changes the last bulk reaction id to brid
"""
function removebulkreaction!(s::RDMEReferenceImpl,brid)
    lastbrid= lastindex(s.bulkreactions)
    if brid == lastbrid
        pop!(s.bulkreactions)
    else
        s.bulkreactions[brid]= s.bulkreactions[end]
        pop!(s.bulkreactions)
    end
end

function replacebulkreaction!(s::RDMEReferenceImpl,brid,newreaction)
    s.bulkreactions[brid] = deepcopy(newreaction)
end

function addcompartmentreaction!(s::RDMEReferenceImpl,reaction)
    push!(s.compartmentreactions,deepcopy(reaction))
end

"""
remove compartment reaction with id crid,
 and changes the last compartment reaction id to crid
"""
function removecompartmentreaction!(s::RDMEReferenceImpl,crid)
    lastcrid= lastindex(s.compartmentreactions)
    if crid == lastcrid
        pop!(s.compartmentreactions)
    else
        s.compartmentreactions[crid]= s.compartmentreactions[end]
        pop!(s.compartmentreactions)
    end
end

function replacecompartmentreaction!(s::RDMEReferenceImpl,crid,newreaction)
    s.compartmentreactions[crid] = deepcopy(newreaction)
end

function gettotal_a(s::RDMEReferenceImpl)
    nds = getnumdiffusingspecies(s)
    nc = s.numcompartments
    diffusion_a = [s.diffusionrates[i,j,k]*s.diffusingcounts[j,k] for i in 1:6, j in 1:nds, k in 1:nc]
    bulk_a = [propensity(r,s.bulkcounts) for r in s.bulkreactions]
    compartment_a =[propensity(cr,s.diffusingcounts[:,cid],s.fixedcounts[:,cid],s.bulkcounts,s.invvolumes[cid]) for cr in s.compartmentreactions, cid in 1:nc]
    sum(diffusion_a) + sum(bulk_a) + sum(compartment_a)
end

function dorandomreaction!(s::RDMEReferenceImpl)
    nds = getnumdiffusingspecies(s)
    nc = s.numcompartments
    diffusion_a = [s.diffusionrates[i,j,k]*s.diffusingcounts[j,k] for i in 1:6, j in 1:nds, k in 1:nc]
    bulk_a = [propensity(r,s.bulkcounts) for r in s.bulkreactions]
    compartment_a =[propensity(cr,s.diffusingcounts[:,cid],s.fixedcounts[:,cid],s.bulkcounts,s.invvolumes[cid]) for cr in s.compartmentreactions, cid in 1:nc]

    a= [reshape(diffusion_a,length(diffusion_a)); reshape(compartment_a,length(compartment_a)); bulk_a]
    total_a= gettotal_a(s)
    p= a./total_a
    reactionidx= rand(Categorical(p))
    if reactionidx ≤ length(diffusion_a)
        cartesian = Tuple(CartesianIndices((1:6, 1:nds, 1:nc))[reactionidx])
        return dodiffusionreaction!(s,cartesian...)
    end
    reactionidx-= length(diffusion_a)
    if reactionidx ≤ length(compartment_a)
        cartesian = Tuple(CartesianIndices((1:length(s.compartmentreactions), 1:nc))[reactionidx])
        return docompartmentreaction!(s,cartesian...)
    end
    reactionidx-= length(compartment_a)
    return dobulkreaction!(s,reactionidx)
end
