"""
A concrete RDMEPropensity with cached propensity that only gets updated when needed
and rejection sampling for diffusion reactions.

$(TYPEDFIELDS)
"""
Base.@kwdef mutable struct RDMEPropensityRejectDiffusion{NumDiffusingSpecies,NumFixedSpecies} <: RDMEPropensity{NumDiffusingSpecies,NumFixedSpecies}
    numcompartments::Int32 = 0

    diffusingcounts::Matrix{Int32} = zeros(NumDiffusingSpecies,0)

    fixedcounts::Matrix{Q31f32} = zeros(NumFixedSpecies,0)

    "The diffusion rates.
    Indexed by side id, species id, compartment id
    side id key:
    1: x+
    2: x-
    3: y+
    4: y-
    5: z+
    6: z-"
    diffusionrates::Array{Q31f32,3} = zeros(6,NumDiffusingSpecies,0)

    "neighboring compartment ids.
    Indexed by side id, compartment id
     0 is no neighbor in that direction"
    neighbors::Matrix{Int32} = zeros(6,0)

    invvolumes::Vector{Float64} = []

    "Counts of bulk species"
    bulkcounts::Vector{Q31f32} = []

    "Bulk reactions, indexed by bulk reaction id"
    bulkreactions::Vector{BulkReaction} = []

    "Compartment reactions, indexed by compartment reaction id"
    compartmentreactions::Vector{CompartmentReaction} = []

    "indexed by species id, compartment id, sum of diffusionrates for all sides"
    totaldiffusion_rates::Matrix{Q31f32} = zeros(NumDiffusingSpecies,0)

    "sum of diffusion_a"
    totaldiffusion_a::Q31f32 = 0

    "sum of diffusion_a along dim 1, indexed by compartment id"
    totalspeciesdiffusion_a::Vector{Q31f32} = []

    max_totalspeciesdiffusion_a::Q31f32 = 0

    "indexed by species id, compartment id"
    diffusion_a::Matrix{Q31f32} = zeros(NumDiffusingSpecies,0)

    "indexed by reaction id, compartment id"
    compartment_a::Matrix{Q31f32} = zeros(0,0)

    "indexed by reaction id"
    bulk_a::Array{Q31f32,1} = zeros(0)

    total_a::Q31f32 = 0

    "species reaction map, index by species to get a vector of dependent reaction ids,
        ie reactions with the species as a reactant"
    bulks_bulkr_map::Vector{Vector{Int32}} = []
    bulks_compartmentr_map::Vector{Vector{Int32}} = []
    diffusings_compartmentr_map::Vector{Vector{Int32}} = [Int32[] for i in 1:NumDiffusingSpecies]
    fixeds_compartmentr_map::Vector{Vector{Int32}} = [Int32[] for i in 1:NumFixedSpecies]

end


#compartment setters

"""
add empty compartments
"""
function addcompartments!(s::RDMEPropensityRejectDiffusion,num::Integer,invvolume)
    s.numcompartments+=num
    ncs= getnumfixedspecies(s)
    nds= getnumdiffusingspecies(s)
    s.diffusingcounts= [s.diffusingcounts zeros(eltype(s.diffusingcounts),nds,num)]
    s.fixedcounts= [s.fixedcounts zeros(eltype(s.fixedcounts),ncs,num)]
    s.diffusionrates= cat(s.diffusionrates,zeros(eltype(s.diffusionrates),6,nds,num); dims=3)
    s.neighbors= cat(s.neighbors,zeros(eltype(s.neighbors),6,num); dims=2)
    append!(s.invvolumes,fill(invvolume,num))

    s.totaldiffusion_rates= [s.totaldiffusion_rates zeros(eltype(s.totaldiffusion_rates),nds,num)]
    append!(s.totalspeciesdiffusion_a, zeros(eltype(s.totalspeciesdiffusion_a),num))
    s.diffusion_a= [s.diffusion_a zeros(eltype(s.diffusion_a),nds,num)]
    newcompartment_a = [propensity(cr,zeros(eltype(s.diffusingcounts),nds),zeros(eltype(s.fixedcounts),ncs),s.bulkcounts,invvolume) for cr in s.compartmentreactions, i in 1:num]
    s.compartment_a= [s.compartment_a newcompartment_a]
    s.total_a+= sum(newcompartment_a)
end

function setinvvolume!(s::RDMEPropensityRejectDiffusion,cid,invvolume)
    s.invvolumes[cid]= invvolume
    #update all compartment reaction propensities that need to be
    #if invvolume is Inf propensity will return 0.0
    for (crid,reaction) in enumerate(s.compartmentreactions)
        s.total_a-= s.compartment_a[crid,cid]
        s.compartment_a[crid,cid]= propensity(reaction,s.diffusingcounts[:,cid],s.fixedcounts[:,cid],s.bulkcounts,s.invvolumes[cid])
        s.total_a+= s.compartment_a[crid,cid]
    end
end

function setdiffusionrate!(s::RDMEPropensityRejectDiffusion,side,dsid,cid,rate)
    s.diffusionrates[side,dsid,cid]= rate
    oldtotalspeciesdiffusion_a= s.totalspeciesdiffusion_a[cid]
    s.total_a-= s.diffusion_a[dsid,cid]
    s.totaldiffusion_a-= s.diffusion_a[dsid,cid]
    s.totalspeciesdiffusion_a[cid]-= s.diffusion_a[dsid,cid]
    s.totaldiffusion_rates[dsid,cid]= sum(s.diffusionrates[:,dsid,cid])
    s.diffusion_a[dsid,cid]= s.totaldiffusion_rates[dsid,cid]*s.diffusingcounts[dsid,cid]
    s.total_a+= s.diffusion_a[dsid,cid]
    s.totaldiffusion_a+= s.diffusion_a[dsid,cid]
    s.totalspeciesdiffusion_a[cid]+= s.diffusion_a[dsid,cid]
    if s.totalspeciesdiffusion_a[cid] ≥ s.max_totalspeciesdiffusion_a
        s.max_totalspeciesdiffusion_a= s.totalspeciesdiffusion_a[cid]
    elseif oldtotalspeciesdiffusion_a == s.max_totalspeciesdiffusion_a
        #reset max here, maybe have a smarter way of doing this?
        s.max_totalspeciesdiffusion_a= maximum(s.totalspeciesdiffusion_a)
    end


end

function setneighbor!(s::RDMEPropensityRejectDiffusion,side,cid,neighborcid)
    s.neighbors[side,cid]= neighborcid
end

function setfixedspeciescount!(s::RDMEPropensityRejectDiffusion,sid,cid,newcount)
    @assert newcount≥0 "counts must be positive"
    s.fixedcounts[sid,cid]= newcount
    for crid in s.fixeds_compartmentr_map[sid]
        reaction= s.compartmentreactions[crid]
        s.total_a-= s.compartment_a[crid,cid]
        s.compartment_a[crid,cid]= propensity(reaction,s.diffusingcounts[:,cid],s.fixedcounts[:,cid],s.bulkcounts,s.invvolumes[cid])
        s.total_a+= s.compartment_a[crid,cid]
    end
end

function setdiffusingspeciescount!(s::RDMEPropensityRejectDiffusion,sid,cid,newcount)
    @assert newcount≥0 "counts must be positive"
    @inbounds s.diffusingcounts[sid,cid]= newcount
    for crid in s.diffusings_compartmentr_map[sid]
        @inbounds reaction= s.compartmentreactions[crid]
        s.total_a-= s.compartment_a[crid,cid]
        @inbounds dcounts= @view(s.diffusingcounts[:,cid])
        @inbounds ccounts= @view(s.fixedcounts[:,cid])
        bcounts= s.bulkcounts
        @inbounds prop= propensity(reaction,dcounts,ccounts,bcounts,s.invvolumes[cid])
        @inbounds s.compartment_a[crid,cid]= prop
        s.total_a+= s.compartment_a[crid,cid]
    end
    oldtotalspeciesdiffusion_a= s.totalspeciesdiffusion_a[cid]
    @inbounds s.total_a-= s.diffusion_a[sid,cid]
    s.totaldiffusion_a-= s.diffusion_a[sid,cid]
    @inbounds s.totalspeciesdiffusion_a[cid]-= s.diffusion_a[sid,cid]
    @inbounds s.diffusion_a[sid,cid]= s.totaldiffusion_rates[sid,cid]*s.diffusingcounts[sid,cid]
    s.total_a+= s.diffusion_a[sid,cid]
    s.totaldiffusion_a+= s.diffusion_a[sid,cid]
    s.totalspeciesdiffusion_a[cid]+= s.diffusion_a[sid,cid]
    if s.totalspeciesdiffusion_a[cid] ≥ s.max_totalspeciesdiffusion_a
        s.max_totalspeciesdiffusion_a= s.totalspeciesdiffusion_a[cid]
    elseif oldtotalspeciesdiffusion_a == s.max_totalspeciesdiffusion_a
        #reset max here, maybe have a smarter way of doing this?
        s.max_totalspeciesdiffusion_a= maximum(s.totalspeciesdiffusion_a)
    end
end

function adddiffusingspeciescount!(s::RDMEPropensityRejectDiffusion,sid,cid,inccount)
    newcount= s.diffusingcounts[sid,cid] + inccount
    setdiffusingspeciescount!(s,sid,cid,newcount)
end

function incdiffusingspeciescount!(s::RDMEPropensityRejectDiffusion,sid,cid)
    adddiffusingspeciescount!(s::RDMEPropensityRejectDiffusion,sid,cid,1)
end

function decdiffusingspeciescount!(s::RDMEPropensityRejectDiffusion,sid,cid)
    adddiffusingspeciescount!(s::RDMEPropensityRejectDiffusion,sid,cid,-1)
end

function addbulkspecies!(s::RDMEPropensityRejectDiffusion,initcount)
    @assert initcount≥0 "counts must be positive"
    push!(s.bulkcounts,initcount)
    push!(s.bulks_bulkr_map, [])
    push!(s.bulks_compartmentr_map, [])
end

function setbulkspeciescount!(s::RDMEPropensityRejectDiffusion,bsid,newcount)
    @assert newcount≥0 "counts must be positive"
    s.bulkcounts[bsid]= newcount
    for brid in s.bulks_bulkr_map[bsid]
        reaction= s.bulkreactions[brid]
        s.total_a-= s.bulk_a[brid]
        s.bulk_a[brid]= propensity(reaction, s.bulkcounts)
        s.total_a+= s.bulk_a[brid]
    end
    #This could be a bottleneck
    crids= s.bulks_compartmentr_map[bsid]
    if !isempty(crids)
        for cid in 1:s.numcompartments
            for crid in crids
                reaction= s.compartmentreactions[crid]
                s.total_a-= s.compartment_a[crid,cid]
                s.compartment_a[crid,cid]= propensity(reaction,s.diffusingcounts[:,cid],s.fixedcounts[:,cid],s.bulkcounts,s.invvolumes[cid])
                s.total_a+= s.compartment_a[crid,cid]
            end
        end
    end
end

function addbulkspeciescount!(s::RDMEPropensityRejectDiffusion,bsid,inccount)
    newcount= s.bulkcounts[bsid] + inccount
    setbulkspeciescount!(s,bsid,newcount)
end

function addbulkreaction!(s::RDMEPropensityRejectDiffusion,bulkreaction)
    push!(s.bulkreactions,deepcopy(bulkreaction))
    #update s.bulks_bulkr_map
    brid= length(s.bulkreactions)
    for reactant in bulkreaction.reactants
        push!(s.bulks_bulkr_map[reactant.id],brid)
    end
    push!(s.bulk_a, propensity(bulkreaction, s.bulkcounts))
    s.total_a+= s.bulk_a[brid]
end

"""
remove bulk reaction with id brid,
 and changes the last bulk reaction id to brid
"""
function removebulkreaction!(s::RDMEPropensityRejectDiffusion,brid)
    lastbrid= lastindex(s.bulkreactions)
    s.total_a-= s.bulk_a[brid]
    for reactant in s.bulkreactions[brid].reactants
        brids= s.bulks_bulkr_map[reactant.id]
        deleteat!(brids, findfirst(==(brid),brids))
    end
    if brid == lastbrid
    else
        s.bulkreactions[brid]= s.bulkreactions[end]
        s.bulk_a[brid]= s.bulk_a[end]
        for reactant in s.bulkreactions[brid].reactants
            brids= s.bulks_bulkr_map[reactant.id]
            brids[findfirst(==(lastbrid),brids)]= brid
        end
    end
    pop!(s.bulkreactions)
    pop!(s.bulk_a)
end

function replacebulkreaction!(s::RDMEPropensityRejectDiffusion,brid,newreaction)
    oldbulkreaction= s.bulkreactions[brid]
    s.total_a-= s.bulk_a[brid]
    for reactant in oldbulkreaction.reactants
        brids= s.bulks_bulkr_map[reactant.id]
        deleteat!(brids, findfirst(==(brid),brids))
    end
    s.bulkreactions[brid] = deepcopy(newreaction)
    for reactant in newreaction.reactants
        push!(s.bulks_bulkr_map[reactant.id],brid)
    end
    s.bulk_a[brid]= propensity(newreaction, s.bulkcounts)
    s.total_a+= s.bulk_a[brid]
end

function addcompartmentreaction!(s::RDMEPropensityRejectDiffusion,reaction)
    push!(s.compartmentreactions,deepcopy(reaction))
    crid= length(s.compartmentreactions)
    dr1, dr2 = reaction.diffusingreactants
    if !iszero(dr1)
        push!(s.diffusings_compartmentr_map[dr1],crid)
        if !iszero(dr2)
            if(dr1 != dr2)
                push!(s.diffusings_compartmentr_map[dr2],crid)
            end
        end
    end
    for reactant in reaction.fixedreactants
        push!(s.fixeds_compartmentr_map[reactant.id],crid)
    end
    for reactant in reaction.bulkreactants
        push!(s.bulks_compartmentr_map[reactant.id],crid)
    end
    newcompartment_a = [propensity(reaction,s.diffusingcounts[:,cid],s.fixedcounts[:,cid],s.bulkcounts,s.invvolumes[cid]) for cid in 1:s.numcompartments]'
    s.compartment_a= [s.compartment_a; newcompartment_a]
    s.total_a+= reduce(+,newcompartment_a)
end

"""
remove compartment reaction with id crid,
 and changes the last compartment reaction id to crid
"""
function removecompartmentreaction!(s::RDMEPropensityRejectDiffusion,crid)
    lastcrid= lastindex(s.compartmentreactions)
    oldcompartment_a= s.compartment_a[crid,:]
    s.total_a-= reduce(+,oldcompartment_a)
    oldreaction= s.compartmentreactions[crid]
    lastreaction= s.compartmentreactions[end]
    dr1, dr2 = oldreaction.diffusingreactants
    if !iszero(dr1)
        crids= s.diffusings_compartmentr_map[dr1]
        deleteat!(crids,findfirst(==(crid),crids))
        if !iszero(dr2)
            if(dr1 != dr2)
                crids= s.diffusings_compartmentr_map[dr2]
                deleteat!(crids,findfirst(==(crid),crids))
            end
        end
    end
    for reactant in oldreaction.fixedreactants
        crids= s.fixeds_compartmentr_map[reactant.id]
        deleteat!(crids,findfirst(==(crid),crids))
    end
    for reactant in oldreaction.bulkreactants
        crids= s.bulks_compartmentr_map[reactant.id]
        deleteat!(crids,findfirst(==(crid),crids))
    end
    if crid != lastcrid
        s.compartmentreactions[crid]= s.compartmentreactions[end]
        s.compartment_a[crid,:].= s.compartment_a[lastcrid,:]
        dr1, dr2 = lastreaction.diffusingreactants
        if !iszero(dr1)
            crids= s.diffusings_compartmentr_map[dr1]
            crids[findfirst(==(lastcrid),crids)]= crid
            if !iszero(dr2)
                if(dr1 != dr2)
                    crids= s.diffusings_compartmentr_map[dr2]
                    crids[findfirst(==(lastcrid),crids)]= crid
                end
            end
        end
        for reactant in lastreaction.fixedreactants
            crids= s.fixeds_compartmentr_map[reactant.id]
            crids[findfirst(==(lastcrid),crids)]= crid
        end
        for reactant in lastreaction.bulkreactants
            crids= s.bulks_compartmentr_map[reactant.id]
            crids[findfirst(==(lastcrid),crids)]= crid
        end
    end
    s.compartment_a= s.compartment_a[1:end-1,:]
    pop!(s.compartmentreactions)
end

function replacecompartmentreaction!(s::RDMEPropensityRejectDiffusion,crid,newreaction)
    oldcompartment_a= s.compartment_a[crid,:]
    s.total_a-= reduce(+,oldcompartment_a)
    oldreaction= s.compartmentreactions[crid]
    dr1, dr2 = oldreaction.diffusingreactants
    if !iszero(dr1)
        crids= s.diffusings_compartmentr_map[dr1]
        deleteat!(crids,findfirst(==(crid),crids))
        if !iszero(dr2)
            if(dr1 != dr2)
                crids= s.diffusings_compartmentr_map[dr2]
                deleteat!(crids,findfirst(==(crid),crids))
            end
        end
    end
    for reactant in oldreaction.fixedreactants
        crids= s.fixeds_compartmentr_map[reactant.id]
        deleteat!(crids,findfirst(==(crid),crids))
    end
    for reactant in oldreaction.bulkreactants
        crids= s.bulks_compartmentr_map[reactant.id]
        deleteat!(crids,findfirst(==(crid),crids))
    end
    s.compartmentreactions[crid] = deepcopy(newreaction)
    dr1, dr2 = newreaction.diffusingreactants
    if !iszero(dr1)
        push!(s.diffusings_compartmentr_map[dr1],crid)
        if !iszero(dr2)
            if(dr1 != dr2)
                push!(s.diffusings_compartmentr_map[dr2],crid)
            end
        end
    end
    for reactant in newreaction.fixedreactants
        push!(s.fixeds_compartmentr_map[reactant.id],crid)
    end
    for reactant in newreaction.bulkreactants
        push!(s.bulks_compartmentr_map[reactant.id],crid)
    end
    newcompartment_a = [propensity(newreaction,s.diffusingcounts[:,cid],s.fixedcounts[:,cid],s.bulkcounts,s.invvolumes[cid]) for cid in 1:s.numcompartments]'
    s.compartment_a[crid,:].= newcompartment_a
    s.total_a+= reduce(+,newcompartment_a)
end

function gettotal_a(s::RDMEPropensityRejectDiffusion)
    return s.total_a
end

function dorandomreaction!(s::RDMEPropensityRejectDiffusion)
    nds = getnumdiffusingspecies(s)
    nc = s.numcompartments
    ncr= length(s.compartmentreactions)
    u::Q31f32= Q31f32(s.total_a*rand())
    #first go through diffusion reactions, they are usually most likely
    u-= s.totaldiffusion_a
    if u ≤ 0
        #diffusion reaction happened, now rejection sample
        @inbounds while true
            #pick a random compartment
            cid= rand(1:nc)
            u2= s.max_totalspeciesdiffusion_a*rand()
            a= s.totalspeciesdiffusion_a[cid]
            #reject and repeat
            if u2 ≤ a
                u3= a*rand()
                for dsid in 1:nds
                    u3 -= s.diffusion_a[dsid,cid]
                    if u3 ≤ 0
                        u4 = s.totaldiffusion_rates[dsid,cid]*rand()
                        for side in 1:6
                            u4 -= s.diffusionrates[side,dsid,cid]
                            if u4 ≤ 0
                                return dodiffusionreaction!(s,side,dsid,cid)
                            end
                        end
                    end
                end
            end
        end
    end

    #next go through compartment reactions.
    for cid in 1:nc, crid in 1:ncr
        u -= s.compartment_a[crid,cid]
        if u ≤ 0
            return docompartmentreaction!(s,crid,cid)
        end
    end

    #next go through bulk reactions.
    for (brid, reaction) in enumerate(s.bulkreactions)
        u -= s.bulk_a[brid]
        if u ≤ 0
            return dobulkreaction!(s,brid)
        end
    end

    error("no reaction fired, but one should have.")
end
