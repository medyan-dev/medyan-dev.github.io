"""
This file contains auxiliary functions that can be used in the mainloop other than chemistry and energy minimization.
"""

"""
Remesh all membrane meshes.
"""
function adapt_membranes!(c::Context; params::MeshAdaptParams=MeshAdaptParams())
    unset!(c.validflags, VFS_DEP_VERTEX_COORD)
    for m ∈ c.membranes
        verstate2_before = MEDYAN.num_vertexwithstate(m, UInt8(2))
        adaptmesh!(membranemesh_splitfunc!, membranemesh_collapsefunc!, membranemesh_flipfunc!, membranemesh_relocfunc!, m, params)
        verstate2_after = MEDYAN.num_vertexwithstate(m, UInt8(2))    
        if !isequal(verstate2_before, verstate2_after)
            error(
                """Inconsistent number of vertices with UInt8(2)"""
            )
        end
    end
end
export adapt_membranes!


"""
Given an AABB tree corresponding to up-to-date membrane mesh triangles, resolve all filament-membrane intersections.

Requires
- up-to-date unit normals of all triangles in the meshes.
- up-to-date AABB tree corresponding to all membrane meshes.    
"""
function resolve_all_filament_mesh_crossing!(c::Context, tree::BinaryAABBTree; intersect_resbuffer::Vector{LineMeshAABBIntersectResType}=LineMeshAABBIntersectResType[], tback::Real=0.8)::Nothing
    unset!(c.validflags, VFS_SEGMENTS)

    for chem_cylinders_for_ft ∈ c.chem_cylinders
        for fil_idx ∈ eachindex(chem_cylinders_for_ft.per_fil)
            MEDYAN.resolve_filament_mesh_crossing!(chem_cylinders_for_ft, fil_idx, c.membranes, tree; intersect_resbuffer, tback)
        end
    end
end
export resolve_all_filament_mesh_crossing!

"""
Check for crossing of cylinders against membrane meshes and try to resolve them.
Since bead-triangle repulsion is used, it is okay if a cylinder crosses a mesh even number of times, as long as two endpoints are on the same side.

If a cylinder intersects a mesh an odd number of times, the function will
1. Find the endpoint that is *outside* the mesh.
2. Collect all beads on the filament from the outside endpoint. Ignoring their current position, compress those segments such that all those points lie in the interior of the mesh.

This function requires
- up-to-date unit normals of all triangles in the meshes.
- up-to-date AABB tree corresponding to all membrane meshes.

Since this function changes filament bead positions, data that is dependent on bead positions must be updated.

# Keyword arguments:
- `intersect_resbuffer`: can use preallocated vector to reduce allocation.
- `tback`: When intersects occur, compress filament to which portion of maximum allowed length.
"""
function resolve_filament_mesh_crossing!(cylinders::ChemCylinders, fil_idx::Integer, meshes::AbstractVector, tree::BinaryAABBTree; intersect_resbuffer::Vector{LineMeshAABBIntersectResType}=LineMeshAABBIntersectResType[], tback::Real=0.8)::Nothing
    @assert tback > 0 && tback < 1
    chembeadpositions = cylinders.per_fil.chembeadpositions[fil_idx]
    mon_id_info = _mon_id_info(cylinders::ChemCylinders, fil_idx::Int)
    nodemids = _fil_node_mon_ids(cylinders, fil_idx)
    ncyl = length(chembeadpositions) - 1

    # Counts number of cylinders without intersects. The function exits only when it is equal to the total number of cylinders.
    ncyl_nointersect::Int = 0
    while ncyl_nointersect != ncyl
        ncyl_nointersect = 0
        nodepos = _get_nodepositions(cylinders, fil_idx)
        for i ∈ 1:ncyl
            n1 = nodepos[i]
            n2 = nodepos[i+1]
            d = n2 - n1
            line_meshaabb_intersect!(tree, n1, d; sorting=true, tinterval=(0,1), resbuffer=intersect_resbuffer)
            if isempty(intersect_resbuffer)
                ncyl_nointersect += 1
            else
                # Count number of meshes where there are indeed intersects.
                num_intersecting_mesh::Int = 0
                for mindex ∈ 1:length(meshes)
                    # Count intersections for this mesh.
                    local netout::Int = 0
                    local first_ires::Int = -1
                    local last_ires::Int = -1
                    for ires ∈ eachindex(intersect_resbuffer)
                        if intersect_resbuffer[ires].mindex == mindex
                            local tindex = intersect_resbuffer[ires].tindex
                            local un = meshes[mindex].triangles.attr.unitnormal[tindex]
                            if dot(un, d) > 0
                                netout += 1
                            else
                                netout -= 1
                            end
                            if first_ires == -1
                                first_ires = ires
                            end
                            last_ires = ires
                        end
                    end
                    if netout == 0
                        # Do not count intersections.
                    elseif netout == 1
                        num_intersecting_mesh += 1
                        # n2 is outside. Compress all cylinders till plus end and retry.
                        @warn "Cylinder $i on the filament goes out of mesh $mindex."
                        resolve_crossing_aux_compress_filament!(chembeadpositions, mon_id_info, nodepos, nodemids, i, d, true, tback * intersect_resbuffer[first_ires].t)
                        @goto retry_intersect
                    elseif netout == -1
                        num_intersecting_mesh += 1
                        # n1 is outside. Compress all cylinders till minus end and retry.
                        @warn "Cylinder $i on the filament goes inside mesh $mindex."
                        resolve_crossing_aux_compress_filament!(chembeadpositions, mon_id_info, nodepos, nodemids, i, d, false, tback * (1 - intersect_resbuffer[last_ires].t))
                        @goto retry_intersect
                    else
                        error("Cylinder $i on the filament goes out of mesh $mindex $netout times net.")
                    end
                end
                # If there is no effective intersection, also increase non-intersecting cylinder count.
                if num_intersecting_mesh == 0
                    ncyl_nointersect += 1
                end
            end
        end

        # Any compression operations should immediately skip to retrying.
        @label retry_intersect
    end
end

"""
This is the auxiliary function called by `resolve_filament_mesh_crossing!` that compresses part of a filament.
Redundant information is passed into this function to reduce computation and allocations.
"""
function resolve_crossing_aux_compress_filament!(chembeadpositions, mon_id_info, nodepos::AbstractVector, nodemids::AbstractVector{Int}, cylindex::Int, d::AbstractVector, plusend::Bool, ttarget::Real)
    ncyl = length(nodemids) - 1
    if plusend
        # Count monomers.
        nmon_total = nodemids[end] - nodemids[cylindex]
        # Get new d for each monomer.
        dmon = d * (ttarget / nmon_total)
        for i ∈ cylindex:ncyl
            nodepos[i+1] = nodepos[i] + dmon * (nodemids[i+1] - nodemids[i])
        end
    else
        # Count monomers.
        nmon_total = nodemids[cylindex+1] - nodemids[begin]
        # Get new d for each monomer.
        dmon = d * (ttarget / nmon_total)
        for i ∈ cylindex:-1:1
            nodepos[i] = nodepos[i+1] - dmon * (nodemids[i+1] - nodemids[i])
        end
    end
    set_nodepositions!(chembeadpositions, nodepos, mon_id_info...)
end


"""
Updates all membrane geometries used across various parts of MEDYAN.

The list of all items can be found in the document for `MEDYAN.compute_geometry!_system` function.

Keyword parameters:
- `include_ff::Bool`: If true, `compute_geometry!` used in energy computations will be applied as well, requiring vectorization of the membrane. This happens before system geometry computation in case some fields are overriden.
"""
function compute_all_membrane_geometry!_system(c::Context; include_ff::Bool=false)
    for m ∈ c.membranes
        compute_geometry!_system(m)

        if include_ff
            # Vectorize the membrane.
            sm = StaticHalfedgeMesh(m)
            cachecoordindices!(sm)
            Float = eltype(eltype(m.vertices.attr.coord))
            x = reinterpret(Float, m.vertices.attr.coord)
            # Compute geometry vectorized.
            compute_geometry!(sm, x, c.sharedtypedconfigs.meshcurv)
        end
    end

    set!(c.validflags, VFS_MEMBRANE_GEOMETRY_SYSTEM)
    if include_ff
        set!(c.validflags, VFS_MEMBRANE_GEOMETRY_FF)
    end
end
export compute_all_membrane_geometry!_system
