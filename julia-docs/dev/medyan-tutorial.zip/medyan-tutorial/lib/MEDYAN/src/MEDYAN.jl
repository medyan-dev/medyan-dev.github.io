module MEDYAN

using StaticArrays
using Random
using FixedPointNumbers
using DocStringExtensions
using ArgCheck: @argcheck

const PUBLIC = "public\n\n"

include("third-party-patches.jl")

include("util/math/aabbtree.jl")
include("util/math/cuboidslicing.jl")
include("util/math/pathgeometry.jl")
include("util/math/cylinderforces.jl")
include("util/math/ray_triangle_intersect.jl")
include("util/struct-equal.jl")
include("util/unitconversions/chemical.jl")
include("util/unitconversions/mechanical.jl")
include("util/vectorswaperase.jl")
include("util/propdictionary.jl")
include("util/stableindex.jl")
include("util/validflags.jl")

include("force-energy.jl")

include("links/tag-manager.jl")
include("grids.jl")
export CubicGrid
include("boundary.jl")

include("rdmesamplers/rdmesamplerinterface.jl")
include("rdmesamplers/rdmepropensitycache.jl")
include("rdmesamplers/rdmepropensityrejectdiffusion.jl")

include("links/place-indexes.jl")
export FilaIdx
export FilaTipIdx
export FilaMonoIdx
export MembVertIdx
include("links/bonds.jl")
include("sys_def-types.jl")
include("sys_def.jl")
export CadherinState
export CadherinParams
export add_filament_params!
export addfilamentsite!
export addfilamentendsite!
export add_decimated_2mon_site!
export addcadherinsite!
export addpossiblecadherinsite!
export addreaction!
export addreactioncallback!
export addfilament_reaction!
export addfilamentend_reaction!
export add_diffusion_coeff!
export addcadherin!
export addunbindingcadherinsite!

include("filament/structs.jl")
export MonomerState
include("links/link-data-types.jl")
include("cadherins/cadherindata_struct.jl")
include("decimated_2mon_site-calcs/structs.jl")


include("membrane/halfedgemesh.jl")
include("membrane/membraneenergies.jl")
include("membrane/membranemesh.jl")
export gettype_membranemesh
include("membrane/membranemeshgeo.jl")
include("membrane/membranesites.jl")
include("membrane/membranerdme.jl")
include("membrane/meshadapt.jl")
export num_vertexwithstate
include("membrane/meshinit.jl")
export MeshInitSurfaceFunc, MeshInitEllipsoid, MeshInitPlane
include("membrane/meshraytracing.jl")
include("membrane/trianglebeadvolexcl.jl")

include("context.jl")
export filtype_fil_ids
export fil_node_positions
export fil_node_mon_ids
export fil_mon_states
export fila_num_unmin_ends
export vertex_state
export place_exists
export is_minimized
export mon_3states
export mon_position
export mon_plusvector
export mon_position_plusvector


export defer_chem_caching!
export is_chem_cache_valid
export refresh_chem_cache!


export run_chemistry!
export MonomerName
export VertexName
export chem_depolymerize!
export chem_newcadherin!
export chem_removecadherin!
export chem_setcadherinstate!
export chem_adddiffusingcount!
export chem_addfixedcount!
export set_time!
export set_enable_cylinder_volume_exclusion!
export set_mechboundary!
export set_chemboundary!

export adddiffusingcount_rand!
export addmembranediffusingcount_rand!
export newmembrane!

include("links/places.jl")
export is_minus_end
export get_place
include("links/link-manager.jl")
include("links/link-chemistry.jl")
include("cadherins/cadherindata.jl")
include("decimated_2mon_site-calcs/functions.jl")
include("map_nearby_monomers.jl")


include("minimize_energy.jl")
export minimize_energy!

include("auxprocs.jl")

include("filament/functions.jl")
export num_fila_types
export num_fila
export fila_mono_states
export fila_num_nodes
export fila_node_mids
export fila_node_positions
export fila_tip_tags

include("filament/make_fila.jl")
export make_fila!
include("filament/make_fila_rand.jl")
export make_fila_rand!
include("filament/remove_fila.jl")
export remove_fila!
include("filament/update_fila_mono_state.jl")
export update_fila_mono_state!
include("filament/polymerize_fila.jl")
export polymerize_fila!

export sever_fila!

include("filament/sites.jl")

include("filament/endsites.jl")

# include("cadherins/cadherinsites.jl")

include("decimated_2mon_sites.jl")
include("cadherins/possiblecadherinsite.jl")
export VertexState

include("chemistrycallbacks.jl")
include("links/example-reactions.jl")

include("example_contexts.jl")

include("trajectory-io/header.jl")
include("trajectory-io/snapshot.jl")
export load_snapshot!

include("hessian.jl")

end