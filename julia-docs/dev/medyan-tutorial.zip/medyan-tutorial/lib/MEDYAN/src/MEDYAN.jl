module MEDYAN

using StaticArrays
using Random
using FixedPointNumbers
using DocStringExtensions
using ArgCheck: @argcheck

const PUBLIC = "public\n\n"

include("third-party-patches.jl")

include("util/math/aabbtree.jl")
include("util/math/cuboidslicing.jl")
include("util/math/pathgeometry.jl")
include("util/math/cylinderforces.jl")
include("util/math/ray_triangle_intersect.jl")
include("util/struct-equal.jl")
include("util/unitconversions/chemical.jl")
include("util/unitconversions/mechanical.jl")
include("util/vectorswaperase.jl")
include("util/propdictionary.jl")
include("util/stableindex.jl")
include("util/validflags.jl")

include("force-energy.jl")

include("links/tag-manager.jl")
include("grids.jl")
export CubicGrid
include("boundary.jl")

include("rdmesamplers/rdmesamplerinterface.jl")
include("rdmesamplers/rdmepropensitycache.jl")
include("rdmesamplers/rdmepropensityrejectdiffusion.jl")

include("links/place-indexes.jl")
export FilaIdx
export FilaTipIdx
export FilaMonoIdx
export MembVertIdx
include("links/bonds.jl")
include("sys_def-types.jl")
include("sys_def.jl")
export add_filament_params!
export addfilamentsite!
export addfilamentendsite!
export add_decimated_2mon_site!
export addpossiblecadherinsite!
export addreaction!
export addreactioncallback!
export addfilament_reaction!
export addfilamentend_reaction!
export add_diffusion_coeff!

include("filament/structs.jl")
export MonomerState
include("links/link-data-types.jl")
include("decimated_2mon_site-calcs/structs.jl")


include("membrane/halfedgemesh.jl")
include("membrane/membraneenergies.jl")
include("membrane/membranemesh.jl")
export gettype_membranemesh
include("membrane/membranemeshgeo.jl")
include("membrane/membranesites.jl")
include("membrane/membranerdme.jl")
include("membrane/meshadapt.jl")
export num_vertexwithstate
include("membrane/meshinit.jl")
export MeshInitSurfaceFunc, MeshInitEllipsoid, MeshInitPlane
include("membrane/meshraytracing.jl")
include("membrane/trianglebeadvolexcl.jl")

include("context.jl")
export add_diffusing_count!


export defer_chem_caching!
export is_chem_cache_valid
export refresh_chem_cache!


export run_chemistry!
export VertexName
export chem_adddiffusingcount!
export chem_addfixedcount!
export set_time!
export set_enable_cylinder_volume_exclusion!
export set_mechboundary!
export set_chemboundary!

export adddiffusingcount_rand!
export addmembranediffusingcount_rand!
export newmembrane!

include("links/places.jl")
export is_minus_end
export tag2place
include("links/link-manager.jl")
export place_exists
export tag!
export make_link!
export remove_link!
export update_link!
export num_link_types
export get_all_links
export get_all_tags
export tag2links
export place2links
export tag_exists
export link_exists
export link2tags
export tag2place
export place2tag
export has_tag
export get_position
export num_directions
export get_directions
export get_chem_state
export get_state
export get_bond_states
export get_bond_enabled
export get_reaction_enabled
export is_minimized
export get_link_mechanics
include("links/link-chemistry.jl")
include("decimated_2mon_site-calcs/functions.jl")
include("map_nearby_monomers.jl")


include("minimize_energy.jl")
export minimize_energy!

include("auxprocs.jl")

include("filament/functions.jl")
export num_fila_types
export num_fila
export fila_mono_ids
export fila_mono_states
export fila_num_nodes
export fila_node_mids
export fila_node_positions
export fila_tip_tags
export fila_num_unmin_ends
export pick_rand_fila_mono_site
export pick_rand_fila_tip_site

include("filament/make_fila.jl")
export make_fila!
include("filament/make_fila_rand.jl")
export make_fila_rand!
include("filament/remove_fila.jl")
export remove_fila!
include("filament/update_fila_mono_state.jl")
export update_fila_mono_state!
include("filament/polymerize_fila.jl")
export polymerize_fila!
include("filament/depolymerize_fila.jl")
export depolymerize_fila!
include("filament/sever_fila.jl")
export sever_fila!

include("filament/sites.jl")

include("filament/endsites.jl")


include("decimated_2mon_sites.jl")
include("cadherins/possiblecadherinsite.jl")
export VertexState

include("chemistrycallbacks.jl")
include("links/example-reactions.jl")

include("example_contexts.jl")

include("trajectory-io/header.jl")
include("trajectory-io/snapshot.jl")
export load_snapshot!

include("hessian.jl")
include("internal-forces.jl")

include("filament/cofilin_sever_site.jl")

end
