module MEDYAN

using StaticArrays
using Distributions
using Random
using FixedPointNumbers
using DocStringExtensions

const PUBLIC = "public\n\n"

include("third-party-patches.jl")

include("util/math/aabbtree.jl")
include("util/math/cuboidslicing.jl")
include("util/math/pathgeometry.jl")
include("util/math/smoothpaths.jl")
include("util/math/cylinderforces.jl")
include("util/math/ray_triangle_intersect.jl")
include("util/unitconversions/chemical.jl")
include("util/unitconversions/mechanical.jl")
include("util/vectorswaperase.jl")
include("util/propdictionary.jl")
include("util/stableindex.jl")
include("util/validflags.jl")

include("boundary.jl")
include("grids.jl")
export CubicGrid

include("rdmesamplers/rdmesamplerinterface.jl")
include("rdmesamplers/rdmepropensitycache.jl")
include("rdmesamplers/rdmepropensityrejectdiffusion.jl")

include("sysdefs.jl")
export Link2MonState
export Link2MonParams
export CadherinState
export CadherinParams
export add_filament_params!
export addfilamentsite!
export addfilamentendsite!
export add_link_2mon_site!
export add_decimated_2mon_site!
export addcadherinsite!
export addpossiblecadherinsite!
export addreaction!
export addreactioncallback!
export addfilament_reaction!
export addfilamentend_reaction!
export add_diffusion_coeff!
export add_link_2mon!
export addcadherin!
export addunbindinglink_2mon_site!
export addunbindingcadherinsite!

include("chem_cylinder.jl")
export MonomerState

include("link_2mon_data_struct.jl")
include("cadherins/cadherindata_struct.jl")
include("decimated_2mon_site-calcs/structs.jl")


include("membrane/halfedgemesh.jl")
include("membrane/membraneenergies.jl")
include("membrane/membranemesh.jl")
export gettype_membranemesh
include("membrane/membranemeshgeo.jl")
include("membrane/membranesites.jl")
include("membrane/membranerdme.jl")
include("membrane/meshadapt.jl")
export num_vertexwithstate
include("membrane/meshinit.jl")
export MeshInitSurfaceFunc, MeshInitEllipsoid, MeshInitPlane
include("membrane/meshraytracing.jl")
include("membrane/trianglebeadvolexcl.jl")

include("context.jl")
export num_filtypes
export filtype_fil_ids
export fil_node_positions
export fil_node_mon_ids
export fil_mon_states
export fil_num_unmin_ends
export vertex_state
export mon_exists
export mon_minimized
export mon_3states
export mon_position
export mon_plusvector
export mon_position_plusvector

export num_link_2montypes
export link_2mon_endnames
export link_2mon_state


export defer_chem_caching!
export is_chem_cache_valid
export refresh_chem_cache!


export run_chemistry!
export MonomerName
export VertexName
export chem_newfilament!
export chem_removefilament!
export chem_polymerize!
export chem_depolymerize!
export chem_setmonomerstate!
export chem_newlink_2mon!
export chem_removelink_2mon!
export chem_setlink_2mon_state!
export chem_newcadherin!
export chem_removecadherin!
export chem_setcadherinstate!
export chem_adddiffusingcount!
export chem_addfixedcount!
export set_time!
export set_enable_cylinder_volume_exclusion!
export set_mechboundary!
export set_chemboundary!

export newfilament_rand!
export newfilament_undermembrane!
export adddiffusingcount_rand!
export addmembranediffusingcount_rand!
export newmembrane!

include("link_2mon_data.jl")
include("cadherins/cadherindata.jl")
include("decimated_2mon_site-calcs/functions.jl")
include("map_nearby_monomers.jl")


include("minimize_energy.jl")
export minimize_energy!

include("auxprocs.jl")

include("sever_filament.jl")
export sever_filament!

include("filamentsites.jl")

include("filamentendsites.jl")

include("link_2mon_sites.jl")
include("mon_link_2mon_sites.jl")
# include("cadherins/cadherinsites.jl")

include("decimated_2mon_sites.jl")
include("cadherins/possiblecadherinsite.jl")
export VertexState

include("chemistrycallbacks.jl")

include("link_2mons/constantforce.jl")
include("link_2mons/distancerestraint.jl")
include("link_2mons/link_2mon_testing.jl")
include("link_2mons/nothing.jl")
include("link_2mons/relativerestraint.jl")
include("link_2mons/branch-bending-cosine.jl")
include("link_2mons/restraint.jl")

include("example_contexts.jl")

include("trajectory-io/header.jl")
include("trajectory-io/snapshot.jl")
export load_snapshot!

include("cxx_medyan_files.jl")


# avoid depending on visualization packages
# ext/meshcatglue.jl will run only if MeshCat is installed
include("meshcatglue-header.jl")

end