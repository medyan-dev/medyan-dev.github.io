"""
Commonly used chemistry callbacks,

function-like objects that get called with arguments of context::Context, compartmentid::Integer
"""

using AutoHashEquals
using Random
using StaticArrays
using LinearAlgebra
using Setfield

"""
Error check callbacks added to the MEDYAN.SysDef
Called before adding the callback
By default this doesn't do anything. It can be overloaded to error if there is an issue.

This is useful, because otherwise, callbacks can only generate errors when called in the simulation.
"""
function errorcheck_addcallback(callback,s::MEDYAN.SysDef)
    return nothing
end

"""
check if monomer states exist in s
"""
function errorcheck_statesexist(states,ftid,s::MEDYAN.SysDef)
    filtypename = s.agentnames.filamentnames[ftid][1]
    for state in states
        if !(state in s.state[ftid])
            error(
                """unknown state $(state) 
                on filament type $(filtypename), 
                max state $(maximum(s.state[ftid]))"""
            )
        end
    end
end

"""
check if diffusing species in stoich exist in s
"""
function errorcheck_diffusing_species_exist(stoich,s::MEDYAN.SysDef)
    for (id, amount) in stoich
        id in values(s.diffusing) || error("unknown diffusing species id $(id)")
    end
end



"""
Callback that will change the monomer state at a filamentsite in the compartment
Returns the name of the center monomer of the site changed or nothing.

$(TYPEDFIELDS)

"""
@auto_hash_equals struct GeneralFilamentSiteCallback
    "type of filament this acts on"
    ftid::Int

    "filament site id to act on"
    fsid::Int

    "index of center monomer in newstates"
    center::Int

    "new monomer states"
    newstates::Vector{MonomerState}

    "diffusing species net stoich"
    diffusing_net_stoich::Vector{Pair{Int, Int}}
end

function (g::GeneralFilamentSiteCallback)(c::Context, cid)
    name = pickrandomfilamentsite(c, cid, g.ftid, g.fsid)
    if isnothing(name)
        return
    end
    fid = name.fid
    centermid = name.mid
    offsetmid = centermid - g.center

    for i in 1:length(g.newstates)
        mid = i + offsetmid
        chem_setmonomerstate!(c, MonomerName(g.ftid, fid, mid), g.newstates[i])
    end
    for (id, amount) in g.diffusing_net_stoich
        chem_adddiffusingcount!(c, id, cid, amount)
    end
    return name
end

function errorcheck_addcallback(g::GeneralFilamentSiteCallback,s::MEDYAN.SysDef)
    errorcheck_statesexist(g.newstates,g.ftid,s)
    errorcheck_diffusing_species_exist(g.diffusing_net_stoich,s)
end


"""
Callback that will change the monomer state and or depolymerize/polymerize at a filamentendsite in the compartment

$(TYPEDFIELDS)
"""
@auto_hash_equals struct GeneralFilamentEndCallback
    "type of filament this acts on"
    ftid::Int

    "filament end site id to act on"
    fesid::Int

    "number of monomers to add if positive,
     remove if negative,
     just change states if zero"
    Δnummonomers::Int

    "new monomer states
    if the site isminusend then the end state is newstates[begin]
    else it is newstates[end]"
    newstates::Vector{MonomerState}

    diffusing_net_stoich::Vector{Pair{Int, Int}}
end

function (g::GeneralFilamentEndCallback)(c::Context, cid)
    site = c.filamentendsites[g.ftid][g.fesid].site
    name = pickrandomfilamentendsite(c, cid, g.ftid, g.fesid)
    if isnothing(name)
        return
    end
    fid = name.fid
    oldendmid = name.mid
    numpolyerized = max(g.Δnummonomers, 0)
    numdepolyerized = max(-g.Δnummonomers, 0)
    nummonomerschanged = length(g.newstates) - numpolyerized
    for i in 1:numpolyerized
        stateidx = isminusend(site) ? (numpolyerized - i + 1) : (nummonomerschanged + i)
        chem_polymerize!(c, g.ftid, fid, isminusend(site), g.newstates[stateidx])
    end
    for i in 1:numdepolyerized
        chem_depolymerize!(c, g.ftid, fid, isminusend(site))
    end
    if isminusend(site)
        for i in 1:nummonomerschanged
            stateidx = i + numpolyerized
            mid = i + oldendmid + numdepolyerized - 1
            chem_setmonomerstate!(c, MonomerName(g.ftid, fid, mid), g.newstates[stateidx])
        end
    else
        for i in 1:nummonomerschanged
            stateidx = i
            mid = i + oldendmid - nummonomerschanged - numdepolyerized
            chem_setmonomerstate!(c, MonomerName(g.ftid, fid, mid), g.newstates[stateidx])
        end
    end
    for (id, amount) in g.diffusing_net_stoich
        chem_adddiffusingcount!(c, id, cid, amount)
    end
end

function errorcheck_addcallback(g::GeneralFilamentEndCallback,s::MEDYAN.SysDef)
    errorcheck_statesexist(g.newstates,g.ftid,s)
    errorcheck_diffusing_species_exist(g.diffusing_net_stoich,s)
end


"""
Callback that will add a new branched filament at a filamentsite in the compartment

$(TYPEDFIELDS)
"""
@auto_hash_equals struct FilamentSiteBranchingCallback
    "filament site callback"
    filamentsitecallback::GeneralFilamentSiteCallback

    "link_2mon type id"
    ltid::Int

    "new filament type id"
    newftid::Int

    "is the new filament linked by its minus end?"
    attach_fil_minus_end::Bool

    "does the minus end of the link_2mon attach to the old filament?"
    link_2mon_old_minus::Bool

    "monomer states on new filament"
    newstates::Vector{MonomerState}

    diffusing_net_stoich::Vector{Pair{Int, Int}}
end

function (g::FilamentSiteBranchingCallback)(c::Context, cid)
    parentname = g.filamentsitecallback(c, cid)
    if isnothing(parentname)
        return
    end
    spacing = c.filamentmechparams[g.newftid].spacing
    parentpos = mon_position(c, parentname)
    newpos = parentpos + (1//2 * spacing) * randn(typeof(parentpos))
    newdir = normalize_fast(randn(typeof(parentpos)))
    nummonomers = length(g.newstates)
    nodepositions = if g.attach_fil_minus_end
        [newpos, newpos +  nummonomers * spacing * newdir]
    else
        [newpos +  nummonomers * spacing * newdir, newpos]
    end
    attachedmid = g.attach_fil_minus_end ? 0 : -1
    minusendmid = g.attach_fil_minus_end ? 0 : -nummonomers
    newfid = chem_newfilament!(c;
        ftid = g.newftid,
        node_mids = [minusendmid,],
        monomerstates = g.newstates,
        nodepositions,
    )
    childattachname = MonomerName(g.newftid, newfid, attachedmid)
    minusname = g.link_2mon_old_minus ? parentname : childattachname
    plusname = g.link_2mon_old_minus ? childattachname : parentname
    chem_newlink_2mon!(c, g.ltid, minusname=>plusname)
    for (id, amount) in g.diffusing_net_stoich
        chem_adddiffusingcount!(c, id, cid, amount)
    end
    return
end

function errorcheck_addcallback(g::FilamentSiteBranchingCallback,s::MEDYAN.SysDef)
    errorcheck_addcallback(g.filamentsitecallback,s)
    errorcheck_statesexist(g.newstates,g.newftid,s)
    errorcheck_diffusing_species_exist(g.diffusing_net_stoich,s)
end


"""
Callback that will crosslink two monomers.

Uses the default link_2mon state, but
sets the mechstate.L0 to the current distance between the monomers
Returns the monomer name of the minus end of the new link_2mon, 
    or nothing if rejected.

$(TYPEDFIELDS)
"""
@auto_hash_equals struct SimpleCrosslinkBindCallback
    "decimated_2mon site id to act on"
    lbsid::Int

    "link_2mon type id of link_2mon to add"
    ltid::Int

    "new state of both the monomers after binding"
    newstate::MonomerState

    diffusing_net_stoich::Vector{Pair{Int, Int}}
end

function (g::SimpleCrosslinkBindCallback)(c::Context, cid)::Union{Nothing,MonomerName}
    #get the monomer names of the two monomers
    maybemonomers = pickrandom_decimated_2mon_site(c, cid, g.lbsid)
    if isnothing(maybemonomers)
        return
    end
    minusname, plusname = maybemonomers
    #get the current distance between the monomers
    minuspos = mon_position(c, minusname)
    pluspos = mon_position(c, plusname)
    dist = norm_fast(minuspos - pluspos)
    #make the new link_2mon state based on the default with L0 changed
    #add the link_2mon
    chem_newlink_2mon!(c, g.ltid, minusname=>plusname; 
        changedmechstate = (L0 = dist,),
    )
    #set the new monomer states
    chem_setmonomerstate!(c, minusname, g.newstate)
    chem_setmonomerstate!(c, plusname, g.newstate)
    #use the diffusing species
    for (id, amount) in g.diffusing_net_stoich
        chem_adddiffusingcount!(c, id, cid, amount)
    end
    return minusname
end

function errorcheck_addcallback(g::SimpleCrosslinkBindCallback,s::MEDYAN.SysDef)
    s.link_2mon_params[g.ltid].defaultstate.mechstate.L0
    errorcheck_diffusing_species_exist(g.diffusing_net_stoich,s)
end


"""
Callback that will crosslink two monomers with a motor.

Uses the default link_2mon state, but
sets the mechstate.L0 to the current distance between the monomers
sets the chemstate.numHeads to a random int between numHeadsMin and numHeadsMax
Returns the monomer name of the minus end of the new link_2mon, 
    or nothing if rejected.

$(TYPEDFIELDS)
"""
@auto_hash_equals struct SimpleMotorBindCallback
    "decimated_2mon site id to act on"
    lbsid::Int

    "link_2mon type id of link_2mon to add"
    ltid::Int

    numHeadsMax::Int

    numHeadsMin::Int

    "new state of both the monomers after binding"
    newstate::MonomerState

    diffusing_net_stoich::Vector{Pair{Int, Int}}
end

function (g::SimpleMotorBindCallback)(c::Context, cid)::Union{Nothing,MonomerName}
    #get the monomer names of the two monomers
    maybemonomers = pickrandom_decimated_2mon_site(c, cid, g.lbsid)
    if isnothing(maybemonomers)
        return
    end
    minusname, plusname = maybemonomers
    #get the current distance between the monomers
    minuspos = mon_position(c, minusname)
    pluspos = mon_position(c, plusname)
    dist = norm_fast(minuspos - pluspos)
    #make the new link_2mon state based on the default with L0 changed
    #add the link_2mon
    chem_newlink_2mon!(c, g.ltid, minusname=>plusname;
        changedmechstate = (L0 = dist,),
        changedchemstate = (numHeads = rand(g.numHeadsMin:g.numHeadsMax),),
    )
    #set the new monomer states
    chem_setmonomerstate!(c, minusname, g.newstate)
    chem_setmonomerstate!(c, plusname, g.newstate)
    for (id, amount) in g.diffusing_net_stoich
        chem_adddiffusingcount!(c, id, cid, amount)
    end
    return minusname
end

function errorcheck_addcallback(g::SimpleMotorBindCallback,s::MEDYAN.SysDef)
    s.link_2mon_params[g.ltid].defaultstate.chemstate.numHeads
    s.link_2mon_params[g.ltid].defaultstate.mechstate.L0
    errorcheck_diffusing_species_exist(g.diffusing_net_stoich,s)
end


"""
Callback that will step one end of a motor.

If the step fails, the motor will stay in its current state.
returns true if step made.

$(TYPEDFIELDS)
"""
Base.@kwdef struct SimpleMotorStepCallback
    "link_2mon site of the motor step model, 
    the site must have `walking_direction` and `isminusend` properties, 
    for example `Link2MonSiteMotorStall`"
    lsid::Int

    "link_2mon type id of the motor to move"
    ltid::Int

    "new state of the monomer after unbinding"
    unboundstate::MonomerState

    "new state of the monomer after binding"
    boundstate::MonomerState

    "Set of monomer states that the motor cannot walk over"
    blockstates::Vector{MonomerState} = []

    "how many monomers to step"
    stepsize::Int = 1

    diffusing_net_stoich::Vector{Pair{Int, Int}} = []
end

function (g::SimpleMotorStepCallback)(c::Context, cid)::Bool
    maybelink_2mon = pickrandomlink_2mon_site(c, cid, g.ltid, g.lsid)
    if isnothing(maybelink_2mon)
        return false
    end
    lid,minusname,plusname = maybelink_2mon
    stepmodel = c.link_2mon_sites[g.ltid][g.lsid].site
    oldname = stepmodel.isminusend ? minusname : plusname
    oldmid = oldname.mid
    newmid = oldmid + stepmodel.walking_direction * g.stepsize
    newname = @set oldname.mid = newmid
    #check if the new monomer exists
    monstates = fil_mon_states(c, oldname.ftid, oldname.fid)
    if newmid < firstindex(monstates) || newmid > lastindex(monstates)
        return false
    end
    #check if the new monomer is in the right state
    if monstates[newmid] != g.unboundstate
        return false
    end
    #check if the monomer walks over any of the blocking states.
    if !isdisjoint(g.blockstates, @view(monstates[min(newmid,oldmid)+1 : max(newmid,oldmid)-1]))
        return false
    end
    #set the old monomer state to unbound
    chem_setmonomerstate!(c, oldname, g.unboundstate)
    #set the new monomer state to bound
    chem_setmonomerstate!(c, newname, g.boundstate)
    #remove the old link_2mon and move it to newname
    link_2mon_state = get_state(c.link_2mon_data[g.ltid], lid)
    chem_removelink_2mon!(c, g.ltid, lid)
    if stepmodel.isminusend
        chem_newlink_2mon!(c, g.ltid, newname=>plusname, link_2mon_state)
    else
        chem_newlink_2mon!(c, g.ltid, minusname=>newname, link_2mon_state)
    end
    for (id, amount) in g.diffusing_net_stoich
        chem_adddiffusingcount!(c, id, cid, amount)
    end
    return true
end

function errorcheck_addcallback(g::SimpleMotorStepCallback,s::MEDYAN.SysDef)
    s.link_2mon_site[g.ltid][g.lsid].site.isminusend
    s.link_2mon_site[g.ltid][g.lsid].site.walking_direction
    errorcheck_diffusing_species_exist(g.diffusing_net_stoich,s)
end


"""
Callback that will unbind a crosslink between two monomers
Returns the monomer name of the minus end of the removed link_2mon, 
    or nothing if rejected.

$(TYPEDFIELDS)
"""
@auto_hash_equals struct UnbindingLink2MonCallback
    "link_2mon type id of link_2mon to remove"
    ltid::Int

    "link_2mon site id to act on"
    lsid::Int

    "new state of the minus end monomer after unbinding"
    minusnewstate::MonomerState

    "new state of the plus end monomer after unbinding"
    plusnewstate::MonomerState

    diffusing_net_stoich::Vector{Pair{Int, Int}}
end

function (g::UnbindingLink2MonCallback)(c::Context, cid)::Union{Nothing,MonomerName}
    #get the monomer name of the link_2mon
    maybelink_2mon = pickrandomlink_2mon_site(c, cid, g.ltid, g.lsid)
    if isnothing(maybelink_2mon)
        return
    end
    lid,minusname,plusname = maybelink_2mon
    #remove the link_2mon
    chem_removelink_2mon!(c, g.ltid, lid)
    #set the new monomer states
    chem_setmonomerstate!(c, minusname, g.minusnewstate)
    chem_setmonomerstate!(c, plusname, g.plusnewstate)
    for (id, amount) in g.diffusing_net_stoich
        chem_adddiffusingcount!(c, id, cid, amount)
    end
    return minusname
end

function errorcheck_addcallback(g::UnbindingLink2MonCallback,s::MEDYAN.SysDef)
    errorcheck_diffusing_species_exist(g.diffusing_net_stoich,s)
end

"""
Callback that will buil a cadherin between one vertex and one monomer.

Uses the default cadherin state, but
sets the mechstate.L0 to the current distance between the monomers
Returns the vertex name of the new cadherin, 
    or nothing if rejected.

$(TYPEDFIELDS)
"""
@auto_hash_equals struct SimpleCadherinBindCallback
    "possible cadherin site id to act on"
    pcadsid::Int

    "cadherin type id of cadherin to add"
    cadtid::Int

    "new state of the monomer after binding"
    newmonomerstate::MonomerState
end

function (g::SimpleCadherinBindCallback)(c::Context, cid)::Union{Nothing,VertexName}
    possiblecadherinsite = pickrandompossiblecadherinsite(c, cid, g.pcadsid)
    if isnothing(possiblecadherinsite)
        return
    end
    vertexname, monomername = possiblecadherinsite
    #get the current distance between the monomers
    m = c.membranes[vertexname.membraneindex]
    vindx = m.metaattr.id2index_vertex[vertexname.vid]
    vertexpos = m.vertices.attr.coord[vindx]
    monomerpos = mon_position(c, monomername)
    dist = norm_fast(vertexpos - monomerpos)
    #add the cadherin
    chemstate = (;)
    mechstate = (L0 = dist,)
    cadherinstate = CadherinState(chemstate, mechstate)
    chem_newcadherin!(c, g.cadtid, vertexname=>monomername, cadherinstate)
    #set the new monomer state
    #when set the monomer state as bound, no cadherin can bind to this monomers
    chem_setmonomerstate!(c, monomername, g.newmonomerstate)
    return vertexname
end

function errorcheck_addcallback(g::SimpleCadherinBindCallback,s::MEDYAN.SysDef)
    s.cadherinparams[g.cadtid].defaultstate.mechstate.L0
end


"""
Callback that will unbind a cadherin between one vertex and one monomer
Returns the vertex name of the removed cadherin, 
    or nothing if rejected.

$(TYPEDFIELDS)
"""
@auto_hash_equals struct UnbindingCadherinCallback
    "cadherin type id of cadherin to remove"
    cadtid::Int

    "cadherin site id to act on"
    cadsid::Int

    "new state of the monomer after unbinding"
    monomernewstate::MonomerState
end

function (g::UnbindingCadherinCallback)(c::Context, cid)::VertexName
    cadherinsite = pickrandomcadherinsite(c, cid, g.cadtid, g.cadsid)
    if isnothing(cadherinsite)
        return
    end
    cadidx,vertexname,monomername = cadherinsite
    endnames = c.cadherindata[g.cadtid].cadidx_to_endnames[cadidx]
    #remove the cadherin
    chem_removecadherin!(c, g.cadtid, endnames)
    #set the new monomer state
    chem_setmonomerstate!(c, monomername, g.monomernewstate)
    return vertexname
end

"""
Callback that will remove the filament at a filamentendsite in the compartment.

$(TYPEDFIELDS)
"""
struct FilamentDestructionCallback
    "type of filament this acts on"
    ftid::Int

    "filament end site id to act on"
    fesid::Int

    "pairs of id and net change amount"
    diffusing_net_stoich::Vector{Pair{Int,Int}}
end

function (g::FilamentDestructionCallback)(c::MEDYAN.Context, cid)
    site = c.filamentendsites[g.ftid][g.fesid].site
    name = MEDYAN.pickrandomfilamentendsite(c, cid, g.ftid, g.fesid)
    if isnothing(name)
        return
    end
    chem_removefilament!(c; ftid=name.ftid, fid=name.fid)
    for (id, amount) in g.diffusing_net_stoich
        chem_adddiffusingcount!(c, id, cid, amount)
    end
end

function errorcheck_addcallback(g::FilamentDestructionCallback,s::MEDYAN.SysDef)
    errorcheck_diffusing_species_exist(g.diffusing_net_stoich,s)
end
