"""
Commonly used chemistry callbacks,

function-like objects that get called with arguments of context::Context, compartmentid::Integer
"""

using Random
using StaticArrays
using LinearAlgebra
using Setfield

"""
Error check callbacks added to the MEDYAN.SysDef
Called before adding the callback
By default this doesn't do anything. It can be overloaded to error if there is an issue.

This is useful, because otherwise, callbacks can only generate errors when called in the simulation.
"""
function errorcheck_addcallback(callback,s::MEDYAN.SysDef)
    return nothing
end

"""
check if monomer states exist in s
"""
function errorcheck_statesexist(states,ftid,s::MEDYAN.SysDef)
    filtypename = s.agent_names.filamentnames[ftid][1]
    for state in states
        if !(state in s.state[ftid])
            error(
                """unknown state $(state) 
                on filament type $(filtypename), 
                max state $(maximum(s.state[ftid]))"""
            )
        end
    end
end

"""
check if diffusing species in stoich exist in s
"""
function errorcheck_diffusing_species_exist(stoich,s::MEDYAN.SysDef)
    for (id, amount) in stoich
        id in values(s.diffusing) || error("unknown diffusing species id $(id)")
    end
end

"""
Callback that will change the monomer state at a filamentsite in the compartment
Returns the place of the center monomer of the site changed or nothing.

$(TYPEDFIELDS)

"""
struct GeneralFilamentSiteCallback
    "type of filament this acts on"
    ftid::Int

    "filament site id to act on"
    fsid::Int

    "index of center monomer in newstates"
    center::Int

    "new monomer states"
    newstates::Vector{MonomerState}

    "diffusing species net stoich"
    diffusing_net_stoich::Vector{Pair{Int, Int}}
end
Base.:(==)(a::T,b::T) where T<:GeneralFilamentSiteCallback = struct_equal(a, b)
Base.hash(x::GeneralFilamentSiteCallback, h::UInt) = struct_hash(x,h)

function (g::GeneralFilamentSiteCallback)(c::Context, cid)
    name = pickrandomfilamentsite(c, cid, g.ftid, g.fsid)
    if isnothing(name)
        return
    end
    center = _get_fila_mono_idx(c, name)
    for i in eachindex(g.newstates)
        update_fila_mono_state!(c, FilaMonoIdx(c, center, i - g.center), g.newstates[i])
    end
    for (id, amount) in g.diffusing_net_stoich
        chem_adddiffusingcount!(c, id, cid, amount)
    end
    return center
end

function errorcheck_addcallback(g::GeneralFilamentSiteCallback,s::MEDYAN.SysDef)
    errorcheck_statesexist(g.newstates,g.ftid,s)
    errorcheck_diffusing_species_exist(g.diffusing_net_stoich,s)
end


"""
Callback that will change the monomer state and or depolymerize/polymerize at a filamentendsite in the compartment

$(TYPEDFIELDS)
"""
struct GeneralFilamentEndCallback
    "type of filament this acts on"
    ftid::Int

    "filament end site id to act on"
    fesid::Int

    "number of monomers to add if positive,
     remove if negative,
     just change states if zero"
    Δnummonomers::Int

    "new monomer states
    if the site isminusend then the end state is newstates[begin]
    else it is newstates[end]"
    newstates::Vector{MonomerState}

    diffusing_net_stoich::Vector{Pair{Int, Int}}
end
Base.:(==)(a::T,b::T) where T<:GeneralFilamentEndCallback = struct_equal(a, b)
Base.hash(x::GeneralFilamentEndCallback, h::UInt) = struct_hash(x,h)

function (g::GeneralFilamentEndCallback)(c::Context, cid)
    site = c.filamentendsites[g.ftid][g.fesid].site
    name = pickrandomfilamentendsite(c, cid, g.ftid, g.fesid)
    if isnothing(name)
        return
    end
    fid = name.fid
    oldendmid = name.mid
    numpolyerized = max(g.Δnummonomers, 0)
    numdepolyerized = max(-g.Δnummonomers, 0)
    nummonomerschanged = length(g.newstates) - numpolyerized
    for i in 1:numpolyerized
        stateidx = isminusend(site) ? (numpolyerized - i + 1) : (nummonomerschanged + i)
        polymerize_fila!(c, FilaTipIdx(c, _get_fila_idx(c, g.ftid, fid), isminusend(site)), g.newstates[stateidx])
    end
    for i in 1:numdepolyerized
        depolymerize_fila!(c, FilaTipIdx(c, _get_fila_idx(c, g.ftid, fid), isminusend(site)))
    end
    if isminusend(site)
        for i in 1:nummonomerschanged
            stateidx = i + numpolyerized
            mid = i + oldendmid + numdepolyerized - 1
            update_fila_mono_state!(c, _get_fila_mono_idx(c, MonomerName(g.ftid, fid, mid)), g.newstates[stateidx])
        end
    else
        for i in 1:nummonomerschanged
            stateidx = i
            mid = i + oldendmid - nummonomerschanged - numdepolyerized
            update_fila_mono_state!(c, _get_fila_mono_idx(c, MonomerName(g.ftid, fid, mid)), g.newstates[stateidx])
        end
    end
    for (id, amount) in g.diffusing_net_stoich
        chem_adddiffusingcount!(c, id, cid, amount)
    end
end

function errorcheck_addcallback(g::GeneralFilamentEndCallback,s::MEDYAN.SysDef)
    errorcheck_statesexist(g.newstates,g.ftid,s)
    errorcheck_diffusing_species_exist(g.diffusing_net_stoich,s)
end

"""
Callback that will add a new branched filament at a filamentsite in the compartment

$(TYPEDFIELDS)
"""
struct FilamentSiteBranchingCallback
    "filament site callback"
    filamentsitecallback::GeneralFilamentSiteCallback

    "link type id"
    ltid::Int

    "new filament type id"
    newftid::Int

    "is the new filament linked by its minus end?"
    attach_fil_minus_end::Bool

    "does the first place of the link attach to the old filament?"
    link_old_minus::Bool

    "monomer states on new filament"
    newstates::Vector{MonomerState}

    diffusing_net_stoich::Vector{Pair{Int, Int}}
end
Base.:(==)(a::T,b::T) where T<:FilamentSiteBranchingCallback = struct_equal(a, b)
Base.hash(x::FilamentSiteBranchingCallback, h::UInt) = struct_hash(x,h)
function (g::FilamentSiteBranchingCallback)(c::Context, cid)
    parentplace = g.filamentsitecallback(c, cid)
    if isnothing(parentplace)
        return
    end
    spacing = c.filamentmechparams[g.newftid].spacing
    parentpos = get_position(c, parentplace)
    newpos = parentpos + (1//2 * spacing) * randn(typeof(parentpos))
    newdir = normalize_fast(randn(typeof(parentpos)))
    nummonomers = length(g.newstates)
    node_positions = if g.attach_fil_minus_end
        [newpos, newpos +  nummonomers * spacing * newdir]
    else
        [newpos +  nummonomers * spacing * newdir, newpos]
    end
    attachedmid = g.attach_fil_minus_end ? 0 : -1
    minusendmid = g.attach_fil_minus_end ? 0 : -nummonomers
    newfila_idx = make_fila!(c;
        type = g.newftid,
        node_mids = [minusendmid,],
        mono_states = g.newstates,
        node_positions,
    )
    childattachplace = FilaMonoIdx(FilaIdx(c, newfila_idx), attachedmid)
    minusplace = g.link_old_minus ? parentplace : childattachplace
    plusplace = g.link_old_minus ? childattachplace : parentplace
    make_link!(c;
        type = g.ltid,
        places = (minusplace, plusplace)
    )
    for (id, amount) in g.diffusing_net_stoich
        chem_adddiffusingcount!(c, id, cid, amount)
    end
    return
end
function errorcheck_addcallback(g::FilamentSiteBranchingCallback,s::MEDYAN.SysDef)
    errorcheck_addcallback(g.filamentsitecallback,s)
    errorcheck_statesexist(g.newstates,g.newftid,s)
    errorcheck_diffusing_species_exist(g.diffusing_net_stoich,s)
end

"""
Callback that will crosslink two monomers.

Uses the default link state, but
sets the bond state L0 to the current distance between the monomers.

$(TYPEDFIELDS)
"""
struct SimpleCrosslinkBindCallback
    "decimated_2mon site id to act on"
    lbsid::Int

    "link type id of link to add"
    link_type::Int

    "new state of both the monomers after binding"
    newstate::MonomerState

    diffusing_net_stoich::Vector{Pair{Int, Int}}
end
Base.:(==)(a::T,b::T) where T<:SimpleCrosslinkBindCallback = struct_equal(a, b)
Base.hash(x::SimpleCrosslinkBindCallback, h::UInt) = struct_hash(x,h)
function (g::SimpleCrosslinkBindCallback)(c::Context, cid)
    #get the monomer names of the two monomers
    maybemonomers = pickrandom_decimated_2mon_site(c, cid, g.lbsid)
    if isnothing(maybemonomers)
        return 0
    end
    minusplace, plusplace = maybemonomers
    #get the current distance between the monomers
    minuspos = get_position(c, minusplace)
    pluspos = get_position(c, plusplace)
    dist = norm_fast(minuspos - pluspos)
    #make the new link state based on the default with L0 changed
    make_link!(c;
        type=g.link_type,
        places=(minusplace, plusplace),
        bond_states=((;L0 = dist,),),
    )
    #set the new monomer states
    update_fila_mono_state!(c, minusplace, g.newstate)
    update_fila_mono_state!(c, plusplace, g.newstate)
    #use the diffusing species
    for (id, amount) in g.diffusing_net_stoich
        chem_adddiffusingcount!(c, id, cid, amount)
    end
    return 1
end
function errorcheck_addcallback(g::SimpleCrosslinkBindCallback,s::MEDYAN.SysDef)
    errorcheck_diffusing_species_exist(g.diffusing_net_stoich,s)
end

"""
Callback that will crosslink two monomers with a motor.

Uses the default link state, but
sets the bond state L0 to the current distance between the monomers
sets the state numHeads to a random int between numHeadsMin and numHeadsMax

$(TYPEDFIELDS)
"""
struct SimpleMotorBindCallback
    "decimated_2mon site id to act on"
    lbsid::Int

    "link type id of link to add"
    link_type::Int

    numHeadsMax::Int

    numHeadsMin::Int

    "new state of both the monomers after binding"
    newstate::MonomerState

    diffusing_net_stoich::Vector{Pair{Int, Int}}
end
Base.:(==)(a::T,b::T) where T<:SimpleMotorBindCallback = struct_equal(a, b)
Base.hash(x::SimpleMotorBindCallback, h::UInt) = struct_hash(x,h)
function (g::SimpleMotorBindCallback)(c::Context, chem_voxel)::Int64
    #get the monomer names of the two monomers
    maybemonomers = pickrandom_decimated_2mon_site(c, chem_voxel, g.lbsid)
    if isnothing(maybemonomers)
        return 0
    end
    minusplace, plusplace = maybemonomers
    #get the current distance between the monomers
    minuspos = get_position(c, minusplace)
    pluspos = get_position(c, plusplace)
    dist = norm_fast(minuspos - pluspos)
    #make the new link state based on the default with L0 changed
    make_link!(c;
        type=g.link_type,
        places=(minusplace, plusplace),
        state=(;numHeads = rand(g.numHeadsMin:g.numHeadsMax),),
        bond_states=((;L0 = dist,),),
    )
    #set the new monomer states
    update_fila_mono_state!(c, minusplace, g.newstate)
    update_fila_mono_state!(c, plusplace, g.newstate)
    for (id, amount) in g.diffusing_net_stoich
        add_diffusing_count!(c;species=id, chem_voxel, amount)
    end
    return 1
end

function errorcheck_addcallback(g::SimpleMotorBindCallback,s::MEDYAN.SysDef)
    errorcheck_diffusing_species_exist(g.diffusing_net_stoich,s)
end


"""
Callback that will buil a cadherin between one vertex and one monomer.

Uses the default cadherin state, but
sets the mechstate.L0 to the current distance between the monomers
Returns the vertex name of the new cadherin, 
    or nothing if rejected.

$(TYPEDFIELDS)
"""
struct SimpleCadherinBindCallback
    "possible cadherin site id to act on"
    pcadsid::Int

    "cadherin type id of cadherin to add"
    cadtid::Int

    "new state of the monomer after binding"
    newmonomerstate::MonomerState
end
Base.:(==)(a::T,b::T) where T<:SimpleCadherinBindCallback = struct_equal(a, b)
Base.hash(x::SimpleCadherinBindCallback, h::UInt) = struct_hash(x,h)

function (g::SimpleCadherinBindCallback)(c::Context, cid)::Int
    possiblecadherinsite = pickrandompossiblecadherinsite(c, cid, g.pcadsid)
    if isnothing(possiblecadherinsite)
        return 0
    end
    vertex_place, monomer_place = possiblecadherinsite
    #get the current distance between the monomers
    vertexpos = get_position(c, vertex_place)
    monomerpos = get_position(c, monomer_place)
    dist = norm_fast(vertexpos - monomerpos)
    #add the cadherin
    chemstate = (;)
    mechstate = (L0 = dist,)
    cadherinstate = CadherinState(chemstate, mechstate)
    chem_newcadherin!(c, g.cadtid, _get_vertex_name(c, vertex_place)=>_get_monomer_name(c, monomer_place), cadherinstate)
    #set the new monomer state
    #when set the monomer state as bound, no cadherin can bind to this monomers
    update_fila_mono_state!(c, monomer_place, g.newmonomerstate)
    return 1
end

function errorcheck_addcallback(g::SimpleCadherinBindCallback,s::MEDYAN.SysDef)
    s.cadherinparams[g.cadtid].defaultstate.mechstate.L0
end


"""
Callback that will unbind a cadherin between one vertex and one monomer
Returns the vertex name of the removed cadherin, 
    or nothing if rejected.

$(TYPEDFIELDS)
"""
struct UnbindingCadherinCallback
    "cadherin type id of cadherin to remove"
    cadtid::Int

    "cadherin site id to act on"
    cadsid::Int

    "new state of the monomer after unbinding"
    monomernewstate::MonomerState
end
Base.:(==)(a::T,b::T) where T<:UnbindingCadherinCallback = struct_equal(a, b)
Base.hash(x::UnbindingCadherinCallback, h::UInt) = struct_hash(x,h)

function (g::UnbindingCadherinCallback)(c::Context, cid)::VertexName
    cadherinsite = pickrandomcadherinsite(c, cid, g.cadtid, g.cadsid)
    if isnothing(cadherinsite)
        return
    end
    cadidx,vertexname,monomername = cadherinsite
    endnames = c.cadherindata[g.cadtid].cadidx_to_endnames[cadidx]
    #remove the cadherin
    chem_removecadherin!(c, g.cadtid, endnames)
    #set the new monomer state
    update_fila_mono_state!(c, _get_fila_mono_idx(c, monomername), g.monomernewstate)
    return vertexname
end

"""
Callback that will remove the filament at a filamentendsite in the compartment.

$(TYPEDFIELDS)
"""
struct FilamentDestructionCallback
    "type of filament this acts on"
    ftid::Int

    "filament end site id to act on"
    fesid::Int

    "pairs of id and net change amount"
    diffusing_net_stoich::Vector{Pair{Int,Int}}
end
Base.:(==)(a::T,b::T) where T<:FilamentDestructionCallback = struct_equal(a, b)
Base.hash(x::FilamentDestructionCallback, h::UInt) = struct_hash(x,h)

function (g::FilamentDestructionCallback)(c::MEDYAN.Context, cid)
    site = c.filamentendsites[g.ftid][g.fesid].site
    name = MEDYAN.pickrandomfilamentendsite(c, cid, g.ftid, g.fesid)
    if isnothing(name)
        return
    end
    place = _get_fila_mono_idx(c, name)
    remove_fila!(c, FilaIdx(c, place))
    for (id, amount) in g.diffusing_net_stoich
        chem_adddiffusingcount!(c, id, cid, amount)
    end
end

function errorcheck_addcallback(g::FilamentDestructionCallback,s::MEDYAN.SysDef)
    errorcheck_diffusing_species_exist(g.diffusing_net_stoich,s)
end
