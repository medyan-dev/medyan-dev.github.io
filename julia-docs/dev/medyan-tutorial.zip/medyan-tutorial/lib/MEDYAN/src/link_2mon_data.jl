using FixedPointNumbers
using ElasticArrays


function Link2MonData(
        id,
        params,
        num_compartments,
        num_link_2mon_sites,
        num_mon_link_2mon_sites,
    )
    num_sites = num_link_2mon_sites + num_mon_link_2mon_sites
    if iszero(num_sites)
        Link2MonData{typeof(params.defaultstate),typeof(params.mechparams)}(
            id,
            params,
            [], #states
            Ref(1), #next_lid
            Dict(), #lid_to_lidx
            [], #lidx_to_lid
            [], #lidx_to_endnames
            false, #track_sitecounts
            Ref(true), #cache_valid
            [], #lidx_to_cid_clidx
            [], #cid_clidx_to_lidx    
            [], #compartment_sitecounts
            0, #mlsid_offset
            [], #chem_voxel_mon_counts
        )
    else
        chem_voxel_mon_counts = if iszero(num_mon_link_2mon_sites)
            []
        else
            [ElasticArray{Q31f32}(undef, num_mon_link_2mon_sites, 0) for i in 1:num_compartments]
        end
        Link2MonData{typeof(params.defaultstate),typeof(params.mechparams)}(
            id,
            params,
            [], #states
            Ref(1), #next_lid
            Dict(), #lid_to_lidx
            [], #lidx_to_lid
            [], #lidx_to_endnames
            true, #track_sitecounts
            Ref(true), #cache_valid
            [], #lidx_to_cid_clidx
            [[] for i in 1:num_compartments], #cid_clidx_to_lidx    
            [ElasticArray{Q31f32}(undef, num_sites, 0) for i in 1:num_compartments], #compartment_sitecounts
            num_link_2mon_sites,
            chem_voxel_mon_counts,
        )
    end
end

"""
Return the number of link_2mons
"""
function num_link_2mons(link_2mon_data::Link2MonData)
    length(link_2mon_data.states)
end

function get_state(link_2mon_data::Link2MonData, lid::Int64)
    lidx = link_2mon_data.lid_to_lidx[lid]
    link_2mon_data.states[lidx]
end

function get_endnames(link_2mon_data::Link2MonData, lid::Int64)
    lidx = link_2mon_data.lid_to_lidx[lid]
    link_2mon_data.lidx_to_endnames[lidx]
end

"""
Return a tuple of (linker id, minus end, plus end) of a random link_2mon_site, or return nothing if rejected
weighted by counts, using the default RNG
"""
function pickrandomlink_2mon_site(link_2mon_data::Link2MonData,totalsites,cid,lsid)::Union{Tuple{Int64,MonomerName,MonomerName},Nothing}
    @assert link_2mon_data.track_sitecounts
    @assert link_2mon_data.cache_valid[]
    if iszero(totalsites)
        return
    end
    sitecountscid = link_2mon_data.compartment_sitecounts[cid]
    sitecounts = @view(sitecountscid[lsid,:])
    u::Q31f32= Q31f32(totalsites*rand())
    for clidx in 1:length(sitecounts)
        u -= sitecounts[clidx]
        if u ≤ 0
            lidx = link_2mon_data.cid_clidx_to_lidx[cid][clidx]
            endnames = link_2mon_data.lidx_to_endnames[lidx]
            lid = link_2mon_data.lidx_to_lid[lidx]
            return (lid, endnames...)
        end
    end
    return
end

"""
Return a tuple of (linker id, minus end, other end) of a random link_2mon_site, or return nothing if rejected
weighted by counts, using the default RNG
"""
function pickrandommon_link_2mon_site(
        link_2mon_data::Link2MonData,
        totalsites,
        cid,
        mlsid,
        c::Context,
    )::Union{Tuple{Int64,MonomerName,MonomerName},Nothing}
    @assert link_2mon_data.track_sitecounts
    @assert link_2mon_data.cache_valid[]
    @assert !isempty(link_2mon_data.chem_voxel_mon_counts)
    if iszero(totalsites)
        return
    end
    site = c.mon_link_2mon_sites[link_2mon_data.id][mlsid]
    sitecountscid = link_2mon_data.compartment_sitecounts[cid]
    sitecounts = @view(sitecountscid[mlsid+link_2mon_data.mlsid_offset,:])
    moncountscid = link_2mon_data.chem_voxel_mon_counts[cid]
    monomercounts = @view(moncountscid[mlsid,:])
    u::Q31f32= Q31f32(totalsites*rand())
    for clidx in 1:length(monomercounts)
        monomercount = monomercounts[clidx]
        sitecount::Q31f32 = monomercount * sitecounts[clidx]
        u -= sitecount
        if u ≤ 0
            lidx = link_2mon_data.cid_clidx_to_lidx[cid][clidx]
            minusname = link_2mon_data.lidx_to_endnames[lidx][1]
            maybe_other_name = random_nearby_monomer(
                c,
                mon_position(c, minusname),
                getftid(site.site),
                cutoff_distance(site.site),
                Int64(monomercount),
            )
            if isnothing(maybe_other_name)
                return
            else
                lid = link_2mon_data.lidx_to_lid[lidx]
                return (lid, minusname, maybe_other_name)
            end
        end
    end
    return
end

"""
Reset cached data, based on `c`.
reset c.chemistryengine based on the new site counts
"""
function resetlink_2mons!(link_2mon_data::Link2MonData,c::Context)
    if link_2mon_data.track_sitecounts
        num_links = length(link_2mon_data.states)
        # wipe all compartment cache
        empty!.(link_2mon_data.cid_clidx_to_lidx)

        resize!(link_2mon_data.lidx_to_cid_clidx, num_links)

        # go through all link_2mons and set link_2mon_data.cid_clidx_to_lidx and link_2mon_data.lidx_to_cid_clidx
        for lidx in 1:num_links
            endnames = link_2mon_data.lidx_to_endnames[lidx]
            # get cid of the minusend
            cid = get_compartment_id(c,endnames[1])
            clidx_to_lidx = link_2mon_data.cid_clidx_to_lidx[cid]
            push!(clidx_to_lidx,lidx)
            clidx = length(clidx_to_lidx)
            link_2mon_data.lidx_to_cid_clidx[lidx] = (cid,clidx)
        end

        # reset link_2mon_data.compartment_sitecounts and chemistryengine
        for cid in 1:length(link_2mon_data.compartment_sitecounts)
            sitecountscid = link_2mon_data.compartment_sitecounts[cid]
            clidx_to_lidx = link_2mon_data.cid_clidx_to_lidx[cid]
            numlink_2mons = length(clidx_to_lidx)
            ElasticArrays.resize_lastdim!(sitecountscid, numlink_2mons)
            lidxs = clidx_to_lidx
            endnames = link_2mon_data.lidx_to_endnames[lidxs]
            states = link_2mon_data.states[lidxs]
            link_2mon_mechparams = link_2mon_data.params.mechparams
            statetriplets = map(namepair->map(name->mon_3states(c, name),namepair),endnames)
            position_plusvectors = map(namepair->map(name->mon_position_plusvector(c, name),namepair),endnames)
            foreach(c.link_2mon_sites[link_2mon_data.id]) do site
                totalcount = zero(Q31f32)
                for clidx in 1:numlink_2mons
                    s = Q31f32(link_2mon_sitecount(
                        site.site,states[clidx],link_2mon_mechparams,
                        endnames[clidx][1].ftid, endnames[clidx][2].ftid,
                        statetriplets[clidx][1],statetriplets[clidx][2],
                        position_plusvectors[clidx][1][1],
                        position_plusvectors[clidx][2][1],
                        position_plusvectors[clidx][1][2],
                        position_plusvectors[clidx][2][2],
                    ))
                    sitecountscid[site.id, clidx] = s
                    totalcount += s
                end
                setfixedspeciescount!(c.chemistryengine,site.fxsid,cid,totalcount)
            end
            if !isempty(link_2mon_data.chem_voxel_mon_counts)
                moncountscid = link_2mon_data.chem_voxel_mon_counts[cid]
                ElasticArrays.resize_lastdim!(moncountscid, numlink_2mons)
                foreach(c.mon_link_2mon_sites[link_2mon_data.id]) do site
                    local totalcount::Q31f32 = zero(Q31f32)
                    for clidx in 1:numlink_2mons
                        local sitecount_mult = Q31f32(mon_link_2mon_sitecount(site.site, states[clidx]))
                        local monomercount = Int32(num_nearby_monomers(
                            c,
                            position_plusvectors[clidx][1][1],
                            getftid(site.site),
                            cutoff_distance(site.site), # Maybe this should have an added eps.
                        ))
                        sitecountscid[site.id + link_2mon_data.mlsid_offset, clidx] = sitecount_mult
                        moncountscid[site.id, clidx] = monomercount

                        totalcount += Q31f32(monomercount*sitecount_mult)
                    end
                    setfixedspeciescount!(c.chemistryengine,site.fxsid,cid,totalcount)
                end
            end
        end
    end
    link_2mon_data.cache_valid[] = true
    nothing
end

"""
add a link_2mon. minusname monomer must not be the minus end of another link_2mon of this type.

if `new_lid` isn't nothing, it will be used for the id of the new linker. 

Return the link_2mon id.
"""
function newlink_2mon!(
        link_2mon_data::Link2MonData,
        c::Context,
        endnames::Pair{MonomerName,MonomerName},
        link_2mon_state::Link2MonState;
        new_lid::Union{Nothing,Int64}=nothing,
    )
    old_next_lid = link_2mon_data.next_lid[]
    lid::Int64 = if isnothing(new_lid)
        @argcheck old_next_lid > 0
        @argcheck old_next_lid ∉ keys(link_2mon_data.lid_to_lidx)
        old_next_lid
    else
        @argcheck new_lid > 0
        @argcheck new_lid ∉ keys(link_2mon_data.lid_to_lidx)
        new_lid
    end
    link_2mon_data.next_lid[] = max(old_next_lid, Base.checked_add(lid, 1))
    @assert link_2mon_data.next_lid[] ∉ keys(link_2mon_data.lid_to_lidx)

    push!(link_2mon_data.states, link_2mon_state)
    push!(link_2mon_data.lidx_to_endnames, endnames)
    push!(link_2mon_data.lidx_to_lid, lid)
    lidx = length(link_2mon_data.states)
    link_2mon_data.lid_to_lidx[lid] = lidx
    if link_2mon_data.track_sitecounts && checkall(c.validflags, VFS_SEGMENTS)
        # get cid of the minusend
        minusend_pos = mon_position(c, endnames[1])
        cid = get_compartment_id(c, minusend_pos)
        clidx_to_lidx = link_2mon_data.cid_clidx_to_lidx[cid]
        push!(clidx_to_lidx,lidx)
        clidx = length(clidx_to_lidx)
        push!(link_2mon_data.lidx_to_cid_clidx,(cid,clidx))
        sitecountscid = link_2mon_data.compartment_sitecounts[cid]
        ElasticArrays.resize_lastdim!(sitecountscid,clidx)
        sitecountscid[:,end] .= 0
        if !isempty(link_2mon_data.chem_voxel_mon_counts)
            moncountscid = link_2mon_data.chem_voxel_mon_counts[cid]
            ElasticArrays.resize_lastdim!(moncountscid,clidx)
            # get mon_link_2mon nearby monomer counts
            foreach(c.mon_link_2mon_sites[link_2mon_data.id]) do site
                local monomercount = Int32(num_nearby_monomers(
                    c,
                    minusend_pos,
                    getftid(site.site),
                    cutoff_distance(site.site), # Maybe this should have an added eps.
                ))
                moncountscid[site.id, end] = monomercount
            end
        end
        # because the sitecountscid[:,end] are set to zero, the following
        # will add in the correct new site counts to the chem engine.
        setlink_2mon_state!(link_2mon_data, c, lid, link_2mon_state)
    end
    return lid
end

"""
reset c.chemistryengine based on the new site counts
"""
function removelink_2mon!(link_2mon_data::Link2MonData,c::Context,lid::Int64)
    lid in keys(link_2mon_data.lid_to_lidx) || error("link_2mon doesn't exists")
    lidx = link_2mon_data.lid_to_lidx[lid]
    if link_2mon_data.track_sitecounts && checkall(c.validflags, VFS_SEGMENTS)
        cid,clidx = link_2mon_data.lidx_to_cid_clidx[lidx]

        #now move to end of compartment
        clidx_to_lidx = link_2mon_data.cid_clidx_to_lidx[cid]
        lastclidx = length(clidx_to_lidx)
        lastclidx_lidx = clidx_to_lidx[lastclidx]
        clidx_to_lidx[clidx] = lastclidx_lidx
        clidx_to_lidx[lastclidx] = lidx
        link_2mon_data.lidx_to_cid_clidx[lastclidx_lidx] = (cid,clidx)
        link_2mon_data.lidx_to_cid_clidx[lidx] = (cid,lastclidx)
        sitecountscid = link_2mon_data.compartment_sitecounts[cid]
        foreach(c.link_2mon_sites[link_2mon_data.id]) do link_2mon_site
            removeds = sitecountscid[link_2mon_site.id, clidx]
            if !iszero(removeds)
                addfixedspeciescount!(c.chemistryengine,link_2mon_site.fxsid,cid,-removeds)
            end
            sitecountscid[link_2mon_site.id, clidx] = sitecountscid[link_2mon_site.id, lastclidx]
        end
        if !isempty(link_2mon_data.chem_voxel_mon_counts)
            moncountscid = link_2mon_data.chem_voxel_mon_counts[cid]
            foreach(c.mon_link_2mon_sites[link_2mon_data.id]) do site
                local sidx = site.id + link_2mon_data.mlsid_offset
                local sitecount_mult = sitecountscid[sidx, clidx]
                local removed_mon_counts = moncountscid[site.id, clidx]
                local removeds = Q31f32(removed_mon_counts*sitecount_mult)
                if !iszero(removeds)
                    addfixedspeciescount!(c.chemistryengine,site.fxsid,cid,-removeds)
                end
                sitecountscid[sidx, clidx] = sitecountscid[sidx, lastclidx]
                moncountscid[site.id, clidx] = moncountscid[site.id, lastclidx]
            end
            ElasticArrays.resize_lastdim!(moncountscid,lastclidx-1)
        end
        ElasticArrays.resize_lastdim!(sitecountscid,lastclidx-1)

        #copy last link_2mon into link_2mon to delete, then pop arrays.
        
        
        lastcid,lastclidx = link_2mon_data.lidx_to_cid_clidx[end]

        link_2mon_data.lidx_to_cid_clidx[lidx] = (lastcid,lastclidx)
        pop!(link_2mon_data.lidx_to_cid_clidx)

        link_2mon_data.cid_clidx_to_lidx[lastcid][lastclidx] = lidx
        pop!(clidx_to_lidx)
    end
    last_lid = link_2mon_data.lidx_to_lid[end]

    link_2mon_data.lidx_to_endnames[lidx] = link_2mon_data.lidx_to_endnames[end]
    pop!(link_2mon_data.lidx_to_endnames)

    link_2mon_data.states[lidx] = link_2mon_data.states[end]
    pop!(link_2mon_data.states)

    link_2mon_data.lid_to_lidx[last_lid] = lidx
    delete!(link_2mon_data.lid_to_lidx, lid)

    link_2mon_data.lidx_to_lid[lidx] = last_lid
    pop!(link_2mon_data.lidx_to_lid)
    return
end

"""
remove all link_2mons.
does not reset c.chemistryengine based on the new site counts
"""
function emptylink_2mons!(link_2mon_data::Link2MonData)
    empty!(link_2mon_data.states)
    empty!(link_2mon_data.lid_to_lidx)
    empty!(link_2mon_data.lidx_to_lid)
    empty!(link_2mon_data.lidx_to_endnames)
    empty!(link_2mon_data.lidx_to_cid_clidx)
    link_2mon_data.next_lid[] = 1
    foreach(empty!,link_2mon_data.cid_clidx_to_lidx)
    foreach(x->ElasticArrays.resize_lastdim!(x,0),link_2mon_data.compartment_sitecounts)
    foreach(x->ElasticArrays.resize_lastdim!(x,0),link_2mon_data.chem_voxel_mon_counts)
end

"""
reset c.chemistryengine based on the new site counts
"""
function setlink_2mon_state!(link_2mon_data::Link2MonData, c::Context, lid::Int64, link_2mon_state::Link2MonState)
    lidx = link_2mon_data.lid_to_lidx[lid]
    link_2mon_data.states[lidx] = link_2mon_state
    if link_2mon_data.track_sitecounts && checkall(c.validflags, VFS_SEGMENTS)
        resetlink_2mon_sitecounts!(link_2mon_data,c,lid)
        cid,clidx = link_2mon_data.lidx_to_cid_clidx[lidx]
        sitecountscid = link_2mon_data.compartment_sitecounts[cid]
        if !isempty(link_2mon_data.chem_voxel_mon_counts)
            moncountscid = link_2mon_data.chem_voxel_mon_counts[cid]
            foreach(c.mon_link_2mon_sites[link_2mon_data.id]) do site
                local sidx = site.id + link_2mon_data.mlsid_offset
                local olds = sitecountscid[sidx, clidx]
                local news = Q31f32(mon_link_2mon_sitecount(site.site, link_2mon_state))
                local Δs = news-olds
                if !iszero(Δs)
                    local monomercount = moncountscid[site.id, clidx]
                    local sitecountscid[sidx, clidx] = news
                    addfixedspeciescount!(c.chemistryengine,site.fxsid,cid, monomercount*Δs)
                end
            end
        end
    end
    nothing
end

"""
reset c.chemistryengine based on the new site counts.

Used to update link_2mon if monomer states change.
"""
function resetlink_2mon_sitecounts!(link_2mon_data::Link2MonData, c::Context, lid::Int64)
    if link_2mon_data.track_sitecounts
        @assert link_2mon_data.cache_valid[]
        lidx = link_2mon_data.lid_to_lidx[lid]
        endnames = link_2mon_data.lidx_to_endnames[lidx]
        cid,clidx = link_2mon_data.lidx_to_cid_clidx[lidx]
        sitecountscid = link_2mon_data.compartment_sitecounts[cid]
        state = link_2mon_data.states[lidx]
        link_2mon_mechparams = link_2mon_data.params.mechparams
        statetriplets = map(name->mon_3states(c, name),endnames)
        position_plusvectors = map(name->mon_position_plusvector(c, name),endnames)
        foreach(c.link_2mon_sites[link_2mon_data.id]) do link_2mon_site
            olds = sitecountscid[link_2mon_site.id, clidx]
            news = Q31f32(link_2mon_sitecount(
                link_2mon_site.site,state,link_2mon_mechparams,
                endnames[1].ftid, endnames[2].ftid,
                statetriplets[1],statetriplets[2],
                position_plusvectors[1][1],
                position_plusvectors[2][1],
                position_plusvectors[1][2],
                position_plusvectors[2][2],
            ))
            Δs = news-olds
            if !iszero(Δs)
                sitecountscid[link_2mon_site.id, clidx] = news
                addfixedspeciescount!(c.chemistryengine,link_2mon_site.fxsid,cid,Δs)
            end
        end
    end
    return
end



"""
Check if two link_2mon_datas are statistically equal, the internal link_2mon indexes may be different
"""
function statistically_equal(a::Link2MonData,b::Link2MonData)::Bool
    assert_invariants(a)
    assert_invariants(b)
    @assert a.cache_valid[]
    @assert b.cache_valid[]
    a.id == b.id || return false
    a.params == b.params || return false
    keys(a.lid_to_lidx) == keys(b.lid_to_lidx) || return false
    length(a.compartment_sitecounts) == length(b.compartment_sitecounts) || return false
    length(a.chem_voxel_mon_counts) == length(b.chem_voxel_mon_counts) || return false
    a.track_sitecounts == b.track_sitecounts || return false
    a.mlsid_offset == b.mlsid_offset || return false
    for lidx in 1:length(a.states)
        lid = a.lidx_to_lid[lidx]
        blidx = b.lid_to_lidx[lid]
        a.lidx_to_endnames[lidx] == b.lidx_to_endnames[lidx] || return false
        a.states[lidx] == b.states[blidx] || return false
        if a.track_sitecounts
            cid,clidx = a.lidx_to_cid_clidx[lidx]
            bcid,bclidx = b.lidx_to_cid_clidx[blidx]
            cid == bcid || return false
            sitecounts = a.compartment_sitecounts[cid][:,clidx]
            bsitecounts = b.compartment_sitecounts[cid][:,bclidx]
            sitecounts == bsitecounts || return false
            # chem_voxel_mon_counts
            # may be too high because of rejection sampling
            
        end
    end
    return true
end

"""
Assert all invariants on a link_2mon_data
"""
function assert_invariants(l::Link2MonData)
    @assert l.id > 0
    @assert l.next_lid[] > 0
    @assert all(in(1:l.next_lid[]-1), l.lidx_to_lid)
    n = length(l.states)
    @assert n == length(keys(l.lid_to_lidx))
    @assert n == length(l.lidx_to_endnames)
    @assert n == length(l.lidx_to_lid)
    if l.track_sitecounts
        if l.cache_valid[]
            @assert n == length(l.lidx_to_cid_clidx)
        end
    else
        @assert 0 == length(l.lidx_to_cid_clidx)
        @assert 0 == length(l.cid_clidx_to_lidx)
        @assert 0 == length(l.compartment_sitecounts)
        @assert 0 == l.mlsid_offset
        @assert 0 == length(l.chem_voxel_mon_counts)
    end
    for lidx in 1:n
        lid = l.lidx_to_lid[lidx]
        @assert lidx == l.lid_to_lidx[lid]
        if l.track_sitecounts && l.cache_valid[]
            cid, clidx = l.lidx_to_cid_clidx[lidx]
            @assert lidx == l.cid_clidx_to_lidx[cid][clidx]
            @assert cid > 0
        end
    end
    if l.track_sitecounts
        nsites = size(l.compartment_sitecounts[begin])[1]
        @assert length(l.cid_clidx_to_lidx) == length(l.compartment_sitecounts)
        if !isempty(l.chem_voxel_mon_counts)
            @assert nsites == l.mlsid_offset + size(l.chem_voxel_mon_counts[begin])[1]
        end
        totaln = 0
        for cid in 1:length(l.compartment_sitecounts)
            @assert size(l.compartment_sitecounts[cid])[1] == nsites
            if !isempty(l.chem_voxel_mon_counts)
                @assert nsites == l.mlsid_offset + size(l.chem_voxel_mon_counts[cid])[1]
                @assert size(l.compartment_sitecounts[cid])[2] == size(l.chem_voxel_mon_counts[cid])[2]
            end
            if l.cache_valid[]
                nlink_2mon_incid = size(l.compartment_sitecounts[cid])[2]
                @assert nlink_2mon_incid == length(l.cid_clidx_to_lidx[cid])
                totaln += nlink_2mon_incid
            end
        end
        l.cache_valid[] && @assert totaln == n
    end
end
