using StaticArrays
using Random

"""
    CubicGrid(num_voxels::SVector{3,Int}, compartmentsize::Float64)

$(TYPEDFIELDS)
"""
struct CubicGrid
    n::SVector{3,Int}
    compartmentsize::Float64
end

"""
    Base.length(grid::CubicGrid)

Total number of compartments in the grid
"""
function Base.length(grid::CubicGrid)
    prod(grid.n)
end

function area(grid::CubicGrid,gi,side)
    grid.compartmentsize^2
end

function invdistance(grid::CubicGrid,gi,side)
    1/grid.compartmentsize
end

function invvolume(grid::CubicGrid,gi)
    1/(grid.compartmentsize^3)
end

"""$PUBLIC
    grididat(grid::CubicGrid, location)

Return the grid id of location
The origin is in the corner.
Returns a close by voxel if out of the grid
"""
function grididat(grid::CubicGrid, location)::Int
    g_unclamped= floor.(Int, location ./ grid.compartmentsize)
    g= clamp.(g_unclamped, SA[0,0,0], grid.n .- 1)
    1 + g[1] + g[2] * grid.n[1] + g[3] * grid.n[1]*grid.n[2]
end

"""$PUBLIC
    filter_grididat(f, grid::CubicGrid, location)

Return the nearest grid id of location where f(id) evaluates to true.
The origin is in the corner.
errors if there is no id that evaluates to true.
Returns a close by voxel if out of the grid.
"""
function filter_grididat(f, grid::CubicGrid, location)::Int
    cid = grididat(grid, location)
    if f(cid)
        return cid
    end
    #iterate through neighbors
    mindist = Inf
    minid = 0
    for id in grid_neighbor_ids(grid, cid)
        if f(id)
            pos = location-centerof(grid, id)
            d = @noinline norm_fast(pos)
            if d < mindist
                mindist = d
                minid = id
            end
        end
    end
    if isfinite(mindist)
        return minid
    end
    #iterate through all ids
    for id in 1:length(grid)
        if f(id)
            pos = location-centerof(grid, id)
            d = @noinline norm_fast(pos)
            if d < mindist
                mindist = d
                minid = id
            end
        end
    end
    if isfinite(mindist)
        return minid
    end
    error("f is always false in the grid")
end


"""$PUBLIC
    centerof(grid::CubicGrid, cid)
Return the location of the center of a grid id
The origin is in the corner.
"""
function centerof(grid::CubicGrid, cid)::SVector{3,Float64}
    x= (cid-1)%grid.n[1]
    rgi= (cid-1)÷grid.n[1]
    y= rgi%grid.n[2]
    z= rgi÷grid.n[2]
    SA[x+0.5,y+0.5,z+0.5] * grid.compartmentsize
end

"""$PUBLIC
    centerof(grid::CubicGrid)
Return the location of the center the grid
The origin is in the corner.
"""
function centerof(grid::CubicGrid)::SVector{3,Float64}
    (1//2 .* grid.compartmentsize) .* grid.n
end

"""
    cornerof(grid::CubicGrid)
Return the location of the most negative corner the grid
The origin is in the corner.
"""
function cornerof(grid::CubicGrid)::SVector{3,Float64}
    zero(SVector{3,Float64})
end

"""$PUBLIC
    randompoint(grid::CubicGrid,cid)::SVector{3,Float64}
Return a random point in a voxel
Note, due to floating point rounding, 
there is a small chance the returned point may be in a nearby voxel.
"""
function randompoint(grid::CubicGrid,cid)::SVector{3,Float64}
    center= centerof(grid,cid)
    d= (rand(SVector{3,Float64}) .- 0.5) * grid.compartmentsize
    d + center
end

"""$PUBLIC
    randompoint(grid::CubicGrid)::SVector{3,Float64}
Return a random point in the grid
"""
function randompoint(grid::CubicGrid)::SVector{3,Float64}
    d = (rand(SVector{3,Float64})) * grid.compartmentsize
    d .* grid.n
end


"""
side code:
1: x+
2: x-
3: y+
4: y-
5: z+
6: z-

This handles reflective boundary conditions
"""
function adjacentgridid(grid::CubicGrid,cid,side)
    # direction= (side+1)÷2
    # plus= 2*(side%2)-1
    r= cid
    x= (cid-1)%grid.n[1]
    if side==1
        if x<(grid.n[1]-1)
            r+=1
        end
        return r
    end
    if side==2
        if x>0
            r-=1
        end
        return r
    end
    rgi= (cid-1)÷grid.n[1]
    y= rgi%grid.n[2]
    if side==3
        if y<(grid.n[2]-1)
            r+=grid.n[1]
        end
        return r
    end
    if side==4
        if y>0
            r-=grid.n[1]
        end
        return r
    end
    z= rgi÷grid.n[2]
    if side==5
        if z<(grid.n[3]-1)
            r+=grid.n[2]*grid.n[1]
        end
        return r
    end
    if side==6
        if z>0
            r-=grid.n[2]*grid.n[1]
        end
        return r
    end
end

"""
Return a vector of compartment ids that touch a compartment id,
excluding the compartment id itself.
"""
function grid_neighbor_ids(grid::CubicGrid,cid)
    cartesian_ind = CartesianIndices(Tuple(grid.n))
    linear_ind = LinearIndices(Tuple(grid.n))
    ccart = cartesian_ind[cid]
    neighbors = Int[]
    for offsetcart in CartesianIndices((-1:1, -1:1, -1:1))
        newcart = ccart + offsetcart
        if offsetcart != CartesianIndex(0, 0, 0) && newcart in cartesian_ind
            push!(neighbors,linear_ind[newcart])
        end
    end
    neighbors
end