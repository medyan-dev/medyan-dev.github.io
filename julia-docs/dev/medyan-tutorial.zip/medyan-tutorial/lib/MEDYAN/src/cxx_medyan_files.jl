"""

Functions to write and read c++ medyan input and output files.

Some features in c++ medyan are not available in MEDYAN.jl, 
so there won't be full compatibility.

"""


"""
Append a snapshot to an open "snapshot.traj" file.

See: https://medyan.org/docs/site/#manual/output-files/#snapshottraj

for details on the file format.

Note: 
    - `deltal` and `deltar` are not tracked in MEDYAN.jl , so they will always be "0"
    - MEDYAN.jl has no explicit MOTOR or BRANCHER types, both will be LINKER.
"""
function write_snapshot_traj(c::Context, io=stdout)
    # Add header
    # chemstepnumber time numfilaments numlink_2mons nummotors numbranchers
    println(io,
        c.stats.reaction_count, ' ',
        round(c.time[];sigdigits=14), ' ',
        sum(ftid -> length(filtype_fil_ids(c, ftid)), 1:num_filtypes(c)), ' ',
        sum(num_link_2mons, c.link_2mon_data), ' ',
        "0 0"
    )
    # Add filaments
    # FILAMENT filamentid filamenttype filamentcyllength deltal deltar
    # beadcoord1x beadcoord1y beadcoord1z beadcoord2x beadcoord2y beadcoord2z ...
    for ftid in 1:num_filtypes(c)
        for fil_id in filtype_fil_ids(c, ftid)
            node_pos = fil_node_positions(c, ftid, fil_id) .- Ref(cornerof(c.grid))
            println(io,
                "FILAMENT ",
                fil_id, ' ',
                ftid, ' ',
                length(node_pos), ' ',
                "0 0"
            )
            for pos in node_pos
                join(io, round.(pos; digits = 4), ' ')
                print(io, ' ')
            end
            println(io)
        end
    end
    # Add link_2mons
    # LINKER link_2mon_id link_2mon_type
    # startcoordx startcoordy startcoordz endcoordx endcoordy endcoordz
    foreach(c.link_2mon_data) do link_2mon_data
        for (lidx, endnames) in enumerate(link_2mon_data.lidx_to_endnames)
            println(io,
                "LINKER ",
                lidx, ' ',
                link_2mon_data.id
            )
            for name in endnames
                pos = mon_position(c, name) - cornerof(c.grid)
                join(io, round.(pos; digits = 4), ' ')
                print(io, ' ')
            end
            println(io)
        end
    end
    # Final newline
    println(io)
end
