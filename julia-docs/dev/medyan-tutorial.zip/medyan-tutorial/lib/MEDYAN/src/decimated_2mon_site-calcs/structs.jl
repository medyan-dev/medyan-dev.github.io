using CellListMap.PeriodicSystems: PeriodicSystem, PeriodicSystem1, PeriodicSystem2, map_pairwise!
import CellListMap


"""
Store list of pairs of indexes per compartment.
"""
struct PairLists
    pairlists::Vector{Vector{Pair{Int32,Int32}}}
end

function PairLists(n::Integer)
    PairLists([Pair{Int32,Int32}[] for i in 1:n])
end

#define the required Output methods for CellListMap.PeriodicSystems

CellListMap.PeriodicSystems.copy_output(x::PairLists) = PairLists(map(copy,x.pairlists))

function CellListMap.PeriodicSystems.reset_output!(x::PairLists)
    foreach(empty!, x.pairlists)
    x
end

function CellListMap.PeriodicSystems.reducer(x::PairLists, y::PairLists)
    @argcheck length(x.pairlists) == length(y.pairlists)
    foreach(append!, x.pairlists, y.pairlists)
    x
end

abstract type AbstractDecimated2MonSiteManager end

"""

$(TYPEDFIELDS)
"""
Base.@kwdef struct Decimated2MonOneTypeSiteManager{SITE <: SiteData, SYSTEM <: PeriodicSystem1} <: AbstractDecimated2MonSiteManager
    ftid::Int
    site::SITE
    system::SYSTEM
    step::Int
    points::Vector{SVector{3,Float64}} = []
    plusvecs::Vector{SVector{3,Float64}} = []
    cids::Vector{Int32} = []
    fids::Vector{Int32} = []
    mids::Vector{Int32} = []
end

function Decimated2MonOneTypeSiteManager(grid::CubicGrid, site::SiteData; nthreads=1)
    simboxsize = collect(grid.n) .* grid.compartmentsize
    cutoff = cutoff_distance(site.site)
    ftid, ftid2 = getftids(site.site)
    step, step2 = getmidsteps(site.site)
    @argcheck step == step2
    @argcheck ftid == ftid2
    # pad the unit cell to avoid periodic effects
    unitcell = max.(cutoff*2.4, simboxsize .+ 1.2*cutoff .+ 0.2*grid.compartmentsize)
    system = PeriodicSystem(;
        xpositions = SVector{3,Float64}[],
        unitcell,
        cutoff,
        output = PairLists(length(grid)),
        nbatches = (clamp(nthreads,1,8), max(nthreads,1)),
    )
    Decimated2MonOneTypeSiteManager{
        typeof(site),
        typeof(system),
    }(;
        ftid,
        site,
        system,
        step,
    )
end

# const Decimated2MonOneTypeSiteManagerType = Decimated2MonOneTypeSiteManager{MEDYAN.SiteData{MEDYAN.Decimated2MonSiteRange}, CellListMap.PeriodicSystems.PeriodicSystem1{:output, SVector{3, Float64}, MEDYAN.PairLists, CellListMap.Box{CellListMap.OrthorhombicCell, 3, Float64, Float64, 9}, CellListMap.CellList{3, Float64}, CellListMap.AuxThreaded{3, Float64}}}
# export Decimated2MonOneTypeSiteManagerType

"""

$(TYPEDFIELDS)
"""
Base.@kwdef struct Decimated2MonTwoTypeSiteManager{SITE <: SiteData, SYSTEM <: PeriodicSystem2} <: AbstractDecimated2MonSiteManager
    ftid1::Int
    ftid2::Int
    site::SITE
    system::SYSTEM
    step1::Int
    step2::Int
    point1s::Vector{SVector{3,Float64}} = []
    plusvec1s::Vector{SVector{3,Float64}} = []
    cid1s::Vector{Int32} = []
    fid1s::Vector{Int32} = []
    mid1s::Vector{Int32} = []
    point2s::Vector{SVector{3,Float64}} = []
    plusvec2s::Vector{SVector{3,Float64}} = []
    cid2s::Vector{Int32} = []
    fid2s::Vector{Int32} = []
    mid2s::Vector{Int32} = []
end

function Decimated2MonTwoTypeSiteManager(grid::CubicGrid, site::SiteData; nthreads=1)
    simboxsize = collect(grid.n) .* grid.compartmentsize
    cutoff = cutoff_distance(site.site)
    ftid1, ftid2 = getftids(site.site)
    step1, step2 = getmidsteps(site.site)
    @argcheck ftid1 != ftid2
    # pad the unit cell to avoid periodic effects
    unitcell = max.(cutoff*2.4, simboxsize .+ 1.2*cutoff .+ 0.2*grid.compartmentsize)
    system = PeriodicSystem(;
        xpositions = SVector{3,Float64}[],
        ypositions = SVector{3,Float64}[],
        unitcell, 
        cutoff,
        output = PairLists(length(grid)),
        nbatches = (clamp(nthreads,1,8), max(nthreads,1)),
    )
    Decimated2MonTwoTypeSiteManager{
        typeof(site),
        typeof(system),
    }(;
        ftid1,
        ftid2,
        site,
        system,
        step1,
        step2,
    )
end

abstract type AbstractPossibleCadherinSiteManager end

"""

$(TYPEDFIELDS)
"""
Base.@kwdef struct PossibleCadherinSiteManager{SITE <: SiteData, SYSTEM <: PeriodicSystem2} <: AbstractPossibleCadherinSiteManager
    meshid::Int
    ftid::Int
    site::SITE
    system::SYSTEM
    fstep::Int#only for filaments
    vpoints::Vector{SVector{3,Float64}} = []#
    vcids::Vector{Int32} = []
    meshids::Vector{Int32} = []
    vids::Vector{Int32} = []
    fpoints::Vector{SVector{3,Float64}} = []
    fvecs::Vector{SVector{3,Float64}} = []
    cids::Vector{Int32} = []
    fids::Vector{Int32} = []
    mids::Vector{Int32} = []
end

function PossibleCadherinSiteManager(grid::CubicGrid, site::SiteData; nthreads=1)
    simboxsize = collect(grid.n) .* grid.compartmentsize
    cutoff = cutoff_distance(site.site)
    meshid, ftid = getmeshidftid(site.site)
    fstep = getmidsteps(site.site)
    # pad the unit cell to avoid periodic effects
    unitcell = max.(cutoff*2.4, simboxsize .+ 1.2*cutoff .+ 0.2*grid.compartmentsize)
    system = PeriodicSystem(;
        xpositions = SVector{3,Float64}[],#c.membranes[1].vertices.attr.coord,#SVector{3,Float64}[],# coord of vertices and filaments
        ypositions = SVector{3,Float64}[],
        unitcell, 
        cutoff,
        output = PairLists(length(grid)),
        nbatches = (clamp(nthreads,1,8), max(nthreads,1)),
    )
    PossibleCadherinSiteManager{
        typeof(site),
        typeof(system),
    }(;
        meshid,
        ftid,
        site,
        system,
        fstep,
    )
end