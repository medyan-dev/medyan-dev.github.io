

function reset_site_counts!(c::Context, m::Decimated2MonOneTypeSiteManager)::Nothing
    site = m.site
    system = m.system
    ftid = m.ftid
    step = m.step
    cylinders = c.chem_cylinders[ftid]
    fxsid = site.fxsid
    # set vectors of info per linkable monomer
    reset_cached_monomer_info!(c, cylinders, step, m.points, m.plusvecs, m.mids, m.fids, m.cids)
    # update system
    resize!(system.xpositions, length(m.points))
    system.xpositions .= m.points
    map_pairwise!(system) do x,y,i,j,d2,out
        @inbounds pos1 = m.points[i]
        @inbounds pos2 = m.points[j]
        @inbounds plusv1 = m.plusvecs[i]
        @inbounds plusv2 = m.plusvecs[j]
        @inline one_two, two_one = in_linking_range(site.site,pos1,pos2,plusv1,plusv2)
        if one_two
            push!(@inbounds(out.pairlists[m.cids[i]]), (i%Int32)=>(j%Int32))
        end
        if two_one
            push!(@inbounds(out.pairlists[m.cids[j]]), (j%Int32)=>(i%Int32))
        end
        return out
    end
    # update chemistry engine
    maxsitecount = max_decimated_2mon_sitecount(site.site)
    for cid in 1:length(c.grid)
        local totalmaxsitecount = maxsitecount*length(system.output.pairlists[cid])
        setfixedspeciescount!(c.chemistryengine, fxsid, cid, totalmaxsitecount)
    end
    return
end

"""
Return pair of monomer names given a pair of indexes
"""
function index2name(m::Decimated2MonOneTypeSiteManager, indexes)::Tuple{MonomerName,MonomerName}
    a,b = indexes
    a_name = MonomerName(m.ftid, m.fids[a], m.mids[a])
    b_name = MonomerName(m.ftid, m.fids[b], m.mids[b])
    a_name, b_name
end

"""
Return the point and plusvec vectors based on `isminusend`
"""
function get_points_plusvectors(m::Decimated2MonOneTypeSiteManager, isminusend::Bool)::Tuple{Vector,Vector}
    m.points, m.plusvecs
end


function reset_site_counts!(c::Context, m::Decimated2MonTwoTypeSiteManager)::Nothing
    site = m.site
    system = m.system
    ftid1 = m.ftid1
    ftid2 = m.ftid2
    step1 = m.step1
    step2 = m.step2
    cylinders1 = c.chem_cylinders[ftid1]
    cylinders2 = c.chem_cylinders[ftid2]
    fxsid = site.fxsid
    # set vectors of info per linkable monomer
    reset_cached_monomer_info!(c, cylinders1, step1, m.point1s, m.plusvec1s, m.mid1s, m.fid1s, m.cid1s)
    reset_cached_monomer_info!(c, cylinders2, step2, m.point2s, m.plusvec2s, m.mid2s, m.fid2s, m.cid2s)
    # update system
    resize!(system.xpositions, length(m.point1s))
    system.xpositions .= m.point1s
    resize!(system.ypositions, length(m.point2s))
    system.ypositions .= m.point2s
    map_pairwise!(system) do x,y,i,j,d2,out
        pos1 = m.point1s[i]
        pos2 = m.point2s[j]
        plusv1 = m.plusvec1s[i]
        plusv2 = m.plusvec2s[j]
        one_two, two_one = in_linking_range(site.site,pos1,pos2,plusv1,plusv2)
        # this type of decimated_2mon site is one directional.
        if one_two
            push!(out.pairlists[m.cid1s[i]], (i%Int32)=>(j%Int32))
        end
        return out
    end
    # update chemistry engine
    maxsitecount = max_decimated_2mon_sitecount(site.site)
    for cid in 1:length(c.grid)
        local totalmaxsitecount = maxsitecount*length(system.output.pairlists[cid])
        setfixedspeciescount!(c.chemistryengine, fxsid, cid, totalmaxsitecount)
    end
    return
end

"""
Return pair of monomer names given a pair of indexes
"""
function index2name(m::Decimated2MonTwoTypeSiteManager, indexes)::Tuple{MonomerName,MonomerName}
    a,b = indexes
    a_name = MonomerName(m.ftid1, m.fid1s[a], m.mid1s[a])
    b_name = MonomerName(m.ftid2, m.fid2s[b], m.mid2s[b])
    a_name, b_name
end

"""
Return the point and plusvec vectors based on `isminusend`
"""
function get_points_plusvectors(m::Decimated2MonTwoTypeSiteManager, isminusend::Bool)::Tuple{Vector,Vector}
    if isminusend
        m.point1s, m.plusvec1s
    else
        m.point2s, m.plusvec2s
    end
end


"""
Return the real total decimated_2mon_site count.
Just used for testing, not for running chemistry
"""
function get_real_total_decimated_2mon_sitecount(c::Context, m::AbstractDecimated2MonSiteManager)
    site = m.site
    system = m.system
    return map(system.output.pairlists) do pairlist
        mapreduce(+, pairlist; init=zero(Q31f32)) do pair
            a,b = pair
            a_name, b_name  = index2name(m, pair)
            # assert that if monomers are valid they are not moved and still linkable.
            if (
                mon_exists(c, a_name) && 
                mon_exists(c, b_name) &&
                mon_minimized(c, a_name) &&
                mon_minimized(c, b_name)
                )
                a_point, a_plusvec = mon_position_plusvector(c, a_name)
                b_point, b_plusvec = mon_position_plusvector(c, b_name)
                # double check positions and plus vectors match
                point1s, plusvec1s = get_points_plusvectors(m, true)
                point2s, plusvec2s = get_points_plusvectors(m, false)
                @argcheck a_point == point1s[a]
                @argcheck b_point == point2s[b]
                @argcheck a_plusvec == plusvec1s[a]
                @argcheck b_plusvec == plusvec2s[b]
                @argcheck in_linking_range(site.site, a_point, b_point, a_plusvec, b_plusvec)[1]
            end
            get_decimated_2mon_sitecount(c, site.site, a_name, b_name)
        end
    end
end

"""
Return a tuple of (minus, plus) MonomerNames of a random decimated_2mon site, or return nothing if rejected.
weighted by counts, using the default RNG.
"""
function pickrandom_decimated_2mon_site(c::Context, m::AbstractDecimated2MonSiteManager, cid::Integer)::Union{Tuple{MonomerName,MonomerName},Nothing}
    site = m.site
    pairlist = m.system.output.pairlists[cid]
    isempty(pairlist) && return
    a_name, b_name = index2name(m, rand(pairlist))
    maxsitecount = max_decimated_2mon_sitecount(site.site)
    # now get the actual site count
    # first create the monomer names
    sitecount = get_decimated_2mon_sitecount(c, site.site, a_name, b_name)
    @argcheck sitecount ≤ maxsitecount + eps(maxsitecount)
    # now do rejection sampling
    u = maxsitecount*rand()
    if u < sitecount
        return (a_name, b_name)
    else
        return
    end
end


"""
Reset cached monomer info
"""
function reset_cached_monomer_info!(c::Context, cylinders::ChemCylinders, step, points, plusvecs, mids, fids, cids)
    empty!(cids)
    empty!(fids)
    empty!(mids)
    empty!(plusvecs)
    empty!(points)
    for fil_idx in eachindex(cylinders.per_fil)
        fid = cylinders.per_fil.id[fil_idx]
        monstates = _fil_mon_states(cylinders, fil_idx)
        minusend_num_notminimized = cylinders.per_fil.minusend_num_notminimized[fil_idx]
        plusend_num_notminimized = cylinders.per_fil.plusend_num_notminimized[fil_idx]
        startmid = firstindex(monstates) + minusend_num_notminimized
        stopmid = lastindex(monstates) - plusend_num_notminimized
        startmid = cld(startmid, step)*step
        for mon_id in startmid:step:stopmid
            pos, plusvec = _mon_position_plusvector(cylinders, fil_idx, mon_id)
            cid = get_compartment_id(c, pos)
            push!(points, pos)
            push!(plusvecs, plusvec)
            push!(mids, mon_id)
            push!(fids, fid)
            push!(cids, cid)
        end
    end
end


"""
Return the decimated_2mon site count between two monomers in a context that are in linkable range
if they exist and are minimized,
otherwise return 0
"""
function get_decimated_2mon_sitecount(c::Context, site, minusname::MonomerName, plusname::MonomerName)::Q31f32
    site_ftids = getftids(site)
    site_midsteps = getmidsteps(site)
    (minusname.ftid,plusname.ftid) == site_ftids || return 0
    mod(minusname.mid, site_midsteps[1]) == 0 || return 0
    mod(plusname.mid, site_midsteps[2]) == 0 || return 0
    # now check that these monomers were not deleted during this chemistry cycle.
    mon_exists(c, minusname) || return 0
    mon_exists(c, plusname) || return 0
    # now check that these monomers were minimized before this chemistry cycle.
    mon_minimized(c, minusname) || return 0
    mon_minimized(c, plusname) || return 0
    # get the monomer positions and plus vectors and state
    m_pos,m_plusv = mon_position_plusvector(c, minusname)
    p_pos,p_plusv = mon_position_plusvector(c, plusname)
    m_state = fil_mon_states(c, minusname.ftid, minusname.fid)[minusname.mid]
    p_state = fil_mon_states(c, plusname.ftid, plusname.fid)[plusname.mid]
    # get the decimated_2mon site count
    decimated_2mon_sitecount(site,m_state,p_state,m_pos,p_pos,m_plusv,p_plusv)
end