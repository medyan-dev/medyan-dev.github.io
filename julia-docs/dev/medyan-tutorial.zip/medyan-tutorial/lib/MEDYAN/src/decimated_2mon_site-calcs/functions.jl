

function reset_site_counts!(c::Context, m::Decimated2MonOneTypeSiteManager)::Nothing
    site = m.site
    system = m.system
    ftid = m.ftid
    step = m.step
    cylinders = c.chem_cylinders[ftid]
    fxsid = site.fxsid
    # set vectors of info per linkable monomer
    reset_cached_monomer_info!(c, cylinders, step, m.points, m.plusvecs, m.mids, m.ftags, m.cids)
    # update system
    resize!(system.xpositions, length(m.points))
    system.xpositions .= m.points
    map_pairwise!(system) do x,y,i,j,d2,out
        @inbounds pos1 = m.points[i]
        @inbounds pos2 = m.points[j]
        @inbounds plusv1 = m.plusvecs[i]
        @inbounds plusv2 = m.plusvecs[j]
        @inline one_two, two_one = in_linking_range(site.site,pos1,pos2,plusv1,plusv2)
        if one_two
            push!(@inbounds(out.pairlists[m.cids[i]]), (i%Int32)=>(j%Int32))
        end
        if two_one
            push!(@inbounds(out.pairlists[m.cids[j]]), (j%Int32)=>(i%Int32))
        end
        return out
    end
    # update chemistry engine
    maxsitecount = max_decimated_2mon_sitecount(site.site)
    for cid in 1:length(c.grid)
        local totalmaxsitecount = maxsitecount*length(system.output.pairlists[cid])
        setfixedspeciescount!(c.chemistryengine, fxsid, cid, totalmaxsitecount)
    end
    return
end

"""
Reset the monomers for each decimated_2mon_site
"""
function helper_reset_decimated_2mon_site_monomers!(c::Context)
    foreach(c.decimated_2mon_site_managers) do m
        reset_site_counts!(c, m)
    end
end

"""
Return pair of monomer places given a pair of indexes
"""
function index2places(c::Context, m::Decimated2MonOneTypeSiteManager, indexes)::Tuple{FilaMonoIdx,FilaMonoIdx}
    a, b = indexes
    a_place = if tag_exists(c, m.ftags[a])
        FilaMonoIdx(c, FilaIdx(c, m.ftags[a]), m.mids[a])
    else
        FilaMonoIdx()
    end
    b_place = if tag_exists(c, m.ftags[b])
        FilaMonoIdx(c, FilaIdx(c, m.ftags[b]), m.mids[b])
    else
        FilaMonoIdx()
    end
    a_place, b_place
end

"""
Return the real total decimated_2mon_site count.
Just used for testing, not for running chemistry
"""
function get_real_total_decimated_2mon_sitecount(c::Context, m::Decimated2MonOneTypeSiteManager)
    site = m.site
    system = m.system
    return map(system.output.pairlists) do pairlist
        mapreduce(+, pairlist; init=zero(Q31f32)) do pair
            a, b = pair
            a_place, b_place = index2places(c, m, pair)
            # assert that if monomers are valid they are not moved and still linkable.
            if (
                place_exists(c, a_place) && 
                place_exists(c, b_place) &&
                is_minimized(c, a_place) &&
                is_minimized(c, b_place)
                )
                a_point = get_position(c, a_place)
                a_plusvec = get_directions(c, a_place)[1]
                b_point = get_position(c, b_place)
                b_plusvec = get_directions(c, b_place)[1]
                # double check positions and plus vectors match
                points, plusvecs = m.points, m.plusvecs
                @argcheck a_point == points[a]
                @argcheck b_point == points[b]
                @argcheck a_plusvec == plusvecs[a]
                @argcheck b_plusvec == plusvecs[b]
                @argcheck in_linking_range(site.site, a_point, b_point, a_plusvec, b_plusvec)[1]
            end
            get_decimated_2mon_sitecount(c, site.site, a_place, b_place)
        end
    end
end

"""
Return a tuple of (minus, plus) FilaMonoIdx of a random decimated_2mon site, or return nothing if rejected.
weighted by counts, using the default RNG.
"""
function pickrandom_decimated_2mon_site(c::Context, m::AbstractDecimated2MonSiteManager, cid::Integer)::Union{Tuple{FilaMonoIdx,FilaMonoIdx}, Nothing}
    site = m.site
    pairlist = m.system.output.pairlists[cid]
    isempty(pairlist) && return
    a_place, b_place = index2places(c, m, rand(pairlist))
    maxsitecount = max_decimated_2mon_sitecount(site.site)
    # now get the actual site count
    # first create the monomer names
    sitecount = get_decimated_2mon_sitecount(c, site.site, a_place, b_place)
    @argcheck sitecount ≤ maxsitecount + eps(maxsitecount)
    # now do rejection sampling
    u = maxsitecount*rand()
    if u < sitecount
        return (a_place, b_place)
    else
        return
    end
end
function pickrandom_decimated_2mon_site(c::Context,cid,lbsid)::Union{Tuple{FilaMonoIdx,FilaMonoIdx},Nothing}
    helper_warn_chem_cache_invalid!(c)
    pickrandom_decimated_2mon_site(c::Context, c.decimated_2mon_site_managers[lbsid], cid)
end

"""
Reset cached monomer info
"""
function reset_cached_monomer_info!(c::Context, cylinders::ChemCylinders, step, points, plusvecs, mids, ftags, cids)
    ftid = cylinders.ftid
    empty!(cids)
    empty!(ftags)
    empty!(mids)
    empty!(plusvecs)
    empty!(points)
    for fil_idx in eachindex(cylinders.per_fil)
        ftag = tag!(c, FilaTipIdx(FilaIdx(ftid, fil_idx), false))
        monstates = _fil_mon_states(cylinders, fil_idx)
        minusend_num_notminimized = cylinders.per_fil.minusend_num_notminimized[fil_idx]
        plusend_num_notminimized = cylinders.per_fil.plusend_num_notminimized[fil_idx]
        startmid = firstindex(monstates) + minusend_num_notminimized
        stopmid = lastindex(monstates) - plusend_num_notminimized
        startmid = cld(startmid, step)*step
        for mon_id in startmid:step:stopmid
            pos, plusvec = _mon_position_plusvector(cylinders, fil_idx, mon_id)
            cid = get_compartment_id(c, pos)
            push!(points, pos)
            push!(plusvecs, plusvec)
            push!(mids, mon_id)
            push!(ftags, ftag)
            push!(cids, cid)
        end
    end
end


"""
Return the decimated_2mon site count between two monomers in a context that are in linkable range
if they exist and are minimized,
otherwise return 0
"""
function get_decimated_2mon_sitecount(c::Context, site, minusplace::FilaMonoIdx, plusplace::FilaMonoIdx)::Q31f32
    site_ftids = getftids(site)
    site_midsteps = getmidsteps(site)
    (minusplace.fila_idx.typeid, plusplace.fila_idx.typeid) == site_ftids || return 0
    mod(minusplace.mid, site_midsteps[1]) == 0 || return 0
    mod(plusplace.mid, site_midsteps[2]) == 0 || return 0
    # now check that these monomers were not deleted during this chemistry cycle.
    place_exists(c, minusplace) || return 0
    place_exists(c, plusplace) || return 0
    # now check that these monomers were minimized before this chemistry cycle.
    is_minimized(c, minusplace) || return 0
    is_minimized(c, plusplace) || return 0
    # get the monomer positions and plus vectors and state
    m_pos = get_position(c, minusplace)
    m_plusv = get_directions(c, minusplace)[1]
    p_pos = get_position(c, plusplace)
    p_plusv = get_directions(c, plusplace)[1]
    m_state = fila_mono_states(c, minusplace.fila_idx)[minusplace.mid]
    p_state = fila_mono_states(c, plusplace.fila_idx)[plusplace.mid]
    # get the decimated_2mon site count
    decimated_2mon_sitecount(site,m_state,p_state,m_pos,p_pos,m_plusv,p_plusv)
end

"""
Return a tuple of points, plusvecs, states, and compartment ids of monomers that can link.
"""
function helper_linkable_mon_data(c::Context, cylinders::ChemCylinders, step)
    points = SVector{3,Float64}[]
    plusvecs = SVector{3,Float64}[]
    states = MonomerState[]
    cids = Int[]
    for fil_idx in eachindex(cylinders.per_fil)
        monstates = _fil_mon_states(cylinders, fil_idx)
        minusend_num_notminimized = cylinders.per_fil.minusend_num_notminimized[fil_idx]
        plusend_num_notminimized = cylinders.per_fil.plusend_num_notminimized[fil_idx]
        startmid = firstindex(monstates) + minusend_num_notminimized
        stopmid = lastindex(monstates) - plusend_num_notminimized
        startmid = cld(startmid, step)*step
        for mon_id in startmid:step:stopmid
            pos, plusvec = _mon_position_plusvector(cylinders, fil_idx, mon_id)
            cid = get_compartment_id(c, pos)
            state = monstates[mon_id]
            push!(points, pos)
            push!(plusvecs, plusvec)
            push!(states, state)
            push!(cids, cid)
        end
    end
    return (points, plusvecs, states, cids)
end

"""
Returns the total decimated_2mon site count in each compartment for testing.

This is uses CellListMap, and doesn't update any cached data
"""
function helper_total_decimated_2mon_sitecount_sameftid(c::Context, site::SiteData)
    cutoff = cutoff_distance(site.site)
    ftid, ftid2 = getftids(site.site)
    step, step2 = getmidsteps(site.site)
    @argcheck step == step2
    @argcheck ftid == ftid2
    points, plusvecs, states, cids = helper_linkable_mon_data(c, c.chem_cylinders[ftid], step)
    if length(points) < 2
        return zeros(Q31f32, length(c.grid))
    end
    box = CellListMap.Box(CellListMap.limits(points),cutoff*1.1)
    cl = CellListMap.CellList(points,box)
    CellListMap.map_pairwise(zeros(Q31f32, length(c.grid)), box, cl) do x,y,i,j,d2,out
        pos1 = points[i]
        pos2 = points[j]
        plusv1 = plusvecs[i]
        plusv2 = plusvecs[j]
        state1 = states[i]
        state2 = states[j]
        one_two, two_one = in_linking_range(site.site,pos1,pos2,plusv1,plusv2)
        if one_two
            out[cids[i]] += Q31f32(decimated_2mon_sitecount(site.site,state1,state2,pos1,pos2,plusv1,plusv2))
        end
        if two_one
            out[cids[j]] += Q31f32(decimated_2mon_sitecount(site.site,state2,state1,pos2,pos1,plusv2,plusv1))
        end
        return out
    end
end

"""
Returns the total decimated_2mon site count for testing.

This is uses CellListMap, and doesn't update any cached data
"""
function helper_total_decimated_2mon_sitecount_diffftid(c::Context, site::SiteData)
    cutoff = cutoff_distance(site.site)
    ftid1, ftid2 = getftids(site.site)
    step1, step2 = getmidsteps(site.site)
    @argcheck ftid1 != ftid2
    points1, plusvecs1, states1, cids1 = helper_linkable_mon_data(c, c.chem_cylinders[ftid1], step1)
    points2, plusvecs2, states2, cids2 = helper_linkable_mon_data(c, c.chem_cylinders[ftid2], step2)
    if length(points1) < 1 || length(points2) < 1
        return zeros(Q31f32, length(c.grid))
    end
    box = CellListMap.Box(CellListMap.limits([points1; points2]),cutoff*1.1)
    cl = CellListMap.CellList(points1,points2,box)
    CellListMap.map_pairwise(zeros(Q31f32, length(c.grid)), box, cl) do x,y,i,j,d2,out
        pos1 = points1[i]
        pos2 = points2[j]
        plusv1 = plusvecs1[i]
        plusv2 = plusvecs2[j]
        state1 = states1[i]
        state2 = states2[j]
        one_two, two_one = in_linking_range(site.site,pos1,pos2,plusv1,plusv2)
        if one_two
            cid = cids1[i]
            out[cid] += Q31f32(decimated_2mon_sitecount(site.site,state1,state2,pos1,pos2,plusv1,plusv2))
        end
        return out
    end
end
