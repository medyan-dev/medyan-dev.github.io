using StaticArrays
using LinearAlgebra


"""$PUBLIC
Mechanical boundary

See also [`boundary_box`](@ref)

$(TYPEDFIELDS)
"""
Base.@kwdef struct Boundary
    """
    Planes that make up the mechanical boundary of the simulation.

    `E = 1//2 * relu(pos ⋅ planes[bi][1:3] - planes[bi][4])^2`
    
    For example, a mech bounding plane `[1,0,0,3]` would try and make x < 3 nm with a spring constant of 1 pN/nm.
    
    `2.0*[1,0,0,3]` would try and make x < 3 nm with a spring constant of 4 pN/nm.
    """
    planes::Vector{SVector{4,Float64}} = []

    """
    Capsules that make up the mechanical boundary of the simulation.

    `capsules[bi][1:3]` is the starting point of the spine line segment (nm).
    `capsules[bi][4:6]` is the axis of the spine line segment (nm).
    `capsules[bi][7]` is the radius (nm).
    `capsules[bi][8]` is the spring constant (pN/nm).

    if `capsules[bi][4:6]` is zero then the capsule is a sphere.
    Capsule boundaries can be combined with plane boundaries to create cylinder boundaries.

    `E = 1//2*k*relu(d - r0)^2`
    where:
    - d is the distance of the point to the spine line segment described by capsules[bi][1:6].
    - r0 is capsules[bi][7]
    - k is capsules[bi][8]
    """
    capsules::Vector{SVector{8,Float64}} = []
end


"""$PUBLIC
    $(TYPEDSIGNATURES)

Return a box boundary at the edge of a grid.

`offset`(nm): How far the bounding planes should be moved in from the edge of the
grid. Positive is inside the grid, negative is outside the grid.

`stiffness`(pN/nm): How strong the boundary is.
"""
function boundary_box(grid::CubicGrid; offset::Float64=0.0, stiffness=1.0::Float64)
    lens = grid.compartmentsize * grid.n .- 2offset # nm
    cen = centerof(grid)
    k = √(stiffness) # √(pN/nm)
    planes = k*SVector{4,Float64}[
        SA[-1,0,0,-cen[1]+lens[1]/2],
        SA[+1,0,0,+cen[1]+lens[1]/2],
        SA[0,-1,0,-cen[2]+lens[2]/2],
        SA[0,+1,0,+cen[2]+lens[2]/2],
        SA[0,0,-1,-cen[3]+lens[3]/2],
        SA[0,0,+1,+cen[3]+lens[3]/2],
    ]
    Boundary(;planes)
end

function Base.intersect(a::Boundary, b::Boundary)::Boundary
    r = Boundary()
    foreach(fieldnames(Boundary)) do k
        append!(getfield(r, k), getfield(a, k))
        append!(getfield(r, k), getfield(b, k))
    end
    r
end

"""
Return true if the point is inside the boundary
    If there is no boundary defaults to true
"""
function insideboundary(m::Boundary, point)::Bool
    for bp in m.planes
        point ⋅ bp[SOneTo(3)] < bp[4] || return false
    end
    for bc in m.capsules
        startpoint = bc[StaticArrays.SUnitRange(1,3)]
        q = point-startpoint
        p = bc[StaticArrays.SUnitRange(4,6)]
        r = bc[7]
        invpnormsqr = iszero(p⋅p) ? inv(eps(eltype(p))) : inv(p⋅p)
        d = q-clamp((q⋅p)*invpnormsqr,0,1)*p
        d⋅d < r*r || return false
    end
    return true
end

"""
Return a signeddistfun
Note, this will be invalid if the boundary gets modified
"""
function create_signeddistfun(m::Boundary; mesh = nothing)
    planes = m.planes
    capsules = m.capsules
    nhats = [normalize(bp[SOneTo(3)]) for bp in planes]
    d0s = [bp[4]/norm_fast(bp[SOneTo(3)]) for bp in planes]
    startpoints = map(capsules) do bc
        bc[StaticArrays.SUnitRange(1,3)] 
    end
    axis = map(capsules) do bc
        bc[StaticArrays.SUnitRange(4,6)]
    end
    invaxisnormsqr = map(axis) do a
        iszero(a⋅a) ? inv(eps(eltype(a))) : inv(a⋅a)
    end
    radii = [bc[7] for bc in capsules]
    function signeddistfun(pos)
        local planedist = maximum(i->(pos⋅nhats[i]-d0s[i]),eachindex(nhats); init= -Inf)
        local capsuledist = maximum(eachindex(startpoints); init= -Inf) do i
            local q = pos-@inbounds(startpoints[i])
            local p = @inbounds(axis[i])
            local invpnormsqr = @inbounds(invaxisnormsqr[i])
            local r = @inbounds(radii[i])
            norm_fast(q-clamp((q⋅p)*invpnormsqr,0,1)*p)-r
        end
        local meshdist = isnothing(mesh) ? -Inf : signed_distance(mesh, pos)
        max(planedist, capsuledist, meshdist)
    end
end

"""
Add mechboundary forces to forces and energies.
x is dof of positions
"""
function mechboundary_forces!(forces, energies, x, m::Boundary)
    isempty(m.planes) || bounding_planes_forces!(forces, energies, x, m.planes)
    isempty(m.capsules) || bounding_capsules_forces!(forces, energies, x, m.capsules)
end

"""
Add bounding plane forces to forces and energies.
x is dof of positions
"""
function bounding_planes_forces!(forces, energies, x, planes::Vector{SVector{4,Float64}})
    bnum= length(planes)
    posvect= reinterpret(SVector{3,eltype(x)},x)
    forcesvect= reinterpret(SVector{3,eltype(forces)},forces)
    @assert eachindex(posvect) ⊆ eachindex(forcesvect)
    @assert eachindex(posvect) ⊆ eachindex(energies)
    for i in eachindex(posvect)
        @inbounds pos= posvect[i]
        F= zero(forcesvect[i])
        E= zero(energies[i])
        for bi in 1:bnum
            @inbounds bp= planes[bi]
            a= pos ⋅ bp[SOneTo(3)] - bp[4]
            d= (a > zero(a) ? a : zero(a))
            E += 1//2*d^2
            F -= d * bp[SOneTo(3)]
        end
        @inbounds forcesvect[i] += F
        @inbounds energies[i] += E
    end
end

"""
Add bounding capsule forces to forces and energies.
x is dof of positions
"""
function bounding_capsules_forces!(forces, energies, x, capsules::Vector{SVector{8,Float64}})
    posvect= reinterpret(SVector{3,eltype(x)},x)
    forcesvect= reinterpret(SVector{3,eltype(forces)},forces)
    @assert eachindex(posvect) ⊆ eachindex(forcesvect)
    @assert eachindex(posvect) ⊆ eachindex(energies)
    for bc in capsules
        startpoint = bc[StaticArrays.SUnitRange(1,3)]
        p = bc[StaticArrays.SUnitRange(4,6)]
        r = bc[7]
        k = bc[8]
        invpnormsqr = iszero(p⋅p) ? inv(eps(eltype(p))) : inv(p⋅p)
        for i in eachindex(posvect)
            @inbounds pos = posvect[i]
            q = pos-startpoint
            d⃗ = q-clamp((q⋅p)*invpnormsqr,0,1)*p
            d = norm_fast(d⃗)
            d̂ = d⃗/d
            a = d - r
            Δ = (a > zero(a) ? a : zero(a))
            F = (-Δ*k)*d̂
            E = 1//2*k*Δ^2
            @inbounds forcesvect[i] += F
            @inbounds energies[i] += E
        end
    end
end