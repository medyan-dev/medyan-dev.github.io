using StaticArrays
using LinearAlgebra


"""$PUBLIC
Mechanical boundary

See also [`boundary_box`](@ref)

$(TYPEDFIELDS)
"""
Base.@kwdef struct Boundary
    """
    Planes that make up the mechanical boundary of the simulation.

    `E = 1//2 * relu(pos ⋅ planes[bi][1:3] - planes[bi][4])^2`
    
    For example, a mech bounding plane `[1,0,0,3]` would try and make x < 3 nm with a spring constant of 1 pN/nm.
    
    `2.0*[1,0,0,3]` would try and make x < 3 nm with a spring constant of 4 pN/nm.
    """
    planes::Vector{SVector{4,Float64}} = []

    """
    Capsules that make up the mechanical boundary of the simulation.

    `capsules[bi][1:3]` is the starting point of the spine line segment (nm).
    `capsules[bi][4:6]` is the axis of the spine line segment (nm).
    `capsules[bi][7]` is the radius (nm).
    `capsules[bi][8]` is the spring constant (pN/nm).

    if `capsules[bi][4:6]` is zero then the capsule is a sphere.
    Capsule boundaries can be combined with plane boundaries to create cylinder boundaries.

    `E = 1//2*k*relu(d - r0)^2`
    where:
    - d is the distance of the point to the spine line segment described by capsules[bi][1:6].
    - r0 is capsules[bi][7]
    - k is capsules[bi][8]
    """
    capsules::Vector{SVector{8,Float64}} = []
end

"""$PUBLIC
    $(TYPEDSIGNATURES)

Return a plane boundary.

`normal`(unit vector): Vector pointing normal to the plane.
This points outside of the boundary.

`point`(nm): Point on the plane.

`stiffness`(pN/nm): How strong the boundary is.
"""
function boundary_plane(;
        normal::SVector{3,Float64}=SA[1.0,0.0,0.0],
        point::SVector{3,Float64}=SA[0.0,0.0,0.0],
        stiffness::Float64=1.0,
    )
    @argcheck !iszero(norm(normal))
    n̂ = normalize(normal)
    k = √(stiffness) # √(pN/nm)
    planes = k*SVector{4,Float64}[
        SA[n̂..., n̂⋅point],
    ]
    Boundary(;planes)
end

"""$PUBLIC
    $(TYPEDSIGNATURES)

Return a box boundary at the edge of a grid.

`offset`(nm): How far the bounding planes should be moved in from the edge of the
grid. Positive is inside the grid, negative is outside the grid.

`stiffness`(pN/nm): How strong the boundary is.
"""
function boundary_box(grid::CubicGrid; offset::Float64=0.0, stiffness::Float64=1.0)
    lens = grid.compartmentsize * grid.n .- 2offset # nm
    cen = centerof(grid)
    k = √(stiffness) # √(pN/nm)
    planes = k*SVector{4,Float64}[
        SA[-1,0,0,-cen[1]+lens[1]/2],
        SA[+1,0,0,+cen[1]+lens[1]/2],
        SA[0,-1,0,-cen[2]+lens[2]/2],
        SA[0,+1,0,+cen[2]+lens[2]/2],
        SA[0,0,-1,-cen[3]+lens[3]/2],
        SA[0,0,+1,+cen[3]+lens[3]/2],
    ]
    Boundary(;planes)
end

"""$PUBLIC
    $(TYPEDSIGNATURES)

Return a capsule boundary.

`center`(nm): The center of the capsule.

`axis`(nm): The direction and length of the capsule spine.
The spine line segment goes from `center - axis/2` to `center + axis/2`
If zero the capsule is a sphere.

`radius`(nm): Radius of capsule, the full length of the capsule is
`norm(axis) + 2radius`.

`stiffness`(pN/nm): How strong the boundary is.
"""
function boundary_capsule(;
        center::SVector{3,Float64}=SA[0.0,0.0,0.0],
        axis::SVector{3,Float64}=SA[0.0,0.0,0.0],
        radius::Float64=0.0,
        stiffness::Float64=1.0,
    )
    start = center - axis/2
    Boundary(;capsules = [SA[start..., axis..., radius, stiffness]])
end

"""$PUBLIC
    $(TYPEDSIGNATURES)

Return a cylinder boundary.

`center`(nm): The center of the cylinder.

`axis`(nm): The direction and length of the cylinder.
The spine line segment goes from `center - axis/2` to `center + axis/2` 
the full length of the cylinder is
`norm(axis)`.

`radius`(nm): Radius of cylinder.

`stiffness`(pN/nm): How strong the boundary is.
"""
function boundary_cylinder(;
        center::SVector{3,Float64}=SA[0.0,0.0,0.0],
        axis::SVector{3,Float64}=SA[0.0,0.0,0.0],
        radius::Float64=0.0,
        stiffness::Float64=1.0,
    )
    s = center - axis/2
    e = center + axis/2
    v = normalize(axis)
    Boundary(;
        capsules = [SA[s..., axis..., radius, stiffness]],
        planes = √(stiffness)*[
            SA[v..., e⋅v],
            SA[(-v)..., -s⋅v],
        ]
    )
end

function Base.intersect(a::Boundary, b::Boundary)::Boundary
    r = Boundary()
    foreach(fieldnames(Boundary)) do k
        append!(getfield(r, k), getfield(a, k))
        append!(getfield(r, k), getfield(b, k))
    end
    r
end

"""
Return true if the point is inside the boundary
    If there is no boundary defaults to true
"""
function insideboundary(m::Boundary, point)::Bool
    for bp in m.planes
        point ⋅ bp[SOneTo(3)] < bp[4] || return false
    end
    for bc in m.capsules
        startpoint = bc[StaticArrays.SUnitRange(1,3)]
        q = point-startpoint
        p = bc[StaticArrays.SUnitRange(4,6)]
        r = bc[7]
        invpnormsqr = iszero(p⋅p) ? inv(eps(eltype(p))) : inv(p⋅p)
        d = q-clamp((q⋅p)*invpnormsqr,0,1)*p
        d⋅d < r*r || return false
    end
    return true
end

"""
Return a signeddistfun
Note, this will be invalid if the boundary gets modified
"""
function create_signeddistfun(m::Boundary; mesh = nothing)
    planes = m.planes
    capsules = m.capsules
    nhats = [normalize(bp[SOneTo(3)]) for bp in planes]
    d0s = [bp[4]/norm_fast(bp[SOneTo(3)]) for bp in planes]
    startpoints = map(capsules) do bc
        bc[StaticArrays.SUnitRange(1,3)] 
    end
    axis = map(capsules) do bc
        bc[StaticArrays.SUnitRange(4,6)]
    end
    invaxisnormsqr = map(axis) do a
        iszero(a⋅a) ? inv(eps(eltype(a))) : inv(a⋅a)
    end
    radii = [bc[7] for bc in capsules]
    function signeddistfun(pos)
        local planedist = maximum(i->(pos⋅nhats[i]-d0s[i]),eachindex(nhats); init= -Inf)
        local capsuledist = maximum(eachindex(startpoints); init= -Inf) do i
            local q = pos-@inbounds(startpoints[i])
            local p = @inbounds(axis[i])
            local invpnormsqr = @inbounds(invaxisnormsqr[i])
            local r = @inbounds(radii[i])
            norm_fast(q-clamp((q⋅p)*invpnormsqr,0,1)*p)-r
        end
        local meshdist = isnothing(mesh) ? -Inf : signed_distance(mesh, pos)
        max(planedist, capsuledist, meshdist)
    end
end

"""
Add mechboundary terms to `force_energy`.
x is dof of positions
"""
function mechboundary_forces!(force_energy::ForceEnergy, x, m::Boundary; chunk=1, nthreads=1)
    isempty(m.planes) || bounding_planes_forces!(force_energy, x, m.planes; chunk, nthreads)
    isempty(m.capsules) || bounding_capsules_forces!(force_energy, x, m.capsules; chunk, nthreads)
end

"""
Add bounding plane terms to `force_energy`.
x is dof of positions
"""
function bounding_planes_forces!(force_energy::ForceEnergy, x, planes::Vector{SVector{4,Float64}}; chunk=1, nthreads=1)
    bnum= length(planes)
    posvect= reinterpret(SVector{3,eltype(x)},x)
    @inbounds for i in index_chunks(posvect; n=nthreads)[chunk]
        pos= posvect[i]
        F = zero(posvect[i])
        E = 0.0
        for bi in 1:bnum
            bp= planes[bi]
            a= pos ⋅ bp[SOneTo(3)] - bp[4]
            d= (a > zero(a) ? a : zero(a))
            E += 1//2*d^2
            F -= d * bp[SOneTo(3)]
        end
        add_bead_force!(force_energy, i, F)
        add_energy!(force_energy, E)
    end
end

"""
Add bounding capsule terms to `force_energy`.
x is dof of positions
"""
function bounding_capsules_forces!(force_energy::ForceEnergy, x, capsules::Vector{SVector{8,Float64}}; chunk=1, nthreads=1)
    posvect= reinterpret(SVector{3,eltype(x)},x)
    for bc in capsules
        startpoint = bc[StaticArrays.SUnitRange(1,3)]
        p = bc[StaticArrays.SUnitRange(4,6)]
        r = bc[7]
        k = bc[8]
        invpnormsqr = iszero(p⋅p) ? inv(eps(eltype(p))) : inv(p⋅p)
        @inbounds for i in index_chunks(posvect; n=nthreads)[chunk]
            pos = posvect[i]
            q = pos-startpoint
            d⃗ = q-clamp((q⋅p)*invpnormsqr,0,1)*p
            d = norm_fast(d⃗)
            d̂ = d⃗/d
            a = d - r
            Δ = (a > zero(a) ? a : zero(a))
            F = (-Δ*k)*d̂
            E = 1//2*k*Δ^2
            add_bead_force!(force_energy, i, F)
            add_energy!(force_energy, E)
        end
    end
end