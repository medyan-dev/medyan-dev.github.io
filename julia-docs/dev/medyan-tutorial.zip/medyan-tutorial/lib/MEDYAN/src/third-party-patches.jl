# This file contains patches to third party packages that have yet to be merged.

# __precompile__(false)

using Dictionaries
function Base.deepcopy_internal(dict::Dictionary{I,T}, id::IdDict) where {I,T}
    if haskey(id, dict)
        id[dict]::Dictionary{I,T}
    else
        id[dict] = Dictionary{I,T}(Base.deepcopy_internal(keys(dict), id), Base.deepcopy_internal(collect(dict), id))
    end
end
