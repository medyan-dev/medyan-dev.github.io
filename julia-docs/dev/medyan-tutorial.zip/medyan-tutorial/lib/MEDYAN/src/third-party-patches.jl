# This file contains patches to third party packages that have yet to be merged.

# __precompile__(false)

