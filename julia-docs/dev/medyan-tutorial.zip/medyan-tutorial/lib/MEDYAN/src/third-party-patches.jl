# This file contains patches to third party packages that have yet to be merged.

__precompile__(false)

using Dictionaries
Base.deepcopy_internal(dict::Dictionary{I,T}, id::IdDict) where {I,T} = Dictionary{I,T}(Base.deepcopy_internal(keys(dict), id), Base.deepcopy_internal(collect(dict), id))
function Base.deepcopy_internal(ind::Indices{T}, id::IdDict) where {T}
    return Indices{T}(Base.deepcopy_internal(collect(ind), id))
end