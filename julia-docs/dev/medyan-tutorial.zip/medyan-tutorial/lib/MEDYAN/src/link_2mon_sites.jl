"""
Commonly used link_2mon sites
"""

using LinearAlgebra
using StaticArrays


"""
Test that a type follows the interface and check for basic errors
"""
function statictest_link_2mon_site(sitetype::Type, link_2mon_statetype::Type, mechparamstype::Type)
    JET.report_call((
            sitetype,
            link_2mon_statetype,
            mechparamstype,
            Int,
            Int,
            SVector{3,MonomerState},
            SVector{3,MonomerState},
            SVector{3,Float64},
            SVector{3,Float64},
            SVector{3,Float64},
            SVector{3,Float64},
        );
        # print_inference_success=false,
    ) do site,link_2mon_state,mechparams,minusftid,plusftid,minusmonomerstates,plusmonomerstates,m_pos,p_pos,m_plusv,p_plusv
        link_2mon_sitecount(site,link_2mon_state,mechparams,minusftid,plusftid,minusmonomerstates,plusmonomerstates,m_pos,p_pos,m_plusv,p_plusv)::Float64
    end
end




"""$PUBLIC
Always returns 1.0
"""
struct Link2MonSiteOne end

function link_2mon_sitecount(site::Link2MonSiteOne,
    link_2mon_state, mechparams,
    minusftid, plusftid,
    minusmonomerstates, plusmonomerstates,
    m_pos, p_pos, m_plusv, p_plusv)
    return 1.0
end


"""$PUBLIC
Returns `link_2mon_state.chemstate.sitecount`
"""
struct Link2MonSiteCount end

function link_2mon_sitecount(site::Link2MonSiteCount,
    link_2mon_state, mechparams,
    minusftid, plusftid,
    minusmonomerstates, plusmonomerstates,
    m_pos, p_pos, m_plusv, p_plusv)
    return link_2mon_state.chemstate.sitecount
end


"""$PUBLIC
Returns 1.0 if the monomer states match, otherwise, returns 0.0.

$(TYPEDFIELDS)
"""
struct Link2MonSiteMonomerStateMatch
    "minus end monomer state"
    minusstate::NTuple{3, MonomerState}

    "plus end monomer state"
    plusstate::NTuple{3, MonomerState}
end

function link_2mon_sitecount(site::Link2MonSiteMonomerStateMatch,
    link_2mon_state, mechparams,
    minusftid, plusftid,
    minusmonomerstates, plusmonomerstates,
    m_pos, p_pos, m_plusv, p_plusv)
    if minusmonomerstates == site.minusstate && plusmonomerstates == site.plusstate
        1.0
    else
        0.0
    end
end


"""$PUBLIC
Models unbinding rates based on the
following exponential form of Bell et al, 1978:
    min(k0*exp(f/f0), kmax)
Where f is the magnitude of the force.
So as to exponetially increase the unbinding with more force.

`link_2mon_sitecount` returns the unbinding rate in units of 1/s
It returns k0 if the link_2mon hasn't been minimized yet.

$(TYPEDFIELDS)
"""
Base.@kwdef struct Link2MonSiteSlipBond
    "The charicteristic force magnitude. Units of pN"
    f0::Float64

    "Unbinding rate at zero force. Units of 1/s"
    k0::Float64

    "Maximum rate. Units of 1/s"
    kmax::Float64=Inf
end

function link_2mon_sitecount(
    site::Link2MonSiteSlipBond,
    link_2mon_state, mechparams,
    minusftid, plusftid,
    minusmonomerstates, plusmonomerstates,
    m_pos, p_pos, m_plusv, p_plusv
)
    if (link_2mon_state.is_minimized)
        E, mf, pf, mfv, pfv = link_2mon_force(link_2mon_state.mechstate, mechparams, m_pos, p_pos, m_plusv, p_plusv)
        min(site.k0 * exp(max(norm_fast(mf), norm_fast(pf)) * inv(site.f0)), site.kmax)
    else
        site.k0
    end
end


"""$PUBLIC
The catch-bond nature of myosin unbinding with multiple heads.
    Adopted from the results of Erdmann et al. 2013. The parallel cluster model.

As the force increases, the motor unbinding rate decreases to a minimum of k0/10

`link_2mon_sitecount` returns the unbinding rate in units of 1/s
It returns k0 if the link_2mon hasn't been minimized yet.
It assumes link_2mon_state.chemstate.numHeads exists for the link_2mon.

$(TYPEDFIELDS)
"""
Base.@kwdef struct Link2MonSiteMotorCatch
    "single head characteristic unbinding force, units of pN/head"
    f0::Float64 = 12.62 #default MEDYAN example

    "single head binding rate, units of 1/s"
    onRate::Float64 = 0.2 #default MEDYAN example

    "single head unbinding rate, units of 1/s"
    offRate::Float64 = 1.7 #default MEDYAN example

    "slope of head binding, units of (head)/(pN/head)"
    β::Float64 = 2.0 #default MEDYAN example
end

function link_2mon_sitecount(
    site::Link2MonSiteMotorCatch,
    link_2mon_state, mechparams,
    minusftid, plusftid,
    minusmonomerstates, plusmonomerstates,
    m_pos, p_pos, m_plusv, p_plusv
)
    #number of heads
    numHeads = link_2mon_state.chemstate.numHeads
    #dutyRatio
    ρ = site.onRate / (site.onRate + site.offRate)
    #unbinding rate at zero force
    k0 = site.onRate * numHeads / ((1 - ρ)^-numHeads - 1)
    if (link_2mon_state.is_minimized)
        #get tension force
        E, mf, pf, mfv, pfv = link_2mon_force(link_2mon_state.mechstate, mechparams, m_pos, p_pos, m_plusv, p_plusv)
        Fext = max(norm_fast(mf), norm_fast(pf))
        #number of bound heads
        numBoundHeads = min(numHeads, ρ * numHeads + site.β * Fext / numHeads)
        k0 * max(0.1, exp(-Fext / (numBoundHeads * site.f0)))
    else
        #assume zero force if not yet minimized
        k0
    end
end


"""$PUBLIC
Models myosin walking rates 
    from the results of Erdmann et al. 2013. The parallel cluster model.

As the motor work per step increases, its walking rate goes to zero.

Returns the walking rate of one end. 
The callback can then sample which end to move, or reject the move.

$(TYPEDFIELDS)
"""
Base.@kwdef struct Link2MonSiteMotorStall
    "The stall force magnitude. Units of pN"
    fs::Float64

    "Walking rate of one end at zero force. Units of 1/s"
    k0::Float64

    "Positive dimensionless parameter defining the steepness of the curve,
    smaller is more steep, if α is inf, the curve is linear"
    α::Float64 = 0.2

    "Motor walking direction, +1 is towards plus end, -1 is towards minus end"
    walking_direction::Int32 = +1

    "which motor end does this represent"
    isminusend::Bool
end

function link_2mon_sitecount(
    site::Link2MonSiteMotorStall,
    link_2mon_state, mechparams,
    minusftid, plusftid,
    minusmonomerstates, plusmonomerstates,
    m_pos, p_pos, m_plusv, p_plusv
)
    #get drag force
    E, mf, pf, mfv, pfv = link_2mon_force(link_2mon_state.mechstate, mechparams, m_pos, p_pos, m_plusv, p_plusv)
    Fdrag = -(site.walking_direction) * if site.isminusend
        mf ⋅ m_plusv
    else
        pf ⋅ p_plusv
    end
    Fdrag = max(0.0, Fdrag)
    site.k0 * max(0.0, (site.fs - Fdrag) / (site.fs + Fdrag / site.α))
end