using ArgCheck: @argcheck

# helper functions during transition period
function _get_fila_id(c::Context, f::FilaIdx)
    c.chem_cylinders[f.typeid].per_fil[f.idx].id
end
function _get_fila_idx(c::Context, ftid, fid)
    fidx = c.chem_cylinders[ftid].fil_id_2_idx[fid]
    _FilaIdx(ftid, fidx)
end

FilaTipIdx(c::Context, f::FilaIdx, is_minus_end::Bool) = _FilaTipIdx(f, is_minus_end)
FilaTipIdx(c::Context, f::FilaIdx, ::typeof(-)) = _FilaTipIdx(f, true)
FilaTipIdx(c::Context, f::FilaIdx, ::typeof(+)) = _FilaTipIdx(f, false)

_pack_fila_tip_idx(p::FilaTipIdx) = UInt64(p.fila_idx.typeid)<<33 | UInt64(p.fila_idx.idx) | UInt64(p.is_minus_end)<<32
_unpack_fila_tip_idx(i::UInt64) = _FilaTipIdx(_FilaIdx(i >> 33, i & 0xFFFFFFFF), (!iszero)(i & 1<<32))

function tag!(c::Context, f::FilaTipIdx)
    _tag!(c.fila_tip_tags, f)
end

