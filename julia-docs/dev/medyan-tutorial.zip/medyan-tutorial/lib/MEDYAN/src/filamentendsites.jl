"""
Commonly used filament end sites
"""

import JET

"""
Test that a type follows the interface and check for basic errors
"""
function statictest_filamentendsite(sitetype::Type)
    JET.report_call(
        (sitetype, Vector{MonomerState});
        # print_inference_success=false,
    ) do site, states
        getrange(site)::Integer
        isminusend(site)::Bool
        spacing(site)::Float64
        filamentendsitecount(site,states)::Float64
        added_monomers(site)::Integer
    end
end


"""$PUBLIC
Filament end site that matches with a vector of monomer states.

$(TYPEDFIELDS)

"""
Base.@kwdef struct FilamentEndSiteGeneral
    isminusend::Bool
    endstates::Vector{MonomerState}
    spacing::Float64
    added_monomers::Int = 0# number of monomers added
end

function FilamentEndSiteGeneral(isminusend::Bool, endstates::Vector{MonomerState}, spacing::Float64=0.0)
    FilamentEndSiteGeneral(;isminusend, endstates, spacing)
end

Base.:(==)(a::T,b::T) where T<:FilamentEndSiteGeneral = struct_equal(a, b)
Base.hash(x::FilamentEndSiteGeneral, h::UInt) = struct_hash(x,h)

getrange(site::FilamentEndSiteGeneral) = length(site.endstates)

isminusend(site::FilamentEndSiteGeneral) = site.isminusend

spacing(site::FilamentEndSiteGeneral) = site.spacing

added_monomers(site::FilamentEndSiteGeneral) = site.added_monomers

function filamentendsitecount(site::FilamentEndSiteGeneral,states)::Float64
    if states == site.endstates
        return 1.0
    else
        return 0.0
    end
end