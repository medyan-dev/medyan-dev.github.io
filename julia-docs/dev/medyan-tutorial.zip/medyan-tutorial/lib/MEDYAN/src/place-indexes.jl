"""
Represents a temporarily valid references.
"""
struct FilaIdx
    typeid::Int32
    idx::Int32
    global _FilaIdx(typeid, idx) = new(typeid, idx)
end


struct FilaTipIdx <: Place
    fila_idx::FilaIdx
    is_minus_end::Bool
    global _FilaTipIdx(fila_idx, is_minus_end) = new(fila_idx, is_minus_end)
end
null_place(::Type{FilaTipIdx}) = _FilaTipIdx(_FilaIdx(0,0),false)

