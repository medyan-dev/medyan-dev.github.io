using StaticArrays
using LinearAlgebra


"""
$(TYPEDFIELDS)

Required mechstate feilds:
    `mr0::SVector{3,Float64}` - minus end equilibrium position in the sim frame

    `mv̂0::SVector{3,Float64}`` - minus end equilibrium plus unit vector in the sim frame
"""
Base.@kwdef struct RestraintMechParams
    "position spring constant"
    kr::Float64

    "plus unit vector spring constant"
    kv̂::Float64
end

"""
restraint force on minus end
"""
function link_2mon_force(data,mechparams::RestraintMechParams,mr,pr,mv̂,pv̂)
    Δr = mr - data.mr0
    Δv̂ = mv̂ - data.mv̂0
    E = 1//2*mechparams.kr*(Δr⋅Δr) + 1//2*mechparams.kv̂*(Δv̂⋅Δv̂)
    mf = -mechparams.kr*Δr
    mfv = -mechparams.kv̂*Δv̂
    pf = zero(mf)
    pfv = zero(pv̂)
    E, mf, pf, mfv, pfv
end