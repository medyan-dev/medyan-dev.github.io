using StaticArrays
using LinearAlgebra
using Random
import ForwardDiff

"""
Functions to help test link_2mon implementations.
"""

"""
Test link_2mon_force against the result from ForwardDiff
mr, pr, mv̂, pv̂ are the two monomer positions 
and plus end vectors at the test point.

AssertionError gets thrown if anything fails.
"""
function helper_test_link_2mon_force_forward_diff(mechdata, mechparams, mr, pr, mv̂, pv̂; 
    gtol=1E-9)
    mv̂ = normalize(mv̂)
    pv̂ = normalize(pv̂)
    E0, mf0, pf0, mfv0, pfv0 = link_2mon_force(mechdata,mechparams,mr,pr,mv̂,pv̂)
    mfv0 = mfv0 - (mfv0⋅mv̂)*mv̂
    pfv0 = pfv0 - (pfv0⋅pv̂)*pv̂
    forcevect0 = vcat(mf0, pf0, mfv0, pfv0)
    x0 = vcat(mr,pr,mv̂,pv̂)
    g = ForwardDiff.gradient(x0) do x
        local mr = x[1:3]
        local pr = x[4:6]
        local mv̂ = normalize(x[7:9])
        local pv̂ = normalize(x[10:12])
        E, mf, pf, mfv, pfv = link_2mon_force(mechdata,mechparams,mr,pr,mv̂,pv̂)
        return E
    end
    @assert maximum(abs,forcevect0 + g) < gtol "Force error, $(maximum(abs,forcevect0 + g)) < $gtol \n ForwardDiff: $(-g) \n vs $forcevect0"
    return true
end

"""
Test link_2mon_force at a local minimum energy.
mr, pr, mv̂, pv̂ are the two monomer positions 
and plus end vectors at the minimum energy point.

AssertionError gets thrown if not at a local min.
"""
function helper_test_link_2mon_force_at_min(mechdata, mechparams, mr, pr, mv̂, pv̂; 
        gtol=1E-5, ftol=1E-10, rstd=1E-3, seed=1234, trials=100000)
    mv̂ = normalize(mv̂)
    pv̂ = normalize(pv̂)
    #check forces are small
    E, mf, pf, mfv, pfv = link_2mon_force(mechdata,mechparams,mr,pr,mv̂,pv̂)
    @assert maximum(abs,mf) < gtol "mf: $mf not within $gtol of 0\n mr: $mr\n pr: $pr\n mv̂: $mv̂\n pv̂: $pv̂\n"
    @assert maximum(abs,pf) < gtol "pf: $pf not within $gtol of 0\n mr: $mr\n pr: $pr\n mv̂: $mv̂\n pv̂: $pv̂\n"
    @assert maximum(abs,mfv - (mfv⋅mv̂)*mv̂) < gtol "mfv: $mfv not within $gtol of 0\n mr: $mr\n pr: $pr\n mv̂: $mv̂\n pv̂: $pv̂\n"
    @assert maximum(abs,pfv - (pfv⋅pv̂)*pv̂) < gtol "pfv: $pfv not within $gtol of 0\n mr: $mr\n pr: $pr\n mv̂: $mv̂\n pv̂: $pv̂\n"
    #check no nearby positions have lower energy
    rng= Random.Xoshiro(seed)
    for i in 1:trials
        mrtest = mr + rstd*randn(rng,SVector{3,Float64})
        prtest = pr + rstd*randn(rng,SVector{3,Float64})
        mv̂test = normalize(mv̂ + rstd*randn(rng,SVector{3,Float64}))
        pv̂test = normalize(pv̂ + rstd*randn(rng,SVector{3,Float64}))
        Etest, mf, pf, mfv, pfv = link_2mon_force(mechdata,mechparams,mrtest,prtest,mv̂test,pv̂test)
        @assert Etest-E > -ftol "Energy not minimum, Etest - E : $(Etest-E), ftol: $ftol"
    end
    return true
end
