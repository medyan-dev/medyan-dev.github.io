using StaticArrays
using LinearAlgebra

"""
$(TYPEDFIELDS)
"""
Base.@kwdef struct BranchBendingCosineMechParams
    "position spring constant"
    kr::Float64

    "angle spring constant pN/rad"
    kbend::Float64

    "equilibrium cos angle"
    cos0::Float64

    "equilibrium sin angle"
    sin0::Float64
end


function link_2mon_force(data,mechparams::BranchBendingCosineMechParams,mr,pr,mv̂,pv̂)
    Δr = pr - mr
    Epos = 1//2 * mechparams.kr * (Δr ⋅ Δr)
    mf = mechparams.kr * Δr
    pf = -mf
    cosθ = mv̂ ⋅ pv̂
    sinθ = norm_fast(mv̂ × pv̂)
    cosθminus0 = cosθ*mechparams.cos0 + sinθ*mechparams.sin0
    Eθ = mechparams.kbend*(1-cosθminus0)
    k = mechparams.kbend*(mechparams.cos0 - mechparams.sin0*(cosθ/sinθ))
    mfv = k * pv̂
    pfv = k * mv̂
    E = Epos + Eθ                                                                                                                                                                                         
    E, mf, pf, mfv, pfv
end