using StaticArrays
using LinearAlgebra

"""
$(TYPEDFIELDS)
"""
Base.@kwdef struct RelativeRestraintMechParams
    "position spring constant"
    kr::Float64

    "plus unit vector spring constant"
    kv̂::Float64

    "equilibrium position in the mv,mpr frame"
    pr0_mvxmpr::SVector{3,Float64}

    "equilibrium plus unit vector"
    pv̂0_mvxmpr::SVector{3,Float64}
end


function link_2mon_force(data,mechparams::RelativeRestraintMechParams,mr_sim,pr_sim,mv̂_sim,pv̂_sim)
    @assert mechparams.pr0_mvxmpr[3] == 0 "non zero z component in mechparams.pr0_mvxmpr not supported yet"
    mpr_sim = pr_sim - mr_sim
    x̂mvxmpr_sim = mv̂_sim
    ẑmvxmpr_sim = normalize_fast(cross(mv̂_sim,mpr_sim))
    ŷmvxmpr_sim = cross(ẑmvxmpr_sim,x̂mvxmpr_sim) #normalize_fast(mpr_sim - (mv̂_sim ⋅ mpr_sim)*mv̂_sim) 
    dcm_sim_mvxmpr = [x̂mvxmpr_sim ŷmvxmpr_sim ẑmvxmpr_sim]
    pr0_sim = dcm_sim_mvxmpr * mechparams.pr0_mvxmpr
    pv̂0_sim = dcm_sim_mvxmpr * mechparams.pv̂0_mvxmpr
    Δr_sim = mpr_sim - pr0_sim
    Δv̂_sim = pv̂_sim - pv̂0_sim
    E = 1//2*mechparams.kr*(Δr_sim⋅Δr_sim) + 1//2*mechparams.kv̂*(Δv̂_sim⋅Δv̂_sim)
    pfv_sim = -mechparams.kv̂*Δv̂_sim
    pmomentv_sim = cross(pv̂_sim,pfv_sim)
    pf_sim = -mechparams.kr*Δr_sim + (-(pmomentv_sim⋅x̂mvxmpr_sim)/(mpr_sim⋅ŷmvxmpr_sim))*ẑmvxmpr_sim
    mf_sim = -pf_sim
    moment_sim = cross(mpr_sim,pf_sim) + pmomentv_sim
    mfv_sim = -(moment_sim⋅ẑmvxmpr_sim)*ŷmvxmpr_sim + (moment_sim⋅ŷmvxmpr_sim)*ẑmvxmpr_sim                                                                                                                                                                                                  
    E, mf_sim, pf_sim, mfv_sim, pfv_sim
end