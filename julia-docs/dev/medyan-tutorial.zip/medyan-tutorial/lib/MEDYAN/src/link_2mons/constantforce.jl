using StaticArrays
using LinearAlgebra

"""
Constant force on negative end

Required mechstate feilds:
    `f::SVector{3,Float64}` - Force in pN in the sim frame
"""
struct ConstantForceMechParams
end

function link_2mon_force(mechstate,mechparams::ConstantForceMechParams,mr,pr,mv̂,pv̂)
    E = -(mechstate.f ⋅ mr)
    E, mechstate.f, zero(mechstate.f), zero(mechstate.f), zero(mechstate.f)
end