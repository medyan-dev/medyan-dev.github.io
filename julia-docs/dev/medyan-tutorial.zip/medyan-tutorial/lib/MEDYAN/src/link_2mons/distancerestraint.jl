using StaticArrays
using LinearAlgebra

"""
$(TYPEDFIELDS)

Required mechstate feilds:
    `L0::Float64` - equilibrium length

"""
Base.@kwdef struct DistanceRestraintMechParams
    "spring constant"
    k::Float64
end


function link_2mon_force(mechstate,mechparams::DistanceRestraintMechParams,mr_sim,pr_sim,mv̂_sim,pv̂_sim)
    r = pr_sim - mr_sim
    L = norm_fast(r)
    ΔL = L-mechstate.L0
    E = 1//2*mechparams.k*ΔL^2
    pf_sim = -mechparams.k*ΔL*r/L
    mf_sim = -pf_sim
    E, mf_sim, pf_sim, zero(mf_sim), zero(mf_sim)
end