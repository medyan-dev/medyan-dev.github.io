# Empty link_2mon

"""
Zero energy and force
"""
function link_2mon_force(data,mechparams::Nothing,mr,pr,mv̂,pv̂)
    mf = zero(pr)
    mfv = zero(pv̂)
    pf = zero(pr)
    pfv = zero(pv̂)
    0.0, mf, pf, mfv, pfv
end