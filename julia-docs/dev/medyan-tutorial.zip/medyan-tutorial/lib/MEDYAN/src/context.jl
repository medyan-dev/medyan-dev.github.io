"""
Context struct and related structs and functions
"""

using FixedPointNumbers
using Dictionaries
using OffsetArrays
using Random
import Base.show


"""
Filament mechanical parameters

$(TYPEDFIELDS)
"""
Base.@kwdef struct FilamentMechParams
    "Cylinder radius (nm)"
    radius::Float64 = NaN

    "Monomer spacing length (nm)"
    spacing::Float64 = NaN

    "Length force constant (pN/nm)"
    klength::Float64 = NaN

    "Bending force constant (pN*nm/rad²)"
    kangle::Float64 = NaN

    "Number of monomers per cylinder"
    numpercylinder::Int32 = -1

    "Maximum number of unminimized monomers that can be on an end.
    This should be less than the minimum `radius` of other filaments + `radius`
    divided by `spacing`."
    max_num_unmin_end::Int32 = -1
end

"""
Membrane mechanical parameters.

$(TYPEDFIELDS)
"""
Base.@kwdef struct MembraneMechParams
    "Membrane bending coefficient (pN nm)"
    kbend::Float64 = 0
    "Equilibrium curvature (1/nm)"
    eqcurv::Float64 = 0

    "Membrane area elasticity (pN/nm)"
    karea::Float64 = 0
    "Equilibrium area (nm^2)"
    eqarea::Float64 = 1

    "Membrane tension (pN/nm)"
    tension::Float64 = 0

    "Volume conservation k (pN/nm^2)"
    kvolume::Float64 = 0
    "Equilibrium volume (nm^3)"
    eqvolume::Float64 = 1
    "Actual volume is cone volume with the origin plus the offset."
    offsetvolume::Float64 = 0

    "Pinning strength k (pN/nm)"
    kpinning::Float64 = 0

    """
    Controls the minimum edge length when using mem3dg method of computing curvatures.
    This is to prevent minimization issues.
    When the edge length drops below min, a FENE-like potential will be applied.
    """
    edgelength_mem3dg_min::Float64 = 5.0
    edgelength_mem3dg_k::Float64 = 0.0
end

"""
Shared configurations for the entire simulation, stored as types.

$(TYPEDFIELDS)
"""
Base.@kwdef struct SharedTypedConfigs{
        WhichMeshCurv,
        WhichMeshBoundaryPinningMode,
        WhichBendingMode,
    }

    "Which mesh curvature formula to use. `WhichMeshCurv` must be of type `MeshCurvatureFormula`."
    meshcurv::Val{WhichMeshCurv} = Val(meshcurv_mem3dg)

    "Which mesh boundary pinning method to use. Must be within :none, :border1 and :border2."
    mesh_boundary_pinning_mode::Val{WhichMeshBoundaryPinningMode} = Val(:border2)

    "With local curvature, how to compute bending energy. Must be :normal or :bashkirov."
    bending_mode::Val{WhichBendingMode} = Val(:normal)
end

"""
Membrane-filament mechanical interaction parameters.

$(TYPEDFIELDS)
"""
Base.@kwdef struct MembraneFilamentMechParams
    "Triangle-bead volume exclusion constant (pN nm^3)"
    kvolexcl::Float64 = 650
    "Cutoff (nm) outside which energy is zero."
    cutoffvolexcl::Float64 = 100
end

"""
Membrane protein physical parameters.
$(TYPEDFIELDS)
"""
Base.@kwdef struct MembraneSpeciesParams
    "Membrane diffusion coefficients (nm^2/s)."
    diffusion_coeff::Float64 = 0
    "Protein area projected onto the surface (nm^2)."
    area::Float64 = 0
    "Bending rigidity (pN nm)."
    kbend::Float64 = 0
    "The protein's own spontaneous mean curvature (/nm). Can be used in bending energy computations with curvatures."
    eqcurv::Float64 = 0
end
export MembraneSpeciesParams


"""
The chemistry state of a segment of a filament fully contained in a compartment

$(TYPEDFIELDS)
"""
Base.@kwdef mutable struct Segment
    "Compartment id"
    cid::Int32

    "filament type id"
    ftid::Int

    "filament id"
    fid::Int

    "first monomer id, on minus end"
    midminusend::Int

    "last monomer id, on plus end"
    midplusend::Int

    "compartment id of the next segment on the plus end, -1 if no next segment"
    plusend_cid::Int32

    "compartment id of the previous segment on the minus end, -1 if no previous segment"
    minusend_cid::Int32

    "filament site counts from this segment, indexed by filament site id"
    filamentsitecounts::Vector{Q31f32}

    "filament end site counts from this segment, indexed by filament site id"
    filamentendsitecounts::Vector{Q31f32}

end

"""
Shallow copy, 
https://stackoverflow.com/questions/51956958/how-to-copy-a-struct-in-julia
"""
Base.copy(s::Segment) = Segment((getfield(s, k) for k ∈ fieldnames(Segment))...)

isminusendsegment(s::Segment) = s.minusend_cid == -1

isplusendsegment(s::Segment) = s.plusend_cid == -1



"""
The chemistry state of a compartment, not including diffusing species

$(TYPEDFIELDS)
"""
Base.@kwdef struct Compartment
    id::Int32

    "A Vector of compartment ids that touch this compartment, excuding self id"
    neighbor_ids::Vector{Int32}

    """
    All filament segments within this compartment.
    This is valid if the parent context `SEGMENTS` flag is set.
    indexed by filament type id, arbitrary segment id
    """
    segments::Vector{Vector{Segment}}

    """
    All vertices within this compartment.
    This is valid if the parent context `VERTEX_IN_COMPARTMENT` flag is set.
    This can be used in chemistry, so it should be updated before chemistry and remain fixed during chemistry.
    """
    vertexnames::Vector{VertexName} = []

end

"""
Empty Compartment constructor

$(TYPEDFIELDS)
"""
function Compartment(id,neighbor_ids,num_filament_types::Integer)
    Compartment(;
        id,
        neighbor_ids,
        segments = [[] for i in 1:num_filament_types],
        #num_possiblecadherinsite_types,
    )
end

"""
Return the segment id and segment with the monomername in the compartment
"""
function findsegment(comp::Compartment,name::MonomerName)
    sid = findfirst(comp.segments[name.ftid]) do seg
        seg.fid == name.fid && (name.mid in seg.midminusend:seg.midplusend)
    end
    isnothing(sid) && error("No segment found for $name in compartment $(comp.cid)")
    return sid, comp.segments[name.ftid][sid]
end

"""
Holds various counters and other useful stats accumulated during a simulation

All fields must have a default value.

$(TYPEDFIELDS)

"""
Base.@kwdef mutable struct PerformanceStats
    "number of times the force/energy was evaluated during energy minimization"
    force_evals_count::Int = 0

    "number of reactions fired"
    reaction_count::Int = 0

    "number of times any reaction callback was called
    Note, callbacks are prepended when defining a system, 
    so `callback_reaction_count[end]` is the callback added first, and 
    `callback_reaction_count[1]` is the callback added last"
    callback_reaction_count::Vector{Int} = []

    "number of calls to chem_setmonomerstate!"
    chem_setmonomerstate_count::Int = 0

    "number of calls to chem_polymerize!"
    chem_polymerize_count::Int = 0

    "number of calls to chem_depolymerize!"
    chem_depolymerize_count::Int = 0

    "number of calls to make_link!"
    make_link_count::Int = 0

    "number of calls to remove_link!"
    remove_link_count::Int = 0

    "number of calls to update_link!"
    update_link_count::Int = 0

    "number of calls to chem_newcadherin!"
    chem_newcadherin_count::Int = 0

    "number of calls to chem_removecadherin!"
    chem_removecadherin_count::Int = 0

    "number of calls to chem_setcadherinstate!"
    chem_setcadherinstate_count::Int = 0

    "number of calls to chem_newfilament!"
    chem_newfilament_count::Int = 0

    "number of calls to chem_removefilament!"
    chem_removefilament_count::Int = 0

    "Number of events of membrane species diffusing."
    chem_membranediffusing_count::Int = 0

    "Number of events of membrane site reactions."
    chem_membranesite_count::Int = 0

end

"""$PUBLIC
    Context(sys_def::SysDef, grid::CubicGrid; kwargs...)

$(TYPEDFIELDS)

"""
Base.@kwdef struct Context{
        GRID_TYPE,
        NUM_MEMBRANEDIFFUSINGSPECIES,
        RDMESAMPLER_TYPE <: RDMESampler,
        FILAMENTSITES_TYPE <: Tuple{Vararg{Tuple{Vararg{SiteData}}}},
        FILAMENTENDSITES_TYPE <: Tuple{Vararg{Tuple{Vararg{SiteData}}}},
        MEMBRANESITES_TYPE <: Tuple{Vararg{SiteData}},
        MAP_MEMDIFFU_MEMSITE_TYPE <: Tuple{Vararg{Vector{Int}}},
        MEMBRANEMESH_TYPE,
        DECIMATED_2MON_SITES_TYPE <: Tuple{Vararg{SiteData}},
        DECIMATED_2MON_SITES_MANAGERS_TYPE <: Tuple{Vararg{AbstractDecimated2MonSiteManager}},
        CADHERINSITES_TYPE <: Tuple{Vararg{Tuple{Vararg{SiteData}}}},
        # POSSIBLECADHERINSITES_TYPE <: Tuple{Vararg{SiteData}},
	    CADHERINDATA_TYPE <: Tuple{Vararg{CadherinData}},
        POSSIBLECADHERINSITESMANAGERS_TYPE <: Tuple{Vararg{AbstractPossibleCadherinSiteManager}},
        CALLBACKS_TYPE,
        ExternalEnergyForce,
        FuncMembraneSpeciesPotentialEnergy,
        SHARED_TYPED_CONFIGS_TYPE <: SharedTypedConfigs,
    }
    agent_names::AgentNames

    sys_def::SysDef

    compartments::Vector{Compartment}

    grid::GRID_TYPE

    "time (s)"
    time::Ref{Float64}

    stats::PerformanceStats

    "inverse kT (1/(nm*pN))"
    β::Float64

    "Diffusion coefficients indexed by diffusing species id (nm²/s)"
    base_diffusion_coeffs::Vector{Float64}

    "Membrane species parameters indexed by membrane diffusing species id."
    membrane_species_params::SVector{NUM_MEMBRANEDIFFUSINGSPECIES,MembraneSpeciesParams}

    "Smallest volume a compartment can have before being deactivated
    as a ratio to a full compartment volume."
    min_compartment_volume_ratio::Float64

    "The reaction diffusion master equation sampler,
    contains the diffusing and regular fixed species state"
    chemistryengine::RDMESAMPLER_TYPE

    "The largest filament id, indexed by filament type id"
    largestfilamentid::Vector{Int}

    "Data about filament cylinders, indexed by filament type id"
    chem_cylinders::Vector{ChemCylinders}

    "All membrane meshes."
    membranes::Vector{MEMBRANEMESH_TYPE}

    link_manager::LinkManager

    "Site managers, indexed by site id"
    decimated_2mon_site_managers::DECIMATED_2MON_SITES_MANAGERS_TYPE

    "The filament site definitions,
    indexed by filament type id, filament site id
    to get a SiteData with fields of id, site, fxsid"
    filamentsites::FILAMENTSITES_TYPE

    "The filamentend site definitions,
    indexed by filament type id, filamentend site id
    to get a SiteData with fields of id, site, fxsid"
    filamentendsites::FILAMENTENDSITES_TYPE

    "The maximum plus range in monomers that any filament site or end site can see.
    Indexed by filament type id"
    maxfilsite_plusrange::Vector{Int}

    "The maximum minus range in monomers that any filament site or end site can see.
    Indexed by filament type id"
    maxfilsite_minusrange::Vector{Int}

    "Maps membrane site id to a SiteData with fields of id, site, fxsid."
    membranesites::MEMBRANESITES_TYPE

    """
    Maps membrane diffusing species index to a list of membrane sites using this species as reactant.
    This is initialized during context init and should not be changed.
    """
    map_membranediffusingspeciesindex_membranesiteindices::MAP_MEMDIFFU_MEMSITE_TYPE

    "Site definitions,
    indexed by site id
    to get a SiteData with fields of id, site, fxsid"
    decimated_2mon_sites::DECIMATED_2MON_SITES_TYPE

    cadherinsites::CADHERINSITES_TYPE

    # possiblecadherinsites::POSSIBLECADHERINSITES_TYPE
    
    # vertexsites::VERTEXSITES_TYPE

    cadherindata::CADHERINDATA_TYPE

    "Site managers, indexed by site id"
    possiblecadherinsite_managers::POSSIBLECADHERINSITESMANAGERS_TYPE

    "Dictionary of all vertices that have a bound cadherin.
    indexed by vertex name, then cadherintypeid, 
    to give a vector of unique cadherin endnames that reference the monomer name and vertex name"
    cadherinlinked_vertices::Dictionary{VertexName,Vector{Vector{Pair{VertexName,MonomerName}}}}

    "If true site counts are checked 
        for errors on every chem update.
        This is extremely slow, but useful for testing 
        chem update errors."
    check_sitecount_error::Bool

    compartmentreactioncallbacks::CALLBACKS_TYPE
    bulkreactioncallbacks::CALLBACKS_TYPE

    "Mock bulk species index for membrane diffusion."
    memdiff_bulks_index::Int = 0

    ## Mechanics
    "viscosity (pN*s/nm² or MPa*s) water is about 1E-9"
    viscosity::Float64

    "maximum force magnitude after minimization (pN)"
    g_tol::Float64

    "number of fractional bits used to scale force values into Int64"
    nforce_fractbit::Int64

    "number of fractional bits used to scale energy values into Int64"
    nenergy_fractbit::Int64

    "If true, add noise to coordinates before starting minimization."
    shake_before_minimization::Bool

    "Max number of steps in conjugate gradient minimization."
    iter_max_cg_minimization::Int

    "max step to take during line search (nm)"
    maxstep::Float64

    "max cylinder force when two cylinders are at zero distance (pN)"
    max_cylinder_force::Float64

    "If true neighborlists are checked 
        for errors on every force calc.
        This is extremely slow, but useful for testing 
        neighborlist errors."
    check_neighborlist_error::Bool

    """ Experimental
    Set to more than 1 to enable multi threading.
    This is currently may result in non bitwise reproducable simulations.
    Results should be statistcally identical, but this is currently not well tested.
    """
    nthreads::Int

    "Are cylinder volume exclusion forces calculated"
    enable_cylinder_volume_exclusion::Ref{Bool}

    "Are triangle-bead volume exclusion forces calculated."
    enable_triangle_bead_volume_exclusion::Bool

    "Extra cell list cutoff radius in nm.
    The cell lists are reset after a bead moves over this amount"
    cylinder_skin_radius::Float64

    "The filament mechanical parameters, indexed by filament type id"
    filamentmechparams::Vector{FilamentMechParams}

    "Membrane mechanical parameters, indexed by membrane type id."
    membranemechparams::Vector{MembraneMechParams}

    "Membrane species potential energy function. See docs on default function for more info."
    func_membranespeciespotentialenergy::FuncMembraneSpeciesPotentialEnergy

    "Membrane-filament mechanical interaction parameters."
    membranefilamentmechparams::MembraneFilamentMechParams

    """
    External energy/force expressions.
    This should be a mutating function taking a `(fc::MEDYAN.ForceContext)`, which adds to `fc.forces, fc.energies, and fc.energy`. The energy and force must be consistent, and this is not checked.
    This can be used as ad-hoc solutions to experiment with uncommon forces, such as specifically designed attachments, etc. If this variable is used often, consider moving it into MEDYAN.
    """
    external_energy_forces!::ExternalEnergyForce

    "chemical boundary,
    updates compartment volumes and diffusion rates"
    chemboundary::Boundary

    """
    The membrane index used as chemical boundary.
    If values other than 0 is used, the actual interior region of the chemical boundary is the intersection between
    - the interior of `chemboundary`, and
    - the interior of the membrane mesh at this index.
    Note: Since the membrane may change its shape often, `set_chemboundary!` might need to be called often accordingly to update volumes of compartments.
    """
    meshindex_as_chemboundary::Ref{Int}

    "mechanical boundary"
    mechboundary::Boundary

    "Shared configurations stored in type parameters."
    sharedtypedconfigs::SHARED_TYPED_CONFIGS_TYPE

    "Interval system consistency validation flags."
    validflags::ValidFlags
end


function Context(sys_def::SysDef,grid;
    diffusion_coeffs=nothing,
    membrane_species_params = SA{MembraneSpeciesParams}[],
    rdmesamplertype::Type{SamplerType} = RDMEPropensityRejectDiffusion,
    filamentmechparams=nothing,
    membranemechparams=[],
    β=default_β,
    viscosity=1E-6,
    g_tol=0.1,
    nforce_fractbit=20,
    nenergy_fractbit=20,
    shake_before_minimization=true,
    iter_max_cg_minimization = 1000000,
    maxstep=0.7,
    max_cylinder_force=3000.0,
    check_neighborlist_error=false,
    check_sitecount_error= false,
    cylinder_skin_radius=5.0,
    min_compartment_volume_ratio=1/16,
    func_membranespeciespotentialenergy = default_membranespeciespotentialenergy,
    sharedtypedconfigs=SharedTypedConfigs(),
    external_energy_forces! = Returns(nothing),
    nthreads=1,
    ) where SamplerType <: RDMESampler
    # Set multithreading options
    # if nthreads is zero, set it to Threads.nthreads()
    nthreads = iszero(nthreads) ? Threads.nthreads() : nthreads

    #set up compartments

    num_filament_types= length(sys_def.filament)
    if isnothing(filamentmechparams)
        filamentmechparams = collect(values(sys_def.filament_params))
    else
        @warn "specifing `filamentmechparams` when constructing Context is deprecated, 
            use `add_filament_params!` on the `SysDef` instead."
    end
    length(filamentmechparams) == num_filament_types || error("length of filamentmechparams must match number of filament types")
    numcompartments= length(grid)
    compartments= Vector{Compartment}(undef,numcompartments)
    for cid in 1:length(grid)
        neighbor_ids= grid_neighbor_ids(grid,cid)
        compartments[cid]= Compartment(cid,neighbor_ids,num_filament_types)
    end
    #set up chemistry engine
    if isnothing(diffusion_coeffs)
        diffusion_coeffs = collect(values(sys_def.diffusing_coeff))
    else
        @warn "specifing diffusion coefficents when constructing Context is deprecated, 
            use `add_diffusion_coeff!` on the `SysDef` instead."
    end
    @argcheck length(diffusion_coeffs) == length(sys_def.diffusing)
    @argcheck length(membrane_species_params) == length(sys_def.membranediffusing)
    chemistryengine= rdmesamplertype{length(sys_def.diffusing),length(sys_def.allfixedspeciesnames)}()
    addgrid!(chemistryengine,grid,diffusion_coeffs)
    addcompartmentreaction!.((chemistryengine,),sys_def.compartmentreactions)
    for _ ∈ 1:length(sys_def.bulkspecies_indexmap)
        addbulkspecies!(chemistryengine, 0)
    end
    addbulkreaction!.((chemistryengine,), sys_def.bulkreactions)
    #set up callbacks
    callbacks= sys_def.compartmentreactioncallbacks
    #setup filament sites convert namedtuples to tuples
    filamentsites = Tuple.(Tuple(sys_def.filamentsite)) |> deepcopy
    filamentendsites = Tuple.(Tuple(sys_def.filamentendsite)) |> deepcopy
    maxfilsite_plusrange = zeros(Int,num_filament_types)
    maxfilsite_minusrange = zeros(Int,num_filament_types)
    for ftid in 1:num_filament_types
        #plus
        filsitemax = maximum(x->getplusrange(x.site),filamentsites[ftid]; init=0)
        filendsitemax = maximum(x->isminusend(x.site)*(getrange(x.site)-1), filamentendsites[ftid]; init=0)
        maxfilsite_plusrange[ftid] = max(filsitemax,filendsitemax)
        #minus
        filsitemax = maximum(x->getminusrange(x.site),filamentsites[ftid]; init=0)
        filendsitemax = maximum(x->!isminusend(x.site)*(getrange(x.site)-1), filamentendsites[ftid]; init=0)
        maxfilsite_minusrange[ftid] = max(filsitemax,filendsitemax)
    end
    chem_cylinders = [ChemCylinders(ftid, filamentmechparams[ftid].numpercylinder) for ftid in 1:num_filament_types]

    # Setup membrane sites.
    membranesites = deepcopy(Tuple(sys_def.membranesite))
    map_membranediffusingspeciesindex_membranesiteindices = let
        local vecmap = [Int[] for _ ∈ eachindex(sys_def.membranediffusing)]
        for siteindex ∈ eachindex(membranesites)
            site = membranesites[siteindex]
            if site.site.id_membranediffusing_reactant != 0
                push!(vecmap[site.site.id_membranediffusing_reactant], siteindex)
            end
        end
        Tuple(vecmap)
    end
    # Setup membrane types.
    MembraneMeshType = gettype_membranemesh(
        Val(tuple(propertynames(sys_def.membranediffusing)...)),
        Val(tuple(propertynames(sys_def.membranesite)...)),
    )

    # Setup links.
    link_manager=LinkManager(collect(LinkConfig, sys_def.link), length(grid))
    
    #setup decimated_2mon_sites
    decimated_2mon_sites = Tuple(sys_def.decimated_2mon_site) |> deepcopy
    decimated_2mon_site_managers = Tuple(map(decimated_2mon_sites) do decimated_2mon_site
        if allequal(getftids(decimated_2mon_site.site))
            Decimated2MonOneTypeSiteManager(grid, decimated_2mon_site; nthreads)
        else
            Decimated2MonTwoTypeSiteManager(grid, decimated_2mon_site; nthreads)
        end
    end)

    #setup possiblecadherinsites
    possiblecadherinsites = Tuple(sys_def.possiblecadherinsite) |> deepcopy
    possiblecadherinsite_managers = Tuple(map(possiblecadherinsites) do possiblecadherinsite
            PossibleCadherinSiteManager(grid, possiblecadherinsite; nthreads)
    end) 
    #cadherins
    cadherinsites = Tuple.(Tuple(sys_def.cadherinsite)) |> deepcopy
    cadherinparams= Tuple(sys_def.cadherinparams) |> deepcopy
    cadherindata = ntuple(id -> CadherinData(id,cadherinparams[id],length(grid),length(cadherinsites[id])),length(cadherinparams))

    # System consistency validations.
    validflags = ValidFlags(VFS_EMPTY)

    Context{typeof(grid),
            length(sys_def.membranediffusing),
            typeof(chemistryengine),
            typeof(filamentsites),
            typeof(filamentendsites),
            typeof(membranesites),
            typeof(map_membranediffusingspeciesindex_membranesiteindices),
            MembraneMeshType,
            typeof(decimated_2mon_sites),
            typeof(decimated_2mon_site_managers),
	        typeof(cadherinsites),
            # typeof(possiblecadherinsites),
	        typeof(cadherindata),
            typeof(possiblecadherinsite_managers),
            typeof(callbacks),
            typeof(external_energy_forces!),
            typeof(func_membranespeciespotentialenergy),
            typeof(sharedtypedconfigs),
        }(;
        agent_names = sys_def.agent_names,
        sys_def,
        compartments,
        grid,
        time= Ref(0.0),
        stats= PerformanceStats(;callback_reaction_count = zeros(Int,length(callbacks))),
        β,
        viscosity,
        g_tol,
        nforce_fractbit,
        nenergy_fractbit,
        shake_before_minimization,
        iter_max_cg_minimization,
        maxstep,
        max_cylinder_force,
        base_diffusion_coeffs= diffusion_coeffs,
        membrane_species_params,
        min_compartment_volume_ratio,
        chemistryengine,
        chem_cylinders,
        largestfilamentid= fill(0,num_filament_types),
        filamentsites,
        filamentendsites,
        maxfilsite_plusrange,
        maxfilsite_minusrange,
        membranesites,
        map_membranediffusingspeciesindex_membranesiteindices,
        membranes = [],
        link_manager,
        decimated_2mon_sites,
        check_sitecount_error,
        decimated_2mon_site_managers,
        cadherinsites,
        cadherindata,
        possiblecadherinsite_managers,
        cadherinlinked_vertices = Dictionary(),
        compartmentreactioncallbacks= callbacks,
        bulkreactioncallbacks = sys_def.bulkreactioncallbacks,
        memdiff_bulks_index = (:__MEDYAN_MEMDIFF_BULK ∈ keys(sys_def.bulkspecies_indexmap) ? sys_def.bulkspecies_indexmap.__MEDYAN_MEMDIFF_BULK : 0),
        check_neighborlist_error,
        enable_cylinder_volume_exclusion = Ref(true),
        enable_triangle_bead_volume_exclusion = true,
        cylinder_skin_radius,
        filamentmechparams= copy(filamentmechparams),
        membranemechparams,
        func_membranespeciespotentialenergy,
        membranefilamentmechparams = MembraneFilamentMechParams(),
        external_energy_forces!,
        chemboundary= Boundary(),
        meshindex_as_chemboundary = Ref(0),
        mechboundary= Boundary(),
        sharedtypedconfigs,
        nthreads,
        # possiblecadherinsites,
        # vertexsites,
        # cadherinlinked_monomers = Dictionary(),
        validflags,
    )
end



Base.show(io::IO, ::Type{<:MEDYAN.Context}) = print(io, "MEDYAN.Context{A bunch of type parameters}")

Base.show(io::IO, ::Type{MEDYAN.Context}) = print(io, "MEDYAN.Context")

function Base.show(io::IO, c::MEDYAN.Context)
    print(io, "MEDYAN.Context at time $(c.time[])s in $(c.grid)")
end

"""
    $(TYPEDSIGNATURES)
Return the number of filament types.
"""
num_filtypes(c::Context) = length(c.chem_cylinders)


"""
    $(TYPEDSIGNATURES)
Return a read only iterable of all filament ids of filament type `ftid`.

This can be invalid after any mutations to context, so collect if needed.
"""
function filtype_fil_ids(c::Context, ftid::Int)::Vector{Int}
    c.chem_cylinders[ftid].per_fil.id
end

"""
    $(TYPEDSIGNATURES)
Return the node positions of the filament
"""
function fil_node_positions(c::Context, ftid::Int, fil_id::Int)::Vector{SVector{3,Float64}}
    cylinders::ChemCylinders = c.chem_cylinders[ftid]
    fil_idx = cylinders.fil_id_2_idx[fil_id]
    _get_nodepositions(cylinders, fil_idx)
end

"""
    $(TYPEDSIGNATURES)
Return the node monomer ids of the filament.

The `fil_node_mon_ids` are the monomer ids at (slightly plus side of) the `fil_node_positions`

                                     |
                          -----+-----|-----+-----
      minus end <----       M  |  M  | (M) |  M        ----> plus end
                          -----+-----|-----+-----
                                     |
                                     ^ A node position is indicated by the line.
    
    The monomer id with parenthesis (M) will in `fil_node_mon_ids`

The first monomer id is the first monomer id on the filament.
The last monomer id is the last monomer id on the filament + 1
"""
function fil_node_mon_ids(c::Context, ftid::Int, fil_id::Int)::Vector{Int}
    cylinders::ChemCylinders = c.chem_cylinders[ftid]
    fil_idx = cylinders.fil_id_2_idx[fil_id]
    _fil_node_mon_ids(cylinders, fil_idx)
end

"""
    $(TYPEDSIGNATURES)
Return a read only OffsetVector of monomer states on a filament.

This can be invalid after any mutations to context, so copy if needed.
"""
function fil_mon_states(c::Context, ftid::Int, fil_id::Int)::OffsetVector{MonomerState, Vector{MonomerState}}
    cylinders::ChemCylinders = c.chem_cylinders[ftid]
    fil_idx = cylinders.fil_id_2_idx[fil_id]
    _fil_mon_states(cylinders, fil_idx)
end

"""
    $(TYPEDSIGNATURES)
Return a tuple (minus, plus) of the number of unminimized monomers on the minus and plus end of a filament.

This will be reset to (0, 0) by [`minimize_energy!`](@ref)

When an end is depolymerized this will decrease, but saturate at 0.
When an end is polymerized this will increase.

For example if after minimization a filament has a plus end depolymerization,
this function will return (0, 0). Then if a plus end polymerization happens,
this function will return (0, 1), even though the net change in filament length is zero.
"""
function fila_num_unmin_ends(c::Context, fila_idx::FilaIdx)::Tuple{Int, Int}
    cylinders::ChemCylinders = c.chem_cylinders[fila_idx.typeid]
    fil_idx = fila_idx.idx
    minus = cylinders.per_fil.minusend_num_notminimized[fil_idx]
    plus = cylinders.per_fil.plusend_num_notminimized[fil_idx]
    (minus, plus)
end
fila_num_unmin_ends(c::Context, t::Tag) = fila_num_unmin_ends(c, FilaIdx(c, t))

"""
    $(TYPEDSIGNATURES)
Return the vertex state on a membrane.
"""
function vertex_state(c::Context, vertexname::VertexName)::VertexState
    m = c.membranes[vertexname.membraneindex]
    vidx = m.metaattr.id2index_vertex[vertexname.vid]
    return m.vertices.attr.vertexstate[vidx]
end

"""
    $(TYPEDSIGNATURES)
Return true iff the filament and monomer exists
"""
function mon_exists(c::Context, monomer::MonomerName)::Bool
    cylinders::ChemCylinders = c.chem_cylinders[monomer.ftid]
    haskey(cylinders.fil_id_2_idx, monomer.fid) || return false
    monstates = fil_mon_states(c, monomer.ftid, monomer.fid)
    monomer.mid in eachindex(monstates)
end

"""
    $(TYPEDSIGNATURES)
Return true iff the monomer has been minimized
"""
function mon_minimized(c::Context, monomer::MonomerName)::Bool
    cylinders::ChemCylinders = c.chem_cylinders[monomer.ftid]
    fil_idx = cylinders.fil_id_2_idx[monomer.fid]
    monstates = _fil_mon_states(cylinders, fil_idx)
    minusend_num_notminimized = cylinders.per_fil.minusend_num_notminimized[fil_idx]
    plusend_num_notminimized = cylinders.per_fil.plusend_num_notminimized[fil_idx]
    startmid = firstindex(monstates) + minusend_num_notminimized
    stopmid = lastindex(monstates) - plusend_num_notminimized
    monomer.mid in startmid:stopmid
end

"""
    $(TYPEDSIGNATURES)
Return a tuple of three monomer states centered at a monomer.

If a monomer doesn't exist, its state will be zero.
The filament must exist.
"""
function mon_3states(c::Context, monomer::MonomerName)::NTuple{3,MonomerState}
    monstates = fil_mon_states(c, monomer.ftid, monomer.fid)
    mon_id = monomer.mid
    ntuple(3) do i
        i = i - 2
        if mon_id + i in eachindex(monstates)
            monstates[mon_id + i]
        else
            zero(MonomerState)
        end
    end
end

"""
    $(TYPEDSIGNATURES)
Return the monomer position.
"""
function mon_position(c::Context, monomer::MonomerName)::SVector{3,Float64}
    cylinders::ChemCylinders = c.chem_cylinders[monomer.ftid]
    fil_idx = cylinders.fil_id_2_idx[monomer.fid]
    _mon_position(cylinders, fil_idx, monomer.mid)
end

"""
    $(TYPEDSIGNATURES)
Return the unit vector toward the plus end of the filament.
"""
function mon_plusvector(c::Context, monomer::MonomerName)::SVector{3,Float64}
    cylinders::ChemCylinders = c.chem_cylinders[monomer.ftid]
    fil_idx = cylinders.fil_id_2_idx[monomer.fid]
    _mon_plusvector(cylinders, fil_idx, monomer.mid)
end

"""
    $(TYPEDSIGNATURES)
Return a tuple of position and plusvector at a monomer.
"""
function mon_position_plusvector(c::Context, monomer::MonomerName)::NTuple{2, SVector{3,Float64}}
    cylinders::ChemCylinders = c.chem_cylinders[monomer.ftid]
    fil_idx = cylinders.fil_id_2_idx[monomer.fid]
    _mon_position_plusvector(cylinders, fil_idx, monomer.mid)
end

getnum_decimated_2mon_sitetypes(c::Context) = length(c.decimated_2mon_sites)

getnumcadherintypes(c::Context) = length(c.cadherindata)

#getnumpossiblecadherinsitetypes(c::Context) = length(c.possiblecadherinsites)

getnumcompartments(c::Context) = length(c.grid)

getcompartmentvolume(c::Context, cid)::Float64 = inv(c.chemistryengine.invvolumes[cid])

getdiffusingspeciescount(c::Context, cid, dsid) = c.chemistryengine.diffusingcounts[dsid,cid]

function get_compartment_id(c::Context, monomer::MonomerName)
    monomerpos = mon_position(c, monomer)
    get_compartment_id(c, monomerpos)
end

"""
Return the nearest active compartment to position.
If there are no active compartments error.
"""
function get_compartment_id(c::Context, position::SVector{3,<:Real})
    cid = filter_grididat(id->isfinite(c.chemistryengine.invvolumes[id]),c.grid, position)
    return cid
end

function get_compartment_id_byvertexname(c::Context, vertex::VertexName)  
    m = c.membranes[vertex.membraneindex]
    vindex = m.metaattr.id2index_vertex[vertex.vid]
    return m.vertices.attr.cid[vindex]
end

"""
Pick a random compartment weighted by volume
"""
function getrandomcompartmentid(c::Context)
    mininvvolume= minimum(c.chemistryengine.invvolumes)
    maxvolume= inv(mininvvolume)
    while true
        cid= rand(1:getnumcompartments(c))
        v= getcompartmentvolume(c, cid)
        u= maxvolume*rand()
        if u ≤ v
            return cid
        end
    end
end

"""
    $(TYPEDSIGNATURES)
Time (s)
"""
set_time!(c::Context, x::Float64)::Float64 = c.time[] = x

"""
    $(TYPEDSIGNATURES)
Are cylinder volume exclusion forces calculated.
"""
set_enable_cylinder_volume_exclusion!(c::Context, x::Bool)::Bool = c.enable_cylinder_volume_exclusion[] = x


"""
    $(TYPEDSIGNATURES)
Set chemical boundary and update compartment volumes and diffusion rates.
Note, the chemboundary should be outside the mechboundary so that it is rare for 
filaments to go outside the chemboundary 

See also [`Boundary`](@ref)

# Keywords
- `planes::Vector{SVector{4,Float64}} = []`
Planes that make up the chemical boundary of the simulation

`inside = signbit(pos ⋅ planes[bi][1:3] - planes[bi][4])`

For example, a plane `[1,0,0,3]` is inside if x < 3 nm.

`2.0*[1,0,0,3]` is also inside if x < 3 nm.
- `capsules::Vector{SVector{8,Float64}} = []`
Capsules that make up the chemical boundary of the simulation.

`capsules[bi][1:3]` is the starting point of the spine line segment (nm).
`capsules[bi][4:6]` is the axis of the spine line segment (nm).
`capsules[bi][7]` is the radius (nm).
`capsules[bi][8]` is ignored.

if `capsules[bi][4:6]` is zero then the capsule is a sphere.
Capsule boundaries can be combined with plane boundaries to create cylinder boundaries.

- `meshindex_as_chemboundary::Int = 0`: Index of membrane mesh that further restricts the chem boundary. 0 for none.

The system geometry information must be up-to-date.
This mesh index is not stored in the boundary object, but is directly set in the context.
"""
set_chemboundary!(c::Context; meshindex_as_chemboundary::Int = 0, kwargs...)::Boundary = set_chemboundary!(c, Boundary(;kwargs...); meshindex_as_chemboundary)

function set_chemboundary!(c::Context, boundary::Boundary; meshindex_as_chemboundary::Int = 0)::Boundary
    if meshindex_as_chemboundary > 0
        requireall(c.validflags, VFS_MEMBRANE_GEOMETRY_SYSTEM)
    end

    foreach(fieldnames(Boundary)) do k
        copy!(getfield(c.chemboundary,k),getfield(boundary,k))
    end
    c.meshindex_as_chemboundary[] = meshindex_as_chemboundary
    grid::CubicGrid = c.grid
    L = grid.compartmentsize
    # get real volumes and areas, currently only support CubicGrid
    areas, volumes = if all(k->isempty(getfield(boundary,k)), fieldnames(Boundary)) && meshindex_as_chemboundary == 0
        fill(L^2,(6,length(grid))), fill(L^3,(length(grid)))
    else
        let grid::CubicGrid = grid, boundary::Boundary = boundary
            local signeddistfun = create_signeddistfun(boundary;
                mesh = (meshindex_as_chemboundary == 0 ? nothing : c.membranes[meshindex_as_chemboundary]),
            )
            """
            New area of each face of the cuboid
            in the order of
                1: x+
                2: x-
                3: y+
                4: y-
                5: z+
                6: z-
            """
            local areas = zeros(6,length(grid))
            local volumes = zeros(length(grid))
            for cid in 1:length(grid)
                local r::PlaneCuboidSlicingResult = function_box_slice(x->clamp(signeddistfun(x),-1E2*L,1E2*L), centerof(grid, cid) .- L/2, L;
                    samples = SA[14,14,14],
                    largeval = 1E6*L,
                )
                volumes[cid] = r.volumeIn
                #This flip is needed because PlaneCuboidSlicingResult 
                # follows a different convension to other stuff.
                # This should be standardized.
                areas[:,cid] .= flip(r, 0x07).areaIn
            end
            areas, volumes
        end
    end
    # update invvolumes, and diffusing rates, don't move any species yet
    # Set invvolumes to Inf to disable the compartment
    minvolume = L^3*c.min_compartment_volume_ratio
    invd = inv(L)
    for cid in 1:length(grid)
        if volumes[cid] < minvolume
            setinvvolume!(c.chemistryengine,cid,Inf)
        else
            setinvvolume!(c.chemistryengine,cid,inv(volumes[cid]))
        end
    end
    for cid in 1:length(grid)
        for side in 1:6
            othercid = adjacentgridid(grid, cid, side)
            otherside = ((side-1)⊻1)+1
            a = 1//2*(areas[side,cid] + areas[otherside,othercid])
            invv = c.chemistryengine.invvolumes[cid]
            otherinvv = c.chemistryengine.invvolumes[othercid]
            for dsid in 1:getnumdiffusingspecies(c.chemistryengine)
                basecoeff = c.base_diffusion_coeffs[dsid]
                newrate = if isfinite(invv) && isfinite(otherinvv)
                    basecoeff*a*invv*invd
                else
                    0.0
                end
                setdiffusionrate!(c.chemistryengine,side,dsid,cid,newrate)
            end
        end
    end
    for cid in 1:length(grid)
        helper_moveout_diffusing_species(cid->isfinite(c.chemistryengine.invvolumes[cid]), c::Context, cid)
    end
    compartmentalize!(c)
    c.chemboundary
end

"""
This function is distinct from the `set_chemboundary!` because setting mesh as boundary should be deferred after the membrane mesh is initialized and the associated geometries are updated. This function updates the mesh index used in chemboundary but does not modify the original chemboundary object.
"""
function set_meshindex_as_chemboundary!(c::Context, meshindex_as_chemboundary::Int)
    set_chemboundary!(c; meshindex_as_chemboundary, c.chemboundary.planes, c.chemboundary.capsules)
end

"""
Randomly move diffusing species out of deactivated compartment with id cid
Each diffusing species is placed at a random position in the compartment 
and then moved to the nearest compartment id where f(id) is true.
if no compartment id evaluates f(id) to true, error
"""
function helper_moveout_diffusing_species(f, c::Context, cid)
    f(cid) && return # no need to move
    for dsid in 1:getnumdiffusingspecies(c.chemistryengine)
        numtomove = c.chemistryengine.diffusingcounts[dsid,cid]
        setdiffusingspeciescount!(c.chemistryengine,dsid,cid,0)
        # This probably could be optimized by sampling a multinomial distribution of where diffusing species can go.
        # But if boundaries are moved slowly, so diffusing species have time to diffuse out of the compartments with small volumes,
        # there shouldn't be many diffusing species to move. 
        for i in 1:numtomove
            position = randompoint(c.grid, cid)
            newcid = filter_grididat(f, c.grid, position)
            incdiffusingspeciescount!(c.chemistryengine,dsid,newcid)
        end
    end
    @assert iszero(c.chemistryengine.diffusingcounts[:,cid])
    return
end


"""
    $(TYPEDSIGNATURES)

See also [`Boundary`](@ref)
"""
set_mechboundary!(c::Context; kwargs...)::Boundary = set_mechboundary!(c, Boundary(;kwargs...))

function set_mechboundary!(c::Context, x::Boundary)::Boundary
    foreach(fieldnames(Boundary)) do k
        copy!(getfield(c.mechboundary,k),getfield(x,k))
    end
    c.mechboundary
end

"""
    $(FUNCTIONNAME)(c::Context, sid, cid, inccount)
Add `inccount` to diffusing species id `sid` in compartment id `cid`
"""
chem_adddiffusingcount!(c::Context, sid, cid, inccount) = adddiffusingspeciescount!(c.chemistryengine,sid,cid,inccount)

"""
    $(FUNCTIONNAME)(c::Context; species, chem_voxel, inccount)
Add `inccount` to diffusing species id `sid` in `chem_voxel`
"""
function add_diffusing_count!(c::Context; species::Union{Symbol,Int}, chem_voxel, amount)
    sid::Int = if species isa Symbol
        c.sys_def.diffusing[species]
    else
        species
    end
    adddiffusingspeciescount!(c.chemistryengine, sid, chem_voxel, amount)
end

"""
    $(FUNCTIONNAME)(c::Context, sid, cid, inccount)
Add `inccount` to fixed species id `sid` in compartment id `cid`
"""
chem_addfixedcount!(c::Context, sid, cid, inccount) = addfixedspeciescount!(c.chemistryengine,sid,cid,inccount)

"""
    $(FUNCTIONNAME)(c::Context, dsid, inccount)
Distribute the added diffusing species count randomly to compartments weighted by volume.

 - `dsid`: diffusing species id.
 - `inccount`: amount to add.
"""
function adddiffusingcount_rand!(c::Context, dsid, inccount)
    for i in 1:inccount
        cid= getrandomcompartmentid(c)
        chem_adddiffusingcount!(c, dsid, cid, 1)
    end
end

"""
    $(TYPEDSIGNATURES)
Distribute the added membrane species count randomly to membrane cells, ignoring cell area difference.
Does NOT update propensity.
"""
function addmembranediffusingcount_rand!(c::Context, membraneindex::Int, speciesindex::Int, addcount::Int)
    m = c.membranes[membraneindex]
    vec_copynumber = getproperty(m.vertices.attr.copynumbers, speciesindex)
    nv = length(m.vertices)
    for _ ∈ 1:addcount
        vindex = rand(1:nv)
        vec_copynumber[vindex] += 1
    end
end


"""
    $(FUNCTIONNAME)(c::Context, monomerstates; iterations = 10^9, ftid = 1)
Add a filament with type id `ftid` to the Context with random center position and direction.

Return the filament id of a new filament.

`monomerstates` is a collection of the `MonomerState` of the monomers in the new filament.

The filament will be inside the mech boundary.

Errors if it fails to add a filament.

The monomer are spaced by the value in the filament type's mechanical parameters.
"""
function newfilament_rand!(c::Context, monomerstates; iterations = 10^9, ftid = 1)
	#get random position in grid
    for i in 1:iterations
        center = randompoint(c.grid)
        dir = normalize_fast(randn(SVector{3,Float64}))
        n = length(monomerstates)
        spacing = c.filamentmechparams[ftid].spacing
        L = n*spacing
        startpos = center - (L/2)*dir
        endpos = center + (L/2)*dir

        inside = insideboundary(c.mechboundary,startpos) && insideboundary(c.mechboundary,endpos)
        if inside
            node_mids = [0,]
            nodepositions = [startpos,endpos]
            return MEDYAN.chem_newfilament!(c;
                ftid,
                monomerstates,
                node_mids,
                nodepositions
            )
        end
    end
    error("failed to add new filament")
end

function newfilament_undermembrane!(c::Context, monomerstates, dist_membrane; iterations = 10^9, ftid = 1)
	#get random position in grid
    for i in 1:iterations
        center = randompoint(c.grid)
        if center[3] < dist_membrane
            center_undermembrane::SVector{3, Float64} = center
            dir = normalize(randn(SVector{3,Float64}))
            n = length(monomerstates)
            spacing = c.filamentmechparams[ftid].spacing
            L = n*spacing
            startpos = center_undermembrane - (L/2)*dir
            endpos = center_undermembrane + (L/2)*dir
            
            twoend_undermembrane::Bool = if startpos[3] < dist_membrane && endpos[3] < dist_membrane
                true
            else
                false
            end

            inside = insideboundary(c.mechboundary,startpos) && insideboundary(c.mechboundary,endpos) && twoend_undermembrane
            if inside
                node_mids = [0,]
                nodepositions = [startpos,endpos]
                return MEDYAN.chem_newfilament!(c;
                    ftid,
                    monomerstates,
                    node_mids,
                    nodepositions
                )
            end
        else
            continue
        end
    
    end
    error("failed to add new filament")
end

"""
    $(FUNCTIONNAME)(c::Context, Δt)
Run chemistry for Δt time.

Update c.time.
"""
function run_chemistry!(c::Context, Δt; before! = before_run_chemistry!_default, after! = after_run_chemistry!_default)
    before!(c)
    timeleft= Δt
    reactioncount=0
    while timeleft > 0
        rinfo= makestep!(c.chemistryengine,timeleft)
        timeleft-= rinfo.time
        reactioncount+=1
        if rinfo.info.reactiontype == :compartment && rinfo.info.reactionid ≤ length(c.compartmentreactioncallbacks)
            c.stats.callback_reaction_count[rinfo.info.reactionid] += 1
            c.compartmentreactioncallbacks[rinfo.info.reactionid](c, Int64(rinfo.info.compartmentid))
        elseif rinfo.info.reactiontype == :bulk && rinfo.info.reactionid <= length(c.bulkreactioncallbacks)
            c.bulkreactioncallbacks[rinfo.info.reactionid](c)
        end
    end
    c.time[]+= Δt
    c.stats.reaction_count += reactioncount
    after!(c)
    return
end

"""
Default function to be executed every time before chemistry.
"""
function before_run_chemistry!_default(c::Context)
    # Reset compartments and chemistry.
    compartmentalize!(c)

    # Check required flags.
    if !isempty(c.membranes)
        # Diffusion or site reactions exist.
        if c.memdiff_bulks_index > 0 || !isempty(c.membranesites)
            requireall(c.validflags, VFS_MEMBRANE_GEOMETRY_SYSTEM)
            if c.func_membranespeciespotentialenergy isa MembraneSpeciesPotentialEnergy_BendingBashkirov
                requireall(c.validflags, VFS_MEMBRANE_GEOMETRY_FF)
            end
        end
        # Site reactions exist.
        if !isempty(c.membranesites)
            requireall(c.validflags, VFS_VERTEX_IN_COMPARTMENT)
        end
    end
    # Update membrane diffusion propensities.
    if c.memdiff_bulks_index > 0
        for m ∈ c.membranes
            update_membranediffusionpropensity!(c.chemistryengine, c.memdiff_bulks_index, c.β, c.membrane_species_params, m, c.func_membranespeciespotentialenergy)
        end
    end
    # Update all membrane site counts.
    for siteindex ∈ eachindex(c.membranesites)
        for m ∈ c.membranes
            update_membranesitecount!(; rdme = c.chemistryengine, c.β, c.membrane_species_params, mesh = m, c.membranesites, siteindex, c.func_membranespeciespotentialenergy)
        end
    end
end
"""
Default function to be executed every time after chemistry.
"""
function after_run_chemistry!_default(c::Context)
    # Clear membrane diffusion propensities.
    # This step is necessary because operations outside chemistry, such as remeshing, may silently break propensity sum/maximum consistency. Therefore, it is safer to clear all propensities, forcing them to be zeros to maintain consistency.
    if c.memdiff_bulks_index > 0
        for m ∈ c.membranes
            clear_membranediffusionpropensity!(c.chemistryengine, c.memdiff_bulks_index, m)
        end
    end
    # Clear all membrane site counts.
    for siteindex ∈ eachindex(c.membranesites)
        for m ∈ c.membranes
            clear_membranesitecount!(; rdme = c.chemistryengine, mesh = m, c.membranesites, siteindex)
        end
    end
end


"""
Return a MonomerName of a random filamentsite, or return nothing if rejected
weighted by counts, using the default RNG
"""
function pickrandomfilamentsite(c::Context,cid,ftid,fsid)::Union{MonomerName,Nothing}
    helper_warn_segments_invalid!(c)
    fxsid= c.filamentsites[ftid][fsid].fxsid
    totalsites= c.chemistryengine.fixedcounts[fxsid,cid]
    if iszero(totalsites)
        return
    end
    filamentsite= c.filamentsites[ftid][fsid].site
    u::Q31f32= Q31f32(totalsites*rand())
    #go through each segment in the compartment
    comp= c.compartments[cid]
    for segment in comp.segments[ftid]
        u -= segment.filamentsitecounts[fsid]
        if u ≤ 0
            #site is on this segment, go though all monomers
            u += segment.filamentsitecounts[fsid]
            monstates = fil_mon_states(c, segment.ftid, segment.fid)
            for mid in segment.midminusend:segment.midplusend
                plusrange= getplusrange(filamentsite)
                minusrange= getminusrange(filamentsite)
                mmid= mid - minusrange
                pmid= mid + plusrange
                #make sure states are in bound
                if mmid ≥ firstindex(monstates) && pmid ≤ lastindex(monstates)
                    states= monstates[mmid:pmid]
                    u -= Q31f32(filamentsitecount(filamentsite,states))
                    if u ≤ 0
                        return MonomerName(ftid,segment.fid,mid)
                    end
                end
            end
        end
    end
    return
end


"""
Return a MonomerName of the end monomer of a random filamentend site, or return nothing if rejected
weighted by counts, using the default RNG
"""
function pickrandomfilamentendsite(c::Context,cid,ftid,fesid)::Union{MonomerName,Nothing}
    helper_warn_segments_invalid!(c)
    fxsid= c.filamentendsites[ftid][fesid].fxsid
    totalsites= c.chemistryengine.fixedcounts[fxsid,cid]
    if iszero(totalsites)
        return
    end
    filamentendsite= c.filamentendsites[ftid][fesid].site
    u::Q31f32= Q31f32(totalsites*rand())
    #go through each segment in the compartment
    comp= c.compartments[cid]
    for segment in comp.segments[ftid]
        u -= segment.filamentendsitecounts[fesid]
        if u ≤ 0
            if isminusend(filamentendsite)
                return MonomerName(ftid,segment.fid,segment.midminusend)
            else
                return MonomerName(ftid,segment.fid,segment.midplusend)
            end
        end
    end
end

function helper_filamentendsitecounts(c::Context,segment::Segment,filamentendsite)::Float64
    ftid = segment.ftid
    #minus end
    if isminusend(filamentendsite)
        if !isminusendsegment(segment)
            return 0.0
        end
        #check range
        n= getrange(filamentendsite)
        monstates = fil_mon_states(c, ftid, segment.fid)
        cylinders = c.chem_cylinders[ftid]
        fil_idx = cylinders.fil_id_2_idx[segment.fid]
        endloadforce = cylinders.per_fil.endloadforces[fil_idx][1]
        if length(monstates)<n
            return 0.0
        end
        # ensure too many monomers aren't added between minimization.
        num_added = added_monomers(filamentendsite)
        if num_added > 0
            num_unmin = cylinders.per_fil.minusend_num_notminimized[fil_idx]
            max_unmin = c.filamentmechparams[ftid].max_num_unmin_end
            @assert max_unmin ≥ 0
            if (num_added + num_unmin) > max_unmin
                return 0.0
            end
        end
        states= monstates[begin:begin+n-1]
        ratefactor= exp(-c.β*spacing(filamentendsite)*endloadforce)
        return ratefactor * filamentendsitecount(filamentendsite,states)
    #plus end
    else
        if !isplusendsegment(segment)
            return 0.0
        end
        #check range
        n= getrange(filamentendsite)
        monstates = fil_mon_states(c, segment.ftid, segment.fid)
        cylinders = c.chem_cylinders[segment.ftid]
        fil_idx = cylinders.fil_id_2_idx[segment.fid]
        endloadforce = cylinders.per_fil.endloadforces[fil_idx][2]
        if length(monstates)<n
            return 0.0
        end
        # ensure too many monomers aren't added between minimization.
        num_added = added_monomers(filamentendsite)
        if num_added > 0
            num_unmin = cylinders.per_fil.plusend_num_notminimized[fil_idx]
            max_unmin = c.filamentmechparams[ftid].max_num_unmin_end
            @assert max_unmin ≥ 0
            if (num_added + num_unmin) > max_unmin
                return 0.0
            end
        end
        states= monstates[end-n+1:end]
        ratefactor= exp(-c.β*spacing(filamentendsite)*endloadforce)
        return ratefactor * filamentendsitecount(filamentendsite,states)
    end
end

"""
Return a tuple of (minus, plus) MonomerNames of a random decimated_2mon site, or return nothing if rejected.
weighted by counts, using the default RNG.
"""
function pickrandom_decimated_2mon_site(c::Context,cid,lbsid)::Union{Tuple{MonomerName,MonomerName},Nothing}
    helper_warn_segments_invalid!(c)
    pickrandom_decimated_2mon_site(c::Context, c.decimated_2mon_site_managers[lbsid], cid)
end

"""
Return a tuple of (linker id, minus end, plus end) of a random cadherin_site, or return nothing if rejected
weighted by counts, using the default RNG
"""
function pickrandomcadherinsite(c::Context,cidv,cadtid,cadsid)::Union{Tuple{Int64,VertexName,MonomerName},Nothing}
    helper_warn_segments_invalid!(c)
    requireall(c.validflags, VFS_DEP_VERTEX_COORD)
    fxsid= c.cadherinsites[cadtid][cadsid].fxsid
    totalsites= c.chemistryengine.fixedcounts[fxsid,cidv]
    pickrandomcadherinsite(c.cadherindata[cadtid],totalsites,cidv,cadsid)
end

"""
Return a tuple of (VertexName, MonomerName) of a random possible cadherin site, or return nothing if rejected.
weighted by counts, using the default RNG.
"""
function pickrandompossiblecadherinsite(c::Context,cid,pcadsid)::Union{Tuple{VertexName,MonomerName},Nothing}
    helper_warn_segments_invalid!(c)
    requireall(c.validflags, VFS_DEP_VERTEX_COORD)
    pickrandompossiblecadherinsite(c::Context, c.possiblecadherinsite_managers[pcadsid], cid)
end


#### Chemistry Caching ####

"""
Warn if segments are invalid, then ensure they are valid.
"""
function helper_warn_segments_invalid!(c::Context)::Nothing
    if !checkall(c.validflags, VFS_SEGMENTS)
        # Find the name of the function that calls this function.
        stacktrace = StackTraces.stacktrace()
        callingfuncname = if length(stacktrace) > 1
            stacktrace[2].func
        else
            :unknown
        end
        @warn "Segments not valid in $callingfuncname, refreshing cache."
        refresh_chem_cache!(c)
    end
end

"""
    $(FUNCTIONNAME)(c::Context)::Nothing
This should only be used for advanced optimizations.

During chemistry, the context mutating functions
will typically try to avoid invalidating various cached data
needed to quickly sample sites.
    
However, if you want to mutate the context outside of chemistry,
for example right before or after minimization,
you may not want to pay the cost of revalidating all the caches
because minimization will already invalidate the caches.
Caching will be enabled again and caches will be made valid the next time chemistry is run.
Caching can also be manually refreshed and reenabled with:
[`refresh_chem_cache!`](@ref)
"""
function defer_chem_caching!(c::Context)::Nothing
    c.link_manager.cache_valid[] = false
    unset!(c.validflags, VFS_SEGMENTS)
    nothing
end

"""
    $(FUNCTIONNAME)(c::Context)::Nothing
Normally this isn't needed as it will happen automatically.
"""
function refresh_chem_cache!(c::Context)::Nothing
    compartmentalize!(c)
    nothing
end

"""
    $(FUNCTIONNAME)(c::Context)::Bool
Return true if the chemistry cache is valid, false otherwise.
"""
function is_chem_cache_valid(c::Context)::Bool
    checkall(c.validflags, VFS_SEGMENTS)
end

"""
Update caches to prepare for chemistry
"""
function compartmentalize!(c::Context)
    helper_resetsegments!(c)
    helper_reset_decimated_2mon_site_monomers!(c)
    helper_resetfilamentsitecounts!(c)
    reset_link_cache!(c.link_manager, c)
    helper_update_allverticesincompartments!(c)
    helper_resetpossiblecadherinsites!(c)
    helper_resetcadherins!(c)
    set!(c.validflags, VFS_SEGMENTS)#Whether add VFS_DEP_VERTEX_COORD
    nothing
end


"""
    $(FUNCTIONNAME)(c::Context)
Remove all 
    filaments,
    membranes,
    links,
    cadherins,
    diffusing species,
    fixed species,
    bulk species,
    chemboundary,
    and mechboundary.
"""
function Base.empty!(c::Context)
    # set all species counts to 0.
    for bulk_species_id in 1:length(c.chemistryengine.bulkcounts)
        setbulkspeciescount!(c.chemistryengine,bulk_species_id,0)
    end
    for cid in 1:length(c.grid)
        for dsid in 1:getnumdiffusingspecies(c.chemistryengine)
            setdiffusingspeciescount!(c.chemistryengine,dsid,cid,0)
        end
        for fxsid in 1:getnumfixedspecies(c.chemistryengine)
            setfixedspeciescount!(c.chemistryengine,fxsid,cid,0)
        end
    end
    # empty segments in compartments
    foreach(c.compartments) do comp::Compartment
        foreach(empty!,comp.segments)
    end
    # empty filaments
    foreach(empty!, c.chem_cylinders)
    c.largestfilamentid .= 0
    empty!(c.link_manager)
    # empty membrane vertexes in compartments
    foreach(c.compartments) do comp::Compartment
        empty!(comp.vertexnames)
    end
    # empty membranes
    empty!(c.membranes)
    # empty cadherins
    foreach(emptycadherins!, c.cadherindata)
    empty!(c.cadherinlinked_vertices)
    set_chemboundary!(c)
    set_mechboundary!(c)
    set!(c.validflags, VFS_EMPTY)
    helper_check_sitecount_error(c)
    return
end


"""
Mark all filaments and monomers as minimized, for testing,
    this is normally done in helper_unvectorize_filaments!
"""
function helper_mark_monomers_minimized!(c::Context)
    for cylinders in c.chem_cylinders
        for filament in LazyRows(cylinders.per_fil)
            filament.minusend_num_notminimized = 0
            filament.plusend_num_notminimized = 0
        end
    end
    unset!(c.validflags, VFS_SEGMENTS)
    return
end


#### CHEMISTRY EVENTS ####


"""
Return a tuple of points, plusvecs, states, and compartment ids of monomers that can link.
"""
function helper_linkable_mon_data(c::Context, cylinders::ChemCylinders, step)
    points = SVector{3,Float64}[]
    plusvecs = SVector{3,Float64}[]
    states = MonomerState[]
    cids = Int[]
    for fil_idx in eachindex(cylinders.per_fil)
        monstates = _fil_mon_states(cylinders, fil_idx)
        minusend_num_notminimized = cylinders.per_fil.minusend_num_notminimized[fil_idx]
        plusend_num_notminimized = cylinders.per_fil.plusend_num_notminimized[fil_idx]
        startmid = firstindex(monstates) + minusend_num_notminimized
        stopmid = lastindex(monstates) - plusend_num_notminimized
        startmid = cld(startmid, step)*step
        for mon_id in startmid:step:stopmid
            pos, plusvec = _mon_position_plusvector(cylinders, fil_idx, mon_id)
            cid = get_compartment_id(c, pos)
            state = monstates[mon_id]
            push!(points, pos)
            push!(plusvecs, plusvec)
            push!(states, state)
            push!(cids, cid)
        end
    end
    return (points, plusvecs, states, cids)
end

"""
Returns the total decimated_2mon site count in each compartment for testing.

This is uses CellListMap, and doesn't update any cached data
"""
function helper_total_decimated_2mon_sitecount_sameftid(c::Context, site::SiteData)
    cutoff = cutoff_distance(site.site)
    ftid, ftid2 = getftids(site.site)
    step, step2 = getmidsteps(site.site)
    @argcheck step == step2
    @argcheck ftid == ftid2
    points, plusvecs, states, cids = helper_linkable_mon_data(c, c.chem_cylinders[ftid], step)
    if length(points) < 2
        return zeros(Q31f32, length(c.grid))
    end
    box = CellListMap.Box(CellListMap.limits(points),cutoff*1.1)
    cl = CellListMap.CellList(points,box)
    CellListMap.map_pairwise(zeros(Q31f32, length(c.grid)), box, cl) do x,y,i,j,d2,out
        pos1 = points[i]
        pos2 = points[j]
        plusv1 = plusvecs[i]
        plusv2 = plusvecs[j]
        state1 = states[i]
        state2 = states[j]
        one_two, two_one = in_linking_range(site.site,pos1,pos2,plusv1,plusv2)
        if one_two
            out[cids[i]] += Q31f32(decimated_2mon_sitecount(site.site,state1,state2,pos1,pos2,plusv1,plusv2))
        end
        if two_one
            out[cids[j]] += Q31f32(decimated_2mon_sitecount(site.site,state2,state1,pos2,pos1,plusv2,plusv1))
        end
        return out
    end
end

"""
Returns the total decimated_2mon site count for testing.

This is uses CellListMap, and doesn't update any cached data
"""
function helper_total_decimated_2mon_sitecount_diffftid(c::Context, site::SiteData)
    cutoff = cutoff_distance(site.site)
    ftid1, ftid2 = getftids(site.site)
    step1, step2 = getmidsteps(site.site)
    @argcheck ftid1 != ftid2
    points1, plusvecs1, states1, cids1 = helper_linkable_mon_data(c, c.chem_cylinders[ftid1], step1)
    points2, plusvecs2, states2, cids2 = helper_linkable_mon_data(c, c.chem_cylinders[ftid2], step2)
    if length(points1) < 1 || length(points2) < 1
        return zeros(Q31f32, length(c.grid))
    end
    box = CellListMap.Box(CellListMap.limits([points1; points2]),cutoff*1.1)
    cl = CellListMap.CellList(points1,points2,box)
    CellListMap.map_pairwise(zeros(Q31f32, length(c.grid)), box, cl) do x,y,i,j,d2,out
        pos1 = points1[i]
        pos2 = points2[j]
        plusv1 = plusvecs1[i]
        plusv2 = plusvecs2[j]
        state1 = states1[i]
        state2 = states2[j]
        one_two, two_one = in_linking_range(site.site,pos1,pos2,plusv1,plusv2)
        if one_two
            cid = cids1[i]
            out[cid] += Q31f32(decimated_2mon_sitecount(site.site,state1,state2,pos1,pos2,plusv1,plusv2))
        end
        return out
    end
end


"""
assert all invariants on a context.
"""
function assert_invariants(c::Context)
    foreach(assert_invariants, c.chem_cylinders)
    foreach(assert_invariants, c.cadherindata)
    assert_invariants(c.link_manager)
    # check all tags are valid
    foreach(_all_place_types(c.link_manager)) do P
        for t in get_tags(c, P())
            @argcheck place_exists(c, get_place(c, t))
        end
    end
    @argcheck length(c.grid) == length(c.compartments)

end

"""
assert two contexts are statistically equal.
"""
function assert_statistically_equal(c1::Context, c2::Context)
    @argcheck typeof(c1) == typeof(c2)
    assert_invariants(c1)
    assert_invariants(c2)
    if !checkall(c1.validflags, VFS_SEGMENTS)
        compartmentalize!(c1)
        assert_invariants(c1)
    end
    if !checkall(c2.validflags, VFS_SEGMENTS)
        compartmentalize!(c2)
        assert_invariants(c2)
    end
    @argcheck all((getfield(c1.agent_names, k) == getfield(c2.agent_names, k) for k ∈ fieldnames(AgentNames)))
    # check that both contexts have the same segments.
    @argcheck length(c1.compartments) == length(c2.compartments)
    @argcheck num_filtypes(c1) == num_filtypes(c2)
    for cid in 1:length(c1.grid)
        nftid = num_filtypes(c1)
        for ftid in 1:nftid
            #each compartment should match in number of segments per filament type
            segments1 = c1.compartments[cid].segments[ftid]
            segments2 = c2.compartments[cid].segments[ftid]
            if length(segments1) != length(segments2)
                println("missmatch in number of segments")
                println("in compartment $cid ftid: $ftid")
                @show segments1
                @show segments2
            end
            segments_data1 = [((getfield(s, k) for k ∈ fieldnames(Segment))...,) for s in segments1]
            segments_data2 = [((getfield(s, k) for k ∈ fieldnames(Segment))...,) for s in segments2]
            @argcheck issetequal(segments_data1, segments_data2)
        end
    end
    # TODO check compartment vertexnames
    @argcheck c1.time[] == c2.time[]
    @argcheck c1.β == c2.β
    @argcheck c1.base_diffusion_coeffs == c2.base_diffusion_coeffs
    @argcheck c1.membrane_species_params === c2.membrane_species_params
    @argcheck c1.min_compartment_volume_ratio == c2.min_compartment_volume_ratio
    # TODO check membranes are the same.
    # check site counts per compartment
    fixedcounts1 = c1.chemistryengine.fixedcounts
    fixedcounts2 = c2.chemistryengine.fixedcounts
    @argcheck size(fixedcounts1) == size(fixedcounts2)
    for ftid in 1:num_filtypes(c1)
        for site in c1.filamentsites[ftid]
            fxsid = site.fxsid
            if fixedcounts1[fxsid,:] != fixedcounts2[fxsid,:]
                error("filamentsite $site not equal")
            end
        end
        for site in c1.filamentendsites[ftid]
            fxsid = site.fxsid
            if fixedcounts1[fxsid,:] != fixedcounts2[fxsid,:]
                error("filamentendsite $site not equal")
            end
        end
    end
    @argcheck statistically_equal(c1.link_manager, c2.link_manager)
    @argcheck length(c1.decimated_2mon_sites) == length(c2.decimated_2mon_sites)
    for site in c1.decimated_2mon_sites
        fxsid = site.fxsid
        local true_totalcount1 = if allequal(getftids(site.site))
            helper_total_decimated_2mon_sitecount_sameftid(c1, site)
        else
            helper_total_decimated_2mon_sitecount_diffftid(c1, site)
        end
        local true_totalcount2 = if allequal(getftids(site.site))
            helper_total_decimated_2mon_sitecount_sameftid(c2, site)
        else
            helper_total_decimated_2mon_sitecount_diffftid(c2, site)
        end
        local maxtotalcount1 = fixedcounts1[fxsid,:]
        local maxtotalcount2 = fixedcounts2[fxsid,:]
        @argcheck all(true_totalcount1 .≤ maxtotalcount1)
        @argcheck all(true_totalcount2 .≤ maxtotalcount2)
        @argcheck true_totalcount2 == true_totalcount1
        @argcheck true_totalcount1 == get_real_total_decimated_2mon_sitecount(c1, c1.decimated_2mon_site_managers[site.id])
        @argcheck true_totalcount2 == get_real_total_decimated_2mon_sitecount(c2, c2.decimated_2mon_site_managers[site.id])
    end
end

"""
test that defer_chem_caching! doesn't affect the end result of a sequence of mutations.
"""
function test_chem_mutation_sequence(startc, test_seq)
    c = deepcopy(startc)
    for testfun in test_seq
        testfun(c)
    end
    c_no_defer = deepcopy(c)
    for defer_pos in 1:length(test_seq)
        c = deepcopy(startc)
        for testfun in insert!(copy(test_seq), defer_pos, c->MEDYAN.defer_chem_caching!(c))
            testfun(c)
        end
        MEDYAN.assert_statistically_equal(c, c_no_defer)
    end
end

"""
errors if c.check_sitecount_error and c.chemistryengine.fixedcounts changes when compartmentalized
"""
function helper_check_sitecount_error(c::Context)
    if c.check_sitecount_error && checkall(c.validflags, VFS_SEGMENTS)
        c_true = deepcopy(c)
        compartmentalize!(c_true)
        # both should have valid chem_cylinders
        foreach(assert_invariants, c.chem_cylinders)
        # c_true should be statistically identical to c
        assert_statistically_equal(c, c_true)
    end
end

"""
    $(FUNCTIONNAME)(c::Context, name::MonomerName, state::MonomerState)
Update a monomer state.
"""
function chem_setmonomerstate!(c::Context, name::MonomerName, state::MonomerState)
    update_fila_mono_state!(c, _get_fila_mono_idx(c, name), state)
end

"""
    $(FUNCTIONNAME)(c::Context, p::FilaMonoIdx, state::Union{Symbol,MonomerState})
Update a monomer state.
"""
function update_fila_mono_state!(c::Context, p::FilaMonoIdx, _state::Union{Symbol,MonomerState})
    state::MonomerState = if _state isa Symbol
        c.sys_def.state[p.fila_idx.typeid][_state]
    else
        _state
    end
    c.stats.chem_setmonomerstate_count += 1
    ftid = Int64(p.fila_idx.typeid)
    cylinders = c.chem_cylinders[ftid]
    fil_idx = Int64(p.fila_idx.idx)
    mid= p.mono_idx
    _set_mon_state!(cylinders, fil_idx, mid, state)
    # if the segments aren't valid no point in keeping them valid
    if checkall(c.validflags, VFS_SEGMENTS)
        begin #helper_resetfilamentsitecounts!(c)
            fil_id = _get_fila_id(c, p.fila_idx)
            effected_segments = helper_get_filsite_effected_segments(c, ftid, fil_id, mid, mid)
            @assert length(effected_segments) > 0
            for segment in effected_segments
                helper_updatesegmentsitecounts!(c,segment)
            end
        end
        begin # reset links
            helper_reset_links_one_monomer!(c, p)
        end
    end
    helper_check_sitecount_error(c)
    return
end
function update_fila_mono_state!(c::Context, t::Tag{FilaMonoIdx}, state::Union{Symbol,MonomerState})
    update_fila_mono_state!(c, get_place(c, t), state)
end

"""
Reset link site counts effected by the change to one monomer state.
"""
function helper_reset_links_one_monomer!(c::Context, p::FilaMonoIdx)
    for offset in -1:+1
        for link_tag in get_links(c, FilaMonoIdx(c, p, offset))
            _update_link_reactions!(c, link_tag)
        end
        # TODO update links attached to filament tip
    end
end

"""
    $(FUNCTIONNAME)(c::Context, ftid, fid, isminusend::Bool, newstate::MonomerState)
Add a monomer with state `newstate` to the end of the filament 
with type id `ftid` and id `fid`.

If `isminusend` is `true` add the monomer to the minus end of the filament, 
if `false` add it to the plus end of the filament.

This doesn't affect the other monomer states, positions, or change any of the monomer names.
New monomers are not linkable until after minimization.
"""
function chem_polymerize!(c::Context, ftid::Int, fid::Int, isminusend::Bool, newstate::MonomerState)
    c.stats.chem_polymerize_count += 1
    cylinders::ChemCylinders = c.chem_cylinders[ftid]
    fil_idx = cylinders.fil_id_2_idx[fid]
    newmid::Int = -1
    if isminusend
        polymerizeminusend!(cylinders, fil_idx, newstate)
    else
        polymerizeplusend!(cylinders, fil_idx, newstate)
    end
    if checkall(c.validflags, VFS_SEGMENTS)
        oldsegment::Union{Segment,Nothing} = nothing
        #helper_resetsegments!(c)
        if isminusend 
            newmid = cylinders.per_fil.mon_id_first[fil_idx]
            oldmid = newmid + 1
            oldcid = get_compartment_id(c, _mon_position(cylinders, fil_idx, oldmid))
            newcid = get_compartment_id(c, _mon_position(cylinders, fil_idx, newmid))
            if oldcid == newcid
                # just modify segment
                comp = c.compartments[newcid]
                sid, seg = findsegment(comp,MonomerName(ftid,fid,oldmid))
                seg.midminusend = newmid
            else
                # create new segment
                newcomp = c.compartments[newcid]
                oldcomp = c.compartments[oldcid]
                sid, seg = findsegment(oldcomp,MonomerName(ftid,fid,oldmid))
                oldsegment = seg
                seg.minusend_cid = newcid
                newseg = Segment(;
                    cid = newcid,
                    ftid,
                    fid,
                    midminusend = newmid,
                    midplusend = newmid,
                    plusend_cid = oldcid,
                    minusend_cid = -1,
                    filamentsitecounts= zeros(length(c.filamentsites[ftid])),
                    filamentendsitecounts= zeros(length(c.filamentendsites[ftid])),
                )
                push!(newcomp.segments[ftid],newseg)
            end
        else
            newmid = cylinders.per_fil.mon_id_last[fil_idx]
            oldmid = newmid - 1
            oldcid = get_compartment_id(c, _mon_position(cylinders, fil_idx, oldmid))
            newcid = get_compartment_id(c, _mon_position(cylinders, fil_idx, newmid))
            if oldcid == newcid
                # just modify segment
                comp = c.compartments[newcid]
                sid, seg = findsegment(comp,MonomerName(ftid,fid,oldmid))
                seg.midplusend = newmid
            else
                # create new segment
                newcomp = c.compartments[newcid]
                oldcomp = c.compartments[oldcid]
                sid, seg = findsegment(oldcomp,MonomerName(ftid,fid,oldmid))
                oldsegment = seg
                seg.plusend_cid = newcid
                newseg = Segment(;
                    cid = newcid,
                    ftid,
                    fid,
                    midminusend = newmid,
                    midplusend = newmid,
                    plusend_cid = -1,
                    minusend_cid = oldcid,
                    filamentsitecounts= zeros(length(c.filamentsites[ftid])),
                    filamentendsitecounts= zeros(length(c.filamentendsites[ftid])),
                )
                push!(newcomp.segments[ftid],newseg)
            end
        end
        new_fila_mono_idx = FilaMonoIdx(c, FilaIdx(ftid, fil_idx), newmid)
        begin #helper_resetfilamentsitecounts!(c)
            # first subtract update end sites on oldsegment 
            # oldsegment is nothing if the new monomer stayed in the same compartment.
            isnothing(oldsegment) || helper_updatesegment_filamentendsitecounts!(c, oldsegment)
            effected_segments = helper_get_filsite_effected_segments(c,ftid,fid,newmid,newmid)
            @assert length(effected_segments) > 0
            for segment in effected_segments
                helper_updatesegmentsitecounts!(c,segment)
            end
        end
        #new monomers are not linkable, 
        #so decimated_2mon sites don't need to be updated.
        #helper_resetdecimated_2mon_sitecounts!(c)
        begin # helper_reset_links_one_monomer!
            helper_reset_links_one_monomer!(c, new_fila_mono_idx)
            # TODO move filament tips
        end
    end
    helper_check_sitecount_error(c)
    return
end

"""
    $(FUNCTIONNAME)(c::Context, fila_tip_idx::FilaTipIdx, newstate::Union{Symbol,MonomerState})
Add a monomer with state `newstate` to the end of the filament.

This doesn't affect the other monomer states, positions, or change any of the monomer names.
New monomers are not linkable until after minimization.
"""
function polymerize_fila!(c::Context, fila_tip_idx::FilaTipIdx, _state::Union{Symbol,MonomerState})
    state::MonomerState = if _state isa Symbol
        c.sys_def.state[fila_tip_idx.fila_idx.typeid][_state]
    else
        _state
    end
    fid = _get_fila_id(c, fila_tip_idx.fila_idx)
    ftid = fila_tip_idx.fila_idx.typeid
    chem_polymerize!(c,
        Int(ftid),
        Int(fid),
        fila_tip_idx.is_minus_end,
        state,
    )
    nothing
end
function polymerize_fila!(c::Context, t::Tag{FilaTipIdx}, state::Union{Symbol,MonomerState})
    polymerize_fila!(c, get_place(c, t), state)
end

"""
    $(FUNCTIONNAME)(c::Context, ftid, fid, isminusend::Bool)
Remove a monomer from the end of the filament 
with type id `ftid` and id `fid`.

If `isminusend` is `true` remove the monomer from the minus end of the filament, 
if `false` remove it from the plus end of the filament.

This doesn't affect the other monomer states, positions, or change any of the monomer names.

Error if the filament isn't initially over 2 monomers long.

Warn if the old end monomer is referenced in a link, and remove the place from the link.

The warning can be disabled by passing keyword argument `warniflink_2mon_removed=false`
"""
function chem_depolymerize!(c::Context, ftid::Int, fid::Int, isminusend::Bool; warniflink_2mon_removed=true)
    c.stats.chem_depolymerize_count += 1
    cylinders::ChemCylinders = c.chem_cylinders[ftid]
    fil_idx = cylinders.fil_id_2_idx[fid]
    fil_data = LazyRow(cylinders.per_fil, fil_idx)
    oldname = if isminusend
        MonomerName(ftid,fid,fil_data.mon_id_first)
    else
        MonomerName(ftid,fid,fil_data.mon_id_last)
    end
    oldmid = oldname.mid
    if fil_data.mon_id_last - fil_data.mon_id_first < 2
        error("depolymerizing a filament that is too short. The filament must be over 2 monomers long")
    end
    # update links to remove references to the place
    old_fila_mono_idx = _get_fila_mono_idx(c, oldname)
    helper_removeplace!(c, old_fila_mono_idx; warn_if_unlink=warniflink_2mon_removed)
    # If the segments aren't valid just update cylinders::ChemCylinders,
    # Otherwise update both cylinders and segments to keep them valid.
    if !checkall(c.validflags, VFS_SEGMENTS)
        if isminusend
            depolymerizeminusend!(cylinders, fil_idx)
        else
            depolymerizeplusend!(cylinders, fil_idx)
        end
    else
        cid = get_compartment_id(c, _mon_position(cylinders, fil_idx, oldmid))
        comp = c.compartments[cid]
        if isminusend
            depolymerizeminusend!(cylinders, fil_idx)
            sid, seg = findsegment(comp,oldname)
            if seg.midplusend == oldmid
                newendcomp = c.compartments[seg.plusend_cid]
                newsid, newseg = findsegment(newendcomp,MonomerName(ftid,fid,oldmid+1))
                newseg.minusend_cid = -1
                helper_deletesegment!(c,cid,ftid,sid)
            else
                seg.midminusend += 1
            end   
        else
            depolymerizeplusend!(cylinders, fil_idx)
            sid, seg = findsegment(comp,oldname)
            if seg.midminusend == oldmid
                newendcomp = c.compartments[seg.minusend_cid]
                newsid, newseg = findsegment(newendcomp,MonomerName(ftid,fid,oldmid-1))
                newseg.plusend_cid = -1
                helper_deletesegment!(c,cid,ftid,sid)
            else
                seg.midplusend -= 1
            end  
        end
        #helper_resetsegments!(c)
        #helper_reset_decimated_2mon_site_monomers!(c)
        begin #helper_resetfilamentsitecounts!(c)
            #search nearby mid as well, to catch new end sites
            effected_segments = helper_get_filsite_effected_segments(c,ftid,fid,oldmid-1,oldmid+1)
            @assert length(effected_segments) > 0
            for segment in effected_segments
                helper_updatesegmentsitecounts!(c,segment)
            end
        end
        begin #helper_reset_links_one_monomer!(c)
            helper_reset_links_one_monomer!(c, old_fila_mono_idx)
            # TODO update filament tip location
        end
    end
    try
        helper_check_sitecount_error(c)
    catch
        @show ftid
        @show fid
        @show isminusend
        @show oldname
        rethrow()
    end
    return
end

"""
    $(FUNCTIONNAME)(c::Context, fila_tip_idx::FilaTipIdx)
Remove a monomer from the end of the filament.

This doesn't affect the other monomer states, positions, or change any of the monomer names.

Error if the filament isn't initially over 2 monomers long.

Warn if the old end monomer is referenced in a link, and remove the place from the link. 
Links attached to the filament tip will remain attached.

The warning can be disabled by passing keyword argument `warn_if_unlink=false`
"""
function depolymerize_fila!(c::Context, fila_tip_idx::FilaTipIdx; warn_if_unlink=true)
    fid = _get_fila_id(c, fila_tip_idx.fila_idx)
    ftid = fila_tip_idx.fila_idx.typeid
    chem_depolymerize!(c,
        Int(ftid),
        Int(fid),
        fila_tip_idx.is_minus_end;
        warniflink_2mon_removed=warn_if_unlink,
    )
    nothing
end

function chem_newcadherin!(c::Context, cadtid::Int, endnames::Pair{VertexName,MonomerName}, cadherinstate::CadherinState)
    c.stats.chem_newcadherin_count += 1
    newcadherin!(c.cadherindata[cadtid],c,endnames,cadherinstate)
    if !(endnames[1] in keys(c.cadherinlinked_vertices))
        ncadtid = getnumcadherintypes(c)
        insert!(c.cadherinlinked_vertices, endnames[1], [[] for i in 1:ncadtid])
    end
    push!(c.cadherinlinked_vertices[endnames[1]][cadtid],endnames)
    helper_check_sitecount_error(c)
    return
end

function chem_removecadherin!(c::Context, cadtid::Int, endnames::Pair{VertexName,MonomerName})
    c.stats.chem_removecadherin_count += 1
    removecadherin!(c.cadherindata[cadtid],c,endnames)
    info = c.cadherinlinked_vertices[endnames[1]][cadtid]
    ind = findfirst(==(endnames),info)
    info[ind] = info[end]
    pop!(info)

    if endnames[1] in keys(c.cadherinlinked_vertices)
        if all( isempty , c.cadherinlinked_vertices[endnames[1]])
            delete!(c.cadherinlinked_vertices, endnames[1])
        end
    end

    helper_check_sitecount_error(c)
    return
end

function chem_setcadherinstate!(c::Context, cadtid, endnames::Pair{VertexName,MonomerName}, cadherinstate::CadherinState)
    c.stats.chem_setcadherinstate_count += 1
    setcadherinstate!(c.cadherindata[cadtid],c,endnames,cadherinstate)
    helper_check_sitecount_error(c)
    return
end

"""
    $(FUNCTIONNAME)(c::Context; ftid=1, monomerstates, node_mids, nodepositions)
Return the filament id of a new filament.

Error if the filament isn't initially over 2 monomers long.

Newly added filaments don't have decimated_2mon sites, until after minimization.

# Keyword Arguments
- `ftid=1`: filament type id.
- `monomerstates`: Collection of the `MonomerState` of the monomers in the new filament. 
    In order from minus end to plus end. 

    `length(monomerstates)>1`
- `nodepositions`: Collection of `SVector{3,Float64}`. The positions of the nodes, monomers are between nodes.
- `node_mids`: Collection of `Integer`. The monomer ids at (slightly plus side of) the `nodepositions`

                                     |
                          -----+-----|-----+-----
      minus end <----       M  |  M  | (M) |  M        ----> plus end
                          -----+-----|-----+-----
                                     |
                                     ^ A nodeposition is indicated by the line.
    
    The monomer id with parenthesis (M) will in `node_mids`

    `length(node_mids) == length(nodepositions) - 1`
- `endloadforces=(0.0=>0.0)`: end load forces, 
    usually don't use this, because load forces will automatically get updated at the next minimization.

"""
function chem_newfilament!(c::Context; ftid=1, monomerstates, node_mids, nodepositions, endloadforces=(0.0=>0.0))
    tag = make_fila!(c; type=ftid, mono_states=monomerstates, node_mids, node_positions=nodepositions, tip_load_forces=endloadforces)
    _get_fila_id(c, FilaIdx(c, tag))
end

"""
    $(FUNCTIONNAME)(c::Context;
        type=1,
        mono_states,
        node_mids,
        node_positions,
    )::FilaIdx
Return the tag of the plus tip of a new filament.
Error if the filament isn't initially over 2 monomers long.
Newly added filaments can't be selected from nearby monomers until after minimization.
# Keyword Arguments
- `type=1`: filament type id or symbol.
- `mono_states`: Collection of the `MonomerState` of the monomers in the new filament. 
    In order from minus end to plus end. 
    `length(mono_states)>1`
- `node_positions`: Collection of `SVector{3,Float64}`. The positions of the nodes, monomers are between nodes.
- `node_mids`: Collection of `Integer`. The monomer ids at (slightly plus side of) the `node_positions`
                                     |
                          -----+-----|-----+-----
      minus end <----       M  |  M  | (M) |  M        ----> plus end
                          -----+-----|-----+-----
                                     |
                                     ^ A node_position is indicated by the line.
    
    The monomer id with parenthesis (M) will in `node_mids`
    `length(node_mids) == length(node_positions) - 1`
- `tip_load_forces=(0.0=>0.0)`: tip load forces, 
    usually don't use this, because load forces will automatically get updated at the next minimization.
"""
function make_fila!(c::Context;
        type::Union{Symbol,Int}=1,
        mono_states,
        node_mids,
        node_positions,
        tip_load_forces=(0.0=>0.0),
    )::Tag{FilaTipIdx}
    ftid::Int = if type isa Symbol
        c.sys_def.filament[type]
    else
        type
    end
    c.stats.chem_newfilament_count += 1
    fid = c.largestfilamentid[ftid]+1
    c.largestfilamentid[ftid]= fid
    cylinders = c.chem_cylinders[ftid]
    fil_idx = create_filament!(cylinders;
        fil_id=fid,
        monomerstates = mono_states,
        node_mids,
        nodepositions = node_positions,
        endloadforces = tip_load_forces,
        minusend_num_notminimized= length(mono_states),
        plusend_num_notminimized= length(mono_states),
    )
    # add tags for filament tips
    _fil_idx = FilaIdx(UInt32(ftid), UInt32(fil_idx))
    tag!(c, FilaTipIdx(c, _fil_idx, true))
    plus_tip_tag = tag!(c, FilaTipIdx(c, _fil_idx, false))
    
    if checkall(c.validflags, VFS_SEGMENTS)
        let # helper_resetsegments!(c) helper_resetfilamentsitecounts!(c)
            local monstates = _fil_mon_states(cylinders, fil_idx)
            local mid= firstindex(monstates)
            local cid= get_compartment_id(c, _mon_position(cylinders,fil_idx,mid))
            local seg= Segment(cid= cid,
                        ftid= ftid,
                        fid= fid,
                        midminusend= mid,
                        midplusend= mid,
                        plusend_cid= -1,#plus cid does not exist yet
                        minusend_cid= -1,#minus end does not exist
                        filamentsitecounts= zeros(length(c.filamentsites[ftid])),
                        filamentendsitecounts= zeros(length(c.filamentendsites[ftid])),
            )
            push!(c.compartments[cid].segments[ftid], seg)
            local last_seg= seg
            local last_cid= cid
            for mid in (firstindex(monstates)+1):lastindex(monstates)
                cid= get_compartment_id(c, _mon_position(cylinders,fil_idx,mid))
                if cid==last_cid
                    last_seg.midplusend= mid
                else
                    last_seg.plusend_cid= cid
                    #left last_cid, create new segment
                    #first save filament site counts of last_seg
                    helper_updatesegmentsitecounts!(c, last_seg)
                    seg= Segment(cid= cid,
                        ftid= ftid,
                        fid= fid,
                        midminusend= mid,
                        midplusend= mid,
                        plusend_cid= -1,#plus cid does not exist yet
                        minusend_cid= last_cid,
                        filamentsitecounts= zeros(length(c.filamentsites[ftid])),
                        filamentendsitecounts= zeros(length(c.filamentendsites[ftid])),
                    )
                    push!(c.compartments[cid].segments[ftid], seg)
                    last_seg= seg
                    last_cid= cid
                end
            end
            helper_updatesegmentsitecounts!(c, last_seg)
        end
    end
    helper_check_sitecount_error(c)
    return plus_tip_tag
end


"""
    $(FUNCTIONNAME)(c::Context; ftid=1, fid=maximum(filtype_fil_ids(c, ftid)))
Remove the filament with type id `ftid` and id `fid`.

By default the last added filament with type id `ftid` is removed.

Warn if any monomers on the filament are referenced by any link, and remove the places from the links.

The warning can be disabled by passing keyword argument `warniflink_2mon_removed=false`
"""
function chem_removefilament!(c::Context; ftid=1, fid=maximum(filtype_fil_ids(c, ftid)), warniflink_2mon_removed=true)
    fila_idx = _get_fila_idx(c, ftid, fid)
    c.stats.chem_removefilament_count += 1
    monstates = fila_mono_states(c, fila_idx)
    # update links to remove references to the place
    for dir in (false, true)
        helper_removeplace!(c, FilaTipIdx(c, fila_idx, dir); warn_if_unlink=warniflink_2mon_removed)
    end
    for mono_idx in eachindex(monstates)
        helper_removeplace!(c, FilaMonoIdx(c, fila_idx, mono_idx); warn_if_unlink=warniflink_2mon_removed)
    end
    #Delete segments
    if checkall(c.validflags, VFS_SEGMENTS)
        firstname = MonomerName(ftid,fid,firstindex(monstates))
        cid = get_compartment_id(c,firstname)
        sid, seg = findsegment(c.compartments[cid],firstname)
        while !isplusendsegment(seg)
            nextcid = seg.plusend_cid
            comp = c.compartments[nextcid]
            name = MonomerName(ftid,fid,seg.midplusend+1)
            nextsid, seg = findsegment(comp,name)
            helper_deletesegment!(c, cid, ftid, sid)
            cid = nextcid
            sid = nextsid
        end
        helper_deletesegment!(c, cid, ftid, sid)
    end
    cylinders = c.chem_cylinders[ftid]
    changed_fil_idx = remove_filament(cylinders, fid)
    if !isnothing(changed_fil_idx)
        let changed_fil_idx = changed_fil_idx
            # move tags on filament that changed index
            local old_fil_idx, new_fil_idx = changed_fil_idx
            local old_fila_idx = FilaIdx(ftid, old_fil_idx)
            local new_fila_idx = FilaIdx(ftid, new_fil_idx)
            # move tags for filament tips
            for dir in (false, true)
                _move_place!(
                    _tag_manager(c.link_manager, FilaTipIdx()),
                    FilaTipIdx(c, old_fila_idx, dir),
                    FilaTipIdx(c, new_fila_idx, dir),
                )
            end
            # move tags for filament monomers
            for mono_idx in eachindex(fila_mono_states(c, new_fila_idx))
                local t = _tag_manager(c.link_manager, FilaMonoIdx())
                local new_place = FilaMonoIdx(c, new_fila_idx, mono_idx)
                local old_place = FilaMonoIdx(c, old_fila_idx, mono_idx)
                _move_place!(
                    t,
                    old_place,
                    new_place,
                )
            end
        end
    end
    helper_check_sitecount_error(c)
    return
end

"""
    $(FUNCTIONNAME)(c::Context, filaidx::Union{FilaIdx, Tag})
Remove the filament.

Warn if any monomers or tips on the filament are referenced by any links, and unlink.

The warning can be disabled by passing keyword argument `warn_if_unlink=false`
"""
function remove_fila!(c::Context, fila_idx::FilaIdx; warn_if_unlink::Bool=true)
    fid = _get_fila_id(c, fila_idx)
    ftid = fila_idx.typeid
    chem_removefilament!(c; ftid, fid, warniflink_2mon_removed=warn_if_unlink)
    nothing
end
function remove_fila!(c::Context, fila_idx::Tag; warn_if_unlink::Bool=true)
    remove_fila!(c, FilaIdx(c, fila_idx); warn_if_unlink)
end

function helper_removeplace!(c::Context, place::Place; warn_if_unlink::Bool)
    has_tag(c, place) || return
    local t = tag!(c, place)
    for link_tag in collect(get_links(c, t))
        tags = get_tags(c, link_tag)
        if warn_if_unlink
            @warn "removal of $(t) unlinked $(link_tag) attached to $(tags)"
        end
        update_link!(c,
            link_tag;
            places=replace(tags, t=>typeof(t)())
        )
    end
    @assert isempty(get_links(c, t))
    @assert tag_exists(c, t)
    _force_remove_idx!(_tag_manager(c.link_manager, place), t.idx)
    return
end

"""
Update compartment segment data from filamentdata.
Doesn't update other compartmentdata or any reaction counts
"""
function helper_resetsegments!(c::Context)
    #clear current segments
    num_filament_types= num_filtypes(c)
    for comp in c.compartments
        for ftid in 1:num_filament_types
            empty!(comp.segments[ftid])
        end
    end
    #create segments
    for ftid in 1:num_filament_types
        cylinders = c.chem_cylinders[ftid]
        for fil_idx in eachindex(cylinders.per_fil)
            fid = cylinders.per_fil.id[fil_idx]
            monstates = _fil_mon_states(cylinders, fil_idx)
            mid= firstindex(monstates)
            cid= get_compartment_id(c, _mon_position(cylinders, fil_idx, mid))
            seg= Segment(cid= cid,
                        ftid= ftid,
                        fid= fid,
                        midminusend= mid,
                        midplusend= mid,
                        plusend_cid= -1,#plus cid does not exist yet
                        minusend_cid= -1,#minus end does not exist
                        filamentsitecounts= zeros(length(c.filamentsites[ftid])),
                        filamentendsitecounts= zeros(length(c.filamentendsites[ftid])),
                    )
            push!(c.compartments[cid].segments[ftid], seg)
            last_seg= seg
            last_cid= cid
            for mid in (firstindex(monstates)+1):lastindex(monstates)
                cid= get_compartment_id(c, _mon_position(cylinders, fil_idx, mid))
                if cid==last_cid
                    last_seg.midplusend= mid
                else
                    #left last_cid, create new segment
                    last_seg.plusend_cid= cid
                    seg= Segment(cid= cid,
                        ftid= ftid,
                        fid= fid,
                        midminusend= mid,
                        midplusend= mid,
                        plusend_cid= -1,#plus cid does not exist yet
                        minusend_cid= last_cid,
                        filamentsitecounts= zeros(length(c.filamentsites[ftid])),
                        filamentendsitecounts= zeros(length(c.filamentendsites[ftid])),
                    )
                    push!(c.compartments[cid].segments[ftid], seg)
                    last_seg= seg
                    last_cid= cid
                end
            end
        end
    end
end

"""
Reset the monomers for each decimated_2mon_site
"""
function helper_reset_decimated_2mon_site_monomers!(c::Context)
    foreach(c.decimated_2mon_site_managers) do m
        reset_site_counts!(c, m)
    end
end

"""
Update filament site and filament end site counts on a single segment.
Delta gets sent to chemistryengine
Make sure `segment.filamentsitecounts` is what it was before the state change,
Only updates filamentendsitecounts if the segment is at an end.
"""
function helper_updatesegmentsitecounts!(c::Context, segment::Segment)
    requireall(c.validflags, VFS_SEGMENTS)
    ftid = segment.ftid
    fid = segment.fid
    cid = segment.cid
    # check if segment is a filament end
    if isminusendsegment(segment) || isplusendsegment(segment)
        #go through all filamentendsites and add counts to chemistryengine
        for siteinfo in c.filamentendsites[ftid]
            newsitecount = Q31f32(helper_filamentendsitecounts(c,segment,siteinfo.site))
            oldsitecount = segment.filamentendsitecounts[siteinfo.id]
            if newsitecount != oldsitecount
                addfixedspeciescount!(c.chemistryengine,siteinfo.fxsid,cid,newsitecount-oldsitecount)
                segment.filamentendsitecounts[siteinfo.id] = newsitecount
            end
        end
    end
    filamentsitecounts= zeros(Q31f32,length(c.filamentsites[ftid]))
    monstates = fil_mon_states(c, ftid, fid)
    for mid in segment.midminusend:segment.midplusend
        for sitetuple in c.filamentsites[ftid]
            fsid= sitetuple.id
            filamentsite= sitetuple.site
            plusrange= getplusrange(filamentsite)
            minusrange= getminusrange(filamentsite)
            mmid= mid - minusrange
            pmid= mid + plusrange
            #make sure states are in bound
            if mmid ≥ firstindex(monstates) && pmid ≤ lastindex(monstates)
                states= monstates[mmid:pmid]
                s= Q31f32(filamentsitecount(filamentsite,states))
                filamentsitecounts[fsid] += s
            end
        end
    end
    for fsid in eachindex(filamentsitecounts)
        newsitecount = filamentsitecounts[fsid]
        oldsitecount = segment.filamentsitecounts[fsid]
        if newsitecount != oldsitecount
            fxsid= c.filamentsites[ftid][fsid].fxsid
            addfixedspeciescount!(c.chemistryengine,fxsid,cid,newsitecount-oldsitecount)
            segment.filamentsitecounts[fsid] = newsitecount
        end
    end
end

"""
delete a segment and subtract all site counts
"""
function helper_deletesegment!(c::Context, cid, ftid, sid)
    requireall(c.validflags, VFS_SEGMENTS)
    comp = c.compartments[cid]
    segs = comp.segments[ftid]
    seg = segs[sid]
    #go through all filamentendsites and add counts to chemistryengine
    for siteinfo in c.filamentendsites[ftid]
        counts = seg.filamentendsitecounts[siteinfo.id]
        if !iszero(counts)
            addfixedspeciescount!(c.chemistryengine,siteinfo.fxsid,cid,-counts)
        end
    end
    for siteinfo in c.filamentsites[ftid]
        counts = seg.filamentsitecounts[siteinfo.id]
        if !iszero(counts)
            addfixedspeciescount!(c.chemistryengine,siteinfo.fxsid,cid,-counts)
        end
    end
    #now delete
    segs[sid] = segs[end]
    pop!(segs)
    return
end


"""
Update filament end site counts on a single segment even if it no longer is an end.
Delta gets sent to chemistryengine
Make sure `segment.filamentendsitecounts` is what it was before the state change,
"""
function helper_updatesegment_filamentendsitecounts!(c::Context, segment::Segment)
    requireall(c.validflags, VFS_SEGMENTS)
    ftid = segment.ftid
    fid = segment.fid
    cid = segment.cid
    #go through all filamentendsites and add counts to chemistryengine
    for siteinfo in c.filamentendsites[ftid]
        newsitecount = Q31f32(helper_filamentendsitecounts(c,segment,siteinfo.site))
        oldsitecount = segment.filamentendsitecounts[siteinfo.id]
        if newsitecount != oldsitecount
            addfixedspeciescount!(c.chemistryengine,siteinfo.fxsid,cid,newsitecount-oldsitecount)
            segment.filamentendsitecounts[siteinfo.id] = newsitecount
        end
    end
end

"""
Return the segments that can have filament sites or filament end sites effected by a change to monomer states from midstart to midstop
"""
function helper_get_filsite_effected_segments(c::Context,ftid,fid,midstart,midstop)::Vector{Segment}
    requireall(c.validflags, VFS_SEGMENTS)
    monstates = fil_mon_states(c, ftid, fid)
    midminusend = firstindex(monstates)
    midplusend = lastindex(monstates)
    midminusmaxrange = c.maxfilsite_minusrange[ftid]
    midplusmaxrange = c.maxfilsite_plusrange[ftid]
    midstarteffect = max(midstart-midplusmaxrange,midminusend)
    midstopeffect = min(midstop+midminusmaxrange,midplusend)
    
    mid = midstarteffect
    cid = get_compartment_id(c, MonomerName(ftid,fid,mid))
    segments = Vector{Segment}()
    while true
        comp = c.compartments[cid]
        sid, seg = findsegment(comp,MonomerName(ftid,fid,mid))
        push!(segments,seg)
        if midstopeffect > seg.midplusend
            cid= seg.plusend_cid
            mid= seg.midplusend+1
        else
            return segments
        end
    end
end

"""
Reset the filament and filamentend site counts and fixedspecies number after segments are reset
"""
function helper_resetfilamentsitecounts!(c::Context)
    #go through segments and get the filament site counts
    for comp in c.compartments
        for ftid in 1:num_filtypes(c)
            filamentsitecounts= zeros(Q31f32,length(c.filamentsites[ftid]))
            filamentendsitecounts= zeros(Q31f32,length(c.filamentendsites[ftid]))
            for segment in comp.segments[ftid]
                monstates = fil_mon_states(c, ftid, segment.fid)
                segment.filamentsitecounts .= 0
                segment.filamentendsitecounts .= 0
                for mid in segment.midminusend:segment.midplusend
                    for sitetuple in c.filamentsites[ftid]
                        fsid= sitetuple.id
                        filamentsite= sitetuple.site
                        plusrange= getplusrange(filamentsite)
                        minusrange= getminusrange(filamentsite)
                        mmid= mid - minusrange
                        pmid= mid + plusrange
                        #make sure states are in bound
                        if mmid ≥ firstindex(monstates) && pmid ≤ lastindex(monstates)
                            states= monstates[mmid:pmid]
                            s= Q31f32(filamentsitecount(filamentsite,states))
                            segment.filamentsitecounts[fsid] += s
                            filamentsitecounts[fsid] += s
                        end
                    end
                end
                for fesid in eachindex(filamentendsitecounts)
                    s = Q31f32(helper_filamentendsitecounts(c,segment,c.filamentendsites[ftid][fesid].site))
                    segment.filamentendsitecounts[fesid] += s
                    filamentendsitecounts[fesid] += s
                end
            end
            for fsid in eachindex(filamentsitecounts)
                fxsid= c.filamentsites[ftid][fsid].fxsid
                setfixedspeciescount!(c.chemistryengine,fxsid,comp.id,filamentsitecounts[fsid])
            end
            for fesid in eachindex(filamentendsitecounts)
                fxsid= c.filamentendsites[ftid][fesid].fxsid
                setfixedspeciescount!(c.chemistryengine,fxsid,comp.id,filamentendsitecounts[fesid])
            end
        end
    end
end

"""
Reset cadherinsite counts in each compartment
"""
function helper_resetcadherins!(c::Context)
    for cadherindata in c.cadherindata
        resetcadherins!(cadherindata,c)
    end
end

"""
Reset the pairlist for each possiblecadherinsite
"""
function helper_resetpossiblecadherinsites!(c::Context)
    foreach(c.possiblecadherinsite_managers) do m
        reset_possiblecadherinsite_counts!(c, m)
    end
end

"""
Update all vertex names in compartments.
"""
function helper_update_allverticesincompartments!(c::Context)
    # Clear all recordings.
    for comp ∈ c.compartments
        empty!(comp.vertexnames)
    end

    # Add all vertices.
    for mindex ∈ eachindex(c.membranes)
        m = c.membranes[mindex]
        for vindex ∈ eachindex(m.vertices)
            coord = m.vertices.attr.coord[vindex]
            cid = get_compartment_id(c, coord)
            push!(c.compartments[cid].vertexnames, VertexName(mindex, m.vertices.attr.id[vindex]))
            # Also stores cid in the vertex.
            m.vertices.attr.cid[vindex] = cid
        end
    end

    set!(c.validflags, VFS_VERTEX_IN_COMPARTMENT)
end


"""
    $(TYPEDSIGNATURES)
Add a new membrane to the system.

# Keyword arguments

- `meshinit` is structure containing mesh shape initialization information, 
    such as a named tuple `(vertlist, trilist)` containing vertex coordinates and triangle list,
    `MeshInitEllipsoid`, `MeshInitPlane` or a general `MeshInitSurfaceFunc`.
"""
function newmembrane!(c::Context; type::Int, meshinit)
    if type ∉ eachindex(c.membranemechparams)
        error("Membrane type $type does not have corresponding mech parameters in the context. Perhaps you should provide a proper list of membrane mech parameters when constructing the context.")
    end
    unset!(c.validflags, VFS_DEP_VERTEX_COORD)
    MT = eltype(c.membranes)
    m = create_membranemesh(getval_speciesnames(MT), getval_membranesitenames(MT); membranetype=type)
    initmesh!(m, meshinit)
    push!(c.membranes, m)
    m
end

function resetvertexstate!(m::DynamicHalfedgeMesh, s::SysDef)
    rand!(m.vertices.attr.vertexstate, collect(s.vertex))
    # All ver2 model test
    vstates = m.vertices.attr.vertexstate
    # for vidx in 1:length(m.vertices.attr.vertexstate)
    #     vstates[vidx] = s.vertex[2]
    # end
    # All vertices on borders have vertex state 1
    for vidx in 1:length(m.vertices.attr.vertexstate)
        if m.vertices.conn[vidx].num_targeting_border_halfedges > 0
            vstates[vidx] = s.vertex[1]
        end
    end
end
