"""
Context struct and related structs and functions
"""

using FixedPointNumbers
using Dictionaries
using OffsetArrays
using Random
import Base.show


"""
Filament mechanical parameters

$(TYPEDFIELDS)
"""
Base.@kwdef struct FilamentMechParams
    "Cylinder radius (nm)"
    radius::Float64 = NaN

    "Monomer spacing length (nm)"
    spacing::Float64 = NaN

    "Length force constant (pN/nm)"
    klength::Float64 = NaN

    "Bending force constant (pN*nm/rad²)"
    kangle::Float64 = NaN

    "Number of monomers per cylinder"
    numpercylinder::Int32 = -1

    "Maximum number of unminimized monomers that can be on an end.
    This should be less than the minimum `radius` of other filaments + `radius`
    divided by `spacing`."
    max_num_unmin_end::Int32 = -1
end

"""
Membrane mechanical parameters.

$(TYPEDFIELDS)
"""
Base.@kwdef struct MembraneMechParams
    "Membrane bending coefficient (pN nm)"
    kbend::Float64 = 0
    "Equilibrium curvature (1/nm)"
    eqcurv::Float64 = 0

    "Membrane area elasticity (pN/nm)"
    karea::Float64 = 0
    "Equilibrium area (nm^2)"
    eqarea::Float64 = 1

    "Membrane tension (pN/nm)"
    tension::Float64 = 0

    "Volume conservation k (pN/nm^2)"
    kvolume::Float64 = 0
    "Equilibrium volume (nm^3)"
    eqvolume::Float64 = 1
    "Actual volume is cone volume with the origin plus the offset."
    offsetvolume::Float64 = 0

    "Pinning strength k (pN/nm)"
    kpinning::Float64 = 0

    """
    Controls the minimum edge length when using mem3dg method of computing curvatures.
    This is to prevent minimization issues.
    When the edge length drops below min, a FENE-like potential will be applied.
    """
    edgelength_mem3dg_min::Float64 = 5.0
    edgelength_mem3dg_k::Float64 = 0.0
end

"""
Shared configurations for the entire simulation, stored as types.

$(TYPEDFIELDS)
"""
Base.@kwdef struct SharedTypedConfigs{
        WhichMeshCurv,
        WhichMeshBoundaryPinningMode,
        WhichBendingMode,
    }

    "Which mesh curvature formula to use. `WhichMeshCurv` must be of type `MeshCurvatureFormula`."
    meshcurv::Val{WhichMeshCurv} = Val(meshcurv_mem3dg)

    "Which mesh boundary pinning method to use. Must be within :none, :border1 and :border2."
    mesh_boundary_pinning_mode::Val{WhichMeshBoundaryPinningMode} = Val(:border2)

    "With local curvature, how to compute bending energy. Must be :normal or :bashkirov."
    bending_mode::Val{WhichBendingMode} = Val(:normal)
end

"""
Membrane-filament mechanical interaction parameters.

$(TYPEDFIELDS)
"""
Base.@kwdef struct MembraneFilamentMechParams
    "Triangle-bead volume exclusion constant (pN nm^3)"
    kvolexcl::Float64 = 650
    "Cutoff (nm) outside which energy is zero."
    cutoffvolexcl::Float64 = 100
end

"""
Membrane protein physical parameters.
$(TYPEDFIELDS)
"""
Base.@kwdef struct MembraneSpeciesParams
    "Membrane diffusion coefficients (nm^2/s)."
    diffusion_coeff::Float64 = 0
    "Protein area projected onto the surface (nm^2)."
    area::Float64 = 0
    "Bending rigidity (pN nm)."
    kbend::Float64 = 0
    "The protein's own spontaneous mean curvature (/nm). Can be used in bending energy computations with curvatures."
    eqcurv::Float64 = 0
end
export MembraneSpeciesParams


"""
The chemistry state of a segment of a filament fully contained in a compartment

$(TYPEDFIELDS)
"""
Base.@kwdef mutable struct Segment
    "Compartment id"
    cid::Int32

    "filament type id"
    ftid::Int

    "filament id"
    fid::Int

    "first monomer id, on minus end"
    midminusend::Int

    "last monomer id, on plus end"
    midplusend::Int

    "compartment id of the next segment on the plus end, -1 if no next segment"
    plusend_cid::Int32

    "compartment id of the previous segment on the minus end, -1 if no previous segment"
    minusend_cid::Int32

    "filament site counts from this segment, indexed by filament site id"
    filamentsitecounts::Vector{Q31f32}

    "filament end site counts from this segment, indexed by filament site id"
    filamentendsitecounts::Vector{Q31f32}

end

"""
Shallow copy, 
https://stackoverflow.com/questions/51956958/how-to-copy-a-struct-in-julia
"""
Base.copy(s::Segment) = Segment((getfield(s, k) for k ∈ fieldnames(Segment))...)

isminusendsegment(s::Segment) = s.minusend_cid == -1

isplusendsegment(s::Segment) = s.plusend_cid == -1



"""
The chemistry state of a compartment, not including diffusing species

$(TYPEDFIELDS)
"""
Base.@kwdef struct Compartment
    id::Int32

    "A Vector of compartment ids that touch this compartment, excuding self id"
    neighbor_ids::Vector{Int32}

    """
    All filament segments within this compartment.
    This is valid if the parent context `SEGMENTS` flag is set.
    indexed by filament type id, arbitrary segment id
    """
    segments::Vector{Vector{Segment}}

    """
    All vertices within this compartment.
    This is valid if the parent context `VERTEX_IN_COMPARTMENT` flag is set.
    This can be used in chemistry, so it should be updated before chemistry and remain fixed during chemistry.
    """
    vertexnames::Vector{VertexName} = []

end

"""
Empty Compartment constructor

$(TYPEDFIELDS)
"""
function Compartment(id,neighbor_ids,num_filament_types::Integer)
    Compartment(;
        id,
        neighbor_ids,
        segments = [[] for i in 1:num_filament_types],
    )
end

"""
Return the segment id and segment with the monomername in the compartment
"""
function findsegment(comp::Compartment,name::MonomerName)
    sid = findfirst(comp.segments[name.ftid]) do seg
        seg.fid == name.fid && (name.mid in seg.midminusend:seg.midplusend)
    end
    isnothing(sid) && error("No segment found for $name in compartment $(comp.cid)")
    return sid, comp.segments[name.ftid][sid]
end

"""
Holds various counters and other useful stats accumulated during a simulation

All fields must have a default value.

$(TYPEDFIELDS)

"""
Base.@kwdef mutable struct PerformanceStats
    "number of times the force/energy was evaluated during energy minimization"
    force_evals_count::Int = 0

    "number of reactions fired"
    reaction_count::Int = 0

    "number of times any reaction callback was called
    Note, callbacks are prepended when defining a system, 
    so `callback_reaction_count[end]` is the callback added first, and 
    `callback_reaction_count[1]` is the callback added last"
    callback_reaction_count::Vector{Int} = []

    "number of calls to update_fila_mono_state!"
    update_fila_mono_state_count::Int = 0

    "number of calls to polymerize_fila!"
    polymerize_fila_count::Int = 0

    "number of calls to depolymerize_fila!"
    depolymerize_fila_count::Int = 0

    "number of calls to make_link!"
    make_link_count::Int = 0

    "number of calls to remove_link!"
    remove_link_count::Int = 0

    "number of calls to update_link!"
    update_link_count::Int = 0

    "number of calls to make_fila!"
    make_fila_count::Int = 0

    "number of calls to remove_fila!"
    remove_fila_count::Int = 0

    "Number of events of membrane species diffusing."
    chem_membranediffusing_count::Int = 0

    "Number of events of membrane site reactions."
    chem_membranesite_count::Int = 0

    "Number of events of membrane site reactions."
    chem_severfilament_count::Int = 0

end

"""$PUBLIC
    Context(sys_def::SysDef, grid::CubicGrid; kwargs...)

$(TYPEDFIELDS)

"""
Base.@kwdef struct Context{
        GRID_TYPE,
        NUM_MEMBRANEDIFFUSINGSPECIES,
        RDMESAMPLER_TYPE <: RDMESampler,
        FILAMENTSITES_TYPE <: Tuple{Vararg{Tuple{Vararg{SiteData}}}},
        FILAMENTENDSITES_TYPE <: Tuple{Vararg{Tuple{Vararg{SiteData}}}},
        MEMBRANESITES_TYPE <: Tuple{Vararg{SiteData}},
        MAP_MEMDIFFU_MEMSITE_TYPE <: Tuple{Vararg{Vector{Int}}},
        MEMBRANEMESH_TYPE,
        POSSIBLECADHERINSITESMANAGERS_TYPE <: Tuple{Vararg{AbstractPossibleCadherinSiteManager}},
        CALLBACKS_TYPE,
        ExternalEnergyForce,
        FuncMembraneSpeciesPotentialEnergy,
        SHARED_TYPED_CONFIGS_TYPE <: SharedTypedConfigs,
    }
    agent_names::AgentNames

    sys_def::SysDef

    compartments::Vector{Compartment}

    grid::GRID_TYPE

    "time (s)"
    time::Ref{Float64}

    stats::PerformanceStats

    "inverse kT (1/(nm*pN))"
    β::Float64

    "Diffusion coefficients indexed by diffusing species id (nm²/s)"
    base_diffusion_coeffs::Vector{Float64}

    "Membrane species parameters indexed by membrane diffusing species id."
    membrane_species_params::SVector{NUM_MEMBRANEDIFFUSINGSPECIES,MembraneSpeciesParams}

    "Smallest volume a compartment can have before being deactivated
    as a ratio to a full compartment volume."
    min_compartment_volume_ratio::Float64

    "The reaction diffusion master equation sampler,
    contains the diffusing and regular fixed species state"
    chemistryengine::RDMESAMPLER_TYPE

    "The largest filament id, indexed by filament type id"
    largestfilamentid::Vector{Int}

    "Data about filament cylinders, indexed by filament type id"
    chem_cylinders::Vector{ChemCylinders}

    "All membrane meshes."
    membranes::Vector{MEMBRANEMESH_TYPE}

    link_manager::LinkManager

    "Site managers, indexed by site id"
    decimated_2mon_site_managers::Vector{AbstractDecimated2MonSiteManager}

    "The filament site definitions,
    indexed by filament type id, filament site id
    to get a SiteData with fields of id, site, fxsid"
    filamentsites::FILAMENTSITES_TYPE

    "The filamentend site definitions,
    indexed by filament type id, filamentend site id
    to get a SiteData with fields of id, site, fxsid"
    filamentendsites::FILAMENTENDSITES_TYPE

    "The maximum plus range in monomers that any filament site or end site can see.
    Indexed by filament type id"
    maxfilsite_plusrange::Vector{Int}

    "The maximum minus range in monomers that any filament site or end site can see.
    Indexed by filament type id"
    maxfilsite_minusrange::Vector{Int}

    "Maps membrane site id to a SiteData with fields of id, site, fxsid."
    membranesites::MEMBRANESITES_TYPE

    """
    Maps membrane diffusing species index to a list of membrane sites using this species as reactant.
    This is initialized during context init and should not be changed.
    """
    map_membranediffusingspeciesindex_membranesiteindices::MAP_MEMDIFFU_MEMSITE_TYPE

    "Site definitions,
    indexed by site id
    to get a SiteData with fields of id, site, fxsid"
    decimated_2mon_sites::Vector{SiteData}

    "Site managers, indexed by site id"
    possiblecadherinsite_managers::POSSIBLECADHERINSITESMANAGERS_TYPE

    "If true site counts are checked 
        for errors on every chem update.
        This is extremely slow, but useful for testing 
        chem update errors."
    check_sitecount_error::Bool

    compartmentreactioncallbacks::CALLBACKS_TYPE
    bulkreactioncallbacks::CALLBACKS_TYPE

    "Mock bulk species index for membrane diffusion."
    memdiff_bulks_index::Int = 0

    ## Mechanics
    "viscosity (pN*s/nm² or MPa*s) water is about 1E-9"
    viscosity::Float64

    "maximum force magnitude after minimization (pN)"
    g_tol::Float64

    "number of fractional bits used to scale force values into Int64"
    nforce_fractbit::Int64

    "number of fractional bits used to scale energy values into Int64"
    nenergy_fractbit::Int64

    "If true, add noise to coordinates before starting minimization."
    shake_before_minimization::Bool

    "Max number of steps in conjugate gradient minimization."
    iter_max_cg_minimization::Int

    "max step to take during line search (nm)"
    maxstep::Float64

    "max cylinder force when two cylinders are at zero distance (pN)"
    max_cylinder_force::Float64

    "If true neighborlists are checked 
        for errors on every force calc.
        This is extremely slow, but useful for testing 
        neighborlist errors."
    check_neighborlist_error::Bool

    """ Experimental
    Set to more than 1 to enable multi threading.
    This is currently may result in non bitwise reproducable simulations.
    Results should be statistcally identical, but this is currently not well tested.
    """
    nthreads::Int

    "Are cylinder volume exclusion forces calculated"
    enable_cylinder_volume_exclusion::Ref{Bool}

    "Are triangle-bead volume exclusion forces calculated."
    enable_triangle_bead_volume_exclusion::Bool

    "Extra cell list cutoff radius in nm.
    The cell lists are reset after a bead moves over this amount"
    cylinder_skin_radius::Float64

    "The filament mechanical parameters, indexed by filament type id"
    filamentmechparams::Vector{FilamentMechParams}

    "Membrane mechanical parameters, indexed by membrane type id."
    membranemechparams::Vector{MembraneMechParams}

    "Membrane species potential energy function. See docs on default function for more info."
    func_membranespeciespotentialenergy::FuncMembraneSpeciesPotentialEnergy

    "Membrane-filament mechanical interaction parameters."
    membranefilamentmechparams::MembraneFilamentMechParams

    """
    External energy/force expressions.
    This should be a mutating function taking a `(fc::MEDYAN.ForceContext)`, which adds to `fc.forces, fc.energies, and fc.energy`. The energy and force must be consistent, and this is not checked.
    This can be used as ad-hoc solutions to experiment with uncommon forces, such as specifically designed attachments, etc. If this variable is used often, consider moving it into MEDYAN.
    """
    external_energy_forces!::ExternalEnergyForce

    "chemical boundary,
    updates compartment volumes and diffusion rates"
    chemboundary::Boundary

    """
    The membrane index used as chemical boundary.
    If values other than 0 is used, the actual interior region of the chemical boundary is the intersection between
    - the interior of `chemboundary`, and
    - the interior of the membrane mesh at this index.
    Note: Since the membrane may change its shape often, `set_chemboundary!` might need to be called often accordingly to update volumes of compartments.
    """
    meshindex_as_chemboundary::Ref{Int}

    "mechanical boundary"
    mechboundary::Boundary

    "Shared configurations stored in type parameters."
    sharedtypedconfigs::SHARED_TYPED_CONFIGS_TYPE

    "Interval system consistency validation flags."
    validflags::ValidFlags
end


function Context(sys_def::SysDef,grid;
    diffusion_coeffs=nothing,
    membrane_species_params = SA{MembraneSpeciesParams}[],
    rdmesamplertype::Type{SamplerType} = RDMEPropensityRejectDiffusion,
    filamentmechparams=nothing,
    membranemechparams=[],
    β=default_β,
    viscosity=1E-6,
    g_tol=0.1,
    nforce_fractbit=20,
    nenergy_fractbit=20,
    shake_before_minimization=true,
    iter_max_cg_minimization = 1000000,
    maxstep=0.7,
    max_cylinder_force=3000.0,
    check_neighborlist_error=false,
    check_sitecount_error= false,
    cylinder_skin_radius=5.0,
    min_compartment_volume_ratio=1/16,
    func_membranespeciespotentialenergy = default_membranespeciespotentialenergy,
    sharedtypedconfigs=SharedTypedConfigs(),
    external_energy_forces! = Returns(nothing),
    nthreads=1,
    ) where SamplerType <: RDMESampler
    # Set multithreading options
    # if nthreads is zero, set it to Threads.nthreads()
    nthreads = iszero(nthreads) ? Threads.nthreads() : nthreads

    #set up compartments

    num_filament_types= length(sys_def.filament)
    if isnothing(filamentmechparams)
        filamentmechparams = collect(values(sys_def.filament_params))
    else
        @warn "specifing `filamentmechparams` when constructing Context is deprecated, 
            use `add_filament_params!` on the `SysDef` instead."
    end
    length(filamentmechparams) == num_filament_types || error("length of filamentmechparams must match number of filament types")
    numcompartments= length(grid)
    compartments= Vector{Compartment}(undef,numcompartments)
    for cid in 1:length(grid)
        neighbor_ids= grid_neighbor_ids(grid,cid)
        compartments[cid]= Compartment(cid,neighbor_ids,num_filament_types)
    end
    #set up chemistry engine
    if isnothing(diffusion_coeffs)
        diffusion_coeffs = collect(values(sys_def.diffusing_coeff))
    else
        @warn "specifing diffusion coefficents when constructing Context is deprecated, 
            use `add_diffusion_coeff!` on the `SysDef` instead."
    end
    @argcheck length(diffusion_coeffs) == length(sys_def.diffusing)
    @argcheck length(membrane_species_params) == length(sys_def.membranediffusing)
    chemistryengine= rdmesamplertype{length(sys_def.diffusing),length(sys_def.allfixedspeciesnames)}()
    addgrid!(chemistryengine,grid,diffusion_coeffs)
    addcompartmentreaction!.((chemistryengine,),sys_def.compartmentreactions)
    for _ ∈ 1:length(sys_def.bulkspecies_indexmap)
        addbulkspecies!(chemistryengine, 0)
    end
    addbulkreaction!.((chemistryengine,), sys_def.bulkreactions)
    #set up callbacks
    callbacks= sys_def.compartmentreactioncallbacks
    #setup filament sites convert namedtuples to tuples
    filamentsites = Tuple.(Tuple(sys_def.filamentsite)) |> deepcopy
    filamentendsites = Tuple.(Tuple(sys_def.filamentendsite)) |> deepcopy
    maxfilsite_plusrange = zeros(Int,num_filament_types)
    maxfilsite_minusrange = zeros(Int,num_filament_types)
    for ftid in 1:num_filament_types
        #plus
        filsitemax = maximum(x->getplusrange(x.site),filamentsites[ftid]; init=0)
        filendsitemax = maximum(x->isminusend(x.site)*(getrange(x.site)-1), filamentendsites[ftid]; init=0)
        maxfilsite_plusrange[ftid] = max(filsitemax,filendsitemax)
        #minus
        filsitemax = maximum(x->getminusrange(x.site),filamentsites[ftid]; init=0)
        filendsitemax = maximum(x->!isminusend(x.site)*(getrange(x.site)-1), filamentendsites[ftid]; init=0)
        maxfilsite_minusrange[ftid] = max(filsitemax,filendsitemax)
    end
    chem_cylinders = [ChemCylinders(ftid, filamentmechparams[ftid].numpercylinder) for ftid in 1:num_filament_types]

    # Setup membrane sites.
    membranesites = deepcopy(Tuple(sys_def.membranesite))
    map_membranediffusingspeciesindex_membranesiteindices = let
        local vecmap = [Int[] for _ ∈ eachindex(sys_def.membranediffusing)]
        for siteindex ∈ eachindex(membranesites)
            site = membranesites[siteindex]
            if site.site.id_membranediffusing_reactant != 0
                push!(vecmap[site.site.id_membranediffusing_reactant], siteindex)
            end
        end
        Tuple(vecmap)
    end
    # Setup membrane types.
    MembraneMeshType = gettype_membranemesh(
        Val(tuple(propertynames(sys_def.membranediffusing)...)),
        Val(tuple(propertynames(sys_def.membranesite)...)),
    )

    # Setup links.
    link_manager=LinkManager(collect(LinkConfig, sys_def.link), length(grid))
    
    #setup decimated_2mon_sites
    decimated_2mon_sites = collect(sys_def.decimated_2mon_site) |> deepcopy
    decimated_2mon_site_managers = collect(map(decimated_2mon_sites) do decimated_2mon_site
        if allequal(getftids(decimated_2mon_site.site))
            Decimated2MonOneTypeSiteManager(grid, decimated_2mon_site; nthreads)
        else
            error("decimated_2mon_sites with two different filament types is no longer supported")
        end
    end)

    #setup possiblecadherinsites
    possiblecadherinsites = Tuple(sys_def.possiblecadherinsite) |> deepcopy
    possiblecadherinsite_managers = Tuple(map(possiblecadherinsites) do possiblecadherinsite
            PossibleCadherinSiteManager(grid, possiblecadherinsite; nthreads)
    end)

    # System consistency validations.
    validflags = ValidFlags(VFS_EMPTY)

    Context{typeof(grid),
            length(sys_def.membranediffusing),
            typeof(chemistryengine),
            typeof(filamentsites),
            typeof(filamentendsites),
            typeof(membranesites),
            typeof(map_membranediffusingspeciesindex_membranesiteindices),
            MembraneMeshType,
            typeof(possiblecadherinsite_managers),
            typeof(callbacks),
            typeof(external_energy_forces!),
            typeof(func_membranespeciespotentialenergy),
            typeof(sharedtypedconfigs),
        }(;
        agent_names = sys_def.agent_names,
        sys_def,
        compartments,
        grid,
        time= Ref(0.0),
        stats= PerformanceStats(;callback_reaction_count = zeros(Int,length(callbacks))),
        β,
        viscosity,
        g_tol,
        nforce_fractbit,
        nenergy_fractbit,
        shake_before_minimization,
        iter_max_cg_minimization,
        maxstep,
        max_cylinder_force,
        base_diffusion_coeffs= diffusion_coeffs,
        membrane_species_params,
        min_compartment_volume_ratio,
        chemistryengine,
        chem_cylinders,
        largestfilamentid= fill(0,num_filament_types),
        filamentsites,
        filamentendsites,
        maxfilsite_plusrange,
        maxfilsite_minusrange,
        membranesites,
        map_membranediffusingspeciesindex_membranesiteindices,
        membranes = [],
        link_manager,
        decimated_2mon_sites,
        check_sitecount_error,
        decimated_2mon_site_managers,
        possiblecadherinsite_managers,
        compartmentreactioncallbacks= callbacks,
        bulkreactioncallbacks = sys_def.bulkreactioncallbacks,
        memdiff_bulks_index = (:__MEDYAN_MEMDIFF_BULK ∈ keys(sys_def.bulkspecies_indexmap) ? sys_def.bulkspecies_indexmap.__MEDYAN_MEMDIFF_BULK : 0),
        check_neighborlist_error,
        enable_cylinder_volume_exclusion = Ref(true),
        enable_triangle_bead_volume_exclusion = true,
        cylinder_skin_radius,
        filamentmechparams= copy(filamentmechparams),
        membranemechparams,
        func_membranespeciespotentialenergy,
        membranefilamentmechparams = MembraneFilamentMechParams(),
        external_energy_forces!,
        chemboundary= Boundary(),
        meshindex_as_chemboundary = Ref(0),
        mechboundary= Boundary(),
        sharedtypedconfigs,
        nthreads,
        validflags,
    )
end



Base.show(io::IO, ::Type{<:MEDYAN.Context}) = print(io, "MEDYAN.Context{A bunch of type parameters}")

Base.show(io::IO, ::Type{MEDYAN.Context}) = print(io, "MEDYAN.Context")

function Base.show(io::IO, c::MEDYAN.Context)
    print(io, "MEDYAN.Context at time $(c.time[])s in $(c.grid)")
end

getnum_decimated_2mon_sitetypes(c::Context) = length(c.decimated_2mon_sites)

getnumcompartments(c::Context) = length(c.grid)

getcompartmentvolume(c::Context, cid)::Float64 = inv(c.chemistryengine.invvolumes[cid])

getdiffusingspeciescount(c::Context, cid, dsid) = c.chemistryengine.diffusingcounts[dsid,cid]

"""
Return the nearest active compartment to position.
If there are no active compartments error.
"""
function get_compartment_id(c::Context, position::SVector{3,<:Real})
    cid = filter_grididat(id->isfinite(c.chemistryengine.invvolumes[id]),c.grid, position)
    return cid
end

function get_compartment_id_byvertexname(c::Context, vertex::VertexName)  
    m = c.membranes[vertex.membraneindex]
    vindex = m.metaattr.id2index_vertex[vertex.vid]
    return m.vertices.attr.cid[vindex]
end

"""
Pick a random compartment weighted by volume
"""
function getrandomcompartmentid(c::Context)
    mininvvolume= minimum(c.chemistryengine.invvolumes)
    maxvolume= inv(mininvvolume)
    while true
        cid= rand(1:getnumcompartments(c))
        v= getcompartmentvolume(c, cid)
        u= maxvolume*rand()
        if u ≤ v
            return cid
        end
    end
end

"""
    $(TYPEDSIGNATURES)
Time (s)
"""
set_time!(c::Context, x::Float64)::Float64 = c.time[] = x

"""
    $(TYPEDSIGNATURES)
Are cylinder volume exclusion forces calculated.
"""
set_enable_cylinder_volume_exclusion!(c::Context, x::Bool)::Bool = c.enable_cylinder_volume_exclusion[] = x


"""
    $(TYPEDSIGNATURES)
Set chemical boundary and update compartment volumes and diffusion rates.
Note, the chemboundary should be outside the mechboundary so that it is rare for 
filaments to go outside the chemboundary.

Calling this will invalidate the chem cache.

See also [`Boundary`](@ref)

# Keywords
- `planes::Vector{SVector{4,Float64}} = []`
Planes that make up the chemical boundary of the simulation

`inside = signbit(pos ⋅ planes[bi][1:3] - planes[bi][4])`

For example, a plane `[1,0,0,3]` is inside if x < 3 nm.

`2.0*[1,0,0,3]` is also inside if x < 3 nm.
- `capsules::Vector{SVector{8,Float64}} = []`
Capsules that make up the chemical boundary of the simulation.

`capsules[bi][1:3]` is the starting point of the spine line segment (nm).
`capsules[bi][4:6]` is the axis of the spine line segment (nm).
`capsules[bi][7]` is the radius (nm).
`capsules[bi][8]` is ignored.

if `capsules[bi][4:6]` is zero then the capsule is a sphere.
Capsule boundaries can be combined with plane boundaries to create cylinder boundaries.

- `meshindex_as_chemboundary::Int = 0`: Index of membrane mesh that further restricts the chem boundary. 0 for none.

The system geometry information must be up-to-date.
This mesh index is not stored in the boundary object, but is directly set in the context.
"""
set_chemboundary!(c::Context; meshindex_as_chemboundary::Int = 0, kwargs...)::Boundary = set_chemboundary!(c, Boundary(;kwargs...); meshindex_as_chemboundary)

function set_chemboundary!(c::Context, boundary::Boundary; meshindex_as_chemboundary::Int = 0)::Boundary
    if meshindex_as_chemboundary > 0
        requireall(c.validflags, VFS_MEMBRANE_GEOMETRY_SYSTEM)
    end

    foreach(fieldnames(Boundary)) do k
        copy!(getfield(c.chemboundary,k),getfield(boundary,k))
    end
    defer_chem_caching!(c)
    c.meshindex_as_chemboundary[] = meshindex_as_chemboundary
    grid::CubicGrid = c.grid
    L = grid.compartmentsize
    # get real volumes and areas, currently only support CubicGrid
    areas, volumes = if all(k->isempty(getfield(boundary,k)), fieldnames(Boundary)) && meshindex_as_chemboundary == 0
        fill(L^2,(6,length(grid))), fill(L^3,(length(grid)))
    else
        let grid::CubicGrid = grid, boundary::Boundary = boundary
            local signeddistfun = create_signeddistfun(boundary;
                mesh = (meshindex_as_chemboundary == 0 ? nothing : c.membranes[meshindex_as_chemboundary]),
            )
            """
            New area of each face of the cuboid
            in the order of
                1: x+
                2: x-
                3: y+
                4: y-
                5: z+
                6: z-
            """
            local areas = zeros(6,length(grid))
            local volumes = zeros(length(grid))
            for cid in 1:length(grid)
                local r::PlaneCuboidSlicingResult = function_box_slice(x->clamp(signeddistfun(x),-1E2*L,1E2*L), centerof(grid, cid) .- L/2, L;
                    samples = SA[14,14,14],
                    largeval = 1E6*L,
                )
                volumes[cid] = r.volumeIn
                #This flip is needed because PlaneCuboidSlicingResult 
                # follows a different convension to other stuff.
                # This should be standardized.
                areas[:,cid] .= flip(r, 0x07).areaIn
            end
            areas, volumes
        end
    end
    # update invvolumes, and diffusing rates, don't move any species yet
    # Set invvolumes to Inf to disable the compartment
    minvolume = L^3*c.min_compartment_volume_ratio
    invd = inv(L)
    for cid in 1:length(grid)
        if volumes[cid] < minvolume
            setinvvolume!(c.chemistryengine,cid,Inf)
        else
            setinvvolume!(c.chemistryengine,cid,inv(volumes[cid]))
        end
    end
    for cid in 1:length(grid)
        for side in 1:6
            othercid = adjacentgridid(grid, cid, side)
            otherside = ((side-1)⊻1)+1
            a = 1//2*(areas[side,cid] + areas[otherside,othercid])
            invv = c.chemistryengine.invvolumes[cid]
            otherinvv = c.chemistryengine.invvolumes[othercid]
            for dsid in 1:getnumdiffusingspecies(c.chemistryengine)
                basecoeff = c.base_diffusion_coeffs[dsid]
                newrate = if isfinite(invv) && isfinite(otherinvv)
                    basecoeff*a*invv*invd
                else
                    0.0
                end
                setdiffusionrate!(c.chemistryengine,side,dsid,cid,newrate)
            end
        end
    end
    for cid in 1:length(grid)
        helper_moveout_diffusing_species(cid->isfinite(c.chemistryengine.invvolumes[cid]), c::Context, cid)
    end
    c.chemboundary
end

"""
This function is distinct from the `set_chemboundary!` because setting mesh as boundary should be deferred after the membrane mesh is initialized and the associated geometries are updated. This function updates the mesh index used in chemboundary but does not modify the original chemboundary object.
"""
function set_meshindex_as_chemboundary!(c::Context, meshindex_as_chemboundary::Int)
    set_chemboundary!(c; meshindex_as_chemboundary, c.chemboundary.planes, c.chemboundary.capsules)
end

"""
Randomly move diffusing species out of deactivated compartment with id cid
Each diffusing species is placed at a random position in the compartment 
and then moved to the nearest compartment id where f(id) is true.
if no compartment id evaluates f(id) to true, error
"""
function helper_moveout_diffusing_species(f, c::Context, cid)
    f(cid) && return # no need to move
    for dsid in 1:getnumdiffusingspecies(c.chemistryengine)
        numtomove = c.chemistryengine.diffusingcounts[dsid,cid]
        setdiffusingspeciescount!(c.chemistryengine,dsid,cid,0)
        # This probably could be optimized by sampling a multinomial distribution of where diffusing species can go.
        # But if boundaries are moved slowly, so diffusing species have time to diffuse out of the compartments with small volumes,
        # there shouldn't be many diffusing species to move. 
        for i in 1:numtomove
            position = randompoint(c.grid, cid)
            newcid = filter_grididat(f, c.grid, position)
            incdiffusingspeciescount!(c.chemistryengine,dsid,newcid)
        end
    end
    @assert iszero(c.chemistryengine.diffusingcounts[:,cid])
    return
end


"""
    $(TYPEDSIGNATURES)

See also [`Boundary`](@ref)
"""
set_mechboundary!(c::Context; kwargs...)::Boundary = set_mechboundary!(c, Boundary(;kwargs...))

function set_mechboundary!(c::Context, x::Boundary)::Boundary
    foreach(fieldnames(Boundary)) do k
        copy!(getfield(c.mechboundary,k),getfield(x,k))
    end
    c.mechboundary
end

"""
    $(FUNCTIONNAME)(c::Context, sid, cid, inccount)
Add `inccount` to diffusing species id `sid` in compartment id `cid`
"""
chem_adddiffusingcount!(c::Context, sid, cid, inccount) = adddiffusingspeciescount!(c.chemistryengine,sid,cid,inccount)

"""
    $(FUNCTIONNAME)(c::Context; species, chem_voxel, inccount)
Add `inccount` to diffusing species id `sid` in `chem_voxel`
"""
function add_diffusing_count!(c::Context; species::Union{Symbol,Int}, chem_voxel, amount)
    sid::Int = if species isa Symbol
        c.sys_def.diffusing[species]
    else
        species
    end
    adddiffusingspeciescount!(c.chemistryengine, sid, chem_voxel, amount)
end

"""
    $(FUNCTIONNAME)(c::Context, sid, cid, inccount)
Add `inccount` to fixed species id `sid` in compartment id `cid`
"""
chem_addfixedcount!(c::Context, sid, cid, inccount) = addfixedspeciescount!(c.chemistryengine,sid,cid,inccount)

"""
    $(FUNCTIONNAME)(c::Context, dsid, inccount)
Distribute the added diffusing species count randomly to compartments weighted by volume.

 - `dsid`: diffusing species id.
 - `inccount`: amount to add.
"""
function adddiffusingcount_rand!(c::Context, dsid, inccount)
    for i in 1:inccount
        cid= getrandomcompartmentid(c)
        chem_adddiffusingcount!(c, dsid, cid, 1)
    end
end

"""
    $(TYPEDSIGNATURES)
Distribute the added membrane species count randomly to membrane cells, ignoring cell area difference.
Does NOT update propensity.
"""
function addmembranediffusingcount_rand!(c::Context, membraneindex::Int, speciesindex::Int, addcount::Int)
    m = c.membranes[membraneindex]
    vec_copynumber = getproperty(m.vertices.attr.copynumbers, speciesindex)
    nv = length(m.vertices)
    for _ ∈ 1:addcount
        vindex = rand(1:nv)
        vec_copynumber[vindex] += 1
    end
end


"""
    $(FUNCTIONNAME)(c::Context, Δt)
Run chemistry for Δt time.

Update c.time.
"""
function run_chemistry!(c::Context, Δt; before! = before_run_chemistry!_default, after! = after_run_chemistry!_default)
    before!(c)
    timeleft= Δt
    reactioncount=0
    while timeleft > 0
        rinfo= makestep!(c.chemistryengine,timeleft)
        timeleft-= rinfo.time
        reactioncount+=1
        if rinfo.info.reactiontype == :compartment && rinfo.info.reactionid ≤ length(c.compartmentreactioncallbacks)
            c.stats.callback_reaction_count[rinfo.info.reactionid] += 1
            c.compartmentreactioncallbacks[rinfo.info.reactionid](c, Int64(rinfo.info.compartmentid))
        elseif rinfo.info.reactiontype == :bulk && rinfo.info.reactionid <= length(c.bulkreactioncallbacks)
            c.bulkreactioncallbacks[rinfo.info.reactionid](c)
        end
    end
    c.time[]+= Δt
    c.stats.reaction_count += reactioncount
    after!(c)
    return
end

"""
Default function to be executed every time before chemistry.
"""
function before_run_chemistry!_default(c::Context)
    # Reset compartments and chemistry.
    refresh_chem_cache!(c)

    # Check required flags.
    if !isempty(c.membranes)
        # Diffusion or site reactions exist.
        if c.memdiff_bulks_index > 0 || !isempty(c.membranesites)
            requireall(c.validflags, VFS_MEMBRANE_GEOMETRY_SYSTEM)
            if c.func_membranespeciespotentialenergy isa MembraneSpeciesPotentialEnergy_BendingBashkirov
                requireall(c.validflags, VFS_MEMBRANE_GEOMETRY_FF)
            end
        end
        # Site reactions exist.
        if !isempty(c.membranesites)
            requireall(c.validflags, VFS_VERTEX_IN_COMPARTMENT)
        end
    end
    # Update membrane diffusion propensities.
    if c.memdiff_bulks_index > 0
        for m ∈ c.membranes
            update_membranediffusionpropensity!(c.chemistryengine, c.memdiff_bulks_index, c.β, c.membrane_species_params, m, c.func_membranespeciespotentialenergy)
        end
    end
    # Update all membrane site counts.
    for siteindex ∈ eachindex(c.membranesites)
        for m ∈ c.membranes
            update_membranesitecount!(; rdme = c.chemistryengine, c.β, c.membrane_species_params, mesh = m, c.membranesites, siteindex, c.func_membranespeciespotentialenergy)
        end
    end
end
"""
Default function to be executed every time after chemistry.
"""
function after_run_chemistry!_default(c::Context)
    # Clear membrane diffusion propensities.
    # This step is necessary because operations outside chemistry, such as remeshing, may silently break propensity sum/maximum consistency. Therefore, it is safer to clear all propensities, forcing them to be zeros to maintain consistency.
    if c.memdiff_bulks_index > 0
        for m ∈ c.membranes
            clear_membranediffusionpropensity!(c.chemistryengine, c.memdiff_bulks_index, m)
        end
    end
    # Clear all membrane site counts.
    for siteindex ∈ eachindex(c.membranesites)
        for m ∈ c.membranes
            clear_membranesitecount!(; rdme = c.chemistryengine, mesh = m, c.membranesites, siteindex)
        end
    end
end


#### Chemistry Caching ####

"""
Warn if chem cache are invalid, then ensure they are valid.
"""
function helper_warn_chem_cache_invalid!(c::Context)::Nothing
    if !checkall(c.validflags, VFS_SEGMENTS)
        # Find the name of the function that calls this function.
        stacktrace = StackTraces.stacktrace()
        callingfuncname = if length(stacktrace) > 1
            stacktrace[2].func
        else
            :unknown
        end
        @warn "Segments not valid in $callingfuncname, refreshing cache."
        refresh_chem_cache!(c)
    end
end

"""
    $(FUNCTIONNAME)(c::Context)::Nothing
This should only be used for advanced optimizations.

During chemistry, the context mutating functions
will typically try to avoid invalidating various cached data
needed to quickly sample sites.
    
However, if you want to mutate the context outside of chemistry,
for example right before or after minimization,
you may not want to pay the cost of revalidating all the caches
because minimization will already invalidate the caches.
Caching will be enabled again and caches will be made valid the next time chemistry is run.
Caching can also be manually refreshed and reenabled with:
[`refresh_chem_cache!`](@ref)
"""
function defer_chem_caching!(c::Context)::Nothing
    c.link_manager.cache_valid[] = false
    unset!(c.validflags, VFS_SEGMENTS)
    nothing
end

"""
    $(FUNCTIONNAME)(c::Context)::Nothing
Normally this isn't needed as it will happen automatically.
"""
function refresh_chem_cache!(c::Context)::Nothing
    helper_resetsegments!(c)
    helper_reset_decimated_2mon_site_monomers!(c)
    helper_resetfilamentsitecounts!(c)
    reset_link_cache!(c.link_manager, c)
    helper_update_allverticesincompartments!(c)
    helper_resetpossiblecadherinsites!(c)
    set!(c.validflags, VFS_SEGMENTS)#Whether add VFS_DEP_VERTEX_COORD
    nothing
end

"""
    $(FUNCTIONNAME)(c::Context)::Bool
Return true if the chemistry cache is valid, false otherwise.
"""
function is_chem_cache_valid(c::Context)::Bool
    checkall(c.validflags, VFS_SEGMENTS)
end


"""
    $(FUNCTIONNAME)(c::Context)
Remove all 
    filaments,
    membranes,
    links,
    diffusing species,
    fixed species,
    bulk species,
    chemboundary,
    and mechboundary.
"""
function Base.empty!(c::Context)
    # set all species counts to 0.
    for bulk_species_id in 1:length(c.chemistryengine.bulkcounts)
        setbulkspeciescount!(c.chemistryengine,bulk_species_id,0)
    end
    for cid in 1:length(c.grid)
        for dsid in 1:getnumdiffusingspecies(c.chemistryengine)
            setdiffusingspeciescount!(c.chemistryengine,dsid,cid,0)
        end
        for fxsid in 1:getnumfixedspecies(c.chemistryengine)
            setfixedspeciescount!(c.chemistryengine,fxsid,cid,0)
        end
    end
    # empty segments in compartments
    foreach(c.compartments) do comp::Compartment
        foreach(empty!,comp.segments)
    end
    # empty filaments
    foreach(empty!, c.chem_cylinders)
    c.largestfilamentid .= 0
    empty!(c.link_manager)
    # empty membrane vertexes in compartments
    foreach(c.compartments) do comp::Compartment
        empty!(comp.vertexnames)
    end
    # empty membranes
    empty!(c.membranes)
    set_chemboundary!(c)
    set_mechboundary!(c)
    set!(c.validflags, VFS_EMPTY)
    return
end




#### CHEMISTRY EVENTS ####


"""
assert all invariants on a context.
"""
function assert_invariants(c::Context)
    foreach(assert_invariants, c.chem_cylinders)
    assert_invariants(c.link_manager)
    # check all tags are valid
    foreach(_all_place_types(c.link_manager)) do P
        for t in get_all_tags(c, P())
            @argcheck place_exists(c, tag2place(c, t))
        end
    end
    @argcheck length(c.grid) == length(c.compartments)

end

"""
assert two contexts are statistically equal.
"""
function assert_statistically_equal(c1::Context, c2::Context)
    @argcheck typeof(c1) == typeof(c2)
    assert_invariants(c1)
    assert_invariants(c2)
    if !checkall(c1.validflags, VFS_SEGMENTS)
        refresh_chem_cache!(c1)
        assert_invariants(c1)
    end
    if !checkall(c2.validflags, VFS_SEGMENTS)
        refresh_chem_cache!(c2)
        assert_invariants(c2)
    end
    @argcheck all((getfield(c1.agent_names, k) == getfield(c2.agent_names, k) for k ∈ fieldnames(AgentNames)))
    # check that both contexts have the same segments.
    @argcheck length(c1.compartments) == length(c2.compartments)
    @argcheck num_fila_types(c1) == num_fila_types(c2)
    for cid in 1:length(c1.grid)
        nftid = num_fila_types(c1)
        for ftid in 1:nftid
            #each compartment should match in number of segments per filament type
            segments1 = c1.compartments[cid].segments[ftid]
            segments2 = c2.compartments[cid].segments[ftid]
            if length(segments1) != length(segments2)
                println("missmatch in number of segments")
                println("in compartment $cid ftid: $ftid")
                @show segments1
                @show segments2
            end
            segments_data1 = [((getfield(s, k) for k ∈ fieldnames(Segment))...,) for s in segments1]
            segments_data2 = [((getfield(s, k) for k ∈ fieldnames(Segment))...,) for s in segments2]
            @argcheck issetequal(segments_data1, segments_data2)
        end
    end
    # TODO check compartment vertexnames
    @argcheck c1.time[] == c2.time[]
    @argcheck c1.β == c2.β
    @argcheck c1.base_diffusion_coeffs == c2.base_diffusion_coeffs
    @argcheck c1.membrane_species_params === c2.membrane_species_params
    @argcheck c1.min_compartment_volume_ratio == c2.min_compartment_volume_ratio
    # TODO check membranes are the same.
    # check site counts per compartment
    fixedcounts1 = c1.chemistryengine.fixedcounts
    fixedcounts2 = c2.chemistryengine.fixedcounts
    @argcheck size(fixedcounts1) == size(fixedcounts2)
    for ftid in 1:num_fila_types(c1)
        for site in c1.filamentsites[ftid]
            fxsid = site.fxsid
            if fixedcounts1[fxsid,:] != fixedcounts2[fxsid,:]
                error("filamentsite $site not equal")
            end
        end
        for site in c1.filamentendsites[ftid]
            fxsid = site.fxsid
            if fixedcounts1[fxsid,:] != fixedcounts2[fxsid,:]
                error("filamentendsite $site not equal")
            end
        end
    end
    @argcheck statistically_equal(c1.link_manager, c2.link_manager)
    @argcheck length(c1.decimated_2mon_sites) == length(c2.decimated_2mon_sites)
    for site in c1.decimated_2mon_sites
        fxsid = site.fxsid
        local true_totalcount1 = if allequal(getftids(site.site))
            helper_total_decimated_2mon_sitecount_sameftid(c1, site)
        else
            helper_total_decimated_2mon_sitecount_diffftid(c1, site)
        end
        local true_totalcount2 = if allequal(getftids(site.site))
            helper_total_decimated_2mon_sitecount_sameftid(c2, site)
        else
            helper_total_decimated_2mon_sitecount_diffftid(c2, site)
        end
        local maxtotalcount1 = fixedcounts1[fxsid,:]
        local maxtotalcount2 = fixedcounts2[fxsid,:]
        @argcheck all(true_totalcount1 .≤ maxtotalcount1)
        @argcheck all(true_totalcount2 .≤ maxtotalcount2)
        @argcheck true_totalcount2 == true_totalcount1
        @argcheck true_totalcount1 == get_real_total_decimated_2mon_sitecount(c1, c1.decimated_2mon_site_managers[site.id])
        @argcheck true_totalcount2 == get_real_total_decimated_2mon_sitecount(c2, c2.decimated_2mon_site_managers[site.id])
    end
end

"""
test that defer_chem_caching! doesn't affect the end result of a sequence of mutations.
"""
function test_chem_mutation_sequence(startc, test_seq)
    c = deepcopy(startc)
    for testfun in test_seq
        testfun(c)
    end
    c_no_defer = deepcopy(c)
    for defer_pos in 1:length(test_seq)
        c = deepcopy(startc)
        for testfun in insert!(copy(test_seq), defer_pos, c->MEDYAN.defer_chem_caching!(c))
            testfun(c)
        end
        MEDYAN.assert_statistically_equal(c, c_no_defer)
    end
end

"""
errors if c.check_sitecount_error and c.chemistryengine.fixedcounts changes when compartmentalized
"""
function helper_check_sitecount_error(c::Context)
    if c.check_sitecount_error && checkall(c.validflags, VFS_SEGMENTS)
        c_true = deepcopy(c)
        refresh_chem_cache!(c_true)
        # both should have valid chem_cylinders
        foreach(assert_invariants, c.chem_cylinders)
        # c_true should be statistically identical to c
        assert_statistically_equal(c, c_true)
    end
end

function helper_removeplace!(c::Context, place::Place; warn_if_unlink::Bool)
    has_tag(c, place) || return
    local t = tag!(c, place)
    for link in collect(tag2links(c, t))
        tags = link2tags(c, link)
        if warn_if_unlink
            @warn "removal of $(t) unlinked $(link) attached to $(tags)"
        end
        update_link!(c,
            link;
            places=replace(tags, t=>typeof(t)())
        )
    end
    @assert isempty(tag2links(c, t))
    @assert tag_exists(c, t)
    _force_remove_idx!(_tag_manager(c.link_manager, place), t.idx)
    return
end

"""
Reset the pairlist for each possiblecadherinsite
"""
function helper_resetpossiblecadherinsites!(c::Context)
    foreach(c.possiblecadherinsite_managers) do m
        reset_possiblecadherinsite_counts!(c, m)
    end
end

"""
Update all vertex names in compartments.
"""
function helper_update_allverticesincompartments!(c::Context)
    # Clear all recordings.
    for comp ∈ c.compartments
        empty!(comp.vertexnames)
    end

    # Add all vertices.
    for mindex ∈ eachindex(c.membranes)
        m = c.membranes[mindex]
        for vindex ∈ eachindex(m.vertices)
            coord = m.vertices.attr.coord[vindex]
            cid = get_compartment_id(c, coord)
            push!(c.compartments[cid].vertexnames, VertexName(mindex, m.vertices.attr.id[vindex]))
            # Also stores cid in the vertex.
            m.vertices.attr.cid[vindex] = cid
        end
    end

    set!(c.validflags, VFS_VERTEX_IN_COMPARTMENT)
end


"""
    $(TYPEDSIGNATURES)
Add a new membrane to the system.

# Keyword arguments

- `meshinit` is structure containing mesh shape initialization information, 
    such as a named tuple `(vertlist, trilist)` containing vertex coordinates and triangle list,
    `MeshInitEllipsoid`, `MeshInitPlane` or a general `MeshInitSurfaceFunc`.
"""
function newmembrane!(c::Context; type::Int, meshinit)
    if type ∉ eachindex(c.membranemechparams)
        error("Membrane type $type does not have corresponding mech parameters in the context. Perhaps you should provide a proper list of membrane mech parameters when constructing the context.")
    end
    unset!(c.validflags, VFS_DEP_VERTEX_COORD)
    MT = eltype(c.membranes)
    m = create_membranemesh(getval_speciesnames(MT), getval_membranesitenames(MT); membranetype=type)
    initmesh!(m, meshinit)
    push!(c.membranes, m)
    m
end

function resetvertexstate!(m::DynamicHalfedgeMesh, s::SysDef)
    rand!(m.vertices.attr.vertexstate, collect(s.vertex))
    # All ver2 model test
    vstates = m.vertices.attr.vertexstate
    # for vidx in 1:length(m.vertices.attr.vertexstate)
    #     vstates[vidx] = s.vertex[2]
    # end
    # All vertices on borders have vertex state 1
    for vidx in 1:length(m.vertices.attr.vertexstate)
        if m.vertices.conn[vidx].num_targeting_border_halfedges > 0
            vstates[vidx] = s.vertex[1]
        end
    end
end
