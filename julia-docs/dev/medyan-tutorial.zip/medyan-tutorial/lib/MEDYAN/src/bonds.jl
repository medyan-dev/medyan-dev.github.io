using StaticArrays
using LinearAlgebra
using Random
import ForwardDiff
using Setfield: @set
using ArgCheck: @argcheck
using Rotations: AngleAxis

"""
The `Bond` type is the supertype of all bond force types.
Subtypes should implement `bond_params`, `bond_inputs`, and `bond_energy_force`
"""
abstract type Bond end

"""
    bond_inputs(::Bond)::Vararg{Int}

Return a tuple of the number of vectors each input has.
"""
function bond_inputs end

"""
    bond_params(::Bond)::Vararg{Symbol}

Return a tuple of the parameter names.
"""
function bond_params end

"""
    bond_energy_force(::Bond, inputs, params) -> (energy, forces)

Return the energy and forces.
# Arguments
- `inputs::Tuple{Vararg{Tuple{Vararg{AbstractVector}}}}`: Input vectors.
- `params::NamedTuple`: Parameters.
"""
function bond_energy_force end


#=
Functions to help test Bond implementations.
=#

"""
Test bond_energy_force against the result from ForwardDiff

ArgumentError gets thrown if anything fails.
"""
function test_bond_energy_force_forward_diff(bond::Bond, inputs, params;
        gtol=1E-9
    )
    E0, fs = bond_energy_force(bond, inputs, params)
    for i in eachindex(inputs)
        # force is negative grad of U with position
        g = ForwardDiff.gradient(inputs[i][1]) do x
            local E, fs = bond_energy_force(bond, @set(inputs[i][1]=x), params)
            E
        end
        @argcheck maximum(abs,fs[i][1] + g) ≤ gtol
        # check torque if there are direction inputs
        if length(inputs[i]) > 1
            # torque is grad of U with position × position
            torque = zero(SVector{3, Float64})
            for j in eachindex(inputs[i])[begin+1:end]
                g = ForwardDiff.gradient(inputs[i][j]) do x
                    local E, fs = bond_energy_force(bond, @set(inputs[i][j]=x), params)
                    return E
                end
                torque += g × inputs[i][j]
            end
            @argcheck maximum(abs,fs[i][2] - torque) ≤ gtol
        end
    end
    return true
end

"""
Test bond_energy_force is at a local minimum energy.

ArgumentError gets thrown if not at a local min.
"""
function test_bond_energy_force_at_min(bond::Bond, inputs, params;
        gtol=1E-5, ftol=1E-10, rstd=1E-3, θstd=1E-3, seed=1234, trials=100000)
    #check forces are small
    E0, fs = bond_energy_force(bond, inputs, params)
    for i in eachindex(inputs)
        for j in eachindex(inputs[i])
            @argcheck maximum(abs, fs[i][j]) < gtol
        end
    end
    #check no nearby positions have lower energy
    rng= Random.Xoshiro(seed)
    for t in 1:trials
        local new_inputs = inputs
        for i in eachindex(inputs)
            new_inputs = @set(new_inputs[i][1]+=rstd*randn(rng,SVector{3,Float64}))
            rand_rot = AngleAxis(θstd*randn(), normalize(randn(rng,SVector{3,Float64}))...)
            for j in 2:length(inputs[i])
                new_inputs = @set(
                    new_inputs[i][j] = rand_rot*new_inputs[i][j]
                )
            end
        end
        Etest, fstest = bond_energy_force(bond, new_inputs, params)
        @argcheck Etest-E0 > -ftol
    end
    return true
end



struct PositionRestraint <: Bond end
bond_inputs(::PositionRestraint) = (1,)
bond_params(::PositionRestraint) = (:k, :r0,)
function bond_energy_force(::PositionRestraint, inputs, params)
    Δr = inputs[1][1] - params.r0
    E = 1//2*params.k*(Δr⋅Δr)
    f = -params.k*Δr
    E, ((f,),)
end

struct ConstantForce <: Bond end
bond_inputs(::ConstantForce) = (1,)
bond_params(::ConstantForce) = (:f,)
function bond_energy_force(::ConstantForce, inputs, params)
    E = -(params.f ⋅ inputs[1][1])
    f = params.f
    E, ((f,),)
end

struct DistanceRestraint <: Bond end
bond_inputs(::DistanceRestraint) = (1,1,)
bond_params(::DistanceRestraint) = (:k, :L0,)
function bond_energy_force(::DistanceRestraint, inputs, params)
    r = inputs[2][1] - inputs[1][1]
    L = norm_fast(r)
    ΔL = L - params.L0
    E = 1//2*params.k*ΔL^2
    pf_sim = -params.k*ΔL*r/L
    E, ((-pf_sim,),(pf_sim,),)
end

struct BranchBendingCosine <: Bond end
bond_inputs(::BranchBendingCosine) = (2,2,)
bond_params(::BranchBendingCosine) = (:kr, :kbend, :cos0, :sin0,)
function bond_energy_force(::BranchBendingCosine, inputs, params)
    Δr = inputs[2][1] - inputs[1][1]
    mv̂ = inputs[1][2]
    pv̂ = inputs[2][2]
    Epos = 1//2 * params.kr * (Δr ⋅ Δr)
    mf = params.kr * Δr
    cosθ = mv̂ ⋅ pv̂
    sinθ = norm_fast(mv̂ × pv̂)
    cosθminus0 = cosθ*params.cos0 + sinθ*params.sin0
    Eθ = params.kbend*(1-cosθminus0)
    k = params.kbend*(params.cos0 - params.sin0*cosθ*inv(sinθ))
    mτ⃗ = k * (mv̂ × pv̂)
    E = Epos + Eθ
    E, ((mf, mτ⃗),(-mf, -mτ⃗),)
end

struct PositionDirectionRestraint <: Bond end
bond_inputs(::PositionDirectionRestraint) = (2,)
bond_params(::PositionDirectionRestraint) = (:kr, :kbend, :r0, :v̂0,)
function bond_energy_force(::PositionDirectionRestraint, inputs, params)
    Δr = inputs[1][1] - params.r0
    v̂ = inputs[1][2]
    E = 1//2*params.kr*(Δr⋅Δr) + params.kbend*(1 - params.v̂0 ⋅ v̂)
    f = -params.kr*Δr
    τ⃗ = -params.kbend*(params.v̂0 × v̂)
    E, ((f, τ⃗),)
end