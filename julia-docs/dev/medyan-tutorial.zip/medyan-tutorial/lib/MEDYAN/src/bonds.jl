using StaticArrays
using LinearAlgebra
using Random
import ForwardDiff
using Setfield: @set
using ArgCheck: @argcheck
using Rotations: AngleAxis

"""
The `Bond` type is the supertype of all bond force types.
Subtypes should implement `bond_params`, `bond_inputs`, and `bond_energy_force`
"""
abstract type Bond end

"""
    bond_inputs(::Bond)::Vararg{Int}

Return a tuple of the number of vectors each input has.
"""
function bond_inputs end

"""
    bond_params(::Bond)::Vararg{Symbol}

Return a tuple of the parameter names.
"""
function bond_params end

"""
    bond_energy_force(::Bond, inputs, params) -> (energy, forces)

Return the energy and forces.
# Arguments
- `inputs::Tuple{Vararg{Tuple{Vararg{AbstractVector}}}}`: Input vectors.
- `params::NamedTuple`: Parameters.
"""
function bond_energy_force end


#=
Functions to help test Bond implementations.
=#

"""
Test bond_energy_force against the result from ForwardDiff

ArgumentError gets thrown if anything fails.
"""
function test_bond_energy_force_forward_diff(bond::Bond, inputs, params;
        gtol=1E-9
    )
    E0, fs = bond_energy_force(bond, inputs, params)
    for i in eachindex(inputs)
        for j in eachindex(inputs[i])
            g = ForwardDiff.gradient(inputs[i][j]) do x
                E, fs = bond_energy_force(bond, @set(inputs[i][j]=x), params)
                return E
            end
            @argcheck maximum(abs,fs[i][j] + g) < gtol
        end
    end
    return true
end

"""
Test bond_energy_force is at a local minimum energy.

ArgumentError gets thrown if not at a local min.
"""
function test_bond_energy_force_at_min(bond::Bond, inputs, params;
        gtol=1E-5, ftol=1E-10, rstd=1E-3, θstd=1E-3, seed=1234, trials=100000)
    #check forces are small
    E0, fs = bond_energy_force(bond, inputs, params)
    for i in eachindex(inputs)
        for j in eachindex(inputs[i])
            @argcheck maximum(abs, fs[i][j]) < gtol
        end
    end
    #check no nearby positions have lower energy
    rng= Random.Xoshiro(seed)
    for t in 1:trials
        local new_inputs = inputs
        for i in eachindex(inputs)
            new_inputs = @set(new_inputs[i][1]+=rstd*randn(rng,SVector{3,Float64}))
            rand_rot = AngleAxis(θstd*randn(), normalize(randn(rng,SVector{3,Float64}))...)
            for j in 2:length(inputs[i])
                new_inputs = @set(
                    new_inputs[i][j] = rand_rot*new_inputs[i][j]
                )
            end
        end
        Etest, fstest = bond_energy_force(bond, new_inputs, params)
        @argcheck Etest-E0 > -ftol
    end
    return true
end



struct PositionRestraint <: Bond end
bond_inputs(::PositionRestraint) = (1,)
bond_params(::PositionRestraint) = (:kr, :r0)
function bond_energy_force(::PositionRestraint, inputs, params)
    Δr = inputs[1][1] - params.r0
    E = 1//2*params.kr*(Δr⋅Δr)
    f = -params.kr*Δr
    E, ((f,),)
end