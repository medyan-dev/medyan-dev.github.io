"""
    $(TYPEDSIGNATURES)
Return final out.
Map a function over all minimized monomers within a certain cutoff range.
"""
function map_nearby_monomers(
        f,
        c::Context,
        pos::SVector{3, Float64},
        fil_typeid::Int,
        cutoff_range::Float64,
        out,
    )
    # naive approach, just go through all monomer positions.
    iszero(cutoff_range) && return out
    cutoff_range2 = cutoff_range*cutoff_range
    for fil_id in filtype_fil_ids(c, fil_typeid)
        states = fil_mon_states(c, fil_typeid, fil_id)
        for mon_id in eachindex(fil_mon_states(c, fil_typeid, fil_id))
            name = MonomerName(fil_typeid, fil_id, mon_id)
            if mon_minimized(c, name)
                mon_pos, plusv = mon_position_plusvector(c, name)
                if sum(abs2, mon_pos - pos) ≤ cutoff_range2
                    out = f(name, mon_pos, plusv, states, out)
                end
            end
        end
    end
    out
end