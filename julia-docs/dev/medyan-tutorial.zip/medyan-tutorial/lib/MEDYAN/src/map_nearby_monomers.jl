"""
    $(TYPEDSIGNATURES)
Return final out.
Map a function over all minimized monomers within a certain cutoff range.
"""
function map_nearby_monomers(
        f,
        c::Context,
        pos::SVector{3, Float64},
        fil_typeid::Int,
        cutoff_range::Float64,
        out,
    )
    # naive approach, just go through all monomer positions.
    iszero(cutoff_range) && return out
    cutoff_range2 = abs2(cutoff_range)
    cylinders::ChemCylinders = c.chem_cylinders[fil_typeid]
    invnumpercylinder = inv(cylinders.numpercylinder)
    for fil_idx in eachindex(cylinders.per_fil)
        fil_id = cylinders.per_fil.id[fil_idx]
        chembeadpositions = cylinders.per_fil.chembeadpositions[fil_idx]
        monstates = _fil_mon_states(cylinders, fil_idx)
        minusend_num_notminimized = cylinders.per_fil.minusend_num_notminimized[fil_idx]
        plusend_num_notminimized = cylinders.per_fil.plusend_num_notminimized[fil_idx]
        startmid = firstindex(monstates) + minusend_num_notminimized
        stopmid = lastindex(monstates) - plusend_num_notminimized
        for fil_cyl_idx in 1:length(chembeadpositions)-1
            r1 = chembeadpositions[fil_cyl_idx]
            r2 = chembeadpositions[fil_cyl_idx + 1]
            if point_linesegment_mindistance(pos,r1,r2) ≤ cutoff_range + eps(cutoff_range)
                cyl_mids = _fil_cyl_mon_ids(
                    fil_cyl_idx,
                    _mon_id_info(cylinders, fil_idx)...
                )
                plusv = normalize_fast(r2 - r1)
                for mon_id in max(startmid,first(cyl_mids)):min(stopmid,last(cyl_mids))
                    name = MonomerName(fil_typeid, fil_id, mon_id)
                    mon_id_on_cyl = mon_id - first(cyl_mids)
                    frac = (mon_id_on_cyl + 0.5)*invnumpercylinder
                    mon_pos = frac*r2 + (1.0-frac)*r1
                    if mapfoldl(abs2, +, mon_pos - pos) ≤ cutoff_range2
                        out = f(name, mon_pos, plusv, monstates, out)
                    end
                end
            end
        end
    end
    out
end

function map_nearby_monomers_naive(
        f,
        c::Context,
        pos::SVector{3, Float64},
        fil_typeid::Int,
        cutoff_range::Float64,
        out,
    )
    # naive approach, just go through all monomer positions.
    iszero(cutoff_range) && return out
    cutoff_range2 = abs2(cutoff_range)
    for fil_id in filtype_fil_ids(c, fil_typeid)
        states = fil_mon_states(c, fil_typeid, fil_id)
        for mon_id in eachindex(fil_mon_states(c, fil_typeid, fil_id))
            name = MonomerName(fil_typeid, fil_id, mon_id)
            if mon_minimized(c, name)
                mon_pos, plusv = mon_position_plusvector(c, name)
                if mapfoldl(abs2, +, mon_pos - pos) ≤ cutoff_range2
                    out = f(name, mon_pos, plusv, states, out)
                end
            end
        end
    end
    out
end


function num_nearby_monomers(
        c::Context,
        pos::SVector{3, Float64},
        fil_typeid::Int,
        cutoff_range::Float64,
    )::Int
    map_nearby_monomers(
        c,
        pos,
        fil_typeid,
        cutoff_range,
        0,
    ) do name, mon_pos, plusv, states, out
        out+1
    end
end

function random_nearby_monomer(
        c::Context,
        pos::SVector{3, Float64},
        fil_typeid::Int,
        cutoff_range::Float64,
        max_num_nearby_monomers::Int,
    )::Union{Nothing, MonomerName}
    iszero(cutoff_range) && return
    iszero(max_num_nearby_monomers) && return
    rand_mon_idx::Int = rand(1:max_num_nearby_monomers)
    final_out = map_nearby_monomers(
        c,
        pos,
        fil_typeid,
        cutoff_range,
        (0, 0, 0),
    ) do name, mon_pos, plusv, states, out
        mon_count::Int, fid::Int, mid::Int = out
        mon_count += 1
        if mon_count == rand_mon_idx
            (mon_count, name.fid, name.mid)
        elseif mon_count > rand_mon_idx
            (mon_count, fid, mid)
        else
            (mon_count, 0, 0)
        end
    end
    final_mon_count, final_fid, final_mid = final_out
    @assert final_mon_count ≤ max_num_nearby_monomers
    if final_mon_count < rand_mon_idx
        nothing
    else
        MonomerName(fil_typeid, final_fid, final_mid)
    end
end