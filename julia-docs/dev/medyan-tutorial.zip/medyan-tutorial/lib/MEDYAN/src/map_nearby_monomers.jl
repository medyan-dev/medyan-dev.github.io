using SimplexCellLists: dist2PointLine

"""
    $(TYPEDSIGNATURES)
Return final out.
Map a function over all minimized monomers within a certain cutoff range.

`f(place::FilaMonoIdx, out) -> (out, cont::Bool)` should return a tuple of new out and a boolean.
If the returned boolean is `false` the map will be finish early, and return out.
"""
function map_nearby_monomers(
        f,
        c::Context,
        pos::SVector{3, Float64},
        fil_typeid::Int,
        cutoff_range::Float64,
        out,
    )
    # naive approach, just go through all monomer positions.
    iszero(cutoff_range) && return out
    cutoff_range2 = abs2(cutoff_range)
    cylinders::ChemCylinders = c.chem_cylinders[fil_typeid]
    invnumpercylinder = inv(cylinders.numpercylinder)
    for fil_idx in eachindex(cylinders.per_fil)
        chembeadpositions = cylinders.per_fil.chembeadpositions[fil_idx]
        mon_ids = _fil_mon_ids(cylinders, fil_idx)
        minusend_num_notminimized = cylinders.per_fil.minusend_num_notminimized[fil_idx]
        plusend_num_notminimized = cylinders.per_fil.plusend_num_notminimized[fil_idx]
        startmid = first(mon_ids) + minusend_num_notminimized
        stopmid = last(mon_ids) - plusend_num_notminimized
        for fil_cyl_idx in 1:length(chembeadpositions)-1
            r1 = chembeadpositions[fil_cyl_idx]
            r2 = chembeadpositions[fil_cyl_idx + 1]
            if @inline(dist2PointLine(SA[pos], SA[r1,r2])) ≤ cutoff_range2 + 10*eps(cutoff_range2)
                cyl_mids = _fil_cyl_mon_ids(
                    fil_cyl_idx,
                    _mon_id_info(cylinders, fil_idx)...
                )
                for mon_id in max(startmid,first(cyl_mids)):min(stopmid,last(cyl_mids))
                    place = FilaMonoIdx(FilaIdx(fil_typeid, fil_idx), mon_id)
                    mon_id_on_cyl = mon_id - first(cyl_mids)
                    frac = (mon_id_on_cyl + 0.5)*invnumpercylinder
                    mon_pos = frac*r2 + (1.0-frac)*r1
                    local r = mon_pos - pos
                    if mapfoldl(abs2, +, r) ≤ cutoff_range2
                        out, cont = f(place, out)
                        cont || return out
                    end
                end
            end
        end
    end
    out
end

function map_nearby_monomers_naive(
        f,
        c::Context,
        pos::SVector{3, Float64},
        fil_typeid::Int,
        cutoff_range::Float64,
        out,
    )
    # naive approach, just go through all monomer positions.
    iszero(cutoff_range) && return out
    cutoff_range2 = abs2(cutoff_range)
    for fil_idx in eachindex(c.chem_cylinders[fil_typeid].per_fil)
        for mon_id in fila_mono_ids(c, FilaIdx(fil_typeid, fil_idx))
            place = FilaMonoIdx(FilaIdx(fil_typeid, fil_idx), mon_id)
            if is_minimized(c, place)
                mon_pos = get_position(c, place)
                if mapfoldl(abs2, +, mon_pos - pos) ≤ cutoff_range2
                    out, cont = f(place, out)
                    cont || return out
                end
            end
        end
    end
    out
end


function num_nearby_monomers(
        c::Context,
        pos::SVector{3, Float64},
        fil_typeid::Int,
        cutoff_range::Float64,
    )::Int
    map_nearby_monomers(
        c,
        pos,
        fil_typeid,
        cutoff_range,
        0,
    ) do place, out
        out+1, true
    end
end

function random_nearby_monomer(
        c::Context,
        pos::SVector{3, Float64},
        fil_typeid::Int,
        cutoff_range::Float64,
        max_num_nearby_monomers::Int,
    )::Union{Nothing, FilaMonoIdx}
    iszero(cutoff_range) && return
    iszero(max_num_nearby_monomers) && return
    rand_mon_idx::Int = rand(1:max_num_nearby_monomers)
    final_out = map_nearby_monomers(
        c,
        pos,
        fil_typeid,
        cutoff_range,
        (0, FilaMonoIdx()),
    ) do place, out
        mon_count::Int, last_place::FilaMonoIdx = out
        mon_count += 1
        if mon_count == rand_mon_idx
            (mon_count, place), false
        elseif mon_count > rand_mon_idx
            (mon_count, last_place), false
        else
            (mon_count, FilaMonoIdx()), true
        end
    end
    final_mon_count, final_place = final_out
    @assert final_mon_count ≤ max_num_nearby_monomers
    if final_mon_count < rand_mon_idx
        nothing
    else
        final_place
    end
end