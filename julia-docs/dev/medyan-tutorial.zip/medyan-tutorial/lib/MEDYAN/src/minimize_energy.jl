"""
Energy minimization function for a Context
"""

using StaticArrays
using LinearAlgebra
using Random
using Setfield
using ArgCheck
import CellListMap
import Graphs
using ChunkSplitters: chunks, index_chunks, Consecutive, RoundRobin


"""

$(TYPEDFIELDS)
"""
@kwdef mutable struct MinimizeEnergyResults
    final_energy::Float64 = NaN
end

function Base.show(io::IO, ::MIME"text/plain", r::MinimizeEnergyResults)
    println(io,"$(typeof(r))")
    print(io, "final energy: ", r.final_energy)
end


struct VectorFilamentInfo
    startid::Int32
    endid::Int32
    monomerspercylinder::Int32
    minusmonomerspercylinder::Int32
    plusmonomerspercylinder::Int32
    mon_id_first::Int32
    mon_id_last::Int32
end


struct CylinderEdge
    id1::Int32
    id2::Int32
    kr::Float32 #scale distances
    ke::Float32 #scale energies
end

struct TriangleBeadEdge
    ixtriangle::SVector{3, Int}
    ixbead::Int
end

abstract type VectorPlaceInfo end

# get cylinder indexes that should be effected by no collide
# defaults to empty
function no_collide_cyl_idxs(::VectorPlaceInfo)
    Int32(1):Int32(0)
end

struct VectorMonomerInfo <: VectorPlaceInfo
    startid::Int32
    "Where on the cylinder, 0.0 is at startid, 1.0 is at startid+1 "
    frac::Float64
end
Base.@propagate_inbounds function get_place_pos_dir(p::VectorMonomerInfo, pos, ::Val{N}) where N
    r1 = pos[p.startid]
    r2 = pos[p.startid+1]
    r = p.frac*r2 + (1-p.frac)*r1
    if N == 0
        return (r,)
    elseif N == 1
        v̂ = normalize_fast(r2-r1)
        return (r, v̂)
    else
        error("This place doesn't have $(N) directions")
    end
end
# no torque
Base.@propagate_inbounds function store_place_force!(p::VectorMonomerInfo, force_energy::ForceEnergy, f::NTuple{1, Any}, pos)
    add_bead_force!(force_energy, p.startid, f[1]*(1-p.frac))
    add_bead_force!(force_energy, p.startid+1, f[1]*(p.frac))
    nothing
end
# with torque
Base.@propagate_inbounds function store_place_force!(p::VectorMonomerInfo, force_energy::ForceEnergy, f::NTuple{2, Any}, pos)
    r1 = pos[p.startid]
    r2 = pos[p.startid+1]
    r⃗ = r2 - r1
    τ⃗ = f[2]
    fτ⃗ = (τ⃗ × r⃗) * inv(sum(abs2, r⃗))
    add_bead_force!(force_energy, p.startid, f[1]*(1-p.frac) - fτ⃗)
    add_bead_force!(force_energy, p.startid+1, f[1]*(p.frac) + fτ⃗)
    nothing
end

# get cylinder indexes that should be effected by no collide
function no_collide_cyl_idxs(p::VectorMonomerInfo)
    p.startid-Int32(1):p.startid+Int32(1)
end

struct VectorVertexInfo <: VectorPlaceInfo
    vertexindex_in_mesh::Int32
end
Base.@propagate_inbounds function get_place_pos_dir(p::VectorVertexInfo, pos, ::Val{N}) where N
    r = pos[p.vertexindex_in_mesh]
    if N == 0
        return (r,)
    elseif N == 1
        error("membrane normal not implemented yet")
    else
        error("This place doesn't have $(N) directions")
    end
end
# no torque
Base.@propagate_inbounds function store_place_force!(p::VectorVertexInfo, force_energy::ForceEnergy, f::NTuple{1, Any}, pos)
    add_bead_force!(force_energy, p.vertexindex_in_mesh, f[1])
    nothing
end
# TODO implement membrane normals to allow torque

"""
info about a bond used in mechanics
"""
struct VectorBondInfo{
        N_DIRS, # A tuple of Val(N) of how many directions each input needs
        B <: Bond, P, SP, LP
    }
    "The bond"
    bond::B

    "A vector of tuples of VectorPlaceInfo"
    places::P

    "The shared parameters for the bonds"
    shared_params::SP

    "A vector of the local parameters for the bonds"
    local_params::LP

    "input places have volume exclusion disabled"
    no_collide::Bool
end


@kwdef mutable struct ForceContext{FE<:ForceEnergy}
    x0::Vector{Float64}

    nthreads::Int

    per_thread_force_energy::Vector{FE}

    "inverse of kb*temperature ((pN*nm)^-1)."
    β::Float64

    "Water is about 1E-9 (pN*s/nm² or MPa*s)."
    viscosity::Float64

    "Time used to generate implicit brownian forces (s).
    If set to Inf, brownian motion is disabled."
    brownian_motion_time::Float64 = Inf

    "Random drag force (pN)."
    drag_rand_force::Vector{Float64} = Float64[]

    "Viscous drag spring like effect (pN/nm)"
    drag_back_k::Vector{Float64} = Float64[]

    enable_cylinder_nl::Bool

    cylinder_nl::Vector{CylinderEdge} = CylinderEdge[]

    enable_triangle_bead_nl::Bool

    triangle_bead_nl::Vector{TriangleBeadEdge} = TriangleBeadEdge[]

    "Membrane-filament mechanical interaction parameters."
    membranefilamentmechparams::MembraneFilamentMechParams

    "indexed by filament type id, and filament index"
    filamentindexinfo::Vector{Vector{VectorFilamentInfo}}

    filcoordrange::UnitRange{Int}

    "The filament mechanical parameters, indexed by filament type id"
    filamentmechparams::Vector{FilamentMechParams}

    "Info about bonds used in mechanics"
    bond_info::Vector{VectorBondInfo} = VectorBondInfo[]

    "mechanical boundary"
    mechboundary::Boundary

    smeshes::Vector{StaticHalfedgeMesh}

    vertexcoordrange::UnitRange{Int}

    "Shared configurations stored in type parameters."
    sharedtypedconfigs::SharedTypedConfigs

    "Membrane species parameters indexed by membrane diffusing species id."
    membrane_species_params::SVector # ::SVector{NUM_MEMBRANEDIFFUSINGSPECIES,MembraneSpeciesParams}

    "Membrane mechanical parameters, indexed by membrane type id."
    membranemechparams::Vector{MembraneMechParams}

    """
    External energy/force expressions.
    This should be a function (fc::ForceContext, vectorized_x), which modifies the force and energy in fc as well. The energy and force must be consistent, and this is not checked.
    This can be used as ad-hoc solutions to experiment with uncommon forces, such as specifically designed attachments, etc. If this variable is used often, consider moving it into MEDYAN.
    """
    external_energy_forces!::Any

    # Neighbor list stuff
    # this is optional because neighbor lists might be turned off.

    simboxsize::Vector{Float64}

    cylinder_nl_extra_cutoff::Float64 = NaN

    max_cylinder_force::Float64 = NaN

    cylinder_radii::Vector{Float64} = Float64[]

    cylinder_excluded::Graphs.SimpleGraph{Int64} = Graphs.path_graph(0)

    cylinder_cl_box::Union{CellListMap.Box, Nothing} = nothing

    x0filament_nl::Vector{Float64} = Float64[]

    triangle_bead_cutoff::Float64 = NaN

    triangle_bead_extra_cutoff::Float64 = NaN

    x0filament_triangle_bead_nl::Vector{Float64} = Float64[]

    x0vertices_triangle_bead_nl::Vector{Float64} = Float64[]

end

"""
Create and initialize a ForceContext based on a Context.
"""
function ForceContext(c::Context; brownian_motion_time::Float64=Inf, nthreads=c.nthreads)
    vectorize_result = helper_vectorize_info(c)
    x0, filamentindexinfo, filcoordrange, smeshes, vertexcoordrange = vectorize_result
    x0filament = view(x0, filcoordrange)
    cylinder_points = reinterpret(SVector{3,eltype(x0)}, x0filament)

    #prepare to compute cylinder neighbor list
    enable_cylinder_nl = (
        c.enable_cylinder_volume_exclusion[] &&
        !isempty(filcoordrange)
    )
    enable_triangle_bead_nl = (
        c.enable_triangle_bead_volume_exclusion &&
        !isempty(filcoordrange) &&
        !isempty(vertexcoordrange)
    )
    per_thread_force_energy = map(1:nthreads) do i
        ForceEnergyFixedPoint{c.nforce_fractbit, c.nenergy_fractbit}(length(x0))
    end
    fc = ForceContext{eltype(per_thread_force_energy)}(;
        x0,
        nthreads,
        per_thread_force_energy,
        c.β,
        c.viscosity,
        brownian_motion_time,
        enable_cylinder_nl,
        enable_triangle_bead_nl,
        c.membranefilamentmechparams,
        filamentindexinfo,
        filcoordrange,
        c.filamentmechparams,
        c.mechboundary,
        smeshes,
        vertexcoordrange,
        c.sharedtypedconfigs,
        c.membrane_species_params,
        c.external_energy_forces!,
        c.membranemechparams,
        simboxsize=collect(c.grid.n) .* c.grid.compartmentsize
    )
    helper_vectorize_bonds!(fc, c) # This must happen before neighborlist construction to ensure no_collide is set up
    if fc.enable_cylinder_nl
        begin
            fc.cylinder_nl_extra_cutoff=2*c.cylinder_skin_radius
            #get the cutoff for cylinder cell list
            cylinder_max_radius = maximum(p->p.radius,c.filamentmechparams; init=0.0)
            cylinder_max_length = 1.2*maximum(p->(p.numpercylinder*p.spacing),c.filamentmechparams; init=0.0)
            cylinder_cutoff = fc.cylinder_nl_extra_cutoff + 2cylinder_max_radius + cylinder_max_length
            boxsize = max.(cylinder_cutoff*2.1, fc.simboxsize .+ 1.1*cylinder_cutoff)
            fc.cylinder_cl_box = CellListMap.Box(boxsize,cylinder_cutoff)
            #make auxilary arrays
            numcylinders = max(length(cylinder_points) - 1, 0)
            # the excluded cylinder volume exclusion interactions
            # by default exclude neighbors
            cylinder_excluded = Graphs.path_graph(numcylinders)
            # exclude bonds with no_collide
            foreach(fc.bond_info) do info
                if info.no_collide
                    local cyls = Int32[]
                    for ps in info.places
                        empty!(cyls)
                        foreach(ps) do p
                            append!(cyls, no_collide_cyl_idxs(p))
                            # TODO add bubbles and triangles here
                        end
                        for i in 1:length(cyls)-1
                            for j in i+1:length(cyls)
                                Graphs.add_edge!(cylinder_excluded, cyls[i], cyls[j])
                            end
                        end
                    end
                end
            end
            fc.cylinder_excluded = cylinder_excluded
            #cylinder radii, negative if the cylinder is to be ignored
            cylinder_radii = fill(-1.0,numcylinders)
            for ftid in 1:num_fila_types(c)
                mechparams = c.filamentmechparams[ftid]
                for filamentinfo in filamentindexinfo[ftid]
                    startid = filamentinfo.startid
                    endid = filamentinfo.endid
                    cylinder_radii[startid:endid-1] .= mechparams.radius
                end
            end
            fc.cylinder_radii = cylinder_radii
            fc.max_cylinder_force = c.max_cylinder_force
        end
        #Actually compute cylinder volume exclusion neighbor list
        #positions at
        fc.x0filament_nl = copy(x0filament)
        #when 2maxmotion > extra_cutoff, cylinder_nl get remade
        fc.cylinder_nl = cylinder_neighborlist(
            fc.cylinder_cl_box,
            x0filament,
            fc.cylinder_excluded,
            fc.cylinder_radii,
            fc.cylinder_nl_extra_cutoff,
            fc.max_cylinder_force,
        )

    end
    if fc.enable_triangle_bead_nl
        # Get cell list box for triangle-bead neighbor list.
        fc.triangle_bead_cutoff = c.membranefilamentmechparams.cutoffvolexcl
        fc.triangle_bead_extra_cutoff = fc.triangle_bead_cutoff * 0.5
        fc.triangle_bead_nl = triangle_bead_neighborlist(
            fc.triangle_bead_cutoff,
            fc.triangle_bead_extra_cutoff,
            fc.simboxsize,
            fc.smeshes,
            x0,
            fc.filcoordrange
        )
        fc.x0filament_triangle_bead_nl = copy(x0filament)
        fc.x0vertices_triangle_bead_nl = copy(view(x0, vertexcoordrange))
    end
    if isfinite(brownian_motion_time)
        #= 
        Brownian motion is implemented using a backward Euler method
        https://en.wikipedia.org/wiki/Backward_Euler_method
        Basically, based on the drag_coefficents, there are two added forces,
        a random force, and a restoring force.
        The following is a derivation of the added forces.

        Lets start with a discretized brownian dynamics equation.
        X(Δt) = X(0) - μ ∇U(X(?))*Δt + √(2*Δt*kT*μ)*randn()
        Where randn() is a standard normal vector with 
        the same length as X, ∇U is the gradient of the energy, 
        μ is a square matrix representing the mobility. For simplicity
        I am treating the mobility as constant, diagonal, 
        and positive definite.
        if ? is replaced with 0, this is a forward Euler method,
        if ? is replaced with (Δt) this is a backward Euler method.
        
        X(Δt) = X(0) - μ∇U(X(Δt))*Δt + √(2*Δt*kT*μ)*randn()
        0 = X(0) - X(Δt) - μ∇U(X(Δt))*Δt + √(2*Δt*kT*μ)*randn()
        0 = -(X(Δt) - X(0)) - μ∇U(X(Δt))*Δt + √(2*Δt*kT*μ)*randn()
        let ΔX = X(Δt) - X(0)
        0 = -ΔX - μ∇U(X(Δt))*Δt + √(2*Δt*kT*μ)*randn()
        0 = -Δt⁻¹μ⁻¹ΔX - ∇U(X(Δt)) + Δt⁻¹μ⁻¹√(2*Δt*kT*μ)*randn()
        0 = -Δt⁻¹μ⁻¹ΔX - ∇U(X(Δt)) + √(2*Δt⁻¹*kT*μ⁻¹)*randn()
        0 = ∇U(X(Δt)) + Δt⁻¹μ⁻¹ΔX  - √(2*Δt⁻¹*kT*μ⁻¹)*randn()

        
        A solution to the last equation can be found by finding a local minima of:
        U(X(Δt)) + ½Δt⁻¹ΔXᵀ*μ⁻¹*ΔX - (√(2*Δt⁻¹*kT*μ⁻¹)*randn())ᵀ*ΔX

        Thus by adding the energy term:
        ½Δt⁻¹ΔXᵀ*μ⁻¹*ΔX - (√(2*Δt⁻¹*kT*μ⁻¹)*randn())ᵀ*ΔX
        and minimizing, we are also solving a discretized version of the
        brownian dynamics equation.
        =#
        drag_coefficents = _calc_drag_coefficents(fc)
        kT = inv(fc.β)
        drag_rand_force_sdiv = sqrt.((2*kT*inv(brownian_motion_time)) .* drag_coefficents)
        fc.drag_rand_force =  drag_rand_force_sdiv .* randn(length(drag_coefficents))
        fc.drag_back_k = inv(brownian_motion_time) .* drag_coefficents
        # @show drag_rand_force_sdiv[1]
        # @show fc.drag_back_k[1]
    end
    fc
end

"""
This should be called before calculating forces and energies.
"""
function refresh_neighborlists!(fc::ForceContext, x::Vector{<:Number}; check_neighborlist_error=false)
    # Cylinder volume exclusion neighbor list update.
    if fc.enable_cylinder_nl
        xfilament = view(x, fc.filcoordrange)
        x0filament_nl = fc.x0filament_nl
        # figure out if neighborlist needs be remade
        # maxmotion = √(3)*maximum(abs,xfilament-fc.x0filament_nl)
        maxmotion = zero(eltype(x))
        @inbounds for i in eachindex(xfilament)
            maxmotion = Base.FastMath.max_fast(maxmotion, abs(xfilament[i] - x0filament_nl[i]))
        end
        maxmotion = oftype(maxmotion, √(3))*maxmotion
        if 2maxmotion > fc.cylinder_nl_extra_cutoff
            #@warn "remaking cylinder_nl"
            #reset cylinder_nl
            x0filament_nl .= xfilament
            fc.cylinder_nl = cylinder_neighborlist(
                fc.cylinder_cl_box,
                xfilament,
                fc.cylinder_excluded,
                fc.cylinder_radii,
                fc.cylinder_nl_extra_cutoff,
                fc.max_cylinder_force,
            )
        end
        if check_neighborlist_error
            check_cylinder_neighborlist(
                xfilament,
                fc.cylinder_excluded,
                fc.cylinder_radii,
                fc.cylinder_nl
            )
        end
    end
    # Triangle-bead volume exclusion neighbor list update.
    if fc.enable_triangle_bead_nl
        # Update neighbor list if needed.
        xfilament = view(x, fc.filcoordrange)
        xvertices = view(x, fc.vertexcoordrange)
        maxrelmotion = √(3)*(maximum(abs, xfilament - fc.x0filament_triangle_bead_nl) + maximum(abs, xvertices - fc.x0vertices_triangle_bead_nl))
        if maxrelmotion > fc.triangle_bead_extra_cutoff
            fc.x0filament_triangle_bead_nl .= xfilament
            fc.x0vertices_triangle_bead_nl .= xvertices
            fc.triangle_bead_nl = triangle_bead_neighborlist(
                fc.triangle_bead_cutoff,
                fc.triangle_bead_extra_cutoff,
                fc.simboxsize,
                fc.smeshes,
                x,
                fc.filcoordrange
            )
        end
    end
end

"""
This functions doesn't update neighbor lists.
"""
function calc_all_force_energy!(fc::ForceContext, x::Vector{<:Number})::Nothing
    main_force_energy = fc.per_thread_force_energy[1]
    nthreads = fc.nthreads
    check_len_force_energy(main_force_energy, length(x))
    @argcheck length(x) == length(fc.x0)
    if nthreads == 1
        set_zero_force_energy!(main_force_energy)
        calc_chunk_force_energy!(fc, x; chunk=1, nthreads=1)
    else
        @sync for chunk in 1:nthreads
            Threads.@spawn let chunk = $chunk, nthreads = $nthreads, force_energy = $(fc.per_thread_force_energy[chunk])
                set_zero_force_energy!(force_energy)
                calc_chunk_force_energy!(fc, x; chunk, nthreads)
            end
        end
        # Accumutate main_force_energy
        @inbounds for chunk in 2:fc.nthreads
            for dof in 1:length(x)
                main_force_energy.forces[dof] += fc.per_thread_force_energy[chunk].forces[dof]
            end
            main_force_energy.energy[] += fc.per_thread_force_energy[chunk].energy[]
        end
    end
    for sm in fc.smeshes
        compute_geometry!(sm, x, fc.sharedtypedconfigs.meshcurv)
        membrane_energies!(
            fc.membranemechparams[sm.metaattr.membranetype], fc.membrane_species_params, sm, x, main_force_energy;
            bending_mode = fc.sharedtypedconfigs.bending_mode,
            meshcurv = fc.sharedtypedconfigs.meshcurv,
        )
    end
    local external_energy_forces! = fc.external_energy_forces!
    if !(external_energy_forces! isa Returns)
        external_energy_forces!(fc, x)
    end
    nothing
end

function calc_chunk_force_energy!(fc::ForceContext, x::Vector{<:Number}; chunk=1, nthreads=1)::Nothing
    force_energy = fc.per_thread_force_energy[chunk]
    if fc.enable_cylinder_nl && chunk ≤ length(fc.cylinder_nl)
        cylindervolume_exclusion_closest!(force_energy, x, chunks(fc.cylinder_nl; n=nthreads)[chunk])
    end
    # Triangle-bead volume exclusion interaction energy and forces.
    if fc.enable_triangle_bead_nl && chunk ≤ length(fc.triangle_bead_nl)
        # Actual energy.
        tb_cutoff = fc.membranefilamentmechparams.cutoffvolexcl
        for pair in chunks(fc.triangle_bead_nl; n=nthreads)[chunk]
            triangle_bead_volexcl!(fc.membranefilamentmechparams.kvolexcl, pair.ixtriangle, pair.ixbead, x, force_energy; cutoff=tb_cutoff)
        end
    end
    for ftid in 1:length(fc.filamentindexinfo)
        local filamentmechparam = fc.filamentmechparams[ftid]
        chunk > length(fc.filamentindexinfo[ftid]) && continue
        for info in chunks(fc.filamentindexinfo[ftid]; n=nthreads, split=RoundRobin())[chunk]
            local startid = info.startid
            local endid = info.endid
            internal_filament_forces!(
                force_energy,
                @view(x[3startid-2:3endid]),
                filamentmechparam,
                info.monomerspercylinder,
                info.minusmonomerspercylinder,
                info.plusmonomerspercylinder,
            )
        end
    end
    foreach(fc.bond_info) do info
        bond_forces!(force_energy, x, info; chunk, nthreads)
    end
    mechboundary_forces!(force_energy, x, fc.mechboundary; chunk, nthreads)
    if isfinite(fc.brownian_motion_time) && chunk ≤ length(x)
        @inbounds for i in index_chunks(x; n=nthreads)[chunk]
            local rand_force = fc.drag_rand_force[i]
            local negΔx = fc.x0[i] - x[i]
            local drag_force = fc.drag_back_k[i]*negΔx
            add_dof_force!(force_energy, i, drag_force + rand_force)
            add_energy!(force_energy, rand_force*negΔx + 1//2*drag_force*negΔx)
        end
    end
    nothing
end

"""
This functions doesn't update neighbor lists.
This calculates forces used for loading filament ends.
"""
function calc_load_force_energy!(fc::ForceContext, x::Vector{<:Number})::Nothing
    force_energy = fc.per_thread_force_energy[1]
    check_len_force_energy(force_energy, length(x))
    @argcheck length(x) == length(fc.x0)
    set_zero_force_energy!(force_energy)
    if fc.enable_cylinder_nl
        cylindervolume_exclusion_closest!(force_energy, x, fc.cylinder_nl)
    end
    # Triangle-bead volume exclusion interaction energy and forces.
    if fc.enable_triangle_bead_nl
        # Actual energy.
        tb_cutoff = fc.membranefilamentmechparams.cutoffvolexcl
        for pair in fc.triangle_bead_nl
            triangle_bead_volexcl!(fc.membranefilamentmechparams.kvolexcl, pair.ixtriangle, pair.ixbead, x, force_energy; cutoff=tb_cutoff)
        end
    else
        0.0
    end
    mechboundary_forces!(force_energy, x, fc.mechboundary)
    nothing
end

"""
    $(FUNCTIONNAME)(c::Context)::MinimizeEnergyResults

Minimize mechanical energy of the context.

# Keyword Arguments
- `check_closest_cylinders::Bool=true`: 
If true, the function will warn if two cylinders get too close during minimization.

- `brownian_motion_time::Float64=Inf`: This parameter is used to simulate the effect 
of Brownian motion over a certain period of time in seconds. 
It is currently experimental.
By default, the effect of Brownian motion is ignored.

- `g_tol::Float64=c.g_tol`: The acceptable maximum residual force on any degree of freedom in pN.

- `iter_max::Int=c.iter_max_cg_minimization`: The maximum number of congugate gradient iterations to do before exiting.
"""
function minimize_energy!(c::Context;
        check_closest_cylinders::Bool=true,
        brownian_motion_time::Float64=Inf,
        g_tol::Float64=c.g_tol,
        iter_max::Int = c.iter_max_cg_minimization,
    )::MinimizeEnergyResults
    me_timer₀ = time_ns()
    fc = ForceContext(c; brownian_motion_time)

    x = copy(fc.x0)
    # add some randomness to x0
    if c.shake_before_minimization
        x .+= 0.001 .* randn(length(x))
    end

    yield_counter::Int = 0 # something to avoid yielding too often
    function fg!(F,G,x)
        yield_counter = (yield_counter+1)%16
        iszero(yield_counter) && yield()

        refresh_neighborlists!(fc, x; c.check_neighborlist_error)

        fg_timer₀ = time_ns()
        calc_all_force_energy!(fc, x)
        c.stats.force_evals_count += 1
        c.stats.force_evals_time += (time_ns() - fg_timer₀)

        if !isnothing(G)
            get_grad!(fc.per_thread_force_energy[1], G)
        end
        if !isnothing(F)
            return get_energy(fc.per_thread_force_energy[1])
        end
    end
    result = MinimizeEnergyResults()
    # The code in the following let block is mostly from Optim.jl optimize() using Conjugate Gradient
    # This is using the algorithm for β described in section 2 of
    # THE LIMITED MEMORY CONJUGATE GRADIENT METHOD Hager and Zhang 2013
    # The lineseach algorithm is derived from the backtracking method in
    # Nocedal and Wright, 2nd ed, section 3.5
    # This is also implemented in https://github.com/JuliaNLSolvers/LineSearches.jl/blob/v7.4.0/src/backtracking.jl
    # Like Optim.jl there is a convergence condition on both the gradient and
    # the function value. Due to rounding errors, if the value hasn't changed after the
    # linesearch, the minimization is considered converged, even if the `g_tol`
    # condition isn't met. This could be changed to get a more precise answers
    # using the "approximate Wolfe" conditions method described in Hager and Zhang 2005
    let
        # Initial force and energy.
        local x_trial = copy(x) # x used during linesearch trials
        local grad_prev = fill(NaN, length(x))
        local grad = fill(NaN, length(x))
        local search_direction = fill(NaN, length(x))
        local energy_prev = NaN
        local energy = NaN
        # Line search parameters
        # Using conventions from Nocedal and Wright, 2nd ed, section 3.5
        local c₁ = 1E-4
        local max_linesearch_iterations = 1000
        local ρ_lo = 0.1
        local ρ_hi = 0.9
        # CG parameters
        local η = 0.4 # From Hager Zhang 2013
        for iteration in 1:iter_max
            local ϕ′₀
            # Get search direction
            if iteration == 1
                energy = fg!(0.0, grad, x)
                if maximum(abs, grad) ≤ g_tol
                    @goto cg_converged
                end
                search_direction .= .- grad
                ϕ′₀ = dot(search_direction, grad)
            else
                # Determine the next search direction using HZ's CG rule
                #  Calculate the beta factor (HZ2013)
                local ddotd = dot(search_direction, search_direction)
                local ηₖ = η * dot(search_direction, grad_prev) / ddotd # New in HZ2013
                grad_prev .= grad .- grad_prev # store y in grad_prev because it isn't needed
                local y = grad_prev
                local ydotd = dot(y, search_direction)
                local ddotg = dot(search_direction, grad)
                local ydoty = dot(y, y)
                local ydotg = dot(y, grad)
                # ydots may be zero if f is not strongly convex or the line search does not satisfy Wolfe
                local θₖ = 1.0
                local βₖ = (ydotg - θₖ*(ydoty*ddotg/ydotd)) / ydotd
                # betak may be undefined if ydots is zero (may due to f not strongly convex or non-Wolfe linesearch)
                local β⁺ₖ = maxnan(βₖ, ηₖ)
                search_direction .= β⁺ₖ .* search_direction .- grad
                ϕ′₀ = dot(search_direction, grad)
                if ϕ′₀ ≥ 0
                    @warn "resetting the search direction because it wasn't a descent direction"
                    search_direction .= .- grad
                    ϕ′₀ = dot(search_direction, grad)
                end
            end
            # @show (energy, maximum(abs, grad), iteration, ϕ′₀, ϕ′₀/norm(search_direction)/norm(grad))
            # Line search
            # Initial step length
            local ϕ₀ = energy
            # Nocedal and Wright, 2nd ed, equation 3.60 limited to max step distance
            # local α = c.maxstep/maximum(abs, search_direction)
            local α = minnan(2 * (energy - energy_prev) / ϕ′₀, c.maxstep/maximum(abs, search_direction))
            # swap grad and grad_prev
            local grad_temp = grad_prev
            grad_prev = grad
            grad = grad_temp
            energy_prev = energy
            local linesearch_iteration = 0
            while true
                # @show α
                α ≥ 0 || error("linesearch step length is negative")
                if linesearch_iteration ≥ max_linesearch_iterations
                    error("linesearch failed to find point with sufficient decrease")
                end
                x_trial .= x .+ α .* search_direction
                energy = fg!(0.0, grad, x_trial)
                local x_temp
                if maximum(abs, grad) ≤ g_tol
                    # swap x and x_trial
                    x_temp = x
                    x = x_trial
                    x_trial = x_temp
                    @goto cg_converged
                end
                # sufficient decrease condition
                # This is written so that if the new energy is equal to
                # the old energy, and c₁*α*ϕ′₀ is small enough that 
                # ϕ₀ + c₁*α*ϕ′₀ == ϕ₀ due to rounding errors, the condition is
                # satisfied.
                # This could be changed to get a more precise answers
                # using the "approximate Wolfe" conditions method described in Hager and Zhang 2005
                if energy ≤ ϕ₀ + c₁*α*ϕ′₀
                    # swap x and x_trial
                    x_temp = x
                    x = x_trial
                    x_trial = x_temp
                    # check if energy has converged
                    if energy == ϕ₀
                        @goto cg_converged
                    end
                    break
                end
                # quadratic interpolation Nocedal and Wright, 2nd ed, equation 3.58
                local α_q = - ϕ′₀ * α^2 / (2*(energy - ϕ₀ - ϕ′₀*α))
                # if the interpolated α is too small, too big, or not finite
                # set it to half the previous value.
                α = if !(α_q > ρ_lo*α) || !(α_q < ρ_hi*α)
                    α/2
                else
                    α_q
                end
                linesearch_iteration += 1
            end
            # Check min Cylinder Cylinder distance and compare to max step
            if fc.enable_cylinder_nl && check_closest_cylinders
                local mindist = cylinder_cylinder_min_closest_dist(x, fc.cylinder_nl)
                if mindist ≤ 2*√(3)*c.maxstep
                    warn_about_closest_cylinders(c, x, fc.cylinder_nl, fc.filamentindexinfo, iteration)
                end
            end
        end
        # Failed to converge in iter_max steps
        @warn "Energy minimization failed to converge in $(iter_max) iterations"
        @warn "residual forces is $(maximum(abs, grad))"
        @label cg_converged
        result.final_energy = energy
    end
    #compute load forces using just mechboundary and cylinder volume exclusion
    calc_load_force_energy!(fc, x)
    write_back_positions_and_load_forces!(c, fc, get_force(fc.per_thread_force_energy[1]), x)
    c.stats.minimize_energy_count += 1
    c.stats.minimize_energy_time += (time_ns() - me_timer₀)
    result
end

function write_back_positions_and_load_forces!(c::Context, fc::ForceContext, forces::Vector{<:Number}, x::Vector{<:Number})
    helper_unvectorize_info!(c, x, forces, fc.filamentindexinfo)
    # set cache_valid to false on link_manager
    c.link_manager.cache_valid[] = false
    # set link is_minimized to true
    _set_all_minimized!(c.link_manager)

    # Breaks consistency of the following.
    unset!(c.validflags, VFS_SEGMENTS ∪ VFS_DEP_VERTEX_COORD)
    nothing
end

"""
Return the drag coefficent of a cylinder.
The parameters are described in:

https://gitlab.com/f-nedelec/cytosim/-/blob/2034e708f676713fd7caa8ff974cbcf8120f9bc4/src/sim/fiber.cc#L554-592

This should give similar results as
https://gitlab.com/f-nedelec/cytosim/-/blob/2034e708f676713fd7caa8ff974cbcf8120f9bc4/src/sim/fiber.cc#L554-592

There is a diffence for very short filaments:
this version smoothly switches to the drag of a sphere 
(3 * π * viscosity * diameter)
as fil_len approaches 2drag_radius, instead of 
jumping at ( ~ 3.94 * radius ).

Also note the parameters are in nm instead of μm.
"""
function cytosim_cylinder_drag(
        viscosity, # pN*s/nm²
        drag_radius, # nm
        drag_length, # nm
        fil_len, # nm
    )
    len_full = max(fil_len, 2drag_radius)
    lenc = min(len_full, drag_length)
    shape_factor = log(0.5*lenc/drag_radius + 1.0) + 0.32
    3 * π * viscosity * len_full * inv(shape_factor)
end

"""
Return the independent drag coefficents of the degrees of freedom.
"""
function _calc_drag_coefficents(fc::ForceContext)::Vector{Float64}
    m = fill(NaN, length(fc.x0))
    if fc.filcoordrange != eachindex(m)
        error("Drag only implemented for filaments for now")
    end
    for ftid in 1:length(fc.filamentindexinfo)
        local filamentmechparam = fc.filamentmechparams[ftid]
        for info in fc.filamentindexinfo[ftid]
            local num_monomers = info.mon_id_last - info.mon_id_first + 1
            local fil_len = filamentmechparam.spacing * num_monomers # nm
            local drag_radius = filamentmechparam.radius # use steric radius as drag radius
            local drag_length = 5E3 # using default value from cytosim, converted to nm.
            # TODO make this more customizable.
            local drag_cylinder = cytosim_cylinder_drag(fc.viscosity, drag_radius, drag_length, fil_len)
            local drag_per_mon = drag_cylinder/num_monomers
            local startid = info.startid
            local endid = info.endid
            for node_id in startid:endid
                # assign drag to each node
                local n_mons::Float64 = if node_id == startid
                    info.minusmonomerspercylinder/2
                elseif node_id == endid
                    info.plusmonomerspercylinder/2
                elseif node_id == startid + 1 && node_id == endid - 1
                    info.minusmonomerspercylinder/2 + info.plusmonomerspercylinder/2
                elseif node_id == startid + 1
                    info.minusmonomerspercylinder/2 + info.monomerspercylinder/2
                elseif node_id == endid - 1
                    info.monomerspercylinder/2 + info.plusmonomerspercylinder/2
                else
                    info.monomerspercylinder
                end
                m[3node_id-2:3node_id] .= drag_per_mon*n_mons
            end
        end
    end
    m
end

"""
Log a warning about the closest pair of cylinders.
"""
function warn_about_closest_cylinders(c, x, neighborlist, filamentindexinfo, iteration)
    posvect = reinterpret(SVector{3,eltype(x)}, x)
    d2min, pair_idx = findmin(neighborlist) do edge
        @inbounds P0, P1 = posvect[edge.id1],posvect[edge.id1+1]
        @inbounds Q0, Q1 = posvect[edge.id2],posvect[edge.id2+1]
        @inline d2 = linesegment_linesegment_dist2(P0, P1, Q0, Q1)
        d2
    end
    mindist = √d2min
    edge = neighborlist[pair_idx]
    # now get fil_idx
    id1_info = mech_debug_fil_pos_idx(c, filamentindexinfo, edge.id1)
    id2_info = mech_debug_fil_pos_idx(c, filamentindexinfo, edge.id2)
    @warn """cylinders are too close after a line search, min distance: $(round(mindist;sigdigits=5)) nm
    consider decreasing context maxstep, currently: $(c.maxstep) nm
        or increasing context max_cylinder_force, currently: $(c.max_cylinder_force) pN
    Iteration: $iteration
    Cylinders are on filament indexes: $(id1_info.fil_idx) and $(id2_info.fil_idx)
    Cylinder A is number $(id1_info.cyl_idx_on_fil) of $(id1_info.num_cyl)
    Cylinder B is number $(id2_info.cyl_idx_on_fil) of $(id2_info.num_cyl)
    Filament A had $(id1_info.chem_fil_info.plusend_num_notminimized) new plus end monomers last chem.
    Filament A had $(id1_info.chem_fil_info.minusend_num_notminimized) new minus end monomers last chem.
    Filament B had $(id2_info.chem_fil_info.plusend_num_notminimized) new plus end monomers last chem.
    Filament B had $(id2_info.chem_fil_info.minusend_num_notminimized) new minus end monomers last chem.
    """
end

"""
Return a named tuple with info about a filament position index.

`filamentindexinfo`: returned from `helper_vectorize_info`
`index`: the index of the position, in the vector of 3D positions.
"""
function mech_debug_fil_pos_idx(c::Context, filamentindexinfo, index)
    for ftid in eachindex(filamentindexinfo)
        # Using linear search because this is just for debug.
        for (fil_idx, fil_info) in pairs(filamentindexinfo[ftid])
            sid = fil_info.startid
            eid = fil_info.endid
            if index ∈ (sid:eid)
                cylinders = c.chem_cylinders[ftid]
                chem_fil_info = cylinders.per_fil[fil_idx]
                return (;
                    ftid,
                    fil_idx,
                    cyl_idx_on_fil = index - sid + 1,
                    num_cyl =  eid - sid,
                    chem_fil_info,
                )
            end
        end
    end
    error("point isn't a filament")
end


"""
Return a vector of CylinderEdge
"""
function cylinder_neighborlist(
        cl_box,
        x,
        excluded,
        radii,
        extra_cutoff,
        max_force,
    )::Vector{CylinderEdge}
    #if no cylinders return empty NL
    isempty(radii) && return []
    
    mid_flat = (1//2) .* (x[begin:end-3] .+ x[begin+3:end])
    mid_points = reinterpret(SVector{3,eltype(mid_flat)},mid_flat)
    start_points = reinterpret(SVector{3,eltype(x)},x)
    nl = Vector{CylinderEdge}()
    numcylinders = length(mid_points)
    cl = CellListMap.CellList(mid_points,cl_box;parallel=false)
    CellListMap.map_pairwise_serial!(nl,cl_box,cl) do x,y,i,j,d2,output
        local ri = radii[i]
        local rj = radii[j]
        # check if i and j are ignored
        if ri > 0 && rj > 0
            if !Graphs.has_edge(excluded, i, j)
                cutoff = extra_cutoff + ri + rj
                i0 = start_points[i]
                i1 = start_points[i+1]
                j0 = start_points[j]
                j1 = start_points[j+1]
                d2 = linesegment_linesegment_dist2(i0,i1,j0,j1)
                if d2 ≤ cutoff^2
                    kr = inv(ri+rj)
                    push!(nl, CylinderEdge(min(i,j), max(i,j), kr, max_force/kr))
                end
            end
        end
        nl
    end

    # for i in 1:numcylinders-1
    #     for j in i+1:numcylinders
    #         ri = radii[i]
    #         rj = radii[j]
    #         # check if i and j are ignored
    #         if ri > 0 && rj > 0
    #             if !Graphs.has_edge(excluded, i, j)
    #                 cutoff = extra_cutoff + ri + rj
    #                 i0 = start_points[i]
    #                 i1 = start_points[i+1]
    #                 j0 = start_points[j]
    #                 j1 = start_points[j+1]
    #                 d2 = linesegment_linesegment_dist2(i0,i1,j0,j1)
    #                 if d2 ≤ cutoff^2
    #                     kr = inv(ri+rj)
    #                     push!(nl,CylinderEdge(i,j,kr,100.0/kr))
    #                 end
    #             end
    #         end
    #     end
    # end
    # nl
end

"""
Get triangle-bead interaction list.
"""
function triangle_bead_neighborlist(cutoff, cutoff_ex, simboxsize, smeshes, x, beadcoordrange)::Vector{TriangleBeadEdge}
    nl = TriangleBeadEdge[]

    # Find a suitable box size, by adding to cutoff the maximum distance from centroid to triangle vertex.
    maxdist2_centroid_to_vertex = maximum(smeshes; init=0.0) do sm
        maximum(1:length(sm.triangles); init=0.0) do i
            ixt = sm.triangles.attr.cached_xcoordindices[i]
            vpos = map(ix -> SVector{3}(view(x, ix:ix+2)), ixt)
            # Centroid.
            pos = sum(vpos) / 3
            maximum(vpos) do vp
                diff = vp - pos
                dot(diff, diff)
            end
        end
    end
    cutoff_cl_inner = cutoff + cutoff_ex
    cutoff_cl_box = cutoff_cl_inner + sqrt(maxdist2_centroid_to_vertex)
    boxsize = max.(cutoff_cl_box * 2, simboxsize .+ cutoff_cl_box)
    box = CellListMap.Box(boxsize, cutoff_cl_box)

    # Find coordinates to be put in the cell list.
    allbeadpos = reinterpret(SVector{3,eltype(x)}, view(x, beadcoordrange))
    alltrianglepos = SVector{3,eltype(x)}[]
    alltriangleix = SVector{3,Int}[]
    for sm ∈ smeshes
        for i ∈ 1:length(sm.triangles)
            ixt = sm.triangles.attr.cached_xcoordindices[i]
            vpos = map(ix -> SVector{3}(view(x, ix:ix+2)), ixt)
            pos = sum(vpos) / 3
            push!(alltrianglepos, pos)
            push!(alltriangleix, ixt)
        end
    end

    # Build pair list from cell list.
    if !isempty(allbeadpos) && !isempty(alltrianglepos)
        # Excluding empty list because CellList has error on empty lists.
        cl = CellListMap.CellList(allbeadpos, alltrianglepos, box; autoswap=false)

        # Build pair list.
        CellListMap.map_pairwise_serial!(nl, box, cl; show_progress=false) do x,y,i,j,d2,thenl
            # TODO: filter by nearest distance wrt cutoff_cl_inner.
            push!(thenl, TriangleBeadEdge(alltriangleix[j], beadcoordrange[3*i-2]))
            thenl
        end
    end
    nl
end


"""
Check a vector of CylinderEdge is a correct neighbor list.
throws an error if the neighborlist is invalid
"""
function check_cylinder_neighborlist(
        x,
        excluded,
        radii,
        nl::Vector{CylinderEdge}
    )
    start_points = reinterpret(SVector{3,eltype(x)},x)
    numcylinders = length(start_points) - 1
    length(radii) == numcylinders || error("length(radii):$(length(radii)), numcylinders:$numcylinders")
    Graphs.nv(excluded) == numcylinders || error("Graphs.nv(excluded):$(Graphs.nv(excluded)), ")
    # first check if any neighbors exist that shouldn't
    for edge in nl
        i = edge.id1
        j = edge.id2
        if i == j
            error("cylinder $i interacts with itself")
        end
        if Graphs.has_edge(excluded, i, j)
            error("neighbor list has an exclude pair $i, $j")
        end
        ri = radii[i]
        rj = radii[j]
        if !(ri > 0)
            error("bad radius $ri in neighborlist on cylinder $i")
        end
        if !(rj > 0)
            error("bad radius $rj in neighborlist on cylinder $j")
        end
    end
    # next check that all neighbor that should exist do
    # build a Graph from the neighborlist
    nlgraph = Graphs.SimpleGraph(numcylinders)
    for edge in nl
        Graphs.add_edge!(nlgraph,edge.id1,edge.id2) || error("edge $edge couldn't be added")
    end
    for i in 1:numcylinders-1
        for j in i+1:numcylinders
            ri = radii[i]
            rj = radii[j]
            # check if i and j are ignored
            if ri > 0 && rj > 0
                if !Graphs.has_edge(excluded, i, j)
                    cutoff = ri + rj
                    i0 = start_points[i]
                    i1 = start_points[i+1]
                    j0 = start_points[j]
                    j1 = start_points[j+1]
                    d2 = linesegment_linesegment_dist2(i0,i1,j0,j1)
                    if d2 < cutoff^2
                        Graphs.has_edge(nlgraph,i,j) || error("neighborlist missing $i, $j")
                    end
                end
            end
        end
    end
end

"""
Add cylinder volume exclusion force and energy to `force_energy`.
Uses the closest approach point
x is the dof
"""
function cylindervolume_exclusion_closest!(force_energy::ForceEnergy, x, neighborlist)
    posvect = reinterpret(SVector{3,eltype(x)},x)
    for edge in neighborlist
        kr = edge.kr
        ke = edge.ke
        switchover_scale_unitless = 8 #TODO, make this constant a config option.
        switchover_scale = switchover_scale_unitless*kr^2 # units of 1/nm^2, 
        #load positions
        @inbounds P0, P1 = posvect[edge.id1], posvect[edge.id1+1]
        @inbounds Q0, Q1 = posvect[edge.id2], posvect[edge.id2+1]
        P = P1-P0
        Q = Q1-Q0
        P0mQ0 = P0 - Q0
        a = P ⋅ P
        b = P ⋅ Q
        c = Q ⋅ Q
        d = P ⋅ P0mQ0
        e = Q ⋅ P0mQ0
        f = P0mQ0 ⋅ P0mQ0
        Δ = a*c - b^2
        #assuming both segments are not zero length
        #critical points
        s0 = clamp(-d/a,0,1)
        s1 = clamp((b-d)/a,0,1)
        t0 = clamp(e/c,0,1)
        t1 = clamp((b+e)/c,0,1)
        sbar = clamp((b*e - c*d)/(Δ+eps(one(Δ))),0,1)
        tbar = clamp((a*e - b*d)/(Δ+eps(one(Δ))),0,1)
        r(s,t) = a*s^2 - 2b*s*t + c*t^2 + 2d*s - 2e*t
        mins = sbar
        mint = tbar
        minr = r(sbar,tbar)
        if  r(s0,0) < minr
            minr = r(s0,0)
            mins = s0
            mint = 0
        end
        if  r(s1,1) < minr
            minr = r(s1,1)
            mins = s1
            mint = 1
        end
        if  r(0,t0) < minr
            minr = r(0,t0)
            mins = 0
            mint = t0
        end
        if  r(1,t1) < minr
            minr = r(1,t1)
            mins = 1
            mint = t1
        end
        d2cl = max(0,f+minr)
        if d2cl < inv(kr)^2
            #return the energy and force on each point give s and t
            function u_f(s,t)
                local Pcl = P0 + s*P
                local Qcl = Q0 + t*Q
                local Rcl = Qcl - Pcl
                local distsq = Rcl ⋅ Rcl
                local dist = sqrt(distsq)
                local u = 1//2*max(0,1-dist*kr)^2
                local d_u_d_dist = -kr*max(0,1-dist*kr)
                local FP = Rcl/dist * d_u_d_dist
                (u, s*FP, -(1-t)*FP, -t*FP)
            end
            switchover = tanh(Δ/sqrt(a*c)*switchover_scale)
            #P0 is set as origin for now, subtract forces later to get final fp0
            ucl, fp1cl, fq0cl, fq1cl = u_f(mins,mint)
            us0, fp1s0, fq0s0, fq1s0 = u_f(s0,0)
            us1, fp1s1, fq0s1, fq1s1 = u_f(s1,1)
            ut0, fp1t0, fq0t0, fq1t0 = u_f(0,t0)
            ut1, fp1t1, fq0t1, fq1t1 = u_f(1,t1)
            uother = +(
                us0,
                us1,
                ut0,
                ut1,
            )
            fp1other = +(
                fp1s0,
                fp1s1,
                fp1t0,
                fp1t1,
            )
            fq0other = +(
                fq0s0,
                fq0s1,
                fq0t0,
                fq0t1,
            )
            fq1other = +(
                fq1s0,
                fq1s1,
                fq1t0,
                fq1t1,
            )
            u = switchover*ucl + 1//2*(1-switchover)*uother
            p = sqrt(a)
            q = sqrt(c)
            g = b/(p*q)
            uswitched = (ucl + -1//2*uother)
            fp1 = switchover*fp1cl + 1//2*(1-switchover)*fp1other
            d_switchover_dp1 = -switchover_scale*(1-switchover^2)*((q/p+b*g/a)*P - 2*g*Q)
            fp1 += d_switchover_dp1*uswitched

            fq0 = switchover*fq0cl + 1//2*(1-switchover)*fq0other
            fq1 = switchover*fq1cl + 1//2*(1-switchover)*fq1other
            d_switchover_dq0 = switchover_scale*(1-switchover^2)*((p/q+b*g/c)*Q - 2*g*P)
            d_switchover_dq1 = - d_switchover_dq0
            fq0 += d_switchover_dq0*uswitched
            fq1 += d_switchover_dq1*uswitched

            @inbounds add_bead_force!(force_energy, edge.id1, -ke*(fp1+fq0+fq1))
            @inbounds add_bead_force!(force_energy, edge.id1+1, ke*fp1)

            @inbounds add_bead_force!(force_energy, edge.id2, ke*fq0)
            @inbounds add_bead_force!(force_energy, edge.id2+1, ke*fq1)

            @inbounds add_energy!(force_energy, u*ke)
        end
    end
end


"""
Return the minimum cylinder cylinder distance
Uses the closest approach point
x is the dof
"""
function cylinder_cylinder_min_closest_dist(x,neighborlist)
    posvect = reinterpret(SVector{3,eltype(x)},x)
    d2min = minimum(neighborlist; init = typemax(eltype(x))) do edge
        @inbounds P0, P1 = posvect[edge.id1],posvect[edge.id1+1]
        @inbounds Q0, Q1 = posvect[edge.id2],posvect[edge.id2+1]
        @inline d2 = linesegment_linesegment_dist2(P0, P1, Q0, Q1)
        d2
    end
    √(d2min)
end


"""
Add internal filament forces and energy to `force_energy`.
x is the dof of a single filament
"""
function internal_filament_forces!(force_energy::ForceEnergy, x, filamentmechparams::FilamentMechParams, monomerspercylinder, minusmonomerspercylinder, plusmonomerspercylinder)
    @inbounds begin
        L0 = filamentmechparams.spacing*monomerspercylinder
        kd = filamentmechparams.klength/monomerspercylinder
        k∠ = filamentmechparams.kangle/monomerspercylinder
        kdminus= filamentmechparams.klength/minusmonomerspercylinder
        L0minus = filamentmechparams.spacing*minusmonomerspercylinder
        kdplus= filamentmechparams.klength/plusmonomerspercylinder
        L0plus = filamentmechparams.spacing*plusmonomerspercylinder
        mnum = length(x)÷3
        posvect = reinterpret(SVector{3,eltype(x)},x)
        idx_offset = (first(first(parentindices(x))) - 1)÷3
        #add initial length bond force and Energy
        pos = posvect[1]
        nextpos = posvect[2]
        r2 = nextpos - pos
        L2 = norm_fast(r2)
        ΔL2 = L0minus - L2
        invL2 = inv(L2)
        r̂2 = r2*invL2
        Ed = 1//2*kdminus*(ΔL2)^2
        F2d = kdminus*(ΔL2)*r̂2
        add_energy!(force_energy, Ed)
        add_bead_force!(force_energy, idx_offset+1, -F2d)
        add_bead_force!(force_energy, idx_offset+2, +F2d)
        @inbounds @fastmath for i in 2:(mnum-2)
            lastpos = posvect[i-1]
            pos = posvect[i]
            nextpos = posvect[i+1]
            r1 = lastpos-pos
            L1 = norm_fast(r1)
            invL1 = inv(L1)
            r̂1 = r1*invL1
            r2 = nextpos - pos
            L2 = norm_fast(r2)
            invL2 = inv(L2)
            r̂2 = r2*invL2
            cosθ = r̂1'*r̂2
            ΔL2 = L0 - L2
            Ed = 1//2*kd*(ΔL2)^2
            F2d = kd*(ΔL2)*r̂2
            E∠ = k∠*(cosθ+1)
            F1∠ = k∠*invL1*(r̂1*cosθ - r̂2)
            F2∠ = k∠*invL2*(r̂2*cosθ - r̂1)
            #Store forces and energies
            add_energy!(force_energy, Ed + E∠)
            add_bead_force!(force_energy, idx_offset+i-1, F1∠)
            add_bead_force!(force_energy, idx_offset+i, -(F2d + F2∠ + F1∠))
            add_bead_force!(force_energy, idx_offset+i+1, F2∠ + F2d)
        end
        if mnum ≥ 3
            #calc plus end forces
            lastpos = posvect[end-2]
            pos = posvect[end-1]
            nextpos = posvect[end]
            r1 = lastpos-pos
            L1 = norm_fast(r1)
            invL1 = inv(L1)
            r̂1 = r1*invL1
            r2 = nextpos - pos
            L2 = norm_fast(r2)
            invL2 = inv(L2)
            r̂2 = r2*invL2
            cosθ = r̂1'*r̂2
            ΔL2 = L0plus - L2
            Ed = 1//2*kdplus*(ΔL2)^2
            F2d = kdplus*(ΔL2)*r̂2
            E∠ = k∠*(cosθ+1)
            F1∠ = k∠*invL1*(r̂1*cosθ - r̂2)
            F2∠ = k∠*invL2*(r̂2*cosθ - r̂1)
            #Store forces and energies
            last_bead_idx = idx_offset + length(posvect)
            add_energy!(force_energy, Ed + E∠)
            add_bead_force!(force_energy, last_bead_idx-2, F1∠)
            add_bead_force!(force_energy, last_bead_idx-1, -(F2d + F2∠ + F1∠))
            add_bead_force!(force_energy, last_bead_idx, F2∠ + F2d)
        end
    end
end

"""
Add bond force and energy to `force_energy`
    x is the degrees of freedom
"""
function bond_forces!(
        force_energy::ForceEnergy,
        x,
        info::VectorBondInfo{N_DIRS};
        chunk=1,
        nthreads=1,
    ) where {N_DIRS}
    bnum = length(info.local_params)
    posvect = reinterpret(SVector{3,eltype(x)}, x)
    shared_params = info.shared_params
    bond = info.bond
    chunk > bnum && return
    for i in chunks(1:bnum; n=nthreads)[chunk]
        places = info.places[i]
        local_params = info.local_params[i]
        params = merge(shared_params, local_params)
        # get place positions and directions
        # hopefully the compiler can unroll this
        pos_dirs = @inline map(places, N_DIRS) do p::VectorPlaceInfo, n
            get_place_pos_dir(p, posvect, n)
        end
        # calculate the force
        @inline E, fs = bond_energy_force(bond, pos_dirs, params)
        add_energy!(force_energy, E)
        # project the torques and forces back to the inputs
        @inline foreach(places, fs) do p::VectorPlaceInfo, f
            store_place_force!(p, force_energy, f, posvect)
        end
    end
end

"""
Return a tuple of
    1. vector of floats
    2. vector of Dictionaries of VectorFilamentInfo
        indexed by filament type id, and filament id,
    3. vector of StaticHalfedgeMesh.
"""
function helper_vectorize_info(c::Context)
    all_positions= SVector{3,Float64}[]
    filinfo= map(c.chem_cylinders) do cylinders
        map(eachindex(cylinders.per_fil)) do fil_idx
            fil = LazyRow(cylinders.per_fil, fil_idx)
            startid= length(all_positions)+1
            positions= _get_nodepositions(cylinders, fil_idx)
            append!(all_positions,positions)
            endid= length(all_positions)
            VectorFilamentInfo(
                startid,
                endid,
                cylinders.numpercylinder,
                _get_nummonomersminusend(cylinders, fil_idx),
                _get_nummonomersplusend(cylinders, fil_idx),
                fil.mon_id_first,
                fil.mon_id_last,
            )
        end
    end
    filcoordrange = 1:3*length(all_positions)
    filcoordend = 3*length(all_positions)

    smeshes = map(c.membranes) do dm
        xoffset = length(all_positions) * 3
        append!(all_positions, dm.vertices.attr.coord)
        sm = StaticHalfedgeMesh(dm)
        cachecoordindices!(sm, xoffset)

        # Update pinning.
        updatevertexpinning!(dm, c.sharedtypedconfigs.mesh_boundary_pinning_mode)

        sm
    end
    vertexcoordrange = (filcoordend+1):(3*length(all_positions))

    (;
        x = collect(reinterpret(Float64,all_positions)),
        filinfo,
        filcoordrange,
        smeshes,
        vertexcoordrange,
    )
end

function helper_unvectorize_info!(c::Context, xmin::AbstractVector, forces::AbstractVector, filamentindexinfo)
    helper_unvectorize_filaments!(c, xmin, forces, filamentindexinfo)

    # Unvectorize membranes.
    for dm ∈ c.membranes
        for iv ∈ 1:length(dm.vertices)
            xi = dm.vertices.attr.cached_xcoordindex[iv]
            dm.vertices.attr.coord[iv] = SA[xmin[xi], xmin[xi+1], xmin[xi+2]]
        end
    end
end

"""
set the bond_info field in fc
"""
function helper_vectorize_bonds!(fc::ForceContext, c::Context)
    empty!(fc.bond_info)
    foreach(c.link_manager.link_data) do d
        for (bi, bond_config) in enumerate(d.bonds)
            bond = bond_config.bond
            N_DIRS = Val.(num_input_directions(bond))
            shared_params = bond_config.param
            no_collide = bond_config.no_collide
            local_params = typeof(bond_config.state)[]
            places = Tuple{map(bond_config.input) do pi
                vector_place_type(d.places[pi])
            end...}[]
            # fill local_params and places with enabled bonds
            for per_link_data in d.per_link
                # bond must be enabled
                # and none of the input places can be null 
                # to add the bond
                per_link_data.bond_enabled[bi] || continue
                any(bond_config.input) do pi
                    is_null(per_link_data.tags[pi])
                end && continue
                push!(local_params, per_link_data.bond_states[bi])
                push!(places, map(bond_config.input) do pi
                    vector_place(tag2place(c, per_link_data.tags[pi]), fc, c)
                end)
            end
            push!(fc.bond_info, VectorBondInfo{
                    N_DIRS,
                    typeof(bond),
                    typeof(places),
                    typeof(shared_params),
                    typeof(local_params),
                }(
                    bond,
                    places,
                    shared_params,
                    local_params,
                    no_collide,
                )
            )
        end
    end
end

vector_place_type(::FilaTipIdx) = VectorMonomerInfo
function vector_place(p::FilaTipIdx, fc::ForceContext, c::Context)::VectorMonomerInfo
    filinfo::VectorFilamentInfo = fc.filamentindexinfo[p.fila_idx.typeid][p.fila_idx.idx]
    # Create monomer info for the tip
    frac = p.is_minus_end ? 0.0 : 1.0
    startid = p.is_minus_end ? filinfo.startid : filinfo.endid-Int32(1)
    VectorMonomerInfo(startid, frac)
end

vector_place_type(::FilaMonoIdx) = VectorMonomerInfo
function vector_place(p::FilaMonoIdx, fc::ForceContext, c::Context)::VectorMonomerInfo
    # find startid
    filinfo::VectorFilamentInfo = fc.filamentindexinfo[p.fila_idx.typeid][p.fila_idx.idx]
    # get cylinder idx and frac for mech cylinders
    cylinderidx, frac = get_fil_mech_cyl_idx_frac(
        p.mid,
        Int(filinfo.mon_id_first),
        Int(filinfo.mon_id_last),
        Int(filinfo.monomerspercylinder),
    )
    startid= filinfo.startid + cylinderidx - 1
    VectorMonomerInfo(startid,frac)
end

vector_place_type(::MembVertIdx) = VectorVertexInfo
function vector_place(p::MembVertIdx, fc::ForceContext, c::Context)::VectorVertexInfo
    smesh::StaticHalfedgeMesh = fc.smeshes[Int(p.memb_idx)]
    vertex_index_in_mesh = Int(p.vert_idx)
    start_vertex_offset = (smesh.vertices.attr.cached_xcoordindex[1]-1)÷3
    VectorVertexInfo(vertex_index_in_mesh + start_vertex_offset)
end

"""
store the xmin vector of floats as bead positions in c according to filamentindexinfo
also store the filament end load forces, from forces

Also fill in holes in c.chem_cylinders

Also remove unreferenced monomer tags.
"""
function helper_unvectorize_filaments!(c::Context, xmin, forces, filamentindexinfo)
    # fill in holes in c.chem_cylinders
    # this means the simplex cell list needs to be refreshed as well. 
    num_filament_types = length(filamentindexinfo)
    for ftid in 1:num_filament_types
        cylinders = c.chem_cylinders[ftid]
        fill_holes!(cylinders)
    end
    for ftid in 1:num_filament_types
        cylinders = c.chem_cylinders[ftid]
        for (fil_idx, info) in pairs(filamentindexinfo[ftid])
            fil_data = LazyRow(cylinders.per_fil, fil_idx)
            startid= info.startid
            endid= info.endid
            pos= reinterpret(SVector{3,eltype(xmin)},xmin[3startid-2:3endid])
            set_nodepositions!(
                fil_data.chembeadpositions,
                pos,
                _mon_id_info(cylinders, fil_idx)...
            )
            forcevect= reinterpret(SVector{3,eltype(forces)},forces[3startid-2:3endid])
            minusendforce = forcevect[begin]
            minusenddir = normalize_fast(pos[begin]-pos[begin+1])
            minusendloadforce = max(-minusendforce ⋅ minusenddir,0)
            plusendforce = forcevect[end]
            plusenddir = normalize_fast(pos[end]-pos[end-1])
            plusendloadforce = max(-plusendforce ⋅ plusenddir,0)
            fil_data.endloadforces = minusendloadforce=>plusendloadforce
            fil_data.minusend_num_notminimized = 0
            fil_data.plusend_num_notminimized = 0
        end
    end
    _free_unreferenced_tags!(_tag_manager(c.link_manager, FilaMonoIdx()))
    nothing
end
