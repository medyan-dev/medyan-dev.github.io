using FixedPointNumbers
using ElasticArrays

"""
Link_2mon Data, there is one instance of this per link_2mon type

$(TYPEDFIELDS)
"""
struct Link2MonData{STATETYPE <: Link2MonState, MECHPARAMS_TYPE}
    "type id"
    id::Int

    "parameters"
    params::Link2MonParams{STATETYPE,MECHPARAMS_TYPE}

    "indexed by lidx"
    states::Vector{STATETYPE}

    "Next link_2mon id"
    next_lid::Ref{Int64}

    "map from link_2mon id to index (lidx)
    link_2mon indexs can change whenever a link_2mon is added or removed, but id's are stable"
    lid_to_lidx::Dict{Int64,Int32}

    "map from link_2mon index (lidx) to lid"
    lidx_to_lid::Vector{Int64}

    "minusend name => plusend name, indexed by lidx"
    lidx_to_endnames::Vector{Pair{MonomerName,MonomerName}}

    "track sitecounts, if false the following fields are empty"
    track_sitecounts::Bool

    "True if the cached info is valid"
    cache_valid::Ref{Bool}

    "cached info, indexed by lidx
    gives (cid, clidx)"
    lidx_to_cid_clidx::Vector{Tuple{Int32,Int32}}

    "cached info indexed by compartment id, clidx index.
    to give the lidx of the link_2mon"
    cid_clidx_to_lidx::Vector{Vector{Int32}}

    "cached info indexed by [cid], [lsid, clidx].
    Used to pick a random link_2mon site in a compartment"
    compartment_sitecounts::Vector{ElasticMatrix{Q31f32,Vector{Q31f32}}}
end
