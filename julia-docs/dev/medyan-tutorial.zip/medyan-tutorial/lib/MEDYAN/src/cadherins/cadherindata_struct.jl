using FixedPointNumbers
using ElasticArrays

"""
struct CadherinData for per cadherin type
    $(TYPEDFIELDS)
"""
struct CadherinData{STATETYPE <: CadherinState, MECHPARAMS_TYPE}
    "type id"
    id::Int

    "parameters"
    params::CadherinParams{STATETYPE,MECHPARAMS_TYPE}

    "indexed by cadidx"
    states::Vector{STATETYPE}

    "map from pair of end name to cadherin index (cadidx)
    cadherin indexs can change whenever a cadherin is added or removed"
    endnames_to_cadidx::Dict{Pair{VertexName,MonomerName},Int32}

    "minusend name => plusend name, indexed by cadidx"
    cadidx_to_endnames::Vector{Pair{VertexName,MonomerName}}

    "map from monomer name to cadherin index (cadidx)"
    monname_to_cadidx::Dict{MonomerName, Int32}

    "the indexs of cadherins in each compartment"
    compartment_cadcounts::Vector{Vector{Int32}}

    "track sitecounts, if false the following fields are empty"
    track_sitecounts::Bool

    "cached info indexed by [cid], [cadsid].
    Used to pick a random cadherin site in a compartment"
    compartment_sitecounts::Vector{ElasticMatrix{Q31f32,Vector{Q31f32}}}

end
