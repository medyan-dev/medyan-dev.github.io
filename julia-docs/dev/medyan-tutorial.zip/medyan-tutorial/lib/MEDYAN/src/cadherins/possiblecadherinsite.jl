using AutoHashEquals
using LinearAlgebra
using StaticArrays
import CellListMap
import JET

"""
Possible Cadherin Site: one end fixed on vertex, other end on filament. For fend within max to min range are linkable. 
If they have matching state with `vertexstate` and `monomerstate`.

$(TYPEDFIELDS)

"""
const VertexState = UInt8

struct PossibleCadherinSiteRange
    meshid::Int
    ftid::Int
    fskip::Int
    vertexstate::VertexState
    monomerstate::MonomerState
    minrange::Float64 
    maxrange::Float64
end


max_possiblecadherinsitecount(site::PossibleCadherinSiteRange)::Float64 = 1.0

function in_possible_cadherin_range(site::PossibleCadherinSiteRange, v_pos,m_pos)::Bool
    distance = norm_fast(v_pos - m_pos)
    return if distance < site.minrange || distance > site.maxrange
        false
    else
        true
    end
end

getmeshidftid(site::PossibleCadherinSiteRange) = (site.meshid, site.ftid)

getmidsteps(site::PossibleCadherinSiteRange) = (site.fskip)

cutoff_distance(site::PossibleCadherinSiteRange) = site.maxrange

function reset_possiblecadherinsite_counts!(c::Context, m::PossibleCadherinSiteManager)::Nothing
    site = m.site
    system = m.system
    meshid = m.meshid
    ftid = m.ftid
    fstep = m.fstep
    fxsid = site.fxsid
    membrane = c.membranes[meshid]
    reset_cached_vertex_info!(c, membrane, meshid, m.vpoints, m.vids, m.meshids, m.vcids)
    cylinders = c.chem_cylinders[ftid]
    # set vectors of info per linkable monomer
    reset_cached_monomer_info!(c, cylinders, fstep, m.fpoints, m.fvecs, m.mids, m.fids, m.cids)
    # update system
    resize!(system.xpositions, length(m.vpoints))
    system.xpositions .= m.vpoints
    resize!(system.ypositions, length(m.fpoints))
    system.ypositions .= m.fpoints
    map_pairwise!(system) do x,y,i,j,d2,out
        pos1 = m.vpoints[i]
        pos2 = m.fpoints[j]
        one_two = in_possible_cadherin_range(site.site,pos1,pos2)
        if one_two
            push!(out.pairlists[m.vcids[i]], (i%Int32)=>(j%Int32))
        end
        return out
    end
    # update chemistry engine
    maxsitecount = max_possiblecadherinsitecount(site.site)
    for vcid in 1:length(c.grid)
        local totalmaxsitecount = maxsitecount*length(system.output.pairlists[vcid])
        setfixedspeciescount!(c.chemistryengine, fxsid, vcid, totalmaxsitecount)
    end
    return
end

"""
Reset cached vertex info
"""
function reset_cached_vertex_info!(c::Context, membrane::DynamicHalfedgeMesh, meshid::Int, vpoints, vids, meshids, vcids)
    empty!(vcids)
    empty!(meshids)
    empty!(vids)
    empty!(vpoints)
    for vidx in 1:length(membrane.vertices.attr.vertexstate)
        #only vertexstate = 2 can be possible linked 
        if membrane.vertices.attr.vertexstate[vidx] == UInt8(2)
            vpos = membrane.vertices.attr.coord[vidx]
            vid = membrane.vertices.attr.id[vidx]
            vertexname = VertexName(meshid, vid)# meshid is equal to membraneindex
            vcid = get_compartment_id_byvertexname(c, vertexname)
            push!(vpoints, vpos)
            push!(vids, vid)
            push!(meshids, meshid)
            push!(vcids, vcid)
        end
    end
end


"""
Return pair of vertex name and monomername given a pair of indexes
"""
function index2vert_mononames(m::PossibleCadherinSiteManager, indexes)::Tuple{VertexName,MonomerName}
    a,b = indexes
    a_name = VertexName(m.meshid, m.vids[a])
    b_name = MonomerName(m.ftid, m.fids[b], m.mids[b])
    a_name, b_name
end


"""
Return a tuple of (VertexName, MonomerName) of a random possible cadherin site, or return nothing if rejected.
weighted by counts, using the default RNG.
"""
function pickrandompossiblecadherinsite(c::Context, m::AbstractPossibleCadherinSiteManager, cid::Integer)::Union{Tuple{VertexName,MonomerName},Nothing}
    site = m.site
    pairlist = m.system.output.pairlists[cid]
    isempty(pairlist) && return
    vertex_name, monomer_name = index2vert_mononames(m, rand(pairlist))
    maxsitecount = max_possiblecadherinsitecount(site.site)
    sitecount = get_possiblecadherinsitecount(c, site.site, vertex_name, monomer_name)
    @argcheck sitecount ≤ maxsitecount + eps(maxsitecount)
    u = maxsitecount*rand()
    if u < sitecount
        return (vertex_name, monomer_name)
    else
        return
    end
end

"""
Return the possible cadherin site count between a vertex and a monomer in a context that are in possible cadherin range
if they exist and are minimized,
otherwise return 0
"""
function get_possiblecadherinsitecount(c::Context, site, vertexname::VertexName, monomername::MonomerName)::Q31f32
    site_meshid_ftid = getmeshidftid(site)
    site_midstep = getmidsteps(site)
    (vertexname.membraneindex,monomername.ftid) == site_meshid_ftid || return 0
    mod(monomername.mid, site_midstep) == 0 || return 0
    # now check that these monomers were not deleted during this chemistry cycle.
    mon_exists(c, monomername) || return 0
    # now check that these monomers were minimized before this chemistry cycle.
    mon_minimized(c, monomername) || return 0
    # get the vertex state and monomer state
    vertexstate = vertex_state(c, vertexname)
    monomerstate = fil_mon_states(c, monomername.ftid, monomername.fid)[monomername.mid]
    # get the linkable site count
    possiblecadherinsitecount(site,vertexstate,monomerstate)
end

function possiblecadherinsitecount(site::PossibleCadherinSiteRange,vertexstate,monomerstate)::Float64
    if vertexstate == site.vertexstate && monomerstate == site.monomerstate
        return 1.0
    else
        return 0.0
    end
end
