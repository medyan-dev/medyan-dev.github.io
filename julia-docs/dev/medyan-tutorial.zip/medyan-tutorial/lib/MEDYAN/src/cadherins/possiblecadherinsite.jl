using LinearAlgebra
using StaticArrays
import CellListMap

"""
Possible Cadherin Site: one end fixed on vertex, other end on filament. For fend within max to min range are linkable. 
If they have matching state with `vertexstate` and `monomerstate`.

$(TYPEDFIELDS)

"""
const VertexState = UInt8

struct PossibleCadherinSiteRange
    meshid::Int
    ftid::Int
    fskip::Int
    vertexstate::VertexState
    monomerstate::MonomerState
    minrange::Float64 
    maxrange::Float64
end


max_possiblecadherinsitecount(site::PossibleCadherinSiteRange)::Float64 = 1.0

function in_possible_cadherin_range(site::PossibleCadherinSiteRange, v_pos,m_pos)::Bool
    distance = norm_fast(v_pos - m_pos)
    return if distance < site.minrange || distance > site.maxrange
        false
    else
        true
    end
end

getmeshidftid(site::PossibleCadherinSiteRange) = (site.meshid, site.ftid)

getmidsteps(site::PossibleCadherinSiteRange) = (site.fskip)

cutoff_distance(site::PossibleCadherinSiteRange) = site.maxrange

function reset_possiblecadherinsite_counts!(c::Context, m::PossibleCadherinSiteManager)::Nothing
    site = m.site
    system = m.system
    meshid = m.meshid
    ftid = m.ftid
    fstep = m.fstep
    fxsid = site.fxsid
    membrane = c.membranes[meshid]
    reset_cached_vertex_info!(c, membrane, meshid, m.vpoints, m.vidxs, m.meshids, m.vcids)
    cylinders = c.chem_cylinders[ftid]
    # set vectors of info per linkable monomer
    reset_cached_monomer_info!(c, cylinders, fstep, m.fpoints, m.fvecs, m.mids, m.ftags, m.cids)
    # update system
    resize!(system.xpositions, length(m.vpoints))
    system.xpositions .= m.vpoints
    resize!(system.ypositions, length(m.fpoints))
    system.ypositions .= m.fpoints
    map_pairwise!(system) do x,y,i,j,d2,out
        pos1 = m.vpoints[i]
        pos2 = m.fpoints[j]
        one_two = in_possible_cadherin_range(site.site,pos1,pos2)
        if one_two
            push!(out.pairlists[m.vcids[i]], (i%Int32)=>(j%Int32))
        end
        return out
    end
    # update chemistry engine
    maxsitecount = max_possiblecadherinsitecount(site.site)
    for vcid in 1:length(c.grid)
        local totalmaxsitecount = maxsitecount*length(system.output.pairlists[vcid])
        setfixedspeciescount!(c.chemistryengine, fxsid, vcid, totalmaxsitecount)
    end
    return
end

"""
Reset cached vertex info
"""
function reset_cached_vertex_info!(c::Context, membrane::DynamicHalfedgeMesh, meshid::Int, vpoints, vidxs, meshids, vcids)
    empty!(vcids)
    empty!(meshids)
    empty!(vidxs)
    empty!(vpoints)
    for vidx in 1:length(membrane.vertices.attr.vertexstate)
        #only vertexstate = 2 can be possible linked 
        if membrane.vertices.attr.vertexstate[vidx] == UInt8(2)
            vpos = membrane.vertices.attr.coord[vidx]
            vcid = membrane.vertices.attr.cid[vidx]
            push!(vpoints, vpos)
            push!(vidxs, vidx)
            push!(meshids, meshid)
            push!(vcids, vcid)
        end
    end
end


"""
Return pair of vertex place and monomer place given a pair of indexes
"""
function index2vert_mononames(c::Context, m::PossibleCadherinSiteManager, indexes)::Tuple{MembVertIdx, FilaMonoIdx}
    a,b = indexes
    a_name = MembVertIdx(m.meshid, m.vidxs[a])
    b_name = if tag_exists(c, m.ftags[b])
        FilaMonoIdx(c, FilaIdx(c, m.ftags[b]), m.mids[b])
    else
        FilaMonoIdx()
    end
    a_name, b_name
end


"""
Return a tuple of (MembVertIdx, FilaMonoIdx) of a random possible cadherin site, or return nothing if rejected.
weighted by counts, using the default RNG.
"""
function pickrandompossiblecadherinsite(c::Context, m::AbstractPossibleCadherinSiteManager, cid::Integer)::Union{Tuple{MembVertIdx, FilaMonoIdx}, Nothing}
    site = m.site
    pairlist = m.system.output.pairlists[cid]
    isempty(pairlist) && return
    vertex_place, monomer_place = index2vert_mononames(c, m, rand(pairlist))
    maxsitecount = max_possiblecadherinsitecount(site.site)
    sitecount = get_possiblecadherinsitecount(c, site.site, vertex_place, monomer_place)
    @argcheck sitecount ≤ maxsitecount + eps(maxsitecount)
    u = maxsitecount*rand()
    if u < sitecount
        return (vertex_place, monomer_place)
    else
        return
    end
end
function pickrandompossiblecadherinsite(c::Context,cid,pcadsid)::Union{Tuple{MembVertIdx, FilaMonoIdx}, Nothing}
    helper_warn_chem_cache_invalid!(c)
    requireall(c.validflags, VFS_DEP_VERTEX_COORD)
    pickrandompossiblecadherinsite(c::Context, c.possiblecadherinsite_managers[pcadsid], cid)
end

"""
Return the possible cadherin site count between a vertex and a monomer in a context that are in possible cadherin range
if they exist and are minimized,
otherwise return 0
"""
function get_possiblecadherinsitecount(c::Context, site, vertex_place::MembVertIdx, monomer_place::FilaMonoIdx)::Q31f32
    site_meshid_ftid = getmeshidftid(site)
    site_midstep = getmidsteps(site)
    (vertex_place.memb_idx, monomer_place.fila_idx.typeid) == site_meshid_ftid || return 0
    mod(monomer_place.mid, site_midstep) == 0 || return 0
    # now check that these monomers were not deleted during this chemistry cycle.
    place_exists(c, vertex_place) || return 0
    place_exists(c, monomer_place) || return 0
    # now check that these monomers were minimized before this chemistry cycle.
    is_minimized(c, monomer_place) || return 0
    # get the vertex state and monomer state
    vertexstate = get_chem_state(c, vertex_place).vertex_state
    monomerstate = get_chem_state(c, monomer_place).monomer_state
    # get the linkable site count
    possiblecadherinsitecount(site,vertexstate,monomerstate)
end

function possiblecadherinsitecount(site::PossibleCadherinSiteRange,vertexstate,monomerstate)::Float64
    if vertexstate == site.vertexstate && monomerstate == site.monomerstate
        return 1.0
    else
        return 0.0
    end
end
