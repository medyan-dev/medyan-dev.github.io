using FixedPointNumbers
using ElasticArrays
using StaticArrays
using LinearAlgebra


function CadherinData(id, params, num_compartments, num_cadherin_sites)
    
        CadherinData{typeof(params.defaultstate),typeof(params.mechparams)}(
            id,
            params,
            [], #states
            Dict(), #endnames_to_cadidx
            [], #cadidx_to_endnames
            Dict(),# monname_to_cadidx
            [[] for i in 1:num_compartments],
            true,   
            [ElasticArray{Q31f32}(undef, num_cadherin_sites, 0) for i in 1:num_compartments], #compartment_sitecounts
        ) 
end

"""
Return the number of cadherins
"""
function num_cadherins(cadherindata::CadherinData)
    length(cadherindata.states)
end

function get_state(cadherindata::CadherinData,endnames::Pair{VertexName,MonomerName})
    cadidx = cadherindata.endnames_to_cadidx[endnames]
    cadherindata.states[cadidx]
end

"""
Change the monomer name of a cadherin.
Doesn't update site counts.
"""
function change_monomer_name!(cadherindata::CadherinData, old_name::MonomerName, new_name::MonomerName)
    @argcheck new_name ∉ keys(cadherindata.monname_to_cadidx)
    #find vertex name
    cadidx = cadherindata.monname_to_cadidx[old_name]
    old_endnames = cadherindata.cadidx_to_endnames[cadidx]
    new_endnames = old_endnames[1] => new_name
    delete!(cadherindata.endnames_to_cadidx, old_endnames)
    cadherindata.endnames_to_cadidx[new_endnames] = cadidx
    delete!(cadherindata.monname_to_cadidx, old_name)
    cadherindata.monname_to_cadidx[new_name] = cadidx
    cadherindata.cadidx_to_endnames[cadidx] = new_endnames
    nothing
end

"""
add a cadherin. {VertexName, MonomerName}.
"""
function newcadherin!(cadherindata::CadherinData,c::Context,endnames::Pair{VertexName,MonomerName},cadherinstate::CadherinState)
    endnames in keys(cadherindata.endnames_to_cadidx) && error("cadherin already exists")
    endnames[2] in keys(cadherindata.monname_to_cadidx) && error("monomer already occupied")
    push!(cadherindata.states,cadherinstate)
    push!(cadherindata.cadidx_to_endnames,endnames)
    cadidx = length(cadherindata.states)
    cadherindata.endnames_to_cadidx[endnames] = cadidx
    cadherindata.monname_to_cadidx[endnames[2]] = cadidx
    if cadherindata.track_sitecounts && checkall(c.validflags, VFS_SEGMENTS ∪ VFS_DEP_VERTEX_COORD)
        cidv = get_compartment_id_byvertexname(c,endnames[1])
        push!(cadherindata.compartment_cadcounts[cidv],cadidx)
        cadnum = length(cadherindata.compartment_cadcounts[cidv]) 
        sitecountscid_cadherin = cadherindata.compartment_sitecounts[cidv]
        ElasticArrays.resize_lastdim!(sitecountscid_cadherin, cadnum)
        sitecountscid_cadherin[:,end] .= 0
        resetcadherin_sitecounts!(cadherindata,c,endnames)
    end
    return
end

"""
Reset cached data, based on `c`.
reset c.chemistryengine based on the new site counts
"""
function resetcadherins!(cadherindata::CadherinData,c::Context)
    if cadherindata.track_sitecounts
        # go through all cadherins and set cadherindata
        empty!.(cadherindata.compartment_cadcounts)
        for cadidx in 1:length(cadherindata.states)
            endnames = cadherindata.cadidx_to_endnames[cadidx]
            cidv = get_compartment_id_byvertexname(c, endnames[1])
            push!(cadherindata.compartment_cadcounts[cidv], cadidx)
        end
        for cid in 1:length(cadherindata.compartment_sitecounts)
            # reset cadherindata.compartment_sitecounts and chemistryengine
            sitecountscid_cadherin = cadherindata.compartment_sitecounts[cid]
            cadnum = length(cadherindata.compartment_cadcounts[cid])#number of cadherins in single compartment
            ElasticArrays.resize_lastdim!(sitecountscid_cadherin,cadnum)
            cadidxs = cadherindata.compartment_cadcounts[cid]
            endnames = cadherindata.cadidx_to_endnames[cadidxs]
            states = cadherindata.states[cadidxs]
            cadherinmechparams = cadherindata.params.mechparams
            state_vertex = map(namepair->vertex_state(c, namepair.first), endnames)
            statetriplets_monomer = map(namepair->mon_3states(c, namepair.second), endnames)
            membranes = map(namepair->c.membranes[namepair.first.membraneindex],endnames)
            for membrane in membranes
                vindxs = map(namepair->membrane.metaattr.id2index_vertex[namepair.first.vid], endnames)
                positions_vertex = map(membrane->map(vindx->membrane.vertices.attr.coord[vindx],vindxs),membranes)
                positions_plusvectors_monomer = map(namepair->mon_position_plusvector(c, namepair.second),endnames)
                foreach(c.cadherinsites[cadherindata.id]) do cadherinsite
                    totalcount = zero(Q31f32)
                    for cadidx in 1:cadnum
                        s = Q31f32(cadherinsitecount(
                        cadherinsite.site,states[cadidx],cadherinmechparams,
                        endnames[cadidx][1].vid, endnames[cadidx][2].ftid,
                        state_vertex[cadidx], statetriplets_monomer[cadidx],
                        positions_vertex[cadidx],
                        positions_plusvectors_monomer[cadidx][1],#position
                        positions_plusvectors_monomer[cadidx][2],#plusvector
                        ))
                        sitecountscid_cadherin[cadherinsite.id, cadidx] = s
                        totalcount += s
                    end
                    setfixedspeciescount!(c.chemistryengine,cadherinsite.fxsid,cid,totalcount)
                end
            end
        end
    end
    return
end

function removecadherin!(cadherindata::CadherinData,c::Context,endnames::Pair{VertexName,MonomerName})
    endnames in keys(cadherindata.endnames_to_cadidx) || error("cadherin doesn't exists")
    cadidx = cadherindata.endnames_to_cadidx[endnames]# target waiting to be removed
    if cadherindata.track_sitecounts && checkall(c.validflags, VFS_SEGMENTS ∪ VFS_DEP_VERTEX_COORD)
        cidv = get_compartment_id_byvertexname(c,endnames[1])
        cadidxs = cadherindata.compartment_cadcounts[cidv]
        cadpos = findfirst(isequal(cadidx), cadherindata.compartment_cadcounts[cidv])#the position of target idx in the compartment
        lastcadidxpos = length(cadidxs)
        lastcadidx = cadherindata.compartment_cadcounts[cidv][lastcadidxpos]
        cadidxs[cadpos] = lastcadidx
        sitecountscid_cadherin = cadherindata.compartment_sitecounts[cidv]
        foreach(c.cadherinsites[cadherindata.id]) do cadherinsite
            removeds = sitecountscid_cadherin[cadherinsite.id, cadpos]
            if !iszero(removeds)
                addfixedspeciescount!(c.chemistryengine,cadherinsite.fxsid,cidv,-removeds)
            end
            sitecountscid_cadherin[cadherinsite.id, cadpos] = sitecountscid_cadherin[cadherinsite.id, lastcadidxpos]
        end
        ElasticArrays.resize_lastdim!(sitecountscid_cadherin,lastcadidxpos-1)
        pop!(cadherindata.compartment_cadcounts[cidv])
        # Reset compartment_cadcount
        endnames_listend = cadherindata.cadidx_to_endnames[end]      
        cidv_listend = get_compartment_id_byvertexname(c,endnames_listend[1])
        if !isempty(cadherindata.compartment_cadcounts[cidv_listend])
            cadidx_max = maximum(cadherindata.compartment_cadcounts[cidv_listend])
            cadidxmax_pos = findfirst(isequal(cadidx_max), cadherindata.compartment_cadcounts[cidv_listend])
            cadherindata.compartment_cadcounts[cidv_listend][cadidxmax_pos] = cadidx
        end
    end

    lastendnames = cadherindata.cadidx_to_endnames[end]

    cadherindata.states[cadidx] = cadherindata.states[end]
    pop!(cadherindata.states)

    cadherindata.endnames_to_cadidx[lastendnames] = cadidx
    delete!(cadherindata.endnames_to_cadidx,endnames)

    cadherindata.cadidx_to_endnames[cadidx] = lastendnames
    pop!(cadherindata.cadidx_to_endnames)

    cadherindata.monname_to_cadidx[lastendnames[2]] = cadidx
    delete!(cadherindata.monname_to_cadidx, endnames[2])
    return
end

"""
remove all cadherins.
"""
function emptycadherins!(cadherindata::CadherinData)
    empty!(cadherindata.states)
    empty!(cadherindata.endnames_to_cadidx)
    empty!(cadherindata.cadidx_to_endnames)
    empty!(cadherindata.monname_to_cadidx)
    foreach(empty!,cadherindata.compartment_cadcounts)
    foreach(x->ElasticArrays.resize_lastdim!(x,0),cadherindata.compartment_sitecounts)
end

"""
reset c.chemistryengine based on the new site counts
"""
function setcadherinstate!(cadherindata::CadherinData,c::Context,endnames::Pair{VertexName,MonomerName},cadherinstate::CadherinState)
    cadidx = cadherindata.endnames_to_cadidx[endnames]
    cadherindata.states[cadidx] = cadherinstate
    if checkall(c.validflags, VFS_SEGMENTS ∪ VFS_DEP_VERTEX_COORD)
        resetcadherin_sitecounts!(cadherindata,c,endnames)
    end
    nothing
end

"""
Return a tuple of (cadherin id, vertex end, monomer end) of a random cadherin site, or return nothing if rejected
weighted by counts, using the default RNG
"""
function pickrandomcadherinsite(cadherindata::CadherinData, totalsites, cidv, cadsid)::Union{Tuple{Int64,VertexName,MonomerName},Nothing}
    @assert cadherindata.track_sitecounts#cached info?
    if iszero(totalsites)
        return
    end
    sitecountscid_cadherin = cadherindata.compartment_sitecounts[cidv]
    sitecounts = @view(sitecountscid_cadherin[cadsid,:])
    u::Q31f32= Q31f32(totalsites*rand())
    for cadidx_cidv in 1:length(sitecounts)
        u -= sitecounts[cadidx_cidv]
        if u ≤ 0
            cadidx = cadherindata.compartment_cadcounts[cidv][cadidx_cidv]
            endnames = cadherindata.cadidx_to_endnames[cadidx]
            return (cadidx, endnames...)
        end
    end
    return
end

"""
reset c.chemistryengine based on the new site counts used to update linker if monomer states change.
"""
function resetcadherin_sitecounts!(cadherindata::CadherinData,c::Context,endnames::Pair{VertexName,MonomerName})
    if cadherindata.track_sitecounts
        cadidx = cadherindata.endnames_to_cadidx[endnames]
        cidv = get_compartment_id_byvertexname(c,endnames[1])
        cadpos = findfirst(isequal(cadidx), cadherindata.compartment_cadcounts[cidv])
        sitecountscid_cadherin = cadherindata.compartment_sitecounts[cidv]
        states = cadherindata.states[cadidx]
        cadherinmechparams = cadherindata.params.mechparams
        state_vertex = vertex_state(c, endnames[1])
        statetriplets_monomer = mon_3states(c, endnames[2])
        m = c.membranes[endnames[1].membraneindex]
        vindx = m.metaattr.id2index_vertex[endnames[1].vid]
        position_vertex = m.vertices.attr.coord[vindx]
        position_plusvector_monomer =  mon_position_plusvector(c, endnames[2])
        foreach(c.cadherinsites[cadherindata.id]) do cadherinsite
            olds = sitecountscid_cadherin[cadherinsite.id, cadpos]
            news = Q31f32(cadherinsitecount(
                cadherinsite.site,states,cadherinmechparams,
                endnames[1].vid, endnames[2].ftid,
                state_vertex, statetriplets_monomer,
                position_vertex,
                position_plusvector_monomer[1],#position
                position_plusvector_monomer[2],#plusvector
            ))
            sitecountscid_cadherin[cadherinsite.id, cadpos] = news
            Δs = news-olds
            if !iszero(Δs)
                addfixedspeciescount!(c.chemistryengine,cadherinsite.fxsid,cidv,Δs)
            end
        end    
    end
    return
end


"""
Check if two cadherindatas are statistically equal, the internal cadherin ids may be different
"""
function statistically_equal(a::CadherinData,b::CadherinData)::Bool
    assert_invariants(a)
    assert_invariants(b)
    a.id == b.id || return false
    a.params == b.params || return false
    keys(a.endnames_to_cadidx) == keys(b.endnames_to_cadidx) || return false
    #length(a.compartment_sitecounts) == length(b.compartment_sitecounts) || return false
    #a.track_sitecounts == b.track_sitecounts || return false
    for cadidx in 1:length(a.states)
        endnames = a.cadidx_to_endnames[cadidx]
        bcadidx = b.endnames_to_cadidx[endnames]
        a.states[cadidx] == b.states[bcadidx] || return false
    end
    return true
end

"""
Assert all invariants on a cadherindata
"""
function assert_invariants(cad::CadherinData)
    @assert cad.id > 0
    n = length(cad.states)
    @assert n == length(keys(cad.endnames_to_cadidx))
    @assert n == length(cad.cadidx_to_endnames)
    @assert n == length(cad.monname_to_cadidx)
    for (cadidx, endnames) in enumerate(cad.cadidx_to_endnames)
        @assert cad.endnames_to_cadidx[endnames] == cadidx
        @assert cad.monname_to_cadidx[endnames[2]] == cadidx
    end
end

struct CadherinSiteCount end

"""
$(TYPEDFIELDS)
"""
Base.@kwdef struct CadherinSiteSlipBond#E calculation is different
    "The charicteristic force magnitude. Units of pN"
    f0::Float64

    "Unbinding rate at zero force. Units of 1/s"
    k0::Float64
end

function cadherinsitecount(
    site::CadherinSiteSlipBond,
    cadherinstate, mechparams,
    vid, ftid,
    vertexstate, monomerstates,
    v_pos, m_pos, m_plusv
)
    if (cadherinstate.is_minimized)
        E, mf, pf = cadherin_force(cadherinstate.mechstate, mechparams, m_pos, p_pos, f_plusv)
        site.k0 * exp(max(norm_fast(mf), norm_fast(pf)) * inv(site.f0))
    else
        site.k0
    end
end

"""
$(TYPEDFIELDS)

Required mechstate feilds:
    `L0::Float64` - equilibrium length

"""
Base.@kwdef struct DistanceRestraintMechParams_Cadherin
    "spring constant"
    k::Float64
end

function cadherin_force(mechstate,mechparams::DistanceRestraintMechParams_Cadherin,verr_sim,monr_sim)
    r = verr_sim - monr_sim
    L = norm_fast(r)
    ΔL = L-mechstate.L0
    E = 1//2*mechparams.k*ΔL^2
    verf_sim = -mechparams.k*ΔL*r/L
    monf_sim = -verf_sim
    E, verf_sim, monf_sim, zero(verf_sim), zero(monf_sim)
end

