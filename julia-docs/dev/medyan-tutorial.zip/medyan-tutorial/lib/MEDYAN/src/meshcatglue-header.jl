"""
Just functions with no methods for
Glue functions for visualizing MEDYAN objects using MeshCat
Any function that requires MeshCat should be defined in this file.
    And its method should be defined in ext/meshcatglue.jl
"""


function drawcontext! end
function drawboundary! end
function drawlink_2mons! end
function draw_decimated_2mon_sites! end
function append_monomer_arrow! end
function drawfilaments! end
function drawfilaments_tubes! end
function drawhalfedgemeshes! end
function drawdiffusing! end
function drawgrid! end
function drawrandomgridpoints! end
function pathExtrudeGenerate end
function unionmesh end
function zeromesh end
function drawvertices! end
function drawcadherins! end
function drawpossiblecadherins! end