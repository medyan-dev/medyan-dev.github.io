
import DataStructures

"""
    add_diffusion_coeff!(s::SysDef, diffusing_name::Symbol, diffusing_coeff::Float64)
Add the diffusing species to the system with diffusion coefficent in units of (nm²/s). Return s.
"""
function add_diffusion_coeff!(s::SysDef,diffusing_name::Symbol,diffusing_coeff::Float64)::SysDef
    s.diffusing_coeff[diffusing_name] = diffusing_coeff
    s
end

"""
    add_filament_params!(s::SysDef, filament_name::Symbol, filament_params::FilamentMechParams)
Add the filament parameters to the system. Return s.

See [`MEDYAN.FilamentMechParams`](@ref)
"""
function add_filament_params!(s::SysDef, filament_name::Symbol, filament_params)::SysDef
    s.filament_params[filament_name] = filament_params
    s
end

"""
    addfilamentsite!(s::SysDef,filamenttypename::Symbol,filamentsitename::Symbol,site)
"""
function addfilamentsite!(s::SysDef,filamenttypename::Symbol,filamentsitename::Symbol,site)::SysDef
    filamenttypename in keys(s.filament) || error("$filamenttypename not in $(keys(s.filament))")
    currentsites= s.filamentsite[filamenttypename]
    filamentsitename in keys(currentsites) && error("$filamentsitename already exists")
    fsid= length(currentsites)+1
    push!(s.allfixedspeciesnames,"filamentsite.$filamenttypename.$filamentsitename")
    fxsid= length(s.allfixedspeciesnames)
    insert!(s.filamentsite[filamenttypename],filamentsitename,SiteData(fsid,site,fxsid))
    s
end

"""
    addfilamentendsite!(s::SysDef,filamenttypename::Symbol,filamentendsitename::Symbol,site)::SysDef
"""
function addfilamentendsite!(s::SysDef,filamenttypename::Symbol,filamentendsitename::Symbol,site)::SysDef
    filamenttypename in keys(s.filament) || error("$filamenttypename not in $(keys(s.filament))")
    currentsites= s.filamentendsite[filamenttypename]
    filamentendsitename in keys(currentsites) && error("$filamentendsitename already exists")
    sid= length(currentsites)+1
    push!(s.allfixedspeciesnames,"filamentendsite.$filamenttypename.$filamentendsitename")
    fxsid= length(s.allfixedspeciesnames)
    insert!(s.filamentendsite[filamenttypename],filamentendsitename,SiteData(sid,site,fxsid))
    s
end

"""
    add_decimated_2mon_site!(s::SysDef,decimated_2mon_sitename::Symbol,site)::SysDef
"""
function add_decimated_2mon_site!(s::SysDef,decimated_2mon_sitename::Symbol,site)::SysDef
    decimated_2mon_sitename in keys(s.decimated_2mon_site) && error("$decimated_2mon_sitename already exists")
    sid= length(s.decimated_2mon_site)+1
    ftids = getftids(site)
    midsteps = getmidsteps(site)
    ftids[1] in s.filament || error("filament type not in system")
    ftids[2] in s.filament || error("filament type not in system")
    ftids[1] != ftids[2] || midsteps[1] == midsteps[2] || error("if filament types match, mid steps must match")
    push!(s.allfixedspeciesnames,"decimated_2mon_site.$decimated_2mon_sitename")
    fxsid= length(s.allfixedspeciesnames)
    insert!(s.decimated_2mon_site,decimated_2mon_sitename,SiteData(sid,site,fxsid))
    s
end

#cadherin related reactions
"""
    addcadherin!(s::SysDef,cadherintypename::Symbol,defaultstate::CadherinState,mechparams). Add the cadherin to the system. Return s.
"""
function addcadherin!(s::SysDef,cadherintypename::Symbol,defaultstate::CadherinState,mechparams;)::SysDef
    
    s.cadherinparams[cadherintypename] = CadherinParams(
        defaultstate,
        mechparams,
    )
    s
end

"""
    addcadherinsite!(s::SysDef,cadherintypename::Symbol,cadherinsitename::Symbol,site)::SysDef
"""
function addcadherinsite!(s::SysDef,cadherintypename::Symbol,cadherinsitename::Symbol,site)::SysDef
    cadherintypename in keys(s.cadherin) || error("$cadherintypename not in $(keys(s.cadherin))")
    currentsites= s.cadherinsite[cadherintypename]
    cadherinsitename in keys(currentsites) && error("$cadherinsitename already exists")
    sid= length(currentsites)+1
    push!(s.allfixedspeciesnames,"cadherinsite.$cadherintypename.$cadherinsitename")
    fxsid= length(s.allfixedspeciesnames)
    insert!(s.cadherinsite[cadherintypename],cadherinsitename,SiteData(sid,site,fxsid))
    s
end

"""
    addpossiblecadherinsite!(s::SysDef,possiblecadherinsitename::Symbol,site)::SysDef
"""
function addpossiblecadherinsite!(s::SysDef,possiblecadherinsitename::Symbol,site)::SysDef
    possiblecadherinsitename in keys(s.possiblecadherinsite) && error("$possiblecadherinsitename already exists")
    sid= length(s.possiblecadherinsite)+1
    site.vertexstate in s.vertex || error("vertex type not in system")
    site.ftid in s.filament || error("filament type not in system")
    push!(s.allfixedspeciesnames,"possiblecadherinsite.$possiblecadherinsitename")
    fxsid= length(s.allfixedspeciesnames)
    insert!(s.possiblecadherinsite,possiblecadherinsitename,SiteData(sid,site,fxsid))
    s
end

"""
    $(TYPEDSIGNATURES)

Add a new site with a specified name.
During this process, a new fixed species is created suffixed with "membranesite.".
"""
function addmembranesite!(s::SysDef, membranesitename::Symbol, site)::SysDef
    if membranesitename ∈ keys(s.membranesite)
        error("$membranesitename already exists.")
    end
    sid = length(s.membranesite) + 1
    push!(s.allfixedspeciesnames, "membranesite.$membranesitename")
    fxsid = length(s.allfixedspeciesnames)
    insert!(s.membranesite, membranesitename, SiteData(sid, site, fxsid))
    s
end
export addmembranesite!

"""
    add_link_type!(s::SysDef;
        name::Symbol,
        description::String,
        places::Vector{<:Place},
        bonds::Vector{<:Union{BondConfig, NamedTuple}},
        reactions::Vector{<:Union{LinkReactionConfig, NamedTuple}}
        param::NamedTuple=(;),
        state::NamedTuple=(;),
    )::SysDef
"""
Base.@nospecializeinfer function add_link_type!(s::SysDef;
        name::Symbol,
        description::String="",
        places::Vector{<:Place},
        bonds::Vector=BondConfig[],
        reactions::Vector{<:Vector}=Vector{LinkReactionConfig}[],
        param::NamedTuple=(;),
        state::NamedTuple=(;),
    )::SysDef
    @nospecialize
    if name ∈ keys(s.link)
        error("$name already exists.")
    end
    id = length(s.link) + 1
    place_offset = s.total_num_link_types_places
    @argcheck length(places) > 0
    @argcheck length(reactions) ≤ length(places)
    @argcheck all(is_null, places)

    parsed_bonds = map(bonds) do _b
        b = if _b isa BondConfig
            _b
        else
            BondConfig(;_b...)
        end
        # validate the place indexes against places
        @argcheck all(∈(eachindex(places)), b.input)
        @argcheck all(num_input_directions(b.bond) .≤ num_directions.(places[collect(b.input)]))
        b::BondConfig
    end
    insert!(s.link_reaction_site, name, PropDictionary())
    place_reaction_infos = [LinkReactionInfo[] for i in 1:length(places)]
    parsed_reactions = [LinkReactionConfig[] for i in 1:length(places)]
    for place_idx in 1:length(reactions)
        local fila_reaction_count::Int64 = 0
        for (reaction_id, _r) in enumerate(reactions[place_idx])
            local r = if _r isa LinkReactionConfig
                _r
            else
                LinkReactionConfig(;_r...)
            end
            # run custom error checking code
            errorcheck_addcallback(r.affect!, s)
            errorcheck_addcallback(r.rate, s)
            # check fila type is valid
            local fila_typeid = if isnothing(r.fila_cutoff)
                0
            else
                fila_reaction_count += 1
                s.filament[r.fila_cutoff[1]]
            end
            # add fixed species and reaction with callback
            local subname_site = "place$(place_idx)_reaction$(reaction_id)"
            local name_site = "link_reaction_site.$(name).$(subname_site)"
            push!(s.allfixedspeciesnames, name_site)
            local fxsid = length(s.allfixedspeciesnames)
            insert!(s.link_reaction_site[name], Symbol(subname_site), (;fxsid))
            callback = if iszero(fila_typeid)
                LinkPlainReactionCallback(id, reaction_id, place_idx+place_offset, place_idx, fxsid, r.affect!)
            else
                LinkFilaReactionCallback(
                    id,
                    reaction_id,
                    fila_reaction_count,
                    fila_typeid,
                    r.fila_cutoff[2],
                    place_idx+place_offset,
                    place_idx,
                    fxsid,
                    r.affect!,
                )
            end
            addreactioncallback!(s,
                "$name_site + $(r.reactants_extra)",
                1.0,
                r.invvolumepower,
                callback,
            )
            if iszero(fila_typeid)
                push!(place_reaction_infos[place_idx], LinkPlainReactionInfo(fxsid, r.rate))
            else
                push!(place_reaction_infos[place_idx], LinkFilaReactionInfo(fxsid, r.rate, fila_reaction_count, fila_typeid, r.fila_cutoff[2]))
            end
            push!(parsed_reactions[place_idx], r)
        end
    end
    insert!(s.link, name, LinkConfig(
            name,
            Int64(id),
            place_offset,
            description,
            places,
            parsed_bonds,
            parsed_reactions,
            place_reaction_infos,
            param,
            state,
        )
    )
    s.total_num_link_types_places += length(places)
    s
end

"""
    addreaction!(s::SysDef,reaction::CompartmentReaction)::SysDef
"""
function addreaction!(s::SysDef,reaction::CompartmentReaction)::SysDef
    push!(s.compartmentreactions, reaction)
    s
end
function addreaction!(s::SysDef, reaction::BulkReaction)::SysDef
    push!(s.bulkreactions, reaction)
    s
end

"""
    addreaction!(s::SysDef,reactionexpr::AbstractString,rate::Float64,invvolumepower::Int)::SysDef
Add a reaction to the system. Return s

`reactionexpr` is a string describing the reaction stoichiometry

`reactionexpr` is comprised of reactant and product parts seperated by a `"-->"`

All whitespace characters are ignored.

Each side is then split by `"+"` to get the species names.

Repeated or extra `"+"` are ignored.

A species name can be prepended by a positive integer to represent multiple copies.

1. `rate::Float64`: Base rate for the reaction. ((nm³)^(`invvolumepower`)/s)
    rate constants correspond to stochastic rate constants in the sense used by Gillespie (J. Comp. Phys., 1976, 22 (4)).
1. `invvolumepower::Int`: `volumefactor= (1/volume)^invvolumepower` where `volume` is the volume of the compartment in nm³.
    Generally this is 0 for reactions without another diffusing reactant, and 1 if there is another diffusing reactant.


# Example good `reactionexpr`
    "diffusing.a + diffusing.b --> diffusing.c"
    "diffusing.c --> diffusing.a + diffusing.b"
    "+ + diffusing.c + --> + diffusing.a + + diffusing.b + +"
    " --> diffusing.a + diffusing.b"
    "diffusing.a + diffusing.b --> "
    "diffusing.a + diffusing.a --> "
    "2diffusing.a --> "
    "2diffusing.a --> 20diffusing.a"
    "diffusing.c + diffusing.b --> diffusing.c + diffusing.b"
    "fixedspecies.rate1b --> fixedspecies.g"
    "fixedspecies.rate1b + fixedspecies.g --> fixedspecies.g"
    "fixedspecies.rate1b + 23fixedspecies.g --> fixedspecies.g"
    "fixedspecies.g --> fixedspecies.rate1b + 23fixedspecies.g"
    "fixedspecies.g + fixedspecies.rate1b--> 2fixedspecies.rate1b + 23fixedspecies.g"
    "filamentsite.MT.d --> filamentsite.MT.d"
    "filamentsite.MT.d + diffusing.a --> filamentsite.MT.d"
    "fixedspecies.g --> diffusing.a"
    "diffusing.a --> fixedspecies.g"
    "filamentsite.actin.pm + diffusing.a --> filamentsite.actin.pm"
"""
function addreaction!(s::SysDef,reactionexpr::AbstractString,rate::Float64,invvolumepower::Int)
    reaction= parsereaction(s,reactionexpr,rate,invvolumepower)
    addreaction!(s,reaction)
end

"""
    addreactioncallback!(s::SysDef, reaction::CompartmentReaction, callback)::SysDef
    addreactioncallback!(s::SysDef, reactantexpr::AbstractString, rate::Float64, invvolumepower::Int, callback)::SysDef
Like [`addreaction!`](@ref) but also adds `callback`.
`callback` is called when the reaction happens with 
input of `MEDYAN.Context` and `Int` the compartment id where the reaction happened.

The reaction should normally have no net stoichiometry because the callback should handle updating species counts.
If an `AbstractString` is passed instead of a `CompartmentReaction` for the reaction, that string will be parsed to determine the reactants.
The net stoichiometry will be zero.

`MEDYAN.errorcheck_addcallback(callback,s::SysDef)` can optionally be overloaded
to add errorchecking when the callback is added.
"""
function addreactioncallback!(s::SysDef, reaction::CompartmentReaction, callback)::SysDef
    # warn if net stoich is non zero
    isempty(reaction.diffusingnet_stoich) || @warn "non zero net stoich for reaction with callback"
    isempty(reaction.fixednet_stoich) || @warn "non zero net stoich for reaction with callback"
    isempty(reaction.bulknet_stoich) || @warn "non zero net stoich for reaction with callback"
    #check that callback has the right signature
    any(m-> Tuple{typeof(callback),Context,Int} <: m.sig, methods(callback)) ||
        error("callback doesn't have the right signature: $callback")
    #run custom error checking code specialized on callback
    errorcheck_addcallback(callback,s)
    #callback reactions are at the front
    pushfirst!(s.compartmentreactions,reaction)
    pushfirst!(s.compartmentreactioncallbacks,callback)
    s
end
"""
Callback for bulk reactions: Context -> Nothing.
"""
function addreactioncallback!(s::SysDef, reaction::BulkReaction, callback)::SysDef
    # warn if net stoich is non zero
    isempty(reaction.net_stoich) || @warn "non zero net stoich for reaction with callback"
    # Check that the callback has the right signature.
    any(m -> Tuple{typeof(callback), Context} <: m.sig, methods(callback)) ||
        error("callback does not have the right signature: $callback")
    # Run custom error checking code specialized on callback.
    errorcheck_addcallback(callback,s)
    # Push at front of reactions and callbacks.
    pushfirst!(s.bulkreactions, reaction)
    pushfirst!(s.bulkreactioncallbacks, callback)
    s
end

function addreactioncallback!(s::SysDef,reactantexpr::AbstractString,rate::Float64,invvolumepower::Int, callback)::SysDef
    # make a reaction with zero net stoich
    reaction= parsereaction(s,reactantexpr*"-->"*reactantexpr,rate,invvolumepower)
    addreactioncallback!(s, reaction, callback)
end


"""
Add filament reaction. Return s.
Add a `filamentsite` and reaction with callback to change the monomer state.
This can be used for filament aging, filament catalyzed reactions, or simple binding reactions.

# Arguments
1. `s::SysDef`: the system to add to.
1. `filamenttypename::Symbol`: the filament type name.
1. `filamentsitename::Symbol`: the new name of the `filamentsite` added. This can be used as a catalyst in other reactions.
1. `changedstatenames::Pair{Vector{Symbol}, Vector{Symbol}}`: 
    the changes to the monomer states, the first is the states to match. 
    The second is the new monomer states after the reaction.
    both should be the same length.
    Ordered minus end first.
1. `center::Int`: Which index of `changedstatenames.first` 
    is the actual location of the `filamentsite`. Used for determining what compartment the reaction goes in.
1. `reactantexpr::AbstractString`: Allows adding other reactants or products to the reaction.
    `" + filamentsite.\$(filamenttypename).\$(filamentsitename) + "` 
    gets added to both sides this to create the full reaction expression. See [`addreaction!`](@ref) for syntax.
1. `rate::Float64`: Base rate for the reaction. ((nm³)^(`invvolumepower`)/s)
1. `invvolumepower::Int`: `volumefactor= (1/volume)^invvolumepower` where `volume` is the volume of the compartment in nm³.
    `volumefactor` only applies to this reaction not any other reaction using `filamentsitename`
    Generally this is 0 for reactions without another diffusing reactant, and 1 if there is another diffusing reactant.

# Examples
```julia
using MEDYAN
agent_names = AgentNames(
	filamentnames= [(:filname,[
                            :a,
                            :b,
                            :c,
                        ]),
	],
)
s= SysDef(agent_names)
addfilament_reaction!(s, :filname, :ab,
    [:a]=>[:b], 1,
    "-->", 1.75E-3, 0,
)
addfilament_reaction!(s, :filname, :aabc,
    [:a,:a]=>[:b,:c], 2,
    "-->", 1.75E-3, 0,
)
```
"""
function addfilament_reaction!(
        s::SysDef,
        filamenttypename::Symbol,
        filamentsitename::Symbol,
        changedstatenames::Pair{Vector{Symbol}, Vector{Symbol}},
        center::Int,
        reactionexpr::AbstractString,
        rate::Float64,
        invvolumepower::Int
    )::SysDef
    oldstatenames = changedstatenames.first
    newstatenames = changedstatenames.second
    @assert length(oldstatenames)==length(newstatenames) "old and new states not the same length"
    @assert center in eachindex(oldstatenames) "center out of range"
    sitestates= getproperty.((s.state[filamenttypename],),oldstatenames)
    site= FilamentSiteGeneral(center,sitestates)
    addfilamentsite!(s,filamenttypename,filamentsitename,site)
    newstates= getproperty.((s.state[filamenttypename],),newstatenames)
    #add site to both sides of the reaction expression 
    sitestring= " + filamentsite.$(filamenttypename).$(filamentsitename) + "
    fullexpr= sitestring*reactionexpr*sitestring
    reaction= parsereaction(s,fullexpr,rate,invvolumepower)
    # empty the diffusing net stoich because the callback handles that
    diffusing_net_stoich = map((x->(x.id=>x.amount)), reaction.diffusingnet_stoich)
    empty!(reaction.diffusingnet_stoich)
    callback= GeneralFilamentSiteCallback(
        s.filament[filamenttypename],
        s.filamentsite[filamenttypename][filamentsitename].id,
        center,
        newstates,
        diffusing_net_stoich,
    )
    addreactioncallback!(s, reaction, callback)
end


"""
Add filament end reaction. Return s.
Add a `filamentendsite` and reaction with callback to change the filaments.
This can be used for polymerization, depolymeriation, and changing end state.

# Arguments
1. `s::SysDef`: the system to add to.
1. `filamenttypename::Symbol`: the filament type name.
1. `filamentendsitename::Symbol`: the new name of the `filamentendsite` added. This can be used as a catalyst in other reactions.
1. `isminusend::Bool`: true if changing the minus end, false if changing the plus end.
1. `changedendstatenames::Pair{Vector{Symbol}, Vector{Symbol}}`: 
    the changes to the end monomer states, the first is the states to match. The second is the new monomer states after the reaction.
    If the second has more states than the first, new monomers will be added, if the second has less, monomers will be removed.
    Ordered minus end first.
1. `spacing::Float64`: Space needed at the filament end for this reaction. (nm)
    `ratefactor= exp(-β*spacing*loadforce)` 
    where β is 1/kT, 
    `loadforce` is the external force pushing axially on the end of the filament.
    and `ratefactor` affects this reaction propensity and any others using `filamentendsitename`
1. `reactionexpr::AbstractString`: Allows adding other reactants or products to the reaction.
    `" + filamentendsite.\$(filamenttypename).\$(filamentendsitename) + "` 
    gets added to both sides this to create the full reaction expression. See [`addreaction!`](@ref) for syntax.
1. `rate::Float64`: Base rate for the reaction. ((nm³)^(`invvolumepower`)/s)
1. `invvolumepower::Int`: `volumefactor= (1/volume)^invvolumepower` where `volume` is the volume of the voxel in nm³.
    `volumefactor` only applies to this reaction not any other reaction using `filamentendsitename`
    Generally this is 0 for reactions without another diffusing reactant, and 1 if there is another diffusing reactant.

# Examples
```julia
using MEDYAN
agent_names = AgentNames(
	diffusingspeciesnames= [:a,],
	filamentnames= [(:filname,[
                            :plus,
                            :mid,
                            :minus,
                        ]),
	],
)
s= SysDef(agent_names)
monomerspacing= 2.7
#minus end polymerization
addfilamentend_reaction!(s, :filname, :pm, true,
    [:minus]=>[:minus,:mid], monomerspacing,
    "diffusing.a -->", 10E3, 1,
)
#plus end depolymerization
addfilamentend_reaction!(s, :filname, :dpp, false,
    [:mid,:plus]=>[:plus], 0.0,
    "--> diffusing.a", 1.75E-3, 0,
)
```
"""
function addfilamentend_reaction!(
        s::SysDef,
        filamenttypename::Symbol,
        filamentendsitename::Symbol,
        isminusend::Bool,
        changedendstatenames::Pair{Vector{Symbol}, Vector{Symbol}},
        spacing::Float64,
        reactionexpr::AbstractString,
        rate::Float64,
        invvolumepower::Int
    )
    oldendstatenames = changedendstatenames.first
    newendstatenames = changedendstatenames.second
    sitestates= getproperty.((s.state[filamenttypename],),oldendstatenames)
    newstates= getproperty.((s.state[filamenttypename],),newendstatenames)
    Δmonomers= length(newendstatenames)-length(oldendstatenames)
    site= FilamentEndSiteGeneral(;
        isminusend,
        endstates=sitestates,
        spacing,
        added_monomers=max(Δmonomers,0),
    )
    addfilamentendsite!(s,filamenttypename,filamentendsitename,site)
    
    #add site to both sides of the reaction expression
    sitestring= " + filamentendsite.$(filamenttypename).$(filamentendsitename) + "
    fullexpr= sitestring*reactionexpr*sitestring
    reaction= parsereaction(s,fullexpr,rate,invvolumepower)
    # empty the diffusing net stoich because the callback handles that
    diffusing_net_stoich = map((x->(x.id=>x.amount)), reaction.diffusingnet_stoich)
    empty!(reaction.diffusingnet_stoich)
    callback= GeneralFilamentEndCallback(
        s.filament[filamenttypename],
        s.filamentendsite[filamenttypename][filamentendsitename].id,
        Δmonomers,
        newstates,
        diffusing_net_stoich,
    )
    addreactioncallback!(s, reaction, callback)
end


function addunbindingcadherinsite!(
    s,
    cadherintypename,
    cadherinsitename,
    cadherinsite,
    filamenttypename,
    newmonomerstatename,
    reactionexpr,
    rate,
    invvolumepower,
)
    filamentnewstate = s.state[filamenttypename][newmonomerstatename]
    addcadherinsite!(s,cadherintypename,cadherinsitename,cadherinsite)
    #add site to both sides of the reaction expression
    sitestring= " + cadherinsite.$(cadherintypename).$(cadherinsitename) + "
    fullexpr= sitestring*reactionexpr*sitestring
    reaction= parsereaction(s,fullexpr,rate,invvolumepower)
    callback = UnbindingCadherinCallback(    
    s.cadherin[cadherintypename],
    s.cadherinsite[cadherintypename][cadherinsitename].id,
    filamentnewstate,
    )
    reaction= parsereaction(s,fullexpr,rate,invvolumepower)
    addreactioncallback!(s, reaction, callback)
end


"""
Add a membrane site with the corresponding reaction with callback.

Keyword arguments:
- s: SysDef.
- name_newmembranesite: Symbol.
- membranediffusingreactants: Vector of symbols as membrane reactants. 0 or 1 reactant is currently supported.
- membranediffusingproducts: Vector of symbols as membrane products.
- reactionexpr_extra: Reaction expression for other species involved.
- rate: Float.
- changerage_bypotentialenergy: Whether the rate is affected by potential energy.
- invvolumepower: rate scaling with compartment volume.

Notes:
- If error occurs, this function does not ensure that s is unchanged.
"""
function add_membranesitereaction!(;
        s::SysDef,
        name_newmembranesite::Symbol,
        membranediffusingreactants::Vector{Symbol},
        membranediffusingproducts::Vector{Symbol},
        reactionexpr_extra::AbstractString,
        rate::Float64,
        canchangerate_bypotentialenergy::Bool,
        invvolumepower::Real,
    )

    # Generating membrane site information.
    if length(membranediffusingreactants) > 1
        error("Currently, membrane site supports up to 1 membrane diffusing species.")
    end
    id_memdiffusing_reactant::Int = length(membranediffusingreactants) == 1 ? getproperty(s.membranediffusing, membranediffusingreactants[1]) : 0
    stoichs_mem = DataStructures.DefaultOrderedDict{Int, Int}(0)
    for r ∈ membranediffusingreactants
        local id = getproperty(s.membranediffusing, r)
        stoichs_mem[id] -= 1
    end
    for p ∈ membranediffusingproducts
        local id = getproperty(s.membranediffusing, p)
        stoichs_mem[id] += 1
    end
    site = MembraneSiteDiffusing(
        id_memdiffusing_reactant,
        canchangerate_bypotentialenergy,
        collect(filter(x->!iszero(x[2]),stoichs_mem)),
    )
    addmembranesite!(s, name_newmembranesite, site)
    siteindex = s.membranesite[name_newmembranesite].id

    # Construct the reaction.
    # add site to both sides of the reaction expression
    sitestring= " + membranesite.$(name_newmembranesite) + "
    fullexpr= sitestring * reactionexpr_extra * sitestring
    reaction= parsereaction(s, fullexpr, rate, invvolumepower)
    # empty the diffusing net stoich because the callback handles that
    diffusing_net_stoich = map((x->(x.id=>x.amount)), reaction.diffusingnet_stoich)
    empty!(reaction.diffusingnet_stoich)

    # Create callback.
    cb = MembraneSiteReactionCallbackDiffusion(siteindex, diffusing_net_stoich)

    addreactioncallback!(s, reaction, cb)
end
export add_membranesitereaction!



function parsereaction(s::SysDef,reactionexpr::AbstractString,rate::Float64,invvolumepower::Int)
    rps= split(filter(!isspace,reactionexpr),"-->")
    length(rps) == 2 || error("use one --> for reaction arrow not $(reactionexpr)")
    dr_dict, fr_dict= try 
        helper_reactionparser(s,String(rps[1]))
    catch e
        error("failed to parse reactants $(repr(rps[1]))")
    end
    dp_dict, fp_dict= try
        helper_reactionparser(s,String(rps[2]))
    catch e
        error("failed to parse products $(repr(rps[2]))")
    end
    #get diffusing reactants
    length(dr_dict) ≤ 2 || error("there is a maximum of two diffusing reactants: $(reactionexpr)")
    sum(values(dr_dict)) ≤ 2 || error("there is a maximum of two diffusing reactants: $(reactionexpr)")
    diffusingreactants::Tuple{Int,Int}= 
        if length(dr_dict) == 0
            (0,0)
        elseif length(dr_dict) == 1
            id= first(dr_dict).first
            amount = first(dr_dict).second
            if amount == 1
                (id,0)
            elseif amount == 2
                (id,id)
            end
        elseif length(dr_dict) == 2
            (keys(dr_dict)...,)
        end

    fixedreactants= Vector{NamedTuple{(:id, :amount), Tuple{Int, Int}}}()
    for fxsid in keys(fr_dict)
        push!(fixedreactants,(id=fxsid,amount=fr_dict[fxsid]))
    end
    all_dsids= DataStructures.OrderedSet((keys(dr_dict)...,keys(dp_dict)...))
    diffusingnet= Vector{NamedTuple{(:id, :amount), Tuple{Int, Int}}}()
    for id in all_dsids
        amount= dp_dict[id] - dr_dict[id]
        if !iszero(amount)
            push!(diffusingnet,(id=id,amount=amount))
        end
    end
    all_fxsids= DataStructures.OrderedSet((keys(fr_dict)...,keys(fp_dict)...))
    fixednet= Vector{NamedTuple{(:id, :amount), Tuple{Int, Int}}}()
    for id in all_fxsids
        amount= fp_dict[id] - fr_dict[id]
        if !iszero(amount)
            id > length(s.fixedspecies) && error("reaction changes dependent fixed species count, include catalysts on both sides: $reactionexpr")
            push!(fixednet,(id=id,amount=amount))
        end
    end
    CompartmentReaction(
        diffusingreactants,
        diffusingnet,
        fixedreactants,
        fixednet,
        [],
        [],
        rate,
        invvolumepower
    )
end

"""
parse one side of a reaction, return a tuple of 2 DefaultOrderedDict{Int, Int}(0), diffusing and compartment
"""
function helper_reactionparser(s::SysDef, oneside::AbstractString)
    diffusing= DataStructures.DefaultOrderedDict{Int, Int}(0)
    compartment= DataStructures.DefaultOrderedDict{Int, Int}(0)
    for species in split(oneside,"+")
        if !isempty(species)
            coefficent= species[begin:(findfirst(!isdigit,species)-1)]
            symbols= Symbol.(split(species[findfirst(!isdigit,species):end],"."))
            length(symbols) > 1 || error("reaction parsing error: $(oneside)")
            amount= 1
            if !isempty(coefficent)
                amount= parse(Int,coefficent)
                amount > 0 || error("only strictly positive coefficents: $(oneside)")
            end
            if symbols[1] == :diffusing
                id= foldl(getproperty,(s, symbols...))
                diffusing[id]+=amount
            elseif symbols[1] == :fixedspecies
                id= foldl(getproperty,(s, symbols...))
                compartment[id]+=amount
            else
                id= foldl(getproperty,(s, symbols..., :fxsid))
                compartment[id]+=amount
            end
        end
    end
    (diffusing, compartment)
end


"""
Convert ordered collection of Symbols to PropDictionary of Symbol to index
"""
function helper_indexify(x,type=Int)
    PropDictionary(x,collect(type,eachindex(x)))
end

