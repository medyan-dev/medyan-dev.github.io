using ArgCheck
using StaticArrays
using ElasticArrays
using StructArrays
using OffsetArrays


const MonomerState = UInt8

"""
The data indexed by fil_idx.

$(TYPEDFIELDS)
"""
Base.@kwdef struct DataPerFilament
    "filament id"
    id::Int

    "start monomer id"
    mon_id_first::Int

    "last monomer id"
    mon_id_last::Int

    monomerstates::Vector{MonomerState}
    
    "Extend beyond the ends of the filament if the ending monomer id isn't divisible by 
    numpercylinder"
    chembeadpositions::Vector{SVector{3, Float64}}

    "cylinder indexes on the filament"
    cyl_idxs::Vector{Int} = []

    "minus end load force => plus end load force"
    endloadforces::Pair{Float64,Float64} = 0.0 => 0.0

    "number of monomers on the minus end that are not tracked for decimated_2mon sites"
    minusend_num_notminimized::Int = 0

    "number of monomers on the plus end that are not tracked for decimated_2mon sites"
    plusend_num_notminimized::Int = 0

    # "starting monomer ids on cylinders on the filament"
    # cyl_start_mids::Vector{Int}
end

# """
# Return the cylinder index given the monomer id and a DataPerFilament.
# """
# function mon_id_2_cyl_idx(d::DataPerFilament, mon_id)
#     i = searchsortedlast(d.cyl_start_mids, mon_id)
#     iszero(i) && error("monomer id $mon_id too small, starting monomer id is $(d.cyl_start_mids[1])")
#     d.cyl_idxs[i]
# end

"""
The data indexed by cyl_idx.

$(TYPEDFIELDS)
"""
Base.@kwdef struct DataPerCylinder
    "filament id"
    fil_id::Int

    exists::Bool = true

end

"""
Data about filament cylinders during chemisty

One of these exists per filament type.

$(TYPEDFIELDS)
"""
Base.@kwdef struct ChemCylinders
    "filament type id."
    ftid::Int

    "number of monomers per cylinder"
    numpercylinder::Int

    per_cyl::typeof(StructVector(DataPerCylinder[])) = StructVector(DataPerCylinder[])

    "collection of unused cylinder indexes"
    holes::Vector{Int} = []

    fil_id_2_idx::Dict{Int,Int} = Dict()

    "Indexed by fil_idx, to get data per filament"
    per_fil::typeof(StructVector(DataPerFilament[])) = StructVector(DataPerFilament[])

end


function ChemCylinders(ftid::Integer, numpercylinder::Integer)
    ChemCylinders(;
        ftid,
        numpercylinder,
    )
end


function assert_invariants(cylinders::ChemCylinders)
    for hole in cylinders.holes
        @argcheck !cylinders.per_cyl.exists[hole]
    end
    num_cyl_exist = length(cylinders.per_cyl) - length(cylinders.holes)
    @argcheck sum(cylinders.per_cyl.exists) == num_cyl_exist
    num_cyl_in_filaments = 0
    @argcheck length(cylinders.per_fil) == length(keys(cylinders.fil_id_2_idx))
    for fil_idx in 1:length(cylinders.per_fil)
        fil = LazyRow(cylinders.per_fil, fil_idx)
        fil_id = fil.id
        @argcheck fil_idx == cylinders.fil_id_2_idx[fil_id]
        for cyl_idx in fil.cyl_idxs
            @argcheck cylinders.per_cyl.exists[cyl_idx]
            @argcheck fil_id == cylinders.per_cyl.fil_id[cyl_idx]
        end
        num_cyl_on_fil = length(fil.cyl_idxs)
        @argcheck num_cyl_on_fil > 0
        @argcheck num_cyl_on_fil == length(fil.chembeadpositions) - 1
        @argcheck fil.mon_id_last - fil.mon_id_first == length(fil.monomerstates) - 1
        num_cyl_in_filaments += num_cyl_on_fil
    end
    @argcheck num_cyl_in_filaments == num_cyl_exist
end


"""
Return mon_id_first, mon_id_last, numpercylinder
"""
function _mon_id_info(cylinders::ChemCylinders, fil_idx::Int)::NTuple{3, Int}
    mon_id_first::Int = cylinders.per_fil.mon_id_first[fil_idx]
    mon_id_last::Int = cylinders.per_fil.mon_id_last[fil_idx]
    numpercylinder::Int = cylinders.numpercylinder
    (
        mon_id_first,
        mon_id_last,
        numpercylinder,
    )
end

"""
    $(TYPEDSIGNATURES)
Return a read only OffsetVector of monomer states on a filament.

This can be invalid after any mutations to context, so copy if needed.
"""
function _fil_mon_states(cylinders::ChemCylinders, fil_idx::Int)::OffsetVector{MonomerState, Vector{MonomerState}}
    mon_id_first = cylinders.per_fil.mon_id_first[fil_idx]
    OffsetArrays.Origin(mon_id_first)(cylinders.per_fil.monomerstates[fil_idx])
end


function _mon_position(cylinders::ChemCylinders, fil_idx::Int, mon_id::Int)
    fil_cyl_idx, frac = @inline(get_fil_chem_cyl_idx_frac(
        mon_id,
        _mon_id_info(cylinders, fil_idx)...
    ))
    chembeadpositions = cylinders.per_fil.chembeadpositions[fil_idx]
    r1 = chembeadpositions[fil_cyl_idx]
    r2 = chembeadpositions[fil_cyl_idx + 1]
    frac*r2 + (1.0-frac)*r1
end

function _mon_plusvector(cylinders::ChemCylinders, fil_idx::Int, mon_id::Int)
    fil_cyl_idx, frac = get_fil_chem_cyl_idx_frac(
        mon_id,
        _mon_id_info(cylinders, fil_idx)...
    )
    chembeadpositions = cylinders.per_fil.chembeadpositions[fil_idx]
    r1 = chembeadpositions[fil_cyl_idx]
    r2 = chembeadpositions[fil_cyl_idx + 1]
    normalize_fast(r2 - r1)
end

function _mon_position_plusvector(cylinders::ChemCylinders, fil_idx::Int, mon_id::Int)
    fil_cyl_idx, frac = get_fil_chem_cyl_idx_frac(
        mon_id,
        _mon_id_info(cylinders, fil_idx)...
    )
    chembeadpositions = cylinders.per_fil.chembeadpositions[fil_idx]
    r1 = chembeadpositions[fil_cyl_idx]
    r2 = chembeadpositions[fil_cyl_idx + 1]
    pos = frac*r2 + (1.0-frac)*r1
    plusv = normalize_fast(r2 - r1)
    pos, plusv
end

function _get_nodepositions(cylinders::ChemCylinders, fil_idx::Int)::Vector{SVector{3,Float64}}
    _get_nodepositions(
        cylinders.per_fil.chembeadpositions[fil_idx],
        _mon_id_info(cylinders, fil_idx)...
    )
end

"""
Return the number of monomers on the minus end cylinder
"""
function _get_nummonomersminusend(cylinders::ChemCylinders, fil_idx::Int)::Int
    if length(cylinders.per_fil.chembeadpositions[fil_idx])==2
        #just one cylinder
        return length(cylinders.per_fil.monomerstates[fil_idx])
    else
        return cylinders.numpercylinder - mod(cylinders.per_fil.mon_id_first[fil_idx], cylinders.numpercylinder)
    end
end

"""
Return the number of monomers on the plus end cylinder
"""
function _get_nummonomersplusend(cylinders::ChemCylinders, fil_idx::Int)::Int
    if length(cylinders.per_fil.chembeadpositions[fil_idx])==2
        #just one cylinder
        return length(cylinders.per_fil.monomerstates[fil_idx])
    else
        return mod(cylinders.per_fil.mon_id_last[fil_idx], cylinders.numpercylinder) + 1
    end
end

function _fil_node_mon_ids(cylinders::ChemCylinders, fil_idx::Int)::Vector{Int}
    _fil_node_mon_ids(
        _mon_id_info(cylinders, fil_idx)...
    )
end


function Base.empty!(cylinders::ChemCylinders)
    empty!(cylinders.per_cyl)
    empty!(cylinders.holes)
    empty!(cylinders.fil_id_2_idx)
    empty!(cylinders.per_fil)
end

function Base.isempty(cylinders::ChemCylinders)
    isempty(cylinders.per_cyl)
end


function _set_mon_state!(
        cylinders::ChemCylinders,
        fil_idx::Int,
        mon_id::Int,
        newstate::MonomerState,
    )
    mon_id_first = cylinders.per_fil.mon_id_first[fil_idx]
    cylinders.per_fil.monomerstates[fil_idx][mon_id - mon_id_first + 1] = newstate
end

function polymerizeminusend!(cylinders::ChemCylinders, fil_idx::Int, newstate::MonomerState)
    fil = LazyRow(cylinders.per_fil, fil_idx)
    fil.minusend_num_notminimized += 1
    mon_id_first = fil.mon_id_first
    numpercylinder = cylinders.numpercylinder
    if mod(mon_id_first, numpercylinder) == 0
        #new cylinder in the same direction and length as the last one
        pushfirst!(fil.chembeadpositions,2*fil.chembeadpositions[begin]-fil.chembeadpositions[begin+1])
        cyl_idx = length(cylinders.per_cyl) + 1
        push!(cylinders.per_cyl, DataPerCylinder(;fil_id = fil.id))
        pushfirst!(fil.cyl_idxs, cyl_idx)
    end
    pushfirst!(fil.monomerstates, newstate)
    fil.mon_id_first -= 1
end

function polymerizeplusend!(cylinders::ChemCylinders, fil_idx::Int, newstate::MonomerState)
    fil = LazyRow(cylinders.per_fil, fil_idx)
    fil.plusend_num_notminimized += 1
    mon_id_last = fil.mon_id_last
    numpercylinder = cylinders.numpercylinder
    if mod(mon_id_last + 1, numpercylinder) == 0
        #new cylinder in the same direction and length as the last one
        push!(fil.chembeadpositions,2*fil.chembeadpositions[end]-fil.chembeadpositions[end-1])
        cyl_idx = length(cylinders.per_cyl) + 1
        push!(cylinders.per_cyl, DataPerCylinder(;fil_id = fil.id))
        push!(fil.cyl_idxs, cyl_idx)
    end
    push!(fil.monomerstates, newstate)
    fil.mon_id_last += 1
end

function depolymerizeminusend!(cylinders::ChemCylinders, fil_idx::Int)
    fil = LazyRow(cylinders.per_fil, fil_idx)
    if !iszero(fil.minusend_num_notminimized)
        fil.minusend_num_notminimized -= 1
    end
    mon_id_first = fil.mon_id_first
    numpercylinder = cylinders.numpercylinder
    if mod(mon_id_first+1,numpercylinder)==0
        #remove cylinder
        popfirst!(fil.chembeadpositions)
        cyl_idx = popfirst!(fil.cyl_idxs)
        @assert cylinders.per_cyl.exists[cyl_idx]
        push!(cylinders.holes, cyl_idx)
        cylinders.per_cyl.exists[cyl_idx] = false
    end
    popfirst!(fil.monomerstates)
    fil.mon_id_first += 1
end

function depolymerizeplusend!(cylinders::ChemCylinders, fil_idx::Int)
    fil = LazyRow(cylinders.per_fil, fil_idx)
    if !iszero(fil.plusend_num_notminimized)
        fil.plusend_num_notminimized -= 1
    end
    mon_id_last = fil.mon_id_last
    numpercylinder = cylinders.numpercylinder
    if mod(mon_id_last,numpercylinder)==0
        #remove cylinder
        pop!(fil.chembeadpositions)
        cyl_idx = pop!(fil.cyl_idxs)
        @assert cylinders.per_cyl.exists[cyl_idx]
        push!(cylinders.holes, cyl_idx)
        cylinders.per_cyl.exists[cyl_idx] = false
    end
    pop!(fil.monomerstates)
    fil.mon_id_last -= 1
end


"""
Rearrange cylinders to remove holes. After this all cylinders should exist.
"""
function fill_holes!(cylinders::ChemCylinders)
    assert_invariants(cylinders)
    currentsize = length(cylinders.per_cyl)
    finalsize = currentsize - length(cylinders.holes)
    hole_idx = 1
    for cyl_idx in (finalsize+1):currentsize
        if cylinders.per_cyl.exists[cyl_idx]
            while cylinders.holes[hole_idx] > finalsize
                hole_idx += 1
            end
            hole = cylinders.holes[hole_idx]
            hole_idx += 1
            # hole is an empty idx inside the final array 
            # to be filled by `cyl_idx`, a not empty element outside the final array.
            @assert !cylinders.per_cyl.exists[hole]
            @assert cylinders.per_cyl.exists[cyl_idx]
            cyl = cylinders.per_cyl[cyl_idx]
            cylinders.per_cyl[hole] = cyl
            fil_id = cyl.fil_id
            fil_idx = cylinders.fil_id_2_idx[fil_id]
            replace!(cylinders.per_fil.cyl_idxs[fil_idx], cyl_idx=>hole)
        end
    end
    resize!(cylinders.per_cyl, finalsize)
    empty!(cylinders.holes)
    @assert all(cylinders.per_cyl.exists)
    assert_invariants(cylinders)
end


"""
Create a filament and add it to `cylinders`.

The monomers are coarse grained such that every `cylinders.numpercylinder` monomer is a cylinder,
beads are between two monomers and monomers are linearly interpolated between beads.

chem beads are linearly interpolated between `nodepositions` 
    so that the monomers to the right of the beads have ids divisible by `cylinders.numpercylinder`,
    the first and last beads, can be extended from `nodepositions[begin]`, `nodepositions[end]`, so they won't change when a monomer is (de)polymerized.

The `node_mids` are the monomer ids at (slightly plus side of) the `nodepositions`

                                     |
                          -----+-----|-----+-----
      minus end <----       M  |  M  | (M) |  M        ----> plus end
                          -----+-----|-----+-----
                                     |
                                     ^ A nodeposition is indicated by the line.
    
The monomer id with parenthesis (M) will in `node_mids`
"""
function create_filament!(cylinders::ChemCylinders;
        fil_id=1,
        monomerstates,
        node_mids,
        nodepositions,
        endloadforces=(0.0 => 0.0),
        minusend_num_notminimized=0,
        plusend_num_notminimized=0,
    )
    @argcheck length(monomerstates)>1 #must have at least 2 monomers
    @argcheck length(nodepositions) ≥ 2
    @argcheck length(node_mids) == length(nodepositions) - 1 || length(node_mids) == length(nodepositions)
    numpercylinder = cylinders.numpercylinder
    full_node_mids = if length(node_mids) == length(nodepositions) - 1
        [copy(node_mids) ; node_mids[begin] + length(monomerstates)]
    else
        @argcheck node_mids[end] == node_mids[begin] + length(monomerstates)
        copy(node_mids)
    end
    chembeadpositions = interpolate_chem_beads(
        full_node_mids,
        convert.(SVector{3, Float64}, nodepositions),
        Int(numpercylinder),
    )
    fil_idx = length(cylinders.per_fil) + 1
    @argcheck !haskey(cylinders.fil_id_2_idx, fil_id)
    cylinders.fil_id_2_idx[fil_id] = fil_idx
    num_new_cyl = length(chembeadpositions) - 1
    cyl_idxs = zeros(Int, num_new_cyl)
    for i in 1:num_new_cyl
        cyl_idx = length(cylinders.per_cyl) + 1
        push!(cylinders.per_cyl, DataPerCylinder(;fil_id))
        cyl_idxs[i] = cyl_idx
    end 
    push!(cylinders.per_fil, DataPerFilament(;
        id= fil_id,
        mon_id_first= full_node_mids[begin],
        mon_id_last= full_node_mids[end]-1,
        monomerstates= collect(monomerstates),
        chembeadpositions,
        cyl_idxs, 
        endloadforces,
        minusend_num_notminimized,
        plusend_num_notminimized,
    ))
    return lastindex(cylinders.per_fil)
end

"""
Remove a filament and its cylinders.

Filament indexes can change from this.
"""
function remove_filament(cylinders::ChemCylinders, fil_id)
    fil_idx = cylinders.fil_id_2_idx[fil_id]
    endfil_idx = length(cylinders.per_fil)
    cyl_idxs = cylinders.per_fil.cyl_idxs[fil_idx]
    for cyl_idx in cyl_idxs
        @assert cylinders.per_cyl.exists[cyl_idx]
        push!(cylinders.holes, cyl_idx)
        cylinders.per_cyl.exists[cyl_idx] = false
    end
    if fil_idx == endfil_idx
        # deleted filament is at end, so just pop
        pop!(cylinders.per_fil)
        delete!(cylinders.fil_id_2_idx, fil_id)
        nothing
    else
        # swap last filament in then pop
        endfil_id = cylinders.per_fil.id[endfil_idx]
        cylinders.per_fil[fil_idx] = cylinders.per_fil[endfil_idx]
        cylinders.fil_id_2_idx[endfil_id] = fil_idx
        pop!(cylinders.per_fil)
        delete!(cylinders.fil_id_2_idx, fil_id)
        endfil_idx => fil_idx
    end
end

"""
Split a filament, return the new `fil_idx`, .
`mon_id` is just to the plus end of the split.
`new_fil_id` is the filament id to assign to the new filament.
Existing filament `fil_idx` are not modified, the new filament is appended.
Monomers on the minus end of the split are added added to the new filament.
Both filaments are marked as not minimized.
"""
function _sever_fila!(cylinders::ChemCylinders, fil_idx, mon_id::Int, new_fil_id)
    numpercylinder = cylinders.numpercylinder
    fil = LazyRow(cylinders.per_fil, fil_idx)
    mon_id_first = fil.mon_id_first
    mon_id_last = fil.mon_id_last
    @argcheck mon_id > mon_id_first+1
    @argcheck mon_id < mon_id_last
    new_fil_idx = length(cylinders.per_fil) + 1
    @argcheck !haskey(cylinders.fil_id_2_idx, new_fil_id)
    cylinders.fil_id_2_idx[new_fil_id] = new_fil_idx
    fil_cyl_idx, mon_frac = get_fil_chem_cyl_idx_frac(
        mon_id,
        mon_id_first,
        mon_id_last,
        numpercylinder,
    )
    plus_cyl_idxs = fil.cyl_idxs[fil_cyl_idx:end]
    plus_chembeadpositions = fil.chembeadpositions[fil_cyl_idx:end]
    plus_monomerstates = fil.monomerstates[mon_id-mon_id_first+begin:end]
    minus_monomerstates = fil.monomerstates[begin:mon_id-mon_id_first+begin-1]
    if mod(mon_id, numpercylinder) == 0
        # no new cylinders are needed
        minus_cyl_idxs = fil.cyl_idxs[begin:fil_cyl_idx-1]
        minus_chembeadpositions = fil.chembeadpositions[begin:fil_cyl_idx]
    else
        # one new cylinder is needed
        new_cyl_idx = length(cylinders.per_cyl) + 1
        minus_cyl_idxs = [fil.cyl_idxs[begin:fil_cyl_idx-1]; new_cyl_idx;]
        minus_chembeadpositions = fil.chembeadpositions[begin:fil_cyl_idx+1]
        push!(cylinders.per_cyl, DataPerCylinder(;fil_id = new_fil_id))
    end
    for cyl_idx in minus_cyl_idxs
        cylinders.per_cyl.fil_id[cyl_idx] = new_fil_id
    end
    # add minus end filament
    push!(cylinders.per_fil, DataPerFilament(;
        id= new_fil_id,
        mon_id_first= mon_id_first,
        mon_id_last= mon_id-1,
        monomerstates= minus_monomerstates,
        chembeadpositions= minus_chembeadpositions,
        cyl_idxs= minus_cyl_idxs, 
        minusend_num_notminimized= length(minus_monomerstates),
        plusend_num_notminimized= length(minus_monomerstates),
    ))
    # update plus end filament
    fil.mon_id_first = mon_id
    fil.monomerstates = plus_monomerstates
    fil.chembeadpositions = plus_chembeadpositions
    fil.cyl_idxs = plus_cyl_idxs
    fil.minusend_num_notminimized = length(plus_monomerstates)
    fil.plusend_num_notminimized = length(plus_monomerstates)
    fil.endloadforces = cylinders.per_fil[new_fil_idx].endloadforces
    new_fil_idx
end

"""
Returns the chem bead positions

The monomers are coarse grained such that every `numpercylinder` monomer is a cylinder,
beads are between two monomers and monomers are linearly interpolated between beads.

chem beads are linearly interpolated between `nodepositions` 
    so that the monomers to the right of the beads have ids divisible by `cylinders.numpercylinder`,
    the first and last beads, can be extended from `nodepositions[begin]`, `nodepositions[end]`, so they won't change when a monomer is (de)polymerized.

The `full_node_mids` are the monomer ids at (slightly plus side of) the `nodepositions`
`full_node_mids[end]` is the last monomer id + 1

                                     |
                          -----+-----|-----+-----
      minus end <----       M  |  M  | (M) |  M        ----> plus end
                          -----+-----|-----+-----
                                     |
                                     ^ A nodeposition is indicated by the line.
    
The monomer id with parenthesis (M) will in `full_node_mids`
"""
function interpolate_chem_beads(full_node_mids::Vector{Int}, nodepositions::Vector{SVector{3,Float64}}, numpercylinder::Int)::Vector{SVector{3,Float64}}
    @argcheck length(full_node_mids) == length(nodepositions)
    @argcheck numpercylinder > 0
    cyl_lengths = full_node_mids[begin+1:end] - full_node_mids[begin:end-1]
    @argcheck all(>(0), cyl_lengths)
    firstmonomerid = full_node_mids[begin]
    firstcylinderid = fld(firstmonomerid,numpercylinder)
    lastmonomerid = full_node_mids[end] - 1
    lastcylinderid= fld(lastmonomerid,numpercylinder)
    numbeads = lastcylinderid - firstcylinderid + 2
    chembeadpositions = fill(SA[NaN,NaN,NaN],numbeads)
    #first bead
    a = - mod(full_node_mids[begin],numpercylinder)
    b = full_node_mids[begin+1] - full_node_mids[begin]
    chembeadpositions[begin] = (1-a/b)*nodepositions[begin] + (a/b)*nodepositions[begin+1]
    #middle beads
    bead_idx = 2
    node_idx = 2
    targetmid = (firstcylinderid+1)*numpercylinder
    while bead_idx < numbeads
        while full_node_mids[node_idx] < targetmid
            node_idx += 1
        end
        a = full_node_mids[node_idx] - targetmid
        b = full_node_mids[node_idx] - full_node_mids[node_idx-1]
        chembeadpositions[bead_idx] = (1-a/b)*nodepositions[node_idx] + (a/b)*nodepositions[node_idx-1]
        bead_idx += 1
        targetmid += numpercylinder
    end
    #last bead
    a = -mod(-full_node_mids[end],numpercylinder)
    b = full_node_mids[end] - full_node_mids[end-1]
    chembeadpositions[end] = (1-a/b)*nodepositions[end] + (a/b)*nodepositions[end-1]
    chembeadpositions
end


"""
Return the node positions with the ends at the actual ends of the filament.

The length of the returned vector will be the same as the length of `chembeadpositions`

All positions will be the same except the first and last which may be moved in if the chem cylinder isn't full.
"""
function _get_nodepositions(chembeadpositions::Vector{SVector{3,Float64}}, mon_id_first::Int, mon_id_last::Int, numpercylinder::Int)::Vector{SVector{3,Float64}}
    nodepositions = copy(chembeadpositions)
    @argcheck mon_id_last > mon_id_first
    # get the expected number of beads based on the monomer ids and numpercylinder
    firstcylinderid = fld(mon_id_first, numpercylinder)
    lastcylinderid = fld(mon_id_last, numpercylinder)
    numbeads = lastcylinderid - firstcylinderid + 2
    @argcheck numbeads == length(chembeadpositions)
    #undo extended ends
    a = mod(mon_id_first,numpercylinder)
    b = numpercylinder
    nodepositions[begin] = (1-a/b)*chembeadpositions[begin] + (a/b)*chembeadpositions[begin+1]
    midlast = mon_id_last + 1
    a = mod(-midlast,numpercylinder)
    nodepositions[end] = (1-a/b)*chembeadpositions[end] + (a/b)*chembeadpositions[end-1]
    nodepositions
end


"""
Set `chembeadpositions` based on `nodepos`

The indexes of `chembeadpositions` and `nodepos` must match

All positions will be the same except the first and last which may be moved out if the chem cylinder isn't full.
"""
function set_nodepositions!(
        chembeadpositions::AbstractVector{SVector{3,Float64}},
        nodepos::AbstractVector{SVector{3,Float64}},
        mon_id_first::Int,
        mon_id_last::Int,
        numpercylinder::Int,
    )::Nothing
    @argcheck eachindex(chembeadpositions) == eachindex(nodepos)
    @argcheck mon_id_last > mon_id_first
    # get the expected number of beads based on the monomer ids and numpercylinder
    firstcylinderid = fld(mon_id_first, numpercylinder)
    lastcylinderid = fld(mon_id_last, numpercylinder)
    numbeads = lastcylinderid - firstcylinderid + 2
    @argcheck numbeads == length(chembeadpositions)
    chembeadpositions .= nodepos
    # Extend first bead to a full cylinder.
    midfirstbead = mon_id_first
    midnextbead = min(fld(midfirstbead,numpercylinder)*numpercylinder + numpercylinder, mon_id_last+1)
    a = - mod(midfirstbead, numpercylinder)
    b = midnextbead - midfirstbead
    chembeadpositions[begin] = (1-a/b)*nodepos[begin] + (a/b)*nodepos[begin+1]
    # Extend last bead to a full cylinder.
    midlastbead = mon_id_last + 1
    midprevbead = max(fld(midlastbead-1,numpercylinder)*numpercylinder, mon_id_first)
    a = - mod(-midlastbead,numpercylinder)
    b = midlastbead - midprevbead
    chembeadpositions[end] = (1-a/b)*nodepos[end] + (a/b)*nodepos[end-1]
    nothing
end


"""
Return the node monomer ids of the filament
"""
function _fil_node_mon_ids(mon_id_first::Int, mon_id_last::Int, numpercylinder::Int)::Vector{Int}
    invnumpercylinder = inv(numpercylinder)
    firstcylinderidfrac = (mon_id_first + 0.5)*invnumpercylinder
    firstcylinderid = Int(round(firstcylinderidfrac,RoundDown))
    nextbeadmid = (firstcylinderid + 1)*numpercylinder
    node_mids = [mon_id_first; nextbeadmid:numpercylinder:mon_id_last; mon_id_last+1]
    node_mids
end

"""
Return the full range of possible mon_ids on a cylinder,
"""
function _fil_cyl_mon_ids(fil_cyl_idx::Int, mon_id_first::Int, mon_id_last::Int, numpercylinder::Int)
    invnumpercylinder = inv(numpercylinder)
    firstcylinderidfrac = (mon_id_first + 0.5)*invnumpercylinder
    firstcylinderid = Int(round(firstcylinderidfrac,RoundDown))
    cyl_id = fil_cyl_idx + firstcylinderid - 1
    start_mid = cyl_id*numpercylinder
    stop_mid = (cyl_id + 1)*numpercylinder - 1
    start_mid:stop_mid
end




"""
Return chem cylinder index on a filament and chem cylinder frac of a monomer id
frac is a float, 0.0 if the monomer is at the chem bead on the minus end of the cylinder,
1.0 if it is at the chem bead on the plus end of the cylinder.
"""
function get_fil_chem_cyl_idx_frac(
        mon_id::Int,
        mon_id_first::Int,
        mon_id_last::Int,
        numpercylinder::Int,
    )
    @argcheck mon_id in mon_id_first:mon_id_last
    invnumpercylinder = inv(numpercylinder)
    cylinderidfrac = (mon_id + 0.5)*invnumpercylinder
    firstcylinderidfrac = (mon_id_first + 0.5)*invnumpercylinder
    firstcylinderid = unsafe_trunc(Int,round(firstcylinderidfrac,RoundDown))
    cylinderid = unsafe_trunc(Int,round(cylinderidfrac,RoundDown))
    cylinderidx= cylinderid - firstcylinderid + 1
    mon_id_on_cyl = mon_id - cylinderid*numpercylinder
    frac = (mon_id_on_cyl + 0.5)*invnumpercylinder
    return cylinderidx, frac
end


"""
Return mech cylinder index on a filament and mech cylinder frac of a monomer id
frac is a float, 0.0 if the monomer is at the mechanics node on the minus end of the cylinder,
1.0 if it is at the mechanics node on the plus end of the cylinder.
"""
function get_fil_mech_cyl_idx_frac(
        mon_id::Int,
        mon_id_first::Int,
        mon_id_last::Int,
        numpercylinder::Int,
    )
    @argcheck mon_id in mon_id_first:mon_id_last
    invnumpercylinder = inv(numpercylinder)
    cylinderidfrac = (mon_id + 0.5)*invnumpercylinder
    firstcylinderidfrac = (mon_id_first + 0.5)*invnumpercylinder
    firstcylinderid = unsafe_trunc(Int,round(firstcylinderidfrac,RoundDown))
    cylinderid = unsafe_trunc(Int,round(cylinderidfrac,RoundDown))
    cylinderidx= cylinderid - firstcylinderid + 1
    #The actual first and last monomer might be moved in if the cylinder isn't full.
    cyl_mon_id_first = max(cylinderid*numpercylinder, mon_id_first)
    cyl_mon_id_last = min(cylinderid*numpercylinder + numpercylinder - 1, mon_id_last)
    cyl_num_mons = cyl_mon_id_last - cyl_mon_id_first + 1
    mon_id_on_cyl = mon_id - cyl_mon_id_first
    frac = (mon_id_on_cyl + 0.5)*inv(cyl_num_mons)
    return cylinderidx, frac
end