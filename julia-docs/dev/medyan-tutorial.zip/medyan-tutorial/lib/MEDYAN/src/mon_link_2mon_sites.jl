"""
Commonly used link_2mon sites
"""

using LinearAlgebra
using StaticArrays


# """
# Test that a type follows the interface and check for basic errors
# """
# function statictest_mon_link_2mon_site(sitetype::Type, link_2mon_statetype::Type, mechparamstype::Type)
#     JET.report_call((
#             sitetype,
#             link_2mon_statetype,
#             mechparamstype,
#             Int,
#             Int,
#             SVector{3,MonomerState},
#             SVector{3,MonomerState},
#             SVector{3,Float64},
#             SVector{3,Float64},
#             SVector{3,Float64},
#             SVector{3,Float64},
#         );
#         # print_inference_success=false,
#     ) do site,link_2mon_state,mechparams,minusftid,plusftid,minusmonomerstates,plusmonomerstates,m_pos,p_pos,m_plusv,p_plusv
#         link_2mon_sitecount(site,link_2mon_state,mechparams,minusftid,plusftid,minusmonomerstates,plusmonomerstates,m_pos,p_pos,m_plusv,p_plusv)::Float64
#     end
# end




"""$PUBLIC
Always returns 1.0
"""
struct MonLink2MonSiteOne
    ftid::Int
    cutoff::Float64
end

cutoff_distance(site::MonLink2MonSiteOne) = site.cutoff

getftid(site::MonLink2MonSiteOne) = site.ftid

mon_link_2mon_sitecount(site::MonLink2MonSiteOne, link_2mon_state::Link2MonState) = 1.0