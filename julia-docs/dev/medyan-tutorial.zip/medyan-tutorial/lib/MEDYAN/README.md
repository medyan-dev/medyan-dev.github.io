# MEDYAN.jl WIP

[![Build Status](https://github.com/medyan-dev/MEDYAN.jl/workflows/CI/badge.svg)](https://github.com/medyan-dev/MEDYAN.jl/actions)
[![docs](https://img.shields.io/badge/docs-dev-blue.svg)](http://medyan.org/julia-docs/dev/)
[![website](https://img.shields.io/website?down_message=medyan.org&up_message=medyan.org&url=https%3A%2F%2Fmedyan.org)](https://medyan.org)

## Warning, the API is very unstable, and this package is not released yet.

Welcome to Papoian Lab’s *Mechanochemical Dynamics of Active Networks* Julia package.

This is based on the C++ medyan command line tool also developed by the Papoian Lab.

Copyright 2022, Papoian lab at the University of Maryland.

This code is distributed under [the license](license.txt) found in this directory, `license.txt`.

## Usage

First install and run Julia https://julialang.org/downloads/

Then if you haven't yet, set up ssh keys with github.

Also, currently you may have to install git and ensure
you have a `.julia/config/startup.jl` with
```julia
ENV["JULIA_PKG_USE_CLI_GIT"]= "true"
```

Finally, to add the current MEDYAN.jl, in Julia run:
```julia
] add git@github.com:medyan-dev/MEDYAN.jl.git
```
To add a specific commit id, for example 2d31e2a, in Julia run:
```julia
] add "git@github.com:medyan-dev/MEDYAN.jl.git"#2d31e2a
```

See the [docs](http://medyan.org/julia-docs) for tutorials and more information.

## Authors

Active developers:

| Name                    | Email             |
|-------------------------|-------------------|
| Haoran Ni               | haoranni@umd.edu  |
| Nathan Zimmerberg       | nzimmerb@umd.edu  |
| Mengxin Gu              | mxgu1234@umd.edu  |

All developers including developers of C++ medyan:

Garegin Papoian (gpapoian@umd.edu), Konstantin Popov, James Komianos, Aravind Chandrasekaran, Qin Ni, Carlos Floyd, Haoran Ni, Nathan Zimmerberg, Joshua Lucker, Mengxin Gu.

All general correspondence about the code and its applications should be directed to Garegin Papoian. All developer and more specific code, installation, and usage correspondence should be directed to Active developers via email or the issue tracker.

## Running tests
In shell:
```sh
cd test
julia --project -e 'using Pkg; Pkg.develop(PackageSpec(path=dirname(pwd()))); Pkg.instantiate()'
julia --project
```
In julia repl:
```julia
include("runtests.jl")
```

You can also include individual test files to run just those tests.

## Running notebooks

To run interactively in a Pluto Notebook, run the following shell commands:
```sh
cd notebooks
julia --project -e 'using Pkg; Pkg.develop(PackageSpec(path=dirname(pwd()))); Pkg.instantiate()'
julia --project -e 'import Pluto; Pluto.run()'
```

To generate static html files, run the following shell commands:

```sh
cd notebooks
julia --project -e 'using Pkg; Pkg.develop(PackageSpec(path=dirname(pwd()))); Pkg.instantiate()'
julia --project runnotebooks.jl
```

## Editing Documentation

First, if you haven't yet, install [quarto](https://quarto.org/docs/get-started/) at least 1.2.

Run the following to check your quarto installation has the julia kernel.
```sh
quarto check jupyter
```

You may have to run the following after updating julia if jupyter doesn't have the latest kernel.
```julia
using Pkg
Pkg.add("IJulia")
Pkg.build("IJulia")
```

Run the following to set up the environment and create a preview.
Any changes to files in `docs` should auto update.

```sh
./docs/make.jl
```

or

```sh
julia docs/make.jl
```

Run the following to refresh the docstrings for the site.

```sh
julia --project=docs docs/make-docstrings.jl
```
