using MEDYAN
using StaticArrays
using LinearAlgebra
using Test

@testset "bonds" begin
    @testset "zero bond" begin
        p = MEDYAN.ZeroBond{1}()
        MEDYAN.test_bond_energy_force_forward_diff(p, ((SA[5.9,1.2,2.0],),), (;))
        MEDYAN.test_bond_energy_force_forward_diff(p, ((SA[5.9,1.2,2.0],),), (;))
        MEDYAN.test_bond_energy_force_at_min(p, ((SA[0,0,0.0],),), (;))
        MEDYAN.test_bond_energy_force_at_min(p, ((SA[0,0,1.0],),), (;))
        p = MEDYAN.ZeroBond{2}()
        MEDYAN.test_bond_energy_force_forward_diff(
            p,
            ((SA[8.9,1.2,2.0],),(SA[5.9,1.2,2.0],),),
            (k=9.2, L0=6.4),
        )
        MEDYAN.test_bond_energy_force_at_min(
            p,
            ((SA[0.0,0.0,6.4],),(SA[0.0,0.0,0.0],),),
            (k=9.2, L0=6.4),
        )
    end
    @testset "position restraint" begin
        p = MEDYAN.PositionRestraint()
        MEDYAN.test_bond_energy_force_forward_diff(p, ((SA[5.9,1.2,2.0],),), (k=0.3, r0=SA[0.0,0.0,0.0]))
        MEDYAN.test_bond_energy_force_forward_diff(p, ((SA[5.9,1.2,2.0],),), (k=0.3, r0=SA[0.0,30.0,0.0]))
        MEDYAN.test_bond_energy_force_at_min(p, ((SA[0,0,0.0],),), (k=0.3, r0=SA[0.0,0.0,0.0]))
        MEDYAN.test_bond_energy_force_at_min(p, ((SA[0,0,1.0],),), (k=0.3, r0=SA[0.0,0.0,1.0]))
    end
    @testset "constant force" begin
        p = MEDYAN.ConstantForce()
        MEDYAN.test_bond_energy_force_forward_diff(
            p,
            ((SA[5.9,1.2,2.0],),),
            (f=SA[0.0,0.0,0.0],),
        )
        MEDYAN.test_bond_energy_force_forward_diff(
            p,
            ((SA[5.9,1.2,2.0],),),
            (f=SA[1.0,2.0,3.0],),
        )
    end
    @testset "distance restraint" begin
        p = MEDYAN.DistanceRestraint()
        MEDYAN.test_bond_energy_force_forward_diff(
            p,
            ((SA[8.9,1.2,2.0],),(SA[5.9,1.2,2.0],),),
            (k=9.2, L0=6.4),
        )
        MEDYAN.test_bond_energy_force_at_min(
            p,
            ((SA[0.0,0.0,6.4],),(SA[0.0,0.0,0.0],),),
            (k=9.2, L0=6.4),
        )
    end
    @testset "branch bending cosine" begin
        p = MEDYAN.BranchBendingCosine()
        for i in 1:1000
            mr = rand(SVector{3, Float64})
            pr = rand(SVector{3, Float64})
            mv = normalize(randn(SVector{3, Float64}))
            pv = normalize(randn(SVector{3, Float64}))
            MEDYAN.test_bond_energy_force_forward_diff(
                p,
                ((mr, mv,),(pr,pv,),),
                (kr=9.2, kbend=10.3, cos0=cos(1.22), sin0=sin(1.22)),
            )
            MEDYAN.test_bond_energy_force_forward_diff(
                p,
                ((mr, mv,),(pr,pv,),),
                (kr=9.2, kbend=10.3, cos0=cos(3.0), sin0=sin(3.0)),
            )
        end
        MEDYAN.test_bond_energy_force_at_min(
            p,
            (
                (SA[0.0,0.0,0.0],SA[1.0,0.0,0.0],),
                (SA[0.0,0.0,0.0],SA[cos(1.22),sin(1.22),0.0],),
            ),
            (kr=9.2, kbend=10.3, cos0=cos(1.22), sin0=sin(1.22)),
        )
    end
    @testset "position direction restraint" begin
        p = MEDYAN.PositionDirectionRestraint()
        for i in 1:1000
            r = rand(SVector{3, Float64})
            r0 = rand(SVector{3, Float64})
            v = normalize(randn(SVector{3, Float64}))
            v0 = normalize(randn(SVector{3, Float64}))
            MEDYAN.test_bond_energy_force_forward_diff(
                p,
                ((r, v,),),
                (kr=9.2, kbend=10.3, r0=r0, v̂0=v0),
            )
        end
        MEDYAN.test_bond_energy_force_at_min(
            p,
            (
                (SA[0.0,0.0,0.5],SA[1.0,0.0,0.0],),
            ),
            (kr=9.2, kbend=10.3, r0=SA[0.0,0.0,0.5], v̂0=SA[1.0,0.0,0.0]),
        )
    end
end