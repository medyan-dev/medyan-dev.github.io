using MEDYAN
using StaticArrays
using Test

@testset "bonds" begin
    p = MEDYAN.PositionRestraint()
    MEDYAN.test_bond_energy_force_forward_diff(p, ((SA[5.9,1.2,2.0],),), (kr=0.3, r0=SA[0.0,0.0,0.0]))
    MEDYAN.test_bond_energy_force_forward_diff(p, ((SA[5.9,1.2,2.0],),), (kr=0.3, r0=SA[0.0,30.0,0.0]))
    MEDYAN.test_bond_energy_force_at_min(p, ((SA[0,0,0.0],),), (kr=0.3, r0=SA[0.0,0.0,0.0]))
    MEDYAN.test_bond_energy_force_at_min(p, ((SA[0,0,1.0],),), (kr=0.3, r0=SA[0.0,0.0,1.0]))
end