using MEDYAN
using Test
using StaticArrays

@testset "Neighbor lists" begin
    @testset "Triangle-bead neighbor list" begin
        # Octahedron.
        dm = MEDYAN.create_membranemesh()
        MEDYAN.initmesh!_vertex_triangle(dm, 6, [SA[1,2,3], SA[1,3,4], SA[1,4,5], SA[1,5,2], SA[6,5,4], SA[6,4,3], SA[6,3,2], SA[6,2,5]])
        sm = MEDYAN.StaticHalfedgeMesh(dm)
        
        # Define coordinates and update static mesh cache.
        offsetvertex = 9
        beadcoordrange = 1:offsetvertex
        x = Float64[
            # Beads.
            0, 0, 0,
            1, 1, 1,
            2, 2, 2,
            # Vertices.
            0, 0, 1,
            0, 1, 0,
            -1, 0, 0,
            0, -1, 0,
            1, 0, 0,
            0, 0, -1,
        ]
        MEDYAN.cachecoordindices!(sm, offsetvertex)

        boxsize = SA[10,10,10]
        cutoff = 1.5 - sqrt(2/3)
        nl = MEDYAN.triangle_bead_neighborlist(cutoff, 0.0, boxsize, (sm,), x, beadcoordrange)
        @test length(nl) == 9
        @test count(pair->pair.ixbead==1, nl) == 8
        @test count(pair->pair.ixbead==4, nl) == 1
        for pair ∈ nl
            @test all(pair.ixtriangle .> offsetvertex)
            @test all((pair.ixtriangle .- offsetvertex) .% 3 .== 1)
            @test pair.ixbead <= offsetvertex
            @test pair.ixbead % 3 == 1
        end

        cutoff = 1.0 - sqrt(2/3)
        nl = MEDYAN.triangle_bead_neighborlist(cutoff, 0.0, boxsize, (sm,), x, beadcoordrange)
        @test length(nl) == 8
        @test count(pair->pair.ixbead==1, nl) == 8

        cutoff = 4.5 - sqrt(2/3)
        nl = MEDYAN.triangle_bead_neighborlist(cutoff, 0.0, boxsize, (sm,), x, beadcoordrange)
        @test length(nl) == 24
    end
end
