using MEDYAN
using Test
using StaticArrays
using LinearAlgebra

@testset "Neighbor lists" begin
    @testset "Triangle-bead neighbor list" begin
        # Octahedron.
        dm = MEDYAN.create_membranemesh()
        MEDYAN.initmesh!_vertex_triangle(dm, 6, [SA[1,2,3], SA[1,3,4], SA[1,4,5], SA[1,5,2], SA[6,5,4], SA[6,4,3], SA[6,3,2], SA[6,2,5]])
        sm = MEDYAN.StaticHalfedgeMesh(dm)
        
        # Define coordinates and update static mesh cache.
        offsetvertex = 9
        beadcoordrange = 1:offsetvertex
        x = Float64[
            # Beads.
            0, 0, 0,
            1, 1, 1,
            2, 2, 2,
            # Vertices.
            0, 0, 1,
            0, 1, 0,
            -1, 0, 0,
            0, -1, 0,
            1, 0, 0,
            0, 0, -1,
        ]
        MEDYAN.cachecoordindices!(sm, offsetvertex)

        boxsize = SA[10,10,10]
        cutoff = 1.5 - sqrt(2/3)
        nl = MEDYAN.triangle_bead_neighborlist(cutoff, 0.0, boxsize, (sm,), x, beadcoordrange)
        @test length(nl) == 9
        @test count(pair->pair.ixbead==1, nl) == 8
        @test count(pair->pair.ixbead==4, nl) == 1
        for pair ∈ nl
            @test all(pair.ixtriangle .> offsetvertex)
            @test all((pair.ixtriangle .- offsetvertex) .% 3 .== 1)
            @test pair.ixbead <= offsetvertex
            @test pair.ixbead % 3 == 1
        end

        cutoff = 1.0 - sqrt(2/3)
        nl = MEDYAN.triangle_bead_neighborlist(cutoff, 0.0, boxsize, (sm,), x, beadcoordrange)
        @test length(nl) == 8
        @test count(pair->pair.ixbead==1, nl) == 8

        cutoff = 4.5 - sqrt(2/3)
        nl = MEDYAN.triangle_bead_neighborlist(cutoff, 0.0, boxsize, (sm,), x, beadcoordrange)
        @test length(nl) == 24
    end
    @testset "Map nearby monomers" begin
        x = SA[1.0,0.0,0.0]
        y = SA[0.0,1.0,0.0]
        z = SA[0.0,0.0,1.0]
        function count_in_range(
                name::MonomerName,
                pos::SVector{3,Float64},
                plusv::SVector{3,Float64},
                states,
                out::Int,
            )
            out+1
        end
        @testset "Empty context" begin
            c, s = MEDYAN.example_actin_mech_context(CubicGrid(SA[2,2,2],500.0); chem_max_search_dist=50.0)
            mon_count = MEDYAN.map_nearby_monomers(
                count_in_range,
                c,
                10x+10y+10z,
                1,
                27.0,
                0,
            )
            @test mon_count isa Int
            @test iszero(mon_count)
        end
        @testset "One filament" begin
            c, s = MEDYAN.example_actin_mech_context(CubicGrid(SA[2,2,2],500.0); chem_max_search_dist=50.0)
            monomerstates = ones(MonomerState, 20)
            nodepos1 = [10x + 10y + 10z, 64x + 10y + 10z]
            fid1 = chem_newfilament!(c;
                monomerstates,
                nodepositions = nodepos1,
                node_mids = [0,],
            )
            mon_count = MEDYAN.map_nearby_monomers(
                count_in_range,
                c,
                10x+10y+10z,
                1,
                27.0,
                0,
            )
            @test mon_count isa Int
            @test iszero(mon_count) # not minimized yet so not tracked

            MEDYAN.helper_mark_monomers_minimized!(c)
            mon_count = MEDYAN.map_nearby_monomers(
                count_in_range,
                c,
                10x+10y+10z,
                1,
                27.0,
                0,
            )
            @test mon_count isa Int
            @test mon_count == 10
        end
        @testset "Random filaments" begin
            c, s = MEDYAN.example_actin_mech_context(CubicGrid(SA[2,2,2],500.0); chem_max_search_dist=60.0)
            for i in 1:500
                num_mons = rand(20:200)
                monomerstates = ones(MonomerState, num_mons)
                MEDYAN.newfilament_rand!(c, monomerstates)
            end
            mon_count = MEDYAN.map_nearby_monomers(
                count_in_range,
                c,
                10x+10y+10z,
                1,
                27.0,
                0,
            )
            @test iszero(mon_count) # not minimized yet so not tracked

            MEDYAN.helper_mark_monomers_minimized!(c)
            for i in 1:100
                p = MEDYAN.randompoint(CubicGrid(SA[2,2,2],500.0))
                mon_count = MEDYAN.map_nearby_monomers(
                    count_in_range,
                    c,
                    p,
                    1,
                    50.0,
                    0,
                )
                mon_count_naive = MEDYAN.map_nearby_monomers_naive(
                    count_in_range,
                    c,
                    p,
                    1,
                    50.0,
                    0,
                )
                # @show mon_count
                @test mon_count == mon_count_naive
            end
        end
    end
end
