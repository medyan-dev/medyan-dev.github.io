using MEDYAN
using StaticArrays
using Random
using LinearAlgebra
using Test

@testset "Link_2mon Mechanics" begin
    x= SA[1.0,0.0,0.0]
    y= SA[0.0,1.0,0.0]
    z= SA[0.0,0.0,1.0]
    o= zero(x)
    @testset "Nothing" begin
        data = nothing
        params = nothing
        @test MEDYAN.helper_test_link_2mon_force_at_min(data, params, x, y, z, z)
        for i in 1:10000
            mr= 100*randn(SVector{3,Float64})
            pr= 100*randn(SVector{3,Float64})
            mv̂= normalize(randn(SVector{3,Float64}))
            pv̂= normalize(randn(SVector{3,Float64}))
            MEDYAN.helper_test_link_2mon_force_forward_diff(data, params, mr, pr, mv̂, pv̂)
        end
    end
    @testset "RestraintMechParams" begin
        data = (mr0 = x, mv̂0 = x)
        params = MEDYAN.RestraintMechParams(1.0,100.0)
        @test MEDYAN.helper_test_link_2mon_force_at_min(data, params, x, y, x, z)
        
        for i in 1:10000
            data = (mr0 = 100*randn(SVector{3,Float64}), mv̂0 = normalize(randn(SVector{3,Float64})))
            mr= 100*randn(SVector{3,Float64})
            pr= 100*randn(SVector{3,Float64})
            mv̂= normalize(randn(SVector{3,Float64}))
            pv̂= normalize(randn(SVector{3,Float64}))
            MEDYAN.helper_test_link_2mon_force_forward_diff(data, params, mr, pr, mv̂, pv̂)
        end
    end
    @testset "RelativeRestraintMechParams" begin

        params = MEDYAN.RelativeRestraintMechParams(1.0,100.0,10y+10x,x)
        data = nothing
        @test MEDYAN.helper_test_link_2mon_force_at_min(data, params, o, 10x+10z, x, x)
        
        params = MEDYAN.RelativeRestraintMechParams(1.0,100.0,10y,y)
        @test MEDYAN.helper_test_link_2mon_force_at_min(data, params, o, 10z, x, z)
        @test_throws AssertionError MEDYAN.helper_test_link_2mon_force_at_min(data, params, o, 10z, x, -z)

        params = MEDYAN.RelativeRestraintMechParams(1.0,100.0,10y,z)
        @test MEDYAN.helper_test_link_2mon_force_at_min(data, params, o, 10z, x, -y)
        @test_throws AssertionError MEDYAN.helper_test_link_2mon_force_at_min(data, params, o, 10z, x, y)


        for i in 1:100000
            mr= 100*randn(SVector{3,Float64})
            pr= 100*randn(SVector{3,Float64})
            mv̂= normalize(randn(SVector{3,Float64}))
            pv̂= normalize(randn(SVector{3,Float64}))
            params = MEDYAN.RelativeRestraintMechParams(1.0,100.0,SA[10*rand(),10*rand()+1E-2,0.0],normalize(randn(SVector{3,Float64})))
            if norm((pr-mr) - ((pr-mr)⋅mv̂)*mv̂) > 1E-3
                MEDYAN.helper_test_link_2mon_force_forward_diff(data, params, mr, pr, mv̂, pv̂)
            end
        end
    end
    @testset "DistanceRestraintMechParams" begin
        params = MEDYAN.DistanceRestraintMechParams(3.0)
        data = (L0=2.0,)
        @test MEDYAN.helper_test_link_2mon_force_at_min(data, params, o, 2x, x, x)
        @test MEDYAN.helper_test_link_2mon_force_at_min(data, params, o, 2z, x, x)
        for i in 1:100000
            mr= 100*randn(SVector{3,Float64})
            pr= 100*randn(SVector{3,Float64})
            mv̂= normalize(randn(SVector{3,Float64}))
            pv̂= normalize(randn(SVector{3,Float64}))
            params = MEDYAN.DistanceRestraintMechParams(rand()*10.0)
            data = (L0=rand()*10.0,)
            MEDYAN.helper_test_link_2mon_force_forward_diff(data, params, mr, pr, mv̂, pv̂)
        end
    end
    @testset "ConstantForceMechParams" begin
        params = MEDYAN.ConstantForceMechParams()
        state = (f=2x+3y-z,)
        #this force has no minimum
        @test_throws AssertionError MEDYAN.helper_test_link_2mon_force_at_min(state, params, o, 2x, x, x)
        for i in 1:100000
            mr= 100*randn(SVector{3,Float64})
            pr= 100*randn(SVector{3,Float64})
            mv̂= normalize(randn(SVector{3,Float64}))
            pv̂= normalize(randn(SVector{3,Float64}))
            params = MEDYAN.ConstantForceMechParams()
            state = (f=100*randn(SVector{3,Float64}),)
            MEDYAN.helper_test_link_2mon_force_forward_diff(state, params, mr, pr, mv̂, pv̂)
        end
    end
    @testset "BranchBendingCosineMechParams" begin
        params = MEDYAN.BranchBendingCosineMechParams(1.0,100.0,cos(70*π/180),sin(70*π/180))
        data = nothing
        @test MEDYAN.helper_test_link_2mon_force_at_min(data, params, o, o, x, cos(70*π/180)*x + sin(70*π/180)*y)
        @test MEDYAN.helper_test_link_2mon_force_at_min(data, params, o, o, x, cos(70*π/180)*x + sin(70*π/180)*z)

        @test MEDYAN.helper_test_link_2mon_force_at_min(data, params, 10z, 10z, cos(70*π/180)*x + sin(70*π/180)*y, x)
        @test_throws AssertionError MEDYAN.helper_test_link_2mon_force_at_min(data, params, o, 10z, x, cos(70*π/180)*x + sin(70*π/180)*y)
        @test_throws AssertionError MEDYAN.helper_test_link_2mon_force_at_min(data, params, o, 10z, x, y)

        for i in 1:100000
            mr= 100*randn(SVector{3,Float64})
            pr= 100*randn(SVector{3,Float64})
            mv̂= normalize(randn(SVector{3,Float64}))
            pv̂= normalize(randn(SVector{3,Float64}))
            MEDYAN.helper_test_link_2mon_force_forward_diff(data, params, mr, pr, mv̂, pv̂)
        end
    end

end