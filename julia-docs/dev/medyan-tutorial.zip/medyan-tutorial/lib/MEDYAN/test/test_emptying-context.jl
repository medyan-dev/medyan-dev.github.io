using MEDYAN
using StaticArrays
using Test

@testset "empty! Context" begin
    startc, s, fida1, fida2, fidb1, fidb2 = MEDYAN.example_all_sites_context(; check_sitecount_error=true)

    c = deepcopy(startc)
    empty!(startc)
    MEDYAN.chem_removefilament!(c;
        ftid = s.filament.a,
        fid = fida1,
        warniflink_2mon_removed = false,
    )
    MEDYAN.chem_removefilament!(c;
        ftid = s.filament.a,
        fid = fida2,
        warniflink_2mon_removed = false,
    )
    MEDYAN.chem_removefilament!(c;
        ftid = s.filament.b,
        fid = fidb1,
        warniflink_2mon_removed = false,
    )
    MEDYAN.chem_removefilament!(c;
        ftid = s.filament.b,
        fid = fidb2,
        warniflink_2mon_removed = false,
    )
    # reset decimated_2mon sites to get filaments to be "fully" deleted.
    MEDYAN.helper_reset_decimated_2mon_site_monomers!(c)
    for cid in 1:length(c.grid)
        for dsid in 1:length(c.agentnames.diffusingspeciesnames)
            MEDYAN.setdiffusingspeciescount!(c.chemistryengine,dsid,cid,0)
        end
        for fxsid in 1:length(c.agentnames.fixedspeciesnames)
            MEDYAN.setfixedspeciescount!(c.chemistryengine,fxsid,cid,0)
        end
    end
    @test c.chemistryengine.fixedcounts == startc.chemistryengine.fixedcounts
    @test c.chemistryengine.diffusingcounts == startc.chemistryengine.diffusingcounts
    
end