using MEDYAN
using Test
using StaticArrays
using Distributions
using Dictionaries
using Random

#=
Test the `_calc_drag_coefficents` function
Currently this uses the equation from:
https://gitlab.com/f-nedelec/cytosim/-/blob/2034e708f676713fd7caa8ff974cbcf8120f9bc4/src/sim/fiber.cc#L554-592 with a few modifications for
simplicity, but gets similar drag coefficents.
Th filament drag, is then divided among the nodes,
by how much length each represents.
=#
@testset "Filament drag unit test" begin
    for num_monomers in (2,3,400)
        for numpercylinder in (1,2,7,19,31,40)
            for starting_mid in (0,1,-331,400)
                monomerspacing = 2.7
                grid= CubicGrid((1,1,1),500*1E3)
                agent_names = MEDYAN.AgentNames(
                    filamentnames= [(:a,[
                                            :plusend,
                                            :minusend,
                                            :middle,
                                        ]),
                    ],
                )
                s= begin
                    s= MEDYAN.SysDef(agent_names)
                    add_filament_params!(s, :a, MEDYAN.FilamentMechParams(;
                        radius= 3.5,
                        spacing= monomerspacing,
                        klength= 4000.0,
                        kangle= 40*672.0,
                        numpercylinder,
                        max_num_unmin_end= 1000,
                    ))
                end
                fil_len = num_monomers*monomerspacing
                monomerstates= zeros(UInt8,num_monomers)
                monomerstates[1:end] .= s.state.a.middle
                monomerstates[1] = s.state.a.minusend
                monomerstates[end] = s.state.a.plusend
                viscosity=1E-6
                ctx = MEDYAN.Context(s,grid;β=4.2,viscosity,g_tol=1E-3,shake_before_minimization=false)
                set_enable_cylinder_volume_exclusion!(ctx,false)
                fid= MEDYAN.chem_newfilament!(ctx;
                    ftid= s.filament.a,
                    monomerstates,
                    node_mids = [0,],
                    nodepositions = [SA[-fil_len/2,0,0],SA[fil_len/2,0,0]],
                )
                drag = reshape(MEDYAN._calc_drag_coefficents(MEDYAN.ForceContext(ctx)), 3, :)
                drag_radius = 3.5
                drag_length = 5E3 # using default value from cytosim, converted to nm.
                drag_cylinder = MEDYAN.cytosim_cylinder_drag(viscosity, drag_radius, drag_length, fil_len)
                @test abs(sum(drag) - drag_cylinder*3) < 1E-7
                node_pos = fil_node_positions(ctx, 1, fid)
                for i in 1:3
                    # Center of drag
                    @test abs(sum(eachindex(node_pos)) do j
                        node_pos[j][i]*drag[i,j]
                    end) < 1E-12
                    # uniform drag in x, y and z
                    @test drag[1,:] == drag[i,:]
                end
            end
        end
    end
end