using MEDYAN
using Test
using StaticArrays
using Distributions
using Dictionaries
using Random

"""
Return the expectation and variance of the average number of monomers added.
Based on buckling theory.
"""
function bucklingtheory(k∠; boxlength=500.0, monomerspacing=2.7, runtime=0.25, trials= 100, β=MEDYAN.default_β)
    EI= k∠*monomerspacing
    L= boxlength*√3
    Pcr= π^2*EI/(L^2)
    rate = 100.0*exp(-β*Pcr*monomerspacing)
    dist = Poisson(2*rate*runtime)
    mean(dist), var(dist)/trials
end

"""
Return the expectation and variance of the average number of monomers added.
Based on buckling theory.
"""
function bucklingtheoryfixedminus(k∠; boxlength=500.0, monomerspacing=2.7, runtime=0.25, trials= 100, β=MEDYAN.default_β)
    EI= k∠*monomerspacing
    L= boxlength*√3*0.7#because one end is now fixed in rotation
    Pcr= π^2*EI/(L^2)
    rate = 100.0*exp(-β*Pcr*monomerspacing)
    dist = Poisson(rate*runtime)
    mean(dist), var(dist)/trials
end

"""
Run a sim and return the average number of monomers added.
"""
function bucklingtest(k∠; boxlength=500.0, monomerspacing=2.7, runtime=0.25, trials= 100, β=MEDYAN.default_β)
	minimizationtime=0.005
	grid= CubicGrid((1,1,1),boxlength)
	agent_names = MEDYAN.AgentNames(
		filamentnames= [(:a,[
	                            :plusend,
	                            :minusend,
	                            :middle,
	                        ]),
		],
	)
	s= begin
		s= MEDYAN.SysDef(agent_names)

		add_filament_params!(s, :a, MEDYAN.FilamentMechParams(
	        radius= 3.0,
	        spacing= monomerspacing,
	        klength= 40000.0,
	        kangle= k∠,
			numpercylinder= 20,
			max_num_unmin_end= 1000,
	    ))
		
		#minus end polymerization
		addfilamentend_reaction!(s, :a, :pm, true, 
			[:minusend]=>[:minusend,:middle], monomerspacing,
			"-->", 100.0, 0
		)
		#plus end polymerization
		addfilamentend_reaction!(s, :a, :pp, false,
			[:plusend]=>[:middle,:plusend], monomerspacing,
			"-->", 100.0, 0,
		)
	end
	begin
		NMonomers= 1+round(Int,grid.compartmentsize*grid.n[1]*sqrt(3)/monomerspacing,RoundUp)
		monomerstates= zeros(UInt8,NMonomers)
		monomerstates[1:end] .= s.state.a.middle
		monomerstates[1] = s.state.a.minusend
		monomerstates[end] = s.state.a.plusend
	end
	cinit= MEDYAN.Context(s,grid;β,viscosity=1E-6,g_tol=1E-3,)
	set_mechboundary!(cinit, MEDYAN.boundary_box(grid; stiffness=100.0))
	set_enable_cylinder_volume_exclusion!(cinit,false)
	fidx = MEDYAN.make_fila!(cinit;
		fila_type=:a,
		mono_states=monomerstates,
		node_mids = [0,],
		node_positions = [SA[0.0,0.0,0.0], SVector(grid.compartmentsize .* grid.n)].+ Ref(MEDYAN.cornerof(grid)),
	)
	MEDYAN.minimize_energy!(cinit; brownian_motion_time=1E-3)
	n = round(Int,runtime/minimizationtime)
	totalmonomersadded = zeros(Int,trials)
	
	for trial in 1:trials
		c= deepcopy(cinit)
		for i in 1:n
			MEDYAN.run_chemistry!(c,minimizationtime)
			MEDYAN.minimize_energy!(c; brownian_motion_time=Inf)
		end
		finalmonomercount=length(MEDYAN.fila_mono_states(c, fidx))
		totalmonomersadded[trial] = finalmonomercount - NMonomers
	end
	# @show totalmonomersadded
	return sum(totalmonomersadded)/trials
end

"""
Run a sim and return the average number of monomers added.
"""
function bucklingtestfixedminus(k∠; boxlength=500.0, monomerspacing=2.7, runtime=0.25, trials= 100, β=MEDYAN.default_β)
	minimizationtime=0.005
	grid= CubicGrid((1,1,1),boxlength)
	agent_names = MEDYAN.AgentNames(
		filamentnames= [(:a,[
	                            :plusend,
	                            :minusend,
	                            :middle,
                                :restrained,
	                        ]),
		],
	)
	s= begin
		s= MEDYAN.SysDef(agent_names)

		add_filament_params!(s, :a, MEDYAN.FilamentMechParams(
	        radius= 3.0,
	        spacing= monomerspacing,
	        klength= 40000.0,
	        kangle= k∠,
			numpercylinder= 20,
			max_num_unmin_end= 1000,
	    ))
		MEDYAN.add_link_type!(s,
			name=:restraint,
			description="restrain the direction of the filament",
			places=[MEDYAN.FilaTipIdx(),],
			# (:kr, :kbend, :r0, :v̂0,)
			bonds=[MEDYAN.BondConfig(
				bond=MEDYAN.PositionDirectionRestraint(),
				input=(1,),
				param=(kr=100, kbend=k∠*1000),
				state=(r0=SA[NaN,NaN,NaN], v̂0=SA[NaN,NaN,NaN])
			)]
		)
		
		#minus end polymerization
		addfilamentend_reaction!(s, :a, :pm, true, 
			[:minusend]=>[:minusend,:middle], monomerspacing,
			"-->", 100.0, 0
		)
		#plus end polymerization
		addfilamentend_reaction!(s, :a, :pp, false,
			[:plusend]=>[:middle,:plusend], monomerspacing,
			"-->", 100.0, 0,
		)
	end
	begin
		NMonomers= 1+round(Int,grid.compartmentsize*grid.n[1]*sqrt(3)/monomerspacing,RoundUp)
		monomerstates= zeros(UInt8,NMonomers)
		monomerstates[1:end] .= s.state.a.middle
		monomerstates[1] = s.state.a.restrained
		monomerstates[end] = s.state.a.plusend
	end
	cinit = MEDYAN.Context(s,grid;β,viscosity=1E-6,g_tol=1E-3,)
	set_mechboundary!(cinit, MEDYAN.boundary_box(grid; stiffness=100.0))
	set_enable_cylinder_volume_exclusion!(cinit,false)
	fidx = MEDYAN.make_fila!(cinit;
		fila_type=:a,
		mono_states=monomerstates,
		node_mids = [0,],
		node_positions = [SA[0.0,0.0,0.0], SVector(grid.compartmentsize .* grid.n)].+ Ref(MEDYAN.cornerof(grid)),
	)
	minus_end = MEDYAN.FilaTipIdx(cinit, fidx, -)
	MEDYAN.make_link!(cinit,
		link_type=:restraint,
		places=(minus_end,),
		bond_states=((;
			r0=MEDYAN.get_position(cinit, minus_end),
			v̂0=MEDYAN.get_directions(cinit, minus_end)[1],
		),),
	)
	MEDYAN.minimize_energy!(cinit; brownian_motion_time=1E-3)
	n = round(Int,runtime/minimizationtime)
	totalmonomersadded = zeros(Int,trials)
	
	for trial in 1:trials
		c= deepcopy(cinit)
		for i in 1:n
			MEDYAN.run_chemistry!(c,minimizationtime)
			MEDYAN.minimize_energy!(c,brownian_motion_time=Inf)
		end
		finalmonomercount=length(MEDYAN.fila_mono_states(c, fidx))
		totalmonomersadded[trial] = finalmonomercount - NMonomers
	end
	return sum(totalmonomersadded)/trials
end

@testset "Filament buckling and polymerization rate change" begin
    Random.seed!(1234)
    trials = 5
    sigmas = 4.0
    for k∠ in (50000.0, 20000.0)
        meantheory, vartheory = bucklingtheoryfixedminus(k∠; trials)
        # @show √vartheory
        # @show meantheory
        testval = bucklingtestfixedminus(k∠; trials)
        @test  testval < meantheory + sigmas*√vartheory
        @test  testval > meantheory - sigmas*√vartheory
    end
    for k∠ in (100000.0, 50000.0)
        meantheory, vartheory = bucklingtheory(k∠; trials)
        # @show √vartheory
        # @show meantheory
        testval = bucklingtest(k∠; trials)
        @test  testval < meantheory + sigmas*√vartheory
        @test  testval > meantheory - sigmas*√vartheory
    end
end