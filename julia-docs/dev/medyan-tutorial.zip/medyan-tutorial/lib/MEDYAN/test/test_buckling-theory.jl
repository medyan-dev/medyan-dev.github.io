using MEDYAN
using Test
using StaticArrays
using Distributions
using Dictionaries
using Random

"""
Return the expectation and variance of the average number of monomers added.
Based on buckling theory.
"""
function bucklingtheory(k∠; boxlength=500.0, monomerspacing=2.7, runtime=0.25, trials= 100, β=MEDYAN.default_β)
    EI= k∠*monomerspacing
    L= boxlength*√3
    Pcr= π^2*EI/(L^2)
    rate = 100.0*exp(-β*Pcr*monomerspacing)
    dist = Poisson(2*rate*runtime)
    mean(dist), var(dist)/trials
end

"""
Return the expectation and variance of the average number of monomers added.
Based on buckling theory.
"""
function bucklingtheoryfixedminus(k∠; boxlength=500.0, monomerspacing=2.7, runtime=0.25, trials= 100, β=MEDYAN.default_β)
    EI= k∠*monomerspacing
    L= boxlength*√3*0.7#because one end is now fixed in rotation
    Pcr= π^2*EI/(L^2)
    rate = 100.0*exp(-β*Pcr*monomerspacing)
    dist = Poisson(rate*runtime)
    mean(dist), var(dist)/trials
end

"""
Run a sim and return the average number of monomers added.
"""
function bucklingtest(k∠; boxlength=500.0, monomerspacing=2.7, runtime=0.25, trials= 100, β=MEDYAN.default_β)
	minimizationtime=0.005
	grid= CubicGrid((1,1,1),boxlength)
	agentnames = MEDYAN.AgentNames(
		filamentnames= [(:a,[
	                            :plusend,
	                            :minusend,
	                            :middle,
	                        ]),
		],
	)
	boundingplanes = 10.0 .* [SA[-1.0,0.0,0.0,0.0],
		SA[1.0,0.0,0.0,grid.compartmentsize*grid.n[1]],
		SA[0.0,-1.0,0.0,0.0],
		SA[0.0,1.0,0.0,grid.compartmentsize*grid.n[2]],
		SA[0.0,0.0,-1.0,0.0],
		SA[0.0,0.0,1.0,grid.compartmentsize*grid.n[3]]
	]
	s= begin
		s= MEDYAN.SysDef(agentnames)

		add_filament_params!(s, :a, MEDYAN.FilamentMechParams(
	        radius= 3.0,
	        spacing= monomerspacing,
	        klength= 40000.0,
	        kangle= k∠,
			numpercylinder= 20,
			max_num_unmin_end= 1000,
	    ))
		
		#minus end polymerization
		addfilamentend_reaction!(s, :a, :pm, true, 
			[:minusend]=>[:minusend,:middle], monomerspacing,
			"-->", 100.0, 0
		)
		#plus end polymerization
		addfilamentend_reaction!(s, :a, :pp, false,
			[:plusend]=>[:middle,:plusend], monomerspacing,
			"-->", 100.0, 0,
		)
	end
	begin
		NMonomers= 1+round(Int,grid.compartmentsize*grid.n[1]*sqrt(3)/monomerspacing,RoundUp)
		monomerstates= zeros(UInt8,NMonomers)
		monomerstates[1:end] .= s.state.a.middle
		monomerstates[1] = s.state.a.minusend
		monomerstates[end] = s.state.a.plusend
	end
	cinit= MEDYAN.Context(s,grid;β,g_tol=1E-4,)
	set_mechboundary!(cinit; planes=boundingplanes)
	set_enable_cylinder_volume_exclusion!(cinit,false)
	fid= MEDYAN.chem_newfilament!(cinit;
		ftid= s.filament.a,
		monomerstates,
		node_mids = [0,],
		nodepositions = [SA[0.0,0.0,0.0], SVector(grid.compartmentsize .* grid.n)],
	)
	MEDYAN.minimize_energy!(cinit)
	n = round(Int,runtime/minimizationtime)
	totalmonomersadded = zeros(Int,trials)
	
	Threads.@threads for trial in 1:trials
		c= deepcopy(cinit)
		for i in 1:n
			MEDYAN.run_chemistry!(c,minimizationtime)
			MEDYAN.minimize_energy!(c)
		end
		finalmonomercount=length(fil_mon_states(c, s.filament.a, fid))
		totalmonomersadded[trial] = finalmonomercount - NMonomers
	end
	# @show totalmonomersadded
	return sum(totalmonomersadded)/trials
end

"""
Run a sim and return the average number of monomers added.
"""
function bucklingtestfixedminus(k∠; boxlength=500.0, monomerspacing=2.7, runtime=0.25, trials= 100, β=MEDYAN.default_β)
	minimizationtime=0.005
	grid= CubicGrid((1,1,1),boxlength)
	agentnames = MEDYAN.AgentNames(
		filamentnames= [(:a,[
	                            :plusend,
	                            :minusend,
	                            :middle,
                                :restrained,
	                        ]),
		],
        link_2mon_names= [:restraint,]
	)
	boundingplanes = 10.0 .* [SA[-1.0,0.0,0.0,0.0],
		SA[1.0,0.0,0.0,grid.compartmentsize*grid.n[1]],
		SA[0.0,-1.0,0.0,0.0],
		SA[0.0,1.0,0.0,grid.compartmentsize*grid.n[2]],
		SA[0.0,0.0,-1.0,0.0],
		SA[0.0,0.0,1.0,grid.compartmentsize*grid.n[3]]
	]
	s= begin
		s= MEDYAN.SysDef(agentnames)

		add_filament_params!(s, :a, MEDYAN.FilamentMechParams(
	        radius= 3.0,
	        spacing= monomerspacing,
	        klength= 40000.0,
	        kangle= k∠,
			numpercylinder= 20,
			max_num_unmin_end= 1000,
	    ))

        add_link_2mon!(s,
            :restraint,
            Link2MonState((;),(mr0 = zero(SVector{3,Float64}),mv̂0 = zero(SVector{3,Float64}))),
            MEDYAN.RestraintMechParams(kr=100.0,kv̂=k∠*1000),
        )
		
		#minus end polymerization
		addfilamentend_reaction!(s, :a, :pm, true, 
			[:minusend]=>[:minusend,:middle], monomerspacing,
			"-->", 100.0, 0
		)
		#plus end polymerization
		addfilamentend_reaction!(s, :a, :pp, false,
			[:plusend]=>[:middle,:plusend], monomerspacing,
			"-->", 100.0, 0,
		)
	end
	begin
		NMonomers= 1+round(Int,grid.compartmentsize*grid.n[1]*sqrt(3)/monomerspacing,RoundUp)
		monomerstates= zeros(UInt8,NMonomers)
		monomerstates[1:end] .= s.state.a.middle
		monomerstates[1] = s.state.a.restrained
		monomerstates[end] = s.state.a.plusend
	end
	cinit= MEDYAN.Context(s,grid;β,g_tol=1E-4,)
	set_mechboundary!(cinit; planes=boundingplanes)
	set_enable_cylinder_volume_exclusion!(cinit,false)
	fid= MEDYAN.chem_newfilament!(cinit;
		ftid= s.filament.a,
		monomerstates,
		node_mids = [0,],
		nodepositions = [SA[0.0,0.0,0.0], SVector(grid.compartmentsize .* grid.n)],
	)
	eqrv = mon_position_plusvector(cinit, MonomerName(s.filament.a, fid, 0))
    MEDYAN.chem_newlink_2mon!(cinit,
		s.link_2mon.restraint,#ltid 
		MonomerName(s.filament.a, fid, 0)=>
		MonomerName(s.filament.a, fid, 0);
		changedmechstate = (mr0 = eqrv[1], mv̂0 = eqrv[2]),
	)
	MEDYAN.minimize_energy!(cinit)
	n = round(Int,runtime/minimizationtime)
	totalmonomersadded = zeros(Int,trials)
	
	Threads.@threads for trial in 1:trials
		c= deepcopy(cinit)
		for i in 1:n
			MEDYAN.run_chemistry!(c,minimizationtime)
			MEDYAN.minimize_energy!(c)
		end
		finalmonomercount=length(fil_mon_states(c, s.filament.a, fid))
		totalmonomersadded[trial] = finalmonomercount - NMonomers
	end
	return sum(totalmonomersadded)/trials
end

@testset "Filament buckling and polymerization rate change" begin
    Random.seed!(1234)
	trials = 5
    sigmas = 4.0 
    for k∠ in (50000.0, 20000.0)
        meantheory, vartheory = bucklingtheoryfixedminus(k∠; trials)
        # @show √vartheory
        # @show meantheory
        testval = bucklingtestfixedminus(k∠; trials)
        @test  testval < meantheory + sigmas*√vartheory
        @test  testval > meantheory - sigmas*√vartheory
    end
    for k∠ in (100000.0, 50000.0)
        meantheory, vartheory = bucklingtheory(k∠; trials)
        # @show √vartheory
        # @show meantheory
        testval = bucklingtest(k∠; trials)
        @test  testval < meantheory + sigmas*√vartheory
        @test  testval > meantheory - sigmas*√vartheory
    end
end