using MEDYAN
using StaticArrays
using Test

@testset "chem_setmonomerstate!" begin
    @testset "basic test" begin
        agent_names = MEDYAN.AgentNames(
            filamentnames= [(:a,[
                                :a,
                                :b,
                                :c,
                            ]),
            ],
        )
        grid= CubicGrid((4,1,1),500.0)
        s= MEDYAN.SysDef(agent_names)
        add_filament_params!(s, :a, MEDYAN.UNITY_FIL_PARAMS)
        c= MEDYAN.Context(s,grid)
        monomerstates= [s.state.a.a,s.state.a.a]
        monomerpositions= [SA[499.0,200.0,200.0],SA[501.0,200.0,200.0]]
        nodepositions= [SA[498.0,200,200],SA[502.0,200,200]]
        MEDYAN.chem_newfilament!(c;ftid=s.filament.a,node_mids=[1,],monomerstates,nodepositions,)
        MEDYAN.chem_setmonomerstate!(c, MonomerName(1,1,1),s.state.a.b)
        monstates = fil_mon_states(c, 1, 1)
        @test collect(monstates) == [s.state.a.b, s.state.a.a]
    end
    @testset "site count optimization tests" begin
        startc, s, fida1, fida2, fidb1, fidb2 = MEDYAN.example_all_sites_context(; check_sitecount_error=true) #deepcopy(cinit)

        MEDYAN.test_chem_mutation_sequence(startc, [
            c->MEDYAN.chem_setmonomerstate!(c,MonomerName(1, fida1, 1),s.state.a.a),
            c->MEDYAN.chem_setmonomerstate!(c,MonomerName(1, fida1, 1),s.state.a.me),
            c->MEDYAN.chem_setmonomerstate!(c,MonomerName(1, fida1, 2),s.state.a.me),
            c->MEDYAN.chem_setmonomerstate!(c,MonomerName(1, fida1, 3),s.state.a.me),
            c->MEDYAN.chem_setmonomerstate!(c,MonomerName(1, fida1, 1),s.state.a.a),
            c->MEDYAN.chem_setmonomerstate!(c,MonomerName(1, fida1, 2),s.state.a.a),
            c->MEDYAN.chem_setmonomerstate!(c,MonomerName(1, fida1, 3),s.state.a.a),
        ])
        MEDYAN.test_chem_mutation_sequence(startc, [
            c->MEDYAN.chem_setmonomerstate!(c,MonomerName(1, fida1, 8),s.state.a.pe),
            c->MEDYAN.chem_setmonomerstate!(c,MonomerName(1, fida1, 7),s.state.a.pe),
        ])
    end
end