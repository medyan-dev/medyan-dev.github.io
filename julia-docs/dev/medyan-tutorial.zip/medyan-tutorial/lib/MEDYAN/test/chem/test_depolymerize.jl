using MEDYAN
using StaticArrays
using Test

@testset "chem_depolymerize!" begin
    agentnames = MEDYAN.AgentNames(
        filamentnames= [(:a,[
                            :a,
                            :b,
                            :c,
                        ]),
        ],
    )
    grid= CubicGrid((4,1,1),500.0)
    s= MEDYAN.SysDef(agentnames)
    add_filament_params!(s, :a, MEDYAN.UNITY_FIL_PARAMS)
    cinit= MEDYAN.Context(s,grid)
    monomerstates= [s.state.a.a,s.state.a.a,s.state.a.b]
    nodepositions = [SA[498.0,200.0,200.0],SA[504.0,200.0,200.0]]
    MEDYAN.chem_newfilament!(cinit;ftid=s.filament.a,monomerstates,nodepositions,node_mids=[1,])
    @testset "plus end depolymerization test" begin
        c= deepcopy(cinit)
                        #context, ftid, fid, isminusend
        MEDYAN.chem_depolymerize!(c, 1, 1, false)
        monstates = fil_mon_states(c, 1, 1)
        @test collect(monstates) == [s.state.a.a,s.state.a.a]
        @test firstindex(monstates) == 1
        @test lastindex(monstates) == 2
        @test mon_plusvector.((c,), MonomerName.(1,1,1:2)) == [SA[1.0,0.0,0.0],SA[1.0,0.0,0.0]]
        @test mon_position.((c,), MonomerName.(1,1,1:2)) == [SA[499.0,200.0,200.0],SA[501.0,200.0,200.0]]
    end
    @testset "minus end depolymerization test" begin
        c= deepcopy(cinit)
        MEDYAN.chem_depolymerize!(c, 1, 1, true)
        monstates = fil_mon_states(c, 1, 1)
        @test collect(monstates) == [s.state.a.a,s.state.a.b]
        @test firstindex(monstates) == 2
        @test lastindex(monstates) == 3
        @test mon_plusvector.((c,), MonomerName.(1,1,2:3)) == [SA[1.0,0.0,0.0],SA[1.0,0.0,0.0]]
        @test mon_position.((c,), MonomerName.(1,1,2:3)) == [SA[501.0,200.0,200.0],SA[503.0,200.0,200.0]]
    end
    @testset "site count optimization tests" begin
        startc, s, fida1, fida2, fidb1, fidb2 = MEDYAN.example_all_sites_context(; check_sitecount_error=true) #deepcopy(cinit)
        
        #depolymerization minus end
        MEDYAN.test_chem_mutation_sequence(startc, [
            c->MEDYAN.chem_setmonomerstate!(c,MonomerName(1, fida1, 1),s.state.a.a),
            c->MEDYAN.chem_depolymerize!(c,1,fida1,true;warniflink_2mon_removed = false),
            c->MEDYAN.chem_setmonomerstate!(c,MonomerName(1, fida1, 2),s.state.a.me),
            c->MEDYAN.chem_depolymerize!(c,1,fida1,true;warniflink_2mon_removed = false),
            c->MEDYAN.chem_setmonomerstate!(c,MonomerName(1, fida1, 3),s.state.a.me),
        ])

        #depolymerization plus end
        c = deepcopy(startc)
        MEDYAN.test_chem_mutation_sequence(startc, [
            c->MEDYAN.chem_depolymerize!(c,1,fida1,false;warniflink_2mon_removed = false),
            c->MEDYAN.chem_setmonomerstate!(c,MonomerName(1, fida1, 8),s.state.a.pe),
            c->MEDYAN.chem_depolymerize!(c,1,fida1,false;warniflink_2mon_removed = false),
            c->MEDYAN.chem_setmonomerstate!(c,MonomerName(1, fida1, 7),s.state.a.pe),
        ])
    end
end