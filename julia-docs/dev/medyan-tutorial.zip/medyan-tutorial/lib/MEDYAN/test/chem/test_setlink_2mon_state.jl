using MEDYAN
using StaticArrays
using Dictionaries
using Test

@testset "chem_setlink_2mon_state!" begin
    grid= CubicGrid((3,1,1),500.0)
	agentnames = MEDYAN.AgentNames(
		filamentnames= [(:a,[
	                            :m,
	                        ]),
		],
        link_2mon_names= [:r,]
	)
    s = MEDYAN.SysDef(agentnames)
    add_filament_params!(s, :a, MEDYAN.UNITY_FIL_PARAMS)
    add_link_2mon!(s,
        :r,
        Link2MonState((sitecount=0.0,),(;)),
        nothing,
    )
    site = MEDYAN.Link2MonSiteCount()
    add_link_2mon_site!(s,:r,:mysite,site)
    NMonomers = 3
    monomerstates = ones(MonomerState,3)
    #start monomers in the third compartment
    nodepositions = [SA[1199.5,200,200],SA[1202.5,200,200]]
    cinit = MEDYAN.Context(s,grid; check_sitecount_error=true)
    fid=chem_newfilament!(cinit;
        monomerstates,
        nodepositions,
        node_mids=[1,],
    )

    @testset "site count when one link_2mon" begin
        c = deepcopy(cinit)
        name = MonomerName(1,fid,2)
        lid1 = chem_newlink_2mon!(c,s.link_2mon.r,name=>name)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,0]
        chem_setlink_2mon_state!(c,s.link_2mon.r,lid1,Link2MonState((sitecount=1.0,),(;)))
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,1]
        chem_setlink_2mon_state!(c,s.link_2mon.r,lid1,Link2MonState((sitecount=2.0,),(;)))
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,2]
    end
    @testset "defer chem cache when one link_2mon" begin
        c = deepcopy(cinit)
        name = MonomerName(1,fid,2)
        lid1 = chem_newlink_2mon!(c,s.link_2mon.r,name=>name)
        MEDYAN.test_chem_mutation_sequence(c, [
            c->chem_setlink_2mon_state!(c,s.link_2mon.r,lid1,Link2MonState((sitecount=1.0,),(;))),
            c->chem_setlink_2mon_state!(c,s.link_2mon.r,lid1,Link2MonState((sitecount=2.0,),(;))),
        ])
    end
end