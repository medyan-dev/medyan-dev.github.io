using MEDYAN
using StaticArrays
using Test

@testset "chem_removefilament!" begin
    @testset "site count optimization tests" begin
        startc, s, fida1, fida2, fidb1, fidb2 = MEDYAN.example_all_sites_context(; check_sitecount_error=true)

        MEDYAN.test_chem_mutation_sequence(startc, [
            c->MEDYAN.chem_removefilament!(c;
                ftid = s.filament.a,
                fid = fida1,
                warniflink_2mon_removed = false,
            ),
            c->MEDYAN.chem_removefilament!(c;
                ftid = s.filament.a,
                fid = fida2,
                warniflink_2mon_removed = false,
            ),
            c->MEDYAN.chem_removefilament!(c;
                ftid = s.filament.b,
                fid = fidb1,
                warniflink_2mon_removed = false,
            ),
            c->MEDYAN.chem_removefilament!(c;
                ftid = s.filament.b,
                fid = fidb2,
                warniflink_2mon_removed = false,
            ),
        ])
    end
end