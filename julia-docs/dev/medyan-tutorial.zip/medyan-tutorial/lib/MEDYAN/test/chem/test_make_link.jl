using MEDYAN
using StaticArrays
using Dictionaries
using Test
using Random

@testset "make_link! and remove_link! mechanics" begin
    grid = CubicGrid((4,4,4),500.0)
    c = MEDYAN.example_actin_mech_context(grid)
    fila_idx = MEDYAN.make_fila!(c;
        fila_type= :actin,
        mono_states= ones(UInt8,20),
        node_mids= [0,],
        node_positions= [SA[-27.0, 0.0, 0.0], SA[27.0, 0.0, 0.0]],
    )
    minus_fila_tip_idx = MEDYAN.FilaTipIdx(c, fila_idx, -)
    plus_fila_tip_idx = MEDYAN.FilaTipIdx(c, fila_idx, +)
    @test isempty(MEDYAN.get_links(c, :fila_tip_restraint))
    link_tag1 = MEDYAN.make_link!(c;
        link_type= :fila_tip_restraint,
        places= (minus_fila_tip_idx,),
    )
    @test collect(MEDYAN.get_links(c, :fila_tip_restraint)) == [link_tag1]
    minus_fila_tip_tag = MEDYAN.tag!(c, minus_fila_tip_idx)
    plus_fila_tip_tag = MEDYAN.tag!(c, plus_fila_tip_idx)
    MEDYAN.assert_invariants(c)
    @test length(MEDYAN.get_tags(c, link_tag1)) == 1
    @test collect(MEDYAN.get_tags(c, link_tag1)) == [minus_fila_tip_tag]

    @test length(MEDYAN.get_links(c, minus_fila_tip_tag)) == 1
    @test collect(MEDYAN.get_links(c, minus_fila_tip_tag)) == [link_tag1,]

    @test length(MEDYAN.get_links(c, minus_fila_tip_idx)) == 1
    @test collect(MEDYAN.get_links(c, minus_fila_tip_idx)) == [link_tag1,]

    @test isempty(MEDYAN.get_links(c, plus_fila_tip_idx))
    
    link_tag2 = MEDYAN.make_link!(c;
        link_type= :fila_tip_restraint,
        places= (minus_fila_tip_idx,),
    )
    link_tag3 = MEDYAN.make_link!(c;
        link_type= :fila_tip_restraint,
        places= (plus_fila_tip_idx,),
    )
    @test length(MEDYAN.get_links(c, minus_fila_tip_idx)) == 2
    @test issetequal(collect(MEDYAN.get_links(c, minus_fila_tip_idx)), [link_tag1, link_tag2])
    @test issetequal(collect(MEDYAN.get_links(c, plus_fila_tip_idx)), [link_tag3])
    @test collect(MEDYAN.get_tags(c, link_tag2)) == [minus_fila_tip_tag]
    @test collect(MEDYAN.get_tags(c, link_tag3)) == [plus_fila_tip_tag]
    MEDYAN.assert_invariants(c)
    links = collect(MEDYAN.get_links(c, :fila_tip_restraint))
    @test issetequal(links, [link_tag1, link_tag2, link_tag3])
    for trial in 1:100
        local _links = shuffle(links)
        local _c = deepcopy(c)
        for lt in _links
            MEDYAN.remove_link!(_c, lt)
            MEDYAN.assert_invariants(_c)
        end
        local lt2 = MEDYAN.make_link!(_c;
            link_type= :fila_tip_restraint,
            places= (plus_fila_tip_idx,),
        )
        MEDYAN.assert_invariants(_c)
        MEDYAN.remove_link!(_c, lt2)
        MEDYAN.assert_invariants(_c)
    end
    MEDYAN.remove_link!(c, link_tag3)
    MEDYAN.assert_invariants(c)
    link_tag4 = MEDYAN.make_link!(c;
        link_type= :fila_tip_restraint,
        places= (plus_fila_tip_idx,),
    )
    @test link_tag4 != link_tag3
    @test issetequal(collect(MEDYAN.get_links(c, plus_fila_tip_idx)), [link_tag4])
    MEDYAN.remove_link!(c, link_tag1)
    @test issetequal(collect(MEDYAN.get_links(c, minus_fila_tip_idx)), [link_tag2])
    MEDYAN.assert_invariants(c)
    link_tag5 = MEDYAN.make_link!(c;
        link_type= :fila_tip_restraint,
        places= (plus_fila_tip_idx,),
    )
    MEDYAN.assert_invariants(c)
    @test issetequal(collect(MEDYAN.get_links(c, plus_fila_tip_idx)), [link_tag5, link_tag4])
end

@testset "make_link! and remove_link! chemistry" begin
    grid= CubicGrid((3,1,1),500.0)
    agent_names = MEDYAN.AgentNames(
        filamentnames= [(:a, [
                :plusend,
                :minusend,
                :middle,
                :restrained,
            ]),
        ],
    )
    s = MEDYAN.SysDef(agent_names)
    MEDYAN.add_link_type!(s;
        name = :restraint,
        description = "test link",
        places = [MEDYAN.FilaMonoIdx()],
        bonds = [
            MEDYAN.BondConfig(;
                bond=MEDYAN.PositionDirectionRestraint(),
                input=(1,),
                state=(;kr=100.0, kbend=0.0, r0=SA[-50,0.0,0.0], v̂0=SA[1.0,0.0,0.0],),
                param=(;),
            ),
        ],
        reactions = [[
            (;
                affect! = Returns(1),
                rate = Returns(1.0),
            )
        ]],
    )
    fxsid = s.link_reaction_site.restraint.place1_reaction1.fxsid
    NMonomers = 3
    monomerstates = [0x01,0x04,0x02]
    #start monomers in the third compartment
    nodepositions = [SA[449.5,0,0], SA[452.5,0,0]]
    add_filament_params!(s, :a, MEDYAN.FilamentMechParams(
            radius= 1.0,
            spacing= 1.0,
            klength= 40000.0,
            kangle= 20000.0,
            numpercylinder= 40,
            max_num_unmin_end= 1000,
    ))
    cinit = MEDYAN.Context(s,grid; check_sitecount_error=true)
    fila_idx = MEDYAN.make_fila!(cinit;
        fila_type= :a,
        mono_states= monomerstates,
        node_mids= [1,],
        node_positions= nodepositions,
    )
    @testset "no site counts when no link" begin
        c = deepcopy(cinit)
        @test c.chemistryengine.fixedcounts[fxsid,:] == [0,0,0]
    end
    @testset "one site count when one link" begin
        c = deepcopy(cinit)
        MEDYAN.make_link!(c;
            link_type = :restraint,
            places = (MEDYAN.FilaMonoIdx(c, fila_idx, 2),),
        )
        @test c.chemistryengine.fixedcounts[fxsid,:] == [0,0,1]
    end
    @testset "two sites count when two link" begin
        c = deepcopy(cinit)
        link_tag1 = MEDYAN.make_link!(c;
            link_type = :restraint,
            places = (MEDYAN.FilaMonoIdx(c, fila_idx, 2),),
        )
        link_tag2 = MEDYAN.make_link!(c;
            link_type = :restraint,
            places = (MEDYAN.FilaMonoIdx(c, fila_idx, 3),),
        )
        @test length(MEDYAN.get_links(c, :restraint)) == 2
        @test c.chemistryengine.fixedcounts[fxsid,:] == [0,0,2]
        MEDYAN.remove_link!(c, link_tag1)
        @test length(MEDYAN.get_links(c, :restraint)) == 1
        @test all(c.chemistryengine.fixedcounts[fxsid,:] .≥ [0,0,1])
        refresh_chem_cache!(c) # removing a link may not decrease the number of sites
        # until after reset, because rejection sampling could be used
        @test c.chemistryengine.fixedcounts[fxsid,:] == [0,0,1]
        MEDYAN.remove_link!(c, link_tag2)
        @test length(MEDYAN.get_links(c, :restraint)) == 0
        @test all(c.chemistryengine.fixedcounts[fxsid,:] .≥ [0,0,0])
        refresh_chem_cache!(c)
        @test c.chemistryengine.fixedcounts[fxsid,:] == [0,0,0]
    end
    @testset "two link defer caching" begin
        local link_tag1::MEDYAN.LinkTag
        local link_tag2::MEDYAN.LinkTag
        MEDYAN.test_chem_mutation_sequence(cinit, [
            c->(link_tag1 = MEDYAN.make_link!(c;
                link_type = :restraint,
                places = (MEDYAN.FilaMonoIdx(c, fila_idx, 2),),
            )),
            c->(link_tag2 = MEDYAN.make_link!(c;
                link_type = :restraint,
                places = (MEDYAN.FilaMonoIdx(c, fila_idx, 3),),
            )),
            c->MEDYAN.remove_link!(c, link_tag1),
            c->MEDYAN.remove_link!(c, link_tag2),
        ])
    end
    @testset "one site count moves after minimization" begin
        c = deepcopy(cinit)
        link_tag1 = MEDYAN.make_link!(c;
            link_type = :restraint,
            places = (MEDYAN.FilaMonoIdx(c, fila_idx, 2),),
        )
        @test c.chemistryengine.fixedcounts[fxsid,:] == [0,0,1]
        @test MEDYAN.get_is_minimized(c, link_tag1) == false
        MEDYAN.minimize_energy!(c)
        @test MEDYAN.get_is_minimized(c, link_tag1) == true
        refresh_chem_cache!(c)
        @test c.chemistryengine.fixedcounts[fxsid,:] == [0,1,0]
    end
end