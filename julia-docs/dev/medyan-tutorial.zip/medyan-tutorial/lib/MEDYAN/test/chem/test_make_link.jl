using MEDYAN
using StaticArrays
using Dictionaries
using Test
using Random

@testset "make_link! and remove_link!" begin
    grid = CubicGrid((4,4,4),500.0)
    c = MEDYAN.example_actin_mech_context(grid)
    fila_idx = MEDYAN.make_fila!(c;
        fila_type= :actin,
        mono_states= ones(UInt8,20),
        node_mids= [0,],
        node_positions= [SA[-27.0, 0.0, 0.0], SA[27.0, 0.0, 0.0]],
    )
    minus_fila_tip_idx = MEDYAN.FilaTipIdx(c, fila_idx, -)
    plus_fila_tip_idx = MEDYAN.FilaTipIdx(c, fila_idx, +)
    @test isempty(MEDYAN.get_links(c, :fila_tip_restraint))
    link_tag1 = MEDYAN.make_link!(c;
        link_type= :fila_tip_restraint,
        places= (minus_fila_tip_idx,),
    )
    @test collect(MEDYAN.get_links(c, :fila_tip_restraint)) == [link_tag1]
    minus_fila_tip_tag = MEDYAN.tag!(c, minus_fila_tip_idx)
    plus_fila_tip_tag = MEDYAN.tag!(c, plus_fila_tip_idx)
    MEDYAN.assert_invariants(c)
    @test length(MEDYAN.get_tags(c, link_tag1)) == 1
    @test collect(MEDYAN.get_tags(c, link_tag1)) == [minus_fila_tip_tag]

    @test length(MEDYAN.get_links(c, minus_fila_tip_tag)) == 1
    @test collect(MEDYAN.get_links(c, minus_fila_tip_tag)) == [link_tag1,]

    @test length(MEDYAN.get_links(c, minus_fila_tip_idx)) == 1
    @test collect(MEDYAN.get_links(c, minus_fila_tip_idx)) == [link_tag1,]

    @test isempty(MEDYAN.get_links(c, plus_fila_tip_idx))
    
    link_tag2 = MEDYAN.make_link!(c;
        link_type= :fila_tip_restraint,
        places= (minus_fila_tip_idx,),
    )
    link_tag3 = MEDYAN.make_link!(c;
        link_type= :fila_tip_restraint,
        places= (plus_fila_tip_idx,),
    )
    @test length(MEDYAN.get_links(c, minus_fila_tip_idx)) == 2
    @test issetequal(collect(MEDYAN.get_links(c, minus_fila_tip_idx)), [link_tag1, link_tag2])
    @test issetequal(collect(MEDYAN.get_links(c, plus_fila_tip_idx)), [link_tag3])
    @test collect(MEDYAN.get_tags(c, link_tag2)) == [minus_fila_tip_tag]
    @test collect(MEDYAN.get_tags(c, link_tag3)) == [plus_fila_tip_tag]
    MEDYAN.assert_invariants(c)
    links = collect(MEDYAN.get_links(c, :fila_tip_restraint))
    @test issetequal(links, [link_tag1, link_tag2, link_tag3])
    for trial in 1:100
        local _links = shuffle(links)
        local _c = deepcopy(c)
        for lt in _links
            MEDYAN.remove_link!(_c, lt)
            MEDYAN.assert_invariants(_c)
        end
        local lt2 = MEDYAN.make_link!(_c;
            link_type= :fila_tip_restraint,
            places= (plus_fila_tip_idx,),
        )
        MEDYAN.assert_invariants(_c)
        MEDYAN.remove_link!(_c, lt2)
        MEDYAN.assert_invariants(_c)
    end
    MEDYAN.remove_link!(c, link_tag3)
    MEDYAN.assert_invariants(c)
    link_tag4 = MEDYAN.make_link!(c;
        link_type= :fila_tip_restraint,
        places= (plus_fila_tip_idx,),
    )
    @test link_tag4 != link_tag3
    @test issetequal(collect(MEDYAN.get_links(c, plus_fila_tip_idx)), [link_tag4])
    MEDYAN.remove_link!(c, link_tag1)
    @test issetequal(collect(MEDYAN.get_links(c, minus_fila_tip_idx)), [link_tag2])
    MEDYAN.assert_invariants(c)
    link_tag5 = MEDYAN.make_link!(c;
        link_type= :fila_tip_restraint,
        places= (plus_fila_tip_idx,),
    )
    MEDYAN.assert_invariants(c)
    @test issetequal(collect(MEDYAN.get_links(c, plus_fila_tip_idx)), [link_tag5, link_tag4])
end