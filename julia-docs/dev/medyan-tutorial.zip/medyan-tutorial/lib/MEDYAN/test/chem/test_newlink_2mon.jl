using MEDYAN
using StaticArrays
using Dictionaries
using Test

@testset "chem_newlink_2mon! and chem_removelink_2mon!" begin
    grid= CubicGrid((3,1,1),500.0)
	agentnames = MEDYAN.AgentNames(
		filamentnames= [(:a,[
	                            :plusend,
	                            :minusend,
	                            :middle,
                                :restrained,
	                        ]),
		],
        link_2mon_names= [:restraint,]
	)
    s = MEDYAN.SysDef(agentnames)
    add_link_2mon!(s,
        :restraint,
        Link2MonState((;),(mr0 = SA[700,200.0,200.0], mv̂0 = SA[1.0,0.0,0.0])),
        MEDYAN.RestraintMechParams(kr=100.0,kv̂=0.0),
    )
    site = MEDYAN.Link2MonSiteOne()
    add_link_2mon_site!(s,:restraint,:mysite,site)
    NMonomers = 3
    monomerstates = [0x01,0x04,0x02]
    #start monomers in the third compartment
    nodepositions = [SA[1199.5,200,200],SA[1202.5,200,200]]
    add_filament_params!(s, :a, MEDYAN.FilamentMechParams(
	        radius= 1.0,
	        spacing= 1.0,
	        klength= 40000.0,
	        kangle= 20000.0,
            numpercylinder= 40,
            max_num_unmin_end= 1000,
	))
    cinit = MEDYAN.Context(s,grid; check_sitecount_error=true)
    set_enable_cylinder_volume_exclusion!(cinit,false)
    fid=chem_newfilament!(cinit;
        monomerstates,
        nodepositions,
        node_mids=[1,],
    )
    @testset "no site counts when no link_2mon" begin
        c = deepcopy(cinit)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,0]
    end
    @testset "one site count when one link_2mon" begin
        c = deepcopy(cinit)
        name = MonomerName(1,fid,2)
        chem_newlink_2mon!(c,s.link_2mon.restraint,name=>name)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,1]
    end
    @testset "two sites count when two link_2mon" begin
        c = deepcopy(cinit)
        name = MonomerName(1,fid,2)
        name2 = MonomerName(1,fid,3)
        lid_1 = chem_newlink_2mon!(c,s.link_2mon.restraint,name=>name)
        lid_2 = chem_newlink_2mon!(c,s.link_2mon.restraint,name2=>name2)
        @test length(c.link_2mon_data[1].states) == 2
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,2]
        chem_removelink_2mon!(c,s.link_2mon.restraint,lid_1)
        @test length(c.link_2mon_data[1].states) == 1
        @test all(c.chemistryengine.fixedcounts[1,:] .≥ [0,0,1])
        refresh_chem_cache!(c) # removing a link_2mon may not decrease the number of sites
        #until after reset, because rejection sampling could be used
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,1]
        chem_removelink_2mon!(c,s.link_2mon.restraint,lid_2)
        @test length(c.link_2mon_data[1].states) == 0
        @test all(c.chemistryengine.fixedcounts[1,:] .≥ [0,0,0])
        refresh_chem_cache!(c)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,0]
    end
    @testset "two link_2mon defer caching" begin
        name = MonomerName(1,fid,2)
        name2 = MonomerName(1,fid,3)
        lid_1::Int64=0
        lid_2::Int64=0
        MEDYAN.test_chem_mutation_sequence(cinit, [
            c->(lid_1 = chem_newlink_2mon!(c,s.link_2mon.restraint,name=>name)),
            c->(lid_2 = chem_newlink_2mon!(c,s.link_2mon.restraint,name2=>name2)),
            c->chem_removelink_2mon!(c,s.link_2mon.restraint,lid_1),
            c->chem_removelink_2mon!(c,s.link_2mon.restraint,lid_2),
        ])
    end
    @testset "one site count moves after minimization" begin
        c = deepcopy(cinit)
        name = MonomerName(1,fid,2)
        chem_newlink_2mon!(c,s.link_2mon.restraint,name=>name)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,1]
        @test c.link_2mon_data[s.link_2mon.restraint].states[1].is_minimized == false
        MEDYAN.minimize_energy!(c)
        @test c.link_2mon_data[s.link_2mon.restraint].states[1].is_minimized == true
        refresh_chem_cache!(c)
        @test c.chemistryengine.fixedcounts[1,:] == [0,1,0]
    end
end