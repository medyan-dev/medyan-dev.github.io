using MEDYAN
using StaticArrays
using Dictionaries
using Test

@testset "chem_newfilament!" begin
    agentnames = MEDYAN.AgentNames(
            filamentnames= [(:actin,[
                                :plusend,
                                :minusend,
                                :middle,
                            ]),
            ],
        )
    grid = CubicGrid((4,1,1),500.0)
    s = MEDYAN.SysDef(agentnames)
    add_filament_params!(s, :actin, MEDYAN.UNITY_FIL_PARAMS)
    cinit = MEDYAN.Context(s,grid)
    @testset "basic single filament test" begin
        nummonomers= 12
        monomerstates= zeros(Int,nummonomers)
        monomerstates[3]= s.state.actin.minusend
        monomerstates[4:8].= s.state.actin.middle
        monomerstates[9]= s.state.actin.plusend
        nodepositions= [SA[0.0,200.0,200.0],SA[2000.0,200.0,200.0]]
        c = deepcopy(cinit)
        MEDYAN.chem_newfilament!(c;ftid=s.filament.actin,node_mids=[1,],monomerstates,nodepositions,)
        #check segments
        
        #negative end segment
        @test length(c.compartments[1].segments[s.filament.actin])==1
        seg= c.compartments[1].segments[s.filament.actin][1]
        @test seg.cid==1
        @test seg.ftid==1
        @test seg.fid==1
        @test seg.midminusend==1
        @test seg.midplusend==3
        @test seg.plusend_cid==2
        @test seg.minusend_cid==-1
        @test seg.filamentsitecounts== []

        #middle segment
        @test length(c.compartments[2].segments[s.filament.actin])==1
        seg= c.compartments[2].segments[s.filament.actin][1]
        @test seg.cid==2
        @test seg.ftid==1
        @test seg.fid==1
        @test seg.midminusend==4
        @test seg.midplusend==6
        @test seg.plusend_cid==3
        @test seg.minusend_cid==1
        @test seg.filamentsitecounts== []

        #end segment
        @test length(c.compartments[4].segments[s.filament.actin])==1
        seg= c.compartments[4].segments[s.filament.actin][1]
        @test seg.cid==4
        @test seg.ftid==1
        @test seg.fid==1
        @test seg.midminusend==10
        @test seg.midplusend==12
        @test seg.plusend_cid==-1
        @test seg.minusend_cid==3
        @test seg.filamentsitecounts== []
    end

    @testset "two monomer edge case" begin
        nummonomers= 2
        monomerstates= [1,2]
        nodepositions= [SA[0.5,200.0,200.0], SA[2.5,200.0,200.0]]
        c = deepcopy(cinit)
        MEDYAN.chem_newfilament!(c;ftid=s.filament.actin,node_mids=[1,],monomerstates,nodepositions,)
        #check segments
        @test length(c.compartments[1].segments[s.filament.actin])==1
        seg= c.compartments[1].segments[s.filament.actin][1]
        @test seg.cid==1
        @test seg.ftid==1
        @test seg.fid==1
        @test seg.midminusend==1
        @test seg.midplusend==2
        @test seg.plusend_cid==-1
        @test seg.minusend_cid==-1
        @test seg.filamentsitecounts== []

        @test length(c.compartments[2].segments[s.filament.actin])==0
    end

    @testset "two monomers in two compartments edge case" begin
        nummonomers= 2
        monomerstates= [1,2]
        nodepositions= [SA[498.0,200.0,200.0], SA[502.0,200.0,200.0]]
        c = deepcopy(cinit)
        MEDYAN.chem_newfilament!(c;ftid=s.filament.actin,node_mids=[1,],monomerstates,nodepositions,)
        #check segments
        @test length(c.compartments[1].segments[s.filament.actin])==1
        seg= c.compartments[1].segments[s.filament.actin][1]
        @test seg.cid==1
        @test seg.ftid==1
        @test seg.fid==1
        @test seg.midminusend==1
        @test seg.midplusend==1
        @test seg.plusend_cid==2
        @test seg.minusend_cid==-1
        @test seg.filamentsitecounts== []

        @test length(c.compartments[2].segments[s.filament.actin])==1
        seg= c.compartments[2].segments[s.filament.actin][1]
        @test seg.cid==2
        @test seg.ftid==1
        @test seg.fid==1
        @test seg.midminusend==2
        @test seg.midplusend==2
        @test seg.plusend_cid==-1
        @test seg.minusend_cid==1
        @test seg.filamentsitecounts== []
    end

    @testset "filament loops back edge case" begin
        nummonomers= 4
        monomerstates= [1,2,3,4]
        nodepositions= [SA[485.0,200.0,200.0],SA[505.0,210.0,200.0],SA[485.0,220.0,200.0]]
        c = deepcopy(cinit)
        MEDYAN.chem_newfilament!(c;ftid=s.filament.actin,node_mids=[1,3],monomerstates,nodepositions,)
        #check segments
        @test length(c.compartments[1].segments[s.filament.actin])==2
        seg= c.compartments[1].segments[s.filament.actin][1]
        @test seg.cid==1
        @test seg.ftid==1
        @test seg.fid==1
        @test seg.midminusend==1
        @test seg.midplusend==1
        @test seg.plusend_cid==2
        @test seg.minusend_cid==-1
        @test seg.filamentsitecounts== []

        seg= c.compartments[1].segments[s.filament.actin][2]
        @test seg.cid==1
        @test seg.ftid==1
        @test seg.fid==1
        @test seg.midminusend==4
        @test seg.midplusend==4
        @test seg.plusend_cid==-1
        @test seg.minusend_cid==2
        @test seg.filamentsitecounts== []

        @test length(c.compartments[2].segments[s.filament.actin])==1
        seg= c.compartments[2].segments[s.filament.actin][1]
        @test seg.cid==2
        @test seg.ftid==1
        @test seg.fid==1
        @test seg.midminusend==2
        @test seg.midplusend==3
        @test seg.plusend_cid==1
        @test seg.minusend_cid==1
        @test seg.filamentsitecounts== []
    end

    @testset "adding multiple filaments" begin
        c = deepcopy(cinit)
        monomerstates= [1,2]
        nodepositions= [SA[498.0,200.0,200.0], SA[502.0,200.0,200.0]]
        MEDYAN.chem_newfilament!(c;ftid=s.filament.actin,node_mids=[1,],monomerstates,nodepositions,)
        nummonomers= 12
        monomerstates= zeros(Int,nummonomers)
        monomerstates[3]= s.state.actin.minusend
        monomerstates[4:8].= s.state.actin.middle
        monomerstates[9]= s.state.actin.plusend
        nodepositions= [SA[0.0,200.0,200.0],SA[2000.0,200.0,200.0]]
        MEDYAN.chem_newfilament!(c;ftid=s.filament.actin,node_mids=[1,],monomerstates,nodepositions,)

        #check segments
        
        #negative end segment
        @test length(c.compartments[1].segments[s.filament.actin])==2
        @test length(filter(c.compartments[1].segments[s.filament.actin]) do seg
            (seg.cid==1
            && seg.ftid==1
            && seg.fid==2
            && seg.midminusend==1
            && seg.midplusend==3
            && seg.plusend_cid==2
            && seg.minusend_cid==-1
            && seg.filamentsitecounts== [])
        end) == 1

        @test length(filter(c.compartments[1].segments[s.filament.actin]) do seg
            (seg.cid==1
            && seg.ftid==1
            && seg.fid==1
            && seg.midminusend==1
            && seg.midplusend==1
            && seg.plusend_cid==2
            && seg.minusend_cid==-1
            && seg.filamentsitecounts== [])
        end) == 1

        #middle segment
        @test length(c.compartments[2].segments[s.filament.actin])==2
        @test length(filter(c.compartments[2].segments[s.filament.actin]) do seg
            (seg.cid==2
            && seg.ftid==1
            && seg.fid==2
            && seg.midminusend==4
            && seg.midplusend==6
            && seg.plusend_cid==3
            && seg.minusend_cid==1
            && seg.filamentsitecounts== [])
        end) == 1

        @test length(filter(c.compartments[2].segments[s.filament.actin]) do seg
            (seg.cid==2
            && seg.ftid==1
            && seg.fid==1
            && seg.midminusend==2
            && seg.midplusend==2
            && seg.plusend_cid==-1
            && seg.minusend_cid==1
            && seg.filamentsitecounts== [])
        end) == 1

        #end segment
        @test length(c.compartments[4].segments[s.filament.actin])==1
        seg= c.compartments[4].segments[s.filament.actin][1]
        @test seg.cid==4
        @test seg.ftid==1
        @test seg.fid==2
        @test seg.midminusend==10
        @test seg.midplusend==12
        @test seg.plusend_cid==-1
        @test seg.minusend_cid==3
        @test seg.filamentsitecounts== []
        
    end
    @testset "site count optimization tests" begin
        startc, s, fida1, fida2, fidb1, fidb2 = MEDYAN.example_all_sites_context(; check_sitecount_error=true) #deepcopy(cinit)

        #new filament in one compartment
        MEDYAN.test_chem_mutation_sequence(startc, [
            c->MEDYAN.chem_newfilament!(c;
                ftid = 1,
                monomerstates = ones(MEDYAN.MonomerState,10),
                node_mids = [1,],
                nodepositions = [SA[1.0,1.0,1.0],SA[100.0,1.0,1.0]]
            ),
            c->MEDYAN.chem_newfilament!(c;
                ftid = 2,
                monomerstates = ones(MEDYAN.MonomerState,10),
                node_mids = [1,],
                nodepositions = [SA[1.0,1.0,1.0],SA[100.0,1.0,1.0]]
            ),
        ])

        #new filament in multiple compartments
        MEDYAN.test_chem_mutation_sequence(startc, [
            c->MEDYAN.chem_newfilament!(c;
                ftid = 1,
                monomerstates = ones(MEDYAN.MonomerState,100),
                node_mids = [1,],
                nodepositions = [SA[300.0,200.0,200.0],SA[1300.0,200.0,200.0]]
            ),
            c->MEDYAN.chem_newfilament!(c;
                ftid = 2,
                monomerstates = ones(MEDYAN.MonomerState,100),
                node_mids = [1,],
                nodepositions = [SA[300.0,200.0,200.0],SA[1300.0,200.0,200.0]]
            ),
        ])
    end
end
