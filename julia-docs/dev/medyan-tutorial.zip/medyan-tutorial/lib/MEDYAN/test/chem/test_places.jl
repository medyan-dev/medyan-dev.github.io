using MEDYAN
using StaticArrays
using Test

@testset "places" begin
    grid = CubicGrid((4,4,4),500.0)
    c = MEDYAN.example_actin_mech_context(grid)
    fila_idx = MEDYAN.make_fila!(c;
        fila_type= :actin,
        mono_states= ones(UInt8,20),
        node_mids= [0,],
        node_positions= [SA[-27.0, 0.0, 0.0], SA[27.0, 0.0, 0.0]],
    )
    @test fila_idx isa MEDYAN.FilaIdx
    minus_fila_tip_idx = MEDYAN.FilaTipIdx(c, fila_idx, -)
    plus_fila_tip_idx = MEDYAN.FilaTipIdx(c, fila_idx, +)
    fila_tip_place_tag = MEDYAN.tag!(c, minus_fila_tip_idx)
    # mono_idx = get_mono_idx(c, fila_end_idx)

    # mono_node_idx = get_place_idx(c, mono_idx)
    # mon_node_id = ref_place_id!(c, mon_node_idx)
    # deref_place_id!(c, mon_node_id)
    # mon_node_idx = get_place_idx(c, mon_node_id)
    # get_node_parent
    # get_node_position
    # get_node_state

end

