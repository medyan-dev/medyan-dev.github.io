using MEDYAN
using StaticArrays
using Test

@testset "zigzag encoding" begin
    @test MEDYAN._zigzag_encode(Int64(0)) === UInt64(0)
    @test MEDYAN._zigzag_encode(Int64(-1)) === UInt64(1)
    @test MEDYAN._zigzag_encode(Int64(1)) === UInt64(2)
    @test MEDYAN._zigzag_encode(Int64(-2)) === UInt64(3)
    @test MEDYAN._zigzag_encode(Int64(2)) === UInt64(4)
    @test MEDYAN._zigzag_encode(typemax(Int64)) === typemax(UInt64)-1
    @test MEDYAN._zigzag_encode(typemin(Int64)) === typemax(UInt64)
    for i in typemin(Int8):typemax(Int8)
        @test MEDYAN._zigzag_decode(MEDYAN._zigzag_encode(i)) === i
    end
    for i in typemin(Int16):typemax(Int16)
        @test MEDYAN._zigzag_decode(MEDYAN._zigzag_encode(i)) === i
    end
end

@testset "filament places" begin
    grid = CubicGrid((4,4,4),500.0)
    c = MEDYAN.example_actin_mech_context(grid)
    fila_idx = MEDYAN.make_fila!(c;
        fila_type= :actin,
        mono_states= ones(UInt8,20),
        node_mids= [0,],
        node_positions= [SA[-27.0, 0.0, 0.0], SA[27.0, 0.0, 0.0]],
    )
    @test fila_idx isa MEDYAN.FilaIdx
    minus_fila_tip_idx = MEDYAN.FilaTipIdx(c, fila_idx, -)
    plus_fila_tip_idx = MEDYAN.FilaTipIdx(c, fila_idx, +)
    fila_tip_place_tag = MEDYAN.tag!(c, minus_fila_tip_idx)
    @test minus_fila_tip_idx == MEDYAN.get_place(c, fila_tip_place_tag)
    mono_idx = MEDYAN.FilaMonoIdx(c, minus_fila_tip_idx)
    @test mono_idx == MEDYAN.FilaMonoIdx(c, fila_idx, 0)
    # Filament tip positions are at the end nodes
    @test MEDYAN.get_position(c, minus_fila_tip_idx) ≈ SA[-27.0, 0.0, 0.0]
    @test MEDYAN.get_position(c, plus_fila_tip_idx) ≈ SA[27.0, 0.0, 0.0]
    # Filament tip directions point out of the filament ends
    @test MEDYAN.get_directions(c, minus_fila_tip_idx) ≈ SA[SA[-1.0, 0.0, 0.0]]
    @test MEDYAN.get_directions(c, plus_fila_tip_idx) ≈ SA[SA[1.0, 0.0, 0.0]]
    @test MEDYAN.get_chem_state(c, minus_fila_tip_idx) == MEDYAN.FilaTipChemState(0x01, 0x01)
    @test MEDYAN.place_exists(c, minus_fila_tip_idx)
    @test MEDYAN.place_exists(c, plus_fila_tip_idx)

    # minus end monomer is half a spacing in from the tip
    @test MEDYAN.get_position(c, mono_idx) ≈ MEDYAN.get_position(c, minus_fila_tip_idx) - 2.7/2*MEDYAN.get_directions(c,minus_fila_tip_idx)[1]
    # monomer directions point to the plus end of the filament
    @test MEDYAN.get_directions(c, mono_idx) ≈ SA[SA[1.0, 0.0, 0.0]]
    @test MEDYAN.get_chem_state(c, mono_idx) == MEDYAN.FilaMonoChemState(0x00, 0x01, 0x01)
    @test MEDYAN.place_exists(c, mono_idx)

    @testset "filament tips have tags by default" begin
        grid = CubicGrid((4,4,4),500.0)
        c = MEDYAN.example_actin_mech_context(grid)
        fila_idx = MEDYAN.make_fila!(c;
            fila_type= :actin,
            mono_states= ones(UInt8,20),
            node_mids= [0,],
            node_positions= [SA[-27.0, 0.0, 0.0], SA[27.0, 0.0, 0.0]],
        )
        MEDYAN.assert_invariants(c)
        @test length(MEDYAN.get_tags(c, MEDYAN.FilaTipIdx())) == 2
        tags = collect(MEDYAN.get_tags(c, MEDYAN.FilaTipIdx()))
        tagged_places =  MEDYAN.get_place.((c,), tags)
        @test length(tagged_places) == 2
        @test issetequal(tagged_places, MEDYAN.FilaTipIdx.((c,), (fila_idx,), false:true))
        # creating a new tag will reuse an existing tag if possible.
        tagm = MEDYAN.tag!(c, MEDYAN.FilaTipIdx(c, fila_idx, true))
        MEDYAN.assert_invariants(c)
        tagp = MEDYAN.tag!(c, MEDYAN.FilaTipIdx(c, fila_idx, false))
        MEDYAN.assert_invariants(c)
        @test issetequal(tags, [tagm, tagp])
        # Running energy minimization doesn't remove tip tags
        MEDYAN.minimize_energy!(c)
        MEDYAN.assert_invariants(c)
        tags = collect(MEDYAN.get_tags(c, MEDYAN.FilaTipIdx()))
        @test issetequal(tags, [tagm, tagp])
        MEDYAN.remove_fila!(c, fila_idx)
        MEDYAN.assert_invariants(c)
        @test isempty(MEDYAN.get_tags(c, MEDYAN.FilaTipIdx()))
        @test !MEDYAN.place_exists(c, MEDYAN.FilaTipIdx(c, fila_idx, true))
        @test !MEDYAN.tag_exists(c, tagm)
        @test !MEDYAN.tag_exists(c, tagp)
        fila_idx1 = MEDYAN.make_fila!(c;
            fila_type= :actin,
            mono_states= ones(UInt8,20),
            node_mids= [0,],
            node_positions= [SA[-27.0, 0.0, 0.0], SA[27.0, 0.0, 0.0]],
        )
        MEDYAN.assert_invariants(c)
        fila_idx2 = MEDYAN.make_fila!(c;
            fila_type= :actin,
            mono_states= ones(UInt8,20),
            node_mids= [0,],
            node_positions= [SA[-27.0, 0.0, 0.0], SA[27.0, 0.0, 0.0]],
        )
        MEDYAN.assert_invariants(c)
        @test !MEDYAN.tag_exists(c, tagm)
        @test !MEDYAN.tag_exists(c, tagp)
        tags = collect(MEDYAN.get_tags(c, MEDYAN.FilaTipIdx()))
        tag1m = MEDYAN.tag!(c, MEDYAN.FilaTipIdx(c, fila_idx1, true))
        tag1p = MEDYAN.tag!(c, MEDYAN.FilaTipIdx(c, fila_idx1, false))
        tag2m = MEDYAN.tag!(c, MEDYAN.FilaTipIdx(c, fila_idx2, true))
        tag2p = MEDYAN.tag!(c, MEDYAN.FilaTipIdx(c, fila_idx2, false))
        MEDYAN.assert_invariants(c)
        @test issetequal(tags, [tag1m, tag1p, tag2m, tag2p])
        @test allunique([tag1m, tag1p, tag2m, tag2p])
        # removing this filament will cause the filament indexes to be invalid
        # But the tags should still work
        MEDYAN.remove_fila!(c, MEDYAN.FilaIdx(c, tag1m))
        MEDYAN.assert_invariants(c)
        @test !MEDYAN.tag_exists(c, tag1m)
        @test !MEDYAN.tag_exists(c, tag1p)
        @test MEDYAN.tag_exists(c, tag2m)
        @test MEDYAN.tag_exists(c, tag2p)
        @test MEDYAN.FilaIdx(c, tag2m) != fila_idx2
        @test_throws Exception MEDYAN.remove_fila!(c, MEDYAN.FilaIdx(c, tag1m))
        MEDYAN.assert_invariants(c)
        MEDYAN.remove_fila!(c, MEDYAN.FilaIdx(c, tag2p))
        MEDYAN.assert_invariants(c)
        @test isempty(MEDYAN.get_tags(c, MEDYAN.FilaTipIdx()))
    end
    @testset "unlinked monomer tags are removed by minimization" begin
        grid = CubicGrid((4,4,4),500.0)
        c = MEDYAN.example_actin_mech_context(grid)
        fila_idx = MEDYAN.make_fila!(c;
            fila_type= :actin,
            mono_states= ones(UInt8,20),
            node_mids= [0,],
            node_positions= [SA[-27.0, 0.0, 0.0], SA[27.0, 0.0, 0.0]],
        )
        @test isempty(MEDYAN.get_tags(c, MEDYAN.FilaMonoIdx()))
        tag0 = MEDYAN.tag!(c, MEDYAN.FilaMonoIdx(c, fila_idx, 0))
        tag1 = MEDYAN.tag!(c, MEDYAN.FilaMonoIdx(c, fila_idx, 1))
        tag19 = MEDYAN.tag!(c, MEDYAN.FilaMonoIdx(c, fila_idx, 19))
        tag18 = MEDYAN.tag!(c, MEDYAN.FilaMonoIdx(c, fila_idx, 18))
        @test MEDYAN.get_place(c, tag0) == MEDYAN.FilaMonoIdx(c, fila_idx, 0)
        @test MEDYAN.get_place(c, tag19) == MEDYAN.FilaMonoIdx(c, fila_idx, 19)
        @test issetequal(MEDYAN.get_tags(c, MEDYAN.FilaMonoIdx()), [tag0, tag1, tag18, tag19])
        # depolymerization removes tags
        MEDYAN.depolymerize_fila!(c, MEDYAN.FilaTipIdx(c, MEDYAN.FilaIdx(c, tag0), -))
        @test !MEDYAN.place_exists(c, MEDYAN.FilaMonoIdx(c, fila_idx, 0))
        @test !MEDYAN.tag_exists(c, tag0)
        @test MEDYAN.tag_exists(c, tag1)
        MEDYAN.assert_invariants(c)
        MEDYAN.depolymerize_fila!(c, MEDYAN.FilaTipIdx(c, MEDYAN.FilaIdx(c, tag18), +))
        @test !MEDYAN.tag_exists(c, tag19)
        @test MEDYAN.tag_exists(c, tag18)
        @test !MEDYAN.tag_exists(c, tag0)
        @test MEDYAN.tag_exists(c, tag1)
        MEDYAN.assert_invariants(c)
        # mechanics removes unreferenced monomer tags
        minimize_energy!(c)
        @test isempty(MEDYAN.get_tags(c, MEDYAN.FilaMonoIdx()))
        MEDYAN.assert_invariants(c)
        fila_idx1 = MEDYAN.make_fila!(c;
            fila_type= :actin,
            mono_states= ones(UInt8,20),
            node_mids= [0,],
            node_positions= [SA[-27.0, 0.0, 0.0], SA[27.0, 0.0, 0.0]],
        )
        MEDYAN.assert_invariants(c)
        fila_idx2 = MEDYAN.make_fila!(c;
            fila_type= :actin,
            mono_states= ones(UInt8,20),
            node_mids= [0,],
            node_positions= [SA[-27.0, 0.0, 0.0], SA[27.0, 0.0, 0.0]],
        )
        MEDYAN.assert_invariants(c)
        @test !MEDYAN.tag_exists(c, tag1)
        @test !MEDYAN.tag_exists(c, tag18)
        tagf1 = MEDYAN.tag!(c, MEDYAN.FilaMonoIdx(c, fila_idx1, 5))
        tagf2 = MEDYAN.tag!(c, MEDYAN.FilaMonoIdx(c, fila_idx2, 5))
        tags = collect(MEDYAN.get_tags(c, MEDYAN.FilaMonoIdx()))
        MEDYAN.assert_invariants(c)
        @test issetequal(tags, [tagf1, tagf2])
        @test allunique([tagf1, tagf2])
        # removing this filament will cause the filament indexes to be invalid
        # But the tags should still work
        MEDYAN.remove_fila!(c, MEDYAN.FilaIdx(c, tagf1))
        MEDYAN.assert_invariants(c)
        @test !MEDYAN.tag_exists(c, tagf1)
        @test MEDYAN.tag_exists(c, tagf2)
        @test MEDYAN.FilaIdx(c, tagf2) != fila_idx2
        @test_throws Exception MEDYAN.remove_fila!(c, MEDYAN.FilaIdx(c, tagf1))
        MEDYAN.assert_invariants(c)
        MEDYAN.remove_fila!(c, MEDYAN.FilaIdx(c, tagf2))
        MEDYAN.assert_invariants(c)
        @test isempty(MEDYAN.get_tags(c, MEDYAN.FilaMonoIdx()))
    end
end

