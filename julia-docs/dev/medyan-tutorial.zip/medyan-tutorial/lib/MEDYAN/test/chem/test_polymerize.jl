using MEDYAN
using StaticArrays
using Test
using Setfield

@testset "polymerize_fila!" begin
    agent_names = MEDYAN.AgentNames(
        filamentnames= [(:a,[
                            :a,
                            :b,
                            :c,
                        ]),
        ],
    )
    grid= CubicGrid((4,1,1),500.0)
    s= MEDYAN.SysDef(agent_names)
    filamentmechparams = MEDYAN.UNITY_FIL_PARAMS
    add_filament_params!(s, :a, @set(filamentmechparams.spacing=2.5))
    cinit= MEDYAN.Context(s,grid)
    mono_states= [s.state.a.a,s.state.a.a]
    node_positions= [SA[498.0,200,200],SA[502.0,200,200]]
    ftag = MEDYAN.make_fila!(cinit;type = :a, node_mids=[1,], mono_states, node_positions,)
    @testset "plus end polymerization test" begin
        c= deepcopy(cinit)
        @test fila_num_unmin_ends(c, ftag) == (2, 2)
        MEDYAN.polymerize_fila!(c, FilaTipIdx(c, ftag, +), :b)
        @test fila_num_unmin_ends(c, ftag) == (2, 3)
        monstates = MEDYAN.fila_mono_states(c, ftag)
        @test collect(monstates) == [s.state.a.a, s.state.a.a, s.state.a.b]
        @test firstindex(monstates) == 1
        @test lastindex(monstates) == 3
        #new monomer should be 2 nm away in the previus end's plus vector direction.
        @test MEDYAN.get_position.((c,), FilaMonoIdx.((c,), (ftag,), -2:0)) == [SA[499.0,200.0,200.0],SA[501.0,200.0,200.0],SA[503.0,200.0,200.0]]
    end
    @testset "minus end polymerization test" begin
        c= deepcopy(cinit)
        @test fila_num_unmin_ends(c, ftag) == (2, 2)
        MEDYAN.polymerize_fila!(c, FilaTipIdx(c, ftag, -), :b)
        @test fila_num_unmin_ends(c, ftag) == (3, 2)
        monstates = MEDYAN.fila_mono_states(c, ftag)
        @test collect(monstates) == [s.state.a.b,s.state.a.a,s.state.a.a]
        @test firstindex(monstates) == 0
        @test lastindex(monstates) == 2
        #new monomer should be 2 nm away in the previus end's negative plus vector direction.
        @test MEDYAN.get_position.((c,), FilaMonoIdx.((c,), (ftag,), -2:0)) == [SA[497.0,200.0,200.0],SA[499.0,200.0,200.0],SA[501.0,200.0,200.0]]
    end
    @testset "site count optimization tests" begin
        startc, s, ftaga1, junk... = MEDYAN.example_all_sites_context(; check_sitecount_error=true)

        #polymerization minus end
        MEDYAN.test_chem_mutation_sequence(startc, [
            c->MEDYAN.polymerize_fila!(c, FilaTipIdx(c, ftaga1, +), s.state.a.me),
            c->MEDYAN.polymerize_fila!(c, FilaTipIdx(c, ftaga1, +), s.state.a.me),
        ])

        #polymerization plus end
        MEDYAN.test_chem_mutation_sequence(startc, [
            c->MEDYAN.polymerize_fila!(c, FilaTipIdx(c, ftaga1, +), s.state.a.me),
            c->MEDYAN.polymerize_fila!(c, FilaTipIdx(c, ftaga1, +), s.state.a.a),
        ])
    end
end