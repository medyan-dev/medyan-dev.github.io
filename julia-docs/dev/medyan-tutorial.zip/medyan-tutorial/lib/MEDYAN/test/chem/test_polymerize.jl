using MEDYAN
using StaticArrays
using Test
using Setfield

@testset "chem_polymerize!" begin
    agent_names = MEDYAN.AgentNames(
        filamentnames= [(:a,[
                            :a,
                            :b,
                            :c,
                        ]),
        ],
    )
    grid= CubicGrid((4,1,1),500.0)
    s= MEDYAN.SysDef(agent_names)
    filamentmechparams = MEDYAN.UNITY_FIL_PARAMS
    add_filament_params!(s, :a, @set(filamentmechparams.spacing=2.5))
    cinit= MEDYAN.Context(s,grid)
    monomerstates= [s.state.a.a,s.state.a.a]
    nodepositions= [SA[498.0,200,200],SA[502.0,200,200]]
    MEDYAN.chem_newfilament!(cinit;ftid=s.filament.a,node_mids=[1,],monomerstates,nodepositions,)
    @testset "plus end polymerization test" begin
        c= deepcopy(cinit)
        @test fil_num_unmin_ends(c, 1, 1) == (2, 2)
                               #context, ftid, fid, isminusend, newstate
        MEDYAN.chem_polymerize!(c, 1, 1, false,s.state.a.b)
        @test fil_num_unmin_ends(c, 1, 1) == (2, 3)
        monstates = fil_mon_states(c, 1, 1)
        @test collect(monstates) == [s.state.a.a, s.state.a.a, s.state.a.b]
        @test firstindex(monstates) == 1
        @test lastindex(monstates) == 3
        #new monomer should be 2 nm away in the previus end's plus vector direction.
        @test mon_position.((c,), MonomerName.(1,1,1:3)) == [SA[499.0,200.0,200.0],SA[501.0,200.0,200.0],SA[503.0,200.0,200.0]]
    end
    @testset "minus end polymerization test" begin
        c= deepcopy(cinit)
        @test fil_num_unmin_ends(c, 1, 1) == (2, 2)
        MEDYAN.chem_polymerize!(c, 1, 1, true,s.state.a.b)
        @test fil_num_unmin_ends(c, 1, 1) == (3, 2)
        monstates = fil_mon_states(c, 1, 1)
        @test collect(monstates) == [s.state.a.b,s.state.a.a,s.state.a.a]
        @test firstindex(monstates) == 0
        @test lastindex(monstates) == 2
        #new monomer should be 2 nm away in the previus end's negative plus vector direction.
        @test mon_position.((c,), MonomerName.(1,1,0:2)) == [SA[497.0,200.0,200.0],SA[499.0,200.0,200.0],SA[501.0,200.0,200.0]]
    end
    @testset "site count optimization tests" begin
        startc, s, fida1, fida2, fidb1, fidb2 = MEDYAN.example_all_sites_context(; check_sitecount_error=true)

        #polymerization minus end
        MEDYAN.test_chem_mutation_sequence(startc, [
            c->MEDYAN.chem_polymerize!(c, 1, fida1, true, s.state.a.me),
            c->MEDYAN.chem_polymerize!(c, 1, fida1, true, s.state.a.me),
        ])

        #polymerization plus end
        MEDYAN.test_chem_mutation_sequence(startc, [
            c->MEDYAN.chem_polymerize!(c, 1, fida1, false, s.state.a.me),
            c->MEDYAN.chem_polymerize!(c, 1, fida1, false, s.state.a.a),
        ])
    end
end