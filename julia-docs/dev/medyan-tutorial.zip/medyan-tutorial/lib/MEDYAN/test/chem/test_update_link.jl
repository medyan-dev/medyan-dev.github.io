using MEDYAN
using StaticArrays
using Test
using Random

@testset "update_link!" begin
    c, _... = MEDYAN.example_all_sites_context()
    fila_tip_tag1 = MEDYAN.get_place(c, first(MEDYAN.get_tags(c, MEDYAN.FilaTipIdx())))
    mono_tag1 = MEDYAN.tag!(c, MEDYAN.FilaMonoIdx(c, fila_tip_tag1))
    mono_tag2 = MEDYAN.tag!(c, MEDYAN.FilaMonoIdx(c, MEDYAN.FilaIdx(c, mono_tag1), -, 2))
    link = MEDYAN.make_link!(c;
        link_type=:fila_mono_2bonds,
        places=(mono_tag1,),
        bond_states=(nothing, (;k=7.0)),
    )
    MEDYAN.assert_invariants(c)
    @test MEDYAN.get_bond_states(c, link) === (
        (;kr=10.0, kbend=2.0, r0=SA[NaN,NaN,NaN], v̂0=SA[NaN,NaN,NaN],),
        (;k=7.0)
    )
    @test collect(MEDYAN.get_tags(c, link)) == [mono_tag1]
    MEDYAN.update_link!(c;
        link,
        bond_states=(
            (;r0=SA[1.0,2.0,3.0]),
            (;k=5.0)
        )
    )
    MEDYAN.assert_invariants(c)
    @test MEDYAN.get_bond_states(c, link) === (
        (;kr=10.0, kbend=2.0, r0=SA[1.0,2.0,3.0], v̂0=SA[NaN,NaN,NaN],),
        (;k=5.0)
    )
    MEDYAN.update_link!(c;
        link,
        places=(mono_tag2,)
    )
    MEDYAN.assert_invariants(c)
    @test collect(MEDYAN.get_tags(c, link)) == [mono_tag2]
    MEDYAN.update_link!(c;
        link,
        places=(nothing,)
    )
    MEDYAN.assert_invariants(c)
    @test collect(MEDYAN.get_tags(c, link)) == [mono_tag2]
    # replace place with null place
    MEDYAN.update_link!(c;
        link,
        places=(typeof(mono_tag1)(),)
    )
    MEDYAN.assert_invariants(c)
    @test collect(MEDYAN.get_tags(c, link)) == [typeof(mono_tag1)()]

    # bond_enabled
    @test MEDYAN.get_bond_enabled(c, link) === (true, true,)
    MEDYAN.update_link!(c;
        link,
        bond_enabled=(false, nothing)
    )
    MEDYAN.assert_invariants(c)
    @test MEDYAN.get_bond_enabled(c, link) === (false, true,)
    
    # test edge case where a link has two inputs on the same monomer
    link2 = MEDYAN.make_link!(c;
        link_type=:fila_mono_distance_bond,
        places=(mono_tag1, mono_tag1),
        bond_states=((;L0=100.0),),
    )
    MEDYAN.assert_invariants(c)
    @test collect(MEDYAN.get_tags(c, link2)) == [mono_tag1, mono_tag1,]
    MEDYAN.update_link!(c;
        link=link2,
        places=(mono_tag2, nothing)
    )
    MEDYAN.assert_invariants(c)
    @test collect(MEDYAN.get_tags(c, link2)) == [mono_tag2, mono_tag1,]
    MEDYAN.update_link!(c;
        link=link2,
        places=(nothing, mono_tag2)
    )
    MEDYAN.assert_invariants(c)
    @test collect(MEDYAN.get_tags(c, link2)) == [mono_tag2, mono_tag2,]
    MEDYAN.update_link!(c;
        link=link2,
        places=(nothing, nothing)
    )
    MEDYAN.assert_invariants(c)
    @test collect(MEDYAN.get_tags(c, link2)) == [mono_tag2, mono_tag2,]
    MEDYAN.remove_link!(c, link2)
    MEDYAN.assert_invariants(c)
end