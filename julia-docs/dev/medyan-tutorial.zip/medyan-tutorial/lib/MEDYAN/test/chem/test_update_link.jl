using MEDYAN
using StaticArrays
using Test
using Random
using LinearAlgebra

@testset "update_link!" begin
    c, _... = MEDYAN.example_all_sites_context()
    fila_tip_tag1 = MEDYAN.get_place(c, first(MEDYAN.get_tags(c, MEDYAN.FilaTipIdx())))
    mono_tag1 = MEDYAN.tag!(c, MEDYAN.FilaMonoIdx(c, fila_tip_tag1))
    mono_tag2 = MEDYAN.tag!(c, MEDYAN.FilaMonoIdx(c, MEDYAN.FilaIdx(c, mono_tag1), -, 2))
    link = MEDYAN.make_link!(c;
        type=:fila_mono_2bonds,
        places=(mono_tag1,),
        bond_states=(nothing, (;k=7.0)),
    )
    MEDYAN.assert_invariants(c)
    @test MEDYAN.get_bond_states(c, link) === (
        (;kr=10.0, kbend=2.0, r0=SA[NaN,NaN,NaN], v̂0=SA[NaN,NaN,NaN],),
        (;k=7.0)
    )
    @test collect(MEDYAN.get_tags(c, link)) == [mono_tag1]
    MEDYAN.update_link!(c,
        link;
        bond_states=(
            (;r0=SA[1.0,2.0,3.0]),
            (;k=5.0)
        )
    )
    MEDYAN.assert_invariants(c)
    @test MEDYAN.get_bond_states(c, link) === (
        (;kr=10.0, kbend=2.0, r0=SA[1.0,2.0,3.0], v̂0=SA[NaN,NaN,NaN],),
        (;k=5.0)
    )
    MEDYAN.update_link!(c,
        link;
        places=(mono_tag2,)
    )
    MEDYAN.assert_invariants(c)
    @test collect(MEDYAN.get_tags(c, link)) == [mono_tag2]
    MEDYAN.update_link!(c,
        link;
        places=(nothing,)
    )
    MEDYAN.assert_invariants(c)
    @test collect(MEDYAN.get_tags(c, link)) == [mono_tag2]
    # replace place with null place
    MEDYAN.update_link!(c,
        link;
        places=(typeof(mono_tag1)(),)
    )
    MEDYAN.assert_invariants(c)
    @test collect(MEDYAN.get_tags(c, link)) == [typeof(mono_tag1)()]

    # bond_enabled
    @test MEDYAN.get_bond_enabled(c, link) === (true, true,)
    MEDYAN.update_link!(c,
        link;
        bond_enabled=(false, nothing)
    )
    MEDYAN.assert_invariants(c)
    @test MEDYAN.get_bond_enabled(c, link) === (false, true,)
    
    # test edge case where a link has two inputs on the same monomer
    link2 = MEDYAN.make_link!(c;
        type=:fila_mono_distance_bond,
        places=(mono_tag1, mono_tag1),
        bond_states=((;L0=100.0),),
    )
    MEDYAN.assert_invariants(c)
    @test collect(MEDYAN.get_tags(c, link2)) == [mono_tag1, mono_tag1,]
    MEDYAN.update_link!(c,
        link2;
        places=(mono_tag2, nothing)
    )
    MEDYAN.assert_invariants(c)
    @test collect(MEDYAN.get_tags(c, link2)) == [mono_tag2, mono_tag1,]
    MEDYAN.update_link!(c,
        link2;
        places=(nothing, mono_tag2)
    )
    MEDYAN.assert_invariants(c)
    @test collect(MEDYAN.get_tags(c, link2)) == [mono_tag2, mono_tag2,]
    MEDYAN.update_link!(c,
        link2;
        places=(nothing, nothing)
    )
    MEDYAN.assert_invariants(c)
    @test collect(MEDYAN.get_tags(c, link2)) == [mono_tag2, mono_tag2,]
    MEDYAN.remove_link!(c, link2)
    MEDYAN.assert_invariants(c)
end

@testset "update_link! bond_enabled" begin
    grid = CubicGrid((4,4,4),500.0)
    c = MEDYAN.example_actin_mech_context(grid; g_tol=0.0001)
    fila_idx = MEDYAN.make_fila!(c;
        type= :actin,
        mono_states= ones(UInt8,20),
        node_mids= [0,],
        node_positions= [SA[-27.0, 0.0, 0.0], SA[27.0, 0.0, 0.0]],
    )
    minus_fila_tip_idx = MEDYAN.FilaTipIdx(c, fila_idx, -)
    plus_fila_tip_idx = MEDYAN.FilaTipIdx(c, fila_idx, +)
    link_tag1 = MEDYAN.make_link!(c;
        type= :fila_tip_restraint,
        places= (minus_fila_tip_idx,),
        bond_states = ((;
            r0=SA[-28.0,0.0,0.0],
            v̂0=SA[1.0,0.0,0.0],
        ),),
    )
    link_tag2 = MEDYAN.make_link!(c;
        type= :fila_tip_restraint,
        places= (minus_fila_tip_idx,),
        bond_states = ((;
            kbend=100.0,
            r0=SA[-27.0,0.0,0.0],
            v̂0=SA[0.0,1.0,0.0],
        ),),
        bond_enabled = (false,)
    )
    @test !MEDYAN.get_is_minimized(c, link_tag1)
    @test !MEDYAN.get_is_minimized(c, link_tag2)
    minimize_energy!(c)
    @test MEDYAN.get_is_minimized(c, link_tag1)
    @test MEDYAN.get_is_minimized(c, link_tag2)
    @test norm(
        MEDYAN.get_position(c, minus_fila_tip_idx) - SA[-28.0,0.0,0.0]
    ) < 0.1
    @test norm(
        MEDYAN.get_directions(c, minus_fila_tip_idx)[1] - SA[1.0,0.0,0.0]
    ) < 0.1
    # disable the first link bond, enable the second
    MEDYAN.update_link!(c,
        link_tag1;
        bond_enabled=(false,)
    )
    MEDYAN.update_link!(c,
        link_tag2;
        bond_enabled=(true,)
    )
    @test !MEDYAN.get_is_minimized(c, link_tag1)
    @test !MEDYAN.get_is_minimized(c, link_tag2)
    minimize_energy!(c)
    @test MEDYAN.get_is_minimized(c, link_tag1)
    @test MEDYAN.get_is_minimized(c, link_tag2)
    @test norm(
        MEDYAN.get_position(c, minus_fila_tip_idx) - SA[-27.0,0.0,0.0]
    ) < 0.1
    @test norm(
        MEDYAN.get_directions(c, minus_fila_tip_idx)[1] - SA[0.0,1.0,0.0]
    ) < 0.1
end

@testset "update_link! chemistry" begin
    grid= CubicGrid((3,1,1),500.0)
    agent_names = MEDYAN.AgentNames(
        filamentnames= [(:a,[
                                :m,
                            ]),
        ],
    )
    s = MEDYAN.SysDef(agent_names)
    add_filament_params!(s, :a, MEDYAN.UNITY_FIL_PARAMS)
    MEDYAN.add_link_type!(s;
        name = :r,
        description = "test link",
        state = (;sitecount=0.0,),
        places = [MEDYAN.FilaMonoIdx(), MEDYAN.FilaMonoIdx()],
        reactions = [
            [(;
                affect! = Returns(1),
                rate = (c; link_state, kwargs...) -> (link_state.sitecount),
            )],
            [(;
                affect! = Returns(1),
                rate = (c; link_state, kwargs...) -> (10*link_state.sitecount),
            )],
        ]
    )
    fxsid1 = s.link_reaction_site.r.place1_reaction1.fxsid
    fxsid2 = s.link_reaction_site.r.place2_reaction1.fxsid
    NMonomers = 3
    monomerstates = ones(MonomerState,3)
    #start monomers in the third compartment
    nodepositions = [SA[449.5,0,0], SA[452.5,0,0]]
    cinit = MEDYAN.Context(s,grid; check_sitecount_error=true)
    fila_idx = MEDYAN.make_fila!(cinit;
        type= :a,
        mono_states= monomerstates,
        node_mids= [1,],
        node_positions= nodepositions,
    )
    @testset "site count when one link_2mon" begin
        c = deepcopy(cinit)
        link_tag = MEDYAN.make_link!(c;
            type = :r,
            places = (MEDYAN.FilaMonoIdx(c, fila_idx, 2), MEDYAN.FilaMonoIdx(c, fila_idx, 2),),
        )
        @test c.chemistryengine.fixedcounts[fxsid1, :] == [0,0,0]
        @test c.chemistryengine.fixedcounts[fxsid2, :] == [0,0,0]
        MEDYAN.update_link!(c, link_tag; state=(;sitecount=1.0))
        @test c.chemistryengine.fixedcounts[fxsid1, :] == [0,0,1]
        @test c.chemistryengine.fixedcounts[fxsid2, :] == [0,0,10]
        MEDYAN.update_link!(c, link_tag; state=(;sitecount=2.0))
        @test c.chemistryengine.fixedcounts[fxsid1, :] == [0,0,2]
        @test c.chemistryengine.fixedcounts[fxsid2, :] == [0,0,20]
        # detach one end
        MEDYAN.update_link!(c, link_tag; places=(MEDYAN.FilaMonoIdx(), nothing))
        @test c.chemistryengine.fixedcounts[fxsid1, :] == [0,0,0]
        @test c.chemistryengine.fixedcounts[fxsid2, :] == [0,0,20]
        MEDYAN.update_link!(c, link_tag; places=(MEDYAN.FilaMonoIdx(c, fila_idx, 2), MEDYAN.FilaMonoIdx()))
        @test c.chemistryengine.fixedcounts[fxsid1, :] == [0,0,2]
        @test c.chemistryengine.fixedcounts[fxsid2, :] == [0,0,0]
        MEDYAN.update_link!(c, link_tag; places=(MEDYAN.FilaMonoIdx(), MEDYAN.FilaMonoIdx()))
        @test c.chemistryengine.fixedcounts[fxsid1, :] == [0,0,0]
        @test c.chemistryengine.fixedcounts[fxsid2, :] == [0,0,0]
        MEDYAN.update_link!(c, link_tag; places=(MEDYAN.FilaMonoIdx(c, fila_idx, 2), MEDYAN.FilaMonoIdx(c, fila_idx, 2)))
        @test c.chemistryengine.fixedcounts[fxsid1, :] == [0,0,2]
        @test c.chemistryengine.fixedcounts[fxsid2, :] == [0,0,20]
        # disable reaction
        MEDYAN.update_link!(c, link_tag; reaction_enabled=((),(false,)))
        @test c.chemistryengine.fixedcounts[fxsid1, :] == [0,0,2]
        @test c.chemistryengine.fixedcounts[fxsid2, :] == [0,0,0]
        MEDYAN.update_link!(c, link_tag; reaction_enabled=((),(true,)))
        @test c.chemistryengine.fixedcounts[fxsid1, :] == [0,0,2]
        @test c.chemistryengine.fixedcounts[fxsid2, :] == [0,0,20]
    end
    @testset "defer chem cache when one link_2mon" begin
        c = deepcopy(cinit)
        link_tag = MEDYAN.make_link!(c;
            type = :r,
            places = (MEDYAN.FilaMonoIdx(c, fila_idx, 2), MEDYAN.FilaMonoIdx(c, fila_idx, 2),),
        )
        MEDYAN.test_chem_mutation_sequence(c, [
            c->MEDYAN.update_link!(c, link_tag; state=(;sitecount=1.0)),
            c->MEDYAN.update_link!(c, link_tag; state=(;sitecount=2.0)),
            c->MEDYAN.update_link!(c, link_tag; places=(MEDYAN.FilaMonoIdx(), nothing)),
            c->MEDYAN.update_link!(c, link_tag; places=(MEDYAN.FilaMonoIdx(c, fila_idx, 2), MEDYAN.FilaMonoIdx())),
            c->MEDYAN.update_link!(c, link_tag; places=(MEDYAN.FilaMonoIdx(), MEDYAN.FilaMonoIdx())),
            c->MEDYAN.update_link!(c, link_tag; places=(MEDYAN.FilaMonoIdx(c, fila_idx, 3), MEDYAN.FilaMonoIdx())),
            c->MEDYAN.update_link!(c, link_tag; places=(MEDYAN.FilaMonoIdx(c, fila_idx, 2), MEDYAN.FilaMonoIdx(c, fila_idx, 2))),
            c->MEDYAN.update_link!(c, link_tag; reaction_enabled=((),(false,))),
            c->MEDYAN.update_link!(c, link_tag; reaction_enabled=((),(true,))),
        ])
    end
end