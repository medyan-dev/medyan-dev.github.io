using MEDYAN
using Test
using StaticArrays
using LinearAlgebra
using Random
@testset "decimated_2mon site count edge case" begin
    """
    Return the context and sysdef
    """
    function setup()
        agent_names = MEDYAN.AgentNames(
            filamentnames= [(:actin,[
                                    :AF, # middle actin
                                    :PA, # plus end actin
                                    :MA, # minus end actin
                                    :bound, # general bound actin
                                ]),
            ],
        )
        grid = CubicGrid((10,10,1),400.0)
        # add reactions
        begin
            s= MEDYAN.SysDef(agent_names)
            add_filament_params!(s, :actin, MEDYAN.ACTIN_FIL_PARAMS)

            motorstepsize = 10

            #motor binding
            site = MEDYAN.Decimated2MonSiteMinAngleRange(
                s.filament.actin,
                s.filament.actin,
                motorstepsize,
                motorstepsize,
                s.state.actin.AF,
                s.state.actin.AF,
                175.0,
                225.0,
                cos(5*π/180),
            )
            add_decimated_2mon_site!(s,:motorbinding,site)
        end
        c= MEDYAN.Context(s,grid;
            check_sitecount_error = true,
            g_tol=1.0,
            max_cylinder_force = 2000.0,
            maxstep = 0.7,
        )
        return c,s
    end

    c,s = setup()

    site_data = s.decimated_2mon_site.motorbinding

    # with no filaments the decimated_2mon site count should be zero
    @test reduce(+,MEDYAN.helper_total_decimated_2mon_sitecount_sameftid(c, site_data)) == 0
    @test reduce(+,c.chemistryengine.fixedcounts[site_data.fxsid,:]) == 0

    nodepos1 = SVector{3, Float64}[
        [373.5, 1689.125, 75.625],
        [420.625, 1592.0, 74.375],
        [467.625, 1494.75, 72.875],
        [514.375, 1397.375, 71.375],
        [561.125, 1300.125, 70.0],
        [608.0, 1202.75, 69.125],
        [654.75, 1105.5, 68.625],
        [701.5, 1008.125, 68.375],
        [748.25, 910.75, 68.375],
        [794.75, 813.25, 68.5],
        [841.0, 715.625, 68.75],
        [887.125, 618.0, 69.125],
        [933.125, 520.25, 69.5],
        [978.875, 422.5, 69.75],
        [1024.625, 324.625, 70.0],
        [1061.25, 246.375, 70.125],
    ]
    node_mids1 = [200, 240, 280, 320, 360, 400, 440, 480, 520, 560, 600, 640, 680, 720, 760]
    monomerstates1 = fill(s.state.actin.AF, 592)
    monomerstates1[begin] = s.state.actin.MA
    monomerstates1[end] = s.state.actin.PA
    fid1 = chem_newfilament!(c;
        monomerstates=monomerstates1,
        node_mids=node_mids1,
        nodepositions=nodepos1,
    )

    # when new filaments are added they are not linkable, so the decimated_2mon site count should be zero
    @test reduce(+,MEDYAN.helper_total_decimated_2mon_sitecount_sameftid(c, site_data)) == 0
    @test reduce(+,c.chemistryengine.fixedcounts[site_data.fxsid,:]) == 0

    nodepos2 = SVector{3, Float64}[
        [1031.0, 983.75, 217.12499999999997],
        [1007.5, 1006.0, 217.125],
        [929.0, 1080.25, 217.25],
        [850.875, 1154.75, 217.125],
        [772.875, 1229.375, 216.5],
        [695.125, 1304.5, 215.5],
        [618.5, 1380.5, 214.75],
        [543.0, 1457.625, 214.0],
        [468.75, 1536.125, 213.25],
        [395.875, 1615.875, 212.25],
        [324.5, 1696.875, 211.125],
        [255.0, 1779.5, 211.75],
        [186.375, 1862.875, 210.25],
        [118.375, 1946.75, 207.625],
        [50.625, 2030.875, 204.5],
        [18.5, 2070.75, 203.0],
    ]
    node_mids2 = [228, 240, 280, 320, 360, 400, 440, 480, 520, 560, 600, 640, 680, 720, 760]
    monomerstates2 = fill(s.state.actin.AF, 551)
    monomerstates2[begin] = s.state.actin.MA
    monomerstates2[end] = s.state.actin.PA
    fid2 = chem_newfilament!(c;
        monomerstates=monomerstates2,
        node_mids=node_mids2,
        nodepositions=nodepos2,
    )

    # when new filaments are added they are not linkable, so the decimated_2mon site count should be zero
    @test reduce(+,MEDYAN.helper_total_decimated_2mon_sitecount_sameftid(c, site_data)) == 0
    @test reduce(+,c.chemistryengine.fixedcounts[site_data.fxsid,:]) == 0
    
    # This function is normally automatically called after minimization
    # For this test I am avoiding any minimization, so I use these helper functions.
    MEDYAN.helper_mark_monomers_minimized!(c)
    MEDYAN.refresh_chem_cache!(c)

    # after minimization filaments are marked as linkable.
    @test reduce(+,MEDYAN.helper_total_decimated_2mon_sitecount_sameftid(c, site_data)) == 302
    # decimated_2mon sites with the wrong state will still get added the fixedsitecounts
    @test reduce(+,c.chemistryengine.fixedcounts[site_data.fxsid,:]) == 314

    MEDYAN.helper_check_sitecount_error(c)
    chem_depolymerize!(c, 1, 1, true)
end