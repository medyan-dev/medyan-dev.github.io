using MEDYAN
using StaticArrays
using Dictionaries
using Test

@testset "add cadherin, cadherin site, possible cadherinsite!" begin
	agentnames = MEDYAN.AgentNames(
		filamentnames= [(:a,[
	                            :m,
	                        ]),
		],
        vertexnames = [:ver,],
        cadherinnames = [:filaver,]
	)
    s = MEDYAN.SysDef(agentnames)
    addcadherin!(s,
        :filaver,
        CadherinState((sitecount=0.0,),(;)),
        nothing,
    )
    site = MEDYAN.CadherinSiteCount()
    addcadherinsite!(s,:filaver,:mycadsite,site)

    site1 = MEDYAN.PossibleCadherinSiteRange(1,1,3,1,1,6.0,1.0)
    addpossiblecadherinsite!(s,:mypossiblecadsite,site1)

end

