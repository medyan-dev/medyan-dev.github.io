using MEDYAN
using FixedPointNumbers
using StaticArrays
using LinearAlgebra
using Test
import DataStructures
using MeshCat

@testset "test randomly pick cadherin sites" begin
    agentnames = MEDYAN.AgentNames(
            filamentnames= [(:a,[
                                :me,
                                :a,
                                :b,
                                :c,
                                :pe,
                            ]),
            ],
            vertexnames = [:ver1, :ver2],
            cadherinnames = [:filaver,],

        )
    filamentmechparams= [
        MEDYAN.FilamentMechParams(
            radius= 1.0,
            spacing= 10.0,
            klength= 1.0,
            kangle= 1.0,
            numpercylinder= 40,
            max_num_unmin_end= 1000,
        ),
    ]
    grid= CubicGrid((3,3,3),500.0)
    s = MEDYAN.SysDef(agentnames)# set membrane type to be 1. 
    
    site = MEDYAN.PossibleCadherinSiteRange(1,s.filament.a,1,s.vertex.ver2,s.state.a.a,1.0,150.0)#range too large
    addpossiblecadherinsite!(s,:sitename,site)


    membranemechparams = [
        MEDYAN.MembraneMechParams(
            kbend = 100,
            tension = 0.02,
            kpinning = 10,
        ),
    ]

    c= MEDYAN.Context(s,grid;
        filamentmechparams,
        membranemechparams,
        check_sitecount_error=true
    )
    set_mechboundary!(c, MEDYAN.helper_create_mechboundary(grid, 100))

    #Add membrane
    m1 = newmembrane!(c; type=1, meshinit=MEDYAN.MeshInitPlane(
        boxorigin = SA[0,0,100],
        boxwidths = SA[1500,1500,300],
        normal = SA[0,0,1],
        normal_multiplier_from_origin = 200,
        samples = (40,40,2),
    ))
        
    MEDYAN.compute_geometry!_system(m1)
    MEDYAN.adapt_membranes!(c)
    MEDYAN.resetvertexstate!(m1,s)
    MEDYAN.compute_all_membrane_geometry!_system(c;include_ff=true)

    nodepositionsA = [SA[5.0,200.0,100.0], SA[5.0+9*10.0,200.0,100.0]]
    nodepositionsB = [SA[15.0,201.0,100.0], SA[15.0+9*10.0,201.0,100.0]]
    nodepositionsC = [SA[470.0,200.0,100.0], SA[470.0+9*10.0,200.0,100.0]]
    nodepositionsD = [SA[480.0,201.0,100.0], SA[480.0+9*10.0,201.0,100.0]]

    nummonomers= 9
    monomerstates= zeros(MonomerState,nummonomers)
    monomerstates[1]= s.state.a.me# minus end/ plus end
    monomerstates[2:end-1].= s.state.a.a
    monomerstates[end]= s.state.a.pe
    nodepositions = [SA[10.0,200.0,100.0], SA[10.0+nummonomers*100.0,200.0,100.0]]
    fid = MEDYAN.chem_newfilament!(c; ftid=s.filament.a,monomerstates,node_mids=[1,], nodepositions)
    MEDYAN.helper_mark_monomers_minimized!(c)
    MEDYAN.compartmentalize!(c)

    # println(s.possiblecadherinsite.sitename.id)
    pcadsid = s.possiblecadherinsite.sitename.id#id is from SiteDta, also sid
    # println("pcadsid = $pcadsid")# pcadsid = 1
    local manager = c.possiblecadherinsite_managers[pcadsid]
    # println(s.possiblecadherinsite.sitename.site)
    pairlists = manager.system.output.pairlists
    # println(pairlists)# build pairlists
    namepairs = map(pairlists) do pairlist
        map(pairlist) do pair
            MEDYAN.index2vert_mononames(manager, pair)
        end
    end
    # println(length(namepairs))#namepairs[cid]#compartment id
    # println(namepairs)

    pickedpairs = Vector{Tuple{VertexName, MonomerName}}()
    for cid in 1:length(c.grid)
        pickedpair = MEDYAN.pickrandompossiblecadherinsite(c,cid,pcadsid)
        if pickedpair !== nothing
            push!(pickedpairs, pickedpair)
        end
    end

    count = 0
    for idx in 1:length(pickedpairs)
        for cid in 1:length(c.grid)
            if in(pickedpairs[idx], namepairs[cid])
                count = count+1
            end
        end
    end

    @test length(pickedpairs) == count

    # Initialize visualizer
    vis1 = Visualizer()
    MEDYAN.drawcontext!(vis1, c, s)
    # delete!(vis1)
    setvisible!(vis1["/Grid"],true)
    setvisible!(vis1["/Axes"],false)
    setvisible!(vis1["/Background"],true)
    setvisible!(vis1["/meshcat/mechboundary"],false)

    render(vis1)
    
end
