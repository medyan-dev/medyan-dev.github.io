using MEDYAN
using StaticArrays
using Dictionaries
using Test
using Setfield

@testset "Test vertex-monomer reactions" begin
    grid= CubicGrid((3,1,1),500.0)
    agentnames = MEDYAN.AgentNames(
		filamentnames= [(:a,[
	                            :m,
                                :k,
                                :g,
                                :bound,
	                        ]),
		],
        link_2mon_names= [
            :crosslinker,
        ],
        vertexnames = [:ver,:ver1,:ver2,:ver3],
        cadherinnames = [:filaver,],
        diffusingspeciesnames = [:cl],
	)
    s = MEDYAN.SysDef(agentnames)
    default_actin = MEDYAN.ACTIN_FIL_PARAMS
    add_filament_params!(s, :a, @set(default_actin.numpercylinder = 2)) #number of monomers in each cylinder 40 to 2
    # Initiate a membrane
    m = MEDYAN.create_membranemesh()
    trilist = [SA[1,2,3], SA[3,2,4]]
    vertlist = [SA[0,0,0], SA[1,0,0], SA[1000,500,500], SA[600,500,1]]
    id = [222,777,888,999]
    vertexstate = zeros(MEDYAN.VertexState,4)
    vertexstate = [s.vertex[1], s.vertex[2], s.vertex[1], s.vertex[3]]
    MEDYAN.initmesh!(m,(; vertlist, trilist, id, vertexstate))


    #Add cadherin to the the system
    cadherinstate = CadherinState((sitecount=0.0,),(L0=1.0,))#(;)
    addcadherin!(s,
        :filaver,
        cadherinstate,
        nothing,
    )
    
    #Add cadherinsites to system 
    site = MEDYAN.CadherinSiteSlipBond(f0=4.9,k0=2.0) #or CadherinSiteCount()
    addcadherinsite!(s,:filaver,:mycadsite,site)
    
    c = MEDYAN.Context(s,grid)
    push!(c.membranes, m)
    

    #Return compartment id by input Contex, Vertexname(membraneindex, vid)
    # println("before_update_compartment = $(c.compartments)")
    MEDYAN.helper_update_allverticesincompartments!(c)
    name1 = VertexName(1, 888)
    MEDYAN.get_compartment_id_byvertexname(c,name1)
    # println(MEDYAN.get_compartment_id_byvertexname(c,name1))
    # println("after_update_c.compartment = $(c.compartments)")
    # println("m.vertices.attr.id = $(m.vertices.attr.id)")


    # Vertex STATES
    # vertexstate and mapvertexid_state
    # println("vertexnames = $(s.agentnames.vertexnames)")  
    # println("s.vertex = $(s.vertex)")
    # println("id_state_dict = $(m.vertices.attr.mapvertexid_state)") 

    #Initiate filament
    nmon = 10
    monomerstates = zeros(MonomerState,10)
    monomerstates[1] = s.state.a.m
    monomerstates[end] = s.state.a.g
    monomerstates[2:end-1] .= s.state.a.k
    nodepositions = [SA[490.0, 200.0, 200.0],SA[502.0, 200.0, 200.0],SA[509.0, 200.0, 200.0]]
    node_mids = [0, 2, 10, ]
    MEDYAN.chem_newfilament!(c;
            ftid= 1, 
            monomerstates,
            node_mids,
            nodepositions,
        )
    @test length(node_mids) == 3
    @test node_mids[end] == 10

    @testset "Give default vertexstate value when vertex state is not defined" begin
        m1 = MEDYAN.create_membranemesh()
        trilist = [SA[1,2,3]]
        vertlist = [SA[0,0,0], SA[1,0,0], SA[1000,500,500]]
        id = [222,777,888]
        MEDYAN.initmesh!(m1,(; vertlist, trilist, id))
        @test m1.vertices.attr.vertexstate == [0x01, 0x01, 0x01]
    end

    @testset "chem_newcadherin!, chem_setcadherinstate!, chem_removecadherin!" begin
        #Cadherin Chemistry. Vertex and Monomer should be in same compartment.
        name1 = VertexName(1,999)
        name2 = MonomerName(1,1,7)

        
        # Add one new cadherin"
        chem_newcadherin!(c,s.cadherin.filaver,name1=>name2,cadherinstate)

        # Set cadherin state
        chemstate = (sitecount=1.0,)
        mechstate = (L0 = 2.0,)#(;)
        cadherinstate_changed = CadherinState(chemstate, mechstate)
        chem_setcadherinstate!(c, s.cadherin.filaver, name1=>name2,cadherinstate_changed)
        # for cadherinparams, the cadherinstate is the default sate given by initial cadherinstate 
        

        @test length(c.cadherindata[1].states) == 1# 1 is the cadherin type
        @test c.chemistryengine.fixedcounts[1,:] == [0,2,0] #cadherin site id = 1, compartment id = 2 

        # Remove one cadherin
        chem_removecadherin!(c, s.cadherin.filaver, name1=>name2)
        @test length(c.cadherindata[1].states) == 0
        @test all(c.chemistryengine.fixedcounts[1,:] == [0,0,0])#fixed count doesn't change after simple remove


        # Reset the cadherindata to update fixedcounts
        MEDYAN.compartmentalize!(c)
        @test length(c.cadherindata[1].states) == 0
        @test all(c.chemistryengine.fixedcounts[1,:] == [0,0,0])

        # Add three cadherins in different compartments
        name1 = VertexName(1,999)
        name2 = MonomerName(1,1,7)
        name3 = VertexName(1,222)
        name4 = MonomerName(1,1,0)
        name5 = VertexName(1,777)
        name6 = MonomerName(1,1,1)

        chem_newcadherin!(c,s.cadherin.filaver,name1=>name2,cadherinstate)# cid = 2
        chem_newcadherin!(c,s.cadherin.filaver,name3=>name4,cadherinstate)# cid = 1
        chem_newcadherin!(c,s.cadherin.filaver,name5=>name6,cadherinstate)# cid = 1
        @test all(c.chemistryengine.fixedcounts[1,:] == [4,2,0])

    end

    @testset "pickrandom cadherin site" begin
        MEDYAN.pickrandomcadherinsite(c, 1, 1, 1)
    end

    @testset "Add unbinding cadherin" begin
        
        MEDYAN.addunbindingcadherinsite!(
            s, :filaver, :unbindingcadsite, site, :a, :k, 
            " --> ", 1.0, 0,
        )
        @test s.cadherinsite.filaver.unbindingcadsite.fxsid == 2

    end

    @testset "Cadherin Binding Callback" begin
        # Reaction callback
        site = MEDYAN.PossibleCadherinSiteRange(
            1,#meshid
            s.filament.a,
            1,
            s.vertex.ver2,
            s.state.a.k,
            30.0,
            40.0)
        addpossiblecadherinsite!(s,:filaver,site)

        sitecallback = MEDYAN.SimpleCadherinBindCallback(
            s.possiblecadherinsite.filaver.id,
            s.cadherin.filaver,
            s.state.a.bound,
        )
        
        addreactioncallback!(s,
            "possiblecadherinsite.filaver",
            0.01*500^3/2,
            1,
            sitecallback,
        )
        # @test s.compartmentreactioncallbacks == Any[MEDYAN.SimpleCadherinBindCallback(1, 1, 0x04), MEDYAN.UnbindingCadherinCallback(1, 2, 0x02)]
    end
    

end