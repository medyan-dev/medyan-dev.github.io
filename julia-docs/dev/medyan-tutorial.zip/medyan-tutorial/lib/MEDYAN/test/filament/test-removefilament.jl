using MEDYAN
using StaticArrays
using Test

@testset "chem_removefilament!" begin
    @testset "site count optimization tests" begin
        startc, s, fida1, fida2, fidb1, fidb2 = MEDYAN.example_all_sites_context(; check_sitecount_error=true)

        MEDYAN.test_chem_mutation_sequence(startc, [
            c->MEDYAN.remove_fila!(c, fida1;
                warn_if_unlink = false,
            ),
            c->MEDYAN.remove_fila!(c, fida2;
                warn_if_unlink = false,
            ),
            c->MEDYAN.remove_fila!(c, fidb1;
                warn_if_unlink = false,
            ),
            c->MEDYAN.remove_fila!(c, fidb2;
                warn_if_unlink = false,
            ),
        ])
    end
end