using MEDYAN
using StaticArrays
using Test
using LinearAlgebra
using Setfield

@testset "interpolate_chem_beads" begin
    ≊(a,b) = isapprox(a, b; atol = 1E-9)
    function test_filament_nodepositions_roundtrip!(chembeadpos, mon_id_first, mon_id_last, numpercylinder)
        other_args = (mon_id_first, mon_id_last, numpercylinder)
        prev_chembeadpos = copy(chembeadpos)
        nodepos = MEDYAN._get_nodepositions(chembeadpos, other_args...)
        MEDYAN.set_nodepositions!(chembeadpos, nodepos, other_args...)
        @test eachindex(nodepos) == eachindex(chembeadpos)
        @test eachindex(nodepos) == eachindex(prev_chembeadpos)
        @test @views(nodepos[begin+1:end-1] == chembeadpos[begin+1:end-1])
        @test prev_chembeadpos == chembeadpos
    end
    @testset "two cylinder one monomer per cylinder" begin
        chembeadpos = MEDYAN.interpolate_chem_beads(
            [0,2],
            [SA[-0.5,0.0,0.0],SA[1.5,0.0,0.0]],
            1,
        )
        @test chembeadpos[1] ≊ SA[-0.5,0.0,0.0]
        @test chembeadpos[2] ≊ SA[0.5,0.0,0.0]
        @test chembeadpos[3] ≊ SA[1.5,0.0,0.0]
        mon_id_info = (0, 1, 1) # first mon id, last mon id, num mon per cyl
        @test MEDYAN._fil_node_mon_ids(mon_id_info...) == [0,1,2]
        @test MEDYAN.get_fil_chem_cyl_idx_frac(0, mon_id_info...) == (1, 0.5)
        @test MEDYAN.get_fil_chem_cyl_idx_frac(1, mon_id_info...) == (2, 0.5)
        nodepos = MEDYAN._get_nodepositions(chembeadpos, mon_id_info...)
        @test nodepos == chembeadpos
        test_filament_nodepositions_roundtrip!(chembeadpos, mon_id_info...)
    end
    @testset "two cylinder one monomer per cylinder more nodes" begin
        chembeadpos = MEDYAN.interpolate_chem_beads(
            [0,1,2],
            [SA[-0.5,0.0,0.0],SA[0.5,0.0,0.0],SA[1.5,0.0,0.0]],
            1,
        )
        @test chembeadpos[1] ≊ SA[-0.5,0.0,0.0]
        @test chembeadpos[2] ≊ SA[0.5,0.0,0.0]
        @test chembeadpos[3] ≊ SA[1.5,0.0,0.0]
        mon_id_info = (0, 1, 1) # first mon id, last mon id, num mon per cyl
        @test MEDYAN.get_fil_chem_cyl_idx_frac(0, mon_id_info...) == (1, 0.5)
        @test MEDYAN.get_fil_chem_cyl_idx_frac(1, mon_id_info...) == (2, 0.5)
        nodepos = MEDYAN._get_nodepositions(chembeadpos, mon_id_info...)
        @test nodepos == chembeadpos
        test_filament_nodepositions_roundtrip!(chembeadpos, mon_id_info...)
    end
    @testset "three cylinder one monomer per cylinder" begin
        chembeadpos = MEDYAN.interpolate_chem_beads(
            [0,3],
            [SA[-0.5,0.0,0.0],SA[2.5,0.0,0.0]],
            1,
        )
        @test chembeadpos[1] ≊ SA[-0.5,0.0,0.0]
        @test chembeadpos[2] ≊ SA[0.5,0.0,0.0]
        @test chembeadpos[3] ≊ SA[1.5,0.0,0.0]
        @test chembeadpos[4] ≊ SA[2.5,0.0,0.0]
        mon_id_info = (0, 2, 1) # first mon id, last mon id, num mon per cyl
        @test MEDYAN.get_fil_chem_cyl_idx_frac(0, mon_id_info...) == (1, 0.5)
        @test MEDYAN.get_fil_chem_cyl_idx_frac(1, mon_id_info...) == (2, 0.5)
        @test MEDYAN.get_fil_chem_cyl_idx_frac(2, mon_id_info...) == (3, 0.5)
        nodepos = MEDYAN._get_nodepositions(chembeadpos, mon_id_info...)
        @test nodepos == chembeadpos
        test_filament_nodepositions_roundtrip!(chembeadpos, mon_id_info...)
    end
    @testset "two cylinder, two monomers, four monomer per cylinder" begin
        chembeadpos = MEDYAN.interpolate_chem_beads(
            [-1,1],
            [SA[-0.5,0.0,0.0],SA[1.5,0.0,0.0]],
            4,
        )
        @test chembeadpos[1] ≊ SA[-3.5,0.0,0.0]
        @test chembeadpos[2] ≊ SA[0.5,0.0,0.0]
        @test chembeadpos[3] ≊ SA[4.5,0.0,0.0]
        mon_id_info = (-1, 0, 4) # first mon id, last mon id, num mon per cyl
        @test MEDYAN._fil_node_mon_ids(mon_id_info...) == [-1,0,1]
        @test MEDYAN.get_fil_chem_cyl_idx_frac(-1, mon_id_info...) == (1, 7/8)
        @test MEDYAN.get_fil_chem_cyl_idx_frac(0, mon_id_info...) == (2, 1/8)
        nodepos = MEDYAN._get_nodepositions(chembeadpos, mon_id_info...)
        @test nodepos ≊ [SA[-0.5,0.0,0.0], SA[0.5,0.0,0.0], SA[1.5,0.0,0.0]]
        test_filament_nodepositions_roundtrip!(chembeadpos, mon_id_info...)
    end
    @testset "one cylinder, two monomers, four monomer per cylinder" begin
        chembeadpos = MEDYAN.interpolate_chem_beads(
            [1,3],
            [SA[-0.5,0.0,0.0],SA[1.5,0.0,0.0]],
            4,
        )
        @test chembeadpos[1] ≊ SA[-1.5,0.0,0.0]
        @test chembeadpos[2] ≊ SA[2.5,0.0,0.0]
        mon_id_info = (1, 2, 4) # first mon id, last mon id, num mon per cyl
        MEDYAN._fil_node_mon_ids(mon_id_info...) == [1,3]
        @test MEDYAN.get_fil_chem_cyl_idx_frac(1, mon_id_info...) == (1, 3/8)
        @test MEDYAN.get_fil_chem_cyl_idx_frac(2, mon_id_info...) == (1, 5/8)
        nodepos = MEDYAN._get_nodepositions(chembeadpos, mon_id_info...)
        @test nodepos ≊ [SA[-0.5,0.0,0.0], SA[1.5,0.0,0.0]]
        test_filament_nodepositions_roundtrip!(chembeadpos, mon_id_info...)
    end
    @testset "three cylinder, 7 monomers, four monomer per cylinder 2 nodes" begin
        chembeadpos = MEDYAN.interpolate_chem_beads(
            [2,9],
            [SA[-0.5,0.0,0.0],SA[6.5,0.0,0.0]],
            4,
        )
        @test chembeadpos[1] ≊ SA[-2.5,0.0,0.0]
        @test chembeadpos[2] ≊ SA[1.5,0.0,0.0]
        @test chembeadpos[3] ≊ SA[5.5,0.0,0.0]
        @test chembeadpos[4] ≊ SA[9.5,0.0,0.0]
        mon_id_info = (2, 8, 4) # first mon id, last mon id, num mon per cyl
        @test MEDYAN.get_fil_chem_cyl_idx_frac(2, mon_id_info...) == (1, 5/8)
        @test MEDYAN.get_fil_chem_cyl_idx_frac(3, mon_id_info...) == (1, 7/8)
        @test MEDYAN.get_fil_chem_cyl_idx_frac(4, mon_id_info...) == (2, 1/8)
        @test MEDYAN.get_fil_chem_cyl_idx_frac(5, mon_id_info...) == (2, 3/8)
        @test MEDYAN.get_fil_chem_cyl_idx_frac(6, mon_id_info...) == (2, 5/8)
        @test MEDYAN.get_fil_chem_cyl_idx_frac(7, mon_id_info...) == (2, 7/8)
        @test MEDYAN.get_fil_chem_cyl_idx_frac(8, mon_id_info...) == (3, 1/8)
        nodepos = MEDYAN._get_nodepositions(chembeadpos, mon_id_info...)
        @test nodepos ≊ [SA[-0.5,0.0,0.0], SA[1.5,0.0,0.0], 
                        SA[5.5,0.0,0.0], SA[6.5,0.0,0.0]]
        test_filament_nodepositions_roundtrip!(chembeadpos, mon_id_info...)
    end
    @testset "three cylinder, 7 monomers, four monomer per cylinder 3 nodes" begin
        chembeadpos = MEDYAN.interpolate_chem_beads(
            [2,3,9],
            [SA[-0.5,0.0,0.0],SA[0.5,0.0,0.0],SA[6.5,0.0,0.0]],
            4,
        )
        @test chembeadpos[1] ≊ SA[-2.5,0.0,0.0]
        @test chembeadpos[2] ≊ SA[1.5,0.0,0.0]
        @test chembeadpos[3] ≊ SA[5.5,0.0,0.0]
        @test chembeadpos[4] ≊ SA[9.5,0.0,0.0]
        mon_id_info = (2, 8, 4) # first mon id, last mon id, num mon per cyl
        nodepos = MEDYAN._get_nodepositions(chembeadpos,mon_id_info...)
        @test nodepos ≊ [SA[-0.5,0.0,0.0], SA[1.5,0.0,0.0], 
                        SA[5.5,0.0,0.0], SA[6.5,0.0,0.0]]
        test_filament_nodepositions_roundtrip!(chembeadpos, mon_id_info...)
    end
    @testset "three cylinder, 7 monomers, four monomer per cylinder 4 nodes" begin
        chembeadpos = MEDYAN.interpolate_chem_beads(
            [2,3,8,9],
            [SA[-0.5,0.0,0.0],SA[0.5,0.0,0.0],SA[5.5,0.0,0.0],SA[6.5,0.0,0.0]],
            4,
        )
        @test chembeadpos[1] ≊ SA[-2.5,0.0,0.0]
        @test chembeadpos[2] ≊ SA[1.5,0.0,0.0]
        @test chembeadpos[3] ≊ SA[5.5,0.0,0.0]
        @test chembeadpos[4] ≊ SA[9.5,0.0,0.0]
        mon_id_info = (2, 8, 4) # first mon id, last mon id, num mon per cyl
        nodepos = MEDYAN._get_nodepositions(chembeadpos, mon_id_info...)
        @test nodepos ≊ [SA[-0.5,0.0,0.0], SA[1.5,0.0,0.0], 
                        SA[5.5,0.0,0.0], SA[6.5,0.0,0.0]]
        test_filament_nodepositions_roundtrip!(chembeadpos, mon_id_info...)
    end
end
@testset "interpolate_twist" begin
    @testset "simple two cylinder case" begin
        # Test with 2 cylinders, 1 monomer per cylinder
        # twists = [0.5] (one twist value between first and second cylinder)
        joint_twists = MEDYAN.interpolate_twist([0, 1, 2], [0.5], 1)
        @test length(joint_twists) == 1
        @test joint_twists[1] ≈ 0.5
    end
    @testset "three cylinder case" begin
        # Test with 3 cylinders, 1 monomer per cylinder
        # full_node_mids = [0, 1, 2, 3]
        # twists = [0.2, 0.3] (two twist values)
        joint_twists = MEDYAN.interpolate_twist([0, 1, 2, 3], [0.2, 0.3], 1)
        @test length(joint_twists) == 2  # numbeads - 2 = 4 - 2 = 2
        @test joint_twists[1] ≈ 0.2  # first joint gets first twist
        @test joint_twists[2] ≈ 0.3  # second joint gets second twist
    end
    @testset "multiple monomers per cylinder" begin
        # Test with 2 cylinders, 4 monomers per cylinder
        joint_twists = MEDYAN.interpolate_twist([-1, 1], Float64[], 4)
        @test length(joint_twists) == 1
        @test joint_twists[1] ≈ 0.0
    end
    @testset "accumulating twists" begin
        # Test case where multiple twist values contribute to one joint
        # 3 cylinders, 4 monomers per cylinder, but nodes are closer together
        # This tests the accumulation logic in the while loop
        joint_twists = MEDYAN.interpolate_twist([2, 3, 8, 9], [0.1, 0.2,], 4)
        @test length(joint_twists) == 2  # numbeads - 2 = 4 - 2 = 2
        # First joint at targetmid = 4: accumulates twists at nodes 3 (twists[1])
        @test joint_twists[1] ≈ 0.1
        # Second joint at targetmid = 8: accumulates twist at node 8 (twists[2])
        @test joint_twists[2] ≈ 0.2
    end
    @testset "single cylinder case" begin
        # Test with only one cylinder - should have no joints
        # With 1 cylinder, numbeads = 2, so joint_twists length = 0
        joint_twists = MEDYAN.interpolate_twist([1, 3, 4], [0.5], 4)
        @test length(joint_twists) == 0  # numbeads - 2 = 2 - 2 = 0
    end
    @testset "zero twist values" begin
        # Test with zero twists
        joint_twists = MEDYAN.interpolate_twist([0, 1, 2, 3], [0.0, 0.0], 1)
        @test length(joint_twists) == 2
        @test joint_twists[1] ≈ 0.0
        @test joint_twists[2] ≈ 0.0
    end
    @testset "negative twist values" begin
        # Test with negative twists
        joint_twists = MEDYAN.interpolate_twist([0, 1, 2, 3], [-0.5, 0.3], 1)
        @test length(joint_twists) == 2
        @test joint_twists[1] ≈ -0.5
        @test joint_twists[2] ≈ 0.3
    end
    @testset "three cylinder, 7 monomers, four monomer per cylinder 2 nodes" begin
        joint_twists = MEDYAN.interpolate_twist([2,9], Float64[], 4)
        @test length(joint_twists) == 2
        @test joint_twists[1] == 0.0
        @test joint_twists[2] == 0.0
    end
    @testset "one cylinder, two monomers, four monomer per cylinder" begin
        joint_twists = MEDYAN.interpolate_twist([1,3], Float64[], 4)
        @test length(joint_twists) == 0
    end
    @testset "three cylinder, two monomers, four monomer per cylinder" begin
        joint_twists = MEDYAN.interpolate_twist(collect(2:10), Float64.(collect(11:17)), 4)
        @test length(joint_twists) == 2
        @test joint_twists[1] == 11 + 12
        @test joint_twists[2] == 13 + 14 + 15 + 16
    end
    @testset "error cases" begin
        # Test argument validation
        # Wrong length of twists vector (should be length(full_node_mids) - 2)
        @test_throws ArgumentError MEDYAN.interpolate_twist([0, 1, 2], [0.1, 0.2], 1)  # twists too long
        @test_throws ArgumentError MEDYAN.interpolate_twist([0, 1, 2, 3], [0.1], 1)    # twists too short
        
        # Zero or negative numpercylinder
        @test_throws ArgumentError MEDYAN.interpolate_twist([0, 1, 2], [0.1], 0)
        @test_throws ArgumentError MEDYAN.interpolate_twist([0, 1, 2], [0.1], -1)
        
        # Non-positive cylinder lengths
        @test_throws ArgumentError MEDYAN.interpolate_twist([0, 0, 1], [0.1], 1)  # zero length
        @test_throws ArgumentError MEDYAN.interpolate_twist([0, 2, 1], [0.1], 1)  # negative length
    end
end