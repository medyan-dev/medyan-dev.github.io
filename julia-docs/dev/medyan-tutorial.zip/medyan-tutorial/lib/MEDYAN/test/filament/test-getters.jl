using MEDYAN
using StaticArrays
using Test
using LinearAlgebra
using Setfield

@testset "filament getters" begin
    c, s, fila_plus_tag_a1, junk... = MEDYAN.example_all_sites_context()
    @test num_fila_types(c) == 2
    @test num_fila(c; type=:b) == 2
    @test num_fila(c; type=1) == 2
    @test num_fila(c) == 2
    mono_states = fila_mono_states(c, fila_plus_tag_a1)
    n_nodes = fila_num_nodes(c, fila_plus_tag_a1)
    @test n_nodes isa Int
    node_mids = fila_node_mids(c, fila_plus_tag_a1)
    @test length(node_mids) == n_nodes
    @test first(node_mids) == firstindex(mono_states)
    @test last(node_mids) == lastindex(mono_states) + 1
    @test fila_node_positions(c, FilaIdx(1, 1)) isa Vector{SVector{3, Float64}}
    @test fila_node_positions(c, fila_plus_tag_a1) isa Vector{SVector{3, Float64}}
    @test length(fila_node_positions(c, fila_plus_tag_a1)) == n_nodes
    tip_tags = fila_tip_tags(c, fila_plus_tag_a1)
    @test length(tip_tags) == 2
    @test tip_tags[2] == fila_plus_tag_a1
    @test FilaIdx(c, tip_tags[1]) == FilaIdx(c, tip_tags[2])
    @test is_minus_end(tag2place(c, tip_tags[1]))
end