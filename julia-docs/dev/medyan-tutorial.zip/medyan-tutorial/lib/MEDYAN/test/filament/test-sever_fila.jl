using MEDYAN
using StaticArrays
using Test

@testset "sever_fila!" begin
    ≊(a,b) = isapprox(a, b; atol = 1E-9)
    @testset "filament itself" begin
        c_init = MEDYAN.example_actin_mech_context(CubicGrid((2,2,2),500.0))
        f_params = MEDYAN.ACTIN_FIL_PARAMS
        numcyl = 6
        nummonomers = numcyl*f_params.numpercylinder
        mono_states = ones(UInt8,nummonomers)
        mono_states[begin] = 2
        mono_states[end] = 3
        mon_len = f_params.spacing
        cyl_len = f_params.spacing*f_params.numpercylinder
        node_positions = [
            SA[1.0,2.0,3.0],
            SA[1.0,2.0,3.0+cyl_len*numcyl]
        ]
        ftag_long = MEDYAN.make_fila!(c_init;
            type= 1, 
            mono_states,
            node_mids= [5],
            node_positions,
        )
        ftag_short = MEDYAN.make_fila!(c_init;
            type= 1, 
            mono_states= [0x01, 0x02, 0x03, 0x04, 0x05],
            node_mids= [5],
            node_positions= [
                SA[1.0,2.0,3.0],
                SA[1.0,2.0,3.0+mon_len*5],
            ],
        )
        @testset "cut long filament at node" begin
            c = deepcopy(c_init)
            new_ftag = sever_fila!(c, FilaMonoIdx(c, FilaIdx(c, ftag_long), 120))
            MEDYAN.assert_invariants(c)
            @test MEDYAN.is_chem_cache_valid(c)
            tags = collect(MEDYAN.get_all_tags(c, FilaTipIdx()))
            @test ftag_long ∈ tags
            @test length(tags) == 6
            @test FilaIdx(c, new_ftag) == setdiff(FilaIdx.((c,), tags), [FilaIdx(c, ftag_long), FilaIdx(c, ftag_short)])[1]
            # the minus end is the new filament. 
            minus_nodes = fila_node_positions(c, new_ftag)
            plus_nodes = fila_node_positions(c, ftag_long)
            @test minus_nodes ≊ [
                SA[1.0,2.0,3.0],
                SA[1.0,2.0,3.0+35mon_len],
                SA[1.0,2.0,3.0+35mon_len+cyl_len],
                SA[1.0,2.0,3.0+35mon_len+2cyl_len],
            ]
            @test plus_nodes ≊ [
                SA[1.0,2.0,3.0+35mon_len+2cyl_len],
                SA[1.0,2.0,3.0+35mon_len+3cyl_len],
                SA[1.0,2.0,3.0+35mon_len+4cyl_len],
                SA[1.0,2.0,3.0+35mon_len+5cyl_len],
                SA[1.0,2.0,3.0+6cyl_len],
            ]
            minus_mon_ids = MEDYAN.fila_mono_ids(c, new_ftag)
            minus_mon_states = MEDYAN.fila_mono_states(c, new_ftag)
            plus_mon_ids = MEDYAN.fila_mono_ids(c, ftag_long)
            plus_mon_states = MEDYAN.fila_mono_states(c, ftag_long)
            @test first(minus_mon_ids) == 5
            @test minus_mon_states == [0x02; ones(UInt8,114);]
            @test first(plus_mon_ids) == 120
            @test plus_mon_states == [ones(UInt8,124); 0x03;]
            @test !place_exists(c, FilaMonoIdx(FilaIdx(c, ftag_long),119))
            @test place_exists(c, FilaMonoIdx(FilaIdx(c, ftag_long),120))
            @test place_exists(c, FilaMonoIdx(FilaIdx(c, ftag_long),244))
            @test !place_exists(c, FilaMonoIdx(FilaIdx(c, ftag_long),245))

            @test !place_exists(c, FilaMonoIdx(FilaIdx(c, new_ftag),4))
            @test place_exists(c, FilaMonoIdx(FilaIdx(c, new_ftag),5))
            @test place_exists(c, FilaMonoIdx(FilaIdx(c, new_ftag),119))
            @test !place_exists(c, FilaMonoIdx(FilaIdx(c, new_ftag),120))
        end
        @testset "cut long filament between nodes" begin
            c = deepcopy(c_init)
            new_ftag = sever_fila!(c, FilaMonoIdx(FilaIdx(c, ftag_long),125))
            MEDYAN.assert_invariants(c)
            # the minus end is the new filament. 
            minus_nodes = fila_node_positions(c, new_ftag)
            plus_nodes = fila_node_positions(c, ftag_long)
            @test minus_nodes ≊ [
                SA[1.0,2.0,3.0],
                SA[1.0,2.0,3.0+35mon_len],
                SA[1.0,2.0,3.0+35mon_len+cyl_len],
                SA[1.0,2.0,3.0+35mon_len+2cyl_len],
                SA[1.0,2.0,3.0+3cyl_len],
            ]
            @test plus_nodes ≊ [
                SA[1.0,2.0,3.0+3cyl_len],
                SA[1.0,2.0,3.0+35mon_len+3cyl_len],
                SA[1.0,2.0,3.0+35mon_len+4cyl_len],
                SA[1.0,2.0,3.0+35mon_len+5cyl_len],
                SA[1.0,2.0,3.0+6cyl_len],
            ]
            minus_mon_ids = MEDYAN.fila_mono_ids(c, new_ftag)
            minus_mon_states = MEDYAN.fila_mono_states(c, new_ftag)
            plus_mon_ids = MEDYAN.fila_mono_ids(c, ftag_long)
            plus_mon_states = MEDYAN.fila_mono_states(c, ftag_long)
            @test first(minus_mon_ids) == 5
            @test minus_mon_states == [0x02; ones(UInt8,119);]
            @test first(plus_mon_ids) == 125
            @test plus_mon_states == [ones(UInt8,119); 0x03;]
            @test !place_exists(c,FilaMonoIdx(FilaIdx(c, ftag_long),124))
            @test place_exists(c,FilaMonoIdx(FilaIdx(c, ftag_long),125))
            @test place_exists(c,FilaMonoIdx(FilaIdx(c, ftag_long),244))
            @test !place_exists(c,FilaMonoIdx(FilaIdx(c, ftag_long),245))

            @test !place_exists(c,FilaMonoIdx(FilaIdx(c, new_ftag),4))
            @test place_exists(c,FilaMonoIdx(FilaIdx(c, new_ftag),5))
            @test place_exists(c,FilaMonoIdx(FilaIdx(c, new_ftag),124))
            @test !place_exists(c,FilaMonoIdx(FilaIdx(c, new_ftag),125))
        end
        @testset "cut long filament near minus end" begin
            c = deepcopy(c_init)
            new_ftag = sever_fila!(c, FilaMonoIdx(FilaIdx(c, ftag_long),10))
            MEDYAN.assert_invariants(c)
            # the minus end is the new filament. 
            minus_nodes = fila_node_positions(c, new_ftag)
            plus_nodes = fila_node_positions(c, ftag_long)
            @test minus_nodes ≊ [
                SA[1.0,2.0,3.0],
                SA[1.0,2.0,3.0+5mon_len],
            ]
            @test plus_nodes ≊ [
                SA[1.0,2.0,3.0+5mon_len],
                SA[1.0,2.0,3.0+35mon_len],
                SA[1.0,2.0,3.0+35mon_len+cyl_len],
                SA[1.0,2.0,3.0+35mon_len+2cyl_len],
                SA[1.0,2.0,3.0+35mon_len+3cyl_len],
                SA[1.0,2.0,3.0+35mon_len+4cyl_len],
                SA[1.0,2.0,3.0+35mon_len+5cyl_len],
                SA[1.0,2.0,3.0+6cyl_len],
            ]
            minus_mon_ids = MEDYAN.fila_mono_ids(c, new_ftag)
            minus_mon_states = MEDYAN.fila_mono_states(c, new_ftag)
            plus_mon_ids = MEDYAN.fila_mono_ids(c, ftag_long)
            plus_mon_states = MEDYAN.fila_mono_states(c, ftag_long)
            @test first(minus_mon_ids) == 5
            @test minus_mon_states == [0x02; ones(UInt8,4);]
            @test first(plus_mon_ids) == 10
            @test plus_mon_states == [ones(UInt8,234); 0x03;]
            @test !place_exists(c,FilaMonoIdx(FilaIdx(c, ftag_long),9))
            @test place_exists(c,FilaMonoIdx(FilaIdx(c, ftag_long),10))
            @test place_exists(c,FilaMonoIdx(FilaIdx(c, ftag_long),244))
            @test !place_exists(c,FilaMonoIdx(FilaIdx(c, ftag_long),245))

            @test !place_exists(c,FilaMonoIdx(FilaIdx(c, new_ftag),4))
            @test place_exists(c,FilaMonoIdx(FilaIdx(c, new_ftag),5))
            @test place_exists(c,FilaMonoIdx(FilaIdx(c, new_ftag),9))
            @test !place_exists(c,FilaMonoIdx(FilaIdx(c, new_ftag),10))
        end
        @testset "cut long filament near plus end" begin
            c = deepcopy(c_init)
            new_ftag = sever_fila!(c, FilaMonoIdx(FilaIdx(c, ftag_long),241))
            MEDYAN.assert_invariants(c)
            # the minus end is the new filament. 
            minus_nodes = fila_node_positions(c, new_ftag)
            plus_nodes = fila_node_positions(c, ftag_long)
            @test minus_nodes ≊ [
                SA[1.0,2.0,3.0],
                SA[1.0,2.0,3.0+35mon_len],
                SA[1.0,2.0,3.0+35mon_len+cyl_len],
                SA[1.0,2.0,3.0+35mon_len+2cyl_len],
                SA[1.0,2.0,3.0+35mon_len+3cyl_len],
                SA[1.0,2.0,3.0+35mon_len+4cyl_len],
                SA[1.0,2.0,3.0+35mon_len+5cyl_len],
                SA[1.0,2.0,3.0+35mon_len+5cyl_len+mon_len],
            ]
            @test plus_nodes ≊ [
                SA[1.0,2.0,3.0+35mon_len+5cyl_len+mon_len],
                SA[1.0,2.0,3.0+6cyl_len],
            ]
            minus_mon_ids = MEDYAN.fila_mono_ids(c, new_ftag)
            minus_mon_states = MEDYAN.fila_mono_states(c, new_ftag)
            plus_mon_ids = MEDYAN.fila_mono_ids(c, ftag_long)
            plus_mon_states = MEDYAN.fila_mono_states(c, ftag_long)
            @test first(minus_mon_ids) == 5
            @test minus_mon_states == [0x02; ones(UInt8,235);]
            @test first(plus_mon_ids) == 241
            @test plus_mon_states == [ones(UInt8,3); 0x03;]
            @test !place_exists(c,FilaMonoIdx(FilaIdx(c, ftag_long),240))
            @test place_exists(c,FilaMonoIdx(FilaIdx(c, ftag_long),241))
            @test place_exists(c,FilaMonoIdx(FilaIdx(c, ftag_long),244))
            @test !place_exists(c,FilaMonoIdx(FilaIdx(c, ftag_long),245))

            @test !place_exists(c,FilaMonoIdx(FilaIdx(c, new_ftag),4))
            @test place_exists(c,FilaMonoIdx(FilaIdx(c, new_ftag),5))
            @test place_exists(c,FilaMonoIdx(FilaIdx(c, new_ftag),240))
            @test !place_exists(c,FilaMonoIdx(FilaIdx(c, new_ftag),241))
        end
        @testset "cut short filament" begin
            c = deepcopy(c_init)
            new_ftag = sever_fila!(c, FilaMonoIdx(FilaIdx(c, ftag_short),7))
            MEDYAN.assert_invariants(c)
            # the minus end is the new filament. 
            minus_nodes = fila_node_positions(c, new_ftag)
            plus_nodes = fila_node_positions(c, ftag_short)
            @test minus_nodes ≊ [
                SA[1.0,2.0,3.0],
                SA[1.0,2.0,3.0+2mon_len],
            ]
            @test plus_nodes ≊ [
                SA[1.0,2.0,3.0+2mon_len],
                SA[1.0,2.0,3.0+5mon_len],
            ]
            minus_mon_ids = MEDYAN.fila_mono_ids(c, new_ftag)
            minus_mon_states = MEDYAN.fila_mono_states(c, new_ftag)
            plus_mon_ids = MEDYAN.fila_mono_ids(c, ftag_short)
            plus_mon_states = MEDYAN.fila_mono_states(c, ftag_short)
            @test first(minus_mon_ids) == 5
            @test minus_mon_states == [0x01, 0x02,]
            @test first(plus_mon_ids) == 7
            @test plus_mon_states == [0x03, 0x04, 0x05,]
            @test !place_exists(c,FilaMonoIdx(FilaIdx(c, ftag_short),6))
            @test place_exists(c,FilaMonoIdx(FilaIdx(c, ftag_short),7))
            @test place_exists(c,FilaMonoIdx(FilaIdx(c, ftag_short),9))
            @test !place_exists(c,FilaMonoIdx(FilaIdx(c, ftag_short),10))

            @test !place_exists(c,FilaMonoIdx(FilaIdx(c, new_ftag),4))
            @test place_exists(c,FilaMonoIdx(FilaIdx(c, new_ftag),5))
            @test place_exists(c,FilaMonoIdx(FilaIdx(c, new_ftag),6))
            @test !place_exists(c,FilaMonoIdx(FilaIdx(c, new_ftag),7))
        end
        @testset "creating a filament with less than 2 monomers errors" begin
            c = deepcopy(c_init)
            @test_throws Exception sever_fila!(c, FilaMonoIdx(FilaIdx(c, ftag_short),6))
        end

    end
    @testset "site count optimization tests" begin
        startc, s, ftag1, ftag2, junk... = MEDYAN.example_all_sites_context(; check_sitecount_error=true)
    
        MEDYAN.test_chem_mutation_sequence(startc, [
            c->sever_fila!(c, FilaMonoIdx(c, ftag1, -, +2)),
            c->sever_fila!(c, FilaMonoIdx(c, ftag2, +, -1)),
        ])
    end
end

