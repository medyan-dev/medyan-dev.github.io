using MEDYAN
using Test
using StaticArrays


@testset "make_fila_rand!" begin
    c = MEDYAN.example_actin_mech_context(CubicGrid((2,2,2),500.0))
    for i in 1:100
        ftag = make_fila_rand!(c,ones(MEDYAN.MonomerState,100))
        nodes = MEDYAN.fila_node_positions(c, ftag)
        @test all(nodes) do pos
            all(<(500.0),pos) && all(>(-500.0),pos)
        end
    end
end
