using MEDYAN
using StaticArrays
using Test

@testset "depolymerize_fila!" begin
    agent_names = MEDYAN.AgentNames(
        filamentnames= [(:a,[
                            :a,
                            :b,
                            :c,
                        ]),
        ],
    )
    grid= CubicGrid((4,1,1),500.0)
    s= MEDYAN.SysDef(agent_names)
    add_filament_params!(s, :a, MEDYAN.UNITY_FIL_PARAMS)
    cinit= MEDYAN.Context(s,grid)
    mono_states= [s.state.a.a, s.state.a.a, s.state.a.b]
    node_positions = [SA[-2.0,0.0,0.0], SA[4.0,0.0,0.0]]
    ftag = MEDYAN.make_fila!(cinit; type = :a, mono_states, node_positions, node_mids=[1,])
    @testset "plus end depolymerization test" begin
        c= deepcopy(cinit)
        MEDYAN.depolymerize_fila!(c, FilaTipIdx(c, ftag, +))
        monstates = MEDYAN.fila_mono_states(c, ftag)
        @test monstates == [s.state.a.a, s.state.a.a]
        @test first(MEDYAN.fila_mono_ids(c, ftag)) == 1
        @test last(MEDYAN.fila_mono_ids(c, ftag)) == 2
        mono_idxs = FilaMonoIdx.((c,), (FilaIdx(c, ftag),), 1:2)
        @test MEDYAN.get_directions.((c,), mono_idxs) == [[SA[1.0,0.0,0.0]], [SA[1.0,0.0,0.0]]]
        @test MEDYAN.get_position.((c,), mono_idxs) ≈ [SA[-1.0,0.0,0.0], SA[1.0,0.0,0.0]]
    end
    @testset "minus end depolymerization test" begin
        c= deepcopy(cinit)
        MEDYAN.depolymerize_fila!(c, FilaTipIdx(c, ftag, -))
        monstates = MEDYAN.fila_mono_states(c, ftag)
        @test monstates == [s.state.a.a, s.state.a.b]
        @test first(MEDYAN.fila_mono_ids(c, ftag)) == 2
        @test last(MEDYAN.fila_mono_ids(c, ftag)) == 3
        mono_idxs = MEDYAN.FilaMonoIdx.((c,), (FilaIdx(c, ftag),), 2:3)
        @test MEDYAN.get_directions.((c,), mono_idxs) == [[SA[1.0,0.0,0.0]], [SA[1.0,0.0,0.0]]]
        @test MEDYAN.get_position.((c,), mono_idxs) ≈ [SA[1.0,0.0,0.0], SA[3.0,0.0,0.0]]
    end
    @testset "site count optimization tests" begin
        startc, s, ftaga1, ftaga2, ftagb1, ftagb2 = MEDYAN.example_all_sites_context(; check_sitecount_error=true) #deepcopy(cinit)
        fila_idx = FilaIdx(startc, ftaga1)
        #depolymerization minus end
        MEDYAN.test_chem_mutation_sequence(startc, [
            c->MEDYAN.update_fila_mono_state!(c, FilaMonoIdx(fila_idx, 1), :a),
            c->MEDYAN.depolymerize_fila!(c, FilaTipIdx(fila_idx, true)),
            c->MEDYAN.update_fila_mono_state!(c, FilaMonoIdx(fila_idx, 2), :me),
            c->MEDYAN.depolymerize_fila!(c, FilaTipIdx(fila_idx, true)),
            c->MEDYAN.update_fila_mono_state!(c, FilaMonoIdx(fila_idx, 3), :me),
        ])

        #depolymerization plus end
        c = deepcopy(startc)
        MEDYAN.test_chem_mutation_sequence(startc, [
            c->MEDYAN.depolymerize_fila!(c, FilaTipIdx(fila_idx, false)),
            c->MEDYAN.update_fila_mono_state!(c, FilaMonoIdx(fila_idx, 8), :pe),
            c->MEDYAN.depolymerize_fila!(c, FilaTipIdx(fila_idx, false)),
            c->MEDYAN.update_fila_mono_state!(c, FilaMonoIdx(fila_idx, 7), :pe),
        ])
    end
end