using MEDYAN
using StaticArrays
using Test

@testset "update_fila_mono_state!" begin
    @testset "basic test" begin
        agent_names = MEDYAN.AgentNames(
            filamentnames= [(:a,[
                                :a,
                                :b,
                                :c,
                            ]),
            ],
        )
        grid= CubicGrid((4,1,1),500.0)
        s= MEDYAN.SysDef(agent_names)
        add_filament_params!(s, :a, MEDYAN.UNITY_FIL_PARAMS)
        c= MEDYAN.Context(s,grid)
        mono_states= [s.state.a.a,s.state.a.a]
        node_positions= [SA[498.0,200,200],SA[502.0,200,200]]
        ftag = MEDYAN.make_fila!(c; type = :a, node_mids=[1,], mono_states, node_positions,)
        MEDYAN.update_fila_mono_state!(c, FilaMonoIdx(c, ftag, -1), s.state.a.b)
        monstates = MEDYAN.fila_mono_states(c, ftag)
        @test collect(monstates) == [s.state.a.b, s.state.a.a]
    end
    @testset "site count optimization tests" begin
        startc, s, ftag, junk... = MEDYAN.example_all_sites_context(; check_sitecount_error=true) #deepcopy(cinit)
        fila_idx = FilaIdx(startc, ftag)
        MEDYAN.test_chem_mutation_sequence(startc, [
            c->MEDYAN.update_fila_mono_state!(c, FilaMonoIdx(fila_idx, 1), s.state.a.a),
            c->MEDYAN.update_fila_mono_state!(c, FilaMonoIdx(fila_idx, 1), s.state.a.me),
            c->MEDYAN.update_fila_mono_state!(c, FilaMonoIdx(fila_idx, 2), s.state.a.me),
            c->MEDYAN.update_fila_mono_state!(c, FilaMonoIdx(fila_idx, 3), s.state.a.me),
            c->MEDYAN.update_fila_mono_state!(c, FilaMonoIdx(fila_idx, 1), s.state.a.a),
            c->MEDYAN.update_fila_mono_state!(c, FilaMonoIdx(fila_idx, 2), s.state.a.a),
            c->MEDYAN.update_fila_mono_state!(c, FilaMonoIdx(fila_idx, 3), s.state.a.a),
        ])
        MEDYAN.test_chem_mutation_sequence(startc, [
            c->MEDYAN.update_fila_mono_state!(c, FilaMonoIdx(fila_idx, 8), s.state.a.pe),
            c->MEDYAN.update_fila_mono_state!(c, FilaMonoIdx(fila_idx, 7), s.state.a.pe),
        ])
    end
end