using MEDYAN
using StaticArrays
using Random
using LinearAlgebra
using Test


@testset "internal_filament_forces!" begin
    filamentmechparams= MEDYAN.FilamentMechParams(
        radius = 7.0,
        spacing = 2.5,
        klength = 3.0, 
        kangle = 4.0,
        numpercylinder= 40,
        max_num_unmin_end= 1000,
    )
    @testset "two monomers" begin
        x= [0.0,0.0,1.0,
            0.0,0.0,3.5]
        force_energy = MEDYAN.ForceEnergyFloat64(length(x))
        MEDYAN.internal_filament_forces!(force_energy,x,filamentmechparams,1,1,1)
        @test MEDYAN.get_energy(force_energy) == 0.0

        x= [0.0,0.0,1.0,
            0.0,0.0,4.5]
        force_energy = MEDYAN.ForceEnergyFloat64(length(x))
        MEDYAN.internal_filament_forces!(force_energy,x,filamentmechparams,1,1,1)
        @test MEDYAN.get_energy(force_energy) == 1//2*3.0

        x= [0.0,0.0,1.0,
            0.0,0.0,2.5]
        force_energy = MEDYAN.ForceEnergyFloat64(length(x))
        MEDYAN.internal_filament_forces!(force_energy,x,filamentmechparams,1,1,1)
        @test MEDYAN.get_energy(force_energy) == 1//2*3.0
    end
    @testset "three monomers" begin
        x= [0.0,0.0,1.0,
            0.0,0.0,3.5,
            0.0,0.0,6.0]
        force_energy = MEDYAN.ForceEnergyFloat64(length(x))
        MEDYAN.internal_filament_forces!(force_energy,x,filamentmechparams,1,1,1)
        @test MEDYAN.get_energy(force_energy) == 0.0

        x= [0.0,0.0,0.5,
            0.0,0.0,3.5,
            0.0,0.0,6.0]
        force_energy = MEDYAN.ForceEnergyFloat64(length(x))
        MEDYAN.internal_filament_forces!(force_energy,x,filamentmechparams,1,1,1)
        @test MEDYAN.get_energy(force_energy) ≈ 1//2*3.0*0.5^2

        x= [0.0,0.0,1.0,
            0.0,0.0,3.0,
            0.0,0.0,6.0]
        force_energy = MEDYAN.ForceEnergyFloat64(length(x))
        MEDYAN.internal_filament_forces!(force_energy,x,filamentmechparams,1,1,1)
        @test MEDYAN.get_energy(force_energy) ≈ 2*1//2*3.0*0.5^2

        x= [0.0,0.0,1.0,
            0.0,0.0,3.0,
            0.0,0.0,5.5]
        force_energy = MEDYAN.ForceEnergyFloat64(length(x))
        MEDYAN.internal_filament_forces!(force_energy,x,filamentmechparams,1,1,1)
        @test MEDYAN.get_energy(force_energy) ≈ 1//2*3.0*0.5^2

        x1= [0.0,0.0,0.0]
        x0= [-2.5,0.0,0.0]
        x2= [2.5*cos(0.2), 2.5*sin(0.2), 0.0]
        x= vcat(x0,x1,x2)
        force_energy = MEDYAN.ForceEnergyFloat64(length(x))
        MEDYAN.internal_filament_forces!(force_energy,x,filamentmechparams,1,1,1)
        @test MEDYAN.get_energy(force_energy) ≈ 4.0*(cos(pi-0.2)+1)

        x1= [0.0,0.0,0.0]
        x0= [-2.5,0.0,0.0]
        x2= [3.0*cos(0.2), 3.0*sin(0.2), 0.0]
        x= vcat(x0,x1,x2)
        force_energy = MEDYAN.ForceEnergyFloat64(length(x))
        MEDYAN.internal_filament_forces!(force_energy,x,filamentmechparams,1,1,1)
        @test MEDYAN.get_energy(force_energy) ≈ 4.0*(cos(pi-0.2)+1) + 1//2*3.0*0.5^2
    end
    @testset "finite differences" begin
        for i in 1:100
            x0= randn(Float64,3*10)
            force_energy0 = MEDYAN.ForceEnergyFloat64(length(x0))
            MEDYAN.internal_filament_forces!(force_energy0,x0,filamentmechparams,1,1,1)
            forces0 = MEDYAN.get_force(force_energy0)
            E0= MEDYAN.get_energy(force_energy0)
            for j in 1:100
                #choose random deviation
                Δx= 1E-5 .* randn(Float64,3*10)
                x= x0 .+ Δx
                force_energy = MEDYAN.ForceEnergyFloat64(length(x))
                MEDYAN.internal_filament_forces!(force_energy,x,filamentmechparams,1,1,1)
                forces = MEDYAN.get_force(force_energy)
                predE= E0 - dot(Δx, (forces0 .+ forces) ./ 2)
                realE= MEDYAN.get_energy(force_energy)
                @test abs(realE-predE)<1E-10
            end
        end
    end
    @testset "finite differences coarse grain" begin
        for i in 1:100
            x0= randn(Float64,3*10)
            force_energy0 = MEDYAN.ForceEnergyFloat64(length(x0))
            MEDYAN.internal_filament_forces!(force_energy0, x0, filamentmechparams, 40, 2, 1)
            E0= MEDYAN.get_energy(force_energy0)
            forces0= MEDYAN.get_force(force_energy0)
            for j in 1:100
                #choose random deviation
                local Δx= 1E-5 .* randn(Float64,3*10)
                local x= x0 .+ Δx
                force_energy = MEDYAN.ForceEnergyFloat64(length(x))
                MEDYAN.internal_filament_forces!(force_energy, x, filamentmechparams, 40, 2, 1)
                local forces= MEDYAN.get_force(force_energy)
                local predE= E0 - dot(Δx, (forces0 .+ forces) ./ 2)
                local realE= MEDYAN.get_energy(force_energy)
                @test abs(realE-predE)<1E-10
            end
        end
    end
end