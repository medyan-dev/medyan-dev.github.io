using MEDYAN
using Test
using Setfield
using StaticArrays
using LinearAlgebra

@testset "Filament vectorization" begin
    #tests to ensure minimize_energy vectorization is working
    ≊(a,b) = isapprox(a, b; atol = 1E-9)
    grid = CubicGrid((4,4,4),500)
    c = MEDYAN.example_actin_mech_context(grid)

    fid1 = newfilament_rand!(c,ones(MEDYAN.MonomerState,160))
    fid2 = MEDYAN.chem_newfilament!(c;
        ftid = 1,
        monomerstates= ones(MEDYAN.MonomerState,100),
        node_mids = [10,],
        nodepositions = [SA[10.0,10.0,10.0],[280.0,10.0,10.0]],
    )
    pos1 = fil_node_positions(c, 1, fid1)
    pos2 = fil_node_positions(c, 1, fid2)

    let m = MEDYAN.create_membranemesh()
        # Create shape: tetrahedra at top, with triangular prism below, without bottom surface.
        MEDYAN.initmesh!_vertex_triangle(m, 7, [SA[1,2,3], SA[1,3,4], SA[1,4,2],  SA[2,5,3], SA[3,5,6], SA[3,6,4], SA[4,6,7], SA[4,7,2], SA[2,7,5]])
        m.vertices.attr.coord .= reinterpret(SVector{3,Float64}, collect(Float64, 1:7*3))
        push!(c.membranes, m)
    end
    let m = MEDYAN.create_membranemesh()
        MEDYAN.initmesh!_vertex_triangle(m, 3, [SA[1,2,3]])
        m.vertices.attr.coord[1] = SA[-1,-2,-3]
        m.vertices.attr.coord[2] = SA[-4,-5,-6]
        m.vertices.attr.coord[3] = SA[-7,-8,-9]
        push!(c.membranes, m)
    end
    x0, filamentindexinfo, filcoordrange, smeshes, vertexcoordrange = MEDYAN.helper_vectorize_info(c)
    @test length(filcoordrange) == 3 * (length(pos1) + length(pos2))
    @test length(smeshes) == 2
    membrane_xoffset = (length(pos1) + length(pos2)) * 3
    @test vertexcoordrange == membrane_xoffset+1:membrane_xoffset+30
    @test view(x0, membrane_xoffset+1:membrane_xoffset+3) == SA[1,2,3]
    @test view(x0, membrane_xoffset+22:membrane_xoffset+24) == SA[-1,-2,-3]
    x0[membrane_xoffset+10:membrane_xoffset+12] = SA[-10,-11,-12]

    forces= zeros(length(x0))
    MEDYAN.helper_unvectorize_info!(c,x0,forces,filamentindexinfo)
    @test fil_node_positions(c, 1, fid1) ≊ pos1
    @test fil_node_positions(c, 1, fid2) ≊ pos2
    @test c.membranes[1].vertices.attr.coord[4] == SA[-10,-11,-12]
end


@testset "Link_2mon vectorization" begin
    #tests to ensure minimize_energy vectorization is working with link_2mons
    ≊(a,b) = isapprox(a, b; atol = 1E-2)
    grid = CubicGrid((4,4,4),500)
    default_actin = MEDYAN.ACTIN_FIL_PARAMS
    s = deepcopy(MEDYAN.example_actin_mech_context(grid).sys_def)
    add_filament_params!(s, :actin, @set(default_actin.spacing=2.5))
    cinit = MEDYAN.Context(s,grid; g_tol=1E-6)
    mon_id_firsts = (0, -1, -2, 1, 2, 21, 20, -20, -19)
    link_2mon_mon_offsets = (0, 1, 2, 10, 17, 18, 19)
    @testset "first mon id: $mon_id_first, link_2mon mon offsets: $link_2mon_mon_offset " for mon_id_first in mon_id_firsts, link_2mon_mon_offset in link_2mon_mon_offsets
        c = deepcopy(cinit)
        MEDYAN.set_enable_cylinder_volume_exclusion!(c, false)
        fid1 = MEDYAN.chem_newfilament!(c;
            ftid = 1,
            monomerstates= ones(MEDYAN.MonomerState,20),
            node_mids = [mon_id_first,],
            nodepositions = [SA[10.0,10.0,10.0],[60.0,10.0,10.0]],
        )
        pos1 = fil_node_positions(c, 1, fid1)
        restrained = MonomerName(1, fid1, mon_id_first + link_2mon_mon_offset)
        MEDYAN.chem_newlink_2mon!(c, s.link_2mon.restraint, restrained=>restrained;
            changedmechstate = (;mr0=SA[10.0 + 2.5*(link_2mon_mon_offset + 0.5), 10.0, 10.0], mv̂0=SA[1.0,0,0])
        )
        MEDYAN.minimize_energy!(c)
        # The filament should not move much because the plusend is already at the restained position
        @test fil_node_positions(c, 1, fid1) ≊ pos1
    end
end