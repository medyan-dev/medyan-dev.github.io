using MEDYAN
using Test

@testset "write_snapshot_traj" begin
    c, s = MEDYAN.example_all_sites_context()
    io = IOBuffer()
    MEDYAN.write_snapshot_traj(c,io)
    expected = """
    0 0.0 4 7 0 0
    FILAMENT 1 1 2 0 0
    470.0 200.0 200.0 560.0 200.0 200.0 
    FILAMENT 2 1 2 0 0
    480.0 201.0 200.0 570.0 201.0 200.0 
    FILAMENT 1 2 2 0 0
    470.0 200.0 200.0 560.0 200.0 200.0 
    FILAMENT 2 2 2 0 0
    480.0 201.0 200.0 570.0 201.0 200.0 
    LINKER 1 1
    485.0 200.0 200.0 485.0 200.0 200.0 
    LINKER 2 1
    485.0 200.0 200.0 495.0 201.0 200.0 
    LINKER 1 2
    485.0 200.0 200.0 485.0 200.0 200.0 
    LINKER 2 2
    505.0 200.0 200.0 515.0 200.0 200.0 
    LINKER 1 3
    485.0 200.0 200.0 485.0 200.0 200.0 
    LINKER 2 3
    475.0 200.0 200.0 555.0 200.0 200.0 
    LINKER 3 3
    475.0 200.0 200.0 485.0 200.0 200.0 

    """
    @test String(take!(io)) == expected
end

