using MEDYAN
using FixedPointNumbers
using StaticArrays
using LinearAlgebra
using Test
import DataStructures


@testset "test linkable monomers" begin
    agent_names = MEDYAN.AgentNames(
            filamentnames= [(:a,[
                                :me,
                                :a,
                                :b,
                                :c,
                                :pe,
                            ]),
            ],
        )
    
    grid= CubicGrid((4,1,1),500.0)
    s = MEDYAN.SysDef(agent_names)
    filamentmechparams= MEDYAN.FilamentMechParams(
        radius= 1.0,
        spacing= 10.0,
        klength= 1.0,
        kangle= 1.0,
        numpercylinder= 40,
        max_num_unmin_end= 1000,
    )
    add_filament_params!(s, :a, filamentmechparams)
    site = MEDYAN.Decimated2MonSiteRange(s.filament.a,s.filament.a,1,1,s.state.a.a,s.state.a.a,15.0,35.0)
    add_decimated_2mon_site!(s,:s,site)
    sitestep3 = MEDYAN.Decimated2MonSiteRange(s.filament.a,s.filament.a,3,3,s.state.a.a,s.state.a.a,15.0,35.0)
    add_decimated_2mon_site!(s,:step3,sitestep3)
    cinit = MEDYAN.Context(s,grid, check_sitecount_error=true)

    o = MEDYAN.cornerof(grid)
    nodepositionsA = [SA[5.0,200.0,200.0], SA[5.0+9*10.0,200.0,200.0]] .+ Ref(o)
    nodepositionsB = [SA[15.0,201.0,200.0], SA[15.0+9*10.0,201.0,200.0]] .+ Ref(o)
    nodepositionsC = [SA[470.0,200.0,200.0], SA[470.0+9*10.0,200.0,200.0]] .+ Ref(o)
    nodepositionsD = [SA[480.0,201.0,200.0], SA[480.0+9*10.0,201.0,200.0]] .+ Ref(o)

    @testset "single filament one chem voxel" begin
        c = deepcopy(cinit)
        nummonomers= 9
        monomerstates= zeros(MonomerState, nummonomers)
        monomerstates[1]= s.state.a.me
        monomerstates[2:end-1].= s.state.a.a
        monomerstates[end]= s.state.a.pe
        nodepositions = [SA[10.0,200.0,200.0], SA[10.0+nummonomers*10.0,200.0,200.0]] .+ Ref(o)
        ftag = MEDYAN.make_fila!(c; type = :a, mono_states = monomerstates, node_mids=[1,], node_positions = nodepositions)
        MEDYAN.helper_mark_monomers_minimized!(c)
        MEDYAN.refresh_chem_cache!(c)
        lbsid = s.decimated_2mon_site.s.id
        local m = c.decimated_2mon_site_managers[lbsid]
        pairlists = m.system.output.pairlists
        namepairs = map(pairlists) do pairlist
            map(pairlist) do pair
                MEDYAN.index2places(c, m, pair)
            end
        end
        mn(a,b) = (FilaMonoIdx(FilaIdx(c, ftag), a), FilaMonoIdx(FilaIdx(c, ftag), b))
        in_range_set = Set([
            mn(1,3),
            mn(1,4),
            mn(2,4),
            mn(2,5),
            mn(3,1),
            mn(3,5),
            mn(3,6),
            mn(4,1),
            mn(4,2),
            mn(4,6),
            mn(4,7),
            mn(5,2),
            mn(5,3),
            mn(5,7),
            mn(5,8),
            mn(6,3),
            mn(6,4),
            mn(6,8),
            mn(6,9),
            mn(7,4),
            mn(7,5),
            mn(7,9),
            mn(8,5),
            mn(8,6),
            mn(9,6),
            mn(9,7),
        ])
        linkable_set = Set([
            mn(2,4),
            mn(2,5),
            mn(3,5),
            mn(3,6),
            mn(4,2),
            mn(4,6),
            mn(4,7),
            mn(5,2),
            mn(5,3),
            mn(5,7),
            mn(5,8),
            mn(6,3),
            mn(6,4),
            mn(6,8),
            mn(7,4),
            mn(7,5),
            mn(8,5),
            mn(8,6),
        ])
        @test namepairs[1] |> Set == in_range_set
        samplingresults = DataStructures.DefaultOrderedDict{Union{Tuple{FilaMonoIdx,FilaMonoIdx},Nothing},Int}(0)
        for i in 1:1000
            samplingresults[MEDYAN.pickrandom_decimated_2mon_site(c,1,lbsid)] += 1
        end
        @test issetequal(keys(samplingresults), linkable_set ∪ Set((nothing,)))
        for i in 1:100
            @test MEDYAN.pickrandom_decimated_2mon_site(c,2,lbsid) == nothing
        end
        @test isempty(namepairs[2])
        @test isempty(namepairs[3])
        @test isempty(namepairs[4])
        @test c.chemistryengine.fixedcounts[lbsid,:] == [length(in_range_set),0,0,0]
    end
    @testset "single filament two compartments" begin
        c = deepcopy(cinit)
        nummonomers= 9
        monomerstates= zeros(MonomerState,nummonomers)
        monomerstates[1]= s.state.a.me
        monomerstates[2:end-1].= s.state.a.a
        monomerstates[end]= s.state.a.pe
        nodepositions= nodepositionsC
        ftag = MEDYAN.make_fila!(c; type = :a, mono_states = monomerstates, node_mids=[1,], node_positions = nodepositions)
        MEDYAN.helper_mark_monomers_minimized!(c)
        MEDYAN.refresh_chem_cache!(c)
        
        lbsid = s.decimated_2mon_site.s.id
        local m = c.decimated_2mon_site_managers[lbsid]
        pairlists = m.system.output.pairlists
        namepairs = map(pairlists) do pairlist
            map(pairlist) do pair
                MEDYAN.index2places(c, m, pair)
            end
        end
        mn(a,b) = (FilaMonoIdx(FilaIdx(c, ftag), a), FilaMonoIdx(FilaIdx(c, ftag), b))
        in_range_set1 = Set([
            mn(1,3),
            mn(1,4),
            mn(2,4),
            mn(2,5),
            mn(3,1),
            mn(3,5),
            mn(3,6),
        ])
        in_range_set2 = Set([
            mn(4,1),
            mn(4,2),
            mn(4,6),
            mn(4,7),
            mn(5,2),
            mn(5,3),
            mn(5,7),
            mn(5,8),
            mn(6,3),
            mn(6,4),
            mn(6,8),
            mn(6,9),
            mn(7,4),
            mn(7,5),
            mn(7,9),
            mn(8,5),
            mn(8,6),
            mn(9,6),
            mn(9,7),
        ])
        linkable_set1 = Set([
            mn(2,4),
            mn(2,5),
            mn(3,5),
            mn(3,6),
        ])
        linkable_set2 = Set([
            mn(4,2),
            mn(4,6),
            mn(4,7),
            mn(5,2),
            mn(5,3),
            mn(5,7),
            mn(5,8),
            mn(6,3),
            mn(6,4),
            mn(6,8),
            mn(7,4),
            mn(7,5),
            mn(8,5),
            mn(8,6),
        ])
        samplingresults = DataStructures.DefaultOrderedDict{Union{Tuple{FilaMonoIdx,FilaMonoIdx},Nothing},Int}(0)
        for i in 1:10000
            samplingresults[MEDYAN.pickrandom_decimated_2mon_site(c,1,lbsid)] += 1
        end
        @test issetequal(keys(samplingresults), linkable_set1 ∪ Set((nothing,)))
        empty!(samplingresults)
        for i in 1:10000
            samplingresults[MEDYAN.pickrandom_decimated_2mon_site(c,2,lbsid)] += 1
        end
        @test issetequal(keys(samplingresults), linkable_set2 ∪ Set((nothing,)))
        for i in 1:100
            @test MEDYAN.pickrandom_decimated_2mon_site(c,3,lbsid) == nothing
        end
        @test namepairs[1] |> Set == in_range_set1
        @test namepairs[2] |> Set == in_range_set2
        @test isempty(namepairs[3])
        @test isempty(namepairs[4])
        @test c.chemistryengine.fixedcounts[lbsid,:] == [length(in_range_set1),length(in_range_set2),0,0]
    end
    @testset "single filament two compartments step size 3" begin
        c = deepcopy(cinit)
        nummonomers= 9
        monomerstates= zeros(MonomerState,nummonomers)
        monomerstates[1]= s.state.a.me
        monomerstates[2:end-1].= s.state.a.a
        monomerstates[end]= s.state.a.pe
        nodepositions= nodepositionsC
        ftag = MEDYAN.make_fila!(c; type = :a, mono_states = monomerstates, node_mids=[1,], node_positions = nodepositions)
        MEDYAN.helper_mark_monomers_minimized!(c)
        MEDYAN.refresh_chem_cache!(c)

        lbsid = s.decimated_2mon_site.step3.id
        local m = c.decimated_2mon_site_managers[lbsid]
        pairlists = m.system.output.pairlists
        namepairs = map(pairlists) do pairlist
            map(pairlist) do pair
                MEDYAN.index2places(c, m, pair)
            end
        end
        mn(a,b) = (FilaMonoIdx(FilaIdx(c, ftag), a), FilaMonoIdx(FilaIdx(c, ftag), b))
        in_range_set1 = Set([
            mn(3,6),
        ])
        in_range_set2 = Set([
            mn(6,3),
            mn(6,9),
            mn(9,6),
        ])
        linkable_set1 = Set([
            mn(3,6),
        ])
        linkable_set2 = Set([
            mn(6,3),
        ])
        samplingresults = DataStructures.DefaultOrderedDict{Union{Tuple{FilaMonoIdx,FilaMonoIdx},Nothing},Int}(0)
        for i in 1:10000
            samplingresults[MEDYAN.pickrandom_decimated_2mon_site(c,1,lbsid)] += 1
        end

        @test issetequal(keys(samplingresults), linkable_set1)
        empty!(samplingresults)
        for i in 1:10000
            samplingresults[MEDYAN.pickrandom_decimated_2mon_site(c,2,lbsid)] += 1
        end
        @test issetequal(keys(samplingresults), linkable_set2 ∪ Set((nothing,)))
        for i in 1:100
            @test MEDYAN.pickrandom_decimated_2mon_site(c,3,lbsid) == nothing
        end
        @test namepairs[1] |> Set == in_range_set1
        @test namepairs[2] |> Set == in_range_set2
        @test isempty(namepairs[3])
        @test isempty(namepairs[4])
        @test c.chemistryengine.fixedcounts[lbsid,:] == [length(in_range_set1),length(in_range_set2),0,0]
    end
end