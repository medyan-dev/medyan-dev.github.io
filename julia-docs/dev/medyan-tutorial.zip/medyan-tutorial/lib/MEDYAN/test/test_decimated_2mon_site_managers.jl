using MEDYAN
using FixedPointNumbers
using StaticArrays
using LinearAlgebra
using Test
import DataStructures


@testset "test linkable monomers" begin
    agentnames = MEDYAN.AgentNames(
            filamentnames= [(:a,[
                                :me,
                                :a,
                                :b,
                                :c,
                                :pe,
                            ]),
                            (:b,[
                                :me,
                                :a,
                                :b,
                                :c,
                                :pe,
                            ]),
            ],
        )
    
    grid= CubicGrid((4,1,1),500.0)
    s = MEDYAN.SysDef(agentnames)
    filamentmechparams= MEDYAN.FilamentMechParams(
        radius= 1.0,
        spacing= 10.0,
        klength= 1.0,
        kangle= 1.0,
        numpercylinder= 40,
        max_num_unmin_end= 1000,
    )
    add_filament_params!(s, :a, filamentmechparams)
    add_filament_params!(s, :b, filamentmechparams)
    site = MEDYAN.Decimated2MonSiteRange(s.filament.a,s.filament.a,1,1,s.state.a.a,s.state.a.a,15.0,35.0)
    add_decimated_2mon_site!(s,:s,site)
    sitestep3 = MEDYAN.Decimated2MonSiteRange(s.filament.a,s.filament.a,3,3,s.state.a.a,s.state.a.a,15.0,35.0)
    add_decimated_2mon_site!(s,:step3,sitestep3)
    #multiple filament type decimated_2mon site
    siteab = MEDYAN.Decimated2MonSiteRange(s.filament.a,s.filament.b,1,1,s.state.a.a,s.state.a.a,15.0,35.0)
    add_decimated_2mon_site!(s,:ab,siteab)
    siteba = MEDYAN.Decimated2MonSiteRange(s.filament.b,s.filament.a,1,1,s.state.a.a,s.state.a.a,15.0,35.0)
    add_decimated_2mon_site!(s,:ba,siteba)
    siteb3a2 = MEDYAN.Decimated2MonSiteRange(s.filament.b,s.filament.a,3,2,s.state.a.a,s.state.a.a,15.0,35.0)
    add_decimated_2mon_site!(s,:b3a2,siteb3a2)
    cinit = MEDYAN.Context(s,grid, check_sitecount_error=true)

    nodepositionsA = [SA[5.0,200.0,200.0], SA[5.0+9*10.0,200.0,200.0]]
    nodepositionsB = [SA[15.0,201.0,200.0], SA[15.0+9*10.0,201.0,200.0]]
    nodepositionsC = [SA[470.0,200.0,200.0], SA[470.0+9*10.0,200.0,200.0]]
    nodepositionsD = [SA[480.0,201.0,200.0], SA[480.0+9*10.0,201.0,200.0]]

    @testset "single filament one compartment" begin
        c = deepcopy(cinit)
        nummonomers= 9
        monomerstates= zeros(MonomerState,nummonomers)
        monomerstates[1]= s.state.a.me
        monomerstates[2:end-1].= s.state.a.a
        monomerstates[end]= s.state.a.pe
        nodepositions = [SA[10.0,200.0,200.0], SA[10.0+nummonomers*10.0,200.0,200.0]]
        fid = MEDYAN.chem_newfilament!(c; ftid=s.filament.a,monomerstates,node_mids=[1,], nodepositions)
        MEDYAN.helper_mark_monomers_minimized!(c)
        MEDYAN.compartmentalize!(c)
        lbsid = s.decimated_2mon_site.s.id
        local m = c.decimated_2mon_site_managers[lbsid]
        pairlists = m.system.output.pairlists
        namepairs = map(pairlists) do pairlist
            map(pairlist) do pair
                MEDYAN.index2name(m, pair)
            end
        end
        mn(a,b) = (MonomerName(1, fid, a), MonomerName(1, fid, b))
        in_range_set = Set([
            mn(1,3),
            mn(1,4),
            mn(2,4),
            mn(2,5),
            mn(3,1),
            mn(3,5),
            mn(3,6),
            mn(4,1),
            mn(4,2),
            mn(4,6),
            mn(4,7),
            mn(5,2),
            mn(5,3),
            mn(5,7),
            mn(5,8),
            mn(6,3),
            mn(6,4),
            mn(6,8),
            mn(6,9),
            mn(7,4),
            mn(7,5),
            mn(7,9),
            mn(8,5),
            mn(8,6),
            mn(9,6),
            mn(9,7),
        ])
        linkable_set = Set([
            mn(2,4),
            mn(2,5),
            mn(3,5),
            mn(3,6),
            mn(4,2),
            mn(4,6),
            mn(4,7),
            mn(5,2),
            mn(5,3),
            mn(5,7),
            mn(5,8),
            mn(6,3),
            mn(6,4),
            mn(6,8),
            mn(7,4),
            mn(7,5),
            mn(8,5),
            mn(8,6),
        ])
        @test namepairs[1] |> Set == in_range_set
        samplingresults = DataStructures.DefaultOrderedDict{Union{Tuple{MonomerName,MonomerName},Nothing},Int}(0)
        for i in 1:1000
            samplingresults[MEDYAN.pickrandom_decimated_2mon_site(c,1,lbsid)] += 1
        end
        @test issetequal(keys(samplingresults), linkable_set ∪ Set((nothing,)))
        for i in 1:100
            @test MEDYAN.pickrandom_decimated_2mon_site(c,2,lbsid) == nothing
        end
        @test isempty(namepairs[2])
        @test isempty(namepairs[3])
        @test isempty(namepairs[4])
        @test c.chemistryengine.fixedcounts[lbsid,:] == [length(in_range_set),0,0,0]
    end
    @testset "single filament two compartments" begin
        c = deepcopy(cinit)
        nummonomers= 9
        monomerstates= zeros(MonomerState,nummonomers)
        monomerstates[1]= s.state.a.me
        monomerstates[2:end-1].= s.state.a.a
        monomerstates[end]= s.state.a.pe
        nodepositions= nodepositionsC
        fid = MEDYAN.chem_newfilament!(c; ftid=s.filament.a,monomerstates,node_mids=[1,], nodepositions)
        MEDYAN.helper_mark_monomers_minimized!(c)
        MEDYAN.compartmentalize!(c)
        MEDYAN.helper_mark_monomers_minimized!(c)
        MEDYAN.compartmentalize!(c)
        
        lbsid = s.decimated_2mon_site.s.id
        local m = c.decimated_2mon_site_managers[lbsid]
        pairlists = m.system.output.pairlists
        namepairs = map(pairlists) do pairlist
            map(pairlist) do pair
                MEDYAN.index2name(m, pair)
            end
        end
        mn(a,b) = (MonomerName(1, fid, a), MonomerName(1, fid, b))
        in_range_set1 = Set([
            mn(1,3),
            mn(1,4),
            mn(2,4),
            mn(2,5),
            mn(3,1),
            mn(3,5),
            mn(3,6),
        ])
        in_range_set2 = Set([
            mn(4,1),
            mn(4,2),
            mn(4,6),
            mn(4,7),
            mn(5,2),
            mn(5,3),
            mn(5,7),
            mn(5,8),
            mn(6,3),
            mn(6,4),
            mn(6,8),
            mn(6,9),
            mn(7,4),
            mn(7,5),
            mn(7,9),
            mn(8,5),
            mn(8,6),
            mn(9,6),
            mn(9,7),
        ])
        linkable_set1 = Set([
            mn(2,4),
            mn(2,5),
            mn(3,5),
            mn(3,6),
        ])
        linkable_set2 = Set([
            mn(4,2),
            mn(4,6),
            mn(4,7),
            mn(5,2),
            mn(5,3),
            mn(5,7),
            mn(5,8),
            mn(6,3),
            mn(6,4),
            mn(6,8),
            mn(7,4),
            mn(7,5),
            mn(8,5),
            mn(8,6),
        ])
        samplingresults = DataStructures.DefaultOrderedDict{Union{Tuple{MonomerName,MonomerName},Nothing},Int}(0)
        for i in 1:10000
            samplingresults[MEDYAN.pickrandom_decimated_2mon_site(c,1,lbsid)] += 1
        end
        @test issetequal(keys(samplingresults), linkable_set1 ∪ Set((nothing,)))
        empty!(samplingresults)
        for i in 1:10000
            samplingresults[MEDYAN.pickrandom_decimated_2mon_site(c,2,lbsid)] += 1
        end
        @test issetequal(keys(samplingresults), linkable_set2 ∪ Set((nothing,)))
        for i in 1:100
            @test MEDYAN.pickrandom_decimated_2mon_site(c,3,lbsid) == nothing
        end
        @test namepairs[1] |> Set == in_range_set1
        @test namepairs[2] |> Set == in_range_set2
        @test isempty(namepairs[3])
        @test isempty(namepairs[4])
        @test c.chemistryengine.fixedcounts[lbsid,:] == [length(in_range_set1),length(in_range_set2),0,0]
    end
    @testset "two filament types one compartment" begin
        c = deepcopy(cinit)
        nummonomers= 9
        monomerstates= zeros(MonomerState,nummonomers)
        monomerstates[1]= s.state.a.me
        monomerstates[2:end-1].= s.state.a.a
        monomerstates[end]= s.state.a.pe
        nodepositions1= nodepositionsA
        nodepositions2= nodepositionsB
        fid1 = MEDYAN.chem_newfilament!(c; ftid=s.filament.a,monomerstates,nodepositions=nodepositions1,node_mids=[1,])
        fid2 = MEDYAN.chem_newfilament!(c; ftid=s.filament.b,monomerstates,nodepositions=nodepositions2,node_mids=[1,])
        MEDYAN.helper_mark_monomers_minimized!(c)
        MEDYAN.compartmentalize!(c)

        lbsid_ab = s.decimated_2mon_site.ab.id
        local m_ab = c.decimated_2mon_site_managers[lbsid_ab]
        pairlists_ab = m_ab.system.output.pairlists
        namepairs_ab = map(pairlists_ab) do pairlist
            map(pairlist) do pair
                MEDYAN.index2name(m_ab, pair)
            end
        end

        lbsid_ba = s.decimated_2mon_site.ba.id
        local m_ba = c.decimated_2mon_site_managers[lbsid_ba]
        pairlists_ba = m_ba.system.output.pairlists
        namepairs_ba = map(pairlists_ba) do pairlist
            map(pairlist) do pair
                MEDYAN.index2name(m_ba, pair)
            end
        end

        mn(a,b) = (MonomerName(s.filament.a, fid1, a), MonomerName(s.filament.b, fid2, b))
        in_range_set_ab = Set([
            mn(1,2),
            mn(1,3),
            mn(2,3),
            mn(2,4),
            mn(3,4),
            mn(3,5),
            mn(4,1),
            mn(4,5),
            mn(4,6),
            mn(5,1),
            mn(5,2),
            mn(5,6),
            mn(5,7),
            mn(6,2),
            mn(6,3),
            mn(6,7),
            mn(6,8),
            mn(7,3),
            mn(7,4),
            mn(7,8),
            mn(7,9),
            mn(8,4),
            mn(8,5),
            mn(8,9),
            mn(9,5),
            mn(9,6),
        ])
        linkable_set_ab = Set([
            mn(2,3),
            mn(2,4),
            mn(3,4),
            mn(3,5),
            mn(4,5),
            mn(4,6),
            mn(5,2),
            mn(5,6),
            mn(5,7),
            mn(6,2),
            mn(6,3),
            mn(6,7),
            mn(6,8),
            mn(7,3),
            mn(7,4),
            mn(7,8),
            mn(8,4),
            mn(8,5),
        ])
        in_range_set_ba = Set(reverse.(in_range_set_ab))
        linkable_set_ba = Set(reverse.(linkable_set_ab))
        @test namepairs_ab[1] |> Set == in_range_set_ab
        @test namepairs_ba[1] |> Set == in_range_set_ba

        samplingresults = DataStructures.DefaultOrderedDict{Union{Tuple{MonomerName,MonomerName},Nothing},Int}(0)
        for i in 1:1000
            samplingresults[MEDYAN.pickrandom_decimated_2mon_site(c,1,lbsid_ab)] += 1
        end
        @test issetequal(keys(samplingresults), linkable_set_ab ∪ Set((nothing,)))

        empty!(samplingresults)
        for i in 1:1000
            samplingresults[MEDYAN.pickrandom_decimated_2mon_site(c,1,lbsid_ba)] += 1
        end
        @test issetequal(keys(samplingresults), linkable_set_ba ∪ Set((nothing,)))

        for i in 1:100
            @test MEDYAN.pickrandom_decimated_2mon_site(c,2,lbsid_ab) == nothing
            @test MEDYAN.pickrandom_decimated_2mon_site(c,2,lbsid_ba) == nothing
        end
        @test isempty(namepairs_ab[2])
        @test isempty(namepairs_ab[3])
        @test isempty(namepairs_ab[4])
        @test isempty(namepairs_ba[2])
        @test isempty(namepairs_ba[3])
        @test isempty(namepairs_ba[4])
        @test c.chemistryengine.fixedcounts[lbsid_ab,:] == [length(in_range_set_ab),0,0,0]
        @test c.chemistryengine.fixedcounts[lbsid_ba,:] == [length(in_range_set_ba),0,0,0]
    end
    @testset "two filament types two compartments" begin
        c = deepcopy(cinit)
        nummonomers= 9
        monomerstates= zeros(MonomerState,nummonomers)
        monomerstates[1]= s.state.a.me
        monomerstates[2:end-1].= s.state.a.a
        monomerstates[end]= s.state.a.pe
        nodepositions1= nodepositionsC
        nodepositions2= nodepositionsD
        fid1 = MEDYAN.chem_newfilament!(c; ftid=s.filament.a,monomerstates,nodepositions=nodepositions1,node_mids=[1,])
        fid2 = MEDYAN.chem_newfilament!(c; ftid=s.filament.b,monomerstates,nodepositions=nodepositions2,node_mids=[1,])
        MEDYAN.helper_mark_monomers_minimized!(c)
        MEDYAN.compartmentalize!(c)

        lbsid_ab = s.decimated_2mon_site.ab.id
        local m_ab = c.decimated_2mon_site_managers[lbsid_ab]
        pairlists_ab = m_ab.system.output.pairlists
        namepairs_ab = map(pairlists_ab) do pairlist
            map(pairlist) do pair
                MEDYAN.index2name(m_ab, pair)
            end
        end

        lbsid_ba = s.decimated_2mon_site.ba.id
        local m_ba = c.decimated_2mon_site_managers[lbsid_ba]
        pairlists_ba = m_ba.system.output.pairlists
        namepairs_ba = map(pairlists_ba) do pairlist
            map(pairlist) do pair
                MEDYAN.index2name(m_ba, pair)
            end
        end

        mn(a,b) = (MonomerName(s.filament.a, fid1, a), MonomerName(s.filament.b, fid2, b))
        in_range_set1_ab = Set([
            mn(1,2),
            mn(1,3),
            mn(2,3),
            mn(2,4),
            mn(3,4),
            mn(3,5),
        ])
        in_range_set2_ab = Set([
            mn(4,1),
            mn(4,5),
            mn(4,6),
            mn(5,1),
            mn(5,2),
            mn(5,6),
            mn(5,7),
            mn(6,2),
            mn(6,3),
            mn(6,7),
            mn(6,8),
            mn(7,3),
            mn(7,4),
            mn(7,8),
            mn(7,9),
            mn(8,4),
            mn(8,5),
            mn(8,9),
            mn(9,5),
            mn(9,6),
        ])
        linkable_set1_ab = Set([
            mn(2,3),
            mn(2,4),
            mn(3,4),
            mn(3,5),
        ])
        linkable_set2_ab = Set([
            mn(4,5),
            mn(4,6),
            mn(5,2),
            mn(5,6),
            mn(5,7),
            mn(6,2),
            mn(6,3),
            mn(6,7),
            mn(6,8),
            mn(7,3),
            mn(7,4),
            mn(7,8),
            mn(8,4),
            mn(8,5),
        ])

        in_range_set1_ba = Set(reverse.(Set([
            mn(1,2),
            mn(4,1),
            mn(5,1),
            mn(5,2),
            mn(6,2),
        ])))
        in_range_set2_ba = Set(reverse.(Set([
            mn(1,3),
            mn(2,3),
            mn(2,4),
            mn(3,4),
            mn(3,5),
            mn(4,5),
            mn(4,6),
            mn(5,6),
            mn(5,7),
            mn(6,3),
            mn(6,7),
            mn(6,8),
            mn(7,3),
            mn(7,4),
            mn(7,8),
            mn(7,9),
            mn(8,4),
            mn(8,5),
            mn(8,9),
            mn(9,5),
            mn(9,6),
        ])))
        linkable_set1_ba = Set(reverse.(Set([
            mn(5,2),
            mn(6,2),
        ])))
        linkable_set2_ba = Set(reverse.(Set([
            mn(2,3),
            mn(2,4),
            mn(3,4),
            mn(3,5),
            mn(4,5),
            mn(4,6),
            mn(5,6),
            mn(5,7),
            mn(6,3),
            mn(6,7),
            mn(6,8),
            mn(7,3),
            mn(7,4),
            mn(7,8),
            mn(8,4),
            mn(8,5),
        ])))

        @test namepairs_ab[1] |> Set == in_range_set1_ab
        @test namepairs_ba[1] |> Set == in_range_set1_ba
        @test namepairs_ab[2] |> Set == in_range_set2_ab
        @test namepairs_ba[2] |> Set == in_range_set2_ba

        samplingresults = DataStructures.DefaultOrderedDict{Union{Tuple{MonomerName,MonomerName},Nothing},Int}(0)
        empty!(samplingresults)
        for i in 1:1000
            samplingresults[MEDYAN.pickrandom_decimated_2mon_site(c,1,lbsid_ab)] += 1
        end
        @test issetequal(keys(samplingresults), linkable_set1_ab ∪ Set((nothing,)))

        empty!(samplingresults)
        for i in 1:1000
            samplingresults[MEDYAN.pickrandom_decimated_2mon_site(c,2,lbsid_ab)] += 1
        end
        @test issetequal(keys(samplingresults), linkable_set2_ab ∪ Set((nothing,)))

        empty!(samplingresults)
        for i in 1:1000
            samplingresults[MEDYAN.pickrandom_decimated_2mon_site(c,1,lbsid_ba)] += 1
        end
        @test issetequal(keys(samplingresults), linkable_set1_ba ∪ Set((nothing,)))

        empty!(samplingresults)
        for i in 1:1000
            samplingresults[MEDYAN.pickrandom_decimated_2mon_site(c,2,lbsid_ba)] += 1
        end
        @test issetequal(keys(samplingresults), linkable_set2_ba ∪ Set((nothing,)))


        for i in 1:100
            @test MEDYAN.pickrandom_decimated_2mon_site(c,3,lbsid_ab) == nothing
            @test MEDYAN.pickrandom_decimated_2mon_site(c,3,lbsid_ba) == nothing
        end
        @test isempty(namepairs_ab[3])
        @test isempty(namepairs_ab[4])
        @test isempty(namepairs_ba[3])
        @test isempty(namepairs_ba[4])
        @test c.chemistryengine.fixedcounts[lbsid_ab,:] == [length(in_range_set1_ab),length(in_range_set2_ab),0,0]
        @test c.chemistryengine.fixedcounts[lbsid_ba,:] == [length(in_range_set1_ba),length(in_range_set2_ba),0,0]
    end
    @testset "single filament two compartments step size 3" begin
        c = deepcopy(cinit)
        nummonomers= 9
        monomerstates= zeros(MonomerState,nummonomers)
        monomerstates[1]= s.state.a.me
        monomerstates[2:end-1].= s.state.a.a
        monomerstates[end]= s.state.a.pe
        nodepositions= nodepositionsC
        fid = MEDYAN.chem_newfilament!(c; ftid=s.filament.a,monomerstates,node_mids=[1,], nodepositions)
        MEDYAN.helper_mark_monomers_minimized!(c)
        MEDYAN.compartmentalize!(c)

        lbsid = s.decimated_2mon_site.step3.id
        local m = c.decimated_2mon_site_managers[lbsid]
        pairlists = m.system.output.pairlists
        namepairs = map(pairlists) do pairlist
            map(pairlist) do pair
                MEDYAN.index2name(m, pair)
            end
        end
        mn(a,b) = (MonomerName(1, fid, a), MonomerName(1, fid, b))
        in_range_set1 = Set([
            mn(3,6),
        ])
        in_range_set2 = Set([
            mn(6,3),
            mn(6,9),
            mn(9,6),
        ])
        linkable_set1 = Set([
            mn(3,6),
        ])
        linkable_set2 = Set([
            mn(6,3),
        ])
        samplingresults = DataStructures.DefaultOrderedDict{Union{Tuple{MonomerName,MonomerName},Nothing},Int}(0)
        for i in 1:10000
            samplingresults[MEDYAN.pickrandom_decimated_2mon_site(c,1,lbsid)] += 1
        end

        @test issetequal(keys(samplingresults), linkable_set1)
        empty!(samplingresults)
        for i in 1:10000
            samplingresults[MEDYAN.pickrandom_decimated_2mon_site(c,2,lbsid)] += 1
        end
        @test issetequal(keys(samplingresults), linkable_set2 ∪ Set((nothing,)))
        for i in 1:100
            @test MEDYAN.pickrandom_decimated_2mon_site(c,3,lbsid) == nothing
        end
        @test namepairs[1] |> Set == in_range_set1
        @test namepairs[2] |> Set == in_range_set2
        @test isempty(namepairs[3])
        @test isempty(namepairs[4])
        @test c.chemistryengine.fixedcounts[lbsid,:] == [length(in_range_set1),length(in_range_set2),0,0]
    end
    @testset "two filament types two compartments step size 3 and 2" begin
        c = deepcopy(cinit)
        nummonomers= 9
        monomerstates= zeros(MonomerState,nummonomers)
        monomerstates[1]= s.state.a.me
        monomerstates[2:end-1].= s.state.a.a
        monomerstates[end]= s.state.a.pe
        nodepositions1= nodepositionsC
        nodepositions2= nodepositionsD
        fid1 = MEDYAN.chem_newfilament!(c; ftid=s.filament.a,monomerstates,nodepositions=nodepositions1,node_mids=[1,])
        fid2 = MEDYAN.chem_newfilament!(c; ftid=s.filament.b,monomerstates,nodepositions=nodepositions2,node_mids=[1,])
        MEDYAN.helper_mark_monomers_minimized!(c)
        MEDYAN.compartmentalize!(c)

        lbsid = s.decimated_2mon_site.b3a2.id
        local m = c.decimated_2mon_site_managers[lbsid]
        pairlists = m.system.output.pairlists
        namepairs = map(pairlists) do pairlist
            map(pairlist) do pair
                MEDYAN.index2name(m, pair)
            end
        end

        mn(a,b) = (MonomerName(s.filament.a, fid1, a), MonomerName(s.filament.b, fid2, b))

        in_range_set2 = Set(reverse.(Set([
            mn(2,3),
            mn(4,6),
            mn(6,3),
            mn(8,9),
        ])))
        linkable_set2 = Set(reverse.(Set([
            mn(2,3),
            mn(4,6),
            mn(6,3),
        ])))
        @test namepairs[2] |> Set == in_range_set2

        samplingresults = DataStructures.DefaultOrderedDict{Union{Tuple{MonomerName,MonomerName},Nothing},Int}(0)
        for i in 1:1000
            samplingresults[MEDYAN.pickrandom_decimated_2mon_site(c,2,lbsid)] += 1
        end
        @test issetequal(keys(samplingresults), linkable_set2 ∪ Set((nothing,)))

        for i in 1:100
            @test MEDYAN.pickrandom_decimated_2mon_site(c,1,lbsid) == nothing
        end
        @test isempty(namepairs[1])
        @test isempty(namepairs[3])
        @test isempty(namepairs[4])
        @test c.chemistryengine.fixedcounts[lbsid,:] == [0,length(in_range_set2),0,0]
    end
end