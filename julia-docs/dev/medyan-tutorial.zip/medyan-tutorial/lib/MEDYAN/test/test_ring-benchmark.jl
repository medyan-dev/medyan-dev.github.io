using Test
using Setfield
import SmallZarrGroups
using MEDYAN

module ActinRing
    include("../examples/actin-ring/main.jl")
end

@testset "ring system" begin
    h, c = ActinRing.setup("1")
    group = SmallZarrGroups.load_zip("actin-ring/snap1500.zarr.zip")
    c = ActinRing.load(1500, group["snap"], c)
    # c = ActinRing.loop(1500, c)
    MEDYAN.compartmentalize!(c)
    c2 = @set c.check_sitecount_error = true
    MEDYAN.helper_check_sitecount_error(c2)
    MEDYAN.run_chemistry!(c2,0.0005)
    MEDYAN.minimize_energy!(c2)
    MEDYAN.run_chemistry!(c2,0.0005)
    MEDYAN.minimize_energy!(c2)
end