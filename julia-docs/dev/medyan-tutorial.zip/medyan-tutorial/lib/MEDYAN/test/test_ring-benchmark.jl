using Test
using Setfield
import SmallZarrGroups
using MEDYAN
using Random


module ActinRing
    include("../../examples/actin-ring/main.jl")
end

@testset "ring system" begin
    h, c = ActinRing.setup("1")
    group = SmallZarrGroups.load_zip(joinpath(@__DIR__,"actin-ring/650.zip"))
    c = ActinRing.load(650, group["snap"], c)
    # c = ActinRing.loop(651, c)
    MEDYAN.refresh_chem_cache!(c)
    c2 = @set c.check_sitecount_error = true
    MEDYAN.helper_check_sitecount_error(c2)
    MEDYAN.run_chemistry!(c2,0.0005)

    # Check multithreaded forces give same results
    Random.seed!(12345)
    fc = MEDYAN.ForceContext(c2; brownian_motion_time=0.001, nthreads=1,)
    MEDYAN.calc_all_force_energy!(fc, fc.x0)
    f1 = MEDYAN.get_force(fc.per_thread_force_energy[1])
    e1 = MEDYAN.get_energy(fc.per_thread_force_energy[1])

    Random.seed!(12345)
    fc = MEDYAN.ForceContext(c2; brownian_motion_time=0.001, nthreads=2,)
    MEDYAN.calc_all_force_energy!(fc, fc.x0)
    f2 = MEDYAN.get_force(fc.per_thread_force_energy[1])
    e2 = MEDYAN.get_energy(fc.per_thread_force_energy[1])
    @test e2 == e1
    @test f2 == f1

    MEDYAN.minimize_energy!(c2)
    MEDYAN.run_chemistry!(c2,0.0005)
    MEDYAN.minimize_energy!(c2)
end
