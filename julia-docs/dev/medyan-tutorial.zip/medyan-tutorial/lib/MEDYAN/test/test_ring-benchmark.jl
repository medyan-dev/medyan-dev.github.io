using Test
using Setfield

@testset "ring system" begin
    include("../benchmarks/ringbenchmark.jl")
    c,s = rerun(load_group();frames=5)
    MEDYAN.compartmentalize!(c)
    c2 = @set c.check_sitecount_error = true
    MEDYAN.helper_check_sitecount_error(c2)
    MEDYAN.run_chemistry!(c2,0.0005)
    MEDYAN.minimize_energy!(c2)
    MEDYAN.run_chemistry!(c2,0.0005)
    MEDYAN.minimize_energy!(c2)
end