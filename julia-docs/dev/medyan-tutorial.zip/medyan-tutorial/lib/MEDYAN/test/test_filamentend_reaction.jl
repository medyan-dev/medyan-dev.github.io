using MEDYAN
using StaticArrays
using Test

@testset "filamentend_reaction" begin
    agentnames = MEDYAN.AgentNames(
            filamentnames= [(:a,[
                                :me,
                                :a,
                                :b,
                                :c,
                                :pe,
                            ]),
            ],
        )
    grid= CubicGrid((4,1,1),500.0)
    @testset "depolymerize minus end" begin
        s= MEDYAN.SysDef(agentnames)
        add_filament_params!(s, :a, MEDYAN.UNITY_FIL_PARAMS)
        site= MEDYAN.FilamentEndSiteGeneral(;
            isminusend=true,
            endstates=[s.state.a.me,s.state.a.a],
            spacing=0.0,
        )
        addfilamentendsite!(s,:a,:dpm,site)
        callback= MEDYAN.GeneralFilamentEndCallback(
            s.filament.a,
            s.filamentendsite.a.dpm.id,
            -1,
            [s.state.a.me],
            [],
        )
        addreactioncallback!(s, "filamentendsite.a.dpm",1.75,1,callback)
        nummonomers= 7
        monomerstates= zeros(MonomerState,nummonomers)
        monomerstates[1]= s.state.a.me
        monomerstates[2:end-1].= s.state.a.a
        monomerstates[end]= s.state.a.pe
        nodepositions = [SA[600.0,200.0,200.0],SA[1300.0,200.0,200.0]] .+ Ref(MEDYAN.cornerof(grid))
        c= MEDYAN.Context(s,grid)
        MEDYAN.chem_newfilament!(c;ftid=s.filament.a,monomerstates,node_mids=[1,], nodepositions)
        @test c.chemistryengine.fixedcounts[1,:] == [0,1,0,0]
        callback(c,1)
        @test c.chemistryengine.fixedcounts[1,:] == [0,1,0,0]
        callback(c,2)
        @test c.chemistryengine.fixedcounts[1,:] == [0,1,0,0]
        callback(c,2)
        @test c.chemistryengine.fixedcounts[1,:] == [0,1,0,0]
        callback(c,2)
        @test c.chemistryengine.fixedcounts[1,:] == [0,1,0,0]
        callback(c,2)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,1,0]
        callback(c,2)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,1,0]
        callback(c,3)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,0,0]
        callback(c,3)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,0,0]
    end
    @testset "depolymerize plus end" begin
        s= MEDYAN.SysDef(agentnames)
        add_filament_params!(s, :a, MEDYAN.UNITY_FIL_PARAMS)
        site= MEDYAN.FilamentEndSiteGeneral(;
            isminusend=false,
            endstates=[s.state.a.a,s.state.a.pe],
            spacing=0.0,
        )
        addfilamentendsite!(s,:a,:dpp,site)
        callback= MEDYAN.GeneralFilamentEndCallback(
            s.filament.a,
            s.filamentendsite.a.dpp.id,
            -1,
            [s.state.a.pe],
            [],
        )
        addreactioncallback!(s, "filamentendsite.a.dpp",1.75,1,callback)
        nummonomers= 7
        monomerstates= zeros(MonomerState,nummonomers)
        monomerstates[1]= s.state.a.me
        monomerstates[2:end-1].= s.state.a.a
        monomerstates[end]= s.state.a.pe
        nodepositions = [SA[600.0,200.0,200.0],SA[1300.0,200.0,200.0]] .+ Ref(MEDYAN.cornerof(grid))
        c= MEDYAN.Context(s,grid)
        MEDYAN.chem_newfilament!(c;ftid=s.filament.a,monomerstates,node_mids=[1,], nodepositions)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,1,0]
        for i in 1:2
            callback(c,3)
            @test c.chemistryengine.fixedcounts[1,:] == [0,0,1,0]
        end
        callback(c,3)
        @test c.chemistryengine.fixedcounts[1,:] == [0,1,0,0]
        callback(c,3)
        @test c.chemistryengine.fixedcounts[1,:] == [0,1,0,0]
        callback(c,2)
        @test c.chemistryengine.fixedcounts[1,:] == [0,1,0,0]
        callback(c,2)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,0,0]
        callback(c,2)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,0,0]
    end
    @testset "polymerize minus end" begin
        s= MEDYAN.SysDef(agentnames)
        add_filament_params!(s, :a, MEDYAN.UNITY_FIL_PARAMS)
        site= MEDYAN.FilamentEndSiteGeneral(;
            isminusend=true,
            endstates=[s.state.a.me],
            spacing=150.0,
            added_monomers = 1,
        )
        addfilamentendsite!(s,:a,:pm,site)
        callback= MEDYAN.GeneralFilamentEndCallback(
            s.filament.a,
            s.filamentendsite.a.pm.id,
            1,
            [s.state.a.me,s.state.a.a],
            [],
        )
        addreactioncallback!(s, "filamentendsite.a.pm",1.75,0,callback)
        nummonomers= 7
        monomerstates= zeros(MonomerState,nummonomers)
        monomerstates[1]= s.state.a.me
        monomerstates[2:end-1].= s.state.a.a
        monomerstates[end]= s.state.a.pe
        nodepositions = [SA[700.0,200.0,200.0],SA[1700.0,200.0,200.0]] .+ Ref(MEDYAN.cornerof(grid))
        c= MEDYAN.Context(s,grid)
        MEDYAN.chem_newfilament!(c;ftid=s.filament.a,monomerstates,node_mids=[1,], nodepositions)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,0,0] # zero because not minimized
        MEDYAN.helper_mark_monomers_minimized!(c)
        MEDYAN.refresh_chem_cache!(c)
        @test c.chemistryengine.fixedcounts[1,:] == [0,1,0,0]
        callback(c,2)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,0,0] # zero because not minimized
        MEDYAN.helper_mark_monomers_minimized!(c)
        MEDYAN.refresh_chem_cache!(c)
        @test c.chemistryengine.fixedcounts[1,:] == [0,1,0,0]
        callback(c,2)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,0,0] # zero because not minimized
        MEDYAN.helper_mark_monomers_minimized!(c)
        MEDYAN.refresh_chem_cache!(c)
        @test c.chemistryengine.fixedcounts[1,:] == [1,0,0,0]
        callback(c,1)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,0,0] # zero because not minimized
        MEDYAN.helper_mark_monomers_minimized!(c)
        MEDYAN.refresh_chem_cache!(c)
        @test c.chemistryengine.fixedcounts[1,:] == [1,0,0,0]
        callback(c,1)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,0,0] # zero because not minimized
        MEDYAN.helper_mark_monomers_minimized!(c)
        MEDYAN.refresh_chem_cache!(c)
        @test c.chemistryengine.fixedcounts[1,:] == [1,0,0,0]
    end
    @testset "polymerize plus end" begin
        s= MEDYAN.SysDef(agentnames)
        add_filament_params!(s, :a, MEDYAN.UNITY_FIL_PARAMS)
        site= MEDYAN.FilamentEndSiteGeneral(;
            isminusend=false,
            endstates=[s.state.a.pe],
            spacing=100.0,
            added_monomers = 1,
        )
        addfilamentendsite!(s,:a,:pp,site)
        callback= MEDYAN.GeneralFilamentEndCallback(
            s.filament.a,
            s.filamentendsite.a.pp.id,
            1,
            [s.state.a.a,s.state.a.pe],
            [],
        )
        addreactioncallback!(s, "filamentendsite.a.pp",1.75,0,callback)
        nummonomers= 8
        monomerstates= zeros(MonomerState,nummonomers)
        monomerstates[1]= s.state.a.me
        monomerstates[2:end-1].= s.state.a.a
        monomerstates[end]= s.state.a.pe
        nodepositions = [SA[500.0,200.0,200.0],SA[1300.0,200.0,200.0]] .+ Ref(MEDYAN.cornerof(grid))
        c= MEDYAN.Context(s,grid)
        MEDYAN.chem_newfilament!(c;ftid=s.filament.a,monomerstates,node_mids=[1,], nodepositions)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,0,0] # zero because not minimized
        MEDYAN.helper_mark_monomers_minimized!(c)
        MEDYAN.refresh_chem_cache!(c)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,1,0]
        callback(c,3)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,0,0] # zero because not minimized
        MEDYAN.helper_mark_monomers_minimized!(c)
        MEDYAN.refresh_chem_cache!(c)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,1,0]
        callback(c,3)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,0,0] # zero because not minimized
        MEDYAN.helper_mark_monomers_minimized!(c)
        MEDYAN.refresh_chem_cache!(c)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,1,0]
        callback(c,3)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,0,0] # zero because not minimized
        MEDYAN.helper_mark_monomers_minimized!(c)
        MEDYAN.refresh_chem_cache!(c)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,0,1]
        callback(c,4)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,0,0] # zero because not minimized
        MEDYAN.helper_mark_monomers_minimized!(c)
        MEDYAN.refresh_chem_cache!(c)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,0,1]
        callback(c,4)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,0,0] # zero because not minimized
        MEDYAN.helper_mark_monomers_minimized!(c)
        MEDYAN.refresh_chem_cache!(c)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,0,1]
    end
    @testset "change end state plus end" begin
        s= MEDYAN.SysDef(agentnames)
        add_filament_params!(s, :a, MEDYAN.UNITY_FIL_PARAMS)
        site= MEDYAN.FilamentEndSiteGeneral(;
            isminusend=false,
            endstates=[s.state.a.pe],
            spacing=0.0,
        )
        addfilamentendsite!(s,:a,:pp,site)
        callback= MEDYAN.GeneralFilamentEndCallback(
            s.filament.a,
            s.filamentendsite.a.pp.id,
            0,
            [s.state.a.c],
            [],
        )
        addreactioncallback!(s, "filamentendsite.a.pp",1.75,0,callback)
        nummonomers= 7
        monomerstates= zeros(MonomerState,nummonomers)
        monomerstates[1]= s.state.a.me
        monomerstates[2:end-1].= s.state.a.a
        monomerstates[end]= s.state.a.pe
        nodepositions = [SA[500.0,200.0,200.0],SA[1300.0,200.0,200.0]] .+ Ref(MEDYAN.cornerof(grid))
        c= MEDYAN.Context(s,grid)
        MEDYAN.chem_newfilament!(c;ftid=s.filament.a,monomerstates,node_mids=[1,], nodepositions)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,1,0]
        callback(c,3)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,0,0]
        @test fil_mon_states(c, 1, 1)[end] == s.state.a.c
    end
    @testset "change end state plus end 2" begin
        s= MEDYAN.SysDef(agentnames)
        add_filament_params!(s, :a, MEDYAN.UNITY_FIL_PARAMS)
        site= MEDYAN.FilamentEndSiteGeneral(;
            isminusend=false,
            endstates=[s.state.a.a,s.state.a.pe],
            spacing=0.0,
        )
        addfilamentendsite!(s,:a,:pp,site)
        callback= MEDYAN.GeneralFilamentEndCallback(
            s.filament.a,
            s.filamentendsite.a.pp.id,
            0,
            [s.state.a.c,s.state.a.b],
            [],
        )
        addreactioncallback!(s, "filamentendsite.a.pp",1.75,0,callback)
        nummonomers= 7
        monomerstates= zeros(MonomerState,nummonomers)
        monomerstates[1]= s.state.a.me
        monomerstates[2:end-1].= s.state.a.a
        monomerstates[end]= s.state.a.pe
        nodepositions = [SA[500.0,200.0,200.0],SA[1300.0,200.0,200.0]]
        c= MEDYAN.Context(s,grid)
        MEDYAN.chem_newfilament!(c;ftid=s.filament.a,monomerstates,node_mids=[1,], nodepositions)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,1,0]
        callback(c,3)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,0,0]
        @test fil_mon_states(c, 1, 1)[end - 1] == s.state.a.c
        @test fil_mon_states(c, 1, 1)[end] == s.state.a.b
    end
    @testset "change end state minus end" begin
        s= MEDYAN.SysDef(agentnames)
        add_filament_params!(s, :a, MEDYAN.UNITY_FIL_PARAMS)
        site= MEDYAN.FilamentEndSiteGeneral(;
            isminusend=true,
            endstates=[s.state.a.me,s.state.a.a],
            spacing=0.0,
        )
        addfilamentendsite!(s,:a,:pm,site)
        callback= MEDYAN.GeneralFilamentEndCallback(
            s.filament.a,
            s.filamentendsite.a.pm.id,
            0,
            [s.state.a.c,s.state.a.b],
            [],
        )
        addreactioncallback!(s, "filamentendsite.a.pm",1.75,0,callback)
        nummonomers= 7
        monomerstates= zeros(MonomerState,nummonomers)
        monomerstates[1]= s.state.a.me
        monomerstates[2:end-1].= s.state.a.a
        monomerstates[end]= s.state.a.pe
        nodepositions = [SA[700.0,200.0,200.0],SA[1700.0,200.0,200.0]] .+ Ref(MEDYAN.cornerof(grid))
        c= MEDYAN.Context(s,grid)
        MEDYAN.chem_newfilament!(c;ftid=s.filament.a,monomerstates,node_mids=[1,], nodepositions)
        @test c.chemistryengine.fixedcounts[1,:] == [0,1,0,0]
        callback(c,2)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,0,0]
        @test fil_mon_states(c, 1, 1)[begin + 1] == s.state.a.b
        @test fil_mon_states(c, 1, 1)[begin] == s.state.a.c
    end
end