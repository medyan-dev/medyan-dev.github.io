using MEDYAN
using Test

@testset "empty system" begin
    @testset "running empty system" begin
        s = MEDYAN.SysDef(MEDYAN.AgentNames())
        grid= CubicGrid((3,1,1),500.0)
        c= MEDYAN.Context(s,grid;)
        MEDYAN.minimize_energy!(c)
        run_chemistry!(c,1.0)
        MEDYAN.minimize_energy!(c)
    end
end