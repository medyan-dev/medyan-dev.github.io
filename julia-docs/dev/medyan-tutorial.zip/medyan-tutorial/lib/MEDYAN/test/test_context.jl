using MEDYAN
using StaticArrays
using Test

@testset "Context Construction" begin
    agentnames = MEDYAN.AgentNames(
        diffusingspeciesnames= [:a,:b,:c,:d],
        membranediffusingspeciesnames = [:ma, :mb],
    )
    s= MEDYAN.SysDef(agentnames)
    add_diffusion_coeff!(s, :a, 1.0)
    add_diffusion_coeff!(s, :b, 2.0)
    add_diffusion_coeff!(s, :c, 3.0)
    add_diffusion_coeff!(s, :d, 0.25)
    addmembranesite!(s, :memsite_a1,
        MembraneSiteDiffusing(1, true, [1=>-1])
    )
    addmembranesite!(s, :memsite_a2,
        MembraneSiteDiffusing(1, false, [1=>0])
    )
    addmembranesite!(s, :memsite_none,
        MembraneSiteDiffusing(0, true, [])
    )

    # Prepare to construct Context.
    grid= CubicGrid((2,1,1),10.0)
    membrane_species_params = SVector([MembraneSpeciesParams() for _ ∈ agentnames.membranediffusingspeciesnames]...)
    c= MEDYAN.Context(s,grid; membrane_species_params)

    @test c.grid == grid
    @test c.time[] == 0
    @test c.chemistryengine.diffusionrates[1,1,1] ≈ 1.0/100.0
    @test c.chemistryengine.diffusionrates[1,2,1] ≈ 2.0/100.0

    # Membrane sites.
    @test length(c.membranesites) == 3
    @test c.map_membranediffusingspeciesindex_membranesiteindices == ([1,2], Int[])
end

@testset "Context chemistry utilities" begin
    @testset "Vertex registration in compartments" begin
        s = MEDYAN.SysDef(MEDYAN.AgentNames())
        grid = MEDYAN.CubicGrid((2,2,2), 10.0)
        c = MEDYAN.Context(s, grid; membranemechparams = [MEDYAN.MembraneMechParams()])

        newmembrane!(c;
            type = 1,
            meshinit = (;
                vertlist = [SA[1,1,1], SA[11,1,1], SA[1,11,1], SA[2,2,2], SA[12,12,2], SA[12,12,12]] .+ Ref(MEDYAN.cornerof(grid)),
                trilist = [SA[1,2,3], SA[4,5,6]],
            ),
        )
        newmembrane!(c;
            type = 1,
            meshinit = (;
                vertlist = [SA[3,3,3], SA[4,4,4], SA[5,5,5]] .+ Ref(MEDYAN.cornerof(grid)),
                trilist = [SA[1,2,3]],
            ),
        )

        # Fill in some garbage.
        push!(c.compartments[1].vertexnames, MEDYAN.VertexName(100, 200))

        MEDYAN.helper_update_allverticesincompartments!(c)

        @test c.compartments[1].vertexnames == [
            MEDYAN.VertexName(1, 1),
            MEDYAN.VertexName(1, 4),
            MEDYAN.VertexName(2, 1),
            MEDYAN.VertexName(2, 2),
            MEDYAN.VertexName(2, 3),
        ]
        @test c.compartments[2].vertexnames == [
            MEDYAN.VertexName(1, 2),
        ]
        @test c.compartments[3].vertexnames == [
            MEDYAN.VertexName(1, 3),
        ]
        @test c.compartments[4].vertexnames == [
            MEDYAN.VertexName(1, 5),
        ]
        @test c.compartments[8].vertexnames == [
            MEDYAN.VertexName(1, 6),
        ]
        for cindex ∈ (5, 6, 7)
            @test isempty(c.compartments[cindex].vertexnames)
        end
        @test c.membranes[1].vertices.attr.cid == [1, 2, 3, 1, 4, 8]
        @test c.membranes[2].vertices.attr.cid == [1, 1, 1]
    end
end