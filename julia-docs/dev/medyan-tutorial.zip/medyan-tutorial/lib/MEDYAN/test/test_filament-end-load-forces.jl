using MEDYAN
using Test
using StaticArrays
using LinearAlgebra

@testset "Filament end load forces" begin
    x = SA[1.0,0.0,0.0]
    y = SA[0.0,1.0,0.0]
    z = SA[0.0,0.0,1.0]
    @testset "Single compressed by link_2mon should have zero load force" begin
        c = MEDYAN.example_actin_mech_context(CubicGrid((1, 1, 1), 500.0))
        monomerspacing = MEDYAN.ACTIN_FIL_PARAMS.spacing
        nmon = 20
        node_positions = [zero(x), monomerspacing*nmon*x]
        fila_idx = MEDYAN.make_fila!(c;
            type = 1, 
            mono_states = ones(MonomerState,nmon),
            node_mids = [1,],
            node_positions,
        )
        mon_a = MEDYAN.FilaMonoIdx(c, fila_idx, -, 1)
        mon_b = MEDYAN.FilaMonoIdx(c, fila_idx, +, -1)
        MEDYAN.make_link!(c;
            type = :fila_mono_restraint,
            places = (mon_a,),
            bond_states = ((;r0 = MEDYAN.get_position(c, mon_a) + x, v̂0=x,),)
        )
        MEDYAN.make_link!(c;
            type = :fila_mono_restraint,
            places = (mon_b,),
            bond_states = ((;r0 = MEDYAN.get_position(c, mon_b) - x, v̂0=x,),)
        )
        r = MEDYAN.minimize_energy!(c; g_tol=1E-3)
        cylinders = c.chem_cylinders[1]
        endloadforces = cylinders.per_fil.endloadforces[1]
        @test endloadforces[1] == 0.0
        @test endloadforces[2] == 0.0
    end

end