using MEDYAN
using Test
using StaticArrays
using LinearAlgebra

@testset "Filament end load forces" begin
    x = SA[1.0,0.0,0.0]
    y = SA[0.0,1.0,0.0]
    z = SA[0.0,0.0,1.0]
    @testset "Single compressed by link_2mon should have zero load force" begin
        monomerspacing = 2.5
        agentnames = MEDYAN.AgentNames(
            filamentnames = [
                (:a, [
                    :a,
                ]),
            ],
            link_2mon_names = [:restraint],
        )
        s = MEDYAN.SysDef(agentnames)
        add_filament_params!(s, :a, MEDYAN.FilamentMechParams(
            radius= 3.0,
            spacing= monomerspacing,
            klength= 40000.0,
            kangle= 20000.0,
            numpercylinder= 100,
            max_num_unmin_end= 1000,
        ))
        add_link_2mon!(s,
            :restraint,
            Link2MonState((;),(mr0 = zero(SVector{3,Float64}),mv̂0 = zero(SVector{3,Float64}))),
            MEDYAN.RestraintMechParams(kr=1.0,kv̂=0.0),
        )
        grid = CubicGrid((1, 1, 1), 500.0)
        c = MEDYAN.Context(
            s,grid;
            g_tol = 1E-3,
        )
        nmon = 20
        nodepositions = [250x+250y+250z, 250x+250y+250z+monomerspacing*nmon*x]
        fid1 = MEDYAN.chem_newfilament!(c;
            ftid= 1, 
            monomerstates = ones(MonomerState,nmon),
            node_mids = [1,],
            nodepositions,
        )
        MEDYAN.chem_newlink_2mon!(c,
            s.link_2mon.restraint,#ltid 
            MonomerName(1, fid1, 2)=>
            MonomerName(1, fid1, 2);
            changedmechstate = (mr0 = mon_position(c, MonomerName(1, fid1, 2)) + x, mv̂0 = x),
        )
        MEDYAN.chem_newlink_2mon!(c,
            s.link_2mon.restraint,#ltid 
            MonomerName(1, fid1, nmon-1)=>
            MonomerName(1, fid1, nmon-1);
            changedmechstate = (mr0 = mon_position(c, MonomerName(1, fid1, nmon-1)) - x, mv̂0 = x),
        )
        MEDYAN.minimize_energy!(c)
        cylinders = c.chem_cylinders[1]
        fil_idx1 = cylinders.fil_id_2_idx[fid1]
        endloadforces = cylinders.per_fil.endloadforces[fil_idx1]
        @test endloadforces[1] == 0.0
        @test endloadforces[2] == 0.0
    end

end