using MEDYAN
using Test
using StaticArrays
using Random

@testset "Filament buckling and polymerization rate change" begin
    c = MEDYAN.example_actin_mech_context(CubicGrid(SA[1,1,1], 5000.0))
    fila_params = MEDYAN.ACTIN_TWIST_PARAMS
    nmonomers = 400
    L = fila_params.spacing*nmonomers
    θminusend = 0.0
    θplusend = fila_params.twist_per_monomer*nmonomers
    fil = make_fila!(c;
        type= :actintwist,
        mono_states= ones(UInt8, nmonomers),
        node_mids= [0,],
        node_positions= [SA[-L/2,0,0],SA[+L/2,0,0]],
        minus_end_mat_dir= SA[0.0,1.0,0.0],
    )
    # Now restrain filament tips
    minus_link = make_link!(c;
        type= :fila_tip_frame_restraint,
        places= (FilaTipIdx(c, fil, -),),
        bond_states= ((;
            kr=10.0,
            ktbend=10000.0,
            km1bend=10000.0,
            r0=SA[-L/2,0,0],
            t0=SA[1.0,0.0,0.0],
            m10=SA[0.0,cos(θminusend),sin(θminusend)]
        ),),
    )
    plus_link = make_link!(c;
        type= :fila_tip_frame_restraint,
        places= (FilaTipIdx(c, fil, +),),
        bond_states= ((;
            kr=10.0,
            ktbend=10000.0,
            km1bend=10000.0,
            r0=SA[+L/2,0,0],
            t0=SA[1.0,0.0,0.0],
            m10=SA[0.0,cos(θplusend),sin(θplusend)]
        ),),
    )
    results1 = minimize_energy!(c;
        g_tol= 1E-5,
        shake_before_minimization= 0.0,
    )
    @test results1.final_energy == 0.0
    update_link!(c, plus_link;
        bond_states= ((;
            m10=SA[0.0,cos(θplusend+10*π/180),sin(θplusend+10*π/180)],
        ),),
    )
    expected_energy = 1//2*(10*π/180/nmonomers)^2 *fila_params.ktwist*nmonomers
    results2 = minimize_energy!(c;
        g_tol= 1E-5,
        shake_before_minimization= 0.0,
    )
    @test abs(results2.final_energy - expected_energy) < 0.2
end