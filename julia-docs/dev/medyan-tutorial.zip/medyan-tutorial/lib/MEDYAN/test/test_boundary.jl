using MEDYAN
using Test
using StaticArrays
using Random
using LinearAlgebra


@testset "Boundary" begin
    x = SA[1.0,0.0,0.0]
    y = SA[0.0,1.0,0.0]
    z = SA[0.0,0.0,1.0]
    o = SA[0.0,0.0,0.0]
    
    @testset "insideboundary" begin
        oneplane = MEDYAN.boundary_plane(;normal=x, point=200x)
        grid = CubicGrid(SA[2,3,4], 500.0)
        box = MEDYAN.boundary_box(grid; offset = 100.0)
        onesphere = MEDYAN.boundary_capsule(;center=200x, radius=400.0)
        onecapsule = MEDYAN.boundary_capsule(;center=200x+200y, axis=400y, radius=200.0)
        onecylinder = MEDYAN.boundary_cylinder(;center=200x+200y, axis=400y, radius=200.0)

        gc = MEDYAN.centerof(grid)
        @test !MEDYAN.insideboundary(box, gc + -450x)
        @test MEDYAN.insideboundary(box, gc + -350x)
        @test !MEDYAN.insideboundary(box, gc + 450x)
        @test MEDYAN.insideboundary(box, gc + 350x)
        @test !MEDYAN.insideboundary(box, gc + -700y)
        @test MEDYAN.insideboundary(box, gc + -600y)
        @test !MEDYAN.insideboundary(box, gc + 700y)
        @test MEDYAN.insideboundary(box, gc + 600y)
        @test !MEDYAN.insideboundary(box, gc + -950z)
        @test MEDYAN.insideboundary(box, gc + -850z)
        @test !MEDYAN.insideboundary(box, gc + 950z)
        @test MEDYAN.insideboundary(box, gc + 850z)

        @test !MEDYAN.insideboundary(oneplane,201x)
        @test MEDYAN.insideboundary(oneplane,199x)
        @test MEDYAN.insideboundary(oneplane,-200x)

        @test !MEDYAN.insideboundary(onesphere,-201x)
        @test !MEDYAN.insideboundary(onesphere,601x)
        @test !MEDYAN.insideboundary(onesphere,200x + 401y)
        @test MEDYAN.insideboundary(onesphere,200x + 399y)
        @test MEDYAN.insideboundary(onesphere,200x)
        @test MEDYAN.insideboundary(onesphere,-199x)

        @test !MEDYAN.insideboundary(onecapsule,-1x)
        @test !MEDYAN.insideboundary(onecapsule,401x)
        @test !MEDYAN.insideboundary(onecapsule,-1x+400y)
        @test !MEDYAN.insideboundary(onecapsule,401x+400y)
        @test !MEDYAN.insideboundary(onecapsule,200x+601y)
        @test !MEDYAN.insideboundary(onecapsule,200x+-201y)
        @test MEDYAN.insideboundary(onecapsule,200x)
        @test MEDYAN.insideboundary(onecapsule,1x)
        @test MEDYAN.insideboundary(onecapsule,399x)
        @test MEDYAN.insideboundary(onecapsule,200x+400y)
        @test MEDYAN.insideboundary(onecapsule,1x+400y)
        @test MEDYAN.insideboundary(onecapsule,399x+400y)
        @test MEDYAN.insideboundary(onecapsule,200x+599y)
        @test MEDYAN.insideboundary(onecapsule,200x+-199y)

        @test !MEDYAN.insideboundary(onecylinder,-1x)
        @test !MEDYAN.insideboundary(onecylinder,401x)
        @test !MEDYAN.insideboundary(onecylinder,-1x+400y)
        @test !MEDYAN.insideboundary(onecylinder,401x+400y)
        @test !MEDYAN.insideboundary(onecylinder,200x-1y)
        @test !MEDYAN.insideboundary(onecylinder,200x+401y)
        @test MEDYAN.insideboundary(onecylinder,1x+1y)
        @test MEDYAN.insideboundary(onecylinder,399x+1y)
        @test MEDYAN.insideboundary(onecylinder,200x+399y)
        @test MEDYAN.insideboundary(onecylinder,1x+399y)
        @test MEDYAN.insideboundary(onecylinder,399x+399y) 
    end
    @testset "plane forces" begin
        for i in 1:100
            boundingplanes= randn(SVector{4,Float64},4)
            x0= randn(Float64,3*10)
            force_energy0= MEDYAN.ForceEnergyFloat64(length(x0))
            MEDYAN.bounding_planes_forces!(force_energy0,x0,boundingplanes)
            E0= MEDYAN.get_energy(force_energy0)
            forces0= MEDYAN.get_force(force_energy0)
            for j in 1:100
                #choose random deviation
                local Δx= 1E-4 .* randn(Float64,3*10)
                local x= x0 .+ Δx
                force_energy= MEDYAN.ForceEnergyFloat64(length(x))
                MEDYAN.bounding_planes_forces!(force_energy,x,boundingplanes)
                forces= MEDYAN.get_force(force_energy)
                predE= E0 - dot(Δx, (forces0 .+ forces) ./ 2)
                realE= MEDYAN.get_energy(force_energy)
                @test abs(realE-predE)<1E-7
            end
        end
    end
    @testset "capsule forces finite diff" begin
        for i in 1:100
            boundingcapsules= [SA[10*randn(SVector{6,Float64})...,rand()*10,rand()*10] for k in 1:3]
            x0= 20*randn(Float64,3*10)
            force_energy0= MEDYAN.ForceEnergyFloat64(length(x0))
            MEDYAN.bounding_capsules_forces!(force_energy0,x0,boundingcapsules)
            E0= MEDYAN.get_energy(force_energy0)
            forces0= MEDYAN.get_force(force_energy0)
            for j in 1:100
                #choose random deviation
                local Δx= 1E-4 .* randn(Float64,3*10)
                local x= x0 .+ Δx
                force_energy= MEDYAN.ForceEnergyFloat64(length(x))
                MEDYAN.bounding_capsules_forces!(force_energy,x,boundingcapsules)
                forces= MEDYAN.get_force(force_energy)
                predE= E0 - dot(Δx, (forces0 .+ forces) ./ 2)
                realE= MEDYAN.get_energy(force_energy)
                @test abs(realE-predE)<1E-7
            end
        end
    end
    @testset "capsule forces specific example" begin
        forces= zeros(16*3)
        energies= zeros(16)
        k = 2.75
        examplecapsule = [SA[(200x)...,(400y)...,200.0,k]]
        xs = collect([
            -1x;
            401x;
            -1x+200y;
            401x+200y;
            -1x+400y;
            401x+400y;
            200x+601y;
            200x+-201y;
            1x;
            399x;
            1x+200y;
            399x+200y;
            1x+400y;
            399x+400y;
            200x+599y;
            200x+-199y;
        ])
        expectedEs = [
            fill(1//2*k*1^2,8);
            fill(0.0,8)
        ]
        expectedFs = collect([
            k*x;
            -k*x;
            k*x;
            -k*x;
            k*x;
            -k*x;
            -k*y;
            k*y;
            fill(0.0,8*3)
        ])
        force_energy = MEDYAN.ForceEnergyFloat64(length(xs))
        MEDYAN.bounding_capsules_forces!(force_energy, xs, examplecapsule)
        @test expectedFs == MEDYAN.get_force(force_energy)
        @test sum(expectedEs) == MEDYAN.get_energy(force_energy)
    end
end

@testset "set_chemboundary!" begin
    x = SA[1.0,0.0,0.0]
    y = SA[0.0,1.0,0.0]
    z = SA[0.0,0.0,1.0]
    L = 500.0
    diffcoeff = 1.0E6
    s = MEDYAN.SysDef(MEDYAN.AgentNames(
        diffusingspeciesnames= [:a,:b,:c],
    ))
    add_diffusion_coeff!(s, :a, diffcoeff)
    add_diffusion_coeff!(s, :b, diffcoeff)
    add_diffusion_coeff!(s, :c, diffcoeff)
    grid = CubicGrid((3,1,1),L)
    min_compartment_volume_ratio = 1/16
    cinit = MEDYAN.Context(s, grid; 
        min_compartment_volume_ratio,
    )
    full_box = MEDYAN.boundary_box(grid)
    @testset "invvolumes" begin
        c = deepcopy(cinit)
        set_chemboundary!(c, full_box)
        fullvolume = grid.compartmentsize^3
        for cid in 1:length(grid)
            @test 1/c.chemistryengine.invvolumes[cid] ≈ fullvolume rtol=4/(14*14) # edges can be an issue.
        end

        set_chemboundary!(c, MEDYAN.boundary_plane(;normal=x, point=MEDYAN.cornerof(grid)+1100x))
        for cid in 1:2
            @test abs(1/c.chemistryengine.invvolumes[cid] - fullvolume) < 1E-3*fullvolume
        end
        @test abs(1/c.chemistryengine.invvolumes[3] - fullvolume/5) < 1E-3*fullvolume
        
        set_chemboundary!(c, MEDYAN.boundary_plane(;normal=x, point=MEDYAN.cornerof(grid)+(1000+500*min_compartment_volume_ratio-1)x))
        for cid in 1:2
            @test abs(1/c.chemistryengine.invvolumes[cid] - fullvolume) < 1E-3*fullvolume
        end
        @test c.chemistryengine.invvolumes[3] == Inf

        set_chemboundary!(c, MEDYAN.boundary_plane(;normal=x, point=MEDYAN.cornerof(grid)+600x))
        @test abs(1/c.chemistryengine.invvolumes[1] - fullvolume) < 1E-3*fullvolume
        @test abs(1/c.chemistryengine.invvolumes[2] - fullvolume/5) < 1E-3*fullvolume
        @test c.chemistryengine.invvolumes[3] == Inf

        set_chemboundary!(c, MEDYAN.boundary_plane(;normal=x, point=MEDYAN.cornerof(grid)+100x))
        @test abs(1/c.chemistryengine.invvolumes[1] - fullvolume/5) < 1E-3*fullvolume
        @test c.chemistryengine.invvolumes[2] == Inf
        @test c.chemistryengine.invvolumes[3] == Inf

        #corner
        set_chemboundary!(c, 
            MEDYAN.boundary_plane(;normal=x, point=MEDYAN.cornerof(grid)+250x) ∩
            MEDYAN.boundary_plane(;normal=y, point=MEDYAN.cornerof(grid)+250y)
        )
        @test abs(1/c.chemistryengine.invvolumes[1] - fullvolume/4) < 1E-3*fullvolume
        @test c.chemistryengine.invvolumes[2] == Inf
        @test c.chemistryengine.invvolumes[3] == Inf
    end
    @testset "diffusion rates" begin
        c = deepcopy(cinit)
        base_rate = diffcoeff .* L^-2

        set_chemboundary!(c, 
            MEDYAN.boundary_plane(;normal=x, point=MEDYAN.cornerof(grid)+(2L+L/3)*x)
        )
        inrate = c.chemistryengine.diffusionrates[1,1,2]
        outrate = c.chemistryengine.diffusionrates[2,1,3]
        @test inrate/c.chemistryengine.invvolumes[2] ≈ outrate/c.chemistryengine.invvolumes[3]
        @test inrate ≈ base_rate atol=0.01
        @test outrate ≈ 3*inrate atol=0.01

        set_chemboundary!(c, 
            MEDYAN.boundary_plane(;normal=y, point=MEDYAN.cornerof(grid)+(L/2)*y)
        )
        @test c.chemistryengine.diffusionrates[1,1,2] ≈ base_rate atol=0.1
        @test c.chemistryengine.diffusionrates[2,1,3] ≈ base_rate atol=0.1

        set_chemboundary!(c, 
            MEDYAN.boundary_plane(;normal=y, point=MEDYAN.cornerof(grid)+(L/2)*y) ∩
            MEDYAN.boundary_plane(;normal=x, point=MEDYAN.cornerof(grid)+(2L+L/3)*x)
        )
        inrate = c.chemistryengine.diffusionrates[1,1,2]
        outrate = c.chemistryengine.diffusionrates[2,1,3]
        @test inrate/c.chemistryengine.invvolumes[2] ≈ outrate/c.chemistryengine.invvolumes[3]
        @test inrate ≈ base_rate atol=0.1
        @test outrate ≈ 3*inrate atol=0.2

        set_chemboundary!(c, 
            MEDYAN.boundary_plane(;normal=x, point=MEDYAN.cornerof(grid)+(2L+L*min_compartment_volume_ratio-1)*x)
        )
        inrate = c.chemistryengine.diffusionrates[1,1,2]
        @test inrate == 0
    end
    @testset "moving diffusing species" begin
        c = deepcopy(cinit)
        chem_adddiffusingcount!(c,s.diffusing.a,3,2000)
        set_chemboundary!(c, 
            MEDYAN.boundary_plane(;normal=x, point=MEDYAN.cornerof(grid)+(2L+L/3)*x)
        )
        # this should have no effect on diffusing species count.
        @test c.chemistryengine.diffusingcounts[s.diffusing.a,:] == [0, 0, 2000]

        set_chemboundary!(c, 
            MEDYAN.boundary_plane(;normal=x, point=MEDYAN.cornerof(grid)+(2L+L*min_compartment_volume_ratio-1)*x)
        )
        # diffusing species in compartment 3 should be moved to compartment 2.
        @test c.chemistryengine.diffusingcounts[s.diffusing.a,:] == [0, 2000, 0]
    end
    @testset "empty chemboundary" begin
        c = deepcopy(cinit)
        set_chemboundary!(c;)
        @test c.chemistryengine.diffusionrates == cinit.chemistryengine.diffusionrates
        @test c.chemistryengine.invvolumes == cinit.chemistryengine.invvolumes
    end
    @testset "large cylinder chemboundary" begin
        grid = CubicGrid(SA[3,3,3], L)
        c = MEDYAN.Context(s, grid; 
            min_compartment_volume_ratio,
        )
        chemboundary = MEDYAN.boundary_cylinder(;
            center=MEDYAN.centerof(grid),
            axis=SA[0,0,2L],
            radius=1.5L,
        )
        set_chemboundary!(c, chemboundary)
        expectedvolume = π*(1.5L)^2*2L
        @test sum(inv, c.chemistryengine.invvolumes) ≈ expectedvolume rtol=1E-2
    end
end