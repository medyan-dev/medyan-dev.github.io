using MEDYAN
using Test
using StaticArrays


@testset "new random filament" begin
    c, s = MEDYAN.example_actin_mech_context(CubicGrid((2,2,2),500.0))
    for i in 1:100
        fid = newfilament_rand!(c,ones(MEDYAN.MonomerState,100))
        nodes = MEDYAN.fil_node_positions(c, 1, fid)
        @test all(nodes) do pos
            all(<(1000.0),pos) && all(>(0.0),pos)
        end
    end
end
