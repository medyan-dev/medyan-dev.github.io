using MEDYAN
using Test

@testset "CubicGrid" begin
    @testset "grididat" begin
        unitgrid= CubicGrid((1,1,1),2.0)
        @test MEDYAN.grididat(unitgrid,(1.0,1.0,1.0)) == 1
        @test MEDYAN.grididat(unitgrid,(100.0,-1.0,0.1)) == 1
        grid= CubicGrid((3,2,2),2.0)
        @test MEDYAN.grididat(grid,(1.0,1.0,1.0)) == 1
        @test MEDYAN.grididat(grid,(0.0,0.0,0.0)) == 1
        @test MEDYAN.grididat(grid,(0.0,0.0,-1.0)) == 1
        @test MEDYAN.grididat(grid,(2.0,0.0,-1.0)) == 2
        @test MEDYAN.grididat(grid,(4.0,1.0,1.0)) == 3
        @test MEDYAN.grididat(grid,(-4.0,3.0,1.0)) == 4
        @test MEDYAN.grididat(grid,(2.0,3.0,1.0)) == 5
        @test MEDYAN.grididat(grid,(100.0,3.0,1.0)) == 6
        @test MEDYAN.grididat(grid,(100.0,3.0,10.0)) == 12
    end
    @testset "grid_neighbor_ids" begin
        unitgrid= CubicGrid((1,1,1),2.0)
        @test MEDYAN.grid_neighbor_ids(unitgrid,1) == []
        @test_throws BoundsError MEDYAN.grid_neighbor_ids(unitgrid,0)
        @test_throws BoundsError MEDYAN.grid_neighbor_ids(unitgrid,2)
        grid= CubicGrid((3,2,2),2.0)
        @test MEDYAN.grid_neighbor_ids(grid,1) == [2,4,5,7,8,10,11]
        @test MEDYAN.grid_neighbor_ids(grid,2) == [1,3,4,5,6,7,8,9,10,11,12]
    end
end