using MEDYAN
using Test

@testset "CubicGrid" begin
    @testset "grididat" begin
        unitgrid= CubicGrid(SA[1,1,1],2.0)
        c = MEDYAN.cornerof(unitgrid)
        @test c == SA[-1.0,-1,-1]
        @test MEDYAN.grididat(unitgrid, SA[1.0,1.0,1.0]+c) == 1
        @test MEDYAN.grididat(unitgrid, SA[100.0,-1.0,0.1]+c) == 1
        grid = CubicGrid((3,2,2),2.0)
        c = MEDYAN.cornerof(grid)
        @test c == SA[-3.0,-2,-2]
        @test MEDYAN.grididat(grid,SA[1.0,1.0,1.0]+c) == 1
        @test MEDYAN.grididat(grid,SA[0.0,0.0,0.0]+c) == 1
        @test MEDYAN.grididat(grid,SA[0.0,0.0,-1.0]+c) == 1
        @test MEDYAN.grididat(grid,SA[2.0,0.0,-1.0]+c) == 2
        @test MEDYAN.grididat(grid,SA[4.0,1.0,1.0]+c) == 3
        @test MEDYAN.grididat(grid,SA[-4.0,3.0,1.0]+c) == 4
        @test MEDYAN.grididat(grid,SA[2.0,3.0,1.0]+c) == 5
        @test MEDYAN.grididat(grid,SA[100.0,3.0,1.0]+c) == 6
        @test MEDYAN.grididat(grid,SA[100.0,3.0,10.0]+c) == 12
    end
    @testset "grid_neighbor_ids" begin
        unitgrid= CubicGrid((1,1,1),2.0)
        @test MEDYAN.grid_neighbor_ids(unitgrid,1) == []
        @test_throws BoundsError MEDYAN.grid_neighbor_ids(unitgrid,0)
        @test_throws BoundsError MEDYAN.grid_neighbor_ids(unitgrid,2)
        grid= CubicGrid((3,2,2),2.0)
        @test MEDYAN.grid_neighbor_ids(grid,1) == [2,4,5,7,8,10,11]
        @test MEDYAN.grid_neighbor_ids(grid,2) == [1,3,4,5,6,7,8,9,10,11,12]
    end
end