# Test Reference Data
This directory holds data files needed to test MEDYAN, and the data provenance.

## Creating New Reference Data

Create a sub directory of `test/reference-data`, with the name of the data.

In that sub directory open julia and run:
```
pkg> activate .
pkg> add Package1 Package2 ...
```

to create a new environment and add the needed packages.

If you need to use MEDYAN.jl to generate the data, add a specific version to the environment, for example:

```
pkg> add "git@github.com:medyan-dev/MEDYAN.jl.git"#06c3796
```

Where `06c3796` is the commit id you want to use.

Write and run a `script.jl` julia script that will save the data as `out.<extension>` 

The julia script should not depend on anything outside its sub directory. If external data is needed it must be either copied ahead of time, or retrieved from the internet with a stable url.

This is because scripts may take a long time to run, so they are not automatically run on every commit.

Commit the `Manifest.toml`, `Project.toml`, `script.jl`, any other files needed to run the script, and the output data. Documentation should go inside the `script.jl` file. If there are any other steps needed to generate the data, describe them in a `README.md` file.

## Modifying Reference Data

If you modify reference data, make sure to run the julia script before committing.

```sh
julia --project script.jl
```
