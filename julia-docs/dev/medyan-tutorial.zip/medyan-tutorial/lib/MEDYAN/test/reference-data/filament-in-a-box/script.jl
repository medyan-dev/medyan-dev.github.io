"""
Look up table of energy minimized filament in a cube. vs filament length.
The cube is 1000x1000x1000 nm.
The filament is much more bendable than strechable.

Monomer spacing is 2.7 nm

"""

using SmallZarrGroups
using MEDYAN
using StaticArrays
using ProgressMeter
using Random

Random.seed!(1235)

grid = CubicGrid((2,2,2),500.0)
c, s = MEDYAN.example_actin_mech_context(grid; g_tol=1E-5)

monomerspacing= 2.7
NMonomers= round(Int,grid.compartmentsize*grid.n[1]*sqrt(3)/monomerspacing,RoundDown)
monomerstates= ones(UInt8,NMonomers)

fid= MEDYAN.chem_newfilament!(c;
    ftid=1, 
    monomerstates,
    node_mids = [0,],
    nodepositions = [SA[0.0,0.0,0.0], SVector(grid.compartmentsize .* grid.n)],
)

samples= 250
node_pos = SVector{3,Float64}[]
start_nodes = Int[]
num_nodes = Int[]
node_mids = Int[]
@showprogress for i in 1:samples
    #polymerize both ends and then energy minimize
    MEDYAN.chem_polymerize!(c,1,fid,true,0x01)
    MEDYAN.chem_polymerize!(c,1,fid,false,0x01)
    MEDYAN.minimize_energy!(c)
    local p = fil_node_positions(c, s.filament.actin, fid)
    push!(start_nodes, length(node_pos)+1)
    append!(node_pos, p)
    push!(num_nodes, length(p))
    append!(node_mids, fil_node_mon_ids(c, 1, fid))
end

const position_scale = 2
pos_rounder(pos) = convert.(Float32,round.(pos; digits = position_scale, base=2))

data = ZGroup()
data["node_pos"] = pos_rounder(transpose(stack(node_pos)))
data["start_nodes"] = start_nodes
data["num_nodes"] = num_nodes
data["node_mids"] = node_mids

SmallZarrGroups.save_dir("out.zarr.zip", data)
