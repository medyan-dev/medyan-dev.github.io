"""
Look up table of energy minimized filament in a cube. vs filament length.
The cube is 1000x1000x1000 nm.
The filament is much more bendable than strechable.

Monomer spacing is 2.7 nm

"""

using HDF5
using MEDYAN
using StaticArrays
using ProgressMeter

statedef = StateDefinition(
	filamentnames= [(:actin,[
                            :a,
                        ]),
	],
)

grid= CubicGrid((2,2,2),500.0)

boundingplanes = 10.0 .* [SA[-1.0,0.0,0.0,0.0],
    SA[1.0,0.0,0.0,grid.compartmentsize*grid.n[1]],
    SA[0.0,-1.0,0.0,0.0],
    SA[0.0,1.0,0.0,grid.compartmentsize*grid.n[2]],
    SA[0.0,0.0,-1.0,0.0],
    SA[0.0,0.0,1.0,grid.compartmentsize*grid.n[3]]
]

monomerspacing= 2.7

s= SystemDefinitions(statedef)

begin
	NMonomers= round(Int,grid.compartmentsize*grid.n[1]*sqrt(3)/monomerspacing,RoundDown)
	monomerstates= ones(UInt8,NMonomers)
	filamentmechparams= [MEDYAN.FilamentMechParams(
        radius= 3.0,
        spacing= monomerspacing,
        klength= 4000.0,
        kangle= 27000,
        numpercylinder= 40,
    )]
end

c= MEDYAN.Context(s,grid;filamentmechparams,boundingplanes,g_tol=1E-5)
fid= MEDYAN.chem_newfilament!(c;
    ftid= s.filament.actin, 
    monomerstates,
    node_mids = [0,],
    nodepositions = [SA[0.0,0.0,0.0], SVector(grid.compartmentsize .* grid.n)],
)

samples= 1000
beadpositions=[]
node_mids = []
@showprogress for i in 1:samples
    #polymerize both ends and then energy minimize
    MEDYAN.chem_polymerize!(c,s.filament.actin,fid,true,0x01)
    MEDYAN.chem_polymerize!(c,s.filament.actin,fid,false,0x01)
    MEDYAN.minimize_energy!(c)
    f::MEDYAN.FilamentData = c.filamentdata[s.filament.actin][fid]
    nmonomers= length(f.monomerstates)
    push!(
        beadpositions, 
        (nmonomers, get_nodepositions(f), get_node_mids(f))
    )
end

h5open("out.h5", "w") do file
    gnode_pos = create_group(file, "node_pos") # create a group
    gnode_mids = create_group(file, "node_mids") # create a group
    for dataset in beadpositions
        nmonomers= dataset[1]
        positions= dataset[2]
        mids= dataset[3]
        gnode_pos["$nmonomers"] = convert.(Float32,reduce(hcat,positions))
        gnode_mids["$nmonomers"] = mids
    end
end
