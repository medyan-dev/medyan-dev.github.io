using MEDYAN
using Test
using Random

Random.seed!(1234)

include("test_third-party-patches.jl")

include("test_sysdef.jl")

include("test_example_all_sites_context.jl")

include("chem/test_newfilament.jl")
include("chem/test_removefilament.jl")
include("chem/test_depolymerize.jl")
include("chem/test_polymerize.jl")
include("chem/test_setmonomerstate.jl")
include("chem/test_newlink_2mon.jl")
include("chem/test_setlink_2mon_state.jl")
include("test_chem-cache-api.jl")
include("test_sever_filament.jl")

include("membrane/test_halfedgemesh.jl")
include("membrane/test_membraneenergies.jl")
include("membrane/test_membranemesh.jl")
include("membrane/test_membranemeshgeo.jl")
include("membrane/test_membranerdme.jl")
include("membrane/test_meshadapt.jl")
include("membrane/test_meshinit.jl")
include("membrane/test_meshraytracing.jl")
include("membrane/test_trianglebeadvolexcl.jl")

include("filament/test_chem_cylinders.jl")

include("test_forcefields.jl")

include("test_link_2mon_mechanics.jl")

include("test_link_2mon_sites.jl")

include("cadherin/test_cadherinparams.jl")

include("cadherin/test_chem_cadherin.jl")

include("cadherin/test_pickrandomcadherinsite.jl")

include("test_propensitysamplers.jl")
include("test_grids.jl")
include("test_boundary.jl")
include("util/math/test_aabbtree.jl")
include("util/math/test_pathgeometry.jl")
include("util/math/test_cuboidslicing.jl")
include("util/math/test_ray_triangle_intersect.jl")
include("util/test_propdictionary.jl")
include("util/test_stableindex.jl")
include("util/test_validflags.jl")

include("test_context.jl")

include("test_empty-system.jl")

include("test_emptying-context.jl")

include("test_snapshot.jl")

include("test_decimated_2mon_site_managers.jl")

include("test_decimated_2mon_site-cornercase.jl")

include("test_filamentend_reaction.jl")

include("test_filament_reaction.jl")

include("test_filament-drag.jl")

include("test_filament-in-box-mechanics.jl")

include("test_buckling-theory.jl")

include("test_cylinder-volume-exclusion.jl")

include("test_filament-end-load-forces.jl")

include("test_newrandomfilament.jl")

include("test_vectorization.jl")
include("test_neighborlists.jl")
include("test_nearby_monomer_count.jl")
include("test_auxprocs.jl")

include("test_cxx_medyan_files.jl")

include("test_show-sysdef.jl")

include("test_ring-benchmark.jl")