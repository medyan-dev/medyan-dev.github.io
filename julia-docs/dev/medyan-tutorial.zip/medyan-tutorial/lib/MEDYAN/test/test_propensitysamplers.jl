using MEDYAN
using StaticArrays
using Setfield
using Test
using Random
using HypothesisTests
using Distributions
using InteractiveUtils

#all subtypes(MEDYAN.RDMEPropensity) should pass these tests
@testset "$RDMEPropensityType" for RDMEPropensityType in  [MEDYAN.RDMEPropensityRejectDiffusion] #subtypes(MEDYAN.RDMEPropensity)
    @testset "constructor" begin
        RDMEPropensityType{3,3}()
    end
    @testset "empty makestep!" begin
        #create an empty RDMESampler with 3 diffusing species and 4 fixed species
        s= RDMEPropensityType{3,4}()
        reactioninfo= MEDYAN.makestep!(s)
        @test reactioninfo.reactionhappened==false
        reactioninfo= MEDYAN.makestep!(s)
        @test reactioninfo.reactionhappened==false
    end
    @testset "simple bulk reactions" begin
        s= RDMEPropensityType{0,0}()
        #This is used to calculate the propensity
        bulkreactants= [(id=1,amount=1),]
        #This is how bulk species counts get updated when this reaction happens
        bulknet_stoich= [(id=1,amount=-1),]
        rate= 1.5
        reaction= MEDYAN.BulkReaction(bulkreactants,bulknet_stoich,rate)
        initcount= 3
        MEDYAN.addbulkspecies!(s,initcount)
        #because s is a RDMEPropensity it has a total propensity
        @test s isa MEDYAN.RDMEPropensity
        @test MEDYAN.gettotal_a(s) == 0
        reactioninfo= MEDYAN.makestep!(s)
        @test reactioninfo.reactionhappened==false

        #now add the reaction, and total_a should go up
        MEDYAN.addbulkreaction!(s,reaction)
        @test MEDYAN.gettotal_a(s) == 3*1.5
        
        #makestep! modifies s and returns the info about the reaction that happened
        reactioninfo= MEDYAN.makestep!(s)
        @test reactioninfo.reactionhappened==true
        @test reactioninfo.time > 0.0001
        @test reactioninfo.time < 10.0
        @test reactioninfo.info.reactiontype == :bulk
        @test reactioninfo.info.reactionid == 1
        @test s.bulkcounts[1] == 2
        @test MEDYAN.gettotal_a(s) == 2*1.5

        #The bulkcount can be modified using setters
        MEDYAN.setbulkspeciescount!(s,1,10)
        @test s.bulkcounts[1] == 10
        @test MEDYAN.gettotal_a(s) == 10*1.5

        #The following is a statistical test to check the reaction time is Exponential
        trials= 100000
        times= zeros(trials)
        for i in 1:trials
            MEDYAN.setbulkspeciescount!(s,1,10)
            reactioninfo= MEDYAN.makestep!(s)
            times[i]= reactioninfo.time
        end
        t=ApproximateOneSampleKSTest(times,Exponential(1/(10*1.5)))
        @test pvalue(t) > 0.001
    end
    @testset "more complex bulk reactions" begin
        s= RDMEPropensityType{0,0}()
        reaction1= MEDYAN.BulkReaction([(id=1,amount=1),],
                                    [(id=1,amount=-1),],
                                    1.5)
        reaction2= MEDYAN.BulkReaction([(id=2,amount=2),(id=3,amount=1)],
                                    [(id=2,amount=-1),],
                                    6)
        MEDYAN.addbulkspecies!(s,1)
        MEDYAN.addbulkspecies!(s,2)
        #note bulk species don't need integer counts, 
        # just be careful propensity never is negative
        MEDYAN.addbulkspecies!(s,3.5)
        MEDYAN.addbulkreaction!(s,reaction1)
        MEDYAN.addbulkreaction!(s,reaction2)
        @test MEDYAN.gettotal_a(s) == 1*1.5 + 2*1/2*3.5*6
        reactioninfo= MEDYAN.makestep!(s)
        brid= reactioninfo.info.reactionid
        @test reactioninfo.reactionhappened==true
        @test brid == 1 || brid == 2
        if brid==1
            @test s.bulkcounts == [0,2,3.5]
        else
            @test s.bulkcounts == [1,1,3.5]
        end
        reactioninfo2= MEDYAN.makestep!(s)
        brid2= reactioninfo2.info.reactionid
        @test reactioninfo2.reactionhappened==true
        if brid==1
            @test brid2 == 2
        else
            @test brid2 == 1
        end
        @test s.bulkcounts == [0,1,3.5]
        reactioninfo= MEDYAN.makestep!(s)
        @test reactioninfo.reactionhappened==false
        #reset species counts
        MEDYAN.setbulkspeciescount!(s,1,1)

        #If you want to modify the rate of the first reaction there are two options
        #1. replace the reaction.
        MEDYAN.replacebulkreaction!(s,1,@set reaction1.rate=2.5)
        @test MEDYAN.gettotal_a(s) == 1*2.5
        #2. add an extra bulk count to represent the rate and set it
        #This may be faster than replacing the reaction 
        #if the rate changes frequently
        MEDYAN.addbulkspecies!(s,2.5)
        rate1id= length(s.bulkcounts)
        newreaction= MEDYAN.BulkReaction([(id=1,amount=1),(id=rate1id,amount=1)],
                                        [(id=1,amount=-1),],
                                        1.0)
        MEDYAN.replacebulkreaction!(s,1,newreaction)
        @test MEDYAN.gettotal_a(s) == 1*2.5
        MEDYAN.setbulkspeciescount!(s,rate1id,7.25)
        @test MEDYAN.gettotal_a(s) == 1*7.25

        #Statistical test
        trials= 10000
        rcounts=[0,0]
        p1= 1*7.2/(1*7.2 + 2*1/2*3.5*6)
        for i in 1:trials
            MEDYAN.setbulkspeciescount!(s,1,1)
            MEDYAN.setbulkspeciescount!(s,2,2)
            reactioninfo= MEDYAN.makestep!(s)
            rcounts[reactioninfo.info.reactionid] += 1
        end
        @test abs(rcounts[1]/trials - p1) < 0.01
    end
    @testset "removing bulk reactions" begin
        s= RDMEPropensityType{0,0}()
        reaction1= MEDYAN.BulkReaction([(id=1,amount=1),],
                                    [(id=1,amount=-1),],
                                    1.5)
        reaction2= MEDYAN.BulkReaction([(id=2,amount=2),(id=3,amount=1)],
                                    [(id=2,amount=-1),],
                                    6)
        MEDYAN.addbulkspecies!(s,1)
        MEDYAN.addbulkspecies!(s,2)
        #note bulk species don't need integer counts, 
        # just be careful propensity never is negative
        MEDYAN.addbulkspecies!(s,3.5)
        MEDYAN.addbulkreaction!(s,reaction1)
        MEDYAN.addbulkreaction!(s,reaction2)
        #when reaction 1 is removed, reaction 2 becomes 1
        MEDYAN.removebulkreaction!(s,1)
        reactioninfo= MEDYAN.makestep!(s)
        @test reactioninfo.reactionhappened==true
        @test reactioninfo.info.reactionid == 1
        @test s.bulkcounts == [1,1,3.5]
        reactioninfo= MEDYAN.makestep!(s)
        @test reactioninfo.reactionhappened==false
        MEDYAN.removebulkreaction!(s,1)
        @test s.bulkreactions==[]
    end
    @testset "simple diffusion" begin
        #the system has one diffusing species
        s= RDMEPropensityType{1,0}()
        #add one compartment, diffusion rates and counts are zero by default
        MEDYAN.addcompartments!(s,2,1.0)
        @test s.diffusingcounts[1,1] == 0
        @test s.diffusingcounts[1,2] == 0
        reactioninfo= MEDYAN.makestep!(s)
        @test reactioninfo.reactionhappened==false

        #set diffusionrates and neighbors
        # |   1   |   2   |  --> +x
        #note the rate isn't a the diffusion coefficent, 
        #it is the propensity of a jump of a species from one compartment to another.
        MEDYAN.setneighbor!(s,1,1,2)
        MEDYAN.setneighbor!(s,2,2,1)
        MEDYAN.setdiffusionrate!(s,1,1,1,1.5)
        MEDYAN.setdiffusionrate!(s,2,1,2,2.5)

        #use setters to change species counts
        MEDYAN.setdiffusingspeciescount!(s,1,1,1)
        @test MEDYAN.gettotal_a(s) == 1.5

        #makestep! will move the diffusing species back and forth
        reactioninfo= MEDYAN.makestep!(s)
        @test MEDYAN.gettotal_a(s) == 2.5
        @test s.diffusingcounts[1,1] == 0
        @test s.diffusingcounts[1,2] == 1
        @test reactioninfo.reactionhappened == true
        @test reactioninfo.info.reactiontype == :diffusion
        @test reactioninfo.info.diffusingspeciesid == 1
        @test reactioninfo.info.side == 1
        @test reactioninfo.info.compartmentid == 1
        reactioninfo= MEDYAN.makestep!(s)
        @test MEDYAN.gettotal_a(s) == 1.5
        @test s.diffusingcounts[1,1] == 1
        @test s.diffusingcounts[1,2] == 0
        @test reactioninfo.reactionhappened == true
        @test reactioninfo.info.reactiontype == :diffusion
        @test reactioninfo.info.diffusingspeciesid == 1
        @test reactioninfo.info.side == 2
        @test reactioninfo.info.compartmentid == 2
    end
    @testset "A+B-->B; 0->A reaction example" begin
        A = 1
        B = 2
        abreactionid = 1 
        areactionid = 2
        k1= 0.2
        k2= 1.0
        #note there is always exactly 2 diffusing reactants,
        #   if for example 1A was the reactant the input would be (A,0)
        #       2A would be (A,A)
        #       null would be (0,0)
        abreaction= MEDYAN.CompartmentReaction(
            (A,B), #diffusingreactants
            [(id=A, amount=-1)], #diffusingnet_stoich
            [], #fixedreactants
            [], #fixednet_stoich
            [], #bulkreactants
            [], #bulknet_stoich
            k1, #rate
            1, #invvolumepower
        )
        areaction= MEDYAN.CompartmentReaction(
            (0,0), #diffusingreactants
            [(id=A, amount=1)], #diffusingnet_stoich
            [], #fixedreactants
            [], #fixednet_stoich
            [], #bulkreactants
            [], #bulknet_stoich
            k2, #rate
            -1, #invvolumepower
        )
        Adiffusioncoeff= 1.5
        Bdiffusioncoeff= 1.0
        L= 1.0
        K = 4 #length of compartmentgrid in number of compartments
        h = L/K #side length of compartments
        grid= CubicGrid((K,K,K),h)
        diffusioncoeff= [Adiffusioncoeff,Bdiffusioncoeff]
        #system with 2 diffusingspecies
        s= RDMEPropensityType{2,0}()
        MEDYAN.addgrid!(s,grid,diffusioncoeff)
        MEDYAN.addcompartmentreaction!(s,abreaction)
        MEDYAN.addcompartmentreaction!(s,areaction)
        @test MEDYAN.gettotal_a(s) == k2*(h*K)^3
        MEDYAN.setdiffusingspeciescount!(s,B,1,1)
        #Now the only reactions are B diffusing and A spawning
        @test MEDYAN.gettotal_a(s) == Bdiffusioncoeff/h/h*6 + k2*(h*K)^3
        
        #Statistical test of equilibrium
        #warm up
        for i in 1:10000
            MEDYAN.makestep!(s)
        end
        #avg A counts
        samples= 2000
        total_As= zeros(samples)
        Δt = 0.1
        #samples taken every Δt
        for i in 1:samples
            t= Δt
            while t > 0
                t-= MEDYAN.makestep!(s,t).time
            end  
            total_As[i] = sum(s.diffusingcounts[A,:])
        end
        #this correction is from http://stacks.iop.org/PhysBio/6/046001
        #Radek Erban and S Jonathan Chapman 2009 Phys. Biol. 6 046001
        DAB= Adiffusioncoeff + Bdiffusioncoeff
        β= 0.33461
        kabmacro= k1/(β/(DAB*h)*k1+1)
        λ= k2*((h*K)^3)^2/kabmacro/1
        theorydist= Poisson(λ)
        @test abs(mean(total_As) - λ) < 1.5
        variance= mean((total_As .- λ).^2)
        @test abs(variance - λ) < 16.0 
    end
    @testset "compartment reactions are disabled if invvolume is Inf" begin
        A = 1
        B = 2
        abreactionid = 1 
        areactionid = 2
        k1= 0.2
        k2= 1.0
        abreaction= MEDYAN.CompartmentReaction(
            (A,B), #diffusingreactants
            [(id=A, amount=-1)], #diffusingnet_stoich
            [], #fixedreactants
            [], #fixednet_stoich
            [], #bulkreactants
            [], #bulknet_stoich
            k1, #rate
            1, #invvolumepower
        )
        areaction= MEDYAN.CompartmentReaction(
            (0,0), #diffusingreactants
            [(id=A, amount=1)], #diffusingnet_stoich
            [], #fixedreactants
            [], #fixednet_stoich
            [], #bulkreactants
            [], #bulknet_stoich
            k2, #rate
            -1, #invvolumepower
        )
        Adiffusioncoeff= 1.5
        Bdiffusioncoeff= 1.0
        L= 1.0
        K = 4 #length of compartmentgrid in number of compartments
        h = L/K #side length of compartments
        grid= CubicGrid((K,K,K),h)
        diffusioncoeff= [Adiffusioncoeff,Bdiffusioncoeff]
        #system with 2 diffusingspecies
        s= RDMEPropensityType{2,0}()
        MEDYAN.addgrid!(s,grid,diffusioncoeff)
        MEDYAN.addcompartmentreaction!(s,abreaction)
        MEDYAN.addcompartmentreaction!(s,areaction)
        @test MEDYAN.gettotal_a(s) == k2*(h*K)^3
        MEDYAN.setdiffusingspeciescount!(s,B,1,1)
        MEDYAN.setdiffusingspeciescount!(s,A,1,1)
        @test MEDYAN.gettotal_a(s) ≈ Bdiffusioncoeff/h/h*6 + k2*(h*K)^3 + Adiffusioncoeff/h/h*6 + k1*(h)^-3
        MEDYAN.setinvvolume!(s,1,Inf)
        #this disables compartment reactions in cid 1, but has no effect on diffusion reactions
        @test MEDYAN.gettotal_a(s) ≈ Bdiffusioncoeff/h/h*6 + k2*(h)^3*((K)^3-1) + Adiffusioncoeff/h/h*6
    end
    @testset "A+Bn-->Bn+1; 0->A teleporting B example" begin
        # This is an example of a more complex system uses all three types of species.
        # When an A reacts with B, B's internal state increments
        # The reaction rate of A + Bn is k1/n
        # B teleports to random compartments at a fixed rate
        # When B teleports to compartment 1 its state becomes 1
        # B is too complex to be efficently represented as diffusing species
        # so B's state will be managed external to the RDMESampler
        #diffusing species ids
        A = 1

        #fixed species ids
        Beffective = 1

        #bulk species ids
        Bteleport= 1

        abreactionid = 1 
        areactionid = 2
        k1= 0.2
        k2= 1.0
        abreaction= MEDYAN.CompartmentReaction(
            (A,0), #diffusingreactants
            [(id=A, amount=-1)], #diffusingnet_stoich
            [(id=Beffective, amount=1)], #fixedreactants
            [], #fixednet_stoich
            [], #bulkreactants
            [], #bulknet_stoich
            k1, #rate
            1, #invvolumepower
        )
        areaction= MEDYAN.CompartmentReaction(
            (0,0), #diffusingreactants
            [(id=A, amount=1)], #diffusingnet_stoich
            [], #fixedreactants
            [], #fixednet_stoich
            [], #bulkreactants
            [], #bulknet_stoich
            k2, #rate
            -1, #invvolumepower
        )
        bteleportreaction= MEDYAN.BulkReaction(
            [(id= Bteleport, amount= 1)],
            [],
            1.0)
        Adiffusioncoeff= 1.5
        Bteleportrate= 0.5
        L= 1.0
        K = 4 #length of compartmentgrid in number of compartments
        h = L/K #side length of compartments
        grid= CubicGrid((K,K,K),h)
        diffusioncoeff= [Adiffusioncoeff]
        #system with 1 diffusing species and 1 fixed species
        s= RDMEPropensityType{1,1}()
        MEDYAN.addbulkspecies!(s,Bteleportrate)
        MEDYAN.addbulkreaction!(s,bteleportreaction)
        MEDYAN.addgrid!(s,grid,diffusioncoeff)
        MEDYAN.addcompartmentreaction!(s,abreaction)
        MEDYAN.addcompartmentreaction!(s,areaction)
        @test MEDYAN.gettotal_a(s) == k2*(h*K)^3 + Bteleportrate

        #add in B
        # state, compartment id
        Bstate= ones(Int,2)
        MEDYAN.addfixedspeciescount!(s,Beffective,Bstate[2],1/Bstate[1])

        #do a sim
        Δt = 0.1
        #samples taken every Δt
        samples= 50
        rdme_states= Vector{typeof(s)}(undef,samples)
        for i in 1:samples
            t= Δt
            while t > 0
                rinfo= MEDYAN.makestep!(s,t)
                t-= rinfo.time
                if rinfo.info.reactiontype == :bulk 
                    if rinfo.info.reactionid == 1
                        #do B teleport reaction
                        newBcompartmentid= rand(1:length(grid))
                        #remove B from old compartment
                        MEDYAN.addfixedspeciescount!(s,Beffective,Bstate[2],-1/Bstate[1])
                        #check if new compartment id is 1 if it is reset state
                        if newBcompartmentid==1
                            Bstate= 1
                        end
                        Bstate[2]= newBcompartmentid
                        #add B to new compartment
                        MEDYAN.addfixedspeciescount!(s,Beffective,Bstate[2],1/Bstate[1])
                    end
                elseif rinfo.info.reactiontype == :compartment
                    if rinfo.info.reactionid == abreactionid
                        MEDYAN.addfixedspeciescount!(s,Beffective,Bstate[2],-1/Bstate[1])
                        Bstate[1]+=1
                        MEDYAN.addfixedspeciescount!(s,Beffective,Bstate[2],1/Bstate[1])
                    end
                end
            end
            rdme_states[i] = deepcopy(s)
        end
    end
end