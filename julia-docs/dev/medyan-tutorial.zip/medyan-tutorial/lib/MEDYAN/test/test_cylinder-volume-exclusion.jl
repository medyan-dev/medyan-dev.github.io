using MEDYAN
using Test
using StaticArrays
using LinearAlgebra

@testset "Cylinder volume exclusion" begin
    x = SA[1.0,0.0,0.0]
    y = SA[0.0,1.0,0.0]
    z = SA[0.0,0.0,1.0]
    monomerspacing = 2.5
    filamentmechparams= MEDYAN.FilamentMechParams(
            radius= 3.0,
            spacing= monomerspacing,
            klength= 40000.0,
            kangle= 20000.0,
            numpercylinder= 40,
            max_num_unmin_end= 1000,
    )
    grid = CubicGrid((1, 1, 1), 500.0)
    @testset "Filament cylinder volume exclusion same filament types: $sameft, skin_radius: $skin_radius" for sameft in (true,false), skin_radius in (1.0,10.0,100.0)
        agent_names = MEDYAN.AgentNames(
            filamentnames = [
                (:a, [
                    :a,
                ]),
                (:b, [
                    :a,
                ]),
            ],
            link_2mon_names = [:restraint,:no_collide]
        )
        s= MEDYAN.SysDef(agent_names)
        add_filament_params!(s, :a, filamentmechparams)
        add_filament_params!(s, :b, filamentmechparams)
        #define restraints
        add_link_2mon!(s,
            :restraint,
            Link2MonState((;),(mr0 = zero(SVector{3,Float64}),mv̂0 = zero(SVector{3,Float64}))),
            MEDYAN.RestraintMechParams(kr=0.1,kv̂=0.0),
        )
        add_link_2mon!(s,
            :no_collide,
            Link2MonState(),
            nothing;
            no_collide=true,
        )
        # Set up two filaments perpendicular, and pulled to try and pass though each other.
        NMonomers= 100
        monomerstates= ones(UInt8,NMonomers)
        nodepositions1 = [SA[125.0, 250.0, 260.0],
                          SA[125.0 + NMonomers*monomerspacing, 250.0, 260.0]]
        nodepositions2 = [SA[250.0, 125.0, 250.0],
                          SA[250.0, 125.0 + NMonomers*monomerspacing, 250.0]]
        cinit = MEDYAN.Context(
            s,grid;
            cylinder_skin_radius=skin_radius,
            check_neighborlist_error=true,
        )
        set_mechboundary!(cinit, MEDYAN.boundary_box(grid; stiffness=0.01^2))
        ftid1 = 1
        fid1 = MEDYAN.chem_newfilament!(cinit;
            ftid= ftid1, 
            monomerstates,
            node_mids = [0,],
            nodepositions = nodepositions1,
        )
        ftid2 = sameft ? 1 : 2
        fid2 = MEDYAN.chem_newfilament!(cinit;
            ftid= ftid2, 
            monomerstates,
            node_mids = [0,],
            nodepositions = nodepositions2,
        )
        MEDYAN.chem_newlink_2mon!(cinit,
            s.link_2mon.restraint,#ltid 
            MonomerName(ftid1, fid1, 0)=>
            MonomerName(ftid1, fid1, 0);
            changedmechstate = (mr0 = mon_position(cinit, MonomerName(ftid1, fid1, 0)) - 30z, mv̂0 = x),
        )
        MEDYAN.chem_newlink_2mon!(cinit,
            s.link_2mon.restraint,#ltid 
            MonomerName(ftid1, fid1, NMonomers-1)=>
            MonomerName(ftid1, fid1, NMonomers-1);
            changedmechstate = (mr0 = mon_position(cinit, MonomerName(ftid1, fid1, NMonomers-1)) - 30z, mv̂0 = x),
        )
        MEDYAN.chem_newlink_2mon!(cinit,
            s.link_2mon.restraint,#ltid 
            MonomerName(ftid2, fid2, 0)=>
            MonomerName(ftid2, fid2, 0);
            changedmechstate = (mr0 = mon_position(cinit, MonomerName(ftid2, fid2, 0)) + 30z, mv̂0 = y),
        )
        MEDYAN.chem_newlink_2mon!(cinit,
            s.link_2mon.restraint,#ltid 
            MonomerName(ftid2, fid2, NMonomers-1)=>
            MonomerName(ftid2, fid2, NMonomers-1);
            changedmechstate = (mr0 = mon_position(cinit, MonomerName(ftid2, fid2, NMonomers-1)) + 30z, mv̂0 = y),
        )
        @testset "Filaments can't clip" begin
            c = deepcopy(cinit)
            MEDYAN.minimize_energy!(c)
            #check that fid1 is at some point above fid2.
            isabove = false
            for pos1 in fil_node_positions(c, ftid1, fid1)
                for pos2 in fil_node_positions(c, ftid2, fid2)
                    if pos1[3] > pos2[3]
                        isabove = true
                    end
                end
            end
            @test isabove
        end
        @testset "Filaments can clip if enable_cylinder_volume_exclusion is false" begin
            c = deepcopy(cinit)
            set_enable_cylinder_volume_exclusion!(c,false)
            MEDYAN.minimize_energy!(c)
            #check that fid1 is not at some point above fid2.
            isabove = false
            for pos1 in fil_node_positions(c, ftid1, fid1)
                for pos2 in fil_node_positions(c, ftid2, fid2)
                    if pos1[3] > pos2[3]
                        isabove = true
                    end
                end
            end
            @test !isabove
        end
        @testset "Filaments  with no_collide link_2mons can clip" begin
            c = deepcopy(cinit)
            MEDYAN.chem_newlink_2mon!(c,
                s.link_2mon.no_collide,#ltid 
                MonomerName(ftid1, fid1, NMonomers÷2)=>
                MonomerName(ftid2, fid2, NMonomers÷2),
            )
            MEDYAN.minimize_energy!(c)
            #check that fid1 is not at some point above fid2.
            isabove = false
            for pos1 in fil_node_positions(c, ftid1, fid1)
                for pos2 in fil_node_positions(c, ftid2, fid2)
                    if pos1[3] > pos2[3]
                        isabove = true
                    end
                end
            end
            @test !isabove
        end
    end
    @testset "Filament cylinder volume exclusion filament ends" begin
        # Set up two fixed parallel filaments, and push another filament against them.
        agent_names = MEDYAN.AgentNames(
            filamentnames = [
                (:a, [
                    :a,
                ]),
            ],
            link_2mon_names = [:restraint,:constforce]
        )
        s= MEDYAN.SysDef(agent_names)
        #define restraints
        add_link_2mon!(s,
            :restraint,
            Link2MonState((;),(mr0 = zero(SVector{3,Float64}),mv̂0 = zero(SVector{3,Float64}))),
            MEDYAN.RestraintMechParams(kr=100.0,kv̂=0.0),
            no_collide=true,
        )
        add_link_2mon!(s,
            :constforce,
            Link2MonState((;),(f=zeros(3),)),
            MEDYAN.ConstantForceMechParams(),
        )
        
        NMonomers= 100
        base_length = NMonomers*monomerspacing
        monomerstates= ones(UInt8,NMonomers)
        monomerpositions1= [SVector{3,Float64}(x,253.0,250.0) for x in range(250.0-base_length/2;length=NMonomers,step=monomerspacing)]
        nodepositions1 = [SA[250.0-base_length/2,253.0,250.0],SA[250.0+base_length/2,253.0,250.0]]
        nodepositions2= nodepositions1 .- (6y,)
        add_filament_params!(s, :a, MEDYAN.FilamentMechParams(
            radius= 3.0,
            spacing= monomerspacing,
            klength= 40000.0,
            kangle= 20000.0,
            numpercylinder= NMonomers, #just want one cylinder per filament
            max_num_unmin_end= 1000,
        ))

        cinit = MEDYAN.Context(
            s,grid;
            check_neighborlist_error=true,
            g_tol=1E-5
        )
        set_mechboundary!(cinit, MEDYAN.boundary_box(grid; stiffness=0.01^2))
        fid1 = MEDYAN.chem_newfilament!(cinit;
            ftid= 1, 
            monomerstates,
            node_mids= [0,],
            nodepositions= nodepositions1,
        )
        fid2 = MEDYAN.chem_newfilament!(cinit;
            ftid= 1, 
            monomerstates,
            node_mids= [0,],
            nodepositions= nodepositions2,
        )
        MEDYAN.chem_newlink_2mon!(cinit,
            s.link_2mon.restraint,#ltid 
            MonomerName(1, fid1, 0)=>
            MonomerName(1, fid2, 0);
            changedmechstate = (mr0 = mon_position(cinit, MonomerName(1, fid1, 0)), mv̂0 = x),
        )
        MEDYAN.chem_newlink_2mon!(cinit,
            s.link_2mon.restraint,#ltid 
            MonomerName(1, fid1, NMonomers-1)=>
            MonomerName(1, fid2, NMonomers-1);
            changedmechstate = (mr0 = mon_position(cinit, MonomerName(1, fid1, NMonomers-1)), mv̂0 = x),
        )
        MEDYAN.chem_newlink_2mon!(cinit,
            s.link_2mon.restraint,#ltid 
            MonomerName(1, fid2, 0)=>
            MonomerName(1, fid1, 0);
            changedmechstate = (mr0 = mon_position(cinit, MonomerName(1, fid2, 0)), mv̂0 = x),
        )
        MEDYAN.chem_newlink_2mon!(cinit,
            s.link_2mon.restraint,#ltid 
            MonomerName(1, fid2, NMonomers-1)=>
            MonomerName(1, fid1, NMonomers-1);
            changedmechstate = (mr0 = mon_position(cinit, MonomerName(1, fid2, NMonomers-1)), mv̂0 = x),
        )
        @testset "Filaments can't clip when the force is at the filament end" begin
            c = deepcopy(cinit)
            nmons = 20
            fid3 = MEDYAN.chem_newfilament!(c;
                ftid= 1, 
                monomerstates= ones(UInt8,nmons),
                node_mids= [1,],
                nodepositions = [SA[250.0,250.0,270.0], SA[250.0,250.0,270.0+nmons*monomerspacing]],
            )
            #down force
            MEDYAN.chem_newlink_2mon!(c,
                s.link_2mon.constforce,#ltid 
                MonomerName(1, fid3, 1)=>
                MonomerName(1, fid3, 1);
                changedmechstate = (f=-1.0*z,),
            )
            #up force to keep the cylinder aligned with the z axis
            MEDYAN.chem_newlink_2mon!(c,
                s.link_2mon.constforce,#ltid 
                MonomerName(1, fid3, nmons)=>
                MonomerName(1, fid3, nmons);
                changedmechstate = (f=0.9*z,),
            )
            MEDYAN.minimize_energy!(c)
            #check that fid3 always is above fid1.
            isabove = true
            for pos3 in fil_node_positions(c, 1, fid3)
                for pos1 in fil_node_positions(c, 1, fid1)
                    if pos3[3] < pos1[3]
                        isabove = false
                    end
                end
            end
            @test isabove
            #check that fid3 is aligned with the z axis mostly
            pos3_1 = fil_node_positions(c, 1, fid3)[1]
            pos3_2 = fil_node_positions(c, 1, fid3)[2]
            @test norm(normalize(pos3_2 - pos3_1) - z) < 1E-2
            #check that fid3 starts at the spot between fid1 and fid2
            @test abs(pos3_1[1] - 250) < 1.0
            @test abs(pos3_1[2] - 250) < 1E-2
            @test abs(pos3_1[3] - (250+3*√(3))) < 0.2
        end
        @testset "Filaments can't clip when parallel" begin
            c = deepcopy(cinit)
            nmons = 10
            fid3 = MEDYAN.chem_newfilament!(c;
                ftid= 1, 
                monomerstates= ones(UInt8,nmons),
                node_mids= [1,],
                nodepositions = [SA[250.0,250.0,270.0], SA[250.0+nmons*monomerspacing,250.0,270.0]],
            )
            #down force on both ends of fid3
            MEDYAN.chem_newlink_2mon!(c,
                s.link_2mon.constforce,#ltid 
                MonomerName(1, fid3, 1)=>
                MonomerName(1, fid3, 1);
                changedmechstate = (f=-0.01*z,),
            )
            MEDYAN.chem_newlink_2mon!(c,
                s.link_2mon.constforce,#ltid 
                MonomerName(1, fid3, nmons)=>
                MonomerName(1, fid3, nmons);
                changedmechstate = (f=-0.01*z,),
            )
            MEDYAN.minimize_energy!(c)
            #check that fid3 always is above fid1.
            isabove = true
            for pos3 in fil_node_positions(c, 1, fid3)
                for pos1 in fil_node_positions(c, 1, fid1)
                    if pos3[3] < pos1[3]
                        isabove = false
                    end
                end
            end
            @test isabove
            #check that fid3 is aligned with the x axis mostly
            pos3_1 = fil_node_positions(c, 1, fid3)[1]
            pos3_2 = fil_node_positions(c, 1, fid3)[2]
            @test norm(normalize(pos3_2 - pos3_1) - x) < 1E-4
            #check that fid3 is in the spot between fid1 and fid2
            @test abs(pos3_1[3] - (250+3*√(3))) < 0.002
        end
    end
    @testset "Filament cylinder volume exclusion warning" begin
        # If two cylinders are closer than the minimum distance, 
        # then a helpful warning should be printed
        c,s = MEDYAN.example_actin_mech_context(grid)
        monomerstates = ones(MonomerState, 20)
        nodepos1 = [10x + 10y + 10z, 50x + 10y + 10z]
        nodepos2 = [10x + 10y + 9.9z, 50x + 10y + 10.2z]
        fid1 = chem_newfilament!(c;
            monomerstates,
            nodepositions = nodepos1,
            node_mids = [0,],
        )
        fid2 = chem_newfilament!(c;
            monomerstates,
            nodepositions = nodepos2,
            node_mids = [0,],
        )
        @test_logs (:warn,) match_mode=:any MEDYAN.minimize_energy!(c)
    end
end