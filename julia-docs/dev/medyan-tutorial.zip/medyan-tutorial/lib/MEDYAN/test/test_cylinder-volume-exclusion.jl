using MEDYAN
using MEDYAN: FilaMonoIdx, get_position, fila_node_positions
using Test
using StaticArrays
using LinearAlgebra

@testset "Cylinder volume exclusion" begin
    x = SA[1.0,0.0,0.0]
    y = SA[0.0,1.0,0.0]
    z = SA[0.0,0.0,1.0]
    monomerspacing = 2.5
    filamentmechparams= MEDYAN.FilamentMechParams(
            radius= 3.0,
            spacing= monomerspacing,
            klength= 40000.0,
            kangle= 20000.0,
            numpercylinder= 40,
            max_num_unmin_end= 1000,
    )
    grid = CubicGrid((1, 1, 1), 500.0)
    @testset "Filament cylinder volume exclusion same filament types: $sameft, skin_radius: $skin_radius" for sameft in (true,false), skin_radius in (1.0,10.0,100.0)
        agent_names = MEDYAN.AgentNames(
            filamentnames = [
                (:a, [
                    :a,
                ]),
                (:b, [
                    :a,
                ]),
            ],
        )
        s= MEDYAN.SysDef(agent_names)
        add_filament_params!(s, :a, filamentmechparams)
        add_filament_params!(s, :b, filamentmechparams)
        #define restraints
        MEDYAN.add_link_type!(s;
            name=:restraint,
            description="harmonic position restraint",
            places=[MEDYAN.FilaMonoIdx(),],
            bonds=[MEDYAN.BondConfig(;
                bond=MEDYAN.PositionRestraint(),
                input=(1,),
                param=(;k=0.1),
                state=(;r0=SA[NaN,NaN,NaN]),
            )]

        )
        MEDYAN.add_link_type!(s;
            name=:no_collide,
            description="test for no collide links",
            places=[FilaMonoIdx(), FilaMonoIdx()],
            bonds=[MEDYAN.BondConfig(;
                bond=MEDYAN.ZeroBond{2}(),
                input=(1,2,),
                no_collide=true,
            )]
        )
        # Set up two filaments perpendicular, and pulled to try and pass though each other.
        NMonomers= 100
        monomerstates= ones(UInt8,NMonomers)
        nodepositions1 = [SA[-125.0, 0.0, 10.0],
                          SA[-125.0 + NMonomers*monomerspacing, 0.0, 10.0]]
        nodepositions2 = [SA[0.0, -125.0, 0.0],
                          SA[0.0, -125.0 + NMonomers*monomerspacing, 0.0]]
        cinit = MEDYAN.Context(
            s,grid;
            cylinder_skin_radius=skin_radius,
            check_neighborlist_error=true,
        )
        set_mechboundary!(cinit, MEDYAN.boundary_box(grid; stiffness=0.01^2))
        fila_idx1 = MEDYAN.make_fila!(cinit;
            fila_type=:a,
            mono_states=monomerstates,
            node_mids=[0,],
            node_positions=nodepositions1,
        )
        fila_idx2 = MEDYAN.make_fila!(cinit;
            fila_type=sameft ? :a : :b,
            mono_states=monomerstates,
            node_mids=[0,],
            node_positions=nodepositions2,
        )
        MEDYAN.make_link!(cinit;
            link_type=:restraint,
            places=(FilaMonoIdx(cinit, fila_idx1, -),),
            bond_states=((;r0=get_position(cinit, FilaMonoIdx(cinit, fila_idx1, -)) - 30z),)
        )
        MEDYAN.make_link!(cinit;
            link_type=:restraint,
            places=(FilaMonoIdx(cinit, fila_idx1, +),),
            bond_states=((;r0=get_position(cinit, FilaMonoIdx(cinit, fila_idx1, +)) - 30z),)
        )
        MEDYAN.make_link!(cinit;
            link_type=:restraint,
            places=(FilaMonoIdx(cinit, fila_idx2, -),),
            bond_states=((;r0=get_position(cinit, FilaMonoIdx(cinit, fila_idx2, -)) + 30z),)
        )
        MEDYAN.make_link!(cinit;
            link_type=:restraint,
            places=(FilaMonoIdx(cinit, fila_idx2, +),),
            bond_states=((;r0=get_position(cinit, FilaMonoIdx(cinit, fila_idx2, +)) + 30z),)
        )
        @testset "Filaments can't clip" begin
            c = deepcopy(cinit)
            MEDYAN.minimize_energy!(c)
            #check that filament 1 is at some point above filament 2.
            isabove = false
            for pos1 in fila_node_positions(c, fila_idx1)
                for pos2 in fila_node_positions(c, fila_idx2)
                    if pos1[3] > pos2[3]
                        isabove = true
                    end
                end
            end
            @test isabove
        end
        @testset "Filaments can clip if enable_cylinder_volume_exclusion is false" begin
            c = deepcopy(cinit)
            set_enable_cylinder_volume_exclusion!(c, false)
            MEDYAN.minimize_energy!(c)
            #check that fid1 is not at some point above fid2.
            isabove = false
            for pos1 in fila_node_positions(c, fila_idx1)
                for pos2 in fila_node_positions(c, fila_idx2)
                    if pos1[3] > pos2[3]
                        isabove = true
                    end
                end
            end
            @test !isabove
        end
        @testset "Filaments  with no_collide bonds can clip" begin
            c = deepcopy(cinit)
            MEDYAN.make_link!(c;
                link_type=:no_collide,
                places=(
                    FilaMonoIdx(c, fila_idx1, NMonomers÷2),
                    FilaMonoIdx(c, fila_idx2, NMonomers÷2),
                ),
            )
            MEDYAN.minimize_energy!(c)
            #check that filament 1 is not at some point above filament 2.
            isabove = false
            for pos1 in fila_node_positions(c, fila_idx1)
                for pos2 in fila_node_positions(c, fila_idx2)
                    if pos1[3] > pos2[3]
                        isabove = true
                    end
                end
            end
            @test !isabove
        end
    end
    @testset "Filament cylinder volume exclusion filament ends" begin
        # Set up two fixed parallel filaments, and push another filament against them.
        agent_names = MEDYAN.AgentNames(
            filamentnames = [
                (:a, [
                    :a,
                ]),
            ],
        )
        s= MEDYAN.SysDef(agent_names)
        #define restraints
        MEDYAN.add_link_type!(s;
            name=:restraint,
            description="harmonic position restraint and no collide",
            places=[MEDYAN.FilaMonoIdx(), MEDYAN.FilaMonoIdx(),],
            bonds=[
                MEDYAN.BondConfig(;
                    bond=MEDYAN.PositionRestraint(),
                    input=(1,),
                    param=(;k=100.0),
                    state=(;r0=SA[NaN,NaN,NaN]),
                ),
                MEDYAN.BondConfig(;
                    bond=MEDYAN.ZeroBond{2}(),
                    input=(1,2,),
                    no_collide=true,
                ),
            ]
        )
        MEDYAN.add_link_type!(s;
            name=:constforce,
            description="constant force",
            places=[MEDYAN.FilaMonoIdx(),],
            bonds=[
                MEDYAN.BondConfig(;
                    bond=MEDYAN.ConstantForce(),
                    input=(1,),
                    param=(;),
                    state=(;f=SA[NaN,NaN,NaN]),
                ),
            ]
        )

        NMonomers= 100
        base_length = NMonomers*monomerspacing
        monomerstates= ones(UInt8,NMonomers)
        nodepositions1 = [SA[-base_length/2,3.0,0.0],SA[base_length/2,3.0,0.0]]
        nodepositions2= nodepositions1 .- (6y,)
        add_filament_params!(s, :a, MEDYAN.FilamentMechParams(
            radius= 3.0,
            spacing= monomerspacing,
            klength= 40000.0,
            kangle= 20000.0,
            numpercylinder= NMonomers, #just want one cylinder per filament
            max_num_unmin_end= 1000,
        ))

        cinit = MEDYAN.Context(
            s,grid;
            check_neighborlist_error=true,
            g_tol=1E-5
        )
        set_mechboundary!(cinit, MEDYAN.boundary_box(grid; stiffness=0.01^2))
        fila_idx1 = MEDYAN.make_fila!(cinit;
            fila_type=:a,
            mono_states=monomerstates,
            node_mids=[0,],
            node_positions=nodepositions1,
        )
        fila_idx2 = MEDYAN.make_fila!(cinit;
            fila_type=:a,
            mono_states=monomerstates,
            node_mids=[0,],
            node_positions=nodepositions2,
        )
        MEDYAN.make_link!(cinit;
            link_type=:restraint,
            places=(
                FilaMonoIdx(cinit, fila_idx1, -),
                FilaMonoIdx(cinit, fila_idx2, -),
            ),
            bond_states=((;r0=get_position(cinit, FilaMonoIdx(cinit, fila_idx1, -))),(;))
        )
        MEDYAN.make_link!(cinit;
            link_type=:restraint,
            places=(
                FilaMonoIdx(cinit, fila_idx1, +),
                FilaMonoIdx(cinit, fila_idx2, +),
            ),
            bond_states=((;r0=get_position(cinit, FilaMonoIdx(cinit, fila_idx1, +))),(;))
        )
        MEDYAN.make_link!(cinit;
            link_type=:restraint,
            places=(
                FilaMonoIdx(cinit, fila_idx2, -),
                FilaMonoIdx(cinit, fila_idx1, -),
            ),
            bond_states=((;r0=get_position(cinit, FilaMonoIdx(cinit, fila_idx2, -))),(;))
        )
        MEDYAN.make_link!(cinit;
            link_type=:restraint,
            places=(
                FilaMonoIdx(cinit, fila_idx2, +),
                FilaMonoIdx(cinit, fila_idx1, +),
            ),
            bond_states=((;r0=get_position(cinit, FilaMonoIdx(cinit, fila_idx2, +))),(;))
        )
        @testset "Filaments can't clip when the force is at the filament end" begin
            c = deepcopy(cinit)
            nmons = 20
            fila_idx3 = MEDYAN.make_fila!(c;
                fila_type=:a,
                mono_states=ones(UInt8,nmons),
                node_mids=[1,],
                node_positions=[SA[0.0,0.0,20.0], SA[0.0,0.0,20.0+nmons*monomerspacing]],
            )
            #down force
            MEDYAN.make_link!(c;
                link_type=:constforce,
                places=(FilaMonoIdx(c, fila_idx3, -),),
                bond_states=((;f=-1.0*z),)
            )
            #up force to keep the cylinder aligned with the z axis
            MEDYAN.make_link!(c;
                link_type=:constforce,
                places=(FilaMonoIdx(c, fila_idx3, +),),
                bond_states=((;f=0.9*z),)
            )
            MEDYAN.minimize_energy!(c)
            #check that fid3 always is above fid1.
            isabove = true
            for pos3 in fila_node_positions(c, fila_idx3)
                for pos1 in fila_node_positions(c, fila_idx1)
                    if pos3[3] < pos1[3]
                        isabove = false
                    end
                end
            end
            @test isabove
            #check that fid3 is aligned with the z axis mostly
            pos3_1 = fila_node_positions(c, fila_idx3)[1]
            pos3_2 = fila_node_positions(c, fila_idx3)[2]
            @test norm(normalize(pos3_2 - pos3_1) - z) < 1E-2
            #check that fid3 starts at the spot between fid1 and fid2
            @test abs(pos3_1[1]) < 1.0
            @test abs(pos3_1[2]) < 1E-2
            @test abs(pos3_1[3] - (3*√(3))) < 0.2
        end
        @testset "Filaments can't clip when parallel" begin
            c = deepcopy(cinit)
            nmons = 10
            fila_idx3 = MEDYAN.make_fila!(c;
                fila_type=:a,
                mono_states=ones(UInt8,nmons),
                node_mids=[1,],
                node_positions=[SA[0.0,0.0,20.0], SA[0.0+nmons*monomerspacing,0.0,20.0]],
            )
            #down force on both ends of fid3
            MEDYAN.make_link!(c;
                link_type=:constforce,
                places=(FilaMonoIdx(c, fila_idx3, -),),
                bond_states=((;f=-0.01*z),)
            )
            MEDYAN.make_link!(c;
                link_type=:constforce,
                places=(FilaMonoIdx(c, fila_idx3, +),),
                bond_states=((;f=-0.01*z),)
            )
            MEDYAN.minimize_energy!(c)
            #check that fid3 always is above fid1.
            isabove = true
            for pos3 in fila_node_positions(c, fila_idx3)
                for pos1 in fila_node_positions(c, fila_idx1)
                    if pos3[3] < pos1[3]
                        isabove = false
                    end
                end
            end
            @test isabove
            #check that fid3 is aligned with the x axis mostly
            pos3_1 = fila_node_positions(c, fila_idx3)[1]
            pos3_2 = fila_node_positions(c, fila_idx3)[2]
            @test norm(normalize(pos3_2 - pos3_1) - x) < 1E-4
            #check that fid3 is in the spot between fid1 and fid2
            @test abs(pos3_1[3] - (3*√(3))) < 0.002
        end
    end
    @testset "Filament cylinder volume exclusion warning" begin
        # If two cylinders are closer than the minimum distance, 
        # then a helpful warning should be printed
        c = MEDYAN.example_actin_mech_context(grid)
        mono_states = ones(MonomerState, 20)
        nodepos1 = [10x + 10y + 10z, 50x + 10y + 10z]
        nodepos2 = [10x + 10y + 9.9z, 50x + 10y + 10.2z]
        fila_idx1 = MEDYAN.make_fila!(c;
            fila_type=:actin,
            mono_states,
            node_positions = nodepos1,
            node_mids = [0,],
        )
        fila_idx2 = MEDYAN.make_fila!(c;
            fila_type=:actin,
            mono_states,
            node_positions = nodepos2,
            node_mids = [0,],
        )
        @test_logs (:warn,) match_mode=:any MEDYAN.minimize_energy!(c)
    end
end