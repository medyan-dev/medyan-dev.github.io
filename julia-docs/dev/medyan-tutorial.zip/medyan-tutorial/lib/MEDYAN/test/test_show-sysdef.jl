using MEDYAN
using Test

@testset "show SysDef" begin
    #This test check show compiles for SysDef
    startc, s, = MEDYAN.example_all_sites_context()
    showouttext = Docs.Text() do io
        show(io, s)
    end
    showoutplain = Docs.Text() do io
        show(io, MIME("text/plain"), s)
    end
end