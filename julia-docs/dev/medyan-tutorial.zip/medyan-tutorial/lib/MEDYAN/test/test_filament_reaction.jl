using MEDYAN
using StaticArrays
using Test

@testset "filament_reaction" begin
    agent_names = MEDYAN.AgentNames(
            filamentnames= [(:a,[
                                :me,
                                :a,
                                :b,
                                :c,
                                :pe,
                            ]),
            ],
        )
    grid= CubicGrid((4,1,1),500.0)
    node_positions = [SA[600.0,200.0,200.0], SA[1300.1,200.0,200.0]] .+ Ref(MEDYAN.cornerof(grid))
    @testset "a to b" begin
        s= MEDYAN.SysDef(agent_names)
        add_filament_params!(s, :a, MEDYAN.UNITY_FIL_PARAMS)
        site= MEDYAN.FilamentSiteGeneral(1,[s.state.a.a,])
        addfilamentsite!(s,:a,:ab,site)
        callback= MEDYAN.GeneralFilamentSiteCallback(
            s.filament.a,
            s.filamentsite.a.ab.id,
            1,
            [s.state.a.b],
            [],
        )
        addreactioncallback!(s, "filamentsite.a.ab",1.75,1,callback)
        nummonomers= 7
        mono_states= zeros(MonomerState,nummonomers)
        mono_states[1]= s.state.a.me
        mono_states[2:end-1].= s.state.a.a
        mono_states[end]= s.state.a.pe
        c= MEDYAN.Context(s,grid)
        make_fila!(c;
            type= :a,
            mono_states,
            node_mids=[1,],
            node_positions,
        )
        @test c.chemistryengine.fixedcounts[1,:] == [0,3,2,0]
        callback(c,1)
        @test c.chemistryengine.fixedcounts[1,:] == [0,3,2,0]
        callback(c,2)
        @test c.chemistryengine.fixedcounts[1,:] == [0,2,2,0]
        callback(c,2)
        @test c.chemistryengine.fixedcounts[1,:] == [0,1,2,0]
        callback(c,2)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,2,0]
        callback(c,2)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,2,0]
        callback(c,2)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,2,0]
        callback(c,3)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,1,0]
        callback(c,3)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,0,0]
    end
    @testset "ba to bb" begin
        s = MEDYAN.SysDef(agent_names)
        add_filament_params!(s, :a, MEDYAN.UNITY_FIL_PARAMS)
        addfilament_reaction!(s,:a,:ba2bb,[:b,:a]=>[:b,:b],2,
        "-->",1.75,0)
        callback = s.compartmentreactioncallbacks[1]
        nummonomers= 7
        mono_states= zeros(MonomerState,nummonomers)
        mono_states[1]= s.state.a.me
        mono_states[2]= s.state.a.b
        mono_states[3:end-1].= s.state.a.a
        mono_states[end]= s.state.a.pe
        c= MEDYAN.Context(s,grid)
        make_fila!(c;
            type= :a,
            mono_states,
            node_mids=[1,],
            node_positions,
        )
        @test c.chemistryengine.fixedcounts[1,:] == [0,1,0,0]
        callback(c,1)
        @test c.chemistryengine.fixedcounts[1,:] == [0,1,0,0]
        callback(c,2)
        @test c.chemistryengine.fixedcounts[1,:] == [0,1,0,0]
        callback(c,2)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,1,0]
        callback(c,3)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,1,0]
        callback(c,3)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,0,0]
    end
end