using MEDYAN
using StaticArrays
using Test

@testset "filament_reaction" begin
    agent_names = MEDYAN.AgentNames(
            filamentnames= [(:a,[
                                :me,
                                :a,
                                :b,
                                :c,
                                :pe,
                            ]),
            ],
        )
    grid= CubicGrid((4,1,1),500.0)
    nodepositions = [SA[600.0,200.0,200.0], SA[1300.1,200.0,200.0]] .+ Ref(MEDYAN.cornerof(grid))
    @testset "a to b" begin
        s= MEDYAN.SysDef(agent_names)
        add_filament_params!(s, :a, MEDYAN.UNITY_FIL_PARAMS)
        site= MEDYAN.FilamentSiteGeneral(1,[s.state.a.a,])
        addfilamentsite!(s,:a,:ab,site)
        callback= MEDYAN.GeneralFilamentSiteCallback(
            s.filament.a,
            s.filamentsite.a.ab.id,
            1,
            [s.state.a.b],
            [],
        )
        addreactioncallback!(s, "filamentsite.a.ab",1.75,1,callback)
        nummonomers= 7
        monomerstates= zeros(MonomerState,nummonomers)
        monomerstates[1]= s.state.a.me
        monomerstates[2:end-1].= s.state.a.a
        monomerstates[end]= s.state.a.pe
        c= MEDYAN.Context(s,grid)
        MEDYAN.chem_newfilament!(c;ftid=s.filament.a,monomerstates,node_mids=[1,],nodepositions,)
        @test c.chemistryengine.fixedcounts[1,:] == [0,3,2,0]
        callback(c,1)
        @test c.chemistryengine.fixedcounts[1,:] == [0,3,2,0]
        callback(c,2)
        @test c.chemistryengine.fixedcounts[1,:] == [0,2,2,0]
        callback(c,2)
        @test c.chemistryengine.fixedcounts[1,:] == [0,1,2,0]
        callback(c,2)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,2,0]
        callback(c,2)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,2,0]
        callback(c,2)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,2,0]
        callback(c,3)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,1,0]
        callback(c,3)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,0,0]
    end
    @testset "ba to bb" begin
        s = MEDYAN.SysDef(agent_names)
        add_filament_params!(s, :a, MEDYAN.UNITY_FIL_PARAMS)
        addfilament_reaction!(s,:a,:ba2bb,[:b,:a]=>[:b,:b],2,
        "-->",1.75,0)
        callback = s.compartmentreactioncallbacks[1]
        nummonomers= 7
        monomerstates= zeros(MonomerState,nummonomers)
        monomerstates[1]= s.state.a.me
        monomerstates[2]= s.state.a.b
        monomerstates[3:end-1].= s.state.a.a
        monomerstates[end]= s.state.a.pe
        c= MEDYAN.Context(s,grid)
        MEDYAN.chem_newfilament!(c;ftid=s.filament.a,monomerstates,node_mids=[1,],nodepositions,)
        @test c.chemistryengine.fixedcounts[1,:] == [0,1,0,0]
        callback(c,1)
        @test c.chemistryengine.fixedcounts[1,:] == [0,1,0,0]
        callback(c,2)
        @test c.chemistryengine.fixedcounts[1,:] == [0,1,0,0]
        callback(c,2)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,1,0]
        callback(c,3)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,1,0]
        callback(c,3)
        @test c.chemistryengine.fixedcounts[1,:] == [0,0,0,0]
    end
end