using MEDYAN
using Test

@testset "Stable index" begin
    SI = MEDYAN.StableIndex

    # Empty structure.
    let si = SI()
        @test isempty(si.indices)
        @test isempty(si.unused_ids)
        @test !haskey(si, 0)
        @test !haskey(si, 1)
        @test length(si) == 0
        @test isempty(si)
        @test_throws BoundsError si[1]
        @test_throws KeyError si[1] = 2000

        # Quasi-empty structure.
        id1 = push!(si, 1001)
        id2 = push!(si, 1002)
        delete!(si, id1)
        delete!(si, id2)
        @test !haskey(si, id1)
        @test !haskey(si, id2)
        @test isempty(si)
        @test_throws KeyError si[1] = 2000
    end

    # Modifications.
    let si = SI()
        id1 = push!(si, 1001)
        @test length(si) == 1
        @test si[id1] == 1001

        si[id1] = 2001
        @test length(si) == 1
        @test si[id1] == 2001

        id2 = push!(si, 1002)
        @test length(si) == 2
        @test si[id1] == 2001
        @test si[id2] == 1002

        delete!(si, id1)
        @test length(si) == 1
        @test !haskey(si, id1)
        @test si[id2] == 1002
        @test_throws KeyError si[id1] = 3001

        id3 = push!(si, 1003)
        @test length(si) == 2
        @test si[id2] == 1002
        @test si[id3] == 1003

        empty!(si)
        @test isempty(si)
        @test !haskey(si, id2)
        @test !haskey(si, id3)
    end

    # Iterations.
    let si = SI()
        push!(si, 1001)
        push!(si, 1002)
        push!(si, 1003)
        push!(si, 1004)
        push!(si, 1005)
        delete!(si, 5)
        delete!(si, 3)
        delete!(si, 1)
        push!(si, 1010)
        expect = [1=>1010, 2=>1002, 4=>1004]
        @test [x for x ∈ si] == expect
        @test map(identity, si) == expect
        @test count(x -> x[1]<3, si) == 2
    end
end