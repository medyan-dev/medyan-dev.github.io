using MEDYAN
using StaticArrays
using Test

@testset "vector swap erase" begin
    swaperase! = MEDYAN.swaperase!
    swaperase_track = MEDYAN.swaperase_track

    @testset "single element erase" begin
        v1 = Float64[1,2,3,4,5,6,7,8,9,10]
        # Remove last element.
        r1 = swaperase!(v1, 10) do ifrom, ito
            # Retargeter should not be invoked.
            @test false
        end
        @test r1.newsize == 9
        @test r1.newindices == SA[0]
        @test v1 == Float64[1,2,3,4,5,6,7,8,9]
        @test swaperase_track(r1, 1, 9) == (1,9)
        # Remove non-last element.
        r2 = swaperase!(v1, 5) do ifrom, ito
            @test ifrom == 9
            @test ito == 5
        end
        @test r2.newsize == 8
        @test r2.newindices == SA[5]
        @test v1 == Float64[1,2,3,4,9,6,7,8]
        @test swaperase_track(r2, 1, 9) == (1,5)
    end
    @testset "multiple element erase" begin
        v1 = Float64[1,2,3,4,5,6,7,8,9,10]
        froms = Int64[]
        tos = Int64[]
        r1 = swaperase!(v1, 6, 2, 8, 10, 4) do ifrom, ito
            push!(froms, ifrom)
            push!(tos, ito)
        end
        @test froms == Int64[7, 9]
        @test tos == Int64[2, 4]
        @test r1.newsize == 5
        @test r1.newindices == SA[0, 2, 0, 4, 0]
        @test v1 == Float64[1, 7, 3, 9, 5]
        @test swaperase_track(r1, 1, 5, 9) == (1,5,4)
    end
end
