using MEDYAN
using StaticArrays
using Test

import MEDYAN: ValidFlags, SBSType, VFS_TEST_1, VFS_TEST_2, VFS_TEST_3

@testset "System consistency validation flags" begin
    vf = ValidFlags()

    @test MEDYAN.checkall(vf, SBSType())
    @test !MEDYAN.checkall(vf, VFS_TEST_1)
    @test !MEDYAN.checkall(vf, VFS_TEST_1 ∪ VFS_TEST_2 ∪ VFS_TEST_3)

    MEDYAN.requireall(vf, SBSType())
    @test_throws ErrorException MEDYAN.requireall(vf, VFS_TEST_1)
    @test_throws ErrorException MEDYAN.requireall(vf, VFS_TEST_1 ∪ VFS_TEST_2 ∪ VFS_TEST_3)

    MEDYAN.set!(vf, VFS_TEST_1)
    @test MEDYAN.checkall(vf, SBSType())
    @test MEDYAN.checkall(vf, VFS_TEST_1)
    @test !MEDYAN.checkall(vf, VFS_TEST_1 ∪ VFS_TEST_2 ∪ VFS_TEST_3)

    MEDYAN.set!(vf, VFS_TEST_2 ∪ VFS_TEST_3)
    @test MEDYAN.checkall(vf, SBSType())
    @test MEDYAN.checkall(vf, VFS_TEST_1)
    @test MEDYAN.checkall(vf, VFS_TEST_1 ∪ VFS_TEST_2 ∪ VFS_TEST_3)

    MEDYAN.unset!(vf, VFS_TEST_1)
    @test MEDYAN.checkall(vf, SBSType())
    @test !MEDYAN.checkall(vf, VFS_TEST_1)
    @test !MEDYAN.checkall(vf, VFS_TEST_1 ∪ VFS_TEST_2 ∪ VFS_TEST_3)
end

@testset "Validation flags in action" begin
    # Membrane with diffusion must update its geometry before running chemistry.
    let
        let
            s = MEDYAN.SysDef(MEDYAN.AgentNames())
            c = MEDYAN.Context(s, MEDYAN.CubicGrid((1,1,1),100);
                membranemechparams = [MEDYAN.MembraneMechParams()],
            )
            newmembrane!(c;
                type = 1,
                meshinit = (;
                    vertlist = [SA[1,0,0], SA[0,1,0], SA[0,0,1]],
                    trilist = [SA[1,2,3]],
                ),
            )

            adapt_membranes!(c)
            # No errors here.
            MEDYAN.run_chemistry!(c, 1.0)
        end
        let
            s = MEDYAN.SysDef(MEDYAN.AgentNames(
                membranediffusingspeciesnames = [:md1],
            ))
            MEDYAN.add_membranediffusion_asbulkreaction!(s)
            membranemechparams = [MEDYAN.MembraneMechParams()]
            membrane_species_params = SA[MEDYAN.MembraneSpeciesParams()]
            let
                c = MEDYAN.Context(s, MEDYAN.CubicGrid((1,1,1),100);
                    membranemechparams,
                    membrane_species_params,
                )
                newmembrane!(c;
                    type = 1,
                    meshinit = (;
                        vertlist = [SA[1,0,0], SA[0,1,0], SA[0,0,1]],
                        trilist = [SA[1,2,3]],
                    ),
                )

                adapt_membranes!(c)
                @test_throws ErrorException MEDYAN.run_chemistry!(c, 1.0)

                compute_all_membrane_geometry!_system(c)
                # No errors here.
                MEDYAN.run_chemistry!(c, 1.0)
            end
            let
                c = MEDYAN.Context(s, MEDYAN.CubicGrid((1,1,1),100);
                    membranemechparams,
                    membrane_species_params,
                    func_membranespeciespotentialenergy = MEDYAN.MembraneSpeciesPotentialEnergy_BendingBashkirov(;
                        params_mech = membranemechparams,
                        params_species = membrane_species_params,
                    ),
                )
                newmembrane!(c;
                    type = 1,
                    meshinit = (;
                        vertlist = [SA[1,0,0], SA[0,1,0], SA[0,0,1]],
                        trilist = [SA[1,2,3]],
                    ),
                )

                adapt_membranes!(c)
                compute_all_membrane_geometry!_system(c)
                # Still errors because ff-based geometry is not updated.
                @test_throws ErrorException MEDYAN.run_chemistry!(c, 1.0)

                compute_all_membrane_geometry!_system(c; include_ff=true)
                # No errors here.
                MEDYAN.run_chemistry!(c, 1.0)
            end
        end
    end
end
