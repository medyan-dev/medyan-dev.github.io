using MEDYAN
using StaticArrays
using Rotations: RotMatrix3
using Test

@testset "kabsch" begin
    @testset "random points" begin
        for i in 1:10
            points = randn(SVector{3,Float64},100) .+ Ref(randn(SVector{3,Float64}))
            rot= rand(RotMatrix3{Float64})
            rotpoints = Ref(rot) .* points
            @test MEDYAN.kabsch_rmsd(points,rotpoints)<1E-10
        end
        for i in 1:10
            points = randn(SVector{3,Float64},100) .+ Ref(randn(SVector{3,Float64}))
            otherpoints = randn(SVector{3,Float64},100) .+ Ref(randn(SVector{3,Float64}))
            @test MEDYAN.kabsch_rmsd(points,otherpoints)>0.5
        end

    end
end

@testset "linesegment_linesegment_dist2" begin
    o = SA[0.0,0.0,0.0]
    x = SA[1.0,0.0,0.0]
    y = SA[0.0,1.0,0.0]
    z = SA[0.0,0.0,1.0]
    @testset "random points" begin
        for i in 1:100
            points = 1E3 .* rand(SVector{3,Float64},4)
            d2 = MEDYAN.linesegment_linesegment_dist2(points...)
            mind,maxd,avgd = MEDYAN.min_max_avg_pathdistance(points[1:2],points[3:4];pointspersegment=100000)
            @test abs(sqrt(d2) - mind) < 1E-3
        end
    end
    @testset "parallel line segments" begin
        @test MEDYAN.linesegment_linesegment_dist2(o,x,o,x) ≈ 0
        @test MEDYAN.linesegment_linesegment_dist2(x,o,o,x) ≈ 0
        @test MEDYAN.linesegment_linesegment_dist2(o,x,x,2x) ≈ 0
        @test MEDYAN.linesegment_linesegment_dist2(o,x,3x,4x) ≈ 4.0
        @test MEDYAN.linesegment_linesegment_dist2(x,o,3x,4x) ≈ 4.0
        @test MEDYAN.linesegment_linesegment_dist2(o,x,-3x,4x) ≈ 0.0
        @test MEDYAN.linesegment_linesegment_dist2(o,x,-3x+y,4x+y) ≈ 1.0
        @test MEDYAN.linesegment_linesegment_dist2(x,o,-3x+y,4x+y) ≈ 1.0
    end
end

@testset "clamp nan" begin
    @test MEDYAN.clamp01nan(NaN32) === 0.0f0
    @test MEDYAN.clamp01nan(0.7f0) === 0.7f0
    @test MEDYAN.clamp01nan(-0.7f0) === 0.0f0
    @test MEDYAN.clamp01nan(Inf32) === 1.0f0

    @test MEDYAN.clamphhnan(0.7f0) === 0.5f0
    @test MEDYAN.clamphhnan(NaN32) === 0.0f0
    @test MEDYAN.clamphhnan(-0.4f0) === -0.4f0
end

