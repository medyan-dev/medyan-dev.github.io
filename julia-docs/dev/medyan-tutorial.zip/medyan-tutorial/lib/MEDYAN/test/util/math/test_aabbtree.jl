using MEDYAN
using MutatePlainDataArray
using StaticArrays
using Test

@testset "AABB tree" begin
    ≊(a,b) = isapprox(a, b; atol=1e-9)

    # Store some 4D spheres.
    Sphere = @NamedTuple{
        c::SVector{4,Float64},
        r::Float64,
    }
    function getspherebox(ss::AbstractVector{Sphere}, i)
        (offset = ss[i].c .- ss[i].r, size = 2*ss[i].r * @SVector(ones(4)))
    end

    spheres = Sphere[
        (c=SA[1,1,1,1], r=3),
        (c=SA[1,1,1,2], r=4),
        (c=SA[1,1,2,3], r=4),
        (c=SA[1,1,2,4], r=4),
        (c=SA[100,1,1,1], r=3),
        (c=SA[100,1,1,2], r=4),
        (c=SA[100,1,1,3], r=1),
    ]

    @testset "Build binary AABB tree" begin

        tree = MEDYAN.build_binary_aabbtree(getspherebox, Sphere[])
        @test isempty(tree)
        @test isempty(MEDYAN.check_binary_aabbtree_consistency(tree))

        tree = MEDYAN.build_binary_aabbtree(getspherebox, spheres)
        @test !isempty(tree)
        @test isempty(MEDYAN.check_binary_aabbtree_consistency(tree))

        # Just to make sure that the check works.
        resize!(tree.nodes, length(tree.nodes)+1)
        @test !isempty(MEDYAN.check_binary_aabbtree_consistency(tree))
        pop!(tree.nodes)

        prev_node1 = tree.nodes[1]
        aref(tree.nodes)[1].offset[] += SA[-1e-3,-1e-3,-1e-3,1e-3]
        @test !isempty(MEDYAN.check_binary_aabbtree_consistency(tree))
        tree.nodes[1] = prev_node1
        aref(tree.nodes)[1].size[] += SA[-1e-3,-1e-3,-1e-3,1e-3]
        @test !isempty(MEDYAN.check_binary_aabbtree_consistency(tree))
        tree.nodes[1] = prev_node1

        @test isempty(MEDYAN.check_binary_aabbtree_consistency(tree))
    end

    @testset "AABB tree ray tracing" begin
        # Record if encountered.
        function doraytracing(data, index, o, d, tinterval, resindices)
            push!(resindices, index)
            resindices
        end

        tree = MEDYAN.build_binary_aabbtree(getspherebox, spheres)

        resindices = MEDYAN.trace_line(doraytracing, tree, SA[50,1,1,1], SA[1,0,0,0], Int[]; tinterval=(0,Inf))
        @test resindices == [5,6]
        resindices = MEDYAN.trace_line(doraytracing, tree, SA[50,1,1,1], SA[-1e6,0,0,0], Int[]; tinterval=(0,Inf))
        @test resindices == [1,2,3,4]
        resindices = MEDYAN.trace_line(doraytracing, tree, SA[50,1,1,1], SA[0,1,0,0], Int[]; tinterval=(0,Inf))
        @test resindices == []
    end

    @testset "Ray-AABB intersection" begin
        aabb = MEDYAN.AABB(SA[0,0,0], SA[1,1,1], 0)

        rayo = SA[1,1,1]/2

        rayinvd = 1 ./ SA[0,0,1]
        @test SVector(MEDYAN.line_intersect(aabb, rayo, rayinvd, (-Inf,Inf))) ≊ SA[-1/2, 1/2]
        @test SVector(MEDYAN.line_intersect(aabb, rayo, rayinvd, (0,Inf))) ≊ SA[0, 1/2]
        @test SVector(MEDYAN.line_intersect(aabb, rayo, rayinvd, (0,1/10))) ≊ SA[0, 1/10]
        @test isnothing(MEDYAN.line_intersect(aabb, rayo, rayinvd, (0,-1/10)))
        rayinvd = 1 ./ SA[0,0,1/2]
        @test SVector(MEDYAN.line_intersect(aabb, rayo, rayinvd, (-Inf,Inf))) ≊ SA[-1, 1]
        @test SVector(MEDYAN.line_intersect(aabb, rayo, rayinvd, (0,Inf))) ≊ SA[0, 1]
        rayinvd = 1 ./ SA[0,1e-6,1]
        @test SVector(MEDYAN.line_intersect(aabb, rayo, rayinvd, (-Inf,Inf))) ≊ SA[-1/2, 1/2]
        @test SVector(MEDYAN.line_intersect(aabb, rayo, rayinvd, (0,Inf))) ≊ SA[0, 1/2]
        rayinvd = 1 ./ SA[1,1,1]
        @test SVector(MEDYAN.line_intersect(aabb, rayo, rayinvd, (-Inf,Inf))) ≊ SA[-1/2, 1/2]
        @test SVector(MEDYAN.line_intersect(aabb, rayo, rayinvd, (0,Inf))) ≊ SA[0, 1/2]

        rayo = SA[0,0,0]

        rayinvd = 1 ./ SA[0,0,1]
        @test SVector(MEDYAN.line_intersect(aabb, rayo, rayinvd, (-Inf,Inf))) ≊ SA[0,1]
        @test SVector(MEDYAN.line_intersect(aabb, rayo, rayinvd, (0,Inf))) ≊ SA[0,1]
        rayinvd = 1 ./ SA[-1,-1,-1]
        @test SVector(MEDYAN.line_intersect(aabb, rayo, rayinvd, (-Inf,Inf))) ≊ SA[-1,0]
        @test SVector(MEDYAN.line_intersect(aabb, rayo, rayinvd, (0,Inf))) ≊ SA[0,0]

        rayo = SA[-1,-1,-1]

        rayinvd = 1 ./ SA[1,1,1]
        @test SVector(MEDYAN.line_intersect(aabb, rayo, rayinvd, (-Inf,Inf))) ≊ SA[1,2]
        @test SVector(MEDYAN.line_intersect(aabb, rayo, rayinvd, (0,Inf))) ≊ SA[1,2]
        @test SVector(MEDYAN.line_intersect(aabb, rayo, rayinvd, (0,1))) ≊ SA[1,1]
        @test isnothing(MEDYAN.line_intersect(aabb, rayo, rayinvd, (0,1-1e-6)))
        rayinvd = 1 ./ SA[0,0,1]
        @test isnothing(MEDYAN.line_intersect(aabb, rayo, rayinvd, (-Inf,Inf)))
        @test isnothing(MEDYAN.line_intersect(aabb, rayo, rayinvd, (0,Inf)))
        rayinvd = 1 ./ SA[-1,-1,-2]
        @test SVector(MEDYAN.line_intersect(aabb, rayo, rayinvd, (-Inf,Inf))) ≊ SA[-1,-1]
        @test isnothing(MEDYAN.line_intersect(aabb, rayo, rayinvd, (0,Inf)))
    end
end