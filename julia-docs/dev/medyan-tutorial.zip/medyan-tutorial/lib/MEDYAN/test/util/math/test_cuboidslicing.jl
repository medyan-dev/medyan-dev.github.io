using MEDYAN
using StaticArrays
using LinearAlgebra
using Test

"""
Most of the following tests are translated from the medyan.cpp file:

 src/TESTS/Util/Math/TestCuboidSlicing.cpp

And were originally written by Haoran Ni (drelatgithub) haoranni@umd.edu
"""

function planeCuboidSlicingResultEqual(r1::MEDYAN.PlaneCuboidSlicingResult, r2::MEDYAN.PlaneCuboidSlicingResult, atol)::Bool
    if !isapprox(r1.volumeIn, r2.volumeIn; atol)
        # @show atol
        # @show isapprox(r1.volumeIn, r2.volumeIn; atol)
        # @show "volume test failed"
        # @show r1,r2
        return false
    end
    if !all(isapprox.(r1.areaIn, r2.areaIn; atol))
        # @show r1,r2
        return false
    end
    return true
end

function planeUnitCubeSliceByIntersection(x, y, z)
    normal = normalize(SA[1/x,1/y,1/z])
    point = SA[x,0.0,0.0]
    MEDYAN.plane_unitcube_slice(point,normal)
end

@testset "plane cuboidslicing" begin
    @testset "Unit cube slicing transition continuity" begin
        """
        Test continuity under different transitions under the simplified
        conditions, i.e. normal has all non-neg components (no normal flip is
        required, however, the reverse might secretly use a whole flip).
        
        Cube slicing result is obtained by calculating intersections on the axes,
        and the formula are different depending on the positions of the
        intersections.
        """
        inEps = 1e-6
        outEps = 1e-5
        
        trialvalues = [0.5, 1.0, 2.0]
        for x in trialvalues, y in trialvalues, z in trialvalues
            r1 = planeUnitCubeSliceByIntersection(x - inEps, y - inEps, z - inEps)
            r2 = planeUnitCubeSliceByIntersection(x + inEps, y + inEps, z + inEps)
            @test planeCuboidSlicingResultEqual(r1, r2, outEps)
        end
        # Check reverse condition
        begin
            r1 = planeUnitCubeSliceByIntersection(1.5 - inEps, 1.5 - inEps, 1.5 - inEps)
            r2 = planeUnitCubeSliceByIntersection(1.5 + inEps, 1.5 + inEps, 1.5 + inEps)
            @test planeCuboidSlicingResultEqual(r1, r2, outEps)
            @test !planeCuboidSlicingResultEqual(r1, r2, inEps * 1e-5) # Check actually changed
        end
    end
    @testset "Unit cube edgecases" begin
        inEps = 1e-7
        volume_outEps = 1e-6
        area_outEps = 1e-6
        # intercepts, volume, area
        # if expected area or volume is NaN, the result passes
        testvalues = [
            ([inEps, inEps, inEps], 0, [0,0,0,0,0,0])
            ([1/inEps, inEps, inEps], 0, [0,0,0,0,0,0])
            ([1/inEps, 1+inEps, inEps], 0, [0,0,0,0,1,0])
            ([1/inEps, 1-inEps, inEps], 0, [0,0,0,0,1,0])
            ([1/inEps, 1, inEps], 0, [0,0,0,0,1,0])
            ([1/inEps, 1, 1], 0.5, [0.5,0.5,1,0,1,0])
            ([1/inEps, 1-inEps, 1-inEps], 0.5, [0.5,0.5,1,0,1,0])
            ([1/inEps, 1+inEps, 1-inEps], 0.5, [0.5,0.5,1,0,1,0])
            ([1/inEps, 1-inEps, 1+inEps], 0.5, [0.5,0.5,1,0,1,0])
            ([1/inEps, 1+inEps, 1+inEps], 0.5, [0.5,0.5,1,0,1,0])
            ([1E100, 1-inEps, 1-inEps], 0.5, [0.5,0.5,1,0,1,0])
            ([1E100, 1+inEps, 1-inEps], 0.5, [0.5,0.5,1,0,1,0])
            ([1E100, 1-inEps, 1+inEps], 0.5, [0.5,0.5,1,0,1,0])
            ([1E100, 1+inEps, 1+inEps], 0.5, [0.5,0.5,1,0,1,0])
            ([1E50, prevfloat(1.0), prevfloat(1.0)], 0.5, [0.5,0.5,1,0,1,0])
            ([1E50, nextfloat(1.0), prevfloat(1.0)], 0.5, [0.5,0.5,1,0,1,0])
            ([1E50, prevfloat(1.0), nextfloat(1.0)], 0.5, [0.5,0.5,1,0,1,0])
            ([1E11, nextfloat(1.0), nextfloat(1.0)], 0.5, [0.5,0.5,1,0,1,0])
            ([1,Inf,1], 0.5, [1,0,0.5,0.5,1,0])
            ([nextfloat(1.0),Inf,nextfloat(1.0)], 0.5, [1,0,0.5,0.5,1,0])
            ([1E100, 1-inEps, 1E100], 1.0, [1,1,1,0,1,1])
            ([1E100, 1+inEps, 1E100], 1.0, [1,1,1,1,1,1])
            ([1E100, 1, 1E100], 1.0, [1,1,1,NaN,1,1])
        ]
        for (intercepts, volume, areas) in testvalues
            r = planeUnitCubeSliceByIntersection(intercepts...)
            @test 0.0 ≤ r.volumeIn ≤ 1.0
            if !isnan(volume)
                @test isapprox(r.volumeIn,volume; atol = volume_outEps)
            end
            for i in 1:6
                @test 0.0 ≤ r.areaIn[i] ≤ 1.0
                if !isnan(areas[i])
                    @test isapprox(r.areaIn[i],areas[i]; atol = area_outEps)
                end
            end
        end
    end
    @testset "Unit cube flipping" begin
        """
        Test the flipping of normal vector and cube
        """
        nVal = 1.0 / sqrt(3)
        pVal = 1.0 / 6.0
        point = SA[pVal, 0, 0]
        normal = SA[nVal, nVal, nVal]
        r1 = MEDYAN.plane_unitcube_slice(point, normal)
        Afull = 1.0
        Asmall = 1//2*(pVal)^2
        Abig = Afull-Asmall
        Vsmall = 1//3 * Asmall * pVal
        expectedareas = repeat([Asmall,0.0]; outer=3)
        @test r1.areaIn ≈ expectedareas
        @test r1.volumeIn ≈ Vsmall
        function flip_point_normal(point,normal,flip)
            local p = [(((flip>>i)&1)%Bool ? 1-point[i+1] : point[i+1]) for i in 0:2]
            local n = [(((flip>>i)&1)%Bool ? -normal[i+1] : normal[i+1]) for i in 0:2]
            p, n
        end
        function flip_areas(areas,flip)
            [areas[i⊻(flip>>(i>>1)&1) + 1] for i in 0:5]
        end
        for flip in 0x00:0x07
            r2 = MEDYAN.plane_unitcube_slice(flip_point_normal(point,normal,flip)...)
            @test r2.volumeIn ≈ Vsmall
            @test r2.areaIn ≈ flip_areas(expectedareas,flip)
        end
    end
    @testset "Cube slicing translation and scaling" begin
        """
        Test slicing some cube with certain position and size
        """
        nVal = 1.0 / sqrt(3)
        pVal = 1.0 / 6.0
        r0Val = 10.0
        s = 2.0
        r = MEDYAN.plane_box_slice(
            [r0Val + s * pVal, r0Val + s * pVal, r0Val + s * pVal],
            [-nVal, -nVal, -nVal],
            [r0Val, r0Val, r0Val],
            s,
        )
        exVolumeIn = 47.0 / 6.0
        exAreaIn = [3.5, 4.0, 3.5, 4.0, 3.5, 4.0]
        @test r.volumeIn ≈ exVolumeIn
        @test r.areaIn ≈ exAreaIn
    end
    @testset "Cuboid slicing transition and scaling" begin
        """
        Test slicing non-cube cuboid
        """
        boxSize = [2.0, 4.0, 1.0]
        normal = [0.0, sqrt(0.5), sqrt(0.5)]
        r0 = [100.0, 100.0, 100.0]
        point = [100.0, 102.0, 100.0]
        r = MEDYAN.plane_box_slice(point, normal, r0, boxSize)
        exVolumeIn = 3.0
        exAreaIn = [1.5, 1.5, 2.0, 0.0, 4.0, 2.0]
        @test r.volumeIn ≈ exVolumeIn
        @test r.areaIn ≈ exAreaIn
    end
end

"""
Added by Nathan Zimmerberg (nhz2)
"""

@testset "function cuboidslicing" begin
    @testset "planecuboidslicing" begin
        """
        Test function_box_slice(f,r0,a) is the same as 
        plane_box_slice(point,normal,r0,a)
        if f(r) = (r ⋅ normal) - (point ⋅ normal)
        """
        volumeEps = 1E-2
        areaEps = 1E-2
        for i in 1:100
            normal = normalize(randn(SVector{3,Float64}))
            point = 2.0*randn(SVector{3,Float64})
            r0 = randn(SVector{3,Float64})
            a = rand(SVector{3,Float64}) .+ 0.1
            f(r) = (r ⋅ normal) - (point ⋅ normal)
            r1 = MEDYAN.function_box_slice(f,r0,a; samples=SA[2,2,2])
            r2 = MEDYAN.plane_box_slice(point,normal,r0,a)
            if !isapprox(r1.volumeIn,r2.volumeIn;atol=volumeEps)
                @show r1.volumeIn
                @show r2.volumeIn
                @test false
            end
            for i in 1:6
                if !isapprox(r1.areaIn[i],r2.areaIn[i];atol=areaEps)
                    @show r1.areaIn
                    @show r2.areaIn
                    @show r0
                    @show a
                    @show normal
                    @show point
                    @test false
                end
            end
            # @test planeCuboidSlicingResultEqual(r1,r2,1E-2)
        end
    end
    @testset "sphere cuboidslicing" begin
        """
        Test function_box_slice(f,r0,a)
        with spheres
        """

        volumeEps = 1E-2
        areaEps = 1E-2

        R = 0.2
        smallsphere(r) = r⋅r - R*R
        tests = [
            # Description         , function      , r0                , a              , volume    , areas 
            ("small sphere inside", smallsphere, SA[-0.5,-0.5,-0.5], SA[1.0,1.0,1.0], 4//3*π*R^3, zeros(6)),
            ("small sphere inside reversed", r -> -smallsphere(r), SA[-0.5,-0.5,-0.5], SA[1.0,1.0,1.0], 1 - 4//3*π*R^3, ones(6)),
            ("small sphere in a side", smallsphere, SA[0.0,-0.5,-0.5], SA[1.0,1.0,1.0], 1//2 * 4//3*π*R^3, [π*R^2,0,0,0,0,0]),
            ("small sphere in a side", smallsphere, SA[0.0,-0.5,-0.5], SA[2.0,1.3,1.7], 1//2 * 4//3*π*R^3, [π*R^2,0,0,0,0,0]),
            ("small sphere far away", smallsphere, SA[-10.0,-0.5,-0.5], SA[1.0,1.0,1.0], 0.0, zeros(6)),
            ("small sphere in an edge", smallsphere, SA[0,0,-0.5], SA[1.0,1.0,1.0], 1//4 * 4//3*π*R^3, [1//2*π*R^2,0,1//2*π*R^2,0,0,0]),
            ("small sphere in an edge", smallsphere, SA[-1.0,-1.0,-0.5], SA[1.0,1.0,1.0], 1//4 * 4//3*π*R^3, [0,1//2*π*R^2,0,1//2*π*R^2,0,0]),
            ("small sphere in a corner", smallsphere, SA[0,0,0.0], SA[1.0,1.0,1.0], 1//8 * 4//3*π*R^3, [1//4*π*R^2,0,1//4*π*R^2,0,1//4*π*R^2,0]),
            ("small sphere in a corner", smallsphere, SA[-1.0,-1.0,-1.0], SA[1.0,1.0,1.0], 1//8 * 4//3*π*R^3, [0,1//4*π*R^2,0,1//4*π*R^2,0,1//4*π*R^2]),
        ]
        for (description, f, r0, a, volume, areas) in tests
            result = MEDYAN.function_box_slice(f,r0,a)
            if !isapprox(result.volumeIn,volume;atol=volumeEps)
                @show description
                @show result.volumeIn
                @show volume
                @test false
            end
            for i in 1:6
                if !isapprox(result.areaIn[i],areas[i];atol=areaEps)
                    @show description
                    @show result.areaIn
                    @show areas
                    @test false
                end
            end
            reversedresult = MEDYAN.function_box_slice(r->(-f(r)),r0,a)
            otherinds = SA[
                SA[2,3],
                SA[3,1],
                SA[1,2],
            ]
            reversedareas = @SVector [prod(a[otherinds[i>>1 + 1]]) - areas[i+1] for i in 0:5]
            reversedvolume = prod(a) - volume
            if !isapprox(reversedresult.volumeIn,reversedvolume;atol=volumeEps)
                @show description
                @show reversedresult.volumeIn
                @show reversedvolume
                @test false
            end
            for i in 1:6
                if !isapprox(reversedresult.areaIn[i],reversedareas[i];atol=areaEps)
                    @show description
                    @show reversedresult.areaIn
                    @show reversedareas
                    @test false
                end
            end
        end
    end
end