using MEDYAN
using Test

struct TestPlace <: MEDYAN.Place
    i::Int64
end
MEDYAN.null_place(::Type{TestPlace}) = TestPlace(0)

@testset "TagManager" begin
    @testset "empty" begin
        t = MEDYAN.TagManager{TestPlace}()
        @test isempty(t)
        t2 = MEDYAN.TagManager{TestPlace}()
        @test MEDYAN.statistically_equal(t, t2)
        @test isnothing(MEDYAN._try_get_idx(t, MEDYAN.Tag{TestPlace}(1,2)))
    end
    @testset "tag!" begin
        t = MEDYAN.TagManager{TestPlace}()
        @test isempty(t)
        @test length(t) == 0
        @test eltype(t) == MEDYAN.Tag{TestPlace}
        p1 = TestPlace(1)
        p2 = TestPlace(2)
        p3 = TestPlace(3)
        tag1 = MEDYAN._tag!(t, p1)
        tag2 = MEDYAN._tag!(t, p2)
        @test collect(t) == [tag1, tag2]
        @test length(t) == 2
        # repeated tags to an existing tagged place gets the same tag
        @test tag2 == MEDYAN._tag!(t, p2)
        @test tag1 == MEDYAN._tag!(t, p1)
        @test collect(t) == [tag1, tag2]
        @test length(t) == 2
        tag3 = MEDYAN._tag!(t, p3)
        @test collect(t) == [tag1, tag2, tag3]
        @test length(t) == 3
        MEDYAN.assert_invariants(t)
        @test MEDYAN._get_place(t, tag1) == p1
        @test MEDYAN._get_place(t, tag2) == p2
        @test MEDYAN._get_place(t, tag3) == p3
        # remove place
        let t = deepcopy(t)
            MEDYAN._remove_place!(t, p2)
            @test collect(t) == [tag1, tag3]
            @test length(t) == 2
            MEDYAN.assert_invariants(t)
            @test_throws ArgumentError MEDYAN._get_place(t, tag2)
            @test MEDYAN._get_place(t, tag1) == p1
            @test MEDYAN._get_place(t, tag3) == p3
            MEDYAN._remove_place!(t, p1)
            @test collect(t) == [tag3]
            @test length(t) == 1
            MEDYAN.assert_invariants(t)
            @test_throws ArgumentError MEDYAN._get_place(t, tag1)
            @test MEDYAN._get_place(t, tag3) == p3
            MEDYAN._remove_place!(t, p3)
            @test collect(t) == []
            @test length(t) == 0
            MEDYAN.assert_invariants(t)
            @test !isempty(t.idx2generation)
            @test_throws ArgumentError MEDYAN._get_place(t, tag3)
            # Places may get reused, but tags should be unique
            tag4 = MEDYAN._tag!(t, p1)
            @test collect(t) == [tag4]
            MEDYAN.assert_invariants(t)
            tag5 = MEDYAN._tag!(t, p2)
            @test issetequal(collect(t),[tag4, tag5])
            MEDYAN.assert_invariants(t)
            tag6 = MEDYAN._tag!(t, p3)
            @test issetequal(collect(t),[tag4, tag5, tag6])
            MEDYAN.assert_invariants(t)
            @test allunique([tag1,tag2,tag3,tag4,tag5,tag6])
            @test length(t.idx2place) == 3
            @test MEDYAN._get_place(t, tag4) == p1
            @test MEDYAN._get_place(t, tag5) == p2
            @test MEDYAN._get_place(t, tag6) == p3
            MEDYAN._free_unreferenced_tags!(t)
            @test isempty(t)
        end
        # move place
        let t = deepcopy(t)
            p4 = TestPlace(4)
            MEDYAN._move_place!(t, p1, p4)
            MEDYAN.assert_invariants(t)
            @test MEDYAN._get_place(t, tag1) == p4
            @test MEDYAN._get_place(t, tag2) == p2
            @test MEDYAN._get_place(t, tag3) == p3
            MEDYAN._move_place!(t, p4, p1)
            MEDYAN.assert_invariants(t)
            @test MEDYAN._get_place(t, tag1) == p1
            # Cannot move to an existing tagged place
            @test_throws ArgumentError MEDYAN._move_place!(t, p2, p3)
            MEDYAN.assert_invariants(t)
            @test MEDYAN._get_place(t, tag1) == p1
            @test MEDYAN._get_place(t, tag2) == p2
            @test MEDYAN._get_place(t, tag3) == p3
        end


    end

end