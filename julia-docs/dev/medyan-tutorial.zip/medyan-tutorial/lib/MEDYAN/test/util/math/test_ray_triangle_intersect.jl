using MEDYAN
using StaticArrays
using Test

@testset "Ray-triangle intersect" begin
    a1 = SA[0,0,0]
    b1 = SA[2,0,0]
    c1 = SA[0,2,0]

    o1 = SA[0,0,2]
    d1 = SA[1,1,0] # parallel
    d2 = SA[1,-1,-2] # outside
    d3 = SA[-1,1,-2] # outside
    d4 = SA[2,2,-2] # outside
    d5 = SA[0.5,0.5,-2] # inside
    d6 = SA[-0.5,-0.5,2] # (inside) away

    mt = MEDYAN.moller_trumbore_intersect
    tinterval = (0, Inf)

    # Parallel cases.
    @test !mt(o1, d1, a1, b1, c1; tinterval).intersect

    # Outside cases.
    @test !mt(o1, d2, a1, b1, c1; tinterval).intersect
    @test !mt(o1, d3, a1, b1, c1; tinterval).intersect
    @test !mt(o1, d4, a1, b1, c1; tinterval).intersect

    # Leaving cases.
    @test !mt(o1, d6, a1, b1, c1; tinterval).intersect

    # Intersect cases.
    let res = mt(o1, SA[0.5,0.5,-2], a1, b1, c1; tinterval)
        @test res.intersect
        @test res.t ≈ 1
        @test res.u ≈ 0.25
        @test res.v ≈ 0.25
    end
end
