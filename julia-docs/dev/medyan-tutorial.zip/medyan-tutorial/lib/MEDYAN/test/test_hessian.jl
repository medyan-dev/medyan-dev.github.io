using MEDYAN
using Test
using ForwardDiff
using StaticArrays
using LinearAlgebra

@testset "hessian" begin
    # Compare MEDYAN.hessian to an analytical hessian from ForwardDiff
    # for a simple single cylinder system.
    function HessianForwardDiff(E,x)
        energy = E(x)
        force = -ForwardDiff.gradient(E,x)
        hess = ForwardDiff.hessian(E,x)
        return energy,force,hess
        #return hess
    end

    L = 4
    grid = CubicGrid(SA[L,L,L], 500.0)
    c = MEDYAN.example_actin_mech_context(grid)
    num_monomers = 10
    monomer_len = 2.7 #nm
    filament_points = [
        SA[-num_monomers*monomer_len/2, 0, 0],
        SA[+num_monomers*monomer_len/2, 0, 0],
    ]
    make_fila!(c;
        type=1,
        mono_states=ones(UInt8,num_monomers),
        node_mids=[0,],
        node_positions=filament_points,
    )

    function energy2points(x;k,L)
        r1= x[1:3]
        r2= x[4:6]
        1//2*k*(norm(r2-r1)-L)^2
    end
    for trial in 1:1000
        config_rand = rand(6)
        f,g,h = MEDYAN.hessian!(MEDYAN.ForceContext(c), config_rand; dx = 0.000001)
        fdf, fdg, fdh = HessianForwardDiff(vcat(config_rand...)) do x
            energy2points(x; k= MEDYAN.ACTIN_FIL_PARAMS.klength/num_monomers, L=num_monomers*monomer_len)
        end
        @test maximum(abs, f - fdf) < 1E-9
        @test maximum(abs, g - fdg) < 1E-9
        @test maximum(abs, h - fdh) < 1E-3
    end
end