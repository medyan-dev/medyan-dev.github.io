# printf %s\\n {1..48} | xargs -n 1 -P 16 julia --project=.. myo_parameter_sweep.jl  outdata

include("myofilament-model.jl")

step_bell_distances = [-20.0, -10.0, -5.0, 0.0, 5.0, 10.0]
off_bell_distances = [0.0, 5.0, 10.0, 20.0]
dts = [1E-3, 5E-4]

jobs = []

for step_bell_distance in  step_bell_distances
    for off_bell_distance in off_bell_distances
        for dt in dts
            push!(jobs, (;step_bell_distance, off_bell_distance, dt))
        end
    end
end

job_idx = parse(Int, ARGS[2])
Random.seed!(job_idx)
(;step_bell_distance, off_bell_distance, dt) = jobs[job_idx]
velocities = speed_test(MyosinParameters(;
        number_of_monomers_per_side=15,
        load_force=0.0,
        on_rate=0.5,
        off_rate=0.35,
        step_distance=6.0,
        off_bell_distance=off_bell_distance,
        step_bell_distance=step_bell_distance,
        weak_off_rate=100.0,
        weak_on_off_ratio=1/10,
        myo_motor_mech_params=MaxDistanceRestraintMechParams(
            k= 0.04,# pN/nm
            maxdist= 30.0, # nm
        ),
    );
    trials=5,
    run_T=10.0,
    dt=dt,
    warmup_T=1.0,
)

out_file = joinpath(ARGS[1], "$(job_idx).json")
mkpath(ARGS[1])
open(out_file, "w") do io
    JSON3.pretty(io, OrderedDict([
        "dt"=>dt,
        "step_bell_distance"=>step_bell_distance,
        "off_bell_distance"=>off_bell_distance,
        "velocities"=>velocities,
    ]))
end
