
include("myofilament-model.jl")

vis = Visualizer()
Random.seed!(1234)
p = MyosinParameters(;
    number_of_monomers_per_side=15,
    load_force=0.0,
    on_rate=0.5,
    off_rate=0.35,
    step_distance=6.0,
    off_bell_distance=20.0,
    step_bell_distance=-10.0,
    weak_off_rate=100.0,
    weak_on_off_ratio=1/10,
    myo_motor_mech_params=MaxDistanceRestraintMechParams(
        k= 0.04,# pN/nm
        maxdist= 30.0, # nm
    ),
)
(;c, used_ATP) = make_context(p; grid = CubicGrid((1,1,8),500.0))
set_mechboundary!(c, MEDYAN.boundary_box(CubicGrid((1,1,8),500.0); stiffness=100.0))
s = c.sys_def
# Add a 800 actin filament
monomer_spacing = 2.7
num_monomers = 800
actin_L = num_monomers*monomer_spacing
monomerstates= zeros(UInt8,num_monomers)
monomerstates[1:end] .= s.state.actin.middle
for i in 1:30
    MEDYAN.chem_newfilament!(c;
                ftid=s.filament.actin,
                monomerstates,
                node_mids=[0,],
                nodepositions=[SA[0,0,-actin_L/2], SA[0,0,actin_L/2]],
            )
end

for i in 1:600
    # Number of fake myo monomers per myo filament.
    # spacing is 20 nm, this controls the length of the rigid part of the 
    # myo filament, and is independent of the number of heads.
    num_fake_myo_monomers = 3+5+3
    myo_fid = newfilament_rand!(c, fill(0x01, num_fake_myo_monomers); ftid=s.filament.myo)
    myo_plus_end = MonomerName(s.filament.myo, myo_fid, num_fake_myo_monomers-1)
    myo_minus_end = MonomerName(s.filament.myo, myo_fid, 0)
    chem_newlink_2mon!(
        c,
        s.link_2mon.myo_fil_end,
        myo_plus_end => myo_plus_end;
        changedchemstate = (;numUnbound=p.number_of_monomers_per_side,),
    )
    chem_newlink_2mon!(
        c,
        s.link_2mon.myo_fil_end,
        myo_minus_end => myo_minus_end;
        changedchemstate = (;numUnbound=p.number_of_monomers_per_side,),
    )
end

dt=1E-3
#=
for frame in 1:100
    draw_context!(vis, c, c.sys_def)
    for step in 1:100
        MEDYAN.minimize_energy!(c; brownian_motion_time=dt)
        MEDYAN.run_chemistry!(c, dt)
    end
end
=#
# draw_context!(vis, c, c.sys_def)

