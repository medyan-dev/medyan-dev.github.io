
include("myofilament-model.jl")

vis = Visualizer()
Random.seed!(1234)
p = MyosinParameters(;
    number_of_monomers_per_side=15,
    load_force=0.0,
    on_rate=0.5,
    off_rate=0.35,
    step_distance=6.0,
    off_bell_distance=20.0,
    step_bell_distance=-10.0,
    weak_off_rate=100.0,
    weak_on_off_ratio=1/10,
    myo_motor_mech_params=MaxDistanceRestraintMechParams(
        k= 0.04,# pN/nm
        maxdist= 30.0, # nm
    ),
)
(;c, used_ATP) = make_context(p; grid = CubicGrid((8,4,4),500.0), g_tol=5.0)
set_mechboundary!(c, MEDYAN.boundary_box(CubicGrid((8,4,4),500.0); stiffness=100.0))
s = c.sys_def
# Add a 800 actin filament
monomer_spacing = 2.7
num_monomers = 800
actin_L = num_monomers*monomer_spacing
monomerstates= zeros(UInt8,num_monomers)
monomerstates[1:end] .= s.state.actin.middle
start_points = let
    local lv = SA[0.0, -√(3)/2, 1/2]
    local uv = SA[0.0, 0.0, 1.0]
    local rv = SA[0.0, +√(3)/2, 1/2]
    local p = [
        [[i*uv - j*lv for i in 1:3+j] for j in 0:3]...;
        [[i*uv - 3lv + j*rv for i in 1:6-j] for j in 1:3]...;
    ] .- (3/2*rv + 2uv - 3/2*lv,)
    10.0*p .+ (SA[-actin_L/2, 0, 0,],)
end
for p in start_points
    MEDYAN.chem_newfilament!(c;
                ftid=s.filament.actin,
                monomerstates,
                node_mids=[0,],
                nodepositions=[p, p + SA[actin_L,0,0]],
            )
end

for i in 1:250
    # Number of fake myo monomers per myo filament.
    # spacing is 20 nm, this controls the length of the rigid part of the 
    # myo filament, and is independent of the number of heads.
    num_fake_myo_monomers = 3+5+3
    myo_fid = newfilament_rand!(c, fill(0x01, num_fake_myo_monomers); ftid=s.filament.myo)
    myo_plus_end = MonomerName(s.filament.myo, myo_fid, num_fake_myo_monomers-1)
    myo_minus_end = MonomerName(s.filament.myo, myo_fid, 0)
    chem_newlink_2mon!(
        c,
        s.link_2mon.myo_fil_end,
        myo_plus_end => myo_plus_end;
        changedchemstate = (;numUnbound=p.number_of_monomers_per_side,),
    )
    chem_newlink_2mon!(
        c,
        s.link_2mon.myo_fil_end,
        myo_minus_end => myo_minus_end;
        changedchemstate = (;numUnbound=p.number_of_monomers_per_side,),
    )
end

dt=1E-3
#=
for frame in 1:1000
    draw_context!(vis, c, c.sys_def)
    for step in 1:100
        MEDYAN.minimize_energy!(c; brownian_motion_time=dt)
        MEDYAN.run_chemistry!(c, dt)
    end
    @info frame
end
=#
# draw_context!(vis, c, c.sys_def)

