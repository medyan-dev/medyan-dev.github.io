using MEDYAN
using Test
using StaticArrays
using LinearAlgebra
using HypothesisTests

@testset "nearby monomer sampling" begin
    @testset "filament breadboard" begin
        x = SA[1.0,0.0,0.0]
        y = SA[0.0,1.0,0.0]
        z = SA[0.0,0.0,1.0]
        grid = CubicGrid((4, 4, 2), 720.0)
        cen = MEDYAN.centerof(grid)
        monomerspacing = 12.0
        filamentmechparams= MEDYAN.FilamentMechParams(
                radius= 3.0,
                spacing= monomerspacing,
                klength= 40000.0,
                kangle= 20000.0,
                numpercylinder= 20,
                max_num_unmin_end= 1000,
        )

        agent_names = MEDYAN.AgentNames(
            filamentnames = [
                (:a, [
                    :a,
                ]),
                (:b, [
                    :a,
                ]),
            ],
        )
        s= MEDYAN.SysDef(agent_names)
        add_filament_params!(s, :a, filamentmechparams)
        add_filament_params!(s, :b, filamentmechparams)
        # probe pushes sampled monomers to this vector.
        # This gets captured by the affect! closures.
        samples_init = [MEDYAN.FilaMonoIdx[] for i in 1:4]
        # define probe
        MEDYAN.add_link_type!(s,
            name = :probe,
            description = "probe for sampling nearby monomers",
            places = [MEDYAN.FilaMonoIdx()],
            reactions = [
                [
                    (;
                        name = :a,
                        rate = Returns(1.0),
                        affect! = (c::MEDYAN.Context; link, place, kwargs...) -> let
                            push!(samples_init[1], place)
                            1
                        end,
                        fila_cutoff = (:a, monomerspacing + 1E-4)
                    ),
                    (;
                        name = :b,
                        rate = Returns(2.0),
                        affect! = (c::MEDYAN.Context; link, place, kwargs...) -> let
                            push!(samples_init[2], place)
                            1
                        end,
                        fila_cutoff = (:a, √(2)*monomerspacing + 1E-4)
                    ),
                    (;
                        name = :c,
                        rate = Returns(3.0),
                        affect! = (c::MEDYAN.Context; link, place, kwargs...) -> let
                            push!(samples_init[3], place)
                            1
                        end,
                        fila_cutoff = (:b, monomerspacing + 1E-4)
                    ),
                    (;
                        name = :d,
                        rate = Returns(4.0),
                        affect! = (c::MEDYAN.Context; link, place, kwargs...) -> let
                            push!(samples_init[4], place)
                            1
                        end,
                        fila_cutoff = (:b, √(2)*monomerspacing + 1E-4)
                    ),
                ]
            ]
        )
        cinit = MEDYAN.Context(
            s,grid;
            check_neighborlist_error=true,
        )
        # Set up an array of filaments so monomers are evenly spaced
        # The filaments axis are aligned with the x axis
        # The filaments are distributed on the y axis
        # Type A filaments are in a plane at z = 0
        # Type B filaments are in a plane at z = monomerspacing
        NMonomers= 150
        for fila_typeid in 1:2
            for i in 1:NMonomers
                MEDYAN.make_fila!(cinit;
                    type = fila_typeid, 
                    mono_states = ones(UInt8,NMonomers),
                    node_mids = [1,],
                    node_positions = [
                        cen - NMonomers*monomerspacing/2*x + monomerspacing*(i-NMonomers/2-0.5)*y + (fila_typeid-1)*monomerspacing*z,
                        cen + NMonomers*monomerspacing/2*x + monomerspacing*(i-NMonomers/2-0.5)*y + (fila_typeid-1)*monomerspacing*z,
                    ],
                )
            end
        end
        # before monomers are marked as minimized, there are no nearby monomers
        rco1 = √(2)*monomerspacing/2 + 1E-4
        @test MEDYAN.num_nearby_monomers(cinit, cen, 1, rco1) == 0
        @test MEDYAN.random_nearby_monomer(cinit, cen, 1, rco1, 0) === nothing
        @test MEDYAN.random_nearby_monomer(cinit, cen, 1, rco1, 3) === nothing
        @test MEDYAN.random_nearby_monomer(cinit, cen, 1, 0.0, 0) === nothing
        @test MEDYAN.random_nearby_monomer(cinit, cen, 1, 0.0, 3) === nothing

        c, samples = deepcopy((cinit, samples_init))
        MEDYAN.helper_mark_monomers_minimized!(c)
        @test MEDYAN.num_nearby_monomers(c, cen, 1, rco1) == 4
        @test MEDYAN.random_nearby_monomer(c, cen, 1, rco1, 4) !== nothing
        trials = 1000
        for N in 4:6
            counts = zeros(Int, 5)
            for i in 1:trials
                maybe_name = MEDYAN.random_nearby_monomer(c, cen, 1, rco1, N)
                if isnothing(maybe_name)
                    counts[end] += 1
                elseif maybe_name == FilaMonoIdx(FilaIdx(1,75), 75)
                    counts[1] += 1
                elseif maybe_name == FilaMonoIdx(FilaIdx(1,75), 76)
                    counts[2] += 1
                elseif maybe_name == FilaMonoIdx(FilaIdx(1,76), 75)
                    counts[3] += 1
                elseif maybe_name == FilaMonoIdx(FilaIdx(1,76), 76)
                    counts[4] += 1
                end
            end
            @test counts[end] < trials/2
            @test pvalue(ChisqTest(counts[begin:end-1])) > 0.001
        end

        @testset "Test with chemistry" begin
            Δt = 1000.0
            c, samples = deepcopy((cinit, samples_init))
            MEDYAN.make_link!(c;
                type = :probe,
                places = (MEDYAN.FilaMonoIdx(MEDYAN.FilaIdx(1, 75), 75),)
            )
            MEDYAN.run_chemistry!(c, Δt)
            @test all(isempty, samples)
            MEDYAN.helper_mark_monomers_minimized!(c)
            MEDYAN.run_chemistry!(c, Δt)
            @test issetequal(samples[1], [
                MEDYAN.FilaMonoIdx(MEDYAN.FilaIdx(1, 74), 75),
                MEDYAN.FilaMonoIdx(MEDYAN.FilaIdx(1, 75), 74),
                MEDYAN.FilaMonoIdx(MEDYAN.FilaIdx(1, 75), 75),
                MEDYAN.FilaMonoIdx(MEDYAN.FilaIdx(1, 75), 76),
                MEDYAN.FilaMonoIdx(MEDYAN.FilaIdx(1, 76), 75),
            ])
            @test issetequal(samples[2], [
                MEDYAN.FilaMonoIdx(MEDYAN.FilaIdx(1, 74), 74),
                MEDYAN.FilaMonoIdx(MEDYAN.FilaIdx(1, 74), 75),
                MEDYAN.FilaMonoIdx(MEDYAN.FilaIdx(1, 74), 76),
                MEDYAN.FilaMonoIdx(MEDYAN.FilaIdx(1, 75), 74),
                MEDYAN.FilaMonoIdx(MEDYAN.FilaIdx(1, 75), 75),
                MEDYAN.FilaMonoIdx(MEDYAN.FilaIdx(1, 75), 76),
                MEDYAN.FilaMonoIdx(MEDYAN.FilaIdx(1, 76), 74),
                MEDYAN.FilaMonoIdx(MEDYAN.FilaIdx(1, 76), 75),
                MEDYAN.FilaMonoIdx(MEDYAN.FilaIdx(1, 76), 76),
            ])
            @test issetequal(samples[3], [
                MEDYAN.FilaMonoIdx(MEDYAN.FilaIdx(2, 75), 75),
            ])
            @test issetequal(samples[4], [
                MEDYAN.FilaMonoIdx(MEDYAN.FilaIdx(2, 74), 75),
                MEDYAN.FilaMonoIdx(MEDYAN.FilaIdx(2, 75), 74),
                MEDYAN.FilaMonoIdx(MEDYAN.FilaIdx(2, 75), 75),
                MEDYAN.FilaMonoIdx(MEDYAN.FilaIdx(2, 75), 76),
                MEDYAN.FilaMonoIdx(MEDYAN.FilaIdx(2, 76), 75),
            ])
            for i in 1:4
                local expected_samples = i*length(unique(samples[i]))*Δt
                @test length(samples[i]) < 1.05*expected_samples
                @test length(samples[i]) > 0.95*expected_samples
                # @show expected_samples
                # @show length(samples[i])
            end
        end
        @testset "Test with chemistry with mutating the system" begin
            Δt = 1000.0
            c, samples = deepcopy((cinit, samples_init))
            link = MEDYAN.make_link!(c;
                type = :probe,
                places = (MEDYAN.FilaMonoIdx(MEDYAN.FilaIdx(1, 75), 75),)
            )
            MEDYAN.run_chemistry!(c, Δt)
            @test all(isempty, samples)
            MEDYAN.helper_mark_monomers_minimized!(c)
            MEDYAN.refresh_chem_cache!(c)
            for i in 1:74
                MEDYAN.depolymerize_fila!(c, MEDYAN.FilaTipIdx(MEDYAN.FilaIdx(1, 76), true))
            end
            MEDYAN.remove_fila!(c, MEDYAN.FilaIdx(1, 74))
            MEDYAN.update_link!(c, link; reaction_enabled=((;d=false),))
            MEDYAN.run_chemistry!(c, Δt; before! = Returns(nothing))
            @test issetequal(samples[1], [
                MEDYAN.FilaMonoIdx(MEDYAN.FilaIdx(1, 75), 74),
                MEDYAN.FilaMonoIdx(MEDYAN.FilaIdx(1, 75), 75),
                MEDYAN.FilaMonoIdx(MEDYAN.FilaIdx(1, 75), 76),
                MEDYAN.FilaMonoIdx(MEDYAN.FilaIdx(1, 76), 75),
            ])
            @test issetequal(samples[2], [
                MEDYAN.FilaMonoIdx(MEDYAN.FilaIdx(1, 75), 74),
                MEDYAN.FilaMonoIdx(MEDYAN.FilaIdx(1, 75), 75),
                MEDYAN.FilaMonoIdx(MEDYAN.FilaIdx(1, 75), 76),
                MEDYAN.FilaMonoIdx(MEDYAN.FilaIdx(1, 76), 75),
                MEDYAN.FilaMonoIdx(MEDYAN.FilaIdx(1, 76), 76),
            ])
            @test issetequal(samples[3], [
                MEDYAN.FilaMonoIdx(MEDYAN.FilaIdx(2, 75), 75),
            ])
            @test isempty(samples[4])
            for i in 1:3
                local expected_samples = i*length(unique(samples[i]))*Δt
                @test length(samples[i]) < 1.05*expected_samples
                @test length(samples[i]) > 0.95*expected_samples
                # @show expected_samples
                # @show length(samples[i])
            end
        end

        # using GLMakie

        # MEDYAN.remove_fila!(cinit, MEDYAN.FilaIdx(1, 74))

        # rco = 20*√(2)*6 + 1E-4
        # trials = 100000
        # N = MEDYAN.num_nearby_monomers(cinit, c, 1, rco)
        # counts = zeros(Int, NMonomers, NMonomers)
        # for i in 1:trials
        #     maybe_name = MEDYAN.random_nearby_monomer(cinit, c, 1, rco, N)
        #     if !isnothing(maybe_name)
        #         counts[maybe_name.fid, maybe_name.mid] += 1
        #     end
        # end

        # heatmap(counts)
    end
end


