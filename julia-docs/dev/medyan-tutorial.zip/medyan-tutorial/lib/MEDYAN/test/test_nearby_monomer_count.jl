using MEDYAN
using Test
using StaticArrays
using LinearAlgebra
using HypothesisTests

@testset "nearby monomer sampling" begin
    @testset "filament breadboard" begin
        x = SA[1.0,0.0,0.0]
        y = SA[0.0,1.0,0.0]
        z = SA[0.0,0.0,1.0]
        grid = CubicGrid((4, 4, 2), 720.0)
        cen = MEDYAN.centerof(grid)
        monomerspacing = 12.0
        filamentmechparams= MEDYAN.FilamentMechParams(
                radius= 3.0,
                spacing= monomerspacing,
                klength= 40000.0,
                kangle= 20000.0,
                numpercylinder= 20,
                max_num_unmin_end= 1000,
        )

        agent_names = MEDYAN.AgentNames(
            filamentnames = [
                (:a, [
                    :a,
                ]),
                (:b, [
                    :a,
                ]),
            ],
            link_2mon_names = [:restraint,]
        )
        s= MEDYAN.SysDef(agent_names)
        add_filament_params!(s, :a, filamentmechparams)
        add_filament_params!(s, :b, filamentmechparams)
        #define restraints
        add_link_2mon!(s,
            :restraint,
            Link2MonState((;),(mr0 = zero(SVector{3,Float64}),mv̂0 = zero(SVector{3,Float64}))),
            MEDYAN.RestraintMechParams(kr=0.1,kv̂=0.0),
        )
        cinit = MEDYAN.Context(
            s,grid;
            chem_max_search_dist = 100.0,
            check_neighborlist_error=true,
        )
        # Set up two filaments perpendicular, and pulled to try and pass though each other.
        NMonomers= 150
        monomerstates= ones(UInt8,NMonomers)
        for i in 1:NMonomers
            nodepositions1 = [
                cen - NMonomers*monomerspacing/2*x + monomerspacing*(i-NMonomers/2-0.5)*y,
                cen + NMonomers*monomerspacing/2*x + monomerspacing*(i-NMonomers/2-0.5)*y,
                            ]
            MEDYAN.chem_newfilament!(cinit;
                ftid= 1, 
                monomerstates,
                node_mids = [1,],
                nodepositions = nodepositions1,
            )
        end
        # before monomers are marked as minimized, there are no nearby monomers
        rco1 = √(2)*monomerspacing/2 + 1E-4
        @test MEDYAN.num_nearby_monomers(cinit, cen, 1, rco1) == 0
        @test MEDYAN.random_nearby_monomer(cinit, cen, 1, rco1, 0) === nothing
        @test MEDYAN.random_nearby_monomer(cinit, cen, 1, rco1, 3) === nothing
        @test MEDYAN.random_nearby_monomer(cinit, cen, 1, 0.0, 0) === nothing
        @test MEDYAN.random_nearby_monomer(cinit, cen, 1, 0.0, 3) === nothing

        MEDYAN.helper_mark_monomers_minimized!(cinit)

        @test MEDYAN.num_nearby_monomers(cinit, cen, 1, rco1) == 4
        @test MEDYAN.random_nearby_monomer(cinit, cen, 1, rco1, 4) !== nothing
        trials = 1000
        for N in 4:6
            counts = zeros(Int, 5)
            for i in 1:trials
                maybe_name = MEDYAN.random_nearby_monomer(cinit, cen, 1, rco1, N)
                if isnothing(maybe_name)
                    counts[end] += 1
                elseif maybe_name == MonomerName(1,75, 75)
                    counts[1] += 1
                elseif maybe_name == MonomerName(1,75, 76)
                    counts[2] += 1
                elseif maybe_name == MonomerName(1,76, 75)
                    counts[3] += 1
                elseif maybe_name == MonomerName(1,76, 76)
                    counts[4] += 1
                end
            end
            @test counts[end] < trials/2
            @test pvalue(ChisqTest(counts[begin:end-1])) > 0.001
        end

        # using GLMakie

        # chem_removefilament!(
        #     cinit;
        #     fid=74,

        # )

        # rco = 20*√(2)*6 + 1E-4
        # trials = 100000
        # N = MEDYAN.num_nearby_monomers(cinit, c, 1, rco)
        # counts = zeros(Int, NMonomers, NMonomers)
        # for i in 1:trials
        #     maybe_name = MEDYAN.random_nearby_monomer(cinit, c, 1, rco, N)
        #     if !isnothing(maybe_name)
        #         counts[maybe_name.fid, maybe_name.mid] += 1
        #     end
        # end

        # heatmap(counts)
    end
end


