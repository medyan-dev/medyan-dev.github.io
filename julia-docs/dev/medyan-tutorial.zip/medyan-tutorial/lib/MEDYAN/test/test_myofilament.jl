using MEDYAN
using MeshCat
using Test
using StaticArrays
using LinearAlgebra


# First create a agent names with actin and myosin filaments
# Also include a myosin end link2mon and a myosin end to actin link
agent_names = MEDYAN.AgentNames(;
    filamentnames=[
        (:actin, [:middle, :bound]),
        (:myo, [:myo,]),
    ],
    link_2mon_names=[
        :myo_fil_end,
        :myo_motor,
    ]
)

# Create a SysDef
s = MEDYAN.SysDef(agent_names)

# Add Actin filament parameters
add_filament_params!(s, :actin, MEDYAN.ACTIN_FIL_PARAMS)

# Add Myosin filament parameters
add_filament_params!(s, :myo, MEDYAN.FilamentMechParams(
    radius= 20.0,
    spacing= 20.0,
    klength= 10*100.0,
    kangle= 1,
    numpercylinder= 1000,
    max_num_unmin_end= 1,
))

# Add myo_fil_end parameters
# This has no mechanical force field but keeps track of the number of bound and unbound motors
add_link_2mon!(s, 
    :myo_fil_end,
    MEDYAN.Link2MonState(
        (numBound = 0, numUnbound = 1),
        (;),
    ), 
    nothing,
)

# Define myo_motor mechanical parameters
Base.@kwdef struct MaxDistanceRestraintMechParams
    "spring constant"
    k::Float64

    "maximum distance"
    maxdist::Float64
end


function link_2mon_force(mechstate,mechparams::MaxDistanceRestraintMechParams,mr_sim,pr_sim,mv̂_sim,pv̂_sim)
    r = pr_sim - mr_sim
    L = norm_fast(r)
    ΔL = Base.FastMath.max_fast(L-mechparams.maxdist, zero(L))
    E = 1//2*mechparams.k*ΔL^2
    pf_sim = -mechparams.k*ΔL*r/L
    mf_sim = -pf_sim
    E, mf_sim, pf_sim, zero(mf_sim), zero(mf_sim)
end

# Add myo_motor parameters
# This stores a reference to the myo_fil_end link2mon id so
# that when it unbinds it can update the myo_fil_end link2mon number of bound and unbound motors

add_link_2mon!(s, 
    :myo_motor,
    MEDYAN.Link2MonState(
        (;parentid=-1,),
        (;),
    ), 
    MaxDistanceRestraintMechParams(
        k= 1.0,
        maxdist= 50.0,
    ),
)

# Define a MonLink2Mon site for the myo_fil_end link2mon to bind to an actin monomer.
@kwdef struct MonLink2MonSiteNumUnbound
    ftid::Int
    cutoff::Float64
end

cutoff_distance(site::MonLink2MonSiteNumUnbound) = site.cutoff

getftid(site::MonLink2MonSiteNumUnbound) = site.ftid

mon_link_2mon_sitecount(site::MonLink2MonSiteNumUnbound, link_2mon_state::MEDYAN.Link2MonState) = Float64(link_2mon_state.chemstate.numUnbound)

# Add myo_fil_end mon link2mon site
MEDYAN.add_mon_link_2mon_site!(s, 
    :myo_fil_end,
    :motor_binding,
    MonLink2MonSiteNumUnbound(
        ftid= 1,
        cutoff= 100.0, # this should be significantly larger than the myo_fil_end maxdist
    ),
)

# Define a callback for the myo motor binding reaction
# This will update the myo_fil_end link2mon number of bound and unbound motors
# It will also update the state of the bound monomer, setting it to bound to the myo_fil_end link2mon
# It will also add a myo_motor link2mon between the monomer and the myo_fil_end link2mon myo filament monomer.
# This will be used to apply a mechanical force to the myo filament monomer
# This callback will reject the reaction of the randomly sampled nearby actin monomer
# is already bound, or if the boltzmann factor dictates that the reaction should not occur.
function bind_motor(c::MEDYAN.Context, cid::Integer)
    maybe_nearby_mon_site = MEDYAN.pickrandommon_link_2mon_site(
        c,
        cid,
        s.link_2mon.myo_fil_end,
        s.mon_link_2mon_site.myo_fil_end.motor_binding.id
    )
    if isnothing(maybe_nearby_mon_site)
        return false # pick was rejected
    end
    link_id, minus_end, other_name = maybe_nearby_mon_site
    other_mon_state = mon_3states(c, other_name)[2]
    if other_mon_state != s.state.actin.middle
        return false # the monomer is already bound
    end
    link_state = 





