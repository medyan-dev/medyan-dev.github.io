# using Myosin model from https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6768639/

using MEDYAN
using MEDYANVis
using Test
using StaticArrays
using LinearAlgebra
using Setfield
using Random

"""
    rand_discrete_sample(αs, α_tot)::Union{Int, Nothing}

Return a random index i with probability `αs[i]/α_tot`. If no `i` is selected return `nothing`.
`α_tot` must be greater than or equal to the sum of `αs`.
"""
function rand_discrete_sample(αs, α_tot)::Union{Int, Nothing}
    u = α_tot*rand()
    for (i, α) in enumerate(αs)
        u -= α
        if u ≤ 0
            return i
        end
    end
    return nothing
end

# First create a agent names with actin and myosin filaments
# Also include a myosin end link2mon and a myosin end to actin link
agent_names = MEDYAN.AgentNames(;
    filamentnames=[
        (:actin, [:middle, :bound]),
        (:myo, [:myo,]),
    ],
    link_2mon_names=[
        :myo_fil_end,
        :myo_motor,
        :restraint,
        :constforce,
    ]
)

# Create a SysDef
s = MEDYAN.SysDef(agent_names)

#define restraints
add_link_2mon!(s,
    :restraint,
    Link2MonState((;),(mr0 = zero(SVector{3,Float64}),mv̂0 = zero(SVector{3,Float64}))),
    MEDYAN.RestraintMechParams(kr=0.2,kv̂=0.0),
    no_collide=true,
)
add_link_2mon!(s,
    :constforce,
    Link2MonState((;),(f=zeros(3),)),
    MEDYAN.ConstantForceMechParams(),
)

# Add Actin filament parameters
add_filament_params!(s, :actin, MEDYAN.ACTIN_FIL_PARAMS)

# Add Myosin filament parameters
const myo_spacing = 20.0
add_filament_params!(s, :myo, MEDYAN.FilamentMechParams(
    radius= 15.0,
    spacing= myo_spacing,
    klength= 10*100.0,
    kangle= 1,
    numpercylinder= 1000,
    max_num_unmin_end= 1,
))

# Add myo_fil_end parameters
# This has no mechanical force field but keeps track of the number of bound and unbound motors
add_link_2mon!(s, 
    :myo_fil_end,
    MEDYAN.Link2MonState(
        (
            numBound = 0,
            numUnbound_T_T = 1,
            numUnbound_T_DPi = 0,
            numUnbound_DPi_DPi = 0,
        ),
        (;),
    ), 
    nothing,
)

# Define myo_motor mechanical parameters
Base.@kwdef struct MaxDistanceRestraintMechParams
    "spring constant"
    k::Float64

    "maximum distance"
    maxdist::Float64
end


function MEDYAN.link_2mon_force(mechstate,mechparams::MaxDistanceRestraintMechParams,mr_sim,pr_sim,mv̂_sim,pv̂_sim)
    # mechstate.translated is how far (in nm) the force on the plus end of the link
    # is translated towards the plus end of the filament
    t = mechstate.translated
    r = (pr_sim + t*pv̂_sim) - mr_sim
    L = MEDYAN.norm_fast(r)
    ΔL = Base.FastMath.max_fast(L-mechparams.maxdist, zero(L))
    E = 1//2*mechparams.k*ΔL^2
    pf_sim = -mechparams.k*ΔL*r/L
    mf_sim = -pf_sim
    pfv̂_sim = -t*mechparams.k*ΔL*r/L
    E, mf_sim, pf_sim, zero(mf_sim), pfv̂_sim
end

# Add myo_motor parameters
# This stores a reference to the myo_fil_end link2mon id so
# that when it unbinds it can update the myo_fil_end link2mon number of bound and unbound motors

const myo_motor_mech_params = MaxDistanceRestraintMechParams(
    k= 0.2,
    maxdist= 50.0,
)

const Pi_load_factor = 0.2
const D_x_load_factor = 0.2

const effective_motor_volume = (4/3*π*50.0^3) # nm³

# using rates for α-S1 from table 2
# changed to MEDYAN units and using effective_motor_volume
# to adjust the motor actin binding rates.
const K_A = 10.68/MEDYAN.μM⁻¹_per_nm³/effective_motor_volume # s⁻¹
const K_Pi = 32.14 # s⁻¹
const K_D_x = 100.0 # s⁻¹
const K_D = 1970.0 # s⁻¹
const K_T = 27.6/MEDYAN.μM⁻¹_per_nm³ # nm³/s
const K_T_x = 1800.0 # s⁻¹
const K_T_xx = 1000.0 # s⁻¹
const K_H = 77.2 # s⁻¹
const K_AH = 79.1 # s⁻¹

const K_A_rev = 1000.0 # s⁻¹
const K_Pi_rev = 0.321E-3/MEDYAN.μM⁻¹_per_nm³ # nm³/s
const K_D_x_rev = 2.0 # s⁻¹
const K_D_rev = 10.0/MEDYAN.μM⁻¹_per_nm³ # nm³/s
const K_T_rev = 6597.0 # s⁻¹
const K_T_x_rev = 12.0 # s⁻¹
const K_T_xx_rev = 1.0/MEDYAN.μM⁻¹_per_nm³/effective_motor_volume # s⁻¹
const K_H_rev = 19.0 # s⁻¹
const K_AH_rev = 1.5 # s⁻¹

# Assume ATP, Pi, and ADP concentrations are fixed
const ATP_conc = 10000.0 * MEDYAN.μM⁻¹_per_nm³
const Pi_conc = 2000.0 * MEDYAN.μM⁻¹_per_nm³
const ADP_conc = 2000.0 * MEDYAN.μM⁻¹_per_nm³

const myo_motor_initial_translation = -2.5 # nm
const myo_motor_final_translation = 2.5 # nm

add_link_2mon!(s, 
    :myo_motor,
    MEDYAN.Link2MonState(
        (;parentid=-1, stage=-1, otherstage=-1),
        # Stages:
        # 1: A-M⋅D⋅Pi
        # 2: A⋅M⋅D
        # 3: A⋅M-D
        # 4: A⋅M
        # 5: A⋅M⋅T
        # 6: A-M⋅T
        # 7: M⋅T
        # 8: M⋅D⋅Pi
        (;translated=NaN,),
    ), 
    myo_motor_mech_params,
)



# Define a MonLink2Mon site for the myo_fil_end link2mon to bind to an actin monomer.
@kwdef struct MonLink2MonSiteNumUnbound
    ftid::Int
    cutoff::Float64 # nm
    double_binding_rate_factor::Float64# unitless
    DPi_binding_rate::Float64 # 1/s if a pair exists in the cutoff distance.
    T_binding_rate::Float64 # 1/s if a pair exists in the cutoff distance.
end
MEDYAN.cutoff_distance(site::MonLink2MonSiteNumUnbound) = site.cutoff
MEDYAN.getftid(site::MonLink2MonSiteNumUnbound) = site.ftid
function MEDYAN.mon_link_2mon_sitecount(site::MonLink2MonSiteNumUnbound, link_2mon_state::MEDYAN.Link2MonState)::Float64
    DPi_DPi = link_2mon_state.chemstate.numUnbound_DPi_DPi
    T_DPi = link_2mon_state.chemstate.numUnbound_T_DPi
    T_T = link_2mon_state.chemstate.numUnbound_T_T
    +(
        site.DPi_binding_rate*site.double_binding_rate_factor*DPi_DPi,
        site.DPi_binding_rate*T_DPi,
        site.T_binding_rate*site.double_binding_rate_factor*T_T,
        site.T_binding_rate*T_DPi,
    )
end
# Add myo_fil_end mon link2mon site
MEDYAN.add_mon_link_2mon_site!(s, 
    :myo_fil_end,
    :motor_binding,
    MonLink2MonSiteNumUnbound(
        ftid= 1,
        cutoff= 100.0, # this should be significantly larger than the myo_fil_end maxdist
        double_binding_rate_factor=2.0, # maybe should be 1.0.
        T_binding_rate=K_T_xx_rev,
        DPi_binding_rate=K_A,
    ),
)

# Define a callback for the myo motor binding reaction
# This will update the myo_fil_end link2mon number of bound and unbound motors
# It will also update the state of the bound monomer, setting it to bound to the myo_fil_end link2mon
# It will also add a myo_motor link2mon between the monomer and the myo_fil_end link2mon myo filament monomer.
# This will be used to apply a mechanical force to the myo filament monomer
# This callback will reject the reaction of the randomly sampled nearby actin monomer
# is already bound, or if the boltzmann factor dictates that the reaction should not occur.
const myo_fil_end_id = s.link_2mon.myo_fil_end
const myo_motor_id = s.link_2mon.myo_motor
const motor_binding_id = s.mon_link_2mon_site.myo_fil_end.motor_binding.id
const motor_binding_site = s.mon_link_2mon_site.myo_fil_end.motor_binding.site
const actin_middle_state = s.state.actin.middle
const actin_bound_state = s.state.actin.bound
function bind_motor(c::MEDYAN.Context, cid::Integer)
    site = motor_binding_site
    maybe_nearby_mon_site = MEDYAN.pickrandommon_link_2mon_site(
        c,
        cid,
        myo_fil_end_id,
        motor_binding_id,
    )
    if isnothing(maybe_nearby_mon_site)
        return false # pick was rejected
    end
    link_id, myo_end, actin_name = maybe_nearby_mon_site
    other_mon_state = mon_3states(c, actin_name)[2]
    if other_mon_state != actin_middle_state
        return false # the monomer is already bound
    end
    link_state = link_2mon_state(c, myo_fil_end_id, link_id)
    DPi_DPi::Int = link_state.chemstate.numUnbound_DPi_DPi
    T_DPi::Int = link_state.chemstate.numUnbound_T_DPi
    T_T::Int = link_state.chemstate.numUnbound_T_T
    numBound::Int = link_state.chemstate.numBound

    # randomly select which motor binds
    αs = SA[
        site.DPi_binding_rate*site.double_binding_rate_factor*DPi_DPi,
        site.DPi_binding_rate*T_DPi,
        site.T_binding_rate*site.double_binding_rate_factor*T_T,
        site.T_binding_rate*T_DPi,
    ]
    α_tot = sum(αs)
    # motor translation table
    motor_translations = SA[
        myo_motor_initial_translation,
        myo_motor_initial_translation,
        myo_motor_final_translation,
        myo_motor_final_translation,
    ]
        # Stages:
        # 1: A-M⋅D⋅Pi
        # 6: A-M⋅T
        # 7: M⋅T
        # 8: M⋅D⋅Pi

    # bound motor states table
    motor_bound_states = SA[
        (parentid=link_id, stage=1, otherstage=8),
        (parentid=link_id, stage=1, otherstage=7),
        (parentid=link_id, stage=6, otherstage=7),
        (parentid=link_id, stage=6, otherstage=8),
    ]

    # unbound motor states table
    motor_unbound_states = SA[
        (numBound=numBound+1, numUnbound_T_T=T_T, numUnbound_T_DPi = T_DPi, numUnbound_DPi_DPi = DPi_DPi-1),
        (numBound=numBound+1, numUnbound_T_T=T_T, numUnbound_T_DPi = T_DPi-1, numUnbound_DPi_DPi = DPi_DPi),
        (numBound=numBound+1, numUnbound_T_T=T_T-1, numUnbound_T_DPi = T_DPi, numUnbound_DPi_DPi = DPi_DPi),
        (numBound=numBound+1, numUnbound_T_T=T_T, numUnbound_T_DPi = T_DPi-1, numUnbound_DPi_DPi = DPi_DPi),
    ]

    selected = rand_discrete_sample(αs, α_tot)
    isnothing(selected) && return false # pick was rejected due to rounding errors
    selected_translation = motor_translations[selected]
    selected_bound_state = motor_bound_states[selected]
    selected_unbound_state = motor_unbound_states[selected]

    m_pos, m_plusvec = mon_position_plusvector(c, myo_end)
    a_pos, a_plusvec = mon_position_plusvector(c, actin_name)
    # get the forces and energies if the motor were to bind.
    E, mf_sim, pf_sim, = MEDYAN.link_2mon_force(
        (;translated=selected_translation),
        myo_motor_mech_params,
        m_pos, a_pos, m_plusvec, a_plusvec,
    )
    # TODO add catch-slip dynamics here. Or not.
    boltzmann_factor = exp(-c.β*E)
    if rand() < boltzmann_factor
        # update the myo_fil_end link2mon number of bound and unbound motors
        chem_setlink_2mon_state!(
            c,
            myo_fil_end_id,
            link_id,
            @set(link_state.chemstate = selected_unbound_state),
        )
        # update the state of the bound monomer, setting it to bound to the myo_fil_end link2mon
        chem_setmonomerstate!(c, actin_name, actin_bound_state)
        # add a myo_motor link2mon between the monomer and the myo_fil_end link2mon myo filament monomer.
        # This will be used to apply a mechanical force to the myo filament monomer
        chem_newlink_2mon!(
            c,
            myo_motor_id,
            myo_end => actin_name;
            changedchemstate = selected_bound_state,
            changedmechstate = (;translated=selected_translation,),
        )
        return true
    else
        return false
    end
end

addreactioncallback!(
    s,
    "mon_link_2mon_site.myo_fil_end.motor_binding",
    1.0,
    0,
    bind_motor,
)

# UNBOUND MOTOR ATP HYDROLYSIS REACTIONS
# These act on the myo_fil_end

@kwdef struct Link2MonSiteChemState
    chemstate_field::Symbol
end
function MEDYAN.link_2mon_sitecount(site::Link2MonSiteChemState, link_2mon_state::MEDYAN.Link2MonState, args...; kwargs...)::Float64
    getproperty(link_2mon_state.chemstate, site.chemstate_field)
end

@kwdef struct ChemStateIncCallback
    linker_type_id::Int
    site_id::Int
    chemstate_field_reactant::Symbol
    chemstate_field_product::Symbol
end
function (g::ChemStateIncCallback)(c::MEDYAN.Context, cid::Integer)
    maybe_nearby_mon_site = MEDYAN.pickrandomlink_2mon_site(
        c,
        cid,
        g.linker_type_id,
        g.site_id,
    )
    if isnothing(maybe_nearby_mon_site)
        return false # pick was rejected
    end
    link_id, myo_end, myo_end = maybe_nearby_mon_site
    link_state = link_2mon_state(c, myo_fil_end_id, link_id)
    chem_state = link_state.chemstate
    local new_chem_state::typeof(chem_state) = chem_state # set type for stability
    new_chem_state[g.chemstate_field_reactant] > 0 || return false # pick was not possible
    new_chem_state = Base.setindex(new_chem_state, new_chem_state[g.chemstate_field_reactant]-1, g.chemstate_field_reactant)
    new_chem_state = Base.setindex(new_chem_state, new_chem_state[g.chemstate_field_product]+1, g.chemstate_field_product)
    # update the myo_fil_end link2mon number of bound and unbound motors
    chem_setlink_2mon_state!(
        c,
        myo_fil_end_id,
        link_id,
        @set(link_state.chemstate = new_chem_state),
    )
    return true
end

function add_unbound_motor_reaction!(
        s::MEDYAN.SysDef,
        new_site::Symbol,
        reactant::Symbol,
        product::Symbol,
        rate::Float64,
    )
    MEDYAN.add_link_2mon_site!(
        s,
        :myo_fil_end,
        new_site,
        Link2MonSiteChemState(reactant),
    )
    addreactioncallback!(
        s,
        "link_2mon_site.myo_fil_end.$new_site",
        rate,
        0,
        ChemStateIncCallback(
            s.link_2mon.myo_fil_end,
            s.link_2mon_site.myo_fil_end[new_site].id,
            reactant,
            product,
        ),
    )
end

# T_T -> T_DPi
add_unbound_motor_reaction!(s, :ATP_hydrolysis_T_T, :numUnbound_T_T, :numUnbound_T_DPi, 2K_H)

# T_DPi -> DPi_DPi
add_unbound_motor_reaction!(s, :ATP_hydrolysis_T_DPi, :numUnbound_T_DPi, :numUnbound_DPi_DPi, K_H)

# T_DPi -> T_T
add_unbound_motor_reaction!(s, :ATP_reverse_hydrolysis_T_DPi, :numUnbound_T_DPi, :numUnbound_T_T, K_H_rev)

# DPi_DPi -> T_DPi
add_unbound_motor_reaction!(s, :ATP_reverse_hydrolysis_DPi_DPi, :numUnbound_DPi_DPi, :numUnbound_T_DPi, 2K_H_rev)

@kwdef struct Link2MonSiteATPHydrolysis
end
function MEDYAN.link_2mon_sitecount(
        site::Link2MonSiteATPHydrolysis,
        link_2mon_state, mechparams,
        minusftid, plusftid,
        minusmonomerstates, plusmonomerstates,
        m_pos, a_pos, m_plusvec, a_plusvec,
    )::Float64
    otherstage = link_2mon_state.chemstate.otherstage

    if otherstage == 8
        K_H_rev
    elseif otherstage == 7
        K_H
    else
        0.0
    end
end
MEDYAN.add_link_2mon_site!(
    s,
    :myo_motor,
    :ATP_hydrolysis,
    Link2MonSiteATPHydrolysis(),
)
const other_motor_atp_hydrolysis_id = s.link_2mon_site.myo_motor.ATP_hydrolysis.id
function other_motor_atp_hydrolysis_callback(c::MEDYAN.Context, cid::Integer)
    maybe_motor_site = MEDYAN.pickrandomlink_2mon_site(
        c,
        cid,
        myo_motor_id,
        other_motor_atp_hydrolysis_id,
    )
    if isnothing(maybe_motor_site)
        return false # pick was rejected
    end
    link_id, myo_end, actin_name = maybe_motor_site
    motor_state = link_2mon_state(c, myo_motor_id, link_id)
    chemstate = motor_state.chemstate
    if chemstate.otherstage == 8
        # reverse hydrolysis
        chem_setlink_2mon_state!(
            c,
            myo_motor_id,
            link_id,
            @set(motor_state.chemstate = Base.setindex(chemstate, 7, :otherstage)),
        )
    else
        # forward hydrolysis
        chem_setlink_2mon_state!(
            c,
            myo_motor_id,
            link_id,
            @set(motor_state.chemstate = Base.setindex(chemstate, 8, :otherstage)),
        )
    end
    return true
end

# MOTOR STEPPING

@kwdef struct Link2MonSiteMotorStep
end
function MEDYAN.link_2mon_sitecount(
        site::Link2MonSiteMotorStep,
        link_2mon_state, mechparams,
        minusftid, plusftid,
        minusmonomerstates, plusmonomerstates,
        m_pos, a_pos, m_plusvec, a_plusvec,
    )::Float64
    stage = link_2mon_state.chemstate.stage
    # Get the energies in the initial and final translations
    # This is needed to ensure detailed balance.
    function get_energies()
        local E_final, mf_sim, pf_sim, = MEDYAN.link_2mon_force(
            (;translated=myo_motor_final_translation),
            mechparams,
            m_pos, a_pos, m_plusvec, a_plusvec,
        )
        local E_initial, mf_sim, pf_sim, = MEDYAN.link_2mon_force(
            (;translated=myo_motor_initial_translation),
            mechparams,
            m_pos, a_pos, m_plusvec, a_plusvec,
        )
        E_final, E_initial
    end
    if stage == 1
        # A-M⋅D⋅Pi
        E_final, E_initial = get_energies()
        ΔE = E_final-E_initial
        Pi_boltzmann_factor = exp(-Pi_load_factor*c.β*ΔE)
        # For AH we assume that all of the boltzmann factor effects the reverse rate.
        AH_rev_boltzmann_factor = exp(-c.β*ΔE)
        K_Pi*Pi_boltzmann_factor + K_A_rev + K_AH_rev*AH_rev_boltzmann_factor
    elseif stage == 2
        # A⋅M⋅D
        E_final, E_initial = get_energies()
        ΔE = E_final-E_initial
        K_D_x_slowdown_factor = exp(-D_x_load_factor*c.β*ΔE) # applied to both directions
        Pi_rev_load_factor = 1.0 - Pi_load_factor
        Pi_rev_boltzmann_factor = exp(+Pi_rev_load_factor*c.β*ΔE)
        K_D_x*K_D_x_slowdown_factor + K_Pi_rev*Pi_conc*Pi_rev_boltzmann_factor
    elseif stage == 3
        # A⋅M-D
        E_final, E_initial = get_energies()
        ΔE = E_final-E_initial
        K_D_x_slowdown_factor = exp(-D_x_load_factor*c.β*ΔE) # applied to both directions
        K_D + K_D_x_rev*K_D_x_slowdown_factor
    elseif stage == 4
        # A⋅M
        K_T*ATP_conc + K_D_rev*ADP_conc
    elseif stage == 5
        # A⋅M⋅T
        K_T_x + K_T_rev
    elseif stage == 6
        # A-M⋅T
        K_T_xx + K_T_x_rev + K_AH
    else
        0.0
    end
end
MEDYAN.add_link_2mon_site!(
    s,
    :myo_motor,
    :motor_step,
    Link2MonSiteMotorStep(),
)
const motor_step_id = s.link_2mon_site.myo_motor.motor_step.id

"net number of ATP used by myosin, just for tracking purposes"
const used_ATP = Ref(0)
function step_motor(c::MEDYAN.Context, cid::Integer)
    maybe_motor_site = MEDYAN.pickrandomlink_2mon_site(
        c,
        cid,
        myo_motor_id,
        motor_step_id,
    )
    if isnothing(maybe_motor_site)
        return false # pick was rejected
    end
    link_id, myo_end, actin_name = maybe_motor_site
    motor_state = link_2mon_state(c, myo_motor_id, link_id)
    chemstate = motor_state.chemstate
    mechstate = motor_state.mechstate
    stage = chemstate.stage
    otherstage = chemstate.otherstage
    function get_energies()
        m_pos, m_plusvec = mon_position_plusvector(c, myo_end)
        a_pos, a_plusvec = mon_position_plusvector(c, actin_name)
        local E_final, mf_sim, pf_sim, = MEDYAN.link_2mon_force(
            (;translated=myo_motor_final_translation),
            myo_motor_mech_params,
            m_pos, a_pos, m_plusvec, a_plusvec,
        )
        local E_initial, mf_sim, pf_sim, = MEDYAN.link_2mon_force(
            (;translated=myo_motor_initial_translation),
            myo_motor_mech_params,
            m_pos, a_pos, m_plusvec, a_plusvec,
        )
        E_final, E_initial
    end
    if stage == 1
        let
            # A-M⋅D⋅Pi
            E_final, E_initial = get_energies()
            ΔE = E_final-E_initial
            Pi_boltzmann_factor = exp(-Pi_load_factor*c.β*ΔE)
            # For AH we assume that all of the boltzmann factor effects the reverse rate.
            AH_rev_boltzmann_factor = exp(-c.β*ΔE)
            αs = SA[
                K_Pi*Pi_boltzmann_factor,
                K_A_rev,
                K_AH_rev*AH_rev_boltzmann_factor,
            ]
            α_tot = sum(αs)
            selected = rand_discrete_sample(αs, α_tot)
            isnothing(selected) && return false # pick was rejected due to rounding errors
            if selected == 1
                # A-M⋅D⋅Pi -> A⋅M⋅D
                new_chemstate = Base.setindex(chemstate, 2, :stage)
                new_mechstate = Base.setindex(mechstate, myo_motor_final_translation, :translated)
                chem_setlink_2mon_state!(
                    c,
                    myo_motor_id,
                    link_id,
                    MEDYAN.Link2MonState(new_chemstate, new_mechstate),
                )
                return true
            elseif selected == 2
                # A-M⋅D⋅Pi -> M⋅D⋅Pi
                parent_link_id = motor_state.chemstate.parentid
                parent_link_state = link_2mon_state(c, myo_fil_end_id, parent_link_id)
                parent_chem_state = parent_link_state.chemstate
                DPi_DPi::Int = parent_chem_state.numUnbound_DPi_DPi
                T_DPi::Int = parent_chem_state.numUnbound_T_DPi
                T_T::Int = parent_chem_state.numUnbound_T_T
                numBound::Int = parent_chem_state.numBound
                motor_unbound_state = if otherstage == 7
                    (numBound=numBound-1, numUnbound_T_T=T_T, numUnbound_T_DPi = T_DPi+1, numUnbound_DPi_DPi = DPi_DPi)
                elseif otherstage == 8
                    (numBound=numBound-1, numUnbound_T_T=T_T, numUnbound_T_DPi = T_DPi, numUnbound_DPi_DPi = DPi_DPi+1)
                else
                    error("Invalid otherstage")
                end
                chem_setlink_2mon_state!(
                    c,
                    myo_fil_end_id,
                    parent_link_id,
                    @set(parent_link_state.chemstate = motor_unbound_state),
                )
                # update the state of the bound monomer, setting it to bound to the myo_fil_end link2mon
                chem_setmonomerstate!(c, actin_name, actin_middle_state)
                # remove the myo_motor link2mon.
                chem_removelink_2mon!(
                    c,
                    myo_motor_id,
                    link_id,
                )
                return true
            elseif selected == 3
                # A-M⋅D⋅Pi -> A-M⋅T
                new_chemstate = Base.setindex(chemstate, 6, :stage)
                new_mechstate = Base.setindex(mechstate, myo_motor_final_translation, :translated)
                chem_setlink_2mon_state!(
                    c,
                    myo_motor_id,
                    link_id,
                    MEDYAN.Link2MonState(new_chemstate, new_mechstate),
                )
                return true
            else
                error("Invalid selected")
            end
        end
    elseif stage == 2
        let
            # A⋅M⋅D
            E_final, E_initial = get_energies()
            ΔE = E_final-E_initial
            K_D_x_slowdown_factor = exp(-D_x_load_factor*c.β*ΔE) # applied to both directions
            Pi_rev_load_factor = 1.0 - Pi_load_factor
            Pi_rev_boltzmann_factor = exp(+Pi_rev_load_factor*c.β*ΔE)
            αs = SA[
                K_D_x*K_D_x_slowdown_factor,
                K_Pi_rev*Pi_conc*Pi_rev_boltzmann_factor,
            ]
            α_tot = sum(αs)
            selected = rand_discrete_sample(αs, α_tot)
            isnothing(selected) && return false # pick was rejected due to rounding errors
            if selected == 1
                # A⋅M⋅D -> A⋅M-D
                new_chemstate = Base.setindex(chemstate, 3, :stage)
                chem_setlink_2mon_state!(
                    c,
                    myo_motor_id,
                    link_id,
                    @set(motor_state.chemstate = new_chemstate),
                )
                return true
            elseif selected == 2
                # A⋅M⋅D -> A-M⋅D⋅Pi
                new_chemstate = Base.setindex(chemstate, 1, :stage)
                new_mechstate = Base.setindex(mechstate, myo_motor_initial_translation, :translated)
                chem_setlink_2mon_state!(
                    c,
                    myo_motor_id,
                    link_id,
                    MEDYAN.Link2MonState(new_chemstate, new_mechstate),
                )
                return true
            else
                error("Invalid selected")
            end
        end
    elseif stage == 3
        let
            # A⋅M-D
            E_final, E_initial = get_energies()
            ΔE = E_final-E_initial
            K_D_x_slowdown_factor = exp(-D_x_load_factor*c.β*ΔE) # applied to both directions
            αs = SA[
                K_D,
                K_D_x_rev*K_D_x_slowdown_factor,
            ]
            α_tot = sum(αs)
            selected = rand_discrete_sample(αs, α_tot)
            isnothing(selected) && return false # pick was rejected due to rounding errors
            if selected == 1
                # A⋅M-D -> A⋅M
                new_chemstate = Base.setindex(chemstate, 4, :stage)
                chem_setlink_2mon_state!(
                    c,
                    myo_motor_id,
                    link_id,
                    @set(motor_state.chemstate = new_chemstate),
                )
                return true
            elseif selected == 2
                # A⋅M-D -> A⋅M⋅D
                new_chemstate = Base.setindex(chemstate, 2, :stage)
                chem_setlink_2mon_state!(
                    c,
                    myo_motor_id,
                    link_id,
                    @set(motor_state.chemstate = new_chemstate),
                )
                return true
            else
                error("Invalid selected")
            end
        end
    elseif stage == 4
        let
            # A⋅M
            αs = SA[
                K_T*ATP_conc,
                K_D_rev*ADP_conc,
            ]
            α_tot = sum(αs)
            selected = rand_discrete_sample(αs, α_tot)
            isnothing(selected) && return false # pick was rejected due to rounding errors
            if selected == 1
                # A⋅M -> A⋅M⋅T
                used_ATP[] += 1
                new_chemstate = Base.setindex(chemstate, 5, :stage)
                chem_setlink_2mon_state!(
                    c,
                    myo_motor_id,
                    link_id,
                    @set(motor_state.chemstate = new_chemstate),
                )
                return true
            elseif selected == 2
                # A⋅M -> A⋅M-D
                new_chemstate = Base.setindex(chemstate, 3, :stage)
                chem_setlink_2mon_state!(
                    c,
                    myo_motor_id,
                    link_id,
                    @set(motor_state.chemstate = new_chemstate),
                )
                return true
            else
                error("Invalid selected")
            end
        end
    elseif stage == 5
        let
            # A⋅M⋅T
            αs = SA[
                K_T_x,
                K_T_rev,
            ]
            α_tot = sum(αs)
            selected = rand_discrete_sample(αs, α_tot)
            isnothing(selected) && return false # pick was rejected due to rounding errors
            if selected == 1
                # A⋅M⋅T -> A-M⋅T
                new_chemstate = Base.setindex(chemstate, 6, :stage)
                chem_setlink_2mon_state!(
                    c,
                    myo_motor_id,
                    link_id,
                    @set(motor_state.chemstate = new_chemstate),
                )
                return true
            elseif selected == 2
                # A⋅M⋅T -> A⋅M
                used_ATP[] -= 1
                new_chemstate = Base.setindex(chemstate, 4, :stage)
                chem_setlink_2mon_state!(
                    c,
                    myo_motor_id,
                    link_id,
                    @set(motor_state.chemstate = new_chemstate),
                )
                return true
            else
                error("Invalid selected")
            end
        end
    elseif stage == 6
        let
            # A-M⋅T
            αs = SA[
                K_T_xx,
                K_T_x_rev,
                K_AH,
            ]
            α_tot = sum(αs)
            selected = rand_discrete_sample(αs, α_tot)
            isnothing(selected) && return false # pick was rejected due to rounding errors
            if selected == 1
                # A-M⋅T -> M⋅T
                parent_link_id = motor_state.chemstate.parentid
                parent_link_state = link_2mon_state(c, myo_fil_end_id, parent_link_id)
                parent_chem_state = parent_link_state.chemstate
                DPi_DPi::Int = parent_chem_state.numUnbound_DPi_DPi
                T_DPi::Int = parent_chem_state.numUnbound_T_DPi
                T_T::Int = parent_chem_state.numUnbound_T_T
                numBound::Int = parent_chem_state.numBound
                motor_unbound_state = if otherstage == 7
                    (numBound=numBound-1, numUnbound_T_T=T_T+1, numUnbound_T_DPi = T_DPi, numUnbound_DPi_DPi = DPi_DPi)
                elseif otherstage == 8
                    (numBound=numBound-1, numUnbound_T_T=T_T, numUnbound_T_DPi = T_DPi+1, numUnbound_DPi_DPi = DPi_DPi)
                else
                    error("Invalid otherstage")
                end
                chem_setlink_2mon_state!(
                    c,
                    myo_fil_end_id,
                    parent_link_id,
                    @set(parent_link_state.chemstate = motor_unbound_state),
                )
                # update the state of the bound monomer, setting it to bound to the myo_fil_end link2mon
                chem_setmonomerstate!(c, actin_name, actin_middle_state)
                # remove the myo_motor link2mon.
                chem_removelink_2mon!(
                    c,
                    myo_motor_id,
                    link_id,
                )
                return true
            elseif selected == 2
                # A-M⋅T -> A⋅M⋅T
                new_chemstate = Base.setindex(chemstate, 4, :stage)
                chem_setlink_2mon_state!(
                    c,
                    myo_motor_id,
                    link_id,
                    @set(motor_state.chemstate = new_chemstate),
                )
                return true
            elseif selected == 3
                # A-M⋅T -> A-M⋅D⋅Pi
                new_chemstate = Base.setindex(chemstate, 1, :stage)
                new_mechstate = Base.setindex(mechstate, myo_motor_initial_translation, :translated)
                chem_setlink_2mon_state!(
                    c,
                    myo_motor_id,
                    link_id,
                    MEDYAN.Link2MonState(new_chemstate, new_mechstate),
                )
                return true
            else
                error("Invalid selected")
            end
        end
    else
        error("Invalid stage")
    end
    error("unreachable")
end

addreactioncallback!(
    s,
    "link_2mon_site.myo_motor.motor_step",
    1.0,
    0,
    step_motor,
)

grid = CubicGrid((8,2,2),500.0)
function main(;
    motors_per_half_filament::Int = parse(Int, ARGS[1]),
    load_force::Float64 = parse(Float64, ARGS[2]), # pN
    seed::Int = parse(Int, ARGS[3]),
    )
    Random.seed!(seed)
    used_ATP[] = 0
    @info (;motors_per_half_filament, load_force, seed)
    c = MEDYAN.Context(s, grid)
    # Add an actin filament
    num_monomers = 800
    actin_len = num_monomers * MEDYAN.ACTIN_FIL_PARAMS.spacing
    fid1 = chem_newfilament!(c,
        ftid=s.filament.actin,
        monomerstates=fill(s.state.actin.middle, num_monomers),
        node_mids=[0,],
        nodepositions= [
            SA[-actin_len/2, 0.0, 0.0],
            SA[+actin_len/2, 0.0, 0.0],
        ]
    )
    # restrain filament ends
    MEDYAN.chem_newlink_2mon!(c,
        s.link_2mon.restraint,#ltid 
        MonomerName(s.filament.actin, fid1, 0)=>
        MonomerName(s.filament.actin, fid1, 0);
        changedmechstate = (mr0 = mon_position(c, MonomerName(s.filament.actin, fid1, 0)), mv̂0 = SA[1.0,0,0]),
    )
    MEDYAN.chem_newlink_2mon!(c,
        s.link_2mon.restraint,#ltid 
        MonomerName(s.filament.actin, fid1, num_monomers-1)=>
        MonomerName(s.filament.actin, fid1, num_monomers-1);
        changedmechstate = (mr0 = mon_position(c, MonomerName(s.filament.actin, fid1, num_monomers-1)), mv̂0 = SA[1.0,0,0]),
    )

    # Number of fake myo monomers per myo filament.
    # spacing is 20 nm, this controls the length of the rigid part of the 
    # myo filament, and is independent of the number of heads.
    num_fake_myo_monomers = 3+5+3
    myo_len = num_fake_myo_monomers * myo_spacing
    myo_fid = chem_newfilament!(c,
        ftid=s.filament.myo,
        monomerstates=fill(0x01, num_fake_myo_monomers),
        node_mids=[0,],
        nodepositions= [
            SA[-myo_len/2, -20.0, 0.0],
            SA[myo_len/2, -20.0, 0.0],
        ]
    )
    myo_plus_end = MonomerName(s.filament.myo, myo_fid, num_fake_myo_monomers-1)
    myo_mid_point = MonomerName(s.filament.myo, myo_fid, (num_fake_myo_monomers-1)÷2)
    myo_minus_end = MonomerName(s.filament.myo, myo_fid, 0)
    chem_newlink_2mon!(
        c,
        myo_fil_end_id,
        myo_plus_end => myo_plus_end;
        changedchemstate = (;numUnbound_DPi_DPi=motors_per_half_filament÷2,),
    )
    chem_newlink_2mon!(
        c,
        myo_fil_end_id,
        myo_minus_end => myo_minus_end;
        changedchemstate = (;numUnbound_DPi_DPi=motors_per_half_filament÷2,),
    )
    # load force
    MEDYAN.chem_newlink_2mon!(c,
        s.link_2mon.constforce,#ltid 
        myo_mid_point=>myo_mid_point;
        changedmechstate = (f=-load_force*SA[1.0,0,0],),
    )
    c
end

#=
c = main(;
    motors_per_half_filament = 30,
    load_force = 1.0,
    seed = 1234,
)
vis = Visualizer()
for i in 1:10
    # sleep(0.1)
    draw_context!(vis, c, s)
    for i in 1:1000
        MEDYAN.minimize_energy!(c; brownian_motion_time=1E-5)
        MEDYAN.run_chemistry!(c, 1E-5)
    end
end
=#