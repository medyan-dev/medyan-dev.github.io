using MEDYAN
using MEDYANVis
using Test
using StaticArrays
using LinearAlgebra
using Setfield


# First create a agent names with actin and myosin filaments
# Also include a myosin end link2mon and a myosin end to actin link
agent_names = MEDYAN.AgentNames(;
    filamentnames=[
        (:actin, [:middle, :bound]),
        (:myo, [:myo,]),
    ],
    link_2mon_names=[
        :myo_fil_end,
        :myo_motor,
    ]
)

# Create a SysDef
s = MEDYAN.SysDef(agent_names)

# Add Actin filament parameters
add_filament_params!(s, :actin, MEDYAN.ACTIN_FIL_PARAMS)

# Add Myosin filament parameters
const myo_spacing = 20.0
add_filament_params!(s, :myo, MEDYAN.FilamentMechParams(
    radius= 20.0,
    spacing= myo_spacing,
    klength= 10*100.0,
    kangle= 1,
    numpercylinder= 1000,
    max_num_unmin_end= 1,
))

# Add myo_fil_end parameters
# This has no mechanical force field but keeps track of the number of bound and unbound motors
add_link_2mon!(s, 
    :myo_fil_end,
    MEDYAN.Link2MonState(
        (numBound = 0, numUnbound = 1),
        (;),
    ), 
    nothing,
)

# Define myo_motor mechanical parameters
Base.@kwdef struct MaxDistanceRestraintMechParams
    "spring constant"
    k::Float64

    "maximum distance"
    maxdist::Float64
end


function MEDYAN.link_2mon_force(mechstate,mechparams::MaxDistanceRestraintMechParams,mr_sim,pr_sim,mv̂_sim,pv̂_sim)
    # mechstate.translated is how far (in nm) the force on the plus end of the link
    # is translated towards the plus end of the filament
    t = mechstate.translated
    r = (pr_sim + t*pv̂_sim) - mr_sim
    L = MEDYAN.norm_fast(r)
    ΔL = Base.FastMath.max_fast(L-mechparams.maxdist, zero(L))
    E = 1//2*mechparams.k*ΔL^2
    pf_sim = -mechparams.k*ΔL*r/L
    mf_sim = -pf_sim
    pfv̂_sim = -t*mechparams.k*ΔL*r/L
    E, mf_sim, pf_sim, zero(mf_sim), pfv̂_sim
end

# Add myo_motor parameters
# This stores a reference to the myo_fil_end link2mon id so
# that when it unbinds it can update the myo_fil_end link2mon number of bound and unbound motors

const myo_motor_mech_params = MaxDistanceRestraintMechParams(
    k= 1.0,
    maxdist= 50.0,
)

add_link_2mon!(s, 
    :myo_motor,
    MEDYAN.Link2MonState(
        (;parentid=-1,),
        (;translated=NaN,),
    ), 
    myo_motor_mech_params,
)

myo_motor_initial_translation = -5.0 # nm
myo_motor_final_translation = 5.0 # nm

# Define a MonLink2Mon site for the myo_fil_end link2mon to bind to an actin monomer.
@kwdef struct MonLink2MonSiteNumUnbound
    ftid::Int
    cutoff::Float64
end
MEDYAN.cutoff_distance(site::MonLink2MonSiteNumUnbound) = site.cutoff
MEDYAN.getftid(site::MonLink2MonSiteNumUnbound) = site.ftid
MEDYAN.mon_link_2mon_sitecount(site::MonLink2MonSiteNumUnbound, link_2mon_state::MEDYAN.Link2MonState) = Float64(link_2mon_state.chemstate.numUnbound)
# Add myo_fil_end mon link2mon site
MEDYAN.add_mon_link_2mon_site!(s, 
    :myo_fil_end,
    :motor_binding,
    MonLink2MonSiteNumUnbound(
        ftid= 1,
        cutoff= 100.0, # this should be significantly larger than the myo_fil_end maxdist
    ),
)

# Define a callback for the myo motor binding reaction
# This will update the myo_fil_end link2mon number of bound and unbound motors
# It will also update the state of the bound monomer, setting it to bound to the myo_fil_end link2mon
# It will also add a myo_motor link2mon between the monomer and the myo_fil_end link2mon myo filament monomer.
# This will be used to apply a mechanical force to the myo filament monomer
# This callback will reject the reaction of the randomly sampled nearby actin monomer
# is already bound, or if the boltzmann factor dictates that the reaction should not occur.
const myo_fil_end_id = s.link_2mon.myo_fil_end
const myo_motor_id = s.link_2mon.myo_motor
const motor_binding_id = s.mon_link_2mon_site.myo_fil_end.motor_binding.id
const actin_middle_state = s.state.actin.middle
const actin_bound_state = s.state.actin.bound
function bind_motor(c::MEDYAN.Context, cid::Integer)
    maybe_nearby_mon_site = MEDYAN.pickrandommon_link_2mon_site(
        c,
        cid,
        myo_fil_end_id,
        motor_binding_id,
    )
    if isnothing(maybe_nearby_mon_site)
        return false # pick was rejected
    end
    link_id, myo_end, actin_name = maybe_nearby_mon_site
    other_mon_state = mon_3states(c, actin_name)[2]
    if other_mon_state != actin_middle_state
        return false # the monomer is already bound
    end
    link_state = link_2mon_state(c, myo_fil_end_id, link_id)
    numUnbound::Int = link_state.chemstate.numUnbound
    numBound::Int = link_state.chemstate.numBound
    m_pos, m_plusvec = mon_position_plusvector(c, myo_end)
    a_pos, a_plusvec = mon_position_plusvector(c, actin_name)
    # get the forces and energies if the motor were to bind.
    E, mf_sim, pf_sim, = MEDYAN.link_2mon_force(
        (;translated=myo_motor_initial_translation),
        myo_motor_mech_params,
        m_pos, a_pos, m_plusvec, a_plusvec,
    )
    # TODO add catch-slip dynamics here.
    boltzmann_factor = exp(-c.β*E)
    if rand() < boltzmann_factor
        # update the myo_fil_end link2mon number of bound and unbound motors
        chem_setlink_2mon_state!(
            c,
            myo_fil_end_id,
            link_id,
            @set(link_state.chemstate = (;numBound=numBound+1, numUnbound=numUnbound-1)),
        )
        # update the state of the bound monomer, setting it to bound to the myo_fil_end link2mon
        chem_setmonomerstate!(c, actin_name, actin_bound_state)
        # add a myo_motor link2mon between the monomer and the myo_fil_end link2mon myo filament monomer.
        # This will be used to apply a mechanical force to the myo filament monomer
        chem_newlink_2mon!(
            c,
            myo_motor_id,
            myo_end => actin_name;
            changedchemstate = (;parentid=link_id,),
            changedmechstate = (;translated=myo_motor_initial_translation)
        )
        return true
    else
        return false
    end
end

motor_binding_rate = 1.4
addreactioncallback!(
    s,
    "mon_link_2mon_site.myo_fil_end.motor_binding",
    motor_binding_rate,
    0,
    bind_motor,
)

# MOTOR STEPPING

MEDYAN.add_link_2mon_site!(
    s,
    :myo_motor,
    :motor_step,
    MEDYAN.Link2MonSiteOne(),
)

function step_motor(c::MEDYAN.Context, cid::Integer)
    maybe_motor_site = MEDYAN.pickrandomlink_2mon_site(
        c,
        cid,
        myo_motor_id,
        motor_binding_id,
    )
    if isnothing(maybe_motor_site)
        return false # pick was rejected
    end
    link_id, myo_end, actin_name = maybe_motor_site
    motor_state = link_2mon_state(c, myo_motor_id, link_id)

    # TODO add stalling here.
    chem_setlink_2mon_state!(
        c,
        myo_motor_id,
        link_id,
        @set(motor_state.mechstate = (;translated=myo_motor_final_translation)),
    )
    return true
end

motor_stepping_rate = 10.0
addreactioncallback!(
    s,
    "link_2mon_site.myo_motor.motor_step",
    motor_stepping_rate,
    0,
    step_motor,
)

# MOTOR UNBINDING

MEDYAN.add_link_2mon_site!(
    s,
    :myo_motor,
    :motor_unbind,
    MEDYAN.Link2MonSiteOne(),
)

function unbind_motor(c::MEDYAN.Context, cid::Integer)
    maybe_nearby_mon_site = MEDYAN.pickrandomlink_2mon_site(
        c,
        cid,
        myo_motor_id,
        motor_binding_id,
    )
    if isnothing(maybe_nearby_mon_site)
        return false # pick was rejected
    end
    link_id, myo_end, actin_name = maybe_nearby_mon_site
    motor_state = link_2mon_state(c, myo_motor_id, link_id)
    parent_link_id = motor_state.chemstate.parentid
    parent_link_state = link_2mon_state(c, myo_fil_end_id, parent_link_id)

    numUnbound::Int = parent_link_state.chemstate.numUnbound
    numBound::Int = parent_link_state.chemstate.numBound
    @assert numBound ≥ 1
    m_pos, m_plusvec = mon_position_plusvector(c, myo_end)
    a_pos, a_plusvec = mon_position_plusvector(c, actin_name)
    # get the forces and energies if the motor were to bind.
    E, mf_sim, pf_sim, = MEDYAN.link_2mon_force(
        motor_state.mechstate,
        myo_motor_mech_params,
        m_pos, a_pos, m_plusvec, a_plusvec,
    )
    # TODO add catch-slip dynamics here.
    # update the myo_fil_end link2mon number of bound and unbound motors
    chem_setlink_2mon_state!(
        c,
        myo_fil_end_id,
        parent_link_id,
        @set(parent_link_state.chemstate = (;numBound=numBound-1, numUnbound=numUnbound+1)),
    )
    # update the state of the bound monomer, setting it to bound to the myo_fil_end link2mon
    chem_setmonomerstate!(c, actin_name, actin_middle_state)
    # add a myo_motor link2mon between the monomer and the myo_fil_end link2mon myo filament monomer.
    # This will be used to apply a mechanical force to the myo filament monomer
    chem_removelink_2mon!(
        c,
        myo_motor_id,
        link_id,
    )
    return true
end

motor_unbinding_rate = 1.4
addreactioncallback!(
    s,
    "link_2mon_site.myo_motor.motor_unbind",
    motor_unbinding_rate,
    0,
    unbind_motor,
)

vis = Visualizer()

grid = CubicGrid((2,2,2),500.0)
begin
    c = MEDYAN.Context(s, grid; check_sitecount_error=true)
    # Add an actin filament
    num_monomers = 200
    actin_len = num_monomers * MEDYAN.ACTIN_FIL_PARAMS.spacing
    chem_newfilament!(c,
        ftid=s.filament.actin,
        monomerstates=fill(s.state.actin.middle, num_monomers),
        node_mids=[0,],
        nodepositions= [
            SA[-actin_len/2, 0.0, 0.0],
            SA[+actin_len/2, 0.0, 0.0],
        ]
    )
    # Number of fake myo monomers per myo filament.
    # spacing is 20 nm, this controls the length of the rigid part of the 
    # myo filament, and is independent of the number of heads.
    num_fake_myo_monomers = 3+5+3
    myo_len = num_fake_myo_monomers * myo_spacing
    myo_fid = chem_newfilament!(c,
        ftid=s.filament.myo,
        monomerstates=fill(0x01, num_fake_myo_monomers),
        node_mids=[0,],
        nodepositions= [
            SA[0.0, -20.0-myo_len, 0.0],
            SA[0.0, -20.0, 0.0],
        ]
    )
    myo_plus_end = MonomerName(s.filament.myo, myo_fid, num_fake_myo_monomers-1)
    chem_newlink_2mon!(
        c,
        myo_fil_end_id,
        myo_plus_end => myo_plus_end;
        changedchemstate = (;numUnbound=4,),
    )
end

for i in 1:100
    # sleep(0.1)
    draw_context!(vis, c, s)
    for i in 1:100
        MEDYAN.minimize_energy!(c; brownian_motion_time=1E-3)
        MEDYAN.run_chemistry!(c, 1E-3)
    end
end