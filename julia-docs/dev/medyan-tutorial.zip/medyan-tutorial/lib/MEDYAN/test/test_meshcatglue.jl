using MEDYAN
using Test
using MeshCat

@testset "drawcontext! compiles" begin
    vis = Visualizer()
    c, systemdefs, = MEDYAN.example_all_sites_context(; check_sitecount_error=true)
    MEDYAN.drawcontext!(vis, c, systemdefs)
    MEDYAN.drawdiffusing!(vis["diffusing"], c.grid, c.chemistryengine, systemdefs)
    MEDYAN.draw_decimated_2mon_sites!(vis["decimated_2mon_sites"], c, systemdefs)
    delete!(vis)
    vis = nothing
end