using MEDYAN
using Test

@testset "example_all_sites_context compiles" begin
    # Check  `example_all_sites_context` compiles
    startc, s,= MEDYAN.example_all_sites_context(; check_sitecount_error=true)
    MEDYAN.assert_invariants(startc)
    # Check deepcopy works
    MEDYAN.assert_invariants(deepcopy(startc))
end