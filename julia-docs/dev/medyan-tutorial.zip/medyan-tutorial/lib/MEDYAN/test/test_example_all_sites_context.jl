using MEDYAN
using Test

@testset "example_all_sites_context compiles" begin
    # Check  `example_all_sites_context` compiles
    startc, s,= MEDYAN.example_all_sites_context(; check_sitecount_error=true)
end