using MEDYAN
using Test
using StaticArrays
using LinearAlgebra

@testset "internal forces" begin
    L = 4
    grid = CubicGrid(SA[L,L,L], 500.0)
    x_dir = SA[1.0, 0.0, 0.0]
    y_dir = SA[0.0, 1.0, 0.0]
    z_dir = SA[0.0, 0.0, 1.0]
    @testset "cylinder_volume_exclusion" begin
        c = MEDYAN.example_actin_mech_context(grid; max_cylinder_force=3000.0)
        monomer_len = 2.7
        nmons = 10
        fila_len = monomer_len*nmons
        gap = 4.0
        make_fila!(c;
            mono_states=ones(UInt8, nmons),
            node_mids=[0],
            node_positions=[SA[0, -fila_len/2, -gap/2], SA[0, +fila_len/2, -gap/2]]
        )
        make_fila!(c;
            mono_states=ones(UInt8, nmons),
            node_mids=[0],
            node_positions=[SA[0, -fila_len/2, +gap/2], SA[0, +fila_len/2, +gap/2]]
        )

        expected_compression = 2000.0
        fc = MEDYAN.ForceContext(c)
        out = MEDYAN.get_cylinder_volume_exclusion_internal_forces!(z_dir, 0.0, fc, fc.x0)
        @test length(out) == 1
        @test norm(out[1].f - SA[0.0, 0.0, -expected_compression]) < 1E-3
        @test norm(out[1].r) < 1E-3

        out = MEDYAN.get_cylinder_volume_exclusion_internal_forces!(z_dir, 100.0, fc, fc.x0)
        @test length(out) == 0

        out = MEDYAN.get_cylinder_volume_exclusion_internal_forces!(-z_dir, 1.0, fc, fc.x0)
        @test length(out) == 1
        @test norm(out[1].f - SA[0.0, 0.0, +expected_compression]) < 1E-3
        @test norm(out[1].r - SA[0.0, 0.0, -1.0]) < 1E-3

        out = MEDYAN.get_cylinder_volume_exclusion_internal_forces!(y_dir, 0.0, fc, fc.x0)
        @test length(out) == 1
        @test norm(out[1].f - SA[0.0, 0.0, 0.0]) < 1E-3
        @test norm(out[1].r - SA[0.0, 0.0, 0.0]) < 1E-3
    end
    @testset "bond" begin
        c = MEDYAN.example_actin_mech_context(grid)
        monomer_len = 2.7
        nmons = 10
        gap = 10.0
        fila_len = monomer_len*nmons
        ftag1 = make_fila!(c;
            mono_states=ones(UInt8, nmons),
            node_mids=[0],
            node_positions=[SA[0, 0, -fila_len - gap/2], SA[0, 0, -gap/2]]
        )
        ftag2 = make_fila!(c;
            mono_states=ones(UInt8, nmons),
            node_mids=[0],
            node_positions=[SA[0, 0, +fila_len + gap/2], SA[0, 0, +gap/2]]
        )
        myL0 = 1.0
        myk = 3.0
        make_link!(c;
            type= :fila_mono_distance,
            places= (FilaMonoIdx(c, ftag1), FilaMonoIdx(c, ftag2)),
            bond_states= ((;k=myk, L0=myL0),),
        )
        expected_tension = myk*(monomer_len + gap - myL0)

        fc = MEDYAN.ForceContext(c)
        out = MEDYAN.get_bond_internal_forces(z_dir, 0.0, fc, fc.x0)
        @test length(out) == 1
        @test norm(out[1].f - SA[0.0, 0.0, expected_tension]) < 1E-3
        @test norm(out[1].r) < 1E-3
    end
    @testset "stretching" begin
        c = MEDYAN.example_actin_mech_context(grid)
        monomer_len = 2.7
        nmons = 10
        gap = 0.5
        fila_len = (monomer_len+gap)*nmons
        make_fila!(c;
            mono_states=ones(UInt8, nmons),
            node_mids=[0],
            node_positions=[SA[0, 0, -fila_len/2], SA[0, 0, +fila_len/2]]
        )
        expected_tension = MEDYAN.ACTIN_FIL_PARAMS.klength*gap

        fc = MEDYAN.ForceContext(c)
        out = MEDYAN.get_stretching_internal_forces(z_dir, 0.0, fc, fc.x0)
        @test length(out) == 1
        @test norm(out[1].f - SA[0.0, 0.0, expected_tension]) < 1E-3
        @test norm(out[1].r) < 1E-3
    end
    @testset "bending" begin
        c = MEDYAN.example_actin_mech_context(grid)
        monomer_len = 2.7
        nmons = 80
        fila_len = (monomer_len)*nmons
        make_fila!(c;
            mono_states=ones(UInt8, nmons),
            node_mids=[0,40,80],
            node_positions=[
                SA[-fila_len/2*√(2)/2, -fila_len/2*√(2)/2, 0],
                SA[0, 0, 0],
                SA[+fila_len/2*√(2)/2, -fila_len/2*√(2)/2, 0],
            ]
        )
        expect_y_tension = MEDYAN.ACTIN_FIL_PARAMS.kangle/40/(fila_len/2)*sqrt(2)

        fc = MEDYAN.ForceContext(c)
        out = MEDYAN.get_bending_internal_forces(y_dir, -1.0, fc, fc.x0)
        @test length(out) == 1
        @test norm(out[1].f - SA[0.0, expect_y_tension, 0.0]) < 1E-3
        @test norm(out[1].r - SA[0, -1, 0]) < 1E-3

        out = MEDYAN.get_bending_internal_forces(-y_dir, +1.0, fc, fc.x0)
        @test length(out) == 1
        @test norm(out[1].f - SA[0.0, -expect_y_tension, 0.0]) < 1E-3
        @test norm(out[1].r - SA[0, -1, 0]) < 1E-3

        out = MEDYAN.get_bending_internal_forces(x_dir, -0.001, fc, fc.x0)
        @test length(out) == 1
        @test norm(out[1].f - SA[-expect_y_tension/2, expect_y_tension/2, 0.0]) < 1E-3
        @test norm(out[1].r - SA[-0.001, -fila_len/2/sqrt(2)*4/6, 0]) < 1E-1
    end
end
