using MEDYAN
using StaticArrays
using Test

@testset "Third party patches" begin

end