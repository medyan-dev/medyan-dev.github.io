using MEDYAN
import SmallZarrGroups
using Test
using StaticArrays



function snapshot_load_write_compare(c::MEDYAN.Context, original_snapshot::SmallZarrGroups.ZGroup; kwargs...)
    c_copy = deepcopy(c)
    MEDYAN.load_snapshot!(c_copy,original_snapshot)
    new_snapshot = MEDYAN.snapshot(c_copy;kwargs...)
    SmallZarrGroups.@test_equal original_snapshot new_snapshot
end


@testset "snapshots" begin
    @testset "empty system saving" begin
        s = MEDYAN.SysDef(MEDYAN.AgentNames())
        grid= CubicGrid((3,1,1),500.0)
        cinit= MEDYAN.Context(s,grid;)
        c = deepcopy(cinit)
        g1 = MEDYAN.snapshot(c)
        snapshot_load_write_compare(cinit,g1)
    end
    @testset "empty context saving" begin
        cinit = MEDYAN.example_actin_mech_context(CubicGrid((1,1,1),500.0))
        c = deepcopy(cinit)
        g1 = MEDYAN.snapshot(c)
        @test VersionNumber(SmallZarrGroups.attrs(g1)["version"]) == MEDYAN.SNAPSHOT_VERSION
        snapshot_load_write_compare(cinit,g1)
    end
    @testset "filament context saving" begin
        cinit = MEDYAN.example_actin_mech_context(CubicGrid((1,1,1),500.0))
        c = deepcopy(cinit)
        monomerstates= ones(MonomerState,49)
        nodepositions1 = [SA[70.0,200.0,200.0], SA[70.0+49*2.7,200.0,200.0]]
        fida1 = chem_newfilament!(c; ftid=1,monomerstates,nodepositions=nodepositions1,node_mids=[1,])
        g1 = MEDYAN.snapshot(c)
        @test Set(keys(g1)) == Set(["mechboundary","filaments"])
        snapshot_load_write_compare(cinit,g1)
        snapshot_load_write_compare(c,g1)
    end
    @testset "complex context saving" begin
        cinit, s = MEDYAN.example_all_sites_context()
        c = deepcopy(cinit)
        cempty = deepcopy(cinit)
        empty!(cempty)
        emptygroup = MEDYAN.snapshot(cempty)
        @test Set(keys(emptygroup)) == Set(["diffusingcounts","fixedcounts"])
        fullgroup = MEDYAN.snapshot(c)
        @test Set(keys(fullgroup)) == Set(["chemboundary","mechboundary","filaments","membranes","link_2mons","diffusingcounts","fixedcounts"])
        snapshot_load_write_compare(cinit,fullgroup)
        snapshot_load_write_compare(cempty,fullgroup)
    end
    # @testset "Compare MEDYAN.example_all_sites_context() to example_all_sites_context.zarr" begin
    #     saved_snapshot = SmallZarrGroups.load_dir(joinpath(@__DIR__, "example_all_sites_context.zarr"))
    #     c, s = MEDYAN.example_all_sites_context()
    #     new_snapshot = MEDYAN.snapshot(c)
    #     SmallZarrGroups.@test_equal saved_snapshot new_snapshot
    #     #= Run the following to save a new example snapshot if it needs updates
    #     using MEDYAN
    #     using SmallZarrGroups
    #     c, s = MEDYAN.example_all_sites_context();
    #     snapshot = MEDYAN.snapshot(c)
    #     rm(joinpath(@__DIR__, "example_all_sites_context.zarr"); recursive=true, force=true)
    #     SmallZarrGroups.save_dir(joinpath(@__DIR__, "example_all_sites_context.zarr"), snapshot)
    #     =#
    # end
end