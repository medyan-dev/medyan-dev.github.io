using FixedPointNumbers
using MEDYAN
using StaticArrays
using StructArrays
using Test

@testset "Membrane mesh" begin
    speciesnames1 = (:s1, :s2, :s3)
    speciesnames2 = ()
    membranesitenames1 = (:ms1, :ms2)
    membranesitenames2 = ()
    DummyCopyNumbers1Type = NamedTuple{speciesnames1, NTuple{length(speciesnames1), Int}}
    DummyCopyNumbers2Type = NamedTuple{speciesnames2, NTuple{length(speciesnames2), Int}}
    DummySpeciesFixed1NT  = NamedTuple{speciesnames1, NTuple{length(speciesnames1), Q31f32}}
    DummySpeciesFixed2NT  = NamedTuple{speciesnames2, NTuple{length(speciesnames2), Q31f32}}
    DummyMembraneSiteCount1Type = NamedTuple{membranesitenames1, NTuple{length(membranesitenames1), Q31f32}}
    DummyMembraneSiteCount2Type = NamedTuple{membranesitenames2, NTuple{length(membranesitenames2), Q31f32}}
    VA1 = MEDYAN.MembraneMeshVA{DummyCopyNumbers1Type, DummyMembraneSiteCount1Type}
    VA2 = MEDYAN.MembraneMeshVA{DummyCopyNumbers2Type, DummyMembraneSiteCount2Type}
    @test  MEDYAN.func_attr_unwrap(VA1)(DummyCopyNumbers1Type)
    @test !MEDYAN.func_attr_unwrap(VA2)(DummyCopyNumbers2Type)
    @test  MEDYAN.func_attr_unwrap(VA1)(DummyMembraneSiteCount1Type)
    @test !MEDYAN.func_attr_unwrap(VA2)(DummyMembraneSiteCount2Type)
    @test  MEDYAN.func_attr_unwrap(MEDYAN.MembraneMeshHA{DummySpeciesFixed1NT})(DummySpeciesFixed1NT)
    @test !MEDYAN.func_attr_unwrap(MEDYAN.MembraneMeshHA{DummySpeciesFixed2NT})(DummySpeciesFixed2NT)

    MM1 = gettype_membranemesh(Val(speciesnames1), Val(membranesitenames1))
    MM2 = gettype_membranemesh(Val(speciesnames2), Val(membranesitenames2))
    @test isconcretetype(MM1)
    @test isconcretetype(MM2)
    @test MEDYAN.attrtype_vertex(  MM1) === VA1
    @test MEDYAN.attrtype_vertex(  MM2) === VA2
    @test MEDYAN.attrtype_halfedge(MM1) === MEDYAN.MembraneMeshHA{DummySpeciesFixed1NT}
    @test MEDYAN.attrtype_halfedge(MM2) === MEDYAN.MembraneMeshHA{DummySpeciesFixed2NT}
    @test MEDYAN.attrtype_edge(    MM1) === MEDYAN.MembraneMeshEA
    @test MEDYAN.attrtype_triangle(MM1) === MEDYAN.MembraneMeshTA
    @test MEDYAN.attrtype_border(  MM1) === MEDYAN.DefaultHalfedgeMeshElementAttr
    @test MEDYAN.attrtype_meta(    MM1) === MEDYAN.MembraneMeshMA

    @test MEDYAN.get_speciesnames(MM1) === speciesnames1
    @test MEDYAN.get_speciesnames(MM2) === speciesnames2
    @test MEDYAN.get_numdiffusingspecies(MM1) == length(speciesnames1)
    @test MEDYAN.get_numdiffusingspecies(MM2) == length(speciesnames2)
    @test MEDYAN.get_membranesitenames(MM1) === membranesitenames1
    @test MEDYAN.get_membranesitenames(MM2) === membranesitenames2
    @test MEDYAN.get_nummembranesites(MM1) == length(membranesitenames1)
    @test MEDYAN.get_nummembranesites(MM2) == length(membranesitenames2)

    @testset "Membrane mesh attribute accessors" begin
        vertlist = [SA[0,0,0], SA[1,0,0], SA[0,1,0]]
        trilist = [SA[1,2,3]]
        m = MEDYAN.create_membranemesh()
        MEDYAN.initmesh!(m, (; vertlist, trilist))
        @test MEDYAN.get_coords(m, MEDYAN.IT(1)) ∈ SA[vertlist[SA[1,2,3]], vertlist[SA[2,3,1]], vertlist[SA[3,1,2]]]
    end

    @testset "Membrane mesh initialization" begin
        # Simple initialization.
        vertlist = [SA[0,0,0], SA[1,0,0], SA[0,1,0], SA[1,1,0]]
        trilist = [SA[1,2,3], SA[3,2,4]]
        m = MEDYAN.create_membranemesh(Val(speciesnames1), Val(membranesitenames1))
        MEDYAN.initmesh!(m, (; vertlist, trilist))
        # Zero copy numbers.
        @test all(==(0), m.vertices.attr.copynumbers.s1)
        @test all(==(0), m.vertices.attr.copynumbers.s2)
        @test all(==(0), m.vertices.attr.copynumbers.s3)
        # Zero diffusion propensities.
        @test all(==(0), m.halfedges.attr.diffusion_a.s1)
        @test all(==(0), m.halfedges.attr.diffusion_a.s2)
        @test all(==(0), m.halfedges.attr.diffusion_a.s3)
        @test all(==(0), m.vertices.attr.outdiffusion_a)
        # Zero site counts.
        @test all(==(0), m.vertices.attr.contrib_membranesitecount.ms1)
        @test all(==(0), m.vertices.attr.contrib_membranesitecount.ms2)
    end

    @testset "Membrane mesh modifications" begin
        function getm()
            local m = MEDYAN.create_membranemesh(Val(speciesnames1), Val(membranesitenames1))
            MEDYAN.initmesh!(m, (;
                vertlist = [SA[0,0,0], SA[1,0,0], SA[0,1,0], SA[1,1,0]],
                trilist = [SA[1,2,3], SA[3,2,4]],
                copynumbers = StructArray((
                    s1 = [0, 0, 1, 1],
                    s2 = [2, 2, 2, 2],
                    s3 = [100, 120, 150, 200],
                )),
            ))
            m
        end

        # Test edge splitting.
        m = getm()
        emid = MEDYAN.IE(findfirst(eindex->!MEDYAN.onborder(m, MEDYAN.IE(eindex)), eachindex(m.edges)))
        MEDYAN.membranemesh_splitfunc!(m, emid, SA[1/2, 1/2, 1e-5]) # Make new v1/v3 areas slightly larger than half the original values.
        @test m.vertices.attr.copynumbers.s1 == [0, 0, 0, 1, 1]
        @test m.vertices.attr.copynumbers.s2 == [2, 1, 1, 2, 2]
        @test m.vertices.attr.copynumbers.s3 == [100, 60, 75, 200, 135]
        @test all(==(0), m.vertices.attr.outdiffusion_a)
        @test all(==(0), m.halfedges.attr.diffusion_a.s1)
        @test all(==(0), m.halfedges.attr.diffusion_a.s2)
        @test all(==(0), m.halfedges.attr.diffusion_a.s3)
        @test all(==(0), m.vertices.attr.contrib_membranesitecount.ms1)
        @test all(==(0), m.vertices.attr.contrib_membranesitecount.ms2)

        # Collapsed the splitted edge.
        # Find halfedge from 2 to 5, collapse it and move the preserved vertex (5 -> 2) to where vertex 2 was.
        h25 = MEDYAN.IH(findfirst(
            hindex -> (hindex |> MEDYAN.IH |> MEDYAN.oppo(m) |> MEDYAN.target(m)).value == 2 && (hindex |> MEDYAN.IH |> MEDYAN.target(m)).value == 5,
            eachindex(m.halfedges)
        ))
        MEDYAN.membranemesh_collapsefunc!(m, h25, SA[1,0,0])
        @test m.vertices.attr.copynumbers.s1 == [0, 1, 0, 1]
        @test m.vertices.attr.copynumbers.s2 == [2, 3, 1, 2]
        @test m.vertices.attr.copynumbers.s3 == [100+22, 129, 75+22, 200+22]
    end

    @testset "Membrane mesh coordinate index caching" begin
        local m = MEDYAN.create_membranemesh()
        MEDYAN.initmesh!(m, (;
            vertlist = [SA[0,0,0], SA[1,0,0], SA[0,1,0], SA[1,1,0]],
            trilist = [SA[1,2,3], SA[3,2,4]],
        ))
        sm = MEDYAN.StaticHalfedgeMesh(m)
        MEDYAN.cachecoordindices!(sm, 100)

        @test m.vertices.attr.cached_xcoordindex == [101, 104, 107, 110]
        let xcoordindices = m.edges.attr.cached_xcoordindices[MEDYAN.edge(m, MEDYAN.IV(2), MEDYAN.IV(3)).value]
            @test xcoordindices ∈ ([104,107], [107,104])
        end
        let xcoordindices = m.triangles.attr.cached_xcoordindices[1]
            @test xcoordindices ∈ ([101,104,107], [104,107,101], [107,101,104])
        end
    end

    @testset "Mesh vertex pinning" begin
        local m = MEDYAN.create_membranemesh()
        # Create shape: tetrahedra at top, with triangular prism below, without bottom surface.
        MEDYAN.initmesh!_vertex_triangle(m, 7, [SA[1,2,3], SA[1,3,4], SA[1,4,2],  SA[2,5,3], SA[3,5,6], SA[3,6,4], SA[4,6,7], SA[4,7,2], SA[2,7,5]])
        m.vertices.attr.coord .= reinterpret(SVector{3,Float64}, collect(Float64, 1:7*3))

        let
            MEDYAN.updatevertexpinning!(m, Val(:none))
            @test all(!, m.vertices.attr.pinned)
        end
        let
            MEDYAN.updatevertexpinning!(m, Val(:border1))
            pinnedindices = filter(i -> m.vertices.attr.pinned[i], 1:7)
            @test pinnedindices == [5,6,7]
            @test view(m.vertices.attr.pinned_coord, pinnedindices) == view(m.vertices.attr.coord, pinnedindices)
        end
        let
            MEDYAN.updatevertexpinning!(m, Val(:border2))
            pinnedindices = filter(i -> m.vertices.attr.pinned[i], 1:7)
            @test pinnedindices == [2,3,4,5,6,7]
            @test view(m.vertices.attr.pinned_coord, pinnedindices) == view(m.vertices.attr.coord, pinnedindices)
        end
    end
end
