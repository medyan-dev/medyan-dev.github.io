using LinearAlgebra
using MEDYAN
using StaticArrays
using Test

@testset "Mesh initialization" begin
    @testset "Mesh generation" begin
        # Ellipsoid.
        let (vs, ts) = MEDYAN.genmesh(MeshInitEllipsoid(center=SA[1,2,3], halfaxes=SA[3,4,5]))
            nv = length(vs)
            nt = length(ts)
            @test nv > 0
            @test nt > 0
            ne = nt * 3 ÷ 2
            @test nv + nt - ne == 2

            xmin, xmax = extrema(v->v[1], vs)
            @test isapprox(xmin, -2; atol=1e-2)
            @test isapprox(xmax, 4; atol=1e-2)
        end

        # Plane
        let (vs, ts) = MEDYAN.genmesh(MeshInitPlane(boxorigin=SA[-1,-1,-1], boxwidths=SA[1,1,1], normal=SA[1,1,1], normal_multiplier_from_origin=-0.5))
            nv = length(vs)
            nt = length(ts)
            @test nv > 0
            @test nt > 0

            for i ∈ 1:100:nv
                @test isapprox(dot(vs[i]-SA[-1/2,-1/2,-1/2], SA[1,1,1]), 0; atol=1e-5)
            end
        end
    end

    @testset "Mesh init with data" begin
        val_speciesnames = Val((:s1, :s2))
        val_membranesitenames = Val((:ms1,))
        # A triangle with species.
        let m = MEDYAN.create_membranemesh(val_speciesnames, val_membranesitenames)

            vertlist = [SA[1,2,3], SA[2,3,4], SA[3,4,5]]
            trilist = [SA[1,2,3]]
            copynumbers     = (s1=[101,102,103], s2=[201,202,203])
            copynumbersokay = (s1=[104,105,106], s2=[204,205,206], s3=[301,302,303])
            copynumbersbad  = (s1=[107,108,109],)

            MEDYAN.initmesh!(m, (; vertlist, trilist, copynumbers))
            @test m.vertices.attr.coord == vertlist
            @test m.vertices.attr.coord !== vertlist
            @test m.vertices.attr.copynumbers.s1 == copynumbers.s1
            @test m.vertices.attr.copynumbers.s1 !== copynumbers.s1
            @test m.vertices.attr.copynumbers.s2 == copynumbers.s2
            @test m.vertices.attr.copynumbers.s2 !== copynumbers.s2
            @test all(==(0), m.halfedges.attr.diffusion_a.s1)
            @test all(==(0), m.halfedges.attr.diffusion_a.s2)
            @test all(==(0), m.vertices.attr.outdiffusion_a)
            @test all(==(0), m.vertices.attr.contrib_membranesitecount.ms1)

            MEDYAN.initmesh!(m, (; vertlist, trilist, copynumbers=copynumbersokay))
            @test m.vertices.attr.copynumbers.s1 == copynumbersokay.s1
            @test m.vertices.attr.copynumbers.s2 == copynumbersokay.s2

            @test_throws ErrorException MEDYAN.initmesh!(m, (; vertlist, trilist, copynumbers=copynumbersbad))

            # Initialize vertex IDs as well.
            let
                id = [1, 30, 5]
                MEDYAN.initmesh!(m, (; vertlist, trilist, id))
                @test m.vertices.attr.id == id
                @test length(m.metaattr.id2index_vertex) == 3
                @test [vindex for (vid, vindex) ∈ m.metaattr.id2index_vertex] == [1, 3, 2]

                # Default IDs.
                MEDYAN.initmesh!(m, (; vertlist, trilist))
                @test m.vertices.attr.id == 1:3
                @test length(m.metaattr.id2index_vertex) == 3
                @test [vindex for (vid, vindex) ∈ m.metaattr.id2index_vertex] == 1:3
            end
        end

        # Generated mesh should have attributes correctly initialized, such as zero copy numbers.
        let m = MEDYAN.create_membranemesh(val_speciesnames, val_membranesitenames)
            MEDYAN.initmesh!(m, MeshInitPlane(boxorigin=SA[-1,-1,-1], boxwidths=SA[1,1,1], normal=SA[1,1,1], normal_multiplier_from_origin=-0.5))
            nv = length(m.vertices)
            @test nv > 0

            # Copy numbers should be zero.
            for i ∈ 1:100:nv
                @test m.vertices.attr.copynumbers.s1[i] == 0
                @test m.vertices.attr.copynumbers.s2[i] == 0
            end

            # Vertex IDs should have been correctly assigned.
            for i ∈ 1:100:nv
                local id = m.vertices.attr.id[i]
                @test m.metaattr.id2index_vertex[id] == i
            end
        end        
    end
end
