using LinearAlgebra
using Test
using StaticArrays
using MEDYAN

import MEDYAN:
    IV, IH, IE, IT, IB,
    target, edge, next, prev, oppo, polygon, triangle, border, halfedge, onborder, degree

@testset "Membrane geometry" begin
    M = MEDYAN
    DM = MEDYAN.DynamicHalfedgeMesh
    SM = MEDYAN.StaticHalfedgeMesh
    DA = MEDYAN.DefaultHalfedgeMeshElementAttr
    VA = @NamedTuple{
        cached_xcoordindex::Int,
        astar::Float64,
        g_astar::SVector{3, Float64},
        g_volume::SVector{3, Float64},
        curv::Float64,
        curv2::Float64,
        g_curv::SVector{3, Float64},
        g_curv2::SVector{3, Float64},
    }
    HA = @NamedTuple{
        g_triangle_area::SVector{3, Float64},
        cotθ::Float64,
        g_cotθ::SVector{3, SVector{3, Float64}},
        # Derivative of astar of source vertex on target vertex.
        g_ontarget_sourceastar::SVector{3, Float64},
        # Derivative of curv of source vertex on target vertex.
        g_ontarget_sourcecurv::SVector{3, Float64},
        # Derivative of curv2 of source vertex on target vertex.
        g_ontarget_sourcecurv2::SVector{3, Float64},
    }
    EA = @NamedTuple{
        cached_xcoordindices::SVector{2, Int},
        length::Float64,
        normal_angle::Float64,
    }
    TA = @NamedTuple{
        cached_xcoordindices::SVector{3, Int},
        area::Float64,
        cone_volume::Float64,
    }

    ≊(a,b) = isapprox(a, b; atol = 1E-9)
    invr2 = 1/sqrt(2)

    # Initialize 2 triangles.
    let
        # Initialize 4 vertices.
        dm = DM(VA, HA, EA, TA, DA, nothing)
        MEDYAN.initmesh!_vertex_triangle(dm, 4, [SA[1,2,3], SA[3,2,4]])
        sm = SM(dm)
        MEDYAN.cachecoordindices!(sm)

        # Define coordinates.
        x = Float64[
            -1, 0, 1,
            0, -1, 1,
            0, 1, 1,
            invr2, 0, invr2 + 1,
        ]

        # Some convenient variables.
        emid = IE(findfirst(k -> !onborder(dm, IE(k)), 1:length(dm.edges)))
        hmid_to3 = halfedge(dm, emid)
        if target(dm, hmid_to3).value != 3
            hmid_to3 = oppo(dm, hmid_to3)
        end
        hmid_to2 = oppo(dm, hmid_to3)
        @test target(dm, hmid_to3).value == 3
        @test target(dm, hmid_to2).value == 2

        # Compute geometry.
        MEDYAN.compute_geometry!(sm, x, Val(MEDYAN.meshcurv_mem3dg))
        @test sm.edges.attr.length[emid.value] ≈ 2
        @test sm.edges.attr.normal_angle[emid.value] ≈ -π/4

        @test sm.triangles.attr.area[1] ≈ 1
        @test sm.triangles.attr.area[2] ≈ 1
        @test sm.triangles.attr.cone_volume[1] ≈ 1/3
        @test sm.triangles.attr.cone_volume[2] ≈ 1/(3*sqrt(2))

        @test sm.halfedges.attr.g_triangle_area[hmid_to3.value] ≊ SA[1/2, 1/2, 0]
        @test sm.halfedges.attr.g_triangle_area[next(dm,hmid_to3).value] ≊ SA[-1, 0, 0]
        @test sm.halfedges.attr.g_triangle_area[prev(dm,hmid_to3).value] ≊ SA[1/2, -1/2, 0]
        @test sm.halfedges.attr.g_triangle_area[hmid_to2.value] ≊ SA[-1/(2*sqrt(2)), -1/2, -1/(2*sqrt(2))]
        @test sm.halfedges.attr.g_triangle_area[next(dm,hmid_to2).value] ≊ SA[1/sqrt(2), 0, 1/sqrt(2)]
        @test sm.halfedges.attr.g_triangle_area[prev(dm,hmid_to2).value] ≊ SA[-1/(2*sqrt(2)), 1/2, -1/(2*sqrt(2))]
        @test sm.halfedges.attr.cotθ[hmid_to3.value] ≊ 1
        @test sm.halfedges.attr.cotθ[next(dm,hmid_to3).value] ≊ 0
        @test sm.halfedges.attr.cotθ[prev(dm,hmid_to3).value] ≊ 1
        @test sm.halfedges.attr.cotθ[hmid_to2.value] ≊ 1
        @test sm.halfedges.attr.cotθ[next(dm,hmid_to2).value] ≊ 0
        @test sm.halfedges.attr.cotθ[prev(dm,hmid_to2).value] ≊ 1
        @test sm.halfedges.attr.g_cotθ[hmid_to3.value][1] ≊ SA[-1, 0, 0]
        @test sm.halfedges.attr.g_cotθ[hmid_to3.value][2] ≊ SA[0, 1, 0]
        @test sm.halfedges.attr.g_cotθ[hmid_to3.value][3] ≊ SA[1, -1, 0]
        @test sm.halfedges.attr.g_cotθ[next(dm,hmid_to3).value][1] ≊ SA[1/2, -1/2, 0]
        @test sm.halfedges.attr.g_cotθ[next(dm,hmid_to3).value][2] ≊ SA[-1, 0, 0]
        @test sm.halfedges.attr.g_cotθ[next(dm,hmid_to3).value][3] ≊ SA[1/2, 1/2, 0]

        @test sm.vertices.attr.astar[1] ≈ 1
        @test sm.vertices.attr.astar[2] ≈ 2
        @test sm.vertices.attr.astar[3] ≈ 2
        @test sm.vertices.attr.astar[4] ≈ 1
        @test sm.vertices.attr.g_astar[1] ≊ SA[-1,0,0]
        @test sm.vertices.attr.g_astar[2] ≊ SA[1/2-1/(2*sqrt(2)), -1, -1/(2*sqrt(2))]
        @test sm.vertices.attr.g_astar[3] ≊ SA[1/2-1/(2*sqrt(2)), 1, -1/(2*sqrt(2))]
        @test sm.vertices.attr.g_astar[4] ≊ SA[1/sqrt(2), 0, 1/sqrt(2)]
        @test sm.halfedges.attr.g_ontarget_sourceastar[hmid_to3.value] ≊ sm.vertices.attr.g_astar[3]
        @test sm.halfedges.attr.g_ontarget_sourceastar[next(dm,hmid_to3).value] ≊ sm.vertices.attr.g_astar[1]
        @test sm.halfedges.attr.g_ontarget_sourceastar[oppo(dm,next(dm,hmid_to3)).value] ≊ SA[1/2, 1/2, 0]

        @test sm.vertices.attr.g_volume[1] ≊ SA[-1/3, 0, 0]
        @test sm.vertices.attr.g_volume[2] ≊ (SA[1, -1, 1] + SA[-1-invr2, -invr2, invr2]) / 6
        @test sm.vertices.attr.g_volume[3] ≊ (SA[1, 1, 1] + SA[-1-invr2, invr2, invr2]) / 6
        @test sm.vertices.attr.g_volume[4] ≊ SA[1/3, 0, 0]
    end

    # Octahedron.
    let
        # Initialize 6 vertices.
        dm = DM(VA, HA, EA, TA, DA, nothing)
        MEDYAN.initmesh!_vertex_triangle(dm, 6, [SA[1,2,3], SA[1,3,4], SA[1,4,5], SA[1,5,2], SA[6,5,4], SA[6,4,3], SA[6,3,2], SA[6,2,5]])
        sm = SM(dm)
        MEDYAN.cachecoordindices!(sm)

        # Define coordinates.
        x = Float64[
            0, 0, 1,
            0, 1, 0,
            -1, 0, 0,
            0, -1, 0,
            1, 0, 0,
            0, 0, -1,
        ]

        # If all vertices expand uniformly, the curvature should decrease uniformly.
        # This function tests whether the statement above is true.
        function test_uniform_curvature_change(iv::Int, g::Symbol, gn::Symbol, expected::Number)
            v = MEDYAN.IV(iv)
            xi = sm.vertices.attr.cached_xcoordindex[iv]
            c = x[SVector{3}(xi:xi+2)]
            ∂R_H = 0.0
            for h ∈ MEDYAN.HalfedgesTargetingVertex(dm, v)
                h_o = oppo(dm, h)
                v_n = target(dm, h_o)
                x_n = sm.vertices.attr.cached_xcoordindex[v_n.value]
                c_n = x[SVector{3}(x_n:x_n+2)]
                ∂R_H += dot(
                    getproperty(sm.halfedges.attr, gn)[h_o.value],
                    c_n
                )
            end
            ∂R_H += dot(getproperty(sm.vertices.attr, g)[iv], c)
            @test ∂R_H ≈ expected
        end

        MEDYAN.compute_geometry!(sm, x, Val(MEDYAN.meshcurv_se))
        @test sm.vertices.attr.astar[1] ≈ 2 * sqrt(3)
        @test sm.vertices.attr.g_astar[1] ≊ SA[0, 0, 4/sqrt(3)]
        @test sm.vertices.attr.g_volume[1] ≊ SA[0, 0, 2/3]

        # se curvature uses inscribed sphere.
        for iv ∈ 1:length(sm.vertices)
            @test sm.vertices.attr.curv[iv] ≈ sqrt(3)
            test_uniform_curvature_change(iv, :g_curv, :g_ontarget_sourcecurv, -sqrt(3))
        end
        @test sm.vertices.attr.g_curv[1] ≊ SA[0, 0, 1/sqrt(3)]
        @test sm.vertices.attr.g_curv[2] ≊ SA[0, 1/sqrt(3), 0]

        MEDYAN.compute_geometry!(sm, x, Val(MEDYAN.meshcurv_se_sq))
        for iv ∈ 1:length(sm.vertices)
            @test sm.vertices.attr.curv2[iv] ≈ 3
            test_uniform_curvature_change(iv, :g_curv2, :g_ontarget_sourcecurv2, -6)
        end
        @test sm.vertices.attr.g_curv2[1] ≊ SA[0, 0, 2]
        @test sm.vertices.attr.g_curv2[2] ≊ SA[0, 2, 0]

        MEDYAN.compute_geometry!(sm, x, Val(MEDYAN.meshcurv_mem3dg))
        @test sm.edges.attr.length[1] ≈ sqrt(2)
        @test sm.edges.attr.normal_angle[1] ≈ acos(1/3)
        expected_curv_mem3dg = acos(1/3) * (3*sqrt(2)) / (2*sqrt(3))
        for iv ∈ 1:length(sm.vertices)
            @test sm.vertices.attr.curv[iv] ≈ expected_curv_mem3dg
            test_uniform_curvature_change(iv, :g_curv, :g_ontarget_sourcecurv, -expected_curv_mem3dg)
        end
    end

    # Half octahedron. (Bottomless pyramid)
    let
        # Initialize 5 vertices.
        dm = DM(VA, HA, EA, TA, DA, nothing)
        MEDYAN.initmesh!_vertex_triangle(dm, 5, [SA[1,2,3], SA[1,3,4], SA[1,4,5], SA[1,5,2]])
        sm = SM(dm)
        MEDYAN.cachecoordindices!(sm)

        # Define coordinates.
        x = Float64[
            0, 0, 1,
            0, 1, 0,
            -1, 0, 0,
            0, -1, 0,
            1, 0, 0,
        ]

        function resetcurvs()
            sm.vertices.attr.curv .= NaN
            sm.vertices.attr.curv2 .= NaN
            fill!(sm.vertices.attr.g_curv, SA[NaN,NaN,NaN])
            fill!(sm.vertices.attr.g_curv2, SA[NaN,NaN,NaN])
            fill!(sm.halfedges.attr.g_ontarget_sourcecurv, SA[NaN,NaN,NaN])
            fill!(sm.halfedges.attr.g_ontarget_sourcecurv2, SA[NaN,NaN,NaN])
        end

        # Curvatures are not defined on borders.
        # Regression (https://github.com/medyan-dev/MEDYAN.jl/issues/173).
        resetcurvs()
        MEDYAN.compute_geometry!(sm, x, Val(MEDYAN.meshcurv_se))
        @test filter(vindex->!isnan(sm.vertices.attr.curv[vindex]), eachindex(sm.vertices)) == [1]
        @test filter(vindex->!isnan(sm.vertices.attr.g_curv[vindex]), eachindex(sm.vertices)) == [1]
        hindices_notnan = filter(hindex->!isnan(sm.halfedges.attr.g_ontarget_sourcecurv[hindex]), eachindex(sm.halfedges))
        @test Set(MEDYAN.IH.(hindices_notnan)) == Set(
            MEDYAN.halfedge(dm, MEDYAN.IV(vi1), MEDYAN.IV(vi2))
            for (vi1, vi2) ∈ SA[(1,2), (1,3), (1,4), (1,5)]
        )

        resetcurvs()
        MEDYAN.compute_geometry!(sm, x, Val(MEDYAN.meshcurv_se_sq))
        @test filter(vindex->!isnan(sm.vertices.attr.curv2[vindex]), eachindex(sm.vertices)) == [1]
        @test filter(vindex->!isnan(sm.vertices.attr.g_curv2[vindex]), eachindex(sm.vertices)) == [1]
        hindices_notnan = filter(hindex->!isnan(sm.halfedges.attr.g_ontarget_sourcecurv2[hindex]), eachindex(sm.halfedges))
        @test Set(MEDYAN.IH.(hindices_notnan)) == Set(
            MEDYAN.halfedge(dm, MEDYAN.IV(vi1), MEDYAN.IV(vi2))
            for (vi1, vi2) ∈ SA[(1,2), (1,3), (1,4), (1,5)]
        )

        resetcurvs()
        MEDYAN.compute_geometry!(sm, x, Val(MEDYAN.meshcurv_mem3dg))
        @test filter(vindex->!isnan(sm.vertices.attr.curv[vindex]), eachindex(sm.vertices)) == [1]
        @test filter(vindex->!isnan(sm.vertices.attr.g_curv[vindex]), eachindex(sm.vertices)) == [1]
        hindices_notnan = filter(hindex->!isnan(sm.halfedges.attr.g_ontarget_sourcecurv[hindex]), eachindex(sm.halfedges))
        @test Set(MEDYAN.IH.(hindices_notnan)) == Set(
            MEDYAN.halfedge(dm, MEDYAN.IV(vi1), MEDYAN.IV(vi2))
            for (vi1, vi2) ∈ SA[(1,2), (1,3), (1,4), (1,5)]
        )
    end
    
end

@testset "Membrane geometry for adaptive remeshing" begin
    DM = MEDYAN.DynamicHalfedgeMesh
    DA = MEDYAN.DefaultHalfedgeMeshElementAttr
    VA = @NamedTuple{
        coord::SVector{3, Float64},
        ada_unitnormal::SVector{3, Float64},
    }
    HA = @NamedTuple{
        θ::Float64,
        cotθ::Float64,
    }
    TA = @NamedTuple{
        unitnormal::SVector{3, Float64},
    }

    ≊(a,b) = isapprox(a, b; atol = 1E-9)


    m = DM(VA, HA, DA, TA, DA, nothing)
    MEDYAN.initmesh!_vertex_triangle(m, 4, [SA[1,2,3], SA[3,2,4]])
    # Set coordinates.
    m.vertices.attr.coord[1] = SA[0,0,0]
    m.vertices.attr.coord[2] = SA[1,0,0]
    m.vertices.attr.coord[3] = SA[0,1,0]
    m.vertices.attr.coord[4] = SA[1,1,1]

    # Unit normals.
    MEDYAN.compute_all_triangle_normals_ada!(m)
    @test m.triangles.attr.unitnormal[1] ≊ SA[0,0,1]
    @test m.triangles.attr.unitnormal[2] ≊ SA[-1,-1,1] / sqrt(3)

    # Angles.
    MEDYAN.compute_all_angles_ada!(m)
    let
        h_to1 = halfedge(m, IT(1))
        while target(m, h_to1) != IV(1)
            h_to1 = next(m, h_to1)
        end
        @test m.halfedges.attr.θ[h_to1.value] ≈ π/2
        @test m.halfedges.attr.cotθ[h_to1.value] ≊ 0

        h_t1_to2 = next(m, h_to1)
        @test m.halfedges.attr.θ[h_t1_to2.value] ≈ π/4
        @test m.halfedges.attr.cotθ[h_t1_to2.value] ≈ 1

        h_t2_to2 = h_t1_to2 |> next(m) |> oppo(m)
        @test m.halfedges.attr.θ[h_t2_to2.value] ≈ π/3
        @test m.halfedges.attr.cotθ[h_t2_to2.value] ≈ 1/sqrt(3)
    end

    # Vertex unit normals.
    MEDYAN.compute_all_vertex_normals_ada!(m)
    @test m.vertices.attr.ada_unitnormal[1] ≊ SA[0,0,1]
    @test m.vertices.attr.ada_unitnormal[2] ≊ normalize(SA[-4/sqrt(3), -4/sqrt(3), 3+4/sqrt(3)])
    @test m.vertices.attr.ada_unitnormal[3] ≊ m.vertices.attr.ada_unitnormal[2]
    @test m.vertices.attr.ada_unitnormal[4] ≊ SA[-1,-1,1] / sqrt(3)
end

@testset "Membrane geometry for system" begin
    DM = MEDYAN.DynamicHalfedgeMesh
    DA = MEDYAN.DefaultHalfedgeMeshElementAttr
    VA = @NamedTuple{
        coord::SVector{3, Float64},
        pseudo_unitnormal::SVector{3, Float64},
        astar::Float64,
    }
    HA = @NamedTuple{
        θ::Float64,
        cotθ::Float64,
    }
    EA = @NamedTuple{
        pseudo_unitnormal::SVector{3, Float64},
    }
    TA = @NamedTuple{
        unitnormal::SVector{3, Float64},
        area::Float64,
    }

    ≊(a,b) = isapprox(a, b; atol = 1E-9)


    m = DM(VA, HA, EA, TA, DA, nothing)
    MEDYAN.initmesh!_vertex_triangle(m, 4, [SA[1,2,3], SA[3,2,4]])
    # Set coordinates.
    m.vertices.attr.coord[1] = SA[0,0,0]
    m.vertices.attr.coord[2] = SA[1,0,0]
    m.vertices.attr.coord[3] = SA[0,1,0]
    m.vertices.attr.coord[4] = SA[1,1,1]

    # Compute geometries.
    MEDYAN.compute_geometry!_system(m)

    let
        h_to1 = halfedge(m, IT(1))
        while target(m, h_to1) != IV(1)
            h_to1 = next(m, h_to1)
        end
        @test m.halfedges.attr.θ[h_to1.value] ≈ π/2
        @test m.halfedges.attr.cotθ[h_to1.value] ≊ 0

        h_t1_to2 = next(m, h_to1)
        @test m.halfedges.attr.θ[h_t1_to2.value] ≈ π/4
        @test m.halfedges.attr.cotθ[h_t1_to2.value] ≈ 1

        h_t2_to2 = h_t1_to2 |> next(m) |> oppo(m)
        @test m.halfedges.attr.θ[h_t2_to2.value] ≈ π/3
        @test m.halfedges.attr.cotθ[h_t2_to2.value] ≈ 1/sqrt(3)

        e_t1_to2 = edge(m, h_t1_to2)
        @test m.edges.attr.pseudo_unitnormal[e_t1_to2.value] ≊ SA[0,0,1]

        emid = h_t1_to2 |> next(m) |> edge(m)
        @test m.edges.attr.pseudo_unitnormal[emid.value] ≊ normalize(
            SA[0,0,1] +
            SA[-1,-1,1] / sqrt(3)
        )
    end

    @test m.triangles.attr.unitnormal[1] ≊ SA[0,0,1]
    @test m.triangles.attr.area[1] ≈ 1/2
    @test m.triangles.attr.unitnormal[2] ≊ SA[-1,-1,1] / sqrt(3)
    @test m.triangles.attr.area[2] ≈ sqrt(3)/2

    @test m.vertices.attr.pseudo_unitnormal[1] ≊ SA[0,0,1]
    @test m.vertices.attr.pseudo_unitnormal[2] ≊ normalize(SA[-4/sqrt(3), -4/sqrt(3), 3+4/sqrt(3)])
    @test m.vertices.attr.pseudo_unitnormal[3] ≊ m.vertices.attr.pseudo_unitnormal[2]
    @test m.vertices.attr.pseudo_unitnormal[4] ≊ SA[-1,-1,1] / sqrt(3)

    # Test adhoc geometries functions.
    @test MEDYAN.adhoc_astar(m, IV(1)) ≈ 1/2
    @test MEDYAN.adhoc_astar(m, IV(2)) ≈ 1/2 + sqrt(3)/2
    @test MEDYAN.adhoc_astar(m, IV(3)) ≈ 1/2 + sqrt(3)/2
    @test MEDYAN.adhoc_astar(m, IV(4)) ≈ sqrt(3)/2
end

@testset "Surface mesh signed distance field" begin
    m = MEDYAN.create_membranemesh()

    MEDYAN.initmesh!_vertex_triangle(m, 4, [SA[1,2,3], SA[3,2,4]])
    # Set coordinates.
    m.vertices.attr.coord[1] = SA[0,0,0]
    m.vertices.attr.coord[2] = SA[1,0,0]
    m.vertices.attr.coord[3] = SA[0,1,0]
    m.vertices.attr.coord[4] = SA[1,1,1]

    # Compute geometries.
    MEDYAN.compute_geometry!_system(m)

    # In triangle.
    @test MEDYAN.signed_distance_element(m, IT(1), SA[0.1,0.1,5]) ≈ 5
    @test MEDYAN.signed_distance_element(m, IT(2), SA[1,1,0]) ≈ -1/sqrt(3)
    # On edges.
    @test MEDYAN.signed_distance_element(m, IT(1), SA[1/2,-1/2,1/2]) ≈ 1/sqrt(2)
    @test MEDYAN.signed_distance_element(m, IT(1), SA[-1,1/2,1e-6]) ≈ 1
    @test MEDYAN.signed_distance_element(m, IT(1), SA[-1,1/2,-1e-6]) ≈ -1
    @test MEDYAN.signed_distance_element(m, IT(1), SA[1,1,1e-6]) ≈ -1/sqrt(2)
    @test MEDYAN.signed_distance_element(m, IT(2), SA[0,0,0]) ≈ 1/sqrt(2)
    @test MEDYAN.signed_distance_element(m, IT(2), SA[2,0,1+1e-8]) ≈ sqrt(3/2)
    @test MEDYAN.signed_distance_element(m, IT(2), SA[2,0,1-1e-8]) ≈ -sqrt(3/2)
    @test MEDYAN.signed_distance_element(m, IT(2), SA[1/2,10000,1/2]) ≈ -9999
    # On vertices.
    @test MEDYAN.signed_distance_element(m, IT(1), SA[-1,-1,1]) ≈ sqrt(3)
    @test MEDYAN.signed_distance_element(m, IT(1), SA[2,1/2,0]) ≈ -sqrt(5)/2
    @test MEDYAN.signed_distance_element(m, IT(1), SA[1/2,2,0]) ≈ -sqrt(5)/2
    @test MEDYAN.signed_distance_element(m, IT(2), SA[1,-10000,0]) ≈ 10000
    @test MEDYAN.signed_distance_element(m, IT(2), SA[-10000,1,0]) ≈ 10000
    @test MEDYAN.signed_distance_element(m, IT(2), SA[2,2,1]) ≈ -sqrt(2)


    # Test whole mesh signed distance using octahedron.
    MEDYAN.initmesh!_vertex_triangle(m, 6, [SA[1,2,3], SA[1,3,4], SA[1,4,5], SA[1,5,2], SA[6,5,4], SA[6,4,3], SA[6,3,2], SA[6,2,5]])
    # Set coordinates.
    m.vertices.attr.coord[1] = SA[0, 0, 1]
    m.vertices.attr.coord[2] = SA[0, 1, 0]
    m.vertices.attr.coord[3] = SA[-1, 0, 0]
    m.vertices.attr.coord[4] = SA[0, -1, 0]
    m.vertices.attr.coord[5] = SA[1, 0, 0]
    m.vertices.attr.coord[6] = SA[0, 0, -1]

    # Compute geometries.
    MEDYAN.compute_geometry!_system(m)

    # Without acceleration.
    for accel ∈ (nothing, )
        @test MEDYAN.signed_distance(m, SA[0,0,0]; accel) ≈ -1/sqrt(3)
        @test MEDYAN.signed_distance(m, SA[-1/3,1/3,1/3]; accel) ≈ 0  atol=1e-9
        @test MEDYAN.signed_distance(m, SA[1,-1,1]; accel) ≈ 2/sqrt(3)

        @test MEDYAN.signed_distance(m, SA[2,2,0]; accel) ≈ 3/sqrt(2)
        @test MEDYAN.signed_distance(m, SA[0,0,-3]; accel) ≈ 2
    end

end
