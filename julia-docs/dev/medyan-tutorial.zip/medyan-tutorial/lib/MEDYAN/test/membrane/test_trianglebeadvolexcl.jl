using LinearAlgebra
using MEDYAN
using StaticArrays
using Test

@testset "Triangle bead volume exclusion" begin
    @testset "Energy value, scaling, symmetry and degenerate cases." begin
        x1 = SA[1,0,0]
        x2 = SA[0,1,0]
        x3 = SA[-1,0,0]
        xs = (x1, x2, x3)

        # Close to the triangle.
        let h = 1e-6, coplanartol = 1e-4
            # Perpendicular intersection inside triangle. Close to interaction with the entire plane.
            e = MEDYAN.triangle_bead_volexcl(xs, SA[0, 0.5, h]; coplanartol).energy
            @test isapprox(e, π/h^2; rtol=1e-3)
            # Perpendicular intersection at edge. Close to interaction with the half plane.
            e = MEDYAN.triangle_bead_volexcl(xs, SA[0.5, 0.5, h]; coplanartol).energy
            @test isapprox(e, π/(2*h^2); rtol=1e-3)
            # Perpendicular intersection at vertex. Close to interaction with a portion of the plane depending on the angle.
            e = MEDYAN.triangle_bead_volexcl(xs, SA[-1, 0, h]; coplanartol).energy
            @test isapprox(e, π/(8*h^2); rtol=1e-3)
        end

        # Very far from the triangle: should be close to A/h^4.
        let h = 1e6
            e = MEDYAN.triangle_bead_volexcl(xs, SA[0, 0.5, h]).energy
            @test isapprox(e, 1/h^4; rtol=1e-3)
        end

        # Symmetry.
        let
            # Use nonnegative x coord and positive z coord.
            x0s = (SA[0,-1,1.4], SA[0.5, 0.0, 1], SA[3, 0.0, 2])

            for x0 ∈ x0s
                e1 = MEDYAN.triangle_bead_volexcl(xs, x0).energy
                e2 = MEDYAN.triangle_bead_volexcl(xs, SA[-x0[1],x0[2],x0[3]]).energy
                e3 = MEDYAN.triangle_bead_volexcl(xs, SA[x0[1],x0[2],-x0[3]]).energy
                e4 = MEDYAN.triangle_bead_volexcl(xs, SA[-x0[1],x0[2],-x0[3]]).energy
                @test e1 ≈ e2
                @test e1 ≈ e3
                @test e1 ≈ e4
            end
        end

        # Coplanar degeneracy, far away behavior.
        let x0x = 1e6, x0y = x0x/2
            r2 = x0x^2 + x0y^2
            e = MEDYAN.triangle_bead_volexcl(xs, SA[x0x, x0y, 0.0]).energy
            @test isapprox(e, 1/r2^2; rtol=1e-3)
        end
        let x0z = -1e6
            e = MEDYAN.triangle_bead_volexcl(xs, SA[0, 0, x0z]).energy
            @test isapprox(e, 1/x0z^4; rtol=1e-3)
        end

        # Coplanar degeneracy, continuity.
        let
            h = 1e-6
            coplanartol = 1e-8
            e0 = MEDYAN.triangle_bead_volexcl(xs, SA[1, 1, 0]; coplanartol).energy
            e1 = MEDYAN.triangle_bead_volexcl(xs, SA[1, 1, h]; coplanartol).energy
            @test isapprox(e0, e1; rtol=1e-3)
        end

        # Colinear degeneracy, far away behavior.
        let
            x0x = 1e6
            e = MEDYAN.triangle_bead_volexcl(xs, SA[x0x, 0, 0]).energy
            @test isapprox(e, 1/x0x^4; rtol=1e-3)

            e = MEDYAN.triangle_bead_volexcl(xs, SA[x0x, 1, 0]; colineartol=1e-4).energy
            @test isapprox(e, 1/x0x^4; rtol=1e-3)
        end

        # Colinear degeneracy, continuity.
        let
            x0x = 2
            coplanartol = 1e-7
            colineartol = 1e-5
            # Modifying s when h=0.
            s = 3 * 1e-4
            e0 = MEDYAN.triangle_bead_volexcl(xs, SA[x0x, 0, 0]; colineartol).energy
            e1 = MEDYAN.triangle_bead_volexcl(xs, SA[x0x, s, 0]; colineartol).energy
            e2 = MEDYAN.triangle_bead_volexcl(xs, SA[x0x, -s, 0]; colineartol).energy
            @test isapprox(e0, e1; rtol=1e-3)
            @test isapprox(e0, e2; rtol=1e-3)

            # Modifying h when s=0.
            h = 1e-5
            e0 = MEDYAN.triangle_bead_volexcl(xs, SA[x0x, 0, 0]; coplanartol).energy
            e1 = MEDYAN.triangle_bead_volexcl(xs, SA[x0x, 0, h]; coplanartol).energy
            e2 = MEDYAN.triangle_bead_volexcl(xs, SA[x0x, 0, -h]; coplanartol).energy
            @test isapprox(e0, e1; rtol=1e-3)
            @test isapprox(e0, e2; rtol=1e-3)
        end

        # Finite cutoff.
        let
            gszero = SA[SA[0,0,0], SA[0,0,0], SA[0,0,0]]
            g0zero = SA[0,0,0]

            # On face.
            x0 = SA[0,1/2,1]
            (e, gs, g0) = MEDYAN.triangle_bead_volexcl(xs, x0-SA[0,0,1e-4]; cutoff=1)
            @test e > 0
            @test gs != gszero
            @test g0 != g0zero
            (e, gs, g0) = MEDYAN.triangle_bead_volexcl(xs, x0+SA[0,0,1e-4]; cutoff=1)
            @test e == 0
            @test gs == gszero
            @test g0 == g0zero

            # On edge.
            x0 = SA[0.123, -0.6, -0.8]
            @test MEDYAN.triangle_bead_volexcl(xs, x0-SA[0,0,1e-4]; cutoff=1).energy == 0
            @test MEDYAN.triangle_bead_volexcl(xs, x0+SA[0,0,1e-4]; cutoff=1).energy > 0

            # On vertex.
            x0 = SA[1+0.8, 0.6, 0]
            @test MEDYAN.triangle_bead_volexcl(xs, x0+SA[0,1e-4,0]; cutoff=1).energy == 0
            @test MEDYAN.triangle_bead_volexcl(xs, x0-SA[0,1e-4,0]; cutoff=1).energy > 0
        end

    end


    @testset "Derivatives" begin
        # A non-degenerate location.
        let
            x1 = SA[1,0,0]
            x2 = SA[0,1,0]
            x3 = SA[-1,0,0]
            xs = SA[x1, x2, x3]
            x0 = SA[1,1,-1]
            (e0, gs, g0) = MEDYAN.triangle_bead_volexcl(xs, x0)

            let
                local dxs = SA[SA[1,2,3], SA[4,5,6], SA[7,8,9]] * 1e-6
                local dx0 = SA[-1,-2,-3] * 1e-6
                local de_expect = dot(dxs, gs) + dot(dx0, g0)

                local e1 = MEDYAN.triangle_bead_volexcl(xs - dxs, x0 - dx0).energy
                local e2 = MEDYAN.triangle_bead_volexcl(xs + dxs, x0 + dx0).energy
                local de_actual = (e2 - e1) / 2

                @test isapprox(de_expect, de_actual; rtol=1e-6)
            end
        end

        # Coplanar case.
        let
            x1 = SA[1,0,0]
            x2 = SA[0,1,0]
            x3 = SA[-1,0,0]
            xs = SA[x1, x2, x3]
            x0 = SA[1,1,0]
            (e0, gs, g0) = MEDYAN.triangle_bead_volexcl(xs, x0)
            @test abs(gs[1][3]) < 1e-10
            @test abs(gs[2][3]) < 1e-10
            @test abs(gs[3][3]) < 1e-10
            @test abs(g0[3]) < 1e-10
            
            let
                # In-plane move only.
                local dxs = SA[SA[1,2,0], SA[4,5,0], SA[7,8,0]] * 1e-6
                local dx0 = SA[-1,-2,0] * 1e-6
                local de_expect = dot(dxs, gs) + dot(dx0, g0)

                local e1 = MEDYAN.triangle_bead_volexcl(xs - dxs, x0 - dx0).energy
                local e2 = MEDYAN.triangle_bead_volexcl(xs + dxs, x0 + dx0).energy
                local de_actual = (e2 - e1) / 2

                @test isapprox(de_expect, de_actual; rtol=1e-6)
            end
        end

        # Colinear case.
        let
            x1 = SA[1,0,0]
            x2 = SA[0,1,0]
            x3 = SA[-1,0,0]
            xs = SA[x1, x2, x3]
            x0 = SA[1,2,0]
            (e0, gs, g0) = MEDYAN.triangle_bead_volexcl(xs, x0)
            @test abs(gs[1][3]) < 1e-10
            @test abs(gs[2][3]) < 1e-10
            @test abs(gs[3][3]) < 1e-10
            @test abs(g0[3]) < 1e-10

            let
                # In-plane move only.
                # Tiny move within colinear range.
                dxs = SA[SA[1,2,0], SA[4,5,0], SA[7,8,0]] * 1e-6
                dx0 = SA[-1,-2,0] * 1e-6
                de_expect = dot(dxs, gs) + dot(dx0, g0)

                e1 = MEDYAN.triangle_bead_volexcl(xs - dxs, x0 - dx0; colineartol=1e-3).energy
                e2 = MEDYAN.triangle_bead_volexcl(xs + dxs, x0 + dx0; colineartol=1e-3).energy
                de_actual = (e2 - e1) / 2

                @test isapprox(de_expect, de_actual; rtol=1e-6)

                # More move to coplanar range.
                dxs = SA[SA[1,2,0], SA[4,5,0], SA[7,8,0]] * 1e-4
                dx0 = SA[-1,-20,0] * 1e-4
                de_expect = dot(dxs, gs) + dot(dx0, g0)

                e1 = MEDYAN.triangle_bead_volexcl(xs - dxs, x0 - dx0; colineartol=1e-5).energy
                e2 = MEDYAN.triangle_bead_volexcl(xs + dxs, x0 + dx0; colineartol=1e-5).energy
                de_actual = (e2 - e1) / 2

                @test isapprox(de_expect, de_actual; rtol=1e-4)
            end
        end
    end

    @testset "Energy and force with flat arrays" begin
        x = Float64[
            1, 0, 0,
            0, 1, 0,
            -1, 0, 0,

            1, 1, 1,
            1, 1, -1,
        ]

        force_energy1 = MEDYAN.ForceEnergyFloat64(length(x))
        MEDYAN.triangle_bead_volexcl!(10.0, (1,4,7), 10, x, force_energy1)
        e1 = MEDYAN.get_energy(force_energy1)
        f1 = MEDYAN.get_force(force_energy1)
        @test e1 > 0
        @test f1[12] > 0
        @test f1[15] == 0

        force_energy2 = MEDYAN.ForceEnergyFloat64(length(x))
        MEDYAN.triangle_bead_volexcl!(20.0, (1,4,7), 13, x, force_energy2)
        e2 = MEDYAN.get_energy(force_energy2)
        f2 = MEDYAN.get_force(force_energy2)
        @test e2 > 0
        @test f2[15] < 0
        @test f2[12] == 0

        @test e2 ≈ 2 * e1
        @test isapprox(view(f1, 1:9) .* SA[2,2,-2,2,2,-2,2,2,-2], view(f2, 1:9); atol=1e-9)
    end
end
