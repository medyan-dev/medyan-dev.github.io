using FixedPointNumbers
using MEDYAN
using StaticArrays
using StructArrays
using Test

@testset "Membrane diffusion" begin
    # Membrane diffusion rate adjustments.

    # Prepare parameters.
    β::Float64 = 1
    speciesnames = (:s1, :s2, :s3)
    nspecies = length(speciesnames)
    membrane_species_params = SA[
        MembraneSpeciesParams(diffusion_coeff=1.0),
        MembraneSpeciesParams(diffusion_coeff=1919.810),
        # s3 area is chosen such that 10 proteins will fill vertex 1 and 4 but not 2 or 3.
        MembraneSpeciesParams(diffusion_coeff=1.0, area=(1/2 + sqrt(3)) / 6 / 10),
    ]
    sitenames = (:ms1, :ms2, :ms3, :ms4, :ms5)
    map_speciesindex_membranesites = [[], [1,2], [4,5]]
    membranesites = (
        # s2 -> ∅
        MEDYAN.SiteData(1, MembraneSiteDiffusing(2, true, [2=>-1]), 1),
        # s2 -> s2
        MEDYAN.SiteData(2, MembraneSiteDiffusing(2, false, [2=>0]), 2),
        # ∅ -> s1
        MEDYAN.SiteData(3, MembraneSiteDiffusing(0, false, [1=>1]), 3),
        # s3 -> ∅
        MEDYAN.SiteData(4, MembraneSiteDiffusing(3, true, [3=>-1]), 4),
        # s3 -> s3
        MEDYAN.SiteData(5, MembraneSiteDiffusing(3, false, [3=>0]), 5),
    )
    function membranespeciespotentialenergy(m, v, speciesindex)::Float64
        if speciesindex == 3
            # Use vertex index as energy.
            v.value
        else
            0
        end
    end

    # Initialize membrane.
    m = MEDYAN.create_membranemesh(Val(speciesnames), Val(sitenames))
    MEDYAN.initmesh!(m, (
        vertlist = [SA[0,0,0], SA[1,0,0], SA[0,1,0], SA[1,1,1]],
        trilist = [SA[1,2,3], SA[3,2,4]],
        copynumbers = StructArray((
            s1 = [10, 20, 30, 40],
            s2 = [100, 1000, 10000, 100000],
            s3 = [0, 0, 0, 0],
        ))
    ))
    # All in compartment 1.
    fill!(m.vertices.attr.cid, 1)
    MEDYAN.compute_geometry!_system(m)
    fill!(m.vertices.attr.outdiffusion_a, 0)
    for siteindex ∈ eachindex(sitenames)
        fill!(getproperty(m.vertices.attr.contrib_membranesitecount, siteindex), 0)
    end
    for speciesindex ∈ eachindex(speciesnames)
        fill!(getproperty(m.halfedges.attr.diffusion_a, speciesindex), 0)
    end
    @test length(m.halfedges.attr.diffusion_a) == 10

    rdme = MEDYAN.RDMEPropensityRejectDiffusion{0, length(sitenames)}()
    MEDYAN.addbulkspecies!(rdme, 0)
    MEDYAN.addbulkreaction!(rdme, MEDYAN.BulkReaction(
        # bulks[1] -> bulks[1].
        [(id=1, amount=1)],
        [(id=1, amount=0)],
        1.0
    ))
    # Initialize 1 compartment.
    MEDYAN.addcompartments!(rdme, 1, 1.0)

    @testset "local propensity update" begin
        vup = MEDYAN.update_membranediffusionpropensity!(β, membrane_species_params, m, MEDYAN.IV(1), 1, membranespeciespotentialenergy, Val(:outward))
        @test vup.max_old_outdiffusion_a == 0
        @test vup.max_updated_outdiffusion_a == 60
        @test vup.Δ_outdiffusion_a == 60
        for h ∈ MEDYAN.HalfedgesTargetingVertex(m, MEDYAN.IV(1))
            ho = MEDYAN.oppo(m, h)
            vn = MEDYAN.target(m, ho)
            if vn.value == 2
                @test m.halfedges.attr.diffusion_a.s1[ho.value] == 30
            elseif vn.value == 3
                @test m.halfedges.attr.diffusion_a.s1[ho.value] == 30
            end
        end

        vup = MEDYAN.update_membranediffusionpropensity!(β, membrane_species_params, m, MEDYAN.IV(4), 1, membranespeciespotentialenergy, Val(:inward))
        @test vup.max_old_outdiffusion_a == 0
        @test vup.max_updated_outdiffusion_a ≈ 30 * (3-sqrt(3))/2
        @test vup.Δ_outdiffusion_a ≈ 50 * (3-sqrt(3))/2
        for h ∈ MEDYAN.HalfedgesTargetingVertex(m, MEDYAN.IV(4))
            ho = MEDYAN.oppo(m, h)
            vn = MEDYAN.target(m, ho)
            if vn.value == 2
                @test m.halfedges.attr.diffusion_a.s1[h.value] ≈ 20 * (3 - sqrt(3)) / 2
            elseif vn.value == 3
                @test m.halfedges.attr.diffusion_a.s1[h.value] ≈ 30 * (3 - sqrt(3)) / 2
            end
        end

        vup = MEDYAN.update_membranediffusionpropensity!(β, membrane_species_params, m, MEDYAN.IV(2), 1, membranespeciespotentialenergy, Val(:bi))
        @test vup.max_old_outdiffusion_a == 60
        @test vup.max_updated_outdiffusion_a == 60
        @test vup.Δ_outdiffusion_a ≈ (
            50 * (3-sqrt(3))/2        # From 2 <-> 3.
            + 20 * 3/(1+sqrt(3))      # From 2 -> 1.
            + 40                      # From 4 -> 2.
        )
        for h ∈ MEDYAN.HalfedgesTargetingVertex(m, MEDYAN.IV(2))
            ho = MEDYAN.oppo(m, h)
            vn = MEDYAN.target(m, ho)
            if vn.value == 3
                @test m.halfedges.attr.diffusion_a.s1[h.value] ≈ 30 * (3 - sqrt(3)) / 2
                @test m.halfedges.attr.diffusion_a.s1[ho.value] ≈ 20 * (3 - sqrt(3)) / 2
            end
        end

        @test_throws ErrorException MEDYAN.update_membranediffusionpropensity!(β, membrane_species_params, m, MEDYAN.IV(3), 1, membranespeciespotentialenergy, Val(:invalid))

        Δcount = MEDYAN.update_contrib_membranesitecount!(; β, membrane_species_params, mesh = m, v = MEDYAN.IV(1), membranesites, siteindex = 1, func_membranespeciespotentialenergy = membranespeciespotentialenergy)
        @test Δcount == 100
        Δcount = MEDYAN.update_contrib_membranesitecount!(; β, membrane_species_params, mesh = m, v = MEDYAN.IV(1), membranesites, siteindex = 3, func_membranespeciespotentialenergy = membranespeciespotentialenergy)
        @test Δcount ≈ 1/6
    end

    @testset "membrane mesh overall diffusion propensity update." begin
        MEDYAN.update_membranediffusionpropensity!(β, membrane_species_params, m, membranespeciespotentialenergy)
        # Check consistency of various levels of sums/maxima.
        let
            totala::Q31f32 = 0
            maxa::Q31f32 = 0
            for vindex ∈ eachindex(m.vertices)
                v = MEDYAN.IV(vindex)
                local expect_outdiffusion_a::Q31f32 = 0
                for h ∈ MEDYAN.HalfedgesTargetingVertex(m, v)
                    ho = MEDYAN.oppo(m, h)
                    for speciesindex ∈ eachindex(speciesnames)
                        expect_outdiffusion_a += getproperty(m.halfedges.attr.diffusion_a, speciesnames[speciesindex])[ho.value]
                    end
                end
                @test expect_outdiffusion_a == m.vertices.attr.outdiffusion_a[v.value]

                totala += m.vertices.attr.outdiffusion_a[v.value]
                maxa = max(maxa, m.vertices.attr.outdiffusion_a[v.value])
            end

            @test totala == m.metaattr.total_membranediffusion_a
            @test maxa == m.metaattr.max_vertexoutdiffusion_a
            # Redundant check.
            @test isempty(MEDYAN.fullcheck_membranediffusion_consistency(m))
        end

        # Set original membrane diffusion total propensity to zero and update it again, together with rdme total propensity.
        let
            m.metaattr.total_membranediffusion_a = 0
            rdme.total_a = 0
            MEDYAN.update_membranediffusionpropensity!(rdme, 1, β, membrane_species_params, m, membranespeciespotentialenergy)
            @test isempty(MEDYAN.fullcheck_membranediffusion_consistency(m))
            @test rdme.total_a == rdme.bulk_a[1]
            @test isapprox(m.metaattr.total_membranediffusion_a, rdme.total_a; rtol=1e-9)
            @test rdme.total_a > 0
            # Do it again, which should not change total_a this time.
            local old_totala = rdme.total_a
            MEDYAN.update_membranediffusionpropensity!(rdme, 1, β, membrane_species_params, m, membranespeciespotentialenergy)
            @test rdme.total_a == old_totala
            @test rdme.total_a == rdme.bulk_a[1]
        end

        # Update all site counts and check.
        for siteindex ∈ eachindex(sitenames)
            getproperty(m.vertices.attr.contrib_membranesitecount, siteindex) .= 0
            MEDYAN.update_membranesitecount!(; rdme, β, membrane_species_params, mesh = m, membranesites, siteindex, func_membranespeciespotentialenergy = membranespeciespotentialenergy)
        end
        let
            @test m.vertices.attr.contrib_membranesitecount.ms1 ≈ [100, 1000, 10000, 100000]
            @test rdme.fixedcounts[1, 1] ≈ 111100
            @test m.vertices.attr.contrib_membranesitecount.ms3 ≈ [1/6, 1/6 + 1/(2*sqrt(3)), 1/6 + 1/(2*sqrt(3)), 1/(2*sqrt(3))]
            @test rdme.fixedcounts[3, 1] ≈ 1/2 + sqrt(3)/2
        end


        # Now that all propensities are up-to-date, let's change some copy numbers and see whether propensities are correctly updated.
        rdme.total_a = rdme.bulk_a[1]
        let
            rdme_olda = rdme.total_a
            # Set vertex 1 species s1 to 0.
            MEDYAN.set_membranediffusingspeciescount!(; rdme, memdiff_bulks_index = 1, map_speciesindex_membranesites, β, membrane_species_params, mesh = m, v = MEDYAN.IV(1), speciesindex = 1, membranesites, newcount = 0, func_membranespeciespotentialenergy = membranespeciespotentialenergy)
            @test isempty(MEDYAN.fullcheck_membranediffusion_consistency(m))
            for h ∈ MEDYAN.HalfedgesTargetingVertex(m, MEDYAN.IV(1))
                ho = MEDYAN.oppo(m, h)
                @test m.halfedges.attr.diffusion_a.s1[ho.value] == 0
                @test m.halfedges.attr.diffusion_a.s2[ho.value] > 0
            end

            rdme_newa = rdme.total_a
            @test rdme_olda - rdme_newa == 60
        end
        let
            rdme_olda = rdme.total_a
            MEDYAN.change_membranediffusingspeciescount!(; rdme, memdiff_bulks_index = 1, map_speciesindex_membranesites, β, membrane_species_params, mesh = m, v = MEDYAN.IV(1), speciesindex = 2, membranesites, Δcount = -100, func_membranespeciespotentialenergy = membranespeciespotentialenergy)
            @test isempty(MEDYAN.fullcheck_membranediffusion_consistency(m))
            for h ∈ MEDYAN.HalfedgesTargetingVertex(m, MEDYAN.IV(1))
                ho = MEDYAN.oppo(m, h)
                @test m.halfedges.attr.diffusion_a.s2[ho.value] == 0
            end
            @test m.vertices.attr.outdiffusion_a[1] == 0
            @test m.vertices.attr.contrib_membranesitecount.ms1[1] == 0
            @test m.vertices.attr.contrib_membranesitecount.ms2[1] == 0

            rdme_newa = rdme.total_a
            @test rdme_olda - rdme_newa ≈ 1919.810 * 600
        end
        let
            rdme_olda = rdme.total_a
            # Increase copy numbers of s3 to 10 each.
            for vindex ∈ eachindex(m.vertices)
                MEDYAN.change_membranediffusingspeciescount!(; rdme, memdiff_bulks_index = 1, map_speciesindex_membranesites, β, membrane_species_params, mesh = m, v = MEDYAN.IV(vindex), speciesindex = 3, membranesites, Δcount = 10, func_membranespeciespotentialenergy = membranespeciespotentialenergy)
            end
            @test isempty(MEDYAN.fullcheck_membranediffusion_consistency(m))
            for h ∈ MEDYAN.HalfedgesTargetingVertex(m, MEDYAN.IV(1))
                ho = h |> MEDYAN.oppo(m)
                vn = ho |> MEDYAN.target(m)
                @test vn.value ∈ (2,3)
                if vn.value == 2
                    @test m.halfedges.attr.diffusion_a.s3[ho.value] == 20
                elseif vn.value == 3
                    @test m.halfedges.attr.diffusion_a.s3[ho.value] == 10
                end
            end
            for h ∈ MEDYAN.HalfedgesTargetingVertex(m, MEDYAN.IV(2))
                ho = h |> MEDYAN.oppo(m)
                vn = ho |> MEDYAN.target(m)
                @test vn.value ∈ (1,3,4)
                if vn.value == 3
                    @test m.halfedges.attr.diffusion_a.s3[ho.value] ≈ (
                        # Copy number.
                        10
                        # Inverse area.
                        * 6 / (1 + sqrt(3))
                        # Diffusion and drifting.
                        * max(0,
                            # Diffusion.
                            1 / (2 * sqrt(3))
                            # Drifting.
                            - 1 / 3
                        )
                    )
                end
            end
            for h ∈ MEDYAN.HalfedgesTargetingVertex(m, MEDYAN.IV(3))
                ho = h |> MEDYAN.oppo(m)
                ho = h |> MEDYAN.oppo(m)
                vn = ho |> MEDYAN.target(m)
                @test vn.value ∈ (1,2,4)
                if vn.value == 2
                    @test m.halfedges.attr.diffusion_a.s3[ho.value] ≈ (
                        # Copy number.
                        10
                        # Inverse area.
                        * 6 / (1 + sqrt(3))
                        # Diffusion and drifting.
                        * max(0,
                            # Diffusion.
                            1 / (2 * sqrt(3))
                            # Drifting.
                            - (1 - sqrt(3)) / 6
                        )
                    )
                elseif vn.value == 1 || vn.value == 4
                    # Diffusion is shut down because the target vertex is overly occupied.
                    @test m.halfedges.attr.diffusion_a.s3[ho.value] == 0
                end
            end
            @test m.vertices.attr.contrib_membranesitecount.ms4 ≈ 10 * exp.(1:4)
            @test m.vertices.attr.contrib_membranesitecount.ms5 ≈ 10 * ones(4)
        end

        # Do a diffusion reaction between 2 and 3 for s2, which should not change overall propensities.
        h23 = findfirst(eachindex(m.halfedges)) do hindex
            h = MEDYAN.IH(hindex)
            ho = MEDYAN.oppo(m, h)
            MEDYAN.target(m, h).value == 3 && MEDYAN.target(m, ho).value == 2
        end |> MEDYAN.IH
        let
            rdme_olda = rdme.total_a
            MEDYAN.do_membranediffusionreaction!(; rdme, memdiff_bulks_index = 1, map_speciesindex_membranesites, β, membrane_species_params, mesh = m, h = h23, membranesites, speciesindex = 2, func_membranespeciespotentialenergy = membranespeciespotentialenergy)
            @test isempty(MEDYAN.fullcheck_membranediffusion_consistency(m))
            @test m.vertices.attr.copynumbers.s2 == [0, 999, 10001, 100000]
            @test isapprox(rdme_olda, rdme.total_a; rtol=1e-9)

            rdme_olda = rdme.total_a
            MEDYAN.do_membranediffusionreaction!(; rdme, memdiff_bulks_index = 1, map_speciesindex_membranesites, β, membrane_species_params, mesh = m, h = h23, membranesites, speciesindex = 2, func_membranespeciespotentialenergy = membranespeciespotentialenergy)
            @test isempty(MEDYAN.fullcheck_membranediffusion_consistency(m))
            @test m.vertices.attr.copynumbers.s2 == [0, 998, 10002, 100000]
            @test isapprox(rdme_olda, rdme.total_a; rtol=1e-9)
        end

        # Clearing all membrane diffusion propensities.
        @test isapprox(rdme.total_a, m.metaattr.total_membranediffusion_a; rtol=1e-9)
        MEDYAN.clear_membranediffusionpropensity!(rdme, 1, m)
        @test rdme.total_a == 0
        @test m.metaattr.total_membranediffusion_a == 0
        @test m.metaattr.max_vertexoutdiffusion_a == 0
        @test isempty(MEDYAN.fullcheck_membranediffusion_consistency(m))

        # Clearing all site counts.
        for siteindex ∈ eachindex(sitenames)
            MEDYAN.clear_membranesitecount!(; rdme, mesh=m, membranesites, siteindex)
            @test all(==(0), getproperty(m.vertices.attr.contrib_membranesitecount, siteindex))
        end
    end
end

@testset "Membrane diffusion bulk callback" begin
    speciesnames = (:s1, :s2)
    nspecies = length(speciesnames)
    membrane_species_params = SA[
        MembraneSpeciesParams(diffusion_coeff=1.0),
        MembraneSpeciesParams(diffusion_coeff=1919.810),
    ]

    let
        # If special bulk species already exists, membrane diffusion cannot be added.
        s = MEDYAN.SysDef(
            MEDYAN.AgentNames(
                membranediffusingspeciesnames = [speciesnames...],
                bulkspeciesnames = [:__MEDYAN_MEMDIFF_BULK],
            )
        )
        @test_throws ErrorException MEDYAN.add_membranediffusion_asbulkreaction!(s)
    end

    let
        s = MEDYAN.SysDef(
            MEDYAN.AgentNames(
                membranediffusingspeciesnames = [speciesnames...],
            )
        )
        MEDYAN.add_membranediffusion_asbulkreaction!(s)
        MEDYAN.add_membranesitereaction!(;
            s,
            name_newmembranesite = :ms1,
            membranediffusingreactants = [:s1],
            membranediffusingproducts = [:s2],
            reactionexpr_extra = "-->",
            rate = 10.0,
            canchangerate_bypotentialenergy = false,
            invvolumepower = 1
        )

        @test s.agentnames.bulkspeciesnames == [:__MEDYAN_MEMDIFF_BULK]
        @test length(s.bulkspecies_indexmap) == 1
        @test length(s.bulkreactions) == 1
        @test length(s.bulkreactioncallbacks) == 1
        @test typeof(s.bulkreactioncallbacks[1]) == MEDYAN.MembraneDiffusionBulkCallback

        c = MEDYAN.Context(s, CubicGrid((1,1,1),500.0);
            membrane_species_params,
            membranemechparams = [MEDYAN.MembraneMechParams()],
        )
        @test c.memdiff_bulks_index == 1
        @test length(c.bulkreactioncallbacks) == 1
        @test typeof(c.bulkreactioncallbacks[1]) == MEDYAN.MembraneDiffusionBulkCallback
        @test c.map_membranediffusingspeciesindex_membranesiteindices == ([1], [])
        @test length(c.membranesites) == 1

        # Add membrane.
        MEDYAN.newmembrane!(c;
            type = 1,
            meshinit = (
                vertlist = [SA[0,0,0], SA[1,0,0], SA[0,1,0], SA[1,1,1]],
                trilist = [SA[1,2,3], SA[3,2,4]],
                copynumbers = StructArray((
                    s1 = [10, 20, 30, 40],
                    s2 = [100, 1000, 10000, 100000],
                ))
            )
        )
        @test length(c.membranes) == 1
        m = c.membranes[1]

        MEDYAN.compute_geometry!_system(m)
        MEDYAN.update_membranediffusionpropensity!(c.chemistryengine, c.memdiff_bulks_index, c.β, c.membrane_species_params, m, MEDYAN.default_membranespeciespotentialenergy)
        @test c.chemistryengine.bulkcounts[1] > 0

        MEDYAN.compartmentalize!(c)
        MEDYAN.update_membranesitecount!(; rdme = c.chemistryengine, c.β, c.membrane_species_params, mesh = m, c.membranesites, siteindex = 1, c.func_membranespeciespotentialenergy)
        @test size(c.chemistryengine.fixedcounts) == (1,1)
        @test c.chemistryengine.fixedcounts[1,1] > 0

        # Do a membrane diffusion reaction randomly.
        let
            prevs1 = copy(m.vertices.attr.copynumbers.s1)
            prevs2 = copy(m.vertices.attr.copynumbers.s2)
            # Do the reaction using callbacks.
            c.bulkreactioncallbacks[1](c)
            @test sum(m.vertices.attr.copynumbers.s1) == sum(prevs1)
            @test sum(m.vertices.attr.copynumbers.s2) == sum(prevs2)
            # At least one copy number moved.
            @test m.vertices.attr.copynumbers.s1 != prevs1 || m.vertices.attr.copynumbers.s2 != prevs2
        end

        # Do a membrane site reaction randomly.
        let
            prevs1 = copy(m.vertices.attr.copynumbers.s1)
            prevs2 = copy(m.vertices.attr.copynumbers.s2)
            # Do the reaction using callbacks.
            c.compartmentreactioncallbacks[1](c, 1)
            Δ1 = sum(m.vertices.attr.copynumbers.s1) - sum(prevs1)
            Δ2 = sum(m.vertices.attr.copynumbers.s2) - sum(prevs2)
            @test abs(Δ1) == 1
            @test abs(Δ2) == 1
            @test Δ1 + Δ2 == 0
            # One copy number is changed in each species.
            @test m.vertices.attr.copynumbers.s1 != prevs1 && m.vertices.attr.copynumbers.s2 != prevs2
        end
    end

    let
        s = MEDYAN.SysDef(
            MEDYAN.AgentNames(
                membranediffusingspeciesnames = [speciesnames...],
            )
        )
        MEDYAN.add_membranediffusion_asbulkreaction!(s)
        MEDYAN.add_membranesitereaction!(;
            s,
            name_newmembranesite = :ms1,
            membranediffusingreactants = [:s1],
            membranediffusingproducts = [:s2],
            reactionexpr_extra = "-->",
            rate = 10.0,
            canchangerate_bypotentialenergy = true,
            invvolumepower = 1
        )

        @test s.agentnames.bulkspeciesnames == [:__MEDYAN_MEMDIFF_BULK]
        @test length(s.bulkspecies_indexmap) == 1
        @test length(s.bulkreactions) == 1
        @test length(s.bulkreactioncallbacks) == 1
        @test typeof(s.bulkreactioncallbacks[1]) == MEDYAN.MembraneDiffusionBulkCallback

        grid = CubicGrid(SA[2,1,1], 10.0)
        c = MEDYAN.Context(s, grid;
            membrane_species_params,
            membranemechparams = [MEDYAN.MembraneMechParams()],
        )
        @test c.memdiff_bulks_index == 1
        @test length(c.bulkreactioncallbacks) == 1
        @test typeof(c.bulkreactioncallbacks[1]) == MEDYAN.MembraneDiffusionBulkCallback
        @test c.map_membranediffusingspeciesindex_membranesiteindices == ([1], [])
        @test length(c.membranesites) == 1

        # Add membrane.
        MEDYAN.newmembrane!(c;
            type = 1,
            meshinit = (
                vertlist = [SA[1,1,1], SA[1,9,1], SA[11,5,1]] .+ Ref(MEDYAN.cornerof(grid)),
                trilist = [SA[1,2,3]],
                copynumbers = StructArray((
                    s1 = [100, 100, 100],
                    s2 = [0, 0, 0],
                ))
            )
        )
        m = c.membranes[1]

        MEDYAN.compute_geometry!_system(m)
        MEDYAN.update_membranediffusionpropensity!(c.chemistryengine, c.memdiff_bulks_index, c.β, c.membrane_species_params, m, MEDYAN.default_membranespeciespotentialenergy)
        @test c.chemistryengine.bulkcounts[1] > 0

        MEDYAN.compartmentalize!(c)
        MEDYAN.update_membranesitecount!(; rdme = c.chemistryengine, c.β, c.membrane_species_params, mesh = m, c.membranesites, siteindex = 1, c.func_membranespeciespotentialenergy)
        @test size(c.chemistryengine.fixedcounts) == (1,2)
        @test c.chemistryengine.fixedcounts[1,1] > 0
        @test c.chemistryengine.fixedcounts[1,2] > 0

        # Check membrane site reaction sampling correctness.
        let
            for _ ∈ 1:100
                c.compartmentreactioncallbacks[1](c, 1)
            end
            # Chance of all reactions on one vertex is 2^-99. Consider this impossible.
            @test m.vertices.attr.copynumbers.s1[1] < 100
            @test m.vertices.attr.copynumbers.s1[2] < 100
            @test m.vertices.attr.copynumbers.s1[1] + m.vertices.attr.copynumbers.s1[2] == 100

            @test m.vertices.attr.copynumbers.s1[1] + m.vertices.attr.copynumbers.s2[1] == 100
            @test m.vertices.attr.copynumbers.s1[2] + m.vertices.attr.copynumbers.s2[2] == 100

            for _ ∈ 1:100
                c.compartmentreactioncallbacks[1](c, 2)
            end
            @test m.vertices.attr.copynumbers.s1[3] == 0
            @test m.vertices.attr.copynumbers.s2[3] == 100
            @test_throws AssertionError c.compartmentreactioncallbacks[1](c, 2)
        end
    end

end