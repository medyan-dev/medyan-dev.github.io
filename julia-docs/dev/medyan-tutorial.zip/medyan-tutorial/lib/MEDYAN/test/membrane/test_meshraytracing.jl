using MEDYAN
using Test
using StaticArrays

@testset "Mesh ray tracing using AABB tree" begin
    # Initialize an octahedron with 6 vertices.
    dm1 = MEDYAN.create_membranemesh()
    MEDYAN.initmesh!_vertex_triangle(dm1, 6, [SA[1,2,3], SA[1,3,4], SA[1,4,5], SA[1,5,2], SA[6,5,4], SA[6,4,3], SA[6,3,2], SA[6,2,5]])
    dm1.vertices.attr.coord[1] = SA[0, 0, 1]
    dm1.vertices.attr.coord[2] = SA[0, 1, 0]
    dm1.vertices.attr.coord[3] = SA[-1, 0, 0]
    dm1.vertices.attr.coord[4] = SA[0, -1, 0]
    dm1.vertices.attr.coord[5] = SA[1, 0, 0]
    dm1.vertices.attr.coord[6] = SA[0, 0, -1]

    # Initialize a triangle.
    dm2 = MEDYAN.create_membranemesh()
    MEDYAN.initmesh!_vertex_triangle(dm2, 3, [SA[1,2,3]])
    dm2.vertices.attr.coord[1] = SA[0,0,150]
    dm2.vertices.attr.coord[2] = SA[0,10,150]
    dm2.vertices.attr.coord[3] = SA[10,0,150]

    # Build AABB tree.
    tree = MEDYAN.build_aabbtree_frommeshes((dm1,dm2))
    @test isempty(MEDYAN.check_binary_aabbtree_consistency(tree))
    @test length(tree.data) == 9

    # Try ray tracing.
    res = MEDYAN.line_meshaabb_intersect!(tree, SA[-1,-1,-1], SA[1,1,1]; sorting=true, tinterval=(0,Inf))
    @test length(res) == 2
    @test res[1].mindex == 1
    @test res[1].tindex == 6
    @test res[1].t ≈ 2/3
    @test res[2].mindex == 1
    @test res[2].tindex == 4
    @test res[2].t ≈ 4/3

    res = MEDYAN.line_meshaabb_intersect!(tree, SA[0,0,-2], SA[0,0,1]; sorting=true, tinterval=(0,Inf))
    @test length(res) == 3
    @test res[1].t ≈ 1
    @test res[2].t ≈ 3
    @test res[3].t ≈ 152
    @test res[3].mindex == 2
    @test res[3].tindex == 1

    # If atol is zero, should have multiple degenerate intersects.
    res = MEDYAN.line_meshaabb_intersect!(tree, SA[0,0,-2], SA[0,0,1]; atol=0, sorting=true, tinterval=(0,Inf))
    @test length(res) == 9
end