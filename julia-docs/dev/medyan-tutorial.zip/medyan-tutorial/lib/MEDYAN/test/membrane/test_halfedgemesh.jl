using MEDYAN
using Test
using Setfield
using StaticArrays

import MEDYAN:
    IV, IH, IE, IT, IB,
    pt_triangle, pt_border,
    attrtype_vertex, attrtype_halfedge, attrtype_edge, attrtype_triangle, attrtype_border, attrtype_meta,
    target, edge, next, prev, oppo, polygon, triangle, border, halfedge, onborder, degree,
    HalfedgesTargetingVertex, HalfedgesInTriangle, HalfedgesInBorder, HalfedgesInEdge,
    initmesh!_vertex_triangle, insert_vertex_onedge!, collapse_halfedge!, flip_edge!,
    DefaultHalfedgeMeshElementAttr, default_initattr!,
    get_neighbor_vertex, get_targeting_halfedge, get_leaving_halfedge, get_outer_halfedge, get_targeting_edge, get_polygon,
    fullcheck_mesh_consistency

@testset "Dynamic half edge mesh" begin
    M = MEDYAN
    DA = MEDYAN.DefaultHalfedgeMeshElementAttr

    @testset "Connection init" begin
        m = MEDYAN.DynamicHalfedgeMesh(DA(), DA(), DA(), DA(), DA(), nothing)
        @test isempty(m.vertices)
        @test isempty(m.halfedges)
        @test isempty(m.edges)
        @test isempty(m.triangles)
        @test isempty(m.borders)
        @test isempty(fullcheck_mesh_consistency(m))

        @test attrtype_vertex(m) == DA
        @test attrtype_halfedge(m) == DA
        @test attrtype_edge(m) == DA
        @test attrtype_triangle(m) == DA
        @test attrtype_border(m) == DA
        @test attrtype_meta(m) == Nothing

        # 1 triangle.
        initmesh!_vertex_triangle(m, 3, [SA[1,2,3]])
        @test length(m.vertices) == 3
        @test length(m.halfedges) == 6
        @test length(m.edges) == 3
        @test length(m.triangles) == 1
        @test length(m.borders) == 1
        @test isempty(fullcheck_mesh_consistency(m))

        @test m.vertices.conn[1] == M.DynamicHalfedgeMeshConnectionVertex(IH(1), 2, 1)
        @test m.vertices.conn[2] == M.DynamicHalfedgeMeshConnectionVertex(IH(2), 2, 1)
        @test m.vertices.conn[3] == M.DynamicHalfedgeMeshConnectionVertex(IH(3), 2, 1)

        @test m.halfedges.conn[1] == M.DynamicHalfedgeMeshConnectionHalfedge(pt_triangle, 1, IV(1), IH(4), IH(2), IH(3), IE(1))
        @test m.halfedges.conn[2] == M.DynamicHalfedgeMeshConnectionHalfedge(pt_triangle, 1, IV(2), IH(6), IH(3), IH(1), IE(2))
        @test m.halfedges.conn[3] == M.DynamicHalfedgeMeshConnectionHalfedge(pt_triangle, 1, IV(3), IH(5), IH(1), IH(2), IE(3))
        @test m.halfedges.conn[4] == M.DynamicHalfedgeMeshConnectionHalfedge(pt_border, 1, IV(3), IH(1), IH(5), IH(6), IE(1))
        @test m.halfedges.conn[5] == M.DynamicHalfedgeMeshConnectionHalfedge(pt_border, 1, IV(2), IH(3), IH(6), IH(4), IE(3))
        @test m.halfedges.conn[6] == M.DynamicHalfedgeMeshConnectionHalfedge(pt_border, 1, IV(1), IH(2), IH(4), IH(5), IE(2))

        @test m.edges.conn[1] == M.DynamicHalfedgeMeshConnectionEdge(IH(1), 1)
        @test m.edges.conn[2] == M.DynamicHalfedgeMeshConnectionEdge(IH(2), 1)
        @test m.edges.conn[3] == M.DynamicHalfedgeMeshConnectionEdge(IH(3), 1)

        @test m.triangles.conn[1] == M.DynamicHalfedgeMeshConnectionTriangle(IH(1))
        @test m.borders.conn[1] == M.DynamicHalfedgeMeshConnectionBorder(IH(4))

        @test_throws BoundsError initmesh!_vertex_triangle(m, 3, [SA[1,2,4]])

        # 2 triangles.
        initmesh!_vertex_triangle(m, 4, [SA[1,2,3], SA[3,2,4]])
        @test length(m.vertices) == 4
        @test length(m.halfedges) == 10
        @test length(m.edges) == 5
        @test length(m.triangles) == 2
        @test length(m.borders) == 1
        @test isempty(fullcheck_mesh_consistency(m))

        initmesh!_vertex_triangle(m, 6, [SA[1,2,3], SA[4,5,6]])
        @test length(m.vertices) == 6
        @test length(m.halfedges) == 12
        @test length(m.edges) == 6
        @test length(m.triangles) == 2
        @test length(m.borders) == 2
        @test isempty(fullcheck_mesh_consistency(m))

        @test_throws ErrorException initmesh!_vertex_triangle(m, 5, [SA[1,2,3], SA[3,4,5]])
        @test_throws BoundsError initmesh!_vertex_triangle(m, 4, [SA[0,2,3], SA[3,2,4]])

        # Tetrahedron
        initmesh!_vertex_triangle(m, 4, [SA[1,2,3], SA[1,3,4], SA[1,4,2], SA[4,3,2]])
        @test length(m.vertices) == 4
        @test length(m.halfedges) == 12
        @test length(m.edges) == 6
        @test length(m.triangles) == 4
        @test length(m.borders) == 0
        @test isempty(fullcheck_mesh_consistency(m))

        # Invalid cases.
        @test_throws ErrorException initmesh!_vertex_triangle(m, 4, [SA[1,2,3]])
    end

    @testset "Mesh traversal" begin
        m = MEDYAN.DynamicHalfedgeMesh(DA(), DA(), DA(), DA(), DA(), nothing)

        # A fan of 5 triangles.
        initmesh!_vertex_triangle(m, 6, [SA[1,2,3], SA[1,3,4], SA[1,4,5], SA[1,5,6], SA[1,6,2]])
        @test length(m.vertices) == 6
        @test length(m.halfedges) == 20
        @test length(m.edges) == 10
        @test length(m.triangles) == 5
        @test length(m.borders) == 1
        @test isempty(fullcheck_mesh_consistency(m))

        @test halfedge(m, IV(2), IV(3)).value ∈ eachindex(m.halfedges)
        @test edge(m, IV(2), IV(3)).value ∈ eachindex(m.edges)
        @test isnothing(halfedge(m, IV(2), IV(4)))
        @test isnothing(edge(m, IV(2), IV(4)))

        let h0 = m.vertices.conn[1].halfedge_index
            @test 1 <= h0.value <= length(m.halfedges)
            @test target(m, h0) == IV(1)

            # Triangle traversal.
            for tindex ∈ 1:length(m.triangles)
                ti = IT(tindex)
                hcount = 0
                for h ∈ HalfedgesInTriangle(m, ti)
                    @test triangle(m, h) == ti
                    hcount += 1
                end
                @test hcount == 3
            end

            # Border traversal.
            let b0 = IB(1)
                hcount = 0
                for h ∈ HalfedgesInBorder(m, b0)
                    @test border(m, h) == b0
                    hcount += 1
                end
                @test hcount == 5
            end

            # Center vertex traversal.
            let v0 = IV(1)
                hcount = 0
                hcount_border = 0
                for h ∈ HalfedgesTargetingVertex(m, v0)
                    @test target(m, h) == v0
                    hcount += 1
                    if onborder(m, h)
                        hcount_border += 1
                    end
                end
                @test hcount == 5
                @test hcount_border == 0
            end

            # Border vertex traversal.
            for vindex ∈ 2:length(m.vertices)
                vi = IV(vindex)
                hcount = 0
                hcount_border = 0
                for h ∈ HalfedgesTargetingVertex(m, vi)
                    @test target(m, h) == vi
                    hcount += 1
                    if onborder(m, h)
                        hcount_border += 1
                    end
                end
                @test hcount == 3
                @test hcount_border == 1
            end

            # Edge traversal.
            for eindex ∈ 1:length(m.edges)
                ei = IE(eindex)
                hcount = 0
                for h ∈ HalfedgesInEdge(m, ei)
                    @test edge(m, h) == ei
                    hcount += 1
                end
                @test hcount == 2
            end
        end
    end

    @testset "Mesh operations" begin
        m = MEDYAN.DynamicHalfedgeMesh(DA(), DA(), DA(), DA(), DA(), nothing)

        initattr! = default_initattr!

        # Start with 1 triangle.
        initmesh!_vertex_triangle(m, 3, [SA[1,2,3]])

        # Split the first edge.
        insert_res = insert_vertex_onedge!(initattr!, m, IE(1))
        @test length(m.vertices) == 4
        @test length(m.halfedges) == 10
        @test length(m.edges) == 5
        @test length(m.triangles) == 2
        @test length(m.borders) == 1
        @test isempty(fullcheck_mesh_consistency(m))

        @test insert_res.vnew == IV(4)

        # Split the central edge.
        let eindex = findfirst(k -> (m.edges.conn[k].num_border_halfedges == 0), 1:length(m.edges))
            @test !isnothing(eindex)
            insert_res = insert_vertex_onedge!(initattr!, m, IE(eindex))
            @test length(m.vertices) == 5
            @test length(m.halfedges) == 16
            @test length(m.edges) == 8
            @test length(m.triangles) == 4
            @test length(m.borders) == 1
            @test isempty(fullcheck_mesh_consistency(m))

            @test insert_res.vnew == IV(5)
        end

        # Collapse an inner edge.
        let vindex = findfirst(k -> !onborder(m, IV(k)), 1:length(m.vertices))
            @test vindex == 5
            oh = halfedge(m, IV(vindex))
            @test !onborder(m, edge(m, oh))
            collapse_res = collapse_halfedge!(m, oh)
            @test length(m.vertices) == 4
            @test length(m.halfedges) == 10
            @test length(m.edges) == 5
            @test length(m.triangles) == 2
            @test length(m.borders) == 1
            @test isempty(fullcheck_mesh_consistency(m))

            @test collapse_res.vto.value < 5
        end

        # Collapse a border edge.
        let eindex = findfirst(k -> onborder(m, IE(k)), 1:length(m.edges))
            @test !isnothing(eindex)
            oh = halfedge(m, IE(eindex))
            if polygon(m, oh).type == pt_border
                oh = oppo(m, oh)
            end
            collapse_res = collapse_halfedge!(m, oh)
            @test length(m.vertices) == 3
            @test length(m.halfedges) == 6
            @test length(m.edges) == 3
            @test length(m.triangles) == 1
            @test length(m.borders) == 1
            @test isempty(fullcheck_mesh_consistency(m))

            @test 1 <= collapse_res.vto.value <= 3
        end

        let h = IH(1)
            h_o = oppo(m, h)
            @test_throws ErrorException collapse_halfedge!(m, h)
            @test isempty(fullcheck_mesh_consistency(m))
            @test_throws ErrorException collapse_halfedge!(m, h_o)
            @test isempty(fullcheck_mesh_consistency(m))
        end

        # Initialize as 2 triangles.
        initmesh!_vertex_triangle(m, 4, [SA[1,2,3], SA[3,2,4]])

        # Flip the center edge.
        let eindex = findfirst(k -> !onborder(m, IE(k)), 1:length(m.edges))
            @test !isnothing(eindex)
            flip_edge!(m, IE(eindex))
            @test length(m.vertices) == 4
            @test length(m.halfedges) == 10
            @test length(m.edges) == 5
            @test length(m.triangles) == 2
            @test length(m.borders) == 1
            @test isempty(fullcheck_mesh_consistency(m))
        end
    end
end


@testset "Static half edge mesh" begin
    M = MEDYAN
    SM = MEDYAN.StaticHalfedgeMesh
    DA = MEDYAN.DefaultHalfedgeMeshElementAttr

    @testset "Connection init" begin
        dm = MEDYAN.DynamicHalfedgeMesh((;x=-1, y=NaN), DA(), DA(), DA(), DA(), (0xff, 100))
        @test attrtype_vertex(dm) == @NamedTuple{x::Int, y::Float64}
        @test attrtype_halfedge(dm) == DA
        @test attrtype_edge(dm) == DA
        @test attrtype_triangle(dm) == DA
        @test attrtype_border(dm) == DA
        @test attrtype_meta(dm) == Tuple{UInt8, Int}

        sm = SM(dm)
        @test length(sm.vertices) == 0
        @test length(sm.halfedges) == 0
        @test length(sm.edges) == 0
        @test length(sm.triangles) == 0
        @test length(sm.borders) == 0
        @test sm.metaattr === dm.metaattr

        @test attrtype_vertex(sm) == @NamedTuple{x::Int, y::Float64}
        @test attrtype_halfedge(sm) == DA
        @test attrtype_edge(sm) == DA
        @test attrtype_triangle(sm) == DA
        @test attrtype_border(sm) == DA
        @test attrtype_meta(sm) == Tuple{UInt8, Int}

        # 1 triangle.
        initmesh!_vertex_triangle(dm, 3, [SA[1,2,3]])
        dm.vertices.attr.x[1] = -100
        dm.vertices.attr.x[2] = -200
        dm.vertices.attr.x[3] = -300
        dm.vertices.attr.y[1] = .1
        dm.vertices.attr.y[2] = .2
        dm.vertices.attr.y[3] = .3
        @test isempty(fullcheck_mesh_consistency(dm))

        sm = SM(dm)
        @test length(sm.vertices) == 3
        @test length(sm.halfedges) == 6
        @test length(sm.edges) == 3
        @test length(sm.triangles) == 1
        @test length(sm.borders) == 1

        @test sm.vertices.conn[1].degree == 2
        @test sm.vertices.conn[2].degree == 2
        @test sm.vertices.conn[3].degree == 2
        @test sm.vertices.conn[1].onborder == true
        @test sm.vertices.conn[2].onborder == true
        @test sm.vertices.conn[3].onborder == true
        @test sm.halfedges.conn[1].vertex_indices == SA[3, 1, 2]
        @test sm.halfedges.conn[2].vertex_indices == SA[1, 2, 3]
        @test sm.halfedges.conn[3].vertex_indices == SA[2, 3, 1]
        @test sm.halfedges.conn[4].vertex_indices == SA[1, 3, 2]
        @test sm.halfedges.conn[5].vertex_indices == SA[3, 2, 1]
        @test sm.halfedges.conn[6].vertex_indices == SA[2, 1, 3]
        @test sm.halfedges.conn[1].polygon_type == pt_triangle
        @test sm.halfedges.conn[2].polygon_type == pt_triangle
        @test sm.halfedges.conn[3].polygon_type == pt_triangle
        @test sm.halfedges.conn[4].polygon_type == pt_border
        @test sm.halfedges.conn[5].polygon_type == pt_border
        @test sm.halfedges.conn[6].polygon_type == pt_border
        @test sm.edges.conn[1].vertex_indices == SA[1, 3]
        @test sm.edges.conn[2].vertex_indices == SA[2, 1]
        @test sm.edges.conn[3].vertex_indices == SA[3, 2]
        @test sm.edges.conn[1].polygon_types == SA[pt_triangle, pt_border]
        @test sm.edges.conn[2].polygon_types == SA[pt_triangle, pt_border]
        @test sm.edges.conn[3].polygon_types == SA[pt_triangle, pt_border]
        @test sm.edges.conn[1].polygon_indices == SA[1, 1]
        @test sm.edges.conn[2].polygon_indices == SA[1, 1]
        @test sm.edges.conn[3].polygon_indices == SA[1, 1]
        @test sm.triangles.conn[1].vertex_indices == SA[1, 2, 3]
        @test sm.triangles.conn[1].halfedge_indices == SA[1, 2, 3]
        @test sm.triangles.conn[1].edge_indices == SA[1, 2, 3]

        @test onborder(sm, IV(1))
        @test onborder(sm, IV(2))
        @test onborder(sm, IV(3))
        @test onborder(sm, IE(1))
        @test onborder(sm, IE(2))
        @test onborder(sm, IE(3))

        @test sm.metaconn.max_vertex_degree == 2
        @test size(sm.metaconn.indices_nearvertex) == (M.indices_nearvertex_stride(2), 3)
        @test SMatrix{3,2,Int}(get_neighbor_vertex(   sm, in, iv) for iv ∈ (1,2,3), in ∈ (1,2)) == SA[3 2; 1 3; 2 1]
        @test SMatrix{3,2,Int}(get_targeting_halfedge(sm, in, iv) for iv ∈ (1,2,3), in ∈ (1,2)) == SA[1 6; 2 5; 3 4]
        @test SMatrix{3,2,Int}(get_leaving_halfedge(  sm, in, iv) for iv ∈ (1,2,3), in ∈ (1,2)) == SA[4 2; 6 3; 5 1]
        @test SMatrix{3,2,Int}(get_outer_halfedge(    sm, in, iv) for iv ∈ (1,2,3), in ∈ (1,2)) == SA[3 5; 1 4; 2 6]
        @test SMatrix{3,2,Int}(get_targeting_edge(    sm, in, iv) for iv ∈ (1,2,3), in ∈ (1,2)) == SA[1 2; 2 3; 3 1]
        @test SMatrix{3,2,Int}(get_polygon(           sm, in, iv) for iv ∈ (1,2,3), in ∈ (1,2)) == SA[1 1; 1 1; 1 1]

        @test sm.metaattr === dm.metaattr
        @test sm.vertices.attr === dm.vertices.attr

        # Split the 1st edge.
        initattr! = @set default_initattr!.vertex = (m, v::IV) -> begin
            m.vertices.attr.x[v.value] = -100 * v.value
            m.vertices.attr.y[v.value] = .1 * v.value
        end
        insert_vertex_onedge!(initattr!, dm, IE(1))
        @test isempty(fullcheck_mesh_consistency(dm))
        @test dm.vertices.attr.x[4] == -400
        @test dm.vertices.attr.y[4] ≈ .4

        sm = SM(dm)
        @test length(sm.vertices) == 4
        @test length(sm.halfedges) == 10
        @test length(sm.edges) == 5
        @test length(sm.triangles) == 2
        @test length(sm.borders) == 1
        @test sm.vertices.attr.x[4] == -400
        @test sm.vertices.attr.y[4] ≈ .4
        @test sm.metaattr === dm.metaattr
        @test sm.vertices.attr === dm.vertices.attr

        @test count(vindex->onborder(sm, IV(vindex)), eachindex(sm.vertices)) == 4
        @test count(eindex->onborder(sm, IE(eindex)), eachindex(sm.edges)) == 4
    end
end
