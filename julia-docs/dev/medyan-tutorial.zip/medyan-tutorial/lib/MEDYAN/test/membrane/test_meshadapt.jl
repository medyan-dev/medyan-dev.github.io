using LinearAlgebra
using Test
using StaticArrays
using MEDYAN
using MeshCat


import MEDYAN:
    IV, IH, IE, IT, IB,
    target, edge, next, prev, oppo, polygon, triangle, border, halfedge, onborder, degree

@testset "Triangle quality" begin
    q1 = MEDYAN.TriangleQualityRadiusRatio(2.0)
    q2 = MEDYAN.TriangleQualityRadiusRatio(5.0)
    @test MEDYAN.better(q1, q2)
    @test MEDYAN.thebetter(q1, q2) == q1
    @test !MEDYAN.worse(q1, q2)
    @test MEDYAN.theworse(q1, q2) == q2
    @test MEDYAN.improvement(q1, q2) ≈ 0.4

    @test MEDYAN.trianglequality_radiusratio_fromlengths(1.0, 2.0, 3.0).value ≈ Inf
    @test MEDYAN.trianglequality_radiusratio_fromlengths(2.0, 2.0, 2.0).value ≈ 1.0
    @test MEDYAN.trianglequality_radiusratio_fromlengths(25.0, 50.0, 60.0).value ≈
        MEDYAN.trianglequality_radiusratio_fromlengths(2.5, 5.0, 6.0).value
    @test MEDYAN.trianglequality_radiusratio_fromcoords(SA[0,-1], SA[1,0], SA[0,1]).value ≈ (sqrt(2) + 1) / 2
    @test MEDYAN.trianglequality_radiusratio_fromcoords(SA[1,0,1], SA[0,-1,1+sqrt(2)], SA[-1,0,1]).value ≈ 1
end

@testset "Find coordinates to complete equilateral triangle" begin
    ≊(a,b) = isapprox(a, b; atol = 1E-9)
    @test MEDYAN.coord_tocomplete_equilateraltriangle(SA[-1,0,0], SA[1,0,0], SA[0,0,1]) ≊ SA[0,sqrt(3),0]
    @test MEDYAN.coord_tocomplete_equilateraltriangle(SA[1,0,0], SA[0,1,0], SA[1,1,1]/sqrt(3)) ≊ SA[0,0,1]
end

@testset "Mesh adaptation operations" begin
    DM = MEDYAN.DynamicHalfedgeMesh
    DA = MEDYAN.DefaultHalfedgeMeshElementAttr
    VA = @NamedTuple{
        vertexstate::UInt8,
        coord::SVector{3, Float64},
        ada_unitnormal::SVector{3, Float64},
    }
    HA = @NamedTuple{
        θ::Float64,
        cotθ::Float64,
    }
    EA = @NamedTuple{
        ada_eqlength::Float64,
    }
    TA = @NamedTuple{
        unitnormal::SVector{3, Float64},
    }

    ≊(a,b) = isapprox(a, b; atol = 1E-9)
    function updategeo!(m)
        MEDYAN.compute_all_triangle_normals_ada!(m)
        MEDYAN.compute_all_angles_ada!(m)
        MEDYAN.compute_all_vertex_normals_ada!(m)
    end
    splitfunc!(m, e::IE, newcoord) = MEDYAN.insert_vertex_onedge!(
        (;
            vertex = (dm::MEDYAN.DynamicHalfedgeMesh, v::IV) -> begin
                dm.vertices.attr.coord[v.value] = newcoord
            end,
            MEDYAN.default_initattr!.halfedge,
            MEDYAN.default_initattr!.edge,
            MEDYAN.default_initattr!.triangle,
            MEDYAN.default_initattr!.border,
        ),
        m, e
    )
    flipfunc!(m, e::IE) = MEDYAN.flip_edge!(m, e)
    collapsefunc!(m, h::IH, newcoord) = begin
        change = MEDYAN.collapse_halfedge!(m, h)
        m.vertices.attr.coord[change.vto.value] = newcoord
        change
    end
    relocfunc!(m, v::IV, c::AbstractVector) = m.vertices.attr.coord[v.value] = c

    @testset "Try edge splitting" begin
        m = DM(VA, HA, EA, TA, DA, nothing)

        # Test edge splitting coordinates.
        let
            MEDYAN.initmesh!_vertex_triangle(m, 3, [SA[1,2,3]])
            m.vertices.attr.coord[1] = SA[-1,0,0]
            m.vertices.attr.coord[2] = SA[1,0,0]

            m.vertices.attr.ada_unitnormal[1] = SA[0,0,1]
            m.vertices.attr.ada_unitnormal[2] = SA[0,0,1]
            @test MEDYAN.edge_mid_vertex_coordinate(m, IV(1), IV(2)) ≊ SA[0,0,0]

            m.vertices.attr.ada_unitnormal[1] = SA[-1/2,0,sqrt(3)/2]
            m.vertices.attr.ada_unitnormal[2] = SA[ 1/2,0,sqrt(3)/2]
            @test MEDYAN.edge_mid_vertex_coordinate(m, IV(1), IV(2)) ≊ SA[0,0,2-sqrt(3)]

            m.vertices.attr.ada_unitnormal[1] = SA[-1/2,0,sqrt(3)/2]
            m.vertices.attr.ada_unitnormal[2] = SA[-1/2,0,sqrt(3)/2]
            @test MEDYAN.edge_mid_vertex_coordinate(m, IV(1), IV(2)) ≊ SA[0,0,0]
        end

        MEDYAN.initmesh!_vertex_triangle(m, 4, [SA[1,2,3], SA[3,2,4]])

        for h ∈ MEDYAN.HalfedgesTargetingVertex(m, IV(1))
            e = edge(m, h)
            @test MEDYAN.try_split_edge!(splitfunc!, flipfunc!, m, e, MEDYAN.MeshAdaptParams()) == :border
        end

        h_t1_to3 = halfedge(m, IT(1))
        while target(m, h_t1_to3) != IV(3)
            h_t1_to3 = next(m, h_t1_to3)
        end
        emid = edge(m, h_t1_to3)

        @test MEDYAN.try_split_edge!(splitfunc!, flipfunc!, m, emid, MEDYAN.MeshAdaptParams(max_degree=2)) == :invalid_degree

        m.vertices.attr.coord[1] = SA[-2,0,0]
        m.vertices.attr.coord[2] = SA[0,-1,0]
        m.vertices.attr.coord[3] = SA[0,1,0]
        m.vertices.attr.coord[4] = SA[2,0,0]
        updategeo!(m)
        @test MEDYAN.try_split_edge!(splitfunc!, flipfunc!, m, emid, MEDYAN.MeshAdaptParams()) == :not_longest_edge

        m.vertices.attr.coord[1] = SA[-1,0,0]
        m.vertices.attr.coord[2] = SA[0,-1,0]
        m.vertices.attr.coord[3] = SA[0,1,0]
        m.vertices.attr.coord[4] = SA[1,0,0]
        m.edges.attr.ada_eqlength[emid.value] = 114514.1919810
        updategeo!(m)
        @test MEDYAN.try_split_edge!(splitfunc!, flipfunc!, m, emid, MEDYAN.MeshAdaptParams()) == :success
        @test length(m.vertices) == 5
        @test length(m.edges) == 8
        @test isempty(MEDYAN.fullcheck_mesh_consistency(m))

        @test m.vertices.attr.coord[5] ≊ SA[0,0,0]
        for h ∈ MEDYAN.HalfedgesTargetingVertex(m, IV(5))
            @test m.edges.attr.ada_eqlength[edge(m, h).value] == 114514.1919810
        end

        # After splitting, local geometries should be updated.
        @test m.vertices.attr.ada_unitnormal[5] ≊ SA[0,0,1]
        for h ∈ MEDYAN.HalfedgesTargetingVertex(m, IV(5))
            @test m.halfedges.attr.θ[h.value] ≈ π/2
            @test m.halfedges.attr.θ[next(m,h).value] ≈ π/4
        end
    end

    @testset "Try edge collapse" begin
        m = DM(VA, HA, EA, TA, DA, nothing)

        MEDYAN.initmesh!_vertex_triangle(m, 4, [SA[1,2,3], SA[3,2,4]])
        for eindex ∈ 1:length(m.edges)
            e = IE(eindex)
            if onborder(m, e)
                @test MEDYAN.try_collapse_edge!(collapsefunc!, m, e, MEDYAN.MeshAdaptParams()) == :border
            else
                @test MEDYAN.try_collapse_edge!(collapsefunc!, m, e, MEDYAN.MeshAdaptParams()) == :irremovable_vertices
            end
        end

        # Generate 1 fan.
        let
            MEDYAN.initmesh!_vertex_triangle(m, 7, [SA[1,2,3], SA[1,3,4], SA[1,4,5], SA[1,5,6], SA[1,6,7], SA[1,7,2]])
            m.vertices.attr.coord[1] = SA[0,0,0]
            for i ∈ 1:6
                m.vertices.attr.coord[i+1] = SA[cos((i-1)*π/3),sin((i-1)*π/3),0]
            end
            updategeo!(m)

            h = halfedge(m, IV(1))
            e = edge(m, h)
            @test MEDYAN.try_collapse_edge!(collapsefunc!, m, e, MEDYAN.MeshAdaptParams(max_degree=4)) == :invalid_degree
            @test MEDYAN.try_collapse_edge!(collapsefunc!, m, e, MEDYAN.MeshAdaptParams(edge_collapse_min_quality_improvement=0.5)) == :bad_quality
            @test MEDYAN.try_collapse_edge!(collapsefunc!, m, e, MEDYAN.MeshAdaptParams(edge_collapse_min_quality_improvement=0.4)) == :success
            @test isempty(MEDYAN.fullcheck_mesh_consistency(m))
            @test count(vi -> degree(m, IV(vi)) == 5, 1:6) == 1
            @test count(vi -> degree(m, IV(vi)) == 3, 1:6) == 3
            @test count(vi -> degree(m, IV(vi)) == 2, 1:6) == 2
            let vi = findfirst(vi -> degree(m, IV(vi)) == 2, 1:6)
                @test norm(m.vertices.attr.coord[vi]) ≈ 1
                @test m.vertices.attr.ada_unitnormal[vi] ≊ SA[0,0,1]
            end
        end

        # Generate 2 fans.
        let
            MEDYAN.initmesh!_vertex_triangle(m, 10, [
                SA[1,2,3], SA[1,3,4], SA[1,4,5], SA[1,5,6], SA[1,6,7], SA[1,7,2],
                SA[2,7,8], SA[2,8,9], SA[2,9,10], SA[2,10,3]
            ])
            @test isempty(MEDYAN.fullcheck_mesh_consistency(m))

            m.vertices.attr.coord[1] = SA[0,0,0]
            for i ∈ 1:6
                m.vertices.attr.coord[i+1] = SA[cos((i-1)*π/3),sin((i-1)*π/3),0]
            end
            for i ∈ 1:3
                m.vertices.attr.coord[i+7] = SA[cos((i-2)*π/3)+1,sin((i-2)*π/3),0]
            end
            updategeo!(m)

            h21 = halfedge(m, IV(1))
            while h21 |> oppo(m) |> target(m) != IV(2)
                h21 = h21 |> oppo(m) |> prev(m)
            end
            e = edge(m, h21)

            @test MEDYAN.try_collapse_edge!(collapsefunc!, m, e, MEDYAN.MeshAdaptParams(max_degree=7)) == :invalid_degree
            @test MEDYAN.try_collapse_edge!(collapsefunc!, m, e, MEDYAN.MeshAdaptParams(edge_collapse_min_quality_improvement=1.0)) == :bad_quality

            # Move vertices 7, 8, 9 to very high position.
            for i ∈ 1:3
                m.vertices.attr.coord[i+7] = SA[cos((i-2)*π/3)+1,sin((i-2)*π/3),1000]
            end
            updategeo!(m)
            @test MEDYAN.try_collapse_edge!(collapsefunc!, m, e, MEDYAN.MeshAdaptParams()) == :bad_dihedral

            # Move those vertices back.
            for i ∈ 1:3
                m.vertices.attr.coord[i+7] = SA[cos((i-2)*π/3)+1,sin((i-2)*π/3),0]
            end
            updategeo!(m)
            @test MEDYAN.try_collapse_edge!(collapsefunc!, m, e, MEDYAN.MeshAdaptParams()) == :success
            @test length(m.vertices) == 9
            @test isempty(MEDYAN.fullcheck_mesh_consistency(m))
            let vi = findfirst(vi -> degree(m, IV(vi)) == 8, 1:9)
                @test !isnothing(vi)
                @test m.vertices.attr.coord[vi] ≊ SA[0.5,0,0]
                @test m.vertices.attr.ada_unitnormal[vi] ≊ SA[0,0,1]
            end
        end
    end

    @testset "Try edge flipping" begin
        m = DM(VA, HA, EA, TA, DA, nothing)

        MEDYAN.initmesh!_vertex_triangle(m, 4, [SA[1,2,3], SA[3,2,4]])
        # Set coordinates.
        m.vertices.attr.coord[1] = SA[0,0,0]
        m.vertices.attr.coord[2] = SA[1,0,0]
        m.vertices.attr.coord[3] = SA[0,1,0]
        m.vertices.attr.coord[4] = SA[1,1,1]
        updategeo!(m)

        for h ∈ MEDYAN.HalfedgesTargetingVertex(m, IV(1))
            e = edge(m, h)
            @test MEDYAN.try_flip_edge!(flipfunc!, m, e, MEDYAN.MeshAdaptParams()) == :border
        end

        h_t1_to3 = halfedge(m, IT(1))
        while target(m, h_t1_to3) != IV(3)
            h_t1_to3 = next(m, h_t1_to3)
        end
        emid = edge(m, h_t1_to3)

        @test MEDYAN.try_flip_edge!(flipfunc!, m, emid, MEDYAN.MeshAdaptParams(max_degree=2)) == :invalid_degree
        @test MEDYAN.try_flip_edge!(flipfunc!, m, emid, MEDYAN.MeshAdaptParams(edge_flip_min_dot_normal=0.99)) == :non_coplanar

        # Make vertices 1, 2, 4 on the same line.
        m.vertices.attr.coord[4] = SA[2,0,0]
        updategeo!(m)
        @test MEDYAN.try_flip_edge!(flipfunc!, m, emid, MEDYAN.MeshAdaptParams()) == :degenerate

        # Make original triangles almost coplanar while the new ones are not.
        m.vertices.attr.coord[1] = SA[-1000,0,0]
        m.vertices.attr.coord[2] = SA[0,-1,-1]
        m.vertices.attr.coord[3] = SA[0,1,-1]
        m.vertices.attr.coord[4] = SA[1000,0,0]
        updategeo!(m)
        @test MEDYAN.try_flip_edge!(flipfunc!, m, emid, MEDYAN.MeshAdaptParams(edge_flip_min_dot_normal=0.9)) == :non_coplanar

        # In the same case above, the triangle quality is worse if edge is flipped.
        @test MEDYAN.try_flip_edge!(flipfunc!, m, emid, MEDYAN.MeshAdaptParams(edge_flip_min_dot_normal=-1)) == :bad_quality

        # Rotate the mesh so that it looks the same but flipped.
        m.vertices.attr.coord[1] = SA[0,-1,-1]
        m.vertices.attr.coord[2] = SA[1000,0,0]
        m.vertices.attr.coord[3] = SA[-1000,0,0]
        m.vertices.attr.coord[4] = SA[0,1,-1]
        updategeo!(m)
        @test MEDYAN.try_flip_edge!(flipfunc!, m, emid, MEDYAN.MeshAdaptParams(edge_flip_min_dot_normal=-1)) == :success
        @test target(m, halfedge(m, emid)) ∈ (IV(1), IV(4))
        @test isempty(MEDYAN.fullcheck_mesh_consistency(m))

        # After edge flip, the associated geometries should be updated.
        h_mid_to1 = halfedge(m, emid)
        if target(m, h_mid_to1) != IV(1)
            h_mid_to1 = oppo(m, h_mid_to1)
        end
        @test cot(m.halfedges.attr.θ[next(m, h_mid_to1).value] / 2) ≈ sqrt(1000^2 + 1^2)
        @test m.halfedges.attr.cotθ[h_mid_to1.value] ≈ 1/sqrt(1000^2 + 1^2)
        @test m.triangles.attr.unitnormal[triangle(m, h_mid_to1).value] ≊ normalize(SA[-1,0,1000])
        @test m.vertices.attr.ada_unitnormal[target(m, h_mid_to1).value] ≊ SA[0,0,1]
    end

    @testset "Vertex relocation" begin
        m = DM(VA, HA, EA, TA, DA, nothing)

        # Init 1 triangle.
        MEDYAN.initmesh!_vertex_triangle(m, 3, [SA[1,2,3]])
        m.vertices.attr.coord[1] = SA[1,0,0]
        m.vertices.attr.coord[2] = SA[0,1,0]
        m.vertices.attr.coord[3] = SA[-1,0,0]
        updategeo!(m)

        @test MEDYAN.coord_optimalvertex_barycenter(m, IV(1)) ≊ SA[(sqrt(3)-1)/2, -(sqrt(3)-1)/2, 0]
        @test MEDYAN.coord_optimalvertex_barycenter(m, IV(2)) ≊ SA[0, sqrt(3), 0]

        # Border vertices are not moved during vertex relocation.
        MEDYAN.movevertices!_coordoptimal(relocfunc!, flipfunc!, m, MEDYAN.MeshAdaptParams())
        @test m.vertices.attr.coord[1] ≊ SA[1,0,0]
        @test m.vertices.attr.coord[2] ≊ SA[0,1,0]
        @test m.vertices.attr.coord[3] ≊ SA[-1,0,0]

        # Init a fan of 3 triangles.
        MEDYAN.initmesh!_vertex_triangle(m, 4, [SA[1,2,3], SA[1,3,4], SA[1,4,2]])
        m.vertices.attr.coord[1] = SA[0.1, -0.1, 0]
        m.vertices.attr.coord[2] = SA[0, -1, 0]
        m.vertices.attr.coord[3] = SA[sqrt(3), 0, 0]
        m.vertices.attr.coord[4] = SA[0, 0, 0]
        updategeo!(m)

        @test MEDYAN.coord_optimalvertex_barycenter(m, IV(1)) ≊ SA[sqrt(3)/3, -1/3, 0]

        MEDYAN.movevertices!_coordoptimal(relocfunc!, flipfunc!, m, MEDYAN.MeshAdaptParams())
        @test m.vertices.attr.coord[1] ≊ SA[sqrt(3)/3, -1/3, 0]
    end

    @testset "Mesh smoothing" begin
        m = DM(VA, HA, EA, TA, DA, nothing)
        # Octahedron.
        MEDYAN.initmesh!_vertex_triangle(m, 6, [SA[1,2,3], SA[1,3,4], SA[1,4,5], SA[1,5,2], SA[6,5,4], SA[6,4,3], SA[6,3,2], SA[6,2,5]])
        m.vertices.attr.coord[1] = SA[0, 0, 1]
        m.vertices.attr.coord[2] = SA[0, 1, 0]
        m.vertices.attr.coord[3] = SA[-1, 0, 0]
        m.vertices.attr.coord[4] = SA[0, -1, 0]
        m.vertices.attr.coord[5] = SA[1, 0, 0]
        m.vertices.attr.coord[6] = SA[0, 0, -1]

        dt = 0.01
        iter = 100
        fac = 1 - dt * 4 / sqrt(3)
        MEDYAN.meshsmoothing!(m, dt, iter)
        newr_expect = fac^iter
        @test m.vertices.attr.coord[1] ≊ SA[0,0,newr_expect]
    end

    @testset "Size measure" begin
        m = DM(VA, HA, EA, TA, DA, nothing)

        # Init 1 triangle.
        MEDYAN.initmesh!_vertex_triangle(m, 3, [SA[1,2,3]])
        m.vertices.attr.coord[1] = SA[1,0,0]
        m.vertices.attr.coord[2] = SA[0,2,0]
        m.vertices.attr.coord[3] = SA[-3,0,0]
        updategeo!(m)

        MEDYAN.compute_sizemeasure!(m, MEDYAN.MeshAdaptParams(min_size=0.0, max_size=100.0, diffuse_iter=0))
        @test m.edges.attr.ada_eqlength[1] ≈ (sqrt(13)+sqrt(5))/2
        @test m.edges.attr.ada_eqlength[2] ≈ sqrt(5)
        @test m.edges.attr.ada_eqlength[3] ≈ (sqrt(13)+sqrt(5))/2

        # Octahedron.
        MEDYAN.initmesh!_vertex_triangle(m, 6, [SA[1,2,3], SA[1,3,4], SA[1,4,5], SA[1,5,2], SA[6,5,4], SA[6,4,3], SA[6,3,2], SA[6,2,5]])
        m.vertices.attr.coord[1] = SA[0, 0, 1]
        m.vertices.attr.coord[2] = SA[0, 1, 0]
        m.vertices.attr.coord[3] = SA[-1, 0, 0]
        m.vertices.attr.coord[4] = SA[0, -1, 0]
        m.vertices.attr.coord[5] = SA[1, 0, 0]
        m.vertices.attr.coord[6] = SA[0, 0, -1]
        updategeo!(m)

        MEDYAN.compute_sizemeasure!(m, MEDYAN.MeshAdaptParams(curvature_resolution=0.3, min_size=0, max_size=100, diffuse_iter=100))
        for eindex ∈ 1:length(m.edges)
            @test m.edges.attr.ada_eqlength[eindex] ≈ 0.3
        end
        MEDYAN.compute_sizemeasure!(m, MEDYAN.MeshAdaptParams(curvature_resolution=0.3, min_size=0.1, max_size=0.2, diffuse_iter=100))
        for eindex ∈ 1:length(m.edges)
            @test m.edges.attr.ada_eqlength[eindex] ≈ 0.2
        end
    end

    @testset "Mesh adaptation" begin
        m = DM(VA, HA, EA, TA, DA, nothing)

        # Octahedron.
        r = 100
        MEDYAN.initmesh!_vertex_triangle(m, 6, [SA[1,2,3], SA[1,3,4], SA[1,4,5], SA[1,5,2], SA[6,5,4], SA[6,4,3], SA[6,3,2], SA[6,2,5]])
        m.vertices.attr.coord[1] = SA[0, 0, r]
        m.vertices.attr.coord[2] = SA[0, r, 0]
        m.vertices.attr.coord[3] = SA[-r, 0, 0]
        m.vertices.attr.coord[4] = SA[0, -r, 0]
        m.vertices.attr.coord[5] = SA[r, 0, 0]
        m.vertices.attr.coord[6] = SA[0, 0, -r]
        updategeo!(m)

        p = MEDYAN.MeshAdaptParams()
        MEDYAN.adaptmesh!(splitfunc!, collapsefunc!, flipfunc!, relocfunc!, m, p)

        # Test that the mesh is closed and has the same topology.
        @test isempty(MEDYAN.fullcheck_mesh_consistency(m))
        @test length(m.borders) == 0
        @test length(m.vertices) + length(m.triangles) - length(m.edges) == 2

        # Test that the mesh is correctly adapted.
        let
            local ne_badlen = 0
            local ne_baddihedral = 0

            local cos_res = cos(p.curvature_resolution)
            for eindex ∈ 1:length(m.edges)
                local e = IE(eindex)
                local h = halfedge(m, e)
                local h_o = oppo(m, h)
                local h_n = next(m, h)
                local h_on = next(m, h_o)
                local c1 = m.vertices.attr.coord[target(m, h).value]
                local c2 = m.vertices.attr.coord[target(m, h_o).value]
                local c3 = m.vertices.attr.coord[target(m, h_n).value]
                local c4 = m.vertices.attr.coord[target(m, h_on).value]

                local n1 = normalize(cross(c2 - c1, c3 - c1))
                local n2 = normalize(cross(c1 - c2, c4 - c2))
                local dp = dot(n1, n2)
                local len = norm(c1 - c2)
                local eqlen = m.edges.attr.ada_eqlength[eindex]

                if 2 * len < eqlen || len > 2 * eqlen
                    ne_badlen += 1
                end
                if dp < cos_res * 0.9
                    ne_baddihedral += 1
                end
            end
            @test ne_badlen / length(m.edges) < 0.05
            @test ne_baddihedral / length(m.edges) < 0.05
        end
    end
end
