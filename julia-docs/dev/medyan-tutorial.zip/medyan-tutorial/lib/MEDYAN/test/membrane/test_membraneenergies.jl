using LinearAlgebra
using MEDYAN
using Test
using StaticArrays

import MEDYAN:
    IV, IH, IE, IT, IB,
    target, edge, next, prev, oppo, polygon, triangle, border, halfedge, onborder, degree

@testset "Membrane bending energy" begin

    ≊(a,b) = isapprox(a,b; atol=1e-9)

    # Octahedron.
    let
        # Initialize 6 vertices.
        dm = MEDYAN.create_membranemesh()
        MEDYAN.initmesh!_vertex_triangle(dm, 6, [SA[1,2,3], SA[1,3,4], SA[1,4,5], SA[1,5,2], SA[6,5,4], SA[6,4,3], SA[6,3,2], SA[6,2,5]])
        sm = MEDYAN.StaticHalfedgeMesh(dm)
        MEDYAN.cachecoordindices!(sm)

        # Define coordinates and update geometry.
        x = Float64[
            0, 0, 1,
            0, 1, 0,
            -1, 0, 0,
            0, -1, 0,
            1, 0, 0,
            0, 0, -1,
        ]
        MEDYAN.compute_geometry!(sm, x, Val(MEDYAN.meshcurv_se))
        @test sm.vertices.attr.astar[1] ≈ 2 * sqrt(3)
        @test sm.vertices.attr.curv[1] ≈ sqrt(3)

        # Bending.
        let params = MEDYAN.MembraneMechParams(kbend=100)
            local f = zeros(length(x))
            local es = MEDYAN.membrane_energies!(params, nothing, sm, x, f)
            @test es.e_bending ≈ 2400 * sqrt(3)
            @test es.e_area == 0
            @test es.e_tension == 0
            @test es.e_volume == 0
            @test es.e_pinning == 0
            @test maximum(abs, f) < 1e-9
        end
        let params = MEDYAN.MembraneMechParams(kbend=100, eqcurv=2*sqrt(3))
            local f = zeros(length(x))
            local es = MEDYAN.membrane_energies!(params, nothing, sm, x, f)
            @test es.e_bending ≈ 2400 * sqrt(3)
            @test es.e_area == 0
            @test es.e_tension == 0
            @test es.e_volume == 0
            @test es.e_pinning == 0
            @test f ≊ x * (-1600*sqrt(3))
        end

        # Area.
        let params = MEDYAN.MembraneMechParams(karea=400, eqarea=4*sqrt(3))
            local f = zeros(length(x))
            local es = MEDYAN.membrane_energies!(params, nothing, sm, x, f)
            @test es.e_area ≊ 0
            @test maximum(abs, f) < 1e-9
        end
        let params = MEDYAN.MembraneMechParams(karea=400, eqarea=8*sqrt(3))
            local f = zeros(length(x))
            local es = MEDYAN.membrane_energies!(params, nothing, sm, x, f)
            @test es.e_area ≈ 400 * sqrt(3)
            @test f ≊ x * (800 / sqrt(3))
        end

        # Tension.
        let params = MEDYAN.MembraneMechParams(tension=0.02)
            local f = zeros(length(x))
            local es = MEDYAN.membrane_energies!(params, nothing, sm, x, f)
            @test es.e_tension ≈ 0.08 * sqrt(3)
            @test f ≊ x * (-0.08 / sqrt(3))
        end

        # Volume.
        let params = MEDYAN.MembraneMechParams(kvolume=0.8, eqvolume=4/3)
            local f = zeros(length(x))
            local es = MEDYAN.membrane_energies!(params, nothing, sm, x, f)
            @test es.e_volume ≊ 0
            @test maximum(abs, f) < 1e-9
        end
        let params = MEDYAN.MembraneMechParams(kvolume=0.8, eqvolume=2, offsetvolume=1)
            local f = zeros(length(x))
            local es = MEDYAN.membrane_energies!(params, nothing, sm, x, f)
            @test es.e_volume ≈ 0.8 / 36
            @test f ≊ x * (-0.8 / 9)
        end

        # Edge length protection.
        let params = MEDYAN.MembraneMechParams(; edgelength_mem3dg_k=100.0, edgelength_mem3dg_min=sqrt(2))
            local f = zeros(length(x))
            local es = MEDYAN.membrane_energies!(params, nothing, sm, x, f)
            @test es.e_edgelengthprotect ≊ 0
            @test maximum(abs, f) < 1e-9
        end
        let params = MEDYAN.MembraneMechParams(; edgelength_mem3dg_k=100.0, edgelength_mem3dg_min=2*sqrt(2))
            local f = zeros(length(x))
            local es = MEDYAN.membrane_energies!(params, nothing, sm, x, f)
            @test es.e_edgelengthprotect ≊ 12 * (-100/2) * log(3/4)
            @test f ≊ x * (400 / 6)
        end
    end

    # Cone + bottomless prism.
    let
        dm = MEDYAN.create_membranemesh()
        MEDYAN.initmesh!_vertex_triangle(dm, 7, [SA[1,2,3], SA[1,3,4], SA[1,4,2],  SA[2,5,3], SA[3,5,6], SA[3,6,4], SA[4,6,7], SA[4,7,2], SA[2,7,5]])
        sm = MEDYAN.StaticHalfedgeMesh(dm)
        MEDYAN.cachecoordindices!(sm)

        # Define coordinates and update geometry.
        x = Float64[
            0, 0, 2,
            0, 0, 1,
            1, 0, 1,
            0, 1, 1,
            0, 0, 0,
            1, 0, 0,
            0, 1, 0,
        ]
        sm.vertices.attr.coord .= reinterpret(SVector{3,Float64}, x)
        MEDYAN.compute_geometry!(sm, x, Val(MEDYAN.meshcurv_se))

        let params = MEDYAN.MembraneMechParams(kpinning=100)
            local newx = x + [ifelse(i % 3 == 0, 2.0, 0.0) for i ∈ eachindex(x)]
            # No pinning.
            let
                MEDYAN.updatevertexpinning!(dm, Val(:none))
                local f = zeros(length(x))
                local es = MEDYAN.membrane_energies!(params, nothing, sm, newx, f)
                @test es.e_pinning == 0
                @test all(==(0), f)
            end

            # Border pinning only.
            let
                MEDYAN.updatevertexpinning!(dm, Val(:border1))
                local f = zeros(length(x))
                local es = MEDYAN.membrane_energies!(params, nothing, sm, newx, f)
                @test es.e_pinning == 200 * 3
                @test f ≊ [0,0,0, 0,0,0, 0,0,0, 0,0,0, 0,0,-200, 0,0,-200, 0,0,-200]
            end

            # Border double layer pinning.
            let
                MEDYAN.updatevertexpinning!(dm, Val(:border2))
                local f = zeros(length(x))
                local es = MEDYAN.membrane_energies!(params, nothing, sm, newx, f)
                @test es.e_pinning == 200 * 6
                @test f ≊ [0,0,0, 0,0,-200, 0,0,-200, 0,0,-200, 0,0,-200, 0,0,-200, 0,0,-200]
            end
        end
    end
end

@testset "Membrane species free energy" begin

    @testset "Pairwise interaction energies" begin
        # Initialize 6 vertices.
        speciesnames = (:s1,)
        dm = MEDYAN.create_membranemesh(Val(speciesnames))
        MEDYAN.initmesh!_vertex_triangle(dm, 6, [SA[1,2,3], SA[1,3,4], SA[1,4,5], SA[1,5,2], SA[6,5,4], SA[6,4,3], SA[6,3,2], SA[6,2,5]])
        dm.vertices.attr.copynumbers.s1 .= [100, 100, 100, 100, 200, 300]
        sm = MEDYAN.StaticHalfedgeMesh(dm)
        MEDYAN.cachecoordindices!(sm)

        x = Float64[
            0, 0, 1,
            0, 1, 0,
            -1, 0, 0,
            0, -1, 0,
            1, 0, 0,
            0, 0, -1,
        ]
        # Make internal coordinates the same values as in x.
        dm.vertices.attr.coord .= reinterpret(SVector{3,Float64}, x)

        local vectorize_result = (; smeshes = (sm,))
        local f = zeros(length(x))
        local compgeo!(x) = MEDYAN.compute_geometry!(sm, x, Val(MEDYAN.meshcurv_se))
        local compgeo!sys() = MEDYAN.compute_geometry!_system(dm)

        # Individual potential energies.
        let
            inter = MEDYAN.MembraneSpeciesPotentialEnergy_PairwiseInteraction((
                MEDYAN.MembraneSpeciesPairwiseInteractionParams(μ0 = 0, μ2 = 0),
            ))
            compgeo!sys()
            @test all(vindex -> inter(dm, MEDYAN.IV(vindex), 1) == 0, eachindex(dm.vertices))
        end
        let
            inter = MEDYAN.MembraneSpeciesPotentialEnergy_PairwiseInteraction((
                MEDYAN.MembraneSpeciesPairwiseInteractionParams(μ0 = -10, μ2 = 0),
            ))
            compgeo!sys()
            @test [inter(dm, MEDYAN.IV(vindex), 1) for vindex ∈ eachindex(dm.vertices)] ≈
                dm.vertices.attr.copynumbers.s1 * (-10 / 2 * sqrt(3))
        end
        let
            inter = MEDYAN.MembraneSpeciesPotentialEnergy_PairwiseInteraction((
                MEDYAN.MembraneSpeciesPairwiseInteractionParams(μ0 = 0, μ2 = -10),
            ))
            compgeo!sys()
            @test [inter(dm, MEDYAN.IV(vindex), 1) for vindex ∈ eachindex(dm.vertices)] ≈
                [100, 300, 200, 300, -200, -700, ] * (-10 * sqrt(3) / 4)
        end

        # Total free energies.
        let
            inter! = MEDYAN.MembraneSpeciesFreeEnergy!_PairwiseInteraction((
                MEDYAN.MembraneSpeciesPairwiseInteractionParams(μ0 = 0, μ2 = 0),
            ))
            fill!(f, 0)
            compgeo!(x)
            local e = inter!(vectorize_result, 1, x, f)
            @test e == 0
            @test all(==(0), f)
        end
        let
            inter! = MEDYAN.MembraneSpeciesFreeEnergy!_PairwiseInteraction((
                MEDYAN.MembraneSpeciesPairwiseInteractionParams(μ0 = -10, μ2 = 0),
            ))
            fill!(f, 0)
            compgeo!(x)
            local e = inter!(vectorize_result, 1, x, f)
            @test e ≈ -10 * sqrt(3) / 4 * (170000)

            f_discard = copy(f)
            dx = randn(length(x)) * 1e-4
            compgeo!(x-dx)
            local e1 = inter!(vectorize_result, 1, x-dx, f_discard)
            compgeo!(x+dx)
            local e2 = inter!(vectorize_result, 1, x+dx, f_discard)
            @test dot(dx, f) * 2 ≈ e1 - e2  rtol = 1e-4
        end
        let
            inter! = MEDYAN.MembraneSpeciesFreeEnergy!_PairwiseInteraction((
                MEDYAN.MembraneSpeciesPairwiseInteractionParams(μ0 = 0, μ2 = -10),
            ))
            fill!(f, 0)
            compgeo!(x)
            local e = inter!(vectorize_result, 1, x, f)
            @test e ≈ 10 * sqrt(3) / 2 * (10000 / 2 + 40000 / 2 + 40000 * 3 / 8)

            f_discard = copy(f)
            dx = randn(length(x)) * 1e-4
            compgeo!(x-dx)
            local e1 = inter!(vectorize_result, 1, x-dx, f_discard)
            compgeo!(x+dx)
            local e2 = inter!(vectorize_result, 1, x+dx, f_discard)
            @test dot(dx, f) * 2 ≈ e1 - e2  rtol = 1e-4
        end

        # Compare expressions of individual vs total.
        let
            inter = MEDYAN.MembraneSpeciesPotentialEnergy_PairwiseInteraction((
                MEDYAN.MembraneSpeciesPairwiseInteractionParams(μ0 = -10, μ2 = -10),
            ))
            inter! = MEDYAN.MembraneSpeciesFreeEnergy!_PairwiseInteraction((
                MEDYAN.MembraneSpeciesPairwiseInteractionParams(μ0 = -10, μ2 = -10),
            ))
            dm.vertices.attr.copynumbers.s1 .= [0,0,0,0,0,0]
            compgeo!(x)
            compgeo!sys()
            ep::Float64 = 0
            for i ∈ 1:100
                dm.vertices.attr.copynumbers.s1[1] += 1
                ep += inter(dm, MEDYAN.IV(1), 1)
            end
            for i ∈ 1:200
                dm.vertices.attr.copynumbers.s1[4] += 1
                ep += inter(dm, MEDYAN.IV(4), 1)
            end
            for i ∈ 1:500
                dm.vertices.attr.copynumbers.s1[5] += 1
                ep += inter(dm, MEDYAN.IV(5), 1)
            end
            ef = inter!(vectorize_result, 1, x, f)
            @test ep ≈ ef  rtol=5e-2
        end
    end

    @testset "Bashkirov bending formula." begin
        # Initialize 6 vertices.
        speciesnames = (:s1,)
        dm = MEDYAN.create_membranemesh(Val(speciesnames))
        MEDYAN.initmesh!_vertex_triangle(dm, 6, [SA[1,2,3], SA[1,3,4], SA[1,4,5], SA[1,5,2], SA[6,5,4], SA[6,4,3], SA[6,3,2], SA[6,2,5]])
        dm.vertices.attr.copynumbers.s1 .= [100, 100, 100, 100, 100, 100]
        sm = MEDYAN.StaticHalfedgeMesh(dm)
        MEDYAN.cachecoordindices!(sm)

        x = Float64[
            0, 0, 100,
            0, 100, 0,
            -100, 0, 0,
            0, -100, 0,
            100, 0, 0,
            0, 0, -100,
        ]
        # Make internal coordinates the same values as in x.
        dm.vertices.attr.coord .= reinterpret(SVector{3,Float64}, x)

        local vectorize_result = (; smeshes = (sm,))
        local f = zeros(length(x))
        local compgeo!(x) = MEDYAN.compute_geometry!(sm, x, Val(MEDYAN.meshcurv_se))
        local compgeo!sys() = MEDYAN.compute_geometry!_system(dm)

        # Total free energies, as well as force-energy consistency.
        let
            compgeo!(x)
            @test all(≈(sqrt(3) / 100), sm.vertices.attr.curv)

            params = MEDYAN.MembraneMechParams(kbend=100)
            params_species = SA[
                MEDYAN.MembraneSpeciesParams(area=0, kbend=200, eqcurv=sqrt(3)/50),
            ]
            fill!(f, 0)
            e_bend = MEDYAN.membrane_energies!_bending_bashkirov(params, params_species, sm, x, f)
            @test all(x->abs(x)<1e-9, f)
            @test e_bend ≈ 2400 * sqrt(3)

            params_species = SA[
                MEDYAN.MembraneSpeciesParams(area=10*(2/sqrt(3)), kbend=200, eqcurv=sqrt(3)/50),
            ]
            e_bend = MEDYAN.membrane_energies!_bending_bashkirov(params, params_species, sm, x, f)
            @test e_bend ≈ let
                keff = 300 / 2.8
                curv = sqrt(3) / 100
                eqcurv = sqrt(3)/50 * (2/3) * 0.1
                area = 6 * (2/sqrt(3)) * 10000
                2 * keff * (curv - eqcurv)^2 * area
            end
        end
        let
            # Energy force consistency
            params = MEDYAN.MembraneMechParams(kbend=100)
            params_species = SA[
                MEDYAN.MembraneSpeciesParams(area=10*(2/sqrt(3)), kbend=200, eqcurv=sqrt(3)/50),
            ]
            fill!(f, 0)
            compgeo!(x)
            dm.vertices.attr.copynumbers.s1 .= [100, 300, 500, 700, 900, 1100]
            local e = MEDYAN.membrane_energies!_bending_bashkirov(params, params_species, sm, x, f)

            f_discard = copy(f)
            dx = randn(length(x)) * 1e-4
            compgeo!(x-dx)
            local e1 = MEDYAN.membrane_energies!_bending_bashkirov(params, params_species, sm, x-dx, f_discard)
            compgeo!(x+dx)
            local e2 = MEDYAN.membrane_energies!_bending_bashkirov(params, params_species, sm, x+dx, f_discard)
            @test dot(dx, f) * 2 ≈ e1 - e2  rtol = 1e-4
        end

        # Compare expressions of individual vs total.
        let
            params_mech = SA[MEDYAN.MembraneMechParams(kbend=100)]
            params_species = SA[
                MEDYAN.MembraneSpeciesParams(area=10*(2/sqrt(3)), kbend=200, eqcurv=sqrt(3)/50),
            ]
            params_species_plain = SA[
                MEDYAN.MembraneSpeciesParams(),
            ]

            inter = MEDYAN.MembraneSpeciesPotentialEnergy_BendingBashkirov(;
                params_mech,
                params_species,
            )
            dm.vertices.attr.copynumbers.s1 .= [0,0,0,0,0,0]
            compgeo!(x)
            ep::Float64 = 0
            for i ∈ 1:100
                dm.vertices.attr.copynumbers.s1[1] += 1
                ep += inter(dm, MEDYAN.IV(1), 1)
            end
            for i ∈ 1:200
                dm.vertices.attr.copynumbers.s1[4] += 1
                ep += inter(dm, MEDYAN.IV(4), 1)
            end
            for i ∈ 1:500
                dm.vertices.attr.copynumbers.s1[5] += 1
                ep += inter(dm, MEDYAN.IV(5), 1)
            end
            ef = MEDYAN.membrane_energies!_bending_bashkirov(params_mech[1], params_species, sm, x, f) - MEDYAN.membrane_energies!_bending_bashkirov(params_mech[1], params_species_plain, sm, x, f)
            @test ep ≈ ef  rtol=5e-2
        end
        
    end
end
