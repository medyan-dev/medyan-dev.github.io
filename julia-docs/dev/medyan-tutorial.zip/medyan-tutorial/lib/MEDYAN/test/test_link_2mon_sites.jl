using MEDYAN
using StaticArrays
using Random
using LinearAlgebra
using Test

"""
Return the site count of a link_2mon under tension of f in pN
"""
function testlink_2mon_sitecount_tension(site,chemstate,minusmonomerstates,plusmonomerstates,f,is_minimized)
    m_pos = SA[0.0,0.0,0.0]
    p_pos = SA[0.0,3.0,0.0]
    m_plusv = SA[1.0,0.0,0.0]
    p_plusv = m_plusv
    mechparams = MEDYAN.DistanceRestraintMechParams(k=f)
    mechstate = (L0=2.0,)
    link_2mon_state = Link2MonState(chemstate,mechstate,is_minimized)
    MEDYAN.link_2mon_sitecount(
        site,
        link_2mon_state, mechparams,
        1, 1,
        minusmonomerstates, plusmonomerstates,
        m_pos, p_pos, m_plusv, p_plusv
    )
end

"""
Return the site count of a link_2mon under a force pulling both filaments axially, f in pN 
if `direction` is +1, the force is pulling the filaments towards their minus end,
    +------- ->--<- -------+
if `direction` is -1, the force is pulling the filaments towards their plus end,
    -------+ ->--<- +-------
"""
function testlink_2mon_sitecount_drag(site,chemstate,minusmonomerstates,plusmonomerstates,f,is_minimized,direction)
    m_pos = SA[0.0,0.0,0.0]
    p_pos = SA[3.0,0.0,0.0]
    m_plusv = -direction*SA[1.0,0.0,0.0]
    p_plusv = -m_plusv
    mechparams = MEDYAN.DistanceRestraintMechParams(k=f)
    mechstate = (L0=2.0,)
    link_2mon_state = Link2MonState(chemstate,mechstate,is_minimized)
    MEDYAN.link_2mon_sitecount(
        site,
        link_2mon_state, mechparams,
        1, 1,
        minusmonomerstates, plusmonomerstates,
        m_pos, p_pos, m_plusv, p_plusv
    )
end

@testset "Link_2mon Sites" begin
    blankstates = ones(MonomerState,3)
    @testset "Link2MonSiteSlipBond" begin
        site = MEDYAN.Link2MonSiteSlipBond(f0=4.9,k0=2.0,kmax=1E6)
        @test testlink_2mon_sitecount_tension(site,(;),blankstates,blankstates,10.0,false) == 2.0
        @test testlink_2mon_sitecount_tension(site,(;),blankstates,blankstates,10.0,true) ≈ 2exp(10.0/4.9)
        @test testlink_2mon_sitecount_tension(site,(;),blankstates,blankstates,100.0,true) ≈ 1E6
        @test testlink_2mon_sitecount_tension(site,(;),blankstates,blankstates,-10.0,true) ≈ 2exp(10.0/4.9)
        @test testlink_2mon_sitecount_tension(site,(;),blankstates,blankstates,0.0,true) == 2.0
    end
    @testset "Link2MonSiteMotorCatch" begin
        site = MEDYAN.Link2MonSiteMotorCatch(f0=17.5, onRate=0.2, offRate=0.35, β=2.0)
        @test testlink_2mon_sitecount_tension(site,(numHeads=20,),blankstates,blankstates,10.0,false) ≈ 0.0004744807543508806
        @test testlink_2mon_sitecount_tension(site,(numHeads=20,),blankstates,blankstates,10.0,true) ≈ 0.0004428128737924883
        @test testlink_2mon_sitecount_tension(site,(numHeads=20,),blankstates,blankstates,-10.0,true) ≈ 0.0004428128737924883
        @test testlink_2mon_sitecount_tension(site,(numHeads=20,),blankstates,blankstates,0.0,true) ≈ 0.0004744807543508806
    end
    @testset "Link2MonSiteMotorStall" begin
        minussite = MEDYAN.Link2MonSiteMotorStall(fs=10.0,k0=2.0,α=0.5,walking_direction=+1,isminusend=true)
        plussite = MEDYAN.Link2MonSiteMotorStall(fs=10.0,k0=2.0,α=0.5,walking_direction=+1,isminusend=false)
        #tension perpendicular to the motor walking directions doesn't decrease rate.
        @test testlink_2mon_sitecount_tension(minussite,(;),blankstates,blankstates,10.0,false) ≈ 2.0
        @test testlink_2mon_sitecount_tension(plussite,(;),blankstates,blankstates,10.0,false) ≈ 2.0
        @test testlink_2mon_sitecount_drag(minussite,(;),blankstates,blankstates,10.0,false,+1) ≈ 0.0
        @test testlink_2mon_sitecount_drag(plussite,(;),blankstates,blankstates,10.0,false,+1) ≈ 0.0
        #motor aren't faster with negative drag
        @test testlink_2mon_sitecount_drag(minussite,(;),blankstates,blankstates,10.0,false,-1) ≈ 2.0
        @test testlink_2mon_sitecount_drag(plussite,(;),blankstates,blankstates,10.0,false,-1) ≈ 2.0
        # MotorStall doesn't care if the link_2mon is_minimized
        @test testlink_2mon_sitecount_drag(plussite,(;),blankstates,blankstates,11.0,true,+1) ≈ 0.0
    end
end