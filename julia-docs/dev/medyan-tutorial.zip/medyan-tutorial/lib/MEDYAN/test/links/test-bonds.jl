using MEDYAN
using StaticArrays
using LinearAlgebra
using Test
using ForwardDiff: ForwardDiff
using Setfield: @set
using ArgCheck: @argcheck
using Random
using Rotations: AngleAxis, RotMatrix

#=
Functions to help test Bond implementations.
=#

"""
Test bond_energy_force against the result from ForwardDiff

ArgumentError gets thrown if anything fails.
"""
function test_bond_energy_force_forward_diff(bond::MEDYAN.Bond, inputs, params;
        gtol=1E-9,
        max_energy=Inf, # skip test if energy is higher then this
    )
    E0, fs = MEDYAN.bond_energy_force(bond, inputs, params)
    if !(E0 ≤ max_energy)
        return true
    end
    for i in eachindex(inputs)
        # force is negative grad of U with position
        g = ForwardDiff.gradient(inputs[i][1]) do x
            local E, fs = MEDYAN.bond_energy_force(bond, @set(inputs[i][1]=x), params)
            E
        end
        @argcheck maximum(abs,fs[i][1] + g) ≤ gtol
        # check torque if there are direction inputs
        if length(inputs[i]) > 1
            # torque is grad of U with position × position
            torque = zero(SVector{3, Float64})
            for j in eachindex(inputs[i])[begin+1:end]
                g = ForwardDiff.gradient(inputs[i][j]) do x
                    local E, fs = MEDYAN.bond_energy_force(bond, @set(inputs[i][j]=x), params)
                    return E
                end
                torque += g × inputs[i][j]
            end
            @argcheck maximum(abs,fs[i][2] - torque) ≤ gtol
        end
    end
    return true
end

"""
Test bond_energy_force is at a local minimum energy.

ArgumentError gets thrown if not at a local min.
"""
function test_bond_energy_force_at_min(bond::MEDYAN.Bond, inputs, params;
        gtol=1E-5, ftol=1E-10, rstd=1E-3, θstd=1E-3, seed=1234, trials=100000)
    #check forces are small
    E0, fs = MEDYAN.bond_energy_force(bond, inputs, params)
    for i in eachindex(inputs)
        @argcheck maximum(abs, fs[i][1]) < gtol
        if length(inputs[i]) > 1
            @argcheck maximum(abs, fs[i][2]) < gtol
        end
    end
    #check no nearby positions have lower energy
    rng= Random.Xoshiro(seed)
    for t in 1:trials
        local new_inputs = inputs
        for i in eachindex(inputs)
            new_inputs = @set(new_inputs[i][1]+=rstd*randn(rng,SVector{3,Float64}))
            rand_rot = AngleAxis(θstd*randn(), normalize(randn(rng,SVector{3,Float64}))...)
            for j in 2:length(inputs[i])
                new_inputs = @set(
                    new_inputs[i][j] = rand_rot*new_inputs[i][j]
                )
            end
        end
        Etest, fstest = MEDYAN.bond_energy_force(bond, new_inputs, params)
        @argcheck Etest-E0 > -ftol
    end
    return true
end

@testset "bonds" begin
    @testset "zero bond" begin
        p = MEDYAN.ZeroBond{1}()
        test_bond_energy_force_forward_diff(p, ((SA[5.9,1.2,2.0],),), (;))
        test_bond_energy_force_forward_diff(p, ((SA[5.9,1.2,2.0],),), (;))
        test_bond_energy_force_at_min(p, ((SA[0,0,0.0],),), (;))
        test_bond_energy_force_at_min(p, ((SA[0,0,1.0],),), (;))
        p = MEDYAN.ZeroBond{2}()
        test_bond_energy_force_forward_diff(
            p,
            ((SA[8.9,1.2,2.0],),(SA[5.9,1.2,2.0],),),
            (k=9.2, L0=6.4),
        )
        test_bond_energy_force_at_min(
            p,
            ((SA[0.0,0.0,6.4],),(SA[0.0,0.0,0.0],),),
            (k=9.2, L0=6.4),
        )
    end
    @testset "position restraint" begin
        p = MEDYAN.PositionRestraint()
        test_bond_energy_force_forward_diff(p, ((SA[5.9,1.2,2.0],),), (k=0.3, r0=SA[0.0,0.0,0.0]))
        test_bond_energy_force_forward_diff(p, ((SA[5.9,1.2,2.0],),), (k=0.3, r0=SA[0.0,30.0,0.0]))
        test_bond_energy_force_at_min(p, ((SA[0,0,0.0],),), (k=0.3, r0=SA[0.0,0.0,0.0]))
        test_bond_energy_force_at_min(p, ((SA[0,0,1.0],),), (k=0.3, r0=SA[0.0,0.0,1.0]))
    end
    @testset "constant force" begin
        p = MEDYAN.ConstantForce()
        test_bond_energy_force_forward_diff(
            p,
            ((SA[5.9,1.2,2.0],),),
            (f=SA[0.0,0.0,0.0],),
        )
        test_bond_energy_force_forward_diff(
            p,
            ((SA[5.9,1.2,2.0],),),
            (f=SA[1.0,2.0,3.0],),
        )
    end
    @testset "distance restraint" begin
        p = MEDYAN.DistanceRestraint()
        test_bond_energy_force_forward_diff(
            p,
            ((SA[8.9,1.2,2.0],),(SA[5.9,1.2,2.0],),),
            (k=9.2, L0=6.4),
        )
        test_bond_energy_force_at_min(
            p,
            ((SA[0.0,0.0,6.4],),(SA[0.0,0.0,0.0],),),
            (k=9.2, L0=6.4),
        )
    end
    @testset "max distance restraint" begin
        p = MEDYAN.MaxDistanceRestraint()
        test_bond_energy_force_forward_diff(
            p,
            ((SA[8.9,1.2,2.0],),(SA[50.9,10.2,2.0],normalize(SA[5.9,1.2,2.0])),),
            (k=9.2, maxdist=6.4, translated=-2.4),
        )
        test_bond_energy_force_forward_diff(
            p,
            ((SA[0.0,1.2,2.0],),(SA[0.0,0.0,0.0],SA[0.0,0.0,1.0]),),
            (k=9.2, maxdist=6.4, translated=-2.4),
        )
        test_bond_energy_force_at_min(
            p,
            ((SA[0.0,0.0,0.0],),(SA[0.0,0.0,0.0],SA[0.0,0.0,1.0]),),
            (k=9.2, maxdist=6.4, translated=-2.4),
        )
    end
    @testset "branch bending cosine" begin
        p = MEDYAN.BranchBendingCosine()
        for i in 1:1000
            mr = rand(SVector{3, Float64})
            pr = rand(SVector{3, Float64})
            mv = normalize(randn(SVector{3, Float64}))
            pv = normalize(randn(SVector{3, Float64}))
            test_bond_energy_force_forward_diff(
                p,
                ((mr, mv,),(pr,pv,),),
                (kr=9.2, kbend=10.3, cos0=cos(1.22), sin0=sin(1.22)),
            )
            test_bond_energy_force_forward_diff(
                p,
                ((mr, mv,),(pr,pv,),),
                (kr=9.2, kbend=10.3, cos0=cos(3.0), sin0=sin(3.0)),
            )
        end
        test_bond_energy_force_at_min(
            p,
            (
                (SA[0.0,0.0,0.0],SA[1.0,0.0,0.0],),
                (SA[0.0,0.0,0.0],SA[cos(1.22),sin(1.22),0.0],),
            ),
            (kr=9.2, kbend=10.3, cos0=cos(1.22), sin0=sin(1.22)),
        )
    end
    @testset "position direction restraint" begin
        p = MEDYAN.PositionDirectionRestraint()
        for i in 1:1000
            r = rand(SVector{3, Float64})
            r0 = rand(SVector{3, Float64})
            v = normalize(randn(SVector{3, Float64}))
            v0 = normalize(randn(SVector{3, Float64}))
            test_bond_energy_force_forward_diff(
                p,
                ((r, v,),),
                (kr=9.2, kbend=10.3, r0=r0, v̂0=v0),
            )
        end
        test_bond_energy_force_at_min(
            p,
            (
                (SA[0.0,0.0,0.5],SA[1.0,0.0,0.0],),
            ),
            (kr=9.2, kbend=10.3, r0=SA[0.0,0.0,0.5], v̂0=SA[1.0,0.0,0.0]),
        )
    end
    @testset "position 2 direction restraint" begin
        p = MEDYAN.Position2DirectionRestraint()
        for i in 1:1000
            r = rand(SVector{3, Float64})
            r0 = rand(SVector{3, Float64})
            t = normalize(randn(SVector{3, Float64}))
            t0 = normalize(randn(SVector{3, Float64}))
            m1 = MEDYAN.ortho_normalize(randn(SVector{3, Float64}), t)
            m10 = MEDYAN.ortho_normalize(randn(SVector{3, Float64}), t0)
            test_bond_energy_force_forward_diff(
                p,
                ((r, t, m1),),
                (kr=9.2, ktbend=10.3, km1bend=11.4, r0=r0, t0=t0, m10=m10),
            )
        end
        test_bond_energy_force_at_min(
            p,
            (
                (SA[0.0,0.0,0.5],SA[1.0,0.0,0.0],SA[0.0,1.0,0.0]),
            ),
            (kr=9.2, ktbend=10.3, km1bend=11.4, r0=SA[0.0,0.0,0.5], t0=SA[1.0,0.0,0.0], m10=SA[0.0,1.0,0.0]),
        )
    end
    @testset "branch twisting" begin
        p = MEDYAN.BranchTwisting()
        for i in 1:1000
            pr = rand(SVector{3, Float64})
            cr = rand(SVector{3, Float64})
            A1 = rand(RotMatrix{3})
            A2 = rand(RotMatrix{3})
            A3 = rand(RotMatrix{3})
            test_bond_energy_force_forward_diff(
                p,
                ((pr, A1[:,1], A1[:,2],),(cr, A2[:,1], A2[:,2]),),
                (kr=9.2, kbend=10.3, eq_p_c=A3);
                gtol=1E-5,
                max_energy=1E5, # If energy is too high because angle is near 180, skip the test
            )
        end
        A3 = SMatrix(rand(RotMatrix{3}))
        test_bond_energy_force_at_min(
            p,
            (
                (SA[0.0,0.0,0.0], SA[1.0,0.0,0.0], SA[0.0,1.0,0.0]),
                (SA[0.0,0.0,0.0], A3[:,1], A3[:,2]),
            ),
            (kr=9.2, kbend=10.3, eq_p_c=A3),
        )
    end
end