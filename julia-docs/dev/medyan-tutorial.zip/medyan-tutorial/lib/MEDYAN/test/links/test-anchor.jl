using MEDYAN
using StaticArrays
using Dictionaries
using Test
using Random

@testset "anchors" begin
    grid = CubicGrid((4,4,4),500.0)
    c = MEDYAN.example_actin_mech_context(grid)
    plus_fila_tip_tag = MEDYAN.make_fila!(c;
        type= :actin,
        mono_states= ones(UInt8,20),
        node_mids= [0,],
        node_positions= [SA[-27.0, 0.0, 0.0], SA[27.0, 0.0, 0.0]],
    )
    # Can't make null anchor
    @test_throws ArgumentError make_anchor!(c, Anchor())
    anchor_tag = make_anchor!(c, Anchor(SA[0.0,0.0,0.0]))
    # Can't make repeat anchor
    @test_throws ArgumentError make_anchor!(c, Anchor(SA[0.0,0.0,0.0]))
    # Can make anchor with different state
    anchor_tag2 = make_anchor!(c, Anchor(SA[0.0,0.0,0.0], SA[SA[1.0,0.0,0.0], SA[0.0,1.0,0.0]], 3))
    @test isempty(get_all_links(c; type= :fila_tip_anchor_distance))
    link1 = MEDYAN.make_link!(c;
        type= :fila_tip_anchor_distance,
        places= (plus_fila_tip_tag, anchor_tag),
        bond_states= ((;L0=27.0),)
    )
    MEDYAN.assert_invariants(c)
    MEDYAN.minimize_energy!(c)
    MEDYAN.assert_invariants(c)
    @test tag2place(c, anchor_tag) == Anchor(SA[0.0,0.0,0.0])
    update_anchor!(c, anchor_tag, Anchor(SA[0.1, 0.0, 0.0]))
    MEDYAN.assert_invariants(c)
    @test tag2place(c, anchor_tag) == Anchor(SA[0.1, 0.0, 0.0])
    MEDYAN.remove_anchor!(c, anchor_tag)
    @test !tag_exists(c, anchor_tag)
    MEDYAN.assert_invariants(c)
    anchor_tag3 = make_anchor!(c, Anchor(SA[0.0,0.0,1.0]))
    @test anchor_tag != anchor_tag3
end
