using MEDYAN
using StaticArrays
using Random
using LinearAlgebra
using Test

"""
Return the rate of a link reaction under tension of f in pN
"""
function testlink_rate_tension(rate, link_state, f, is_minimized, place_idx)
    c = MEDYAN.example_actin_mech_context(CubicGrid(SA[1,1,1], 500.0))
    n_monomers = 10
    L = n_monomers*MEDYAN.ACTIN_FIL_PARAMS.spacing
    ftag1 = MEDYAN.make_fila!(c;
        mono_states = fill(0x01, 10),
        node_mids = [0,],
        node_positions = [SA[-L/2, -10.0, 0], SA[L/2, -10.0, 0]],
    )
    fil_idx1 = FilaIdx(c, ftag1)
    ftag2 = MEDYAN.make_fila!(c;
        mono_states = fill(0x01, 10),
        node_mids = [0,],
        node_positions = [SA[-L/2, +10.0, 0], SA[L/2, +10.0, 0]],
    )
    fil_idx2 = FilaIdx(c, ftag2)
    link_tag = MEDYAN.make_link!(c;
        type=:fila_mono_2forces,
        places=(MEDYAN.FilaMonoIdx(fil_idx1, 5), MEDYAN.FilaMonoIdx(fil_idx2, 5)),
        bond_states=((;f=SA[0.0, f, 0.0]), (;f=SA[0.0, -f, 0.0])),
        is_minimized,
    )
    link_data = c.link_manager.link_data[link_tag.typeid]
    rate(c;
        link_tag,
        link_data,
        place_idx,
        link_state,
    )
end

"""
Return the rate of a link reaction under a force pulling both filaments axially, f in pN 
if `direction` is +1, the force is pulling the filaments towards their minus end,
    +------- ->--<- -------+
if `direction` is -1, the force is pulling the filaments towards their plus end,
    -------+ ->--<- +-------
"""
function testlink_rate_drag(rate, link_state, f, is_minimized, place_idx, direction)
    c = MEDYAN.example_actin_mech_context(CubicGrid(SA[1,1,1], 500.0))
    n_monomers = 10
    L = n_monomers*MEDYAN.ACTIN_FIL_PARAMS.spacing
    ftag1 = MEDYAN.make_fila!(c;
        mono_states = fill(0x01, 10),
        node_mids = [0,],
        node_positions = [SA[direction*L/2 - L - 10, 0, 0], SA[-direction*L/2 - L - 10, 0, 0]],
    )
    fil_idx1 = FilaIdx(c, ftag1)
    ftag2 = MEDYAN.make_fila!(c;
        mono_states = fill(0x01, 10),
        node_mids = [0,],
        node_positions = [SA[-direction*L/2 + L + 10, 0, 0], SA[direction*L/2 + L + 10, 0, 0]],
    )
    fil_idx2 = FilaIdx(c, ftag2)
    link_tag = MEDYAN.make_link!(c;
        type=:fila_mono_2forces,
        places=(MEDYAN.FilaMonoIdx(fil_idx1, 5), MEDYAN.FilaMonoIdx(fil_idx2, 5)),
        bond_states=((;f=SA[f, 0.0, 0.0]), (;f=SA[-f, 0.0, 0.0])),
        is_minimized,
    )
    link_data = c.link_manager.link_data[link_tag.typeid]
    rate(c;
        link_tag,
        link_data,
        place_idx,
        link_state,
    )
end

@testset "get_link_mechanics" begin
    nan3 = SA[NaN, NaN, NaN]
    f1 = SA[11.0, 12.0, 13.0]
    f2 = SA[14.0, 15.0, 16.0]
    kr = 10.0
    kbend = 2.0
    r0 = SA[1.0, 2.0, 3.0]
    v̂0 = SA[0.0, 1.0, 0.0]
    c = MEDYAN.example_actin_mech_context(CubicGrid(SA[1,1,1], 500.0))
    n_monomers = 10
    L = n_monomers*MEDYAN.ACTIN_FIL_PARAMS.spacing
    ftag1 = MEDYAN.make_fila!(c;
        mono_states = fill(0x01, 10),
        node_mids = [0,],
        node_positions = [SA[-L/2, -10.0, 0], SA[L/2, -10.0, 0]],
    )
    fil_idx1 = FilaIdx(c, ftag1)
    ftag2 = MEDYAN.make_fila!(c;
        mono_states = fill(0x01, 10),
        node_mids = [0,],
        node_positions = [SA[-L/2, +10.0, 0], SA[L/2, +10.0, 0]],
    )
    fil_idx2 = FilaIdx(c, ftag2)
    link_tag1 = MEDYAN.make_link!(c;
        type=:fila_mono_2forces,
        places=(MEDYAN.FilaMonoIdx(fil_idx1, 5), MEDYAN.FilaMonoIdx(fil_idx2, 5)),
        bond_states=((;f=f1), (;f=f2)),
    )
    link_tag2 = MEDYAN.make_link!(c;
        type=:fila_mono_restraint,
        places=(MEDYAN.FilaMonoIdx(fil_idx1, 5),),
        bond_states=((;r0, v̂0, kr, kbend),),
    )
    (;energy, inputs, forces, torques) = MEDYAN.get_link_mechanics(c, link_tag1)
    p1 = MEDYAN.get_position(c, MEDYAN.FilaMonoIdx(fil_idx1, 5))
    p2 = MEDYAN.get_position(c, MEDYAN.FilaMonoIdx(fil_idx2, 5))
    dir1 = MEDYAN.get_directions(c, MEDYAN.FilaMonoIdx(fil_idx1, 5))[1]
    @test energy ≈ -(p1⋅f1) + -(p2⋅f2)
    @test isequal(inputs, (SA[p1,SA[1.0,0,0],nan3], SA[p2,SA[1.0,0,0],nan3]))
    @test forces == SA[f1, f2]
    @test iszero(torques)

    (;energy, inputs, forces, torques) = MEDYAN.get_link_mechanics(c, link_tag2)
    @test energy ≈ 1//2*kr*sum(abs2, r0-p1) + kbend*(1-v̂0⋅dir1)
    @test isequal(inputs, (SA[p1,SA[1.0,0,0],nan3],))
    @test forces ≈ SA[-kr*(p1-r0),]
    @test torques ≈ SA[-kbend*(v̂0 × SA[1.0,0,0])]
end

@testset "link reaction rates" begin
    @testset "LinkRateSlipBond" begin
        rate = MEDYAN.LinkRateSlipBond(f0=4.9, k0=2.0, kmax=1E6)
        @test testlink_rate_tension(rate,(;),10.0,false, 1) == 2.0
        @test testlink_rate_tension(rate,(;),10.0,true, 1) ≈ 2exp(10.0/4.9)
        @test testlink_rate_tension(rate,(;),100.0,true, 1) ≈ 1E6
        @test testlink_rate_tension(rate,(;),-10.0,true, 1) ≈ 2exp(10.0/4.9)
        @test testlink_rate_tension(rate,(;),0.0,true, 1) == 2.0
    end
    @testset "LinkRateMotorCatch" begin
        rate = MEDYAN.LinkRateMotorCatch(f0=17.5, onRate=0.2, offRate=0.35, β=2.0)
        @test testlink_rate_tension(rate, (;numHeads=20,), 10.0, false, 1) ≈ 0.0004744807543508806
        @test testlink_rate_tension(rate, (;numHeads=20,), 10.0, true, 1) ≈ 0.0004428128737924883
        @test testlink_rate_tension(rate, (;numHeads=20,), -10.0, true, 1) ≈ 0.0004428128737924883
        @test testlink_rate_tension(rate, (;numHeads=20,), 0.0, true, 1) ≈ 0.0004744807543508806
    end
    @testset "LinkRateMotorStall" begin
        rate = MEDYAN.LinkRateMotorStall(fs=10.0,k0=2.0,α=0.5,walking_direction=+1)
        for place_idx in 1:2 # each place_idx corresponds to a different end of the myosin
            # tension perpendicular to the motor walking directions doesn't decrease rate.
            @test testlink_rate_tension(rate, (;), 10.0, false, place_idx) ≈ 2.0
            # fs drag force should stall motor
            @test testlink_rate_drag(rate, (;), 10.0, false, place_idx, +1) ≈ 0.0
            # motors aren't faster with negative drag
            @test testlink_rate_drag(rate, (;), 10.0, false, place_idx, -1) ≈ 2.0
            # MotorStall doesn't care if the link is_minimized
            @test testlink_rate_drag(rate, (;), 11.0, true, place_idx, -1) ≈ 2.0
        end
    end
end
