# using Myosin model from https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6768639/

using MEDYAN
using MEDYANVis
using Test
using StaticArrays
using LinearAlgebra
using Setfield
using Random

"""
    rand_discrete_sample(αs, α_tot)::Union{Int, Nothing}

Return a random index i with probability `αs[i]/α_tot`. If no `i` is selected return `nothing`.
`α_tot` must be greater than or equal to the sum of `αs`.
"""
function rand_discrete_sample(αs, α_tot)::Union{Int, Nothing}
    u = α_tot*rand()
    for (i, α) in enumerate(αs)
        u -= α
        if u ≤ 0
            return i
        end
    end
    return nothing
end

# First create a agent names with actin and myosin filaments
# Also include a myosin end link2mon and a myosin end to actin link
const agent_names = MEDYAN.AgentNames(;
    filamentnames=[
        (:actin, [:middle, :weak_bound, :strong_bound]),
        (:myo, [:myo,]),
    ],
    link_2mon_names=[
        :myo_fil_end,
        :myo_motor,
        :restraint,
        :constforce,
    ]
)

# Define myo_motor mechanical parameters
Base.@kwdef struct MaxDistanceRestraintMechParams
    "spring constant pN/nm"
    k::Float64

    "maximum distance nm"
    maxdist::Float64
end


function MEDYAN.link_2mon_force(mechstate,mechparams::MaxDistanceRestraintMechParams,mr_sim,pr_sim,mv̂_sim,pv̂_sim)
    # mechstate.translated is how far (in nm) the force on the plus end of the link
    # is translated towards the plus end of the filament
    t = mechstate.translated
    r = (pr_sim + t*pv̂_sim) - mr_sim
    L = MEDYAN.norm_fast(r)
    ΔL = Base.FastMath.max_fast(L-mechparams.maxdist, zero(L))
    E = 1//2*mechparams.k*ΔL^2
    pf_sim = -(mechparams.k*ΔL*r*inv(L))
    mf_sim = -pf_sim
    pfv̂_sim = -t*(mechparams.k*ΔL*r*inv(L))
    E, mf_sim, pf_sim, zero(mf_sim), pfv̂_sim
end

# Define a MonLink2Mon site for the myo_fil_end link2mon to bind to an actin monomer.
@kwdef struct MonLink2MonSiteNumUnbound
    ftid::Int
    cutoff::Float64 # nm
    weak_binding_rate::Float64 # 1/s if a pair exists in the cutoff distance.
end
MEDYAN.cutoff_distance(site::MonLink2MonSiteNumUnbound) = site.cutoff
MEDYAN.getftid(site::MonLink2MonSiteNumUnbound) = site.ftid
function MEDYAN.mon_link_2mon_sitecount(site::MonLink2MonSiteNumUnbound, link_2mon_state::MEDYAN.Link2MonState)::Float64
    link_2mon_state.chemstate.numUnbound*site.weak_binding_rate
end

"""
Parameters for a model of non muscle myosin 2.
"""
@kwdef struct MyosinParameters
    number_of_dimers_per_side::Int=8
    load_force::Float64
    on_rate::Float64
    off_rate::Float64
    step_distance::Float64
    off_bell_distance::Float64
    step_bell_distance::Float64
    myo_motor_mech_params::MaxDistanceRestraintMechParams=MaxDistanceRestraintMechParams(
        k= 0.05,# pN/nm
        maxdist= 50.0, # nm
    )
end


@kwdef struct Link2MonSiteMotorStep
    step_distance::Float64
    off_bell_distance::Float64
    step_bell_distance::Float64
    weak_off_rate::Float64
    off_rate::Float64
    on_rate::Float64
end
function MEDYAN.link_2mon_sitecount(
        site::Link2MonSiteMotorStep,
        link_2mon_state, mechparams,
        minusftid, plusftid,
        minusmonomerstates, plusmonomerstates,
        m_pos, a_pos, m_plusvec, a_plusvec,
    )::Float64
    local strongly_bound::Bool = link_2mon_state.chemstate.strongly_bound
    # Get the energies in the initial and final translations
    # This is needed to model force dependent reactions
    function get_energies()
        local E_final, mf_sim, pf_sim, = MEDYAN.link_2mon_force(
            (;translated=+site.step_distance/2),
            mechparams,
            m_pos, a_pos, m_plusvec, a_plusvec,
        )
        local E_initial, mf_sim, pf_sim, = MEDYAN.link_2mon_force(
            (;translated=-site.step_distance/2),
            mechparams,
            m_pos, a_pos, m_plusvec, a_plusvec,
        )
        E_final, E_initial
    end
    if strongly_bound
        # A⋅M⋅D
        # Assume Pi rebinding is impossible
        # Assume after ADP unbinds, ATP binding, actin unbinding, and ATP hydrolysis are instant and irreversible.
        local E_final, E_initial = get_energies()
        local ΔE = E_final-E_initial
        # Force dependent unbinding rate.
        site.off_rate*exp(-c.β*ΔE*site.off_bell_distance*inv(site.step_distance))
    else
        # A-M⋅D⋅Pi
        local E_final, E_initial = get_energies()
        local ΔE = E_final-E_initial
        site.weak_off_rate + site.on_rate*exp(-c.β*ΔE*site.step_bell_distance*inv(site.step_distance))
    end
end

function make_context(p::MyosinParameters)

    # Create a SysDef
    s = MEDYAN.SysDef(agent_names)

    #define restraints
    add_link_2mon!(s,
        :restraint,
        Link2MonState((;),(mr0 = zero(SVector{3,Float64}),mv̂0 = zero(SVector{3,Float64}))),
        MEDYAN.RestraintMechParams(kr=0.2,kv̂=0.0),
        no_collide=true,
    )
    add_link_2mon!(s,
        :constforce,
        Link2MonState((;),(f=zero(SVector{3,Float64}),)),
        MEDYAN.ConstantForceMechParams(),
    )

    # Add Actin filament parameters
    add_filament_params!(s, :actin, MEDYAN.ACTIN_FIL_PARAMS)

    # Add Myosin filament parameters
    myo_spacing = 20.0
    add_filament_params!(s, :myo, MEDYAN.FilamentMechParams(
        radius= 15.0,
        spacing= myo_spacing,
        klength= 10*100.0,
        kangle= 1,
        numpercylinder= 1000,
        max_num_unmin_end= 1,
    ))

    # Add myo_fil_end parameters
    # This has no mechanical force field but keeps track of the number of bound and unbound motors
    add_link_2mon!(s, 
        :myo_fil_end,
        MEDYAN.Link2MonState(
            (
                numBound = 0,
                numUnbound = 0,
            ),
            (;),
        ), 
        nothing,
    )

    add_link_2mon!(s, 
        :myo_motor,
        MEDYAN.Link2MonState(
            (;parentid=-1, strongly_bound=false),
            (;translated=NaN,),
        ), 
        p.myo_motor_mech_params,
    )

    # Add myo_fil_end mon link2mon site
    MEDYAN.add_mon_link_2mon_site!(s, 
        :myo_fil_end,
        :motor_binding,
        MonLink2MonSiteNumUnbound(
            ftid= 1,
            cutoff= p.myo_motor_mech_params.maxdist*3, # this should be significantly larger than the myo_fil_end maxdist
            weak_binding_rate=33.0, 
        ),
    )

    # Define a callback for the myo motor binding reaction
    myo_fil_end_id::Int = s.link_2mon.myo_fil_end
    myo_motor_id::Int = s.link_2mon.myo_motor
    motor_binding_id::Int = s.mon_link_2mon_site.myo_fil_end.motor_binding.id
    actin_middle_state::UInt8 = s.state.actin.middle
    actin_weak_bound_state::UInt8 = s.state.actin.weak_bound
    actin_strong_bound_state::UInt8 = s.state.actin.strong_bound
    function bind_motor(c::MEDYAN.Context, cid::Integer)
        local maybe_nearby_mon_site = MEDYAN.pickrandommon_link_2mon_site(
            c,
            cid,
            myo_fil_end_id,
            motor_binding_id,
        )
        if isnothing(maybe_nearby_mon_site)
            return false # pick was rejected
        end
        local link_id, myo_end, actin_name = maybe_nearby_mon_site
        local other_mon_state = mon_3states(c, actin_name)[2]
        if other_mon_state != actin_middle_state
            return false # the monomer is already bound
        end
        local link_state = link_2mon_state(c, myo_fil_end_id, link_id)
        local numUnbound::Int = link_state.chemstate.numUnbound
        local numBound::Int = link_state.chemstate.numBound

        local selected_translation = -p.step_distance/2
        local selected_bound_state = (parentid=link_id, strongly_bound=false)
        local selected_unbound_state = (numBound=numBound+1, numUnbound=numUnbound-1)

        local m_pos, m_plusvec = mon_position_plusvector(c, myo_end)
        local a_pos, a_plusvec = mon_position_plusvector(c, actin_name)
        # get the forces and energies if the motor were to bind.
        local E, mf_sim, pf_sim, = MEDYAN.link_2mon_force(
            (;translated=selected_translation),
            p.myo_motor_mech_params,
            m_pos, a_pos, m_plusvec, a_plusvec,
        )
        # TODO add catch-slip dynamics here. Or not.
        boltzmann_factor = exp(-c.β*E)
        if rand() < boltzmann_factor
            # update the myo_fil_end link2mon number of bound and unbound motors
            chem_setlink_2mon_state!(
                c,
                myo_fil_end_id,
                link_id,
                @set(link_state.chemstate = selected_unbound_state),
            )
            # update the state of the bound monomer, setting it to bound to the myo_fil_end link2mon
            chem_setmonomerstate!(c, actin_name, actin_weak_bound_state)
            # add a myo_motor link2mon between the monomer and the myo_fil_end link2mon myo filament monomer.
            # This will be used to apply a mechanical force to the myo filament monomer
            chem_newlink_2mon!(
                c,
                myo_motor_id,
                myo_end => actin_name;
                changedchemstate = selected_bound_state,
                changedmechstate = (;translated=selected_translation,),
            )
            return true
        else
            return false
        end
    end

    addreactioncallback!(
        s,
        "mon_link_2mon_site.myo_fil_end.motor_binding",
        1.0,
        0,
        bind_motor,
    )

    # Assume UNBOUND MOTOR ATP HYDROLYSIS REACTIONS are instant and irreversible

    # MOTOR STEPPING

    MEDYAN.add_link_2mon_site!(
        s,
        :myo_motor,
        :motor_step,
        Link2MonSiteMotorStep(;
            p.off_bell_distance,
            p.off_rate,
            p.on_rate,
            p.step_bell_distance,
            p.step_distance,
            weak_off_rate = 1000.0,
        ),
    )
    motor_step_id::Int = s.link_2mon_site.myo_motor.motor_step.id
    
    "net number of ATP used by myosin, just for tracking purposes"
    used_ATP::Base.RefValue{Int} = Ref(0)
    function step_motor(c::MEDYAN.Context, cid::Integer)
        local maybe_motor_site = MEDYAN.pickrandomlink_2mon_site(
            c,
            cid,
            myo_motor_id,
            motor_step_id,
        )
        if isnothing(maybe_motor_site)
            return false # pick was rejected
        end
        local link_id, myo_end, actin_name = maybe_motor_site
        local motor_state = link_2mon_state(c, myo_motor_id, link_id)
        local chemstate = motor_state.chemstate
        local mechstate = motor_state.mechstate
        local strongly_bound::Bool = chemstate.strongly_bound
        function get_energies()
            local m_pos, m_plusvec = mon_position_plusvector(c, myo_end)
            local a_pos, a_plusvec = mon_position_plusvector(c, actin_name)
            local E_final, mf_sim, pf_sim, = MEDYAN.link_2mon_force(
                (;translated=+p.step_distance/2),
                p.myo_motor_mech_params,
                m_pos, a_pos, m_plusvec, a_plusvec,
            )
            local E_initial, mf_sim, pf_sim, = MEDYAN.link_2mon_force(
                (;translated=-p.step_distance/2),
                p.myo_motor_mech_params,
                m_pos, a_pos, m_plusvec, a_plusvec,
            )
            E_final, E_initial
        end
        function do_unbind()::Bool
            local parent_link_id = motor_state.chemstate.parentid
            local parent_link_state = link_2mon_state(c, myo_fil_end_id, parent_link_id)
            local parent_chem_state = parent_link_state.chemstate
            local numUnbound::Int = parent_chem_state.numUnbound
            local numBound::Int = parent_chem_state.numBound
            local motor_unbound_state = (numBound=numBound-1, numUnbound=numUnbound+1,)
            chem_setlink_2mon_state!(
                c,
                myo_fil_end_id,
                parent_link_id,
                @set(parent_link_state.chemstate = motor_unbound_state),
            )
            # update the state of the bound monomer, setting it to unbound
            chem_setmonomerstate!(c, actin_name, actin_middle_state)
            # remove the myo_motor link2mon.
            chem_removelink_2mon!(
                c,
                myo_motor_id,
                link_id,
            )
            return true
        end
        if strongly_bound
            let
                # A⋅M⋅D
                # ADP unbinds, ATP binds, actin unbinds, and ATP hydrolyses
                used_ATP[] += 1
                return do_unbind()
            end
        else
            let
                # A-M⋅D⋅Pi
                local E_final, E_initial = get_energies()
                local ΔE = E_final-E_initial
                αs = SA[
                    1000.0,
                    p.on_rate*exp(-c.β*ΔE*p.step_bell_distance*inv(p.step_distance)),
                ]
                α_tot = sum(αs)
                selected = rand_discrete_sample(αs, α_tot)
                isnothing(selected) && return false # pick was rejected due to rounding errors
                if selected == 1
                    # weak unbinding
                    return do_unbind()
                elseif selected == 2
                    # power stroke
                    local new_chemstate = Base.setindex(chemstate, true, :strongly_bound)
                    local new_mechstate = Base.setindex(mechstate, +p.step_distance/2, :translated)
                    chem_setlink_2mon_state!(
                        c,
                        myo_motor_id,
                        link_id,
                        MEDYAN.Link2MonState(new_chemstate, new_mechstate),
                    )
                    chem_setmonomerstate!(c, actin_name, actin_strong_bound_state)
                    return true
                else
                    error("Invalid selected")
                end
            end
        end
        error("unreachable")
    end
    
    addreactioncallback!(
        s,
        "link_2mon_site.myo_motor.motor_step",
        1.0,
        0,
        step_motor,
    )

    grid = CubicGrid((8,8,2),500.0)

    used_ATP[] = 0
    c = MEDYAN.Context(s, grid; cylinder_skin_radius=7.0)
    # Add an actin filament
    num_filaments = 6
    for i in 1:num_filaments
        num_monomers = 800
        actin_len = num_monomers * MEDYAN.ACTIN_FIL_PARAMS.spacing
        fid1 = chem_newfilament!(c,
            ftid=s.filament.actin,
            monomerstates=fill(s.state.actin.middle, num_monomers),
            node_mids=[0,],
            nodepositions= iszero(i%2) ? [
                SA[-actin_len/2, (i-(num_filaments+1)/2)*10.0, 0.0],
                SA[+actin_len/2, (i-(num_filaments+1)/2)*10.0, 0.0],
            ] : [
                SA[(i-(num_filaments+1)/2)*10.0, -actin_len/2, 0.0],
                SA[(i-(num_filaments+1)/2)*10.0, +actin_len/2, 0.0],
            ]
        )
        # # restrain filament ends
        # MEDYAN.chem_newlink_2mon!(c,
        #     s.link_2mon.restraint,#ltid 
        #     MonomerName(s.filament.actin, fid1, 0)=>
        #     MonomerName(s.filament.actin, fid1, 0);
        #     changedmechstate = (mr0 = mon_position(c, MonomerName(s.filament.actin, fid1, 0)), mv̂0 = SA[1.0,0,0]),
        # )
        # MEDYAN.chem_newlink_2mon!(c,
        #     s.link_2mon.restraint,#ltid 
        #     MonomerName(s.filament.actin, fid1, num_monomers-1)=>
        #     MonomerName(s.filament.actin, fid1, num_monomers-1);
        #     changedmechstate = (mr0 = mon_position(c, MonomerName(s.filament.actin, fid1, num_monomers-1)), mv̂0 = SA[1.0,0,0]),
        # )
    end

    num_myo_fil = 10
    for i in 1:num_myo_fil
        # Number of fake myo monomers per myo filament.
        # spacing is 20 nm, this controls the length of the rigid part of the 
        # myo filament, and is independent of the number of heads.
        num_fake_myo_monomers = 3+5+3
        myo_len = num_fake_myo_monomers * myo_spacing
        myo_fid = chem_newfilament!(c,
            ftid=s.filament.myo,
            monomerstates=fill(0x01, num_fake_myo_monomers),
            node_mids=[0,],
            nodepositions= [
                SA[-myo_len/2-200, -20.0, 20*(i-1)+0.0],
                SA[myo_len/2-200, -20.0, 20*(i-1)+0.0],
            ]
        )
        myo_plus_end = MonomerName(s.filament.myo, myo_fid, num_fake_myo_monomers-1)
        myo_mid_point = MonomerName(s.filament.myo, myo_fid, (num_fake_myo_monomers-1)÷2)
        myo_minus_end = MonomerName(s.filament.myo, myo_fid, 0)
        chem_newlink_2mon!(
            c,
            myo_fil_end_id,
            myo_plus_end => myo_plus_end;
            changedchemstate = (;numUnbound=p.number_of_dimers_per_side,),
        )
        chem_newlink_2mon!(
            c,
            myo_fil_end_id,
            myo_minus_end => myo_minus_end;
            changedchemstate = (;numUnbound=p.number_of_dimers_per_side,),
        )
        # load force
        MEDYAN.chem_newlink_2mon!(c,
            s.link_2mon.constforce,#ltid 
            myo_mid_point=>myo_mid_point;
            changedmechstate = (f=-p.load_force*SA[1.0,0,0],),
        )
    end
    (;c, used_ATP)
end

#=
(;c, used_ATP) = make_context(MyosinParameters(;
       number_of_dimers_per_side=8,
       load_force=0.0,
       on_rate=0.5,
       off_rate=5.0,
       step_distance=6.0,
       off_bell_distance=1.6,
       step_bell_distance=1.6,
))
vis = Visualizer()
for i in 1:10
    # sleep(0.1)
    draw_context!(vis, c, c.sys_def)
    for i in 1:1000
        MEDYAN.minimize_energy!(c; brownian_motion_time=1E-5)
        MEDYAN.run_chemistry!(c, 1E-5)
    end
end
=#