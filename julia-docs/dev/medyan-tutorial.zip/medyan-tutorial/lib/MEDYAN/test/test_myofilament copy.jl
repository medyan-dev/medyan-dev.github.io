# using Myosin model from https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6768639/

using MEDYAN
using MEDYANVis
using Test
using StaticArrays
using LinearAlgebra
using Setfield
using Random

"""
    rand_discrete_sample(αs, α_tot)::Union{Int, Nothing}

Return a random index i with probability `αs[i]/α_tot`. If no `i` is selected return `nothing`.
`α_tot` must be greater than or equal to the sum of `αs`.
"""
function rand_discrete_sample(αs, α_tot)::Union{Int, Nothing}
    u = α_tot*rand()
    for (i, α) in enumerate(αs)
        u -= α
        if u ≤ 0
            return i
        end
    end
    return nothing
end

# First create a agent names with actin and myosin filaments
# Also include a myosin end link2mon and a myosin end to actin link
const agent_names = MEDYAN.AgentNames(;
    filamentnames=[
        (:actin, [:middle, :bound]),
        (:myo, [:myo,]),
    ],
    link_2mon_names=[
        :myo_fil_end,
        :myo_motor,
        :restraint,
        :constforce,
    ]
)

# Define myo_motor mechanical parameters
Base.@kwdef struct MaxDistanceRestraintMechParams
    "spring constant pN/nm"
    k::Float64

    "maximum distance nm"
    maxdist::Float64
end


function MEDYAN.link_2mon_force(mechstate,mechparams::MaxDistanceRestraintMechParams,mr_sim,pr_sim,mv̂_sim,pv̂_sim)
    # mechstate.translated is how far (in nm) the force on the plus end of the link
    # is translated towards the plus end of the filament
    t = mechstate.translated
    r = (pr_sim + t*pv̂_sim) - mr_sim
    L = MEDYAN.norm_fast(r)
    ΔL = Base.FastMath.max_fast(L-mechparams.maxdist, zero(L))
    E = 1//2*mechparams.k*ΔL^2
    pf_sim = -mechparams.k*ΔL*r/L
    mf_sim = -pf_sim
    pfv̂_sim = -t*mechparams.k*ΔL*r/L
    E, mf_sim, pf_sim, zero(mf_sim), pfv̂_sim
end

# Define a MonLink2Mon site for the myo_fil_end link2mon to bind to an actin monomer.
@kwdef struct MonLink2MonSiteNumUnbound
    ftid::Int
    cutoff::Float64 # nm
    weak_binding_rate::Float64 # 1/s if a pair exists in the cutoff distance.
end
MEDYAN.cutoff_distance(site::MonLink2MonSiteNumUnbound) = site.cutoff
MEDYAN.getftid(site::MonLink2MonSiteNumUnbound) = site.ftid
function MEDYAN.mon_link_2mon_sitecount(site::MonLink2MonSiteNumUnbound, link_2mon_state::MEDYAN.Link2MonState)::Float64
    link_2mon_state.chemstate.numUnbound*site.weak_binding_rate
end

"""
Parameters for a model of non muscle myosin 2.
"""
@kwdef struct MyosinParameters
    number_of_dimers_per_side::Int=16
    on_rate::Float64
    off_rate::Float64
    step_distance::Float64
    off_bell_distance::Float64
    step_bell_distance::Float64
    myo_motor_mech_params::MaxDistanceRestraintMechParams=MaxDistanceRestraintMechParams(
        k= 0.2,# pN/nm
        maxdist= 50.0, # nm
    )
end

function make_context(p::MyosinParameters)

    # Create a SysDef
    s = MEDYAN.SysDef(agent_names)

    #define restraints
    add_link_2mon!(s,
        :restraint,
        Link2MonState((;),(mr0 = zero(SVector{3,Float64}),mv̂0 = zero(SVector{3,Float64}))),
        MEDYAN.RestraintMechParams(kr=0.2,kv̂=0.0),
        no_collide=true,
    )
    add_link_2mon!(s,
        :constforce,
        Link2MonState((;),(f=zeros(3),)),
        MEDYAN.ConstantForceMechParams(),
    )

    # Add Actin filament parameters
    add_filament_params!(s, :actin, MEDYAN.ACTIN_FIL_PARAMS)

    # Add Myosin filament parameters
    const myo_spacing = 20.0
    add_filament_params!(s, :myo, MEDYAN.FilamentMechParams(
        radius= 15.0,
        spacing= myo_spacing,
        klength= 10*100.0,
        kangle= 1,
        numpercylinder= 1000,
        max_num_unmin_end= 1,
    ))

    # Add myo_fil_end parameters
    # This has no mechanical force field but keeps track of the number of bound and unbound motors
    add_link_2mon!(s, 
        :myo_fil_end,
        MEDYAN.Link2MonState(
            (
                numBound = 0,
                numUnbound = 0,
            ),
            (;),
        ), 
        nothing,
    )

    add_link_2mon!(s, 
        :myo_motor,
        MEDYAN.Link2MonState(
            (;parentid=-1, strongly_bound=false),
            (;translated=NaN,),
        ), 
        myo_motor_mech_params,
    )


    
    # Add myo_fil_end mon link2mon site
    MEDYAN.add_mon_link_2mon_site!(s, 
        :myo_fil_end,
        :motor_binding,
        MonLink2MonSiteNumUnbound(
            ftid= 1,
            cutoff= p.myo_motor_mech_params.maxdist*2, # this should be significantly larger than the myo_fil_end maxdist
            weak_binding_rate=p.on_rate*10, # because this is not the rate limiting step.
        ),
    )

    # Define a callback for the myo motor binding reaction
    myo_fil_end_id::Int = s.link_2mon.myo_fil_end
    myo_motor_id::Int = s.link_2mon.myo_motor
    motor_binding_id::Int = s.mon_link_2mon_site.myo_fil_end.motor_binding.id
    motor_binding_site::MonLink2MonSiteNumUnbound = s.mon_link_2mon_site.myo_fil_end.motor_binding.site
    actin_middle_state::UInt8 = s.state.actin.middle
    actin_bound_state::UInt8 = s.state.actin.bound
    function bind_motor(c::MEDYAN.Context, cid::Integer)
        site = motor_binding_site
        maybe_nearby_mon_site = MEDYAN.pickrandommon_link_2mon_site(
            c,
            cid,
            myo_fil_end_id,
            motor_binding_id,
        )
        if isnothing(maybe_nearby_mon_site)
            return false # pick was rejected
        end
        link_id, myo_end, actin_name = maybe_nearby_mon_site
        other_mon_state = mon_3states(c, actin_name)[2]
        if other_mon_state != actin_middle_state
            return false # the monomer is already bound
        end
        link_state = link_2mon_state(c, myo_fil_end_id, link_id)
        numUnbound::Int = link_state.chemstate.numUnbound
        numBound::Int = link_state.chemstate.numBound

        # motor translation table
        motor_translations = SA[
            myo_motor_initial_translation,
            myo_motor_initial_translation,
            myo_motor_final_translation,
            myo_motor_final_translation,
        ]
            # Stages:
            # 1: A-M⋅D⋅Pi
            # 6: A-M⋅T
            # 7: M⋅T
            # 8: M⋅D⋅Pi

        # bound motor states table
        motor_bound_states = SA[
            (parentid=link_id, stage=1, otherstage=8),
            (parentid=link_id, stage=1, otherstage=7),
            (parentid=link_id, stage=6, otherstage=7),
            (parentid=link_id, stage=6, otherstage=8),
        ]

        # unbound motor states table
        motor_unbound_states = SA[
            (numBound=numBound+1, numUnbound_T_T=T_T, numUnbound_T_DPi = T_DPi, numUnbound_DPi_DPi = DPi_DPi-1),
            (numBound=numBound+1, numUnbound_T_T=T_T, numUnbound_T_DPi = T_DPi-1, numUnbound_DPi_DPi = DPi_DPi),
            (numBound=numBound+1, numUnbound_T_T=T_T-1, numUnbound_T_DPi = T_DPi, numUnbound_DPi_DPi = DPi_DPi),
            (numBound=numBound+1, numUnbound_T_T=T_T, numUnbound_T_DPi = T_DPi-1, numUnbound_DPi_DPi = DPi_DPi),
        ]

        selected = rand_discrete_sample(αs, α_tot)
        isnothing(selected) && return false # pick was rejected due to rounding errors
        selected_translation = motor_translations[selected]
        selected_bound_state = (parentid=link_id, strongly_bound=false)
        selected_unbound_state = (numBound=numBound+1, numUnbound=numUnbound-1)

        m_pos, m_plusvec = mon_position_plusvector(c, myo_end)
        a_pos, a_plusvec = mon_position_plusvector(c, actin_name)
        # get the forces and energies if the motor were to bind.
        E, mf_sim, pf_sim, = MEDYAN.link_2mon_force(
            (;translated=selected_translation),
            myo_motor_mech_params,
            m_pos, a_pos, m_plusvec, a_plusvec,
        )
        # TODO add catch-slip dynamics here. Or not.
        boltzmann_factor = exp(-c.β*E)
        if rand() < boltzmann_factor
            # update the myo_fil_end link2mon number of bound and unbound motors
            chem_setlink_2mon_state!(
                c,
                myo_fil_end_id,
                link_id,
                @set(link_state.chemstate = selected_unbound_state),
            )
            # update the state of the bound monomer, setting it to bound to the myo_fil_end link2mon
            chem_setmonomerstate!(c, actin_name, actin_bound_state)
            # add a myo_motor link2mon between the monomer and the myo_fil_end link2mon myo filament monomer.
            # This will be used to apply a mechanical force to the myo filament monomer
            chem_newlink_2mon!(
                c,
                myo_motor_id,
                myo_end => actin_name;
                changedchemstate = selected_bound_state,
                changedmechstate = (;translated=selected_translation,),
            )
            return true
        else
            return false
        end
    end

    addreactioncallback!(
        s,
        "mon_link_2mon_site.myo_fil_end.motor_binding",
        1.0,
        0,
        bind_motor,
    )