using MEDYAN
using StaticArrays
using Test

@testset "chem cache api" begin
    startc, s, fida1, fida2, fidb1, fidb2 = MEDYAN.example_all_sites_context()
    refresh_chem_cache!(startc)
    @test is_chem_cache_valid(startc)
    defer_chem_caching!(startc)
    @test !is_chem_cache_valid(startc)
    refresh_chem_cache!(startc)
    @test is_chem_cache_valid(startc)
end