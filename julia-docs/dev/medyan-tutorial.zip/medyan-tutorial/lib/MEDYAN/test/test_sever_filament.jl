using MEDYAN
using StaticArrays
using OffsetArrays: Origin
using Test

@testset "sever_filament!" begin
    ≊(a,b) = isapprox(a, b; atol = 1E-9)
    @testset "filament itself" begin
        c_init = MEDYAN.example_actin_mech_context(CubicGrid((2,2,2),500.0))
        f_params = MEDYAN.ACTIN_FIL_PARAMS
        numcyl = 6
        nummonomers = numcyl*f_params.numpercylinder
        monomerstates = ones(UInt8,nummonomers)
        monomerstates[begin] = 2
        monomerstates[end] = 3
        mon_len = f_params.spacing
        cyl_len = f_params.spacing*f_params.numpercylinder
        nodepositions = [
            SA[1.0,2.0,3.0],
            SA[1.0,2.0,3.0+cyl_len*numcyl]
        ]
        fid_long = MEDYAN.chem_newfilament!(c_init;
            ftid= 1, 
            monomerstates,
            node_mids= [5],
            nodepositions,
        )
        fid_short = MEDYAN.chem_newfilament!(c_init;
            ftid= 1, 
            monomerstates= [0x01, 0x02, 0x03, 0x04, 0x05],
            node_mids= [5],
            nodepositions= [
                SA[1.0,2.0,3.0],
                SA[1.0,2.0,3.0+mon_len*5],
            ],
        )
        @testset "cut long filament at node" begin
            c = deepcopy(c_init)
            new_fid = sever_filament!(c, MonomerName(1,fid_long,120))
            MEDYAN.assert_invariants(c)
            @test !MEDYAN.is_chem_cache_valid(c)
            new_fids = collect(filtype_fil_ids(c, 1))
            @test fid_long ∈ new_fids
            @test length(new_fids) == 3
            @test new_fid == setdiff(new_fids, [fid_long, fid_short])[1]
            # the minus end is the new filament. 
            minus_nodes = fil_node_positions(c, 1, new_fid)
            plus_nodes = fil_node_positions(c, 1, fid_long)
            @test minus_nodes ≊ [
                SA[1.0,2.0,3.0],
                SA[1.0,2.0,3.0+35mon_len],
                SA[1.0,2.0,3.0+35mon_len+cyl_len],
                SA[1.0,2.0,3.0+35mon_len+2cyl_len],
            ]
            @test plus_nodes ≊ [
                SA[1.0,2.0,3.0+35mon_len+2cyl_len],
                SA[1.0,2.0,3.0+35mon_len+3cyl_len],
                SA[1.0,2.0,3.0+35mon_len+4cyl_len],
                SA[1.0,2.0,3.0+35mon_len+5cyl_len],
                SA[1.0,2.0,3.0+6cyl_len],
            ]
            minus_node_mon_ids = fil_node_mon_ids(c, 1, new_fid)
            plus_node_mon_ids = fil_node_mon_ids(c, 1, fid_long)
            @test minus_node_mon_ids == [
                5,
                40,
                80,
                120,
            ]
            @test plus_node_mon_ids == [
                120,
                160,
                200,
                240,
                245,
            ]
            minus_mon_states = fil_mon_states(c, 1, new_fid)
            plus_mon_states = fil_mon_states(c, 1, fid_long)
            @test minus_mon_states == Origin(5)([0x02; ones(UInt8,114);])
            @test plus_mon_states == Origin(120)([ones(UInt8,124); 0x03;])
            @test !mon_exists(c,MonomerName(1,fid_long,119))
            @test mon_exists(c,MonomerName(1,fid_long,120))
            @test mon_exists(c,MonomerName(1,fid_long,244))
            @test !mon_exists(c,MonomerName(1,fid_long,245))

            @test !mon_exists(c,MonomerName(1,new_fid,4))
            @test mon_exists(c,MonomerName(1,new_fid,5))
            @test mon_exists(c,MonomerName(1,new_fid,119))
            @test !mon_exists(c,MonomerName(1,new_fid,120))
        end
        @testset "cut long filament between nodes" begin
            c = deepcopy(c_init)
            new_fid = sever_filament!(c, MonomerName(1,fid_long,125))
            MEDYAN.assert_invariants(c)
            # the minus end is the new filament. 
            minus_nodes = fil_node_positions(c, 1, new_fid)
            plus_nodes = fil_node_positions(c, 1, fid_long)
            @test minus_nodes ≊ [
                SA[1.0,2.0,3.0],
                SA[1.0,2.0,3.0+35mon_len],
                SA[1.0,2.0,3.0+35mon_len+cyl_len],
                SA[1.0,2.0,3.0+35mon_len+2cyl_len],
                SA[1.0,2.0,3.0+3cyl_len],
            ]
            @test plus_nodes ≊ [
                SA[1.0,2.0,3.0+3cyl_len],
                SA[1.0,2.0,3.0+35mon_len+3cyl_len],
                SA[1.0,2.0,3.0+35mon_len+4cyl_len],
                SA[1.0,2.0,3.0+35mon_len+5cyl_len],
                SA[1.0,2.0,3.0+6cyl_len],
            ]
            minus_node_mon_ids = fil_node_mon_ids(c, 1, new_fid)
            plus_node_mon_ids = fil_node_mon_ids(c, 1, fid_long)
            @test minus_node_mon_ids == [
                5,
                40,
                80,
                120,
                125
            ]
            @test plus_node_mon_ids == [
                125,
                160,
                200,
                240,
                245,
            ]
            minus_mon_states = fil_mon_states(c, 1, new_fid)
            plus_mon_states = fil_mon_states(c, 1, fid_long)
            @test minus_mon_states == Origin(5)([0x02; ones(UInt8,119);])
            @test plus_mon_states == Origin(125)([ones(UInt8,119); 0x03;])
            @test !mon_exists(c,MonomerName(1,fid_long,124))
            @test mon_exists(c,MonomerName(1,fid_long,125))
            @test mon_exists(c,MonomerName(1,fid_long,244))
            @test !mon_exists(c,MonomerName(1,fid_long,245))

            @test !mon_exists(c,MonomerName(1,new_fid,4))
            @test mon_exists(c,MonomerName(1,new_fid,5))
            @test mon_exists(c,MonomerName(1,new_fid,124))
            @test !mon_exists(c,MonomerName(1,new_fid,125))
        end
        @testset "cut long filament near minus end" begin
            c = deepcopy(c_init)
            new_fid = sever_filament!(c, MonomerName(1,fid_long,10))
            MEDYAN.assert_invariants(c)
            # the minus end is the new filament. 
            minus_nodes = fil_node_positions(c, 1, new_fid)
            plus_nodes = fil_node_positions(c, 1, fid_long)
            @test minus_nodes ≊ [
                SA[1.0,2.0,3.0],
                SA[1.0,2.0,3.0+5mon_len],
            ]
            @test plus_nodes ≊ [
                SA[1.0,2.0,3.0+5mon_len],
                SA[1.0,2.0,3.0+35mon_len],
                SA[1.0,2.0,3.0+35mon_len+cyl_len],
                SA[1.0,2.0,3.0+35mon_len+2cyl_len],
                SA[1.0,2.0,3.0+35mon_len+3cyl_len],
                SA[1.0,2.0,3.0+35mon_len+4cyl_len],
                SA[1.0,2.0,3.0+35mon_len+5cyl_len],
                SA[1.0,2.0,3.0+6cyl_len],
            ]
            minus_node_mon_ids = fil_node_mon_ids(c, 1, new_fid)
            plus_node_mon_ids = fil_node_mon_ids(c, 1, fid_long)
            @test minus_node_mon_ids == [
                5,
                10,
            ]
            @test plus_node_mon_ids == [
                10,
                40,
                80,
                120,
                160,
                200,
                240,
                245,
            ]
            minus_mon_states = fil_mon_states(c, 1, new_fid)
            plus_mon_states = fil_mon_states(c, 1, fid_long)
            @test minus_mon_states == Origin(5)([0x02; ones(UInt8,4);])
            @test plus_mon_states == Origin(10)([ones(UInt8,234); 0x03;])
            @test !mon_exists(c,MonomerName(1,fid_long,9))
            @test mon_exists(c,MonomerName(1,fid_long,10))
            @test mon_exists(c,MonomerName(1,fid_long,244))
            @test !mon_exists(c,MonomerName(1,fid_long,245))

            @test !mon_exists(c,MonomerName(1,new_fid,4))
            @test mon_exists(c,MonomerName(1,new_fid,5))
            @test mon_exists(c,MonomerName(1,new_fid,9))
            @test !mon_exists(c,MonomerName(1,new_fid,10))
        end
        @testset "cut long filament near plus end" begin
            c = deepcopy(c_init)
            new_fid = sever_filament!(c, MonomerName(1,fid_long,241))
            MEDYAN.assert_invariants(c)
            # the minus end is the new filament. 
            minus_nodes = fil_node_positions(c, 1, new_fid)
            plus_nodes = fil_node_positions(c, 1, fid_long)
            @test minus_nodes ≊ [
                SA[1.0,2.0,3.0],
                SA[1.0,2.0,3.0+35mon_len],
                SA[1.0,2.0,3.0+35mon_len+cyl_len],
                SA[1.0,2.0,3.0+35mon_len+2cyl_len],
                SA[1.0,2.0,3.0+35mon_len+3cyl_len],
                SA[1.0,2.0,3.0+35mon_len+4cyl_len],
                SA[1.0,2.0,3.0+35mon_len+5cyl_len],
                SA[1.0,2.0,3.0+35mon_len+5cyl_len+mon_len],
            ]
            @test plus_nodes ≊ [
                SA[1.0,2.0,3.0+35mon_len+5cyl_len+mon_len],
                SA[1.0,2.0,3.0+6cyl_len],
            ]
            minus_node_mon_ids = fil_node_mon_ids(c, 1, new_fid)
            plus_node_mon_ids = fil_node_mon_ids(c, 1, fid_long)
            @test minus_node_mon_ids == [
                5,
                40,
                80,
                120,
                160,
                200,
                240,
                241,
            ]
            @test plus_node_mon_ids == [
                241,
                245,
            ]
            minus_mon_states = fil_mon_states(c, 1, new_fid)
            plus_mon_states = fil_mon_states(c, 1, fid_long)
            @test minus_mon_states == Origin(5)([0x02; ones(UInt8,235);])
            @test plus_mon_states == Origin(241)([ones(UInt8,3); 0x03;])
            @test !mon_exists(c,MonomerName(1,fid_long,240))
            @test mon_exists(c,MonomerName(1,fid_long,241))
            @test mon_exists(c,MonomerName(1,fid_long,244))
            @test !mon_exists(c,MonomerName(1,fid_long,245))

            @test !mon_exists(c,MonomerName(1,new_fid,4))
            @test mon_exists(c,MonomerName(1,new_fid,5))
            @test mon_exists(c,MonomerName(1,new_fid,240))
            @test !mon_exists(c,MonomerName(1,new_fid,241))
        end
        @testset "cut short filament" begin
            c = deepcopy(c_init)
            new_fid = sever_filament!(c, MonomerName(1,fid_short,7))
            MEDYAN.assert_invariants(c)
            # the minus end is the new filament. 
            minus_nodes = fil_node_positions(c, 1, new_fid)
            plus_nodes = fil_node_positions(c, 1, fid_short)
            @test minus_nodes ≊ [
                SA[1.0,2.0,3.0],
                SA[1.0,2.0,3.0+2mon_len],
            ]
            @test plus_nodes ≊ [
                SA[1.0,2.0,3.0+2mon_len],
                SA[1.0,2.0,3.0+5mon_len],
            ]
            minus_node_mon_ids = fil_node_mon_ids(c, 1, new_fid)
            plus_node_mon_ids = fil_node_mon_ids(c, 1, fid_short)
            @test minus_node_mon_ids == [
                5,
                7,
            ]
            @test plus_node_mon_ids == [
                7,
                10,
            ]
            minus_mon_states = fil_mon_states(c, 1, new_fid)
            plus_mon_states = fil_mon_states(c, 1, fid_short)
            @test minus_mon_states == Origin(5)([0x01, 0x02,])
            @test plus_mon_states == Origin(7)([0x03, 0x04, 0x05,])
            @test !mon_exists(c,MonomerName(1,fid_short,6))
            @test mon_exists(c,MonomerName(1,fid_short,7))
            @test mon_exists(c,MonomerName(1,fid_short,9))
            @test !mon_exists(c,MonomerName(1,fid_short,10))

            @test !mon_exists(c,MonomerName(1,new_fid,4))
            @test mon_exists(c,MonomerName(1,new_fid,5))
            @test mon_exists(c,MonomerName(1,new_fid,6))
            @test !mon_exists(c,MonomerName(1,new_fid,7))
        end
        @testset "creating a filament with less than 2 monomers errors" begin
            c = deepcopy(c_init)
            @test_throws Exception sever_filament!(c, MonomerName(1,fid_short,6))
        end

    end
    @testset "filament interactions" begin
        @testset "link_2mon" begin
            c = MEDYAN.example_actin_mech_context(CubicGrid((2,2,2),500.0))
            f_params = MEDYAN.ACTIN_FIL_PARAMS
            mon_len = f_params.spacing
            fid1 = MEDYAN.chem_newfilament!(c;
                ftid= 1, 
                monomerstates= ones(UInt8, 5),
                node_mids= [5],
                nodepositions= [
                    SA[1.0,2.0,3.0],
                    SA[1.0,2.0,3.0+mon_len*5],
                ],
            )
            fid2 = MEDYAN.chem_newfilament!(c;
                ftid= 1, 
                monomerstates= ones(UInt8, 5),
                node_mids= [1],
                nodepositions= [
                    SA[10.0,2.0,3.0],
                    SA[10.0,2.0,3.0+mon_len*5],
                ],
            )
            lid1 = MEDYAN.chem_newlink_2mon!(c,1,MonomerName(1,fid1,5)=>MonomerName(1,fid1,5);
                changedmechstate = (;mr0 = SA[1.0, 2.0, 3.0]),
            )

            @test link_2mon_state(c, 1, lid1).mechstate.mr0 == SA[1.0, 2.0, 3.0]

            lid2 = MEDYAN.chem_newlink_2mon!(c,1,MonomerName(1,fid1,7)=>MonomerName(1,fid1,7))
            lid3 = MEDYAN.chem_newlink_2mon!(c,1,MonomerName(1,fid1,9)=>MonomerName(1,fid1,9))
            lid4 = MEDYAN.chem_newlink_2mon!(c,1,MonomerName(1,fid1,6)=>MonomerName(1,fid1,7))
            lid5 = MEDYAN.chem_newlink_2mon!(c,1,MonomerName(1,fid1,8)=>MonomerName(1,fid1,6))
            lid6 = MEDYAN.chem_newlink_2mon!(c,1,MonomerName(1,fid1,5)=>MonomerName(1,fid2,1))
            lid7 = MEDYAN.chem_newlink_2mon!(c,1,MonomerName(1,fid2,4)=>MonomerName(1,fid1,8))
            lid8 = MEDYAN.chem_newlink_2mon!(c,1,MonomerName(1,fid1,9)=>MonomerName(1,fid2,5))
            fid3 = sever_filament!(c, MonomerName(1,fid1,7))
            MEDYAN.assert_invariants(c)
            @test link_2mon_endnames(c, 1, lid1) == (MonomerName(1,fid3,5)=>MonomerName(1,fid3,5))
            @test link_2mon_endnames(c, 1, lid2) == (MonomerName(1,fid1,7)=>MonomerName(1,fid1,7))
            @test link_2mon_endnames(c, 1, lid3) == (MonomerName(1,fid1,9)=>MonomerName(1,fid1,9))
            @test link_2mon_endnames(c, 1, lid4) == (MonomerName(1,fid3,6)=>MonomerName(1,fid1,7))
            @test link_2mon_endnames(c, 1, lid5) == (MonomerName(1,fid1,8)=>MonomerName(1,fid3,6))
            @test link_2mon_endnames(c, 1, lid6) == (MonomerName(1,fid3,5)=>MonomerName(1,fid2,1))
            @test link_2mon_endnames(c, 1, lid7) == (MonomerName(1,fid2,4)=>MonomerName(1,fid1,8))
            @test link_2mon_endnames(c, 1, lid8) == (MonomerName(1,fid1,9)=>MonomerName(1,fid2,5))

            @test link_2mon_state(c, 1, lid1).mechstate.mr0 == SA[1.0, 2.0, 3.0]

        end
        # TODO add cadherin tests
    end
end