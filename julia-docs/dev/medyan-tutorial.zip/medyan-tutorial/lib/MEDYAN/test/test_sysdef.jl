using MEDYAN
using Test

@testset "MEDYAN.SysDef" begin
    twofilament_agent_names = MEDYAN.AgentNames(
        diffusingspeciesnames= [:a,:b,:c,:d],
        bulkspeciesnames = [:ba, :bb],
        membranediffusingspeciesnames = [:ma, :mb],
        fixedspeciesnames= [:rate1b,:g],
        filamentnames= [(:actin,[
                            :plusend,
                            :minusend,
                            :middle,
                        ]),
                        (:MT,[
                            :plusend,
                            :minusend,
                            :middle,
                            :middle2,
                        ]),
                    ],
    )

    @testset "Construction" begin
        s= MEDYAN.SysDef(twofilament_agent_names)
        @test s.diffusing.a==1
        @test s.diffusing.b==2
        @test s.diffusing.c==3
        @test s.diffusing.d==4
        @test s.membranediffusing.ma == 1
        @test s.membranediffusing.mb == 2
        @test s.fixedspecies.rate1b==1
        @test s.fixedspecies.g==2
        @test s.filament.actin==1
        @test s.filament.MT==2
        @test s.state.actin.plusend==1
        @test s.state.actin.minusend==2
        @test s.state.actin.middle==3
        @test s.state.MT.plusend==1
        @test s.state.MT.minusend==2
        @test s.state.MT.middle==3
        @test s.state.MT.middle2==4
    end
    @testset "Reaction printing" begin
        s = MEDYAN.SysDef(twofilament_agent_names)
        addreaction!(s, "diffusing.a + diffusing.b --> diffusing.c",1.5,1)
        @test sprint(MEDYAN.printreaction, s, s.compartmentreactions[end]) == "\"diffusing.a + diffusing.b --> diffusing.c\" 1.5 nm³/s"
        addreaction!(s, MEDYAN.BulkReaction(
            [(id=2, amount=2)],
            [(id=2, amount=-1),(id=1, amount=1)],
            2.7,
        ))
        @test sprint(MEDYAN.printreaction, s, s.bulkreactions[end]) == "\"2bulk.bb --> bulk.bb + bulk.ba\" 2.7 1/s"
        # Adding membrane diffusing as bulk species will change s but not s.agent_names.
        MEDYAN.add_membranediffusion_asbulkreaction!(s)
        @test sprint(MEDYAN.printreaction, s, s.bulkreactions[begin]) == "\"bulk.__MEDYAN_MEMDIFF_BULK --> bulk.__MEDYAN_MEMDIFF_BULK\" 1.0 1/s"
    end
    @testset "addfilamentsite!" begin
        s= MEDYAN.SysDef(twofilament_agent_names)
        #place holder site object
        site= (s.state.MT.plusend,s.state.MT.minusend)
        addfilamentsite!(s,:MT,:d,site)
        @test s.filamentsite.MT.d.id==1
        @test s.filamentsite.MT.d.site==site
        @test s.filamentsite.MT.d.fxsid==3
        #place holder site object
        site= (s.state.actin.plusend,s.state.actin.minusend)
        addfilamentsite!(s,:actin,:p,site)
        @test s.filamentsite.actin.p.id==1
        @test s.filamentsite.actin.p.site==site
        @test s.filamentsite.actin.p.fxsid==4
        #place holder site object
        site= (s.state.actin.plusend,s.state.actin.minusend)
        addfilamentsite!(s,:actin,:m,site)
        @test s.filamentsite.actin.m.id==2
        @test s.filamentsite.actin.m.site==site
        @test s.filamentsite.actin.m.fxsid==5
        @test s.allfixedspeciesnames==[
            "fixedspecies.rate1b",
            "fixedspecies.g",
            "filamentsite.MT.d",
            "filamentsite.actin.p",
            "filamentsite.actin.m",
        ]
    end
    @testset "add_link_2mon!" begin
        agent_names = MEDYAN.AgentNames(link_2mon_names=[:a])
        s = MEDYAN.SysDef(agent_names)
        add_link_2mon!(s,
                :a,
                Link2MonState((a=Int32(1),),(;)),
                MEDYAN.RelativeRestraintMechParams(kr=1.0,kv̂=100.0, pr0_mvxmpr=[0.0,2.7,0.0], pv̂0_mvxmpr=[0.0,1.0,0.0]),
        )
        @test s.link_2mon.a == 1
        @test s.link_2mon_params.a.defaultstate == Link2MonState((a=Int32(1),),(;))
        @test s.link_2mon_params.a.mechparams == MEDYAN.RelativeRestraintMechParams(1.0, 100.0, [0.0, 2.7, 0.0], [0.0, 1.0, 0.0])
    end
    @testset "add_link_2mon_site!" begin
        agent_names = MEDYAN.AgentNames(link_2mon_names=[:a])
        s = MEDYAN.SysDef(agent_names)
        site = MEDYAN.Link2MonSiteOne()
        add_link_2mon_site!(s,:a,:mysite,site)
        @test s.link_2mon_site.a.mysite.id == 1
        @test s.link_2mon_site.a.mysite.site == site
        @test s.link_2mon_site.a.mysite.fxsid == 1
    end
    @testset "addfilamentendsite!" begin
        s= MEDYAN.SysDef(twofilament_agent_names)
        #place holder site object
        site= (s.state.MT.plusend,s.state.MT.minusend)
        addfilamentendsite!(s,:MT,:d,site)
        @test s.filamentendsite.MT.d.id==1
        @test s.filamentendsite.MT.d.site==site
        @test s.filamentendsite.MT.d.fxsid==3
        #place holder site object
        site= (s.state.actin.plusend,s.state.actin.minusend)
        addfilamentendsite!(s,:actin,:p,site)
        @test s.filamentendsite.actin.p.id==1
        @test s.filamentendsite.actin.p.site==site
        @test s.filamentendsite.actin.p.fxsid==4
        #place holder site object
        site= (s.state.actin.plusend,s.state.actin.minusend)
        addfilamentendsite!(s,:actin,:m,site)
        @test s.filamentendsite.actin.m.id==2
        @test s.filamentendsite.actin.m.site==site
        @test s.filamentendsite.actin.m.fxsid==5
        @test s.allfixedspeciesnames==[
            "fixedspecies.rate1b",
            "fixedspecies.g",
            "filamentendsite.MT.d",
            "filamentendsite.actin.p",
            "filamentendsite.actin.m",
        ]
    end
    @testset "addmembranesite!" begin
        s = MEDYAN.SysDef(twofilament_agent_names)
        addmembranesite!(s, :ms1, (dummy1 = 1, dummy2 = 2.0))
        @test length(s.membranesite) == 1
        @test s.membranesite.ms1.id == 1
        @test s.membranesite.ms1.site.dummy1 == 1
        @test s.membranesite.ms1.fxsid == 3
        @test_throws ErrorException addmembranesite!(s, :ms1, (dummy1 = 10, dummy2 = 20.0))
        @test length(s.membranesite) == 1
        @test s.membranesite.ms1.site.dummy1 == 1
        addmembranesite!(s, :ms2, (dummy1 = 3, dummy2 = 4.0))
        @test length(s.membranesite) == 2
        @test s.membranesite.ms2.id == 2
        @test s.membranesite.ms2.site.dummy1 == 3
        @test s.membranesite.ms2.fxsid == 4
        @test s.allfixedspeciesnames==[
            "fixedspecies.rate1b",
            "fixedspecies.g",
            "membranesite.ms1",
            "membranesite.ms2",
        ]
    end
    @testset "addreaction! diffusing" begin
        s= MEDYAN.SysDef(twofilament_agent_names)

        addreaction!(s, "diffusing.a + diffusing.b --> diffusing.c",1.5,1)
        @test s.compartmentreactions[end] == MEDYAN.CompartmentReaction(
            (1,2), #diffusingreactants
            [(id=1, amount=-1),(id=2, amount=-1),(id=3, amount=1)], #diffusingnet_stoich
            [], #fixedreactants
            [], #fixednet_stoich
            [], #bulkreactants
            [], #bulknet_stoich
            1.5, #rate
            1, #invvolumepower
        )

        addreaction!(s, "diffusing.c --> diffusing.a + diffusing.b",1.75,0)
        @test s.compartmentreactions[end] == MEDYAN.CompartmentReaction(
            (3,0), #diffusingreactants
            [(id=3, amount=-1),(id=1, amount=1),(id=2, amount=1)], #diffusingnet_stoich
            [], #fixedreactants
            [], #fixednet_stoich
            [], #bulkreactants
            [], #bulknet_stoich
            1.75, #rate
            0, #invvolumepower
        )

        addreaction!(s, "+ + diffusing.c + --> + diffusing.a + + diffusing.b + +",1.75,0)
        @test s.compartmentreactions[end] == MEDYAN.CompartmentReaction(
            (3,0), #diffusingreactants
            [(id=3, amount=-1),(id=1, amount=1),(id=2, amount=1)], #diffusingnet_stoich
            [], #fixedreactants
            [], #fixednet_stoich
            [], #bulkreactants
            [], #bulknet_stoich
            1.75, #rate
            0, #invvolumepower
        )

        addreaction!(s, " --> diffusing.a + diffusing.b",1.75,0)
        @test s.compartmentreactions[end] == MEDYAN.CompartmentReaction(
            (0,0), #diffusingreactants
            [(id=1, amount=1),(id=2, amount=1)], #diffusingnet_stoich
            [], #fixedreactants
            [], #fixednet_stoich
            [], #bulkreactants
            [], #bulknet_stoich
            1.75, #rate
            0, #invvolumepower
        )

        addreaction!(s, "diffusing.a + diffusing.b --> ",1.75,0)
        @test s.compartmentreactions[end] == MEDYAN.CompartmentReaction(
            (1,2), #diffusingreactants
            [(id=1, amount=-1),(id=2, amount=-1)], #diffusingnet_stoich
            [], #fixedreactants
            [], #fixednet_stoich
            [], #bulkreactants
            [], #bulknet_stoich
            1.75, #rate
            0, #invvolumepower
        )

        addreaction!(s, "diffusing.a + diffusing.a --> ",1.75,0)
        @test s.compartmentreactions[end] == MEDYAN.CompartmentReaction(
            (1,1), #diffusingreactants
            [(id=1, amount=-2),], #diffusingnet_stoich
            [], #fixedreactants
            [], #fixednet_stoich
            [], #bulkreactants
            [], #bulknet_stoich
            1.75, #rate
            0, #invvolumepower
        )

        addreaction!(s, "2diffusing.a --> ",1.75,0)
        @test s.compartmentreactions[end] == MEDYAN.CompartmentReaction(
            (1,1), #diffusingreactants
            [(id=1, amount=-2),], #diffusingnet_stoich
            [], #fixedreactants
            [], #fixednet_stoich
            [], #bulkreactants
            [], #bulknet_stoich
            1.75, #rate
            0, #invvolumepower
        )

        addreaction!(s, "2diffusing.a --> 20diffusing.a",1.75,0)
        @test s.compartmentreactions[end] == MEDYAN.CompartmentReaction(
            (1,1), #diffusingreactants
            [(id=1, amount=18),], #diffusingnet_stoich
            [], #fixedreactants
            [], #fixednet_stoich
            [], #bulkreactants
            [], #bulknet_stoich
            1.75, #rate
            0, #invvolumepower
        )

        addreaction!(s, "diffusing.c + diffusing.b --> diffusing.c + diffusing.b",1.75,0)
        @test s.compartmentreactions[end] == MEDYAN.CompartmentReaction(
            (3,2), #diffusingreactants
            [], #diffusingnet_stoich
            [], #fixedreactants
            [], #fixednet_stoich
            [], #bulkreactants
            [], #bulknet_stoich
            1.75, #rate
            0, #invvolumepower
        )
    end
    @testset "addreaction! fixed species" begin
        s= MEDYAN.SysDef(twofilament_agent_names)

        addreaction!(s, "fixedspecies.rate1b --> fixedspecies.g",1.75,0)
        @test s.compartmentreactions[end] == MEDYAN.CompartmentReaction(
            (0,0), #diffusingreactants
            [], #diffusingnet_stoich
            [(id=1, amount=1),], #fixedreactants
            [(id=1, amount=-1),(id=2, amount=1)], #fixednet_stoich
            [], #bulkreactants
            [], #bulknet_stoich
            1.75, #rate
            0, #invvolumepower
        )

        addreaction!(s, "fixedspecies.rate1b + fixedspecies.g --> fixedspecies.g",1.75,0)
        @test s.compartmentreactions[end] == MEDYAN.CompartmentReaction(
            (0,0), #diffusingreactants
            [], #diffusingnet_stoich
            [(id=1, amount=1),(id=2, amount=1)], #fixedreactants
            [(id=1, amount=-1)], #fixednet_stoich
            [], #bulkreactants
            [], #bulknet_stoich
            1.75, #rate
            0, #invvolumepower
        )

        addreaction!(s, "fixedspecies.rate1b + 23fixedspecies.g --> fixedspecies.g",1.75,0)
        @test s.compartmentreactions[end] == MEDYAN.CompartmentReaction(
            (0,0), #diffusingreactants
            [], #diffusingnet_stoich
            [(id=1, amount=1),(id=2, amount=23)], #fixedreactants
            [(id=1, amount=-1),(id=2, amount=-22)], #fixednet_stoich
            [], #bulkreactants
            [], #bulknet_stoich
            1.75, #rate
            0, #invvolumepower
        )

        addreaction!(s, "fixedspecies.g --> fixedspecies.rate1b + 23fixedspecies.g",1.75,0)
        @test s.compartmentreactions[end] == MEDYAN.CompartmentReaction(
            (0,0), #diffusingreactants
            [], #diffusingnet_stoich
            [(id=2, amount=1)], #fixedreactants
            [(id=2, amount=22),(id=1, amount=1)], #fixednet_stoich
            [], #bulkreactants
            [], #bulknet_stoich
            1.75, #rate
            0, #invvolumepower
        )
        addreaction!(s, "fixedspecies.g + fixedspecies.rate1b--> 2fixedspecies.rate1b + 23fixedspecies.g",1.75,0)
        @test s.compartmentreactions[end] == MEDYAN.CompartmentReaction(
            (0,0), #diffusingreactants
            [], #diffusingnet_stoich
            [(id=2, amount=1),(id=1, amount=1)], #fixedreactants
            [(id=2, amount=22),(id=1, amount=1)], #fixednet_stoich
            [], #bulkreactants
            [], #bulknet_stoich
            1.75, #rate
            0, #invvolumepower
        )
    end
    @testset "addreaction! filamentsites" begin
        s= MEDYAN.SysDef(twofilament_agent_names)
        #place holder site object
        site= (s.state.MT.plusend,s.state.MT.minusend)
        addfilamentsite!(s,:MT,:d,site)
        addfilamentsite!(s,:actin,:p,site)
        addfilamentsite!(s,:actin,:m,site)

        addreaction!(s, "filamentsite.MT.d --> filamentsite.MT.d",1.75,0)
        @test s.compartmentreactions[end] == MEDYAN.CompartmentReaction(
            (0,0), #diffusingreactants
            [], #diffusingnet_stoich
            [(id=3, amount=1),], #fixedreactants
            [], #fixednet_stoich
            [], #bulkreactants
            [], #bulknet_stoich
            1.75, #rate
            0, #invvolumepower
        )

        addreaction!(s, "filamentsite.actin.p --> filamentsite.actin.p",1.75,0)
        @test s.compartmentreactions[end] == MEDYAN.CompartmentReaction(
            (0,0), #diffusingreactants
            [], #diffusingnet_stoich
            [(id=4, amount=1),], #fixedreactants
            [], #fixednet_stoich
            [], #bulkreactants
            [], #bulknet_stoich
            1.75, #rate
            0, #invvolumepower
        )
    end
    @testset "addreaction! fixedspecies and diffusing" begin
        s= MEDYAN.SysDef(twofilament_agent_names)
        #place holder site object
        site= (s.state.MT.plusend,s.state.MT.minusend)
        addfilamentsite!(s,:MT,:d,site)
        addfilamentsite!(s,:actin,:p,site)
        addfilamentsite!(s,:actin,:m,site)

        addreaction!(s, "filamentsite.MT.d + diffusing.a --> filamentsite.MT.d",1.75,0)
        @test s.compartmentreactions[end] == MEDYAN.CompartmentReaction(
            (1,0), #diffusingreactants
            [(id=1, amount=-1)], #diffusingnet_stoich
            [(id=3, amount=1),], #fixedreactants
            [], #fixednet_stoich
            [], #bulkreactants
            [], #bulknet_stoich
            1.75, #rate
            0, #invvolumepower
        )

        addreaction!(s, "fixedspecies.g --> diffusing.a",1.75,0)
        @test s.compartmentreactions[end] == MEDYAN.CompartmentReaction(
            (0,0), #diffusingreactants
            [(id=1, amount=1)], #diffusingnet_stoich
            [(id=2, amount=1)], #fixedreactants
            [(id=2, amount=-1)], #fixednet_stoich
            [], #bulkreactants
            [], #bulknet_stoich
            1.75, #rate
            0, #invvolumepower
        )

        addreaction!(s, "diffusing.a --> fixedspecies.g",1.75,0)
        @test s.compartmentreactions[end] == MEDYAN.CompartmentReaction(
            (1,0), #diffusingreactants
            [(id=1, amount=-1)], #diffusingnet_stoich
            [], #fixedreactants
            [(id=2, amount=1)], #fixednet_stoich
            [], #bulkreactants
            [], #bulknet_stoich
            1.75, #rate
            0, #invvolumepower
        )

    end
    @testset "addreactioncallback!" begin
        s= MEDYAN.SysDef(twofilament_agent_names)
        site= MEDYAN.FilamentSiteGeneral(1,[s.state.actin.minusend])
        addfilamentsite!(s,:actin,:pm,site)
        callback= MEDYAN.GeneralFilamentSiteCallback(
            s.filament.actin,
            s.filamentsite.actin.pm.id,
            1,
            [s.state.actin.middle],
            [s.diffusing.a=>-1],
        )
        #"actin(0,minusend) + diffusing.a -> actin(minusend,middle) "
        addreactioncallback!(s, "filamentsite.actin.pm + diffusing.a",1.75,1,callback)
    end
    @testset "addfilamentend_reaction!" begin
        s= MEDYAN.SysDef(twofilament_agent_names)

        #depolymerization minus end
        addfilamentend_reaction!(s,:actin,:dpm,true,
                [:minusend,:middle]=>[:minusend],
                0.0,
                "--> diffusing.a",1.75,0)
        @test s.compartmentreactions[begin] == MEDYAN.CompartmentReaction(
            (0,0), #diffusingreactants
            [], #diffusingnet_stoich
            [(id=s.filamentendsite.actin.dpm.fxsid, amount=1)], #fixedreactants
            [], #fixednet_stoich
            [], #bulkreactants
            [], #bulknet_stoich
            1.75, #rate
            0, #invvolumepower
        )
        @test  s.filamentendsite.actin.dpm.site == MEDYAN.FilamentEndSiteGeneral(
            true, [0x02,0x03], 0.0)
        @test  s.compartmentreactioncallbacks[begin] == MEDYAN.GeneralFilamentEndCallback(
            s.filament.actin, s.filamentendsite.actin.dpm.id, -1, [2], [1=>1])

        #polymerization minus end
        addfilamentend_reaction!(s,:actin,:pm,true,
                [:minusend]=>[:minusend,:middle],
                2.5,
                "diffusing.a --> ",1.75,1)
        @test s.compartmentreactions[begin] == MEDYAN.CompartmentReaction(
            (1,0), #diffusingreactants
            [], #diffusingnet_stoich
            [(id=s.filamentendsite.actin.pm.fxsid, amount=1)], #fixedreactants
            [], #fixednet_stoich
            [], #bulkreactants
            [], #bulknet_stoich
            1.75, #rate
            1, #invvolumepower
        )
        @test  s.filamentendsite.actin.pm.site == MEDYAN.FilamentEndSiteGeneral(
            isminusend=true,
            endstates=[0x02],
            spacing=2.5,
            added_monomers=1,
        )
        @test  s.compartmentreactioncallbacks[begin] == MEDYAN.GeneralFilamentEndCallback(
            s.filament.actin, s.filamentendsite.actin.pm.id, 1, [2,3], [1=>-1])
    end
    @testset "addfilament_reaction!" begin
        s= MEDYAN.SysDef(twofilament_agent_names)

        addfilament_reaction!(s,:MT,:dpm,
                [:middle]=>[:middle2],
                1,
                "diffusing.b --> diffusing.a",1.75,0)
        @test s.compartmentreactions[begin] == MEDYAN.CompartmentReaction(
            (2,0), #diffusingreactants
            [], #diffusingnet_stoich
            [(id=s.filamentsite.MT.dpm.fxsid, amount=1)], #fixedreactants
            [], #fixednet_stoich
            [], #bulkreactants
            [], #bulknet_stoich
            1.75, #rate
            0, #invvolumepower
        )
        @test  s.filamentsite.MT.dpm.site == MEDYAN.FilamentSiteGeneral(
            1,[3])
        @test  s.compartmentreactioncallbacks[begin] == MEDYAN.GeneralFilamentSiteCallback(
            s.filament.MT, s.filamentsite.MT.dpm.id, 1, [4], [s.diffusing.b=>-1, s.diffusing.a=>1])
    end

    @testset "add membrane site and reaction" begin
        s = MEDYAN.SysDef(twofilament_agent_names)

        add_membranesitereaction!(;
            s,
            name_newmembranesite = :ms1,
            membranediffusingreactants = Symbol[],
            membranediffusingproducts = Symbol[],
            reactionexpr_extra = "diffusing.a --> diffusing.b",
            rate = 1.234,
            canchangerate_bypotentialenergy = false,
            invvolumepower = 100
        )
        @test length(s.membranesite) == 1
        @test length(s.compartmentreactions) == 1
        @test length(s.compartmentreactioncallbacks) == 1
        @test length(s.allfixedspeciesnames) == 3
        let r = first(s.compartmentreactions)
            @test r.diffusingreactants == (1, 0)
            @test r.diffusingnet_stoich |> isempty
            @test r.fixedreactants == [(id=3, amount=1)]
            @test r.fixednet_stoich |> isempty
            @test r.bulkreactants |> isempty
            @test r.rate == 1.234
            @test r.invvolumepower == 100
        end
        let cb = first(s.compartmentreactioncallbacks)
            @test typeof(cb) == MEDYAN.MembraneSiteReactionCallbackDiffusion
            @test cb.siteindex == 1
            @test cb.diffusing_net_stoich == [1=>-1, 2=>1]
        end
        let ms = s.membranesite.ms1
            @test typeof(ms.site) == MEDYAN.MembraneSiteDiffusing
            @test ms.id == 1
            @test ms.site.id_membranediffusing_reactant == 0
            @test ms.site.canchangerate_bypotentialenergy == false
            @test ms.site.membranediffusingnet_stoich |> isempty
        end

        add_membranesitereaction!(;
            s,
            name_newmembranesite = :ms2,
            membranediffusingreactants = [:ma],
            membranediffusingproducts = [:ma, :mb],
            reactionexpr_extra = "diffusing.b -->",
            rate = 4.321,
            canchangerate_bypotentialenergy = true,
            invvolumepower = -100
        )
        @test length(s.membranesite) == 2
        @test length(s.compartmentreactions) == 2
        @test length(s.compartmentreactioncallbacks) == 2
        @test length(s.allfixedspeciesnames) == 4
        let r = first(s.compartmentreactions)
            @test r.diffusingreactants == (2, 0)
            @test r.diffusingnet_stoich |> isempty
            @test r.fixedreactants == [(id=4, amount=1)]
            @test r.fixednet_stoich |> isempty
            @test r.bulkreactants |> isempty
            @test r.rate == 4.321
            @test r.invvolumepower == -100
        end
        let cb = first(s.compartmentreactioncallbacks)
            @test typeof(cb) == MEDYAN.MembraneSiteReactionCallbackDiffusion
            @test cb.diffusing_net_stoich == [2=>-1]
            @test cb.siteindex == 2
        end
        let ms = s.membranesite.ms2
            @test typeof(ms.site) == MEDYAN.MembraneSiteDiffusing
            @test ms.id == 2
            @test ms.site.id_membranediffusing_reactant == s.membranediffusing.ma
            @test ms.site.canchangerate_bypotentialenergy == true
            @test ms.site.membranediffusingnet_stoich == [s.membranediffusing.mb=>1]
        end

        @test_throws ErrorException add_membranesitereaction!(;
            s,
            name_newmembranesite = :ms_err1,
            # More than one reactant.
            membranediffusingreactants = [:ma, :mb],
            membranediffusingproducts = Symbol[],
            reactionexpr_extra = "-->",
            rate = 1.0,
            canchangerate_bypotentialenergy = false,
            invvolumepower = 0
        )
        @test_throws ErrorException add_membranesitereaction!(;
            s,
            # Existing name.
            name_newmembranesite = :ms1,
            membranediffusingreactants = Symbol[],
            membranediffusingproducts = Symbol[],
            reactionexpr_extra = "-->",
            rate = 1.0,
            canchangerate_bypotentialenergy = false,
            invvolumepower = 0
        )
        @test_throws ErrorException add_membranesitereaction!(;
            s,
            name_newmembranesite = :ms_err2,
            membranediffusingreactants = Symbol[],
            membranediffusingproducts = Symbol[],
            # Invalid reaction expression.
            reactionexpr_extra = "",
            rate = 1.0,
            canchangerate_bypotentialenergy = false,
            invvolumepower = 0
        )
    end
end