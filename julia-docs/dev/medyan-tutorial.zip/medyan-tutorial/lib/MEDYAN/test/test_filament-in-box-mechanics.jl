using MEDYAN
using Test
using StaticArrays
using HDF5

@testset "Filament growing in a box mechanics" begin
    c, s = MEDYAN.example_actin_mech_context(CubicGrid((2,2,2),500.0))

    for nummonomers in (851,1099)
        # load filament path
        trajfile= h5open(joinpath(@__DIR__,"reference-data/filament-in-a-box/out.h5"),"r")
        filamentdata= read(trajfile["node_pos"]["$nummonomers"])
        filamentpath= [SVector{3,Float64}(filamentdata[:,i]) for i in 1:size(filamentdata,2)]
        filamentmids= Int.(read(trajfile["node_mids"]["$nummonomers"]))

        fid= MEDYAN.chem_newfilament!(c;
            ftid= 1, 
            monomerstates= ones(UInt8,nummonomers),
            node_mids= filamentmids,
            nodepositions= filamentpath,
        )
        MEDYAN.minimize_energy!(c)
        @test MEDYAN.path_rmsd(fil_node_positions(c, 1, fid),filamentpath) < 5.0
        MEDYAN.chem_removefilament!(c)
    end
end