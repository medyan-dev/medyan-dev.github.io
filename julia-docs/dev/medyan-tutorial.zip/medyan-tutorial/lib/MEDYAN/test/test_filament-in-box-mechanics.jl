using MEDYAN
using Test
using StaticArrays
using SmallZarrGroups

@testset "Filament growing in a box mechanics" begin
    c, s = MEDYAN.example_actin_mech_context(CubicGrid((2,2,2),500.0))

    trajfile= SmallZarrGroups.load_dir(joinpath(@__DIR__,"reference-data/filament-in-a-box/out.zarr.zip"))
    for step in (110,230)
        # load filament path
        local n::Int = trajfile["num_nodes"][step]
        local start::Int = trajfile["start_nodes"][step]
        local filament = transpose(trajfile["node_pos"][start:start+n-1,:])
        local node_mids = trajfile["node_mids"][start:start+n-1]
        
        local points = SVector{3,Float64}[SVector{3,Float64}(filament[:,i]) for i in 1:size(filament,2)]

        fid= MEDYAN.chem_newfilament!(c;
            ftid= 1,
            monomerstates= ones(UInt8,node_mids[end]-node_mids[begin]),
            node_mids= node_mids,
            nodepositions= points,
        )
        MEDYAN.minimize_energy!(c)
        @test MEDYAN.path_rmsd(fil_node_positions(c, 1, fid), points) < 5.0
        MEDYAN.chem_removefilament!(c; ftid=1)
    end
end