using MEDYAN
using Setfield
using StaticArrays
using Suppressor
using Test


@testset "Resolve filament mesh crossing" begin
    ≊(a,b) = isapprox(a, b; atol = 1E-9)
    function create_mesh(vertex_triangle_list)
        m = MEDYAN.create_membranemesh()
        MEDYAN.initmesh!(m, vertex_triangle_list)
        MEDYAN.compute_geometry!_system(m)
        m
    end

    function create_filament(;monomerstates, node_mids, nodepositions, numpercylinder)
        cylinders = MEDYAN.ChemCylinders(1, numpercylinder)
        MEDYAN.create_filament!(cylinders;
            fil_id=1,
            monomerstates,
            node_mids,
            nodepositions,

        )
        cylinders, 1
    end

    function set_nodepositions(fc, fi, nodepos)
        cylinders = MEDYAN.ChemCylinders(1, fc.numpercylinder)
        MEDYAN.create_filament!(cylinders;
            fil_id=1,
            monomerstates = fc.per_fil.monomerstates[fi],
            node_mids = MEDYAN._fil_node_mon_ids(fc, fi),
            nodepositions = nodepos,
        )
        cylinders, 1
    end

    m1 = create_mesh((
        vertlist = [SA[0,0,0], SA[1,0,0], SA[0,1,0]],
        trilist = [SA[1,2,3]],
    ))

    tree = MEDYAN.build_aabbtree_frommeshes((m1,))

    # 3 segments.
    nodepos = [SA[1/3,1/3,-5], SA[1/3,1/3,-4], SA[1/3,1/3,-2], SA[1/3,1/3,-1]]
    fc, fi = create_filament(;
        monomerstates = zeros(4),
        node_mids = [-1,0,2],
        nodepositions = copy(nodepos),
        numpercylinder = 2,
    )
    prev_nodepositions = copy(MEDYAN._get_nodepositions(fc, fi))
    MEDYAN.resolve_filament_mesh_crossing!(fc, fi, SA[m1], tree)
    @test prev_nodepositions == MEDYAN._get_nodepositions(fc, fi)

    fc, fi = set_nodepositions(fc, fi, nodepos .+ (SA[0,0,3/2],))
    prev_nodepositions = copy(MEDYAN._get_nodepositions(fc, fi))
    @suppress MEDYAN.resolve_filament_mesh_crossing!(fc, fi, SA[m1], tree; tback=1/2)
    @test prev_nodepositions != MEDYAN._get_nodepositions(fc, fi)
    @test MEDYAN._get_nodepositions(fc, fi) ≊ [SA[1/3,1/3,-7/2], SA[1/3,1/3,-5/2], SA[1/3,1/3,-1/2], SA[1/3,1/3,-1/4]]

    # Right on bead.
    fc, fi = set_nodepositions(fc, fi, nodepos .+ (SA[0,0,1],))
    prev_nodepositions = copy(MEDYAN._get_nodepositions(fc, fi))
    @suppress MEDYAN.resolve_filament_mesh_crossing!(fc, fi, SA[m1], tree; tback=1/2)
    @test prev_nodepositions != MEDYAN._get_nodepositions(fc, fi)
    @test MEDYAN._get_nodepositions(fc, fi) ≊ [SA[1/3,1/3,-4], SA[1/3,1/3,-3], SA[1/3,1/3,-1], SA[1/3,1/3,-1/2]]

    fc, fi = set_nodepositions(fc, fi, nodepos .+ (SA[0,0,3],))
    prev_nodepositions = copy(MEDYAN._get_nodepositions(fc, fi))
    @suppress MEDYAN.resolve_filament_mesh_crossing!(fc, fi, SA[m1], tree; tback=1/2)
    @test prev_nodepositions != MEDYAN._get_nodepositions(fc, fi)
    @test MEDYAN._get_nodepositions(fc, fi) ≊ [SA[1/3,1/3,-2], SA[1/3,1/3,-1], SA[1/3,1/3,-2/3], SA[1/3,1/3,-1/2]]

    # No intersect.
    fc, fi = set_nodepositions(fc, fi, nodepos .+ (SA[2/3,2/3,3],))
    prev_nodepositions = copy(MEDYAN._get_nodepositions(fc, fi))
    MEDYAN.resolve_filament_mesh_crossing!(fc, fi, SA[m1], tree; tback=1/2)
    @test prev_nodepositions == MEDYAN._get_nodepositions(fc, fi)


    # 1 segment.
    nodepos = [SA[1/3,1/3,2], SA[1/3,1/3,-1]]
    fc, fi = create_filament(;
        monomerstates = zeros(30),
        node_mids = [20],
        nodepositions = copy(nodepos),
        numpercylinder = 100,
    )
    prev_nodepositions = copy(MEDYAN._get_nodepositions(fc, fi))
    @suppress MEDYAN.resolve_filament_mesh_crossing!(fc, fi, SA[m1], tree; tback=1/2)
    @test prev_nodepositions != MEDYAN._get_nodepositions(fc, fi)
    @test MEDYAN._get_nodepositions(fc, fi) ≊ [SA[1/3,1/3,-1/2], SA[1/3,1/3,-1]]

    # Add more membranes.
    # m2: 2 triangles with the same direction.
    m2 = create_mesh((
        vertlist = [SA[0,0,0], SA[1,0,0], SA[0,1,0], SA[0,0,1/2], SA[1,0,1/2], SA[0,1,1/2]],
        trilist = [SA[1,2,3], SA[4,5,6]],
    ))
    tree = MEDYAN.build_aabbtree_frommeshes((m2,))
    fc, fi = set_nodepositions(fc, fi, nodepos)
    @test_throws ErrorException MEDYAN.resolve_filament_mesh_crossing!(fc, fi, SA[m2], tree; tback=1/2)

    # m2: 2 triangles with different directions.
    m2 = create_mesh((
        vertlist = [SA[0,0,0], SA[1,0,0], SA[0,1,0], SA[0,0,1/2], SA[1,0,1/2], SA[0,1,1/2]],
        trilist = [SA[1,2,3], SA[6,5,4]],
    ))
    tree = MEDYAN.build_aabbtree_frommeshes((m2,))
    fc, fi = set_nodepositions(fc, fi, nodepos)
    MEDYAN.resolve_filament_mesh_crossing!(fc, fi, SA[m2], tree; tback=1/2)
    @test nodepos ≊ MEDYAN._get_nodepositions(fc, fi)

    # m1 and m2 sandwiches the cylinder.
    m1 = create_mesh((
        vertlist = [SA[0,0,0], SA[1,0,0], SA[0,1,0]],
        trilist = [SA[3,2,1]],
    ))
    m2 = create_mesh((
        vertlist = [SA[0,0,1], SA[1,0,1], SA[0,1,1]],
        trilist = [SA[1,2,3]],
    ))
    tree = MEDYAN.build_aabbtree_frommeshes((m1,m2))
    fc, fi = set_nodepositions(fc, fi, nodepos)
    @suppress MEDYAN.resolve_filament_mesh_crossing!(fc, fi, SA[m1,m2], tree; tback=0.8)
    @test !(nodepos ≊ MEDYAN._get_nodepositions(fc, fi))
    @test MEDYAN._get_nodepositions(fc, fi) ≊ [SA[1/3,1/3,0.88], SA[1/3,1/3,0.4]]

    @testset "Context-based integration" begin
        membranemechparams = fill(MEDYAN.MembraneMechParams(), 2)
        
        grid = MEDYAN.CubicGrid((1,1,1), 500)

        agent_names = MEDYAN.AgentNames(
            filamentnames = [(:actin, [:dummymonomer])],
        )
        s = MEDYAN.SysDef(agent_names)
        add_filament_params!(s, :actin, MEDYAN.FilamentMechParams(;
            radius = 3.0,
            spacing = 1.0,
            klength = 0.0,
            kangle = 0.0,
            numpercylinder = 10,
        ))
        c = MEDYAN.Context(s, grid;
            membranemechparams,
        )

        m1 = newmembrane!(c; type = 1, meshinit = (;
            vertlist = [SA[0,0,1], SA[1,0,1], SA[0,1,1]],
            trilist = [SA[1,2,3]],
        ))
        m2 = newmembrane!(c; type = 1, meshinit = (;
            vertlist = [SA[0,0,0], SA[1,0,0], SA[0,1,0]],
            trilist = [SA[3,2,1]],
        ))
        f1 = MEDYAN.make_fila!(c;
            type= :actin,
            mono_states = fill(s.state.actin.dummymonomer, 10),
            node_positions = [SA[1/3,1/3,-1], SA[1/3,1/3,2]],
            node_mids = [0, 10],
        )

        let tree = MEDYAN.build_aabbtree_frommeshes(c.membranes)
            compute_all_membrane_geometry!_system(c)
            @suppress resolve_all_filament_mesh_crossing!(c, tree; tback = 0.8)
        end
        @test fila_node_positions(c, f1) ≊ [SA[1/3,1/3,0.12], SA[1/3,1/3,0.6]]
    end
end