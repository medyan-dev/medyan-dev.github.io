using PlutoSliderServer
import LibGit2
import Dates

today = string(Dates.today())
repo = LibGit2.GitRepoExt("..")
githash = string(LibGit2.head_oid(repo))[1:7]
export_directory(; Export_output_dir="$(today)-githash-$(githash)")