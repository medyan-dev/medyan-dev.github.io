### A Pluto.jl notebook ###
# v0.19.9

using Markdown
using InteractiveUtils

# ╔═╡ fe60f470-3752-11ec-1cf8-19ed0e8f245c
begin
	filter!(LOAD_PATH) do path
		path != "@v#.#"
	end;
    import Pkg
    # activate the shared project environment
    Pkg.activate(Base.current_project())
	Pkg.resolve()#update Manifest.toml based on MEDYAN Project.toml updates
	Pkg.instantiate()
	
	using Revise
    using MEDYAN
	using MEDYANVis
	using Colors
	using StaticArrays
	using Dictionaries
	md"Packages"
end

# ╔═╡ ba276b7b-f136-4799-b767-a6d72c6326eb
agentnames = MEDYAN.AgentNames(
            filamentnames= [(:a,[
                                :me,
                                :a,
                                :b,
                                :c,
                                :pe,
                            ]),
                            (:b,[
                                :me,
                                :a,
                                :b,
                                :c,
                                :pe,
                            ]),
            ],
        )

# ╔═╡ c17f796f-acf0-4020-8e20-4735dd57e99d
filamentmechparams= [
        MEDYAN.FilamentMechParams(
            radius= 1.0,
            spacing= 10.0,
            klength= 1.0,
            kangle= 1.0,
            numpercylinder= 40,
        ),
        MEDYAN.FilamentMechParams(
            radius= 1.0,
            spacing= 10.0,
            klength= 1.0,
            kangle= 1.0,
            numpercylinder= 40,
        ),
    ]

# ╔═╡ 3c59de85-df1e-4feb-a0e9-141b1dfa3537
grid= CubicGrid((4,1,1),500.0)

# ╔═╡ a9291ffd-274a-4b73-9a99-e39d15bd11fd
boundingplanes = 10.0 .* [SA[-1.0,0.0,0.0,0.0],
	SA[1.0,0.0,0.0,1500],
	SA[0.0,-1.0,0.0,0.0],
	SA[0.0,1.0,0.0,500],
	SA[0.0,0.0,-1.0,0.0],
	SA[0.0,0.0,1.0,500]
]

# ╔═╡ f67e304b-237f-444e-a707-b6614e4920f3
begin
	s = MEDYAN.SysDef(agentnames)
    site = MEDYAN.Decimated2MonSiteRange(
		s.filament.a,s.filament.a,
		1,1,
		s.state.a.a,s.state.a.a,
		15.0,35.0
	)
    add_decimated_2mon_site!(s,:s,site)
    sitestep3 = MEDYAN.Decimated2MonSiteRange(
		s.filament.a,s.filament.a,
		3,3,
		s.state.a.a,s.state.a.a,
		15.0,35.0
	)
    add_decimated_2mon_site!(s,:step3,sitestep3)
    #multiple filament type decimated_2mon site
    siteab = MEDYAN.Decimated2MonSiteRange(
		s.filament.a,s.filament.b,
		1,1,
		s.state.a.a,s.state.b.a,
		15.0,35.0
	)
    add_decimated_2mon_site!(s,:ab,siteab)
    siteba = MEDYAN.Decimated2MonSiteRange(
		s.filament.b,s.filament.a,
		1,1,
		s.state.b.a,s.state.a.a,
		15.0,35.0
	)
    add_decimated_2mon_site!(s,:ba,siteba)
    siteb3a2 = MEDYAN.Decimated2MonSiteRange(
		s.filament.b,s.filament.a,
		3,2,
		s.state.b.a,s.state.a.a,
		15.0,35.0
	)
    add_decimated_2mon_site!(s,:b3a2,siteb3a2)
	siteminangle46 = MEDYAN.Decimated2MonSiteMinAngleRange(
		s.filament.b,s.filament.a,
		1,1,
		s.state.b.a,s.state.a.a,
		1.0,35.0,
		cos(46*π/180)
	)
	add_decimated_2mon_site!(s,:minangle46,siteminangle46)
	siteminangle44 = MEDYAN.Decimated2MonSiteMinAngleRange(
		s.filament.b,s.filament.a,
		1,1,
		s.state.b.a,s.state.a.a,
		1.0,35.0,
		cos(44*π/180)
	)
    add_decimated_2mon_site!(s,:minangle44,siteminangle44)
	cinit = MEDYAN.Context(s,grid;filamentmechparams)
end

# ╔═╡ cdb6f56e-6881-4368-838e-4113794ae6bc


# ╔═╡ 2bd76f00-cd9e-44e9-8af7-065fc474282f


# ╔═╡ 0a6f6070-a768-49d4-a3f9-80c9d3958b21


# ╔═╡ b168a723-7e06-4157-8368-294c2b175a80
vis = Visualizer()

# ╔═╡ 4cce5141-e0f3-437a-bc6a-dde7b04a89d0
begin
	delete!(vis)
	c = deepcopy(cinit)
    nummonomers= 9
        monomerstates= zeros(MonomerState,nummonomers)
        monomerstates[1]= s.state.a.me
        monomerstates[2:end-1].= s.state.a.a
        monomerstates[end]= s.state.a.pe
		nodepositionsC = [SA[470.0,200.0,200.0], SA[470.0+9*10.0,200.0,200.0]]
		nodepositionsD = [SA[480.0,201.0,200.0], SA[480.0+9*10.0,201.0,200.0]]
        fid1 = MEDYAN.chem_newfilament!(c; ftid=s.filament.a,monomerstates,nodepositions=nodepositionsC,node_mids=[1,])
        fid2 = MEDYAN.chem_newfilament!(c; ftid=s.filament.b,monomerstates,nodepositions=nodepositionsD,node_mids=[1,])
	MEDYAN.helper_mark_monomers_minimized!(c)
	MEDYAN.helper_reset_decimated_2mon_site_monomers!(c)
	setvisible!(vis["/Grid"], false)
	setvisible!(vis["/Axes"], false)
	setvisible!(vis["/Background"], false)
	setvisible!(vis["mechboundary"], false)
	setvisible!(vis["diffusing"], false)
end

# ╔═╡ b67dc26f-e0e5-4ff8-b7c8-4f46ac207f4a
typeof(c.link_2mon_data)

# ╔═╡ ae68061e-fd8d-472f-9f70-259644efd5ba
c

# ╔═╡ e6a57b83-adc6-46be-b4e5-eeedcc26d4ff
c.chemistryengine.fixedcounts

# ╔═╡ 72b13c65-e084-40cd-817c-bacdf2bfd04c
draw_context!(vis,c,s)

# ╔═╡ d987a7e3-8735-4279-9216-ab6f57326e2b
MEDYANVis.draw_decimated_2mon_sites!(vis,c,s)

# ╔═╡ 8080faa8-95a7-493c-821b-2367a5403e0b
render(vis)

# ╔═╡ 6f919103-2948-427a-91a5-9586e91f24ab
boundingplanes

# ╔═╡ Cell order:
# ╠═ba276b7b-f136-4799-b767-a6d72c6326eb
# ╠═c17f796f-acf0-4020-8e20-4735dd57e99d
# ╠═3c59de85-df1e-4feb-a0e9-141b1dfa3537
# ╠═a9291ffd-274a-4b73-9a99-e39d15bd11fd
# ╠═f67e304b-237f-444e-a707-b6614e4920f3
# ╠═4cce5141-e0f3-437a-bc6a-dde7b04a89d0
# ╠═cdb6f56e-6881-4368-838e-4113794ae6bc
# ╠═2bd76f00-cd9e-44e9-8af7-065fc474282f
# ╠═b67dc26f-e0e5-4ff8-b7c8-4f46ac207f4a
# ╠═0a6f6070-a768-49d4-a3f9-80c9d3958b21
# ╠═b168a723-7e06-4157-8368-294c2b175a80
# ╠═ae68061e-fd8d-472f-9f70-259644efd5ba
# ╠═e6a57b83-adc6-46be-b4e5-eeedcc26d4ff
# ╠═72b13c65-e084-40cd-817c-bacdf2bfd04c
# ╠═d987a7e3-8735-4279-9216-ab6f57326e2b
# ╠═8080faa8-95a7-493c-821b-2367a5403e0b
# ╠═fe60f470-3752-11ec-1cf8-19ed0e8f245c
# ╠═6f919103-2948-427a-91a5-9586e91f24ab
