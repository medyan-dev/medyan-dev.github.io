### A Pluto.jl notebook ###
# v0.19.9

using Markdown
using InteractiveUtils

# ╔═╡ fe60f470-3752-11ec-1cf8-19ed0e8f245c
begin
	filter!(LOAD_PATH) do path
		path != "@v#.#"
	end;
    import Pkg
    # activate the shared project environment
    Pkg.activate(Base.current_project())
	Pkg.resolve()#update Manifest.toml based on MEDYAN Project.toml updates
	Pkg.instantiate()
	
	using Revise
    using MEDYAN
	using MEDYANVis
	using Colors
	using StaticArrays
	md"Packages"
end

# ╔═╡ 5cf42aee-1af0-4769-a315-63a45e1c369b
using LinearAlgebra

# ╔═╡ ba276b7b-f136-4799-b767-a6d72c6326eb
agentnames = MEDYAN.AgentNames(
	diffusingspeciesnames= [:a,],
	filamentnames= [(:actin,[
                            :plusend,
                            :minusend,
                            :middle,
                        ]),
	],
)

# ╔═╡ 3c59de85-df1e-4feb-a0e9-141b1dfa3537
grid= CubicGrid((3,1,1),500.0)

# ╔═╡ a9291ffd-274a-4b73-9a99-e39d15bd11fd
boundingplanes = 10 .* [SA[-1.0,0.0,0.0,0.0],
	SA[1.0,0.0,0.0,1500],
	SA[0.0,-1.0,0.0,0.0],
	SA[0.0,1.0,0.0,500],
	SA[0.0,0.0,-1.0,0.0],
	SA[0.0,0.0,1.0,500]
]

# ╔═╡ a63c2946-a070-469b-9a33-c3a48185a66b
monomerspacing= 8.0/13.0

# ╔═╡ f67e304b-237f-444e-a707-b6614e4920f3
begin
	s= MEDYAN.SysDef(agentnames)
	
	#plus end polymerization
	addfilamentend_reaction!(s, :actin, :pp, false,
		[:plusend]=>[:middle,:plusend], monomerspacing,
		"diffusing.a -->", 10E3, 1,
	)
	#plus end depolymerization
	addfilamentend_reaction!(s, :actin, :dpp, false,
		[:middle,:plusend]=>[:plusend], 0.0,
		"--> diffusing.a", 1.75E-3, 0,
	)
end

# ╔═╡ 1d7839da-973b-408c-b26e-0e5e1b04f3c5
diffusion_coeffs= [1.0]

# ╔═╡ 1b78304a-ac90-49f0-b2fa-79a06eb101e3
100/0.6

# ╔═╡ b7cff062-630c-4f54-9084-f4e46697486a
EI=MEDYAN.lp_β_to_EI(0.08E6)

# ╔═╡ 80267810-a732-48e9-b088-7c47cf6483c2
MEDYAN.EI_spacing_to_k∠(EI, monomerspacing)

# ╔═╡ 4cce5141-e0f3-437a-bc6a-dde7b04a89d0
begin
	NMonomers= 30
	monomerstates= zeros(UInt8,NMonomers)
	monomerstates[1:end] .= s.state.actin.middle
	monomerstates[1] = s.state.actin.minusend
	monomerstates[end] = s.state.actin.plusend
	nodepositions= [SA[200.0,200,200],SA[200.0+NMonomers*monomerspacing,200.0,200.0]]
	filamentmechparams= [MEDYAN.FilamentMechParams(
        radius= 12.5,
        spacing= monomerspacing,
        klength= 15000.0,
        kangle= MEDYAN.EI_spacing_to_k∠(MEDYAN.lp_β_to_EI(0.08E6), monomerspacing),
		numpercylinder= 160,
		max_num_unmin_end= 1,
    )]
end

# ╔═╡ b168a723-7e06-4157-8368-294c2b175a80
vis = Visualizer()

# ╔═╡ 68a91291-c519-45bc-a3bc-6b08bf0b094c
vis2 = Visualizer()

# ╔═╡ ef4b0e29-ca88-42ca-b673-771b354e1299
begin
	delete!(vis)
	delete!(vis2)
	c= MEDYAN.Context(s,grid;diffusion_coeffs,filamentmechparams)
	set_mechboundary!(c; planes=boundingplanes)
	MEDYAN.adddiffusingcount_rand!(c, s.diffusing.a, 20000)
	fid1= MEDYAN.chem_newfilament!(c;
		ftid= s.filament.actin, 
		monomerstates,
		nodepositions,
		node_mids=[0,]
	)
	fid2= MEDYAN.chem_newfilament!(c;
		ftid= s.filament.actin, 
		monomerstates,
		nodepositions= nodepositions .+ (SA[0.0,100.0,100.0],),
		node_mids=[0,]
	)
	setvisible!(vis["/Grid"], false)
	setvisible!(vis["/Axes"], false)
	setvisible!(vis["/Background"], false)
	setvisible!(vis["mechboundary"], false)
	setvisible!(vis["diffusing"], false)
	nframes=1000
	for i in 1:nframes
		@info i
		draw_context!(vis, c, s)
		for j in 1:10
			MEDYAN.run_chemistry!(c,2.0)
			MEDYAN.minimize_energy!(c)
		end
	end
	#draw after
	setvisible!(vis2["/Grid"], false)
	setvisible!(vis2["/Axes"], false)
	setvisible!(vis2["/Background"], false)
	draw_context!(vis2, c, s)
end

# ╔═╡ a6fef778-a918-4db8-bbb9-e99c32e95225
MEDYAN.minimize_energy!(c)

# ╔═╡ ae68061e-fd8d-472f-9f70-259644efd5ba
c

# ╔═╡ c2ee1574-25d8-4a78-bc53-7e5ab490f2ad
fil_1_points = c.chem_cylinders[1].per_fil[1].chembeadpositions

# ╔═╡ a4335bb1-2604-4208-945a-83f95c63ceba
fil_1_points[1] - fil_1_points[2]

# ╔═╡ a1151738-7b11-4029-8a0a-101b63cb413c
map(1:length(fil_1_points)-1) do i
	norm(fil_1_points[i] - fil_1_points[i+1])
end	

# ╔═╡ e6a57b83-adc6-46be-b4e5-eeedcc26d4ff
c.chemistryengine.fixedcounts

# ╔═╡ 8080faa8-95a7-493c-821b-2367a5403e0b
render(vis)

# ╔═╡ 57eb0a7b-3038-4b79-b532-5324b778fd84
render(vis2)

# ╔═╡ 6f919103-2948-427a-91a5-9586e91f24ab
boundingplanes

# ╔═╡ Cell order:
# ╠═fe60f470-3752-11ec-1cf8-19ed0e8f245c
# ╠═ba276b7b-f136-4799-b767-a6d72c6326eb
# ╠═3c59de85-df1e-4feb-a0e9-141b1dfa3537
# ╠═a9291ffd-274a-4b73-9a99-e39d15bd11fd
# ╠═a63c2946-a070-469b-9a33-c3a48185a66b
# ╠═f67e304b-237f-444e-a707-b6614e4920f3
# ╠═1d7839da-973b-408c-b26e-0e5e1b04f3c5
# ╠═1b78304a-ac90-49f0-b2fa-79a06eb101e3
# ╠═b7cff062-630c-4f54-9084-f4e46697486a
# ╠═80267810-a732-48e9-b088-7c47cf6483c2
# ╠═4cce5141-e0f3-437a-bc6a-dde7b04a89d0
# ╠═ef4b0e29-ca88-42ca-b673-771b354e1299
# ╠═b168a723-7e06-4157-8368-294c2b175a80
# ╠═a6fef778-a918-4db8-bbb9-e99c32e95225
# ╠═ae68061e-fd8d-472f-9f70-259644efd5ba
# ╠═c2ee1574-25d8-4a78-bc53-7e5ab490f2ad
# ╠═a4335bb1-2604-4208-945a-83f95c63ceba
# ╠═5cf42aee-1af0-4769-a315-63a45e1c369b
# ╠═a1151738-7b11-4029-8a0a-101b63cb413c
# ╠═e6a57b83-adc6-46be-b4e5-eeedcc26d4ff
# ╠═68a91291-c519-45bc-a3bc-6b08bf0b094c
# ╠═8080faa8-95a7-493c-821b-2367a5403e0b
# ╠═57eb0a7b-3038-4b79-b532-5324b778fd84
# ╠═6f919103-2948-427a-91a5-9586e91f24ab
