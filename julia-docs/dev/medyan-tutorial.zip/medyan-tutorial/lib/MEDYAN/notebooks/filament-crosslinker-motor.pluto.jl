### A Pluto.jl notebook ###
# v0.19.22

using Markdown
using InteractiveUtils

# ╔═╡ fe60f470-3752-11ec-1cf8-19ed0e8f245c
begin
	filter!(LOAD_PATH) do path
		path != "@v#.#"
	end;
    import Pkg
    # activate the shared project environment
    Pkg.activate(Base.current_project())
	Pkg.resolve()#update Manifest.toml based on MEDYAN Project.toml updates
	Pkg.instantiate()
	
	using Revise
    using MEDYAN
	using MEDYANVis
	using Colors
	using StaticArrays
	using Dictionaries
	using Setfield
	using LinearAlgebra
	md"Packages"
end

# ╔═╡ ba276b7b-f136-4799-b767-a6d72c6326eb
agentnames = MEDYAN.AgentNames(
	diffusingspeciesnames= [:a,:cl,:m],
	filamentnames= [(:actin,[
                            :plusend,
                            :minusend,
                            :middle,
							:bound,
                        ]),
	],
	link_2mon_names= [
		:motor,
		:crosslinker,
	]
)

# ╔═╡ a63c2946-a070-469b-9a33-c3a48185a66b
monomerspacing= 2.7

# ╔═╡ f67e304b-237f-444e-a707-b6614e4920f3
begin
	s= MEDYAN.SysDef(agentnames)

	add_link_2mon!(s,
		:motor,
		Link2MonState((numHeads=20,),(L0=NaN,)),
		MEDYAN.DistanceRestraintMechParams(k=55.0),
	)
	
	add_link_2mon!(s,
		:crosslinker,
		Link2MonState((;),(L0=NaN,)),
		MEDYAN.DistanceRestraintMechParams(k=8.0),
	)
	
	#plus end polymerization
	addfilamentend_reaction!(s, :actin, :pp, false,
		[:plusend]=>[:middle,:plusend], monomerspacing,
		"diffusing.a -->", 0.154*500^3, 1,
	)
	#plus end depolymerization
	addfilamentend_reaction!(s, :actin, :dpp, false,
		[:middle,:plusend]=>[:plusend], 0.0,
		"--> diffusing.a", 1.4, 0,
	)

	#minus end polymerization
	addfilamentend_reaction!(s, :actin, :mp, true,
		[:minusend]=>[:minusend,:middle], monomerspacing,
		"diffusing.a -->", 0.0173*500^3, 1,
	)
	#minus end depolymerization
	addfilamentend_reaction!(s, :actin, :dmp, true,
		[:minusend,:middle]=>[:minusend], 0.0,
		"--> diffusing.a", 0.8, 0,
	)

	motorstepsize = 10

	#motor binding
	site = MEDYAN.Decimated2MonSiteMinAngleRange(
		s.filament.actin,
		s.filament.actin,
		motorstepsize,
		motorstepsize,
		s.state.actin.middle,
		s.state.actin.middle,
		175.0,
		225.0,
		cos(5*π/180),
	)
	add_decimated_2mon_site!(s,:motorbinding,site)
	bindcallback = MEDYAN.SimpleMotorBindCallback(
		s.decimated_2mon_site.motorbinding.id,
		s.link_2mon.motor,
		30, #max number of heads
		15, #min number of heads
		s.state.actin.bound,
		[s.diffusing.m=>-1],
	)
	addreactioncallback!(
		s,
		"decimated_2mon_site.motorbinding + diffusing.m",
		0.2*22*500^3/2,
		1,
		bindcallback,
	)

	#motor unbinding
	site = MEDYAN.Link2MonSiteMotorCatch()
	addunbindinglink_2mon_site!(s, 
		:motor, :unbinding, site,
		:actin, :middle, :actin, :middle,
		"--> diffusing.m", 1.0, 0, 
	)

	#motor stepping
	onrate = 0.2
	offrate = 1.7
	dutyratio = onrate/(onrate+offrate)
	site1 = MEDYAN.Link2MonSiteMotorStall(
		fs = 90.0,
		k0 = 6.0/(108/4)*((1 - dutyratio) / dutyratio) * onrate,
		isminusend = true,
	)
	site2 = @set site1.isminusend = false
	add_link_2mon_site!(s,:motor,:motorstepminus,site1)
	add_link_2mon_site!(s,:motor,:motorstepplus,site2)
	stepcallback1 = MEDYAN.SimpleMotorStepCallback(
		lsid = s.link_2mon_site.motor.motorstepminus.id,
		ltid = s.link_2mon.motor,
		unboundstate = s.state.actin.middle,
		boundstate = s.state.actin.bound,
		stepsize = motorstepsize,
	)
	stepcallback2 = @set stepcallback1.lsid = s.link_2mon_site.motor.motorstepplus.id
	addreactioncallback!(
		s,
		"link_2mon_site.motor.motorstepminus",
		1.0,
		0,
		stepcallback1,
	)
	addreactioncallback!(
		s,
		"link_2mon_site.motor.motorstepplus",
		1.0,
		0,
		stepcallback2,
	)

	#crosslinker binding site
	site = MEDYAN.Decimated2MonSiteMinAngleRange(
		s.filament.actin,
		s.filament.actin,
		10,
		10,
		s.state.actin.middle,
		s.state.actin.middle,
		30.0,
		40.0,
		cos(5*π/180)
	)
	add_decimated_2mon_site!(s,:crosslinkbinding,site)
	sitecallback = MEDYAN.SimpleCrosslinkBindCallback(
		s.decimated_2mon_site.crosslinkbinding.id,
		s.link_2mon.crosslinker,
		s.state.actin.bound,
		[s.diffusing.cl=>-1],
	)
	addreactioncallback!(s,
		"decimated_2mon_site.crosslinkbinding + diffusing.cl",
		0.01*500^3/2,
		1,
		sitecallback,
	)

	#crosslinker unbinding
	site = MEDYAN.Link2MonSiteSlipBond(f0 = inv(0.24*MEDYAN.default_β) , k0 = 0.3)
	addunbindinglink_2mon_site!(s, 
		:crosslinker, :unbinding, site,
		:actin, :middle, :actin, :middle,
		"--> diffusing.cl", 1.0, 0, 
	)
	
end

# ╔═╡ 1d7839da-973b-408c-b26e-0e5e1b04f3c5
#:a,:cl,:m
diffusion_coeffs= [20E6, 2.0E6, 0.2E6]

# ╔═╡ 4cce5141-e0f3-437a-bc6a-dde7b04a89d0
begin
	NMonomers= 40
	monomerstates= zeros(UInt8,NMonomers)
	monomerstates[1:end] .= s.state.actin.middle
	monomerstates[1] = s.state.actin.minusend
	monomerstates[end] = s.state.actin.plusend
	filamentmechparams= [MEDYAN.ACTIN_FIL_PARAMS]
end

# ╔═╡ 3c59de85-df1e-4feb-a0e9-141b1dfa3537
grid= CubicGrid((2,2,2),500.0)

# ╔═╡ a9291ffd-274a-4b73-9a99-e39d15bd11fd
boundingplanes = 10.0 .* [SA[-1.0,0.0,0.0,0.0],
	SA[1.0,0.0,0.0,grid.n[1]*500.0],
	SA[0.0,-1.0,0.0,0.0],
	SA[0.0,1.0,0.0,grid.n[2]*500.0],
	SA[0.0,0.0,-1.0,0.0],
	SA[0.0,0.0,1.0,grid.n[3]*500.0]
]

# ╔═╡ 1e3bce0b-a881-409d-a575-8a2ba57d2fa1
20*0.05

# ╔═╡ b168a723-7e06-4157-8368-294c2b175a80
vis = Visualizer()

# ╔═╡ 68a91291-c519-45bc-a3bc-6b08bf0b094c
vis2 = Visualizer()

# ╔═╡ ef4b0e29-ca88-42ca-b673-771b354e1299
begin
	delete!(vis)
	delete!(vis2)
	c= MEDYAN.Context(s,grid;
		diffusion_coeffs,
		filamentmechparams,
	    max_cylinder_force=1000.0,
		g_tol=1.0,
	)
	set_mechboundary!(c; planes=boundingplanes)
	adddiffusingcount_rand!(c, s.diffusing.a, 625*prod(grid.n))
	adddiffusingcount_rand!(c, s.diffusing.cl, 63*prod(grid.n))
	adddiffusingcount_rand!(c, s.diffusing.m, 6*prod(grid.n))
	for i in 1:(7*prod(grid.n))
		newfilament_rand!(c, monomerstates)
	end
	setvisible!(vis["/Grid"], false)
	setvisible!(vis["/Axes"], false)
	setvisible!(vis["/Background"], false)
	setvisible!(vis["mechboundary"], false)
	nframes=1000
	for i in 1:nframes
		@debug i
		draw_context!(vis, c, s)
		for j in 1:20
			MEDYAN.run_chemistry!(c,0.05)
			MEDYAN.minimize_energy!(c)
		end
	end
	#draw after
	setvisible!(vis2["/Grid"], false)
	setvisible!(vis2["/Axes"], false)
	setvisible!(vis2["/Background"], false)
	draw_context!(vis2, c, s)
end

# ╔═╡ ec558b41-542a-4b49-a04e-46685122866b
c.stats

# ╔═╡ ae68061e-fd8d-472f-9f70-259644efd5ba
c

# ╔═╡ e6a57b83-adc6-46be-b4e5-eeedcc26d4ff
c.chemistryengine.fixedcounts

# ╔═╡ 6f919103-2948-427a-91a5-9586e91f24ab


# ╔═╡ Cell order:
# ╠═ba276b7b-f136-4799-b767-a6d72c6326eb
# ╠═a9291ffd-274a-4b73-9a99-e39d15bd11fd
# ╠═a63c2946-a070-469b-9a33-c3a48185a66b
# ╠═f67e304b-237f-444e-a707-b6614e4920f3
# ╠═1d7839da-973b-408c-b26e-0e5e1b04f3c5
# ╠═4cce5141-e0f3-437a-bc6a-dde7b04a89d0
# ╠═3c59de85-df1e-4feb-a0e9-141b1dfa3537
# ╠═ef4b0e29-ca88-42ca-b673-771b354e1299
# ╠═1e3bce0b-a881-409d-a575-8a2ba57d2fa1
# ╠═ec558b41-542a-4b49-a04e-46685122866b
# ╠═b168a723-7e06-4157-8368-294c2b175a80
# ╠═ae68061e-fd8d-472f-9f70-259644efd5ba
# ╠═e6a57b83-adc6-46be-b4e5-eeedcc26d4ff
# ╠═68a91291-c519-45bc-a3bc-6b08bf0b094c
# ╠═fe60f470-3752-11ec-1cf8-19ed0e8f245c
# ╠═6f919103-2948-427a-91a5-9586e91f24ab
