### A Pluto.jl notebook ###
# v0.19.9

using Markdown
using InteractiveUtils

# ╔═╡ fe60f470-3752-11ec-1cf8-19ed0e8f245c
begin
	filter!(LOAD_PATH) do path
		path != "@v#.#"
	end;
    import Pkg
    # activate the shared project environment
    Pkg.activate(Base.current_project())
	Pkg.resolve()#update Manifest.toml based on MEDYAN Project.toml updates
	Pkg.instantiate()
	
	using Revise
    using MEDYAN
	using MEDYANVis
	using Colors
	using StaticArrays
	md"Packages"
end

# ╔═╡ ba276b7b-f136-4799-b767-a6d72c6326eb
s = MEDYAN.SysDef(MEDYAN.AgentNames())

# ╔═╡ 3c59de85-df1e-4feb-a0e9-141b1dfa3537
grid= CubicGrid((3,1,1),500.0)

# ╔═╡ a9291ffd-274a-4b73-9a99-e39d15bd11fd
boundingplanes = 0.01 .* [SA[-1.0,0.0,0.0,0.0],
	SA[1.0,0.0,0.0,1030],
	SA[0.0,-1.0,0.0,0.0],
	SA[0.0,1.0,0.0,500],
	SA[0.0,0.0,-1.0,0.0],
	SA[0.0,0.0,1.0,500]
]

# ╔═╡ be6d3933-930a-4963-9dd7-16ea0241b2b0
1/(500.0^3)

# ╔═╡ b168a723-7e06-4157-8368-294c2b175a80
vis = Visualizer()

# ╔═╡ 68a91291-c519-45bc-a3bc-6b08bf0b094c
vis2 = Visualizer()

# ╔═╡ ef4b0e29-ca88-42ca-b673-771b354e1299
begin
	delete!(vis)
	delete!(vis2)
	c= MEDYAN.Context(s,grid;)
	set_mechboundary!(c; planes=boundingplanes)
	set_chemboundary!(c; planes=boundingplanes)#, capsules=boundingcapsules)
	draw_context!(vis, c, s)
end

# ╔═╡ a6fef778-a918-4db8-bbb9-e99c32e95225
MEDYAN.minimize_energy!(c)

# ╔═╡ 0f54c094-6b62-47b9-aa31-7689b39d770c


# ╔═╡ b82d38b4-2203-4070-8ee9-a514929823d9
boundingcapsules=[
	SA[0.0,250.0,250.0, 200.0,0.0,0.0, 200.0, 1.0]
]

# ╔═╡ 6217f26b-791a-48ce-bb8d-9bde05e1a9a3
500/16

# ╔═╡ 532bf33e-45c2-4ff1-83d8-13a7d963380c
c.chemistryengine.invvolumes

# ╔═╡ 8080faa8-95a7-493c-821b-2367a5403e0b
render(vis)

# ╔═╡ 57eb0a7b-3038-4b79-b532-5324b778fd84
render(vis2)

# ╔═╡ 6f919103-2948-427a-91a5-9586e91f24ab
boundingplanes

# ╔═╡ Cell order:
# ╠═ba276b7b-f136-4799-b767-a6d72c6326eb
# ╠═3c59de85-df1e-4feb-a0e9-141b1dfa3537
# ╠═a9291ffd-274a-4b73-9a99-e39d15bd11fd
# ╠═be6d3933-930a-4963-9dd7-16ea0241b2b0
# ╠═ef4b0e29-ca88-42ca-b673-771b354e1299
# ╠═b168a723-7e06-4157-8368-294c2b175a80
# ╠═a6fef778-a918-4db8-bbb9-e99c32e95225
# ╠═68a91291-c519-45bc-a3bc-6b08bf0b094c
# ╠═0f54c094-6b62-47b9-aa31-7689b39d770c
# ╠═b82d38b4-2203-4070-8ee9-a514929823d9
# ╠═6217f26b-791a-48ce-bb8d-9bde05e1a9a3
# ╠═532bf33e-45c2-4ff1-83d8-13a7d963380c
# ╠═8080faa8-95a7-493c-821b-2367a5403e0b
# ╠═57eb0a7b-3038-4b79-b532-5324b778fd84
# ╠═fe60f470-3752-11ec-1cf8-19ed0e8f245c
# ╠═6f919103-2948-427a-91a5-9586e91f24ab
