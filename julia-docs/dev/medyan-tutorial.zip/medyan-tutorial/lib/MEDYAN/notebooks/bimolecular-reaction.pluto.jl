### A Pluto.jl notebook ###
# v0.17.1

using Markdown
using InteractiveUtils

# ╔═╡ fe60f470-3752-11ec-1cf8-19ed0e8f245c
begin
	filter!(LOAD_PATH) do path
		path != "@v#.#"
	end;
    import Pkg
    # activate the shared project environment
    Pkg.activate(Base.current_project())
	Pkg.resolve()#update Manifest.toml based on MEDYAN Project.toml updates
	Pkg.instantiate()
	
	using Revise
    using MEDYAN
	using MeshCat
	md"Packages"
end

# ╔═╡ ba276b7b-f136-4799-b767-a6d72c6326eb
agentnames = MEDYAN.AgentNames(
	diffusingspeciesnames= [:a,:b,:c],
)

# ╔═╡ 3c59de85-df1e-4feb-a0e9-141b1dfa3537
grid= CubicGrid((5,1,1),500.0)

# ╔═╡ f67e304b-237f-444e-a707-b6614e4920f3
begin
	s= MEDYAN.SysDef(agentnames)
	s=addreaction!(s,"diffusing.a + diffusing.b --> diffusing.c",1.5E9,1)
end

# ╔═╡ 1d7839da-973b-408c-b26e-0e5e1b04f3c5
diffusion_coeffs= [1.0E6,1.0E6,1.0E6]

# ╔═╡ f16a9d89-9be6-4e60-86a4-53f15cac90ba
vis = Visualizer()

# ╔═╡ c6f67756-6af8-4504-9619-e80b1934e0d5
vis2 = Visualizer()

# ╔═╡ d83dd3e0-8fe7-4cab-a2c6-a6802edff167
begin
	c= MEDYAN.Context(s,grid;diffusion_coeffs)
	chem_adddiffusingcount!(c,s.diffusing.a,1,2000)
	chem_adddiffusingcount!(c,s.diffusing.b,5,2000)
	setvisible!(vis["/Grid"], false)
	setvisible!(vis["/Axes"], false)
	setvisible!(vis["/Background"], false)
	MEDYAN.drawcontext!(vis, c, s)
	MEDYAN.run_chemistry!(c,0.1)
	#draw after
	setvisible!(vis2["/Grid"], false)
	setvisible!(vis2["/Axes"], false)
	setvisible!(vis2["/Background"], false)
	MEDYAN.drawcontext!(vis2, c, s)
	setvisible!(vis2["grid/inner"], false)
end

# ╔═╡ 402ea0a4-14f0-4d73-9b94-6051c7443327
render_static(vis)

# ╔═╡ 6fed52df-806d-42aa-9885-138f46aaa179
render_static(vis2)

# ╔═╡ Cell order:
# ╠═ba276b7b-f136-4799-b767-a6d72c6326eb
# ╠═3c59de85-df1e-4feb-a0e9-141b1dfa3537
# ╠═f67e304b-237f-444e-a707-b6614e4920f3
# ╠═1d7839da-973b-408c-b26e-0e5e1b04f3c5
# ╠═d83dd3e0-8fe7-4cab-a2c6-a6802edff167
# ╠═f16a9d89-9be6-4e60-86a4-53f15cac90ba
# ╠═c6f67756-6af8-4504-9619-e80b1934e0d5
# ╠═402ea0a4-14f0-4d73-9b94-6051c7443327
# ╠═6fed52df-806d-42aa-9885-138f46aaa179
# ╠═fe60f470-3752-11ec-1cf8-19ed0e8f245c
