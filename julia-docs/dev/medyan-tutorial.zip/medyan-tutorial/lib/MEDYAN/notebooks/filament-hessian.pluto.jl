### A Pluto.jl notebook ###
# v0.19.42

using Markdown
using InteractiveUtils

# ╔═╡ fe60f470-3752-11ec-1cf8-19ed0e8f245c
begin
	filter!(LOAD_PATH) do path
		path != "@v#.#"
	end;
    import Pkg
    # activate the shared project environment
    Pkg.activate(Base.current_project())
	Pkg.resolve()#update Manifest.toml based on MEDYAN Project.toml updates
	Pkg.instantiate()
	
	using Revise
    using MEDYAN
	using Colors
	using StaticArrays
	using LinearAlgebra
	using CairoMakie
	using Setfield
	md"Packages"
end

# ╔═╡ ba276b7b-f136-4799-b767-a6d72c6326eb
agentnames = MEDYAN.AgentNames(
	diffusingspeciesnames= [:a,],
	filamentnames= [(:actin,[
                            :plusend,
                            :minusend,
                            :middle,
                        ]),
	],
)

# ╔═╡ 3c59de85-df1e-4feb-a0e9-141b1dfa3537
grid= CubicGrid((2,2,2),5000.0)

# ╔═╡ 4e2803cb-f3bd-4103-a64a-563ac08f8bcc
function make_context(grid::CubicGrid; fila_params = MEDYAN.ACTIN_FIL_PARAMS)
    agent_names = MEDYAN.AgentNames(
        filamentnames= [(:actin,[
                                :a,
                                :restrained,
                            ]),
        ],
    )

    s= MEDYAN.SysDef(agent_names)

    add_filament_params!(s, 
        :actin,
        fila_params,
    )

    c = MEDYAN.Context(s,grid)
    c
end

# ╔═╡ b34be6aa-4098-43b2-a1ea-d79349c01807
default_params = MEDYAN.ACTIN_FIL_PARAMS

# ╔═╡ f142df19-f55b-483e-a767-bc7cd94e6fe4
nmons = round(Int, 1500/2.7)

# ╔═╡ ef4b0e29-ca88-42ca-b673-771b354e1299
begin
c = make_context(grid;fila_params=@set(default_params.numpercylinder=21))
	fid = MEDYAN.newfilament_rand!(c, ones(UInt8, nmons))
end

# ╔═╡ 3a16e5cf-021e-49f1-8e69-5a6f1535f391
begin
	fc = MEDYAN.ForceContext(c)
	H = MEDYAN.hessian!(fc, fc.x0)[3]
end;

# ╔═╡ a6e717b4-082c-4f72-9f00-fbaa50fd90f7
eigvals(H)

# ╔═╡ 24afdd4c-cbfa-415f-89c2-4f5477a0f91b
begin
	ev = abs.(eigvals(H))
	f,a,s = scatter(ev, 1:size(H,1))
	a.limits = ((1E-5,1E0), (1,20))
	a.xscale = log10
	f
end

# ╔═╡ Cell order:
# ╠═fe60f470-3752-11ec-1cf8-19ed0e8f245c
# ╠═ba276b7b-f136-4799-b767-a6d72c6326eb
# ╠═3c59de85-df1e-4feb-a0e9-141b1dfa3537
# ╠═4e2803cb-f3bd-4103-a64a-563ac08f8bcc
# ╠═b34be6aa-4098-43b2-a1ea-d79349c01807
# ╠═3a16e5cf-021e-49f1-8e69-5a6f1535f391
# ╠═a6e717b4-082c-4f72-9f00-fbaa50fd90f7
# ╠═f142df19-f55b-483e-a767-bc7cd94e6fe4
# ╠═24afdd4c-cbfa-415f-89c2-4f5477a0f91b
# ╠═ef4b0e29-ca88-42ca-b673-771b354e1299
