### A Pluto.jl notebook ###
# v0.19.11

using Markdown
using InteractiveUtils

# ╔═╡ fe60f470-3752-11ec-1cf8-19ed0e8f245c
begin
	filter!(LOAD_PATH) do path
		path != "@v#.#"
	end;
    import Pkg
    # activate the shared project environment
    Pkg.activate(Base.current_project())
	Pkg.resolve()#update Manifest.toml based on MEDYAN Project.toml updates
	Pkg.instantiate()
	
	using Revise
    using MEDYAN
	using MEDYANVis
	using Colors
	using StaticArrays
	md"Packages"
end

# ╔═╡ ba276b7b-f136-4799-b767-a6d72c6326eb
agentnames = MEDYAN.AgentNames(
	diffusingspeciesnames= [:a,],
	filamentnames= [(:actin,[
                            :plusend,
                            :minusend,
                            :middle,
							:restrained,
                        ]),
	],
	link_2mon_names= [:restraint,:rel]
)

# ╔═╡ 3c59de85-df1e-4feb-a0e9-141b1dfa3537
grid= CubicGrid((3,1,1),500.0)

# ╔═╡ a9291ffd-274a-4b73-9a99-e39d15bd11fd
boundingplanes = 0.01 .* [SA[-1.0,0.0,0.0,0.0],
	SA[1.0,0.0,0.0,1500],
	SA[0.0,-1.0,0.0,0.0],
	SA[0.0,1.0,0.0,500],
	SA[0.0,0.0,-1.0,0.0],
	SA[0.0,0.0,1.0,500]
]

# ╔═╡ a63c2946-a070-469b-9a33-c3a48185a66b
monomerspacing= 2.7

# ╔═╡ f67e304b-237f-444e-a707-b6614e4920f3
begin
	s= MEDYAN.SysDef(agentnames)
	#define restraints

	add_link_2mon!(s,
		:restraint,
		Link2MonState((;),(mr0 = zero(SVector{3,Float64}),mv̂0 = zero(SVector{3,Float64}))),
		MEDYAN.RestraintMechParams(kr=5.0,kv̂=2.0),
	)
	
	add_link_2mon!(s,
		:rel,
		Link2MonState(),
		MEDYAN.RelativeRestraintMechParams(kr=5.0,kv̂=2.0, pr0_mvxmpr= SA[0.0,2.7,0.0], pv̂0_mvxmpr=SA[0.0,1.0,0.0]),
	)
	
	#minus end polymerization
	addfilamentend_reaction!(s,
		:actin, #filament type name
		:pm, #new site name
		true, #is minus end
		[:minusend]=>[:minusend,:middle], #change in monomer states
		monomerspacing, #free space needed for reaction (nm)
		"diffusing.a -->", #reaction expression
		10E3, #rate of reaction ((nm^3)^(invvolumepower)/s)
		1, #inverse volume power
	)
	#plus end polymerization
	addfilamentend_reaction!(s, :actin, :pp, false,
		[:plusend]=>[:middle,:plusend], monomerspacing,
		"diffusing.a -->", 10E3, 1,
	)
	#minus end depolymerization
	addfilamentend_reaction!(s, :actin, :dpm, true,
		[:minusend,:middle]=>[:minusend], 0.0,
		"--> diffusing.a", 1.75E-3, 0,
	)
	#plus end depolymerization
	addfilamentend_reaction!(s, :actin, :dpp, false,
		[:middle,:plusend]=>[:plusend], 0.0,
		"--> diffusing.a", 1.75E-3, 0,
	)
end

# ╔═╡ 1d7839da-973b-408c-b26e-0e5e1b04f3c5
diffusion_coeffs= [1.0]

# ╔═╡ 4cce5141-e0f3-437a-bc6a-dde7b04a89d0
begin
	NMonomers= 30
	monomerstates= zeros(UInt8,NMonomers)
	monomerstates[1:end] .= s.state.actin.middle
	monomerstates[1] = s.state.actin.restrained
	monomerstates[end] = s.state.actin.plusend
	nodepositions= [SA[200.0,200,200],SA[200.0+NMonomers*monomerspacing,200.0,200.0]]
	filamentmechparams= [MEDYAN.ACTIN_FIL_PARAMS]
end

# ╔═╡ b168a723-7e06-4157-8368-294c2b175a80
vis = Visualizer()

# ╔═╡ 68a91291-c519-45bc-a3bc-6b08bf0b094c
vis2 = Visualizer()

# ╔═╡ ef4b0e29-ca88-42ca-b673-771b354e1299
begin
	delete!(vis)
	delete!(vis2)
	c= MEDYAN.Context(s,grid;diffusion_coeffs,filamentmechparams)
	set_mechboundary!(c; planes=boundingplanes)
	MEDYAN.adddiffusingcount_rand!(c, s.diffusing.a, 3000)
	fid1= MEDYAN.chem_newfilament!(c;
		ftid= s.filament.actin, 
		monomerstates,
		nodepositions,
		node_mids=[0,]
	)
	fid2= MEDYAN.chem_newfilament!(c;
		ftid= s.filament.actin, 
		monomerstates,
		nodepositions= nodepositions .+ (SA[0.0,100.0,100.0],),
		node_mids=[0,]
	)
	eqrv = mon_position_plusvector(c, MonomerName(s.filament.actin, fid1, 1))
	MEDYAN.chem_newlink_2mon!(c,
		s.link_2mon.restraint,#ltid 
		MonomerName(s.filament.actin, fid1, 1)=>
		MonomerName(s.filament.actin, fid1, 1);
		changedmechstate = (mr0 = eqrv[1], mv̂0 = eqrv[2]),
	)
	MEDYAN.chem_newlink_2mon!(c,
		s.link_2mon.rel,#ltid 
		MonomerName(s.filament.actin, fid1, 1)=>
		MonomerName(s.filament.actin, fid2, 1),
		# Link2MonState(
		# 	(;),
		# 	MEDYAN.RelativeRestraintData(SA[0.0,10.0,0.0],SA[1.0,0.0,0.0])
		# )
	)
	setvisible!(vis["/Grid"], false)
	setvisible!(vis["/Axes"], false)
	setvisible!(vis["/Background"], false)
	setvisible!(vis["mechboundary"], false)
	setvisible!(vis["diffusing"], false)
	nframes=20
	for i in 1:nframes
		draw_context!(vis, c, s)
		for j in 1:1000
			MEDYAN.run_chemistry!(c,2.0)
			MEDYAN.minimize_energy!(c)
		end
	end
	#draw after
	setvisible!(vis2["/Grid"], false)
	setvisible!(vis2["/Axes"], false)
	setvisible!(vis2["/Background"], false)
	draw_context!(vis2, c, s)
end

# ╔═╡ b67dc26f-e0e5-4ff8-b7c8-4f46ac207f4a
typeof(c.link_2mon_data)

# ╔═╡ a6fef778-a918-4db8-bbb9-e99c32e95225
MEDYAN.minimize_energy!(c)

# ╔═╡ ae68061e-fd8d-472f-9f70-259644efd5ba
c

# ╔═╡ e6a57b83-adc6-46be-b4e5-eeedcc26d4ff
c.chemistryengine.fixedcounts

# ╔═╡ 8080faa8-95a7-493c-821b-2367a5403e0b
render(vis)

# ╔═╡ 57eb0a7b-3038-4b79-b532-5324b778fd84
render(vis2)

# ╔═╡ 6f919103-2948-427a-91a5-9586e91f24ab
boundingplanes

# ╔═╡ Cell order:
# ╠═ba276b7b-f136-4799-b767-a6d72c6326eb
# ╠═3c59de85-df1e-4feb-a0e9-141b1dfa3537
# ╠═a9291ffd-274a-4b73-9a99-e39d15bd11fd
# ╠═a63c2946-a070-469b-9a33-c3a48185a66b
# ╠═f67e304b-237f-444e-a707-b6614e4920f3
# ╠═1d7839da-973b-408c-b26e-0e5e1b04f3c5
# ╠═4cce5141-e0f3-437a-bc6a-dde7b04a89d0
# ╠═b67dc26f-e0e5-4ff8-b7c8-4f46ac207f4a
# ╠═ef4b0e29-ca88-42ca-b673-771b354e1299
# ╠═b168a723-7e06-4157-8368-294c2b175a80
# ╠═a6fef778-a918-4db8-bbb9-e99c32e95225
# ╠═ae68061e-fd8d-472f-9f70-259644efd5ba
# ╠═e6a57b83-adc6-46be-b4e5-eeedcc26d4ff
# ╠═68a91291-c519-45bc-a3bc-6b08bf0b094c
# ╠═8080faa8-95a7-493c-821b-2367a5403e0b
# ╠═57eb0a7b-3038-4b79-b532-5324b778fd84
# ╠═fe60f470-3752-11ec-1cf8-19ed0e8f245c
# ╠═6f919103-2948-427a-91a5-9586e91f24ab
