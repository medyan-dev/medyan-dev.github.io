### A Pluto.jl notebook ###
# v0.19.8

using Markdown
using InteractiveUtils

# ╔═╡ fe60f470-3752-11ec-1cf8-19ed0e8f245c
begin
	filter!(LOAD_PATH) do path
		path != "@v#.#"
	end;
    import Pkg
    # activate the shared project environment
    Pkg.activate(Base.current_project())
	Pkg.resolve()#update Manifest.toml based on MEDYAN Project.toml updates
	Pkg.instantiate()
	
	using Revise
    using MEDYAN
	using MeshCat
	using Colors
	using StaticArrays
	using Dictionaries
	using Setfield
	using LinearAlgebra
	md"Packages"
end

# ╔═╡ b168a723-7e06-4157-8368-294c2b175a80
vis = Visualizer()

# ╔═╡ cc4f7410-0f72-4910-9c4a-c4fe7d475267
begin
	DM = MEDYAN.DynamicHalfedgeMesh
    DA = MEDYAN.DefaultHalfedgeMeshElementAttr
    VA = @NamedTuple{
        coord::SVector{3, Float64},
        ada_unitnormal::SVector{3, Float64},
    }
    HA = @NamedTuple{
        θ::Float64,
        cotθ::Float64,
    }
    EA = @NamedTuple{
        ada_eqlength::Float64,
    }
    TA = @NamedTuple{
        unitnormal::SVector{3, Float64},
    }

	splitfunc!(m, e::MEDYAN.IE) = MEDYAN.insert_vertex_onedge!(MEDYAN.default_initattr!, m, e)
	collapsefunc!(m, h::MEDYAN.IH) = MEDYAN.collapse_halfedge!(m, h)
	flipfunc!(m, e::MEDYAN.IE) = MEDYAN.flip_edge!(m, e)
	relocfunc!(m, v::MEDYAN.IV, c) = m.vertices.attr.coord[v.value] = c

	m1 = let
		local m = DM(VA, HA, EA, TA, DA, nothing)

		# Octahedron.
		local r = 100
		MEDYAN.initmesh!_vertex_triangle(m, 6, [SA[1,2,3], SA[1,3,4], SA[1,4,5], SA[1,5,2], SA[6,5,4], SA[6,4,3], SA[6,3,2], SA[6,2,5]])
		m.vertices.attr.coord[1] = SA[0, 0, r]
		m.vertices.attr.coord[2] = SA[0, r, 0]
		m.vertices.attr.coord[3] = SA[-r, 0, 0]
		m.vertices.attr.coord[4] = SA[0, -r, 0]
		m.vertices.attr.coord[5] = SA[r, 0, 0]
		m.vertices.attr.coord[6] = SA[0, 0, -r]

		MEDYAN.adaptmesh!(splitfunc!, collapsefunc!, flipfunc!, relocfunc!, m, MEDYAN.MeshAdaptParams())
		m
	end

	m2 = let
		local m = DM(VA, HA, EA, TA, DA, nothing)

		# Two triangles.
		local sz = 90
		MEDYAN.initmesh!_vertex_triangle(m, 4, [SA[1,2,3], SA[3,2,4]])
		m.vertices.attr.coord[1] = SA[-1, -1, 0] * sz
		m.vertices.attr.coord[2] = SA[2, 0, 0] * sz
		m.vertices.attr.coord[3] = SA[0, 2, 0] * sz
		m.vertices.attr.coord[4] = SA[2, 2, 2] * sz

		MEDYAN.adaptmesh!(splitfunc!, collapsefunc!, flipfunc!, relocfunc!, m, MEDYAN.MeshAdaptParams())
		m
	end
	
	MEDYAN.drawhalfedgemeshes!(vis, (m1,m2); scale=1e-3)
end

# ╔═╡ Cell order:
# ╠═b168a723-7e06-4157-8368-294c2b175a80
# ╠═fe60f470-3752-11ec-1cf8-19ed0e8f245c
# ╠═cc4f7410-0f72-4910-9c4a-c4fe7d475267
