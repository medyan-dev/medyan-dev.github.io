### A Pluto.jl notebook ###
# v0.18.1

using Markdown
using InteractiveUtils

# ╔═╡ fe60f470-3752-11ec-1cf8-19ed0e8f245c
begin
	filter!(LOAD_PATH) do path
		path != "@v#.#"
	end;
    import Pkg
    # activate the shared project environment
    Pkg.activate(Base.current_project())
	Pkg.resolve()#update Manifest.toml based on MEDYAN Project.toml updates
	Pkg.instantiate()
	
	using Revise
    using MEDYAN
	using Colors
	using StaticArrays
	using LinearAlgebra
	using Dictionaries
	using ForwardDiff
	using Setfield
	using Plots
	md"Packages"
end

# ╔═╡ 58c39eab-533b-4c00-a0fa-71993e0736c5
plotly()

# ╔═╡ 7d5ef444-390b-4d61-883b-998c9147996e
plotattr(:Axis)

# ╔═╡ 8f206981-7ad9-497e-8070-d9bc8b3744cb
θ = 90*pi/180

# ╔═╡ 6f1f9066-f49a-4484-b9ea-0726056b8403
L = 10.0

# ╔═╡ a231f195-b821-49a9-a798-a9a6f3a0078d
1/(10*L)^2

# ╔═╡ 0994097f-67e9-4671-a793-8fb2998662df
function plotenergy(f,L)
	x = SA[1.0,0.0,0.0]
	y = SA[0.0,1.0,0.0]
	z = SA[0.0,0.0,1.0]
	c1 = L/2*x
	rs = range(start=0.0,stop=10.0,length=1000)
	Essr = []
	for θ in range(start=0.0,stop=pi/2,length=10)
		c2 = L/2*cos(θ)*x + L/2*sin(θ)*z
		Es = [f(-c1, c1, r*y - c2 ,r*y + c2) for r in rs]
		push!(Essr,Es)
	end
	θs = range(start=0.0,stop=pi/2,length=1000)
	Essθ = []
	for r in range(start=0.0,stop=10.0,length=20)
		c2s = [L/2*cos(θ)*x + L/2*sin(θ)*z for θ in θs]
		Es = [f(-c1, c1, r*y - c2 ,r*y + c2) for c2 in c2s]
		push!(Essθ,Es)
	end
	rplot = plot(rs,Essr; 
		xlims = (0,7),
		xticks = 0:0.5:10,
		ylims = (0,10),
	)
	θplot = plot(θs,Essθ; 
		xlims = (0,pi/2),
		ylims = (0,10),
	)
	plot(rplot, θplot, layout=(1,2))
end
	

# ╔═╡ 1a2ef36c-aaff-42bf-89e6-fc074998b860
plotenergy(L) do a,b,c,d
	MEDYAN.cylinder_repulsion1(a,b,c,d,30.0,L,L)
end

# ╔═╡ 7e6bb91b-394d-4a83-a03a-3d2d7af7314e
plotenergy(L) do a,b,c,d
	MEDYAN.cylinder_repulsion2(a,b,c,d,2E-2,6.0)
end

# ╔═╡ 3b6628ed-4822-421f-99d1-7e635840dbef
plotenergy(L) do a,b,c,d
	MEDYAN.cylinder_repulsion3(a,b,c,d,2.0E-2,6.0)
end

# ╔═╡ 119a22ca-80bb-41e9-ba15-12e3a2e6b9c3
plotenergy(L) do a,b,c,d
	MEDYAN.cylinder_repulsion4(a,b,c,d,4.0E-2,6.0)
end

# ╔═╡ c8da4e14-96b0-4870-b63d-8e7d53fa9f53
plotenergy(10*L) do a,b,c,d
	MEDYAN.cylinder_repulsion5(a,b,c,d,2.0,6.0,1E-5)
end

# ╔═╡ a4878e53-cbab-44b4-9c40-88fcce899518
plotenergy(10L) do a,b,c,d
	MEDYAN.cylinder_repulsion6(a,b,c,d,2.0,6.0,1E-5)
end

# ╔═╡ c3b55f25-6081-44ab-be29-8048c6dcdc0b
plotenergy(L) do a,b,c,d
	MEDYAN.cylinder_repulsion7(a,b,c,d,0.1,6.0,1E-3)
end

# ╔═╡ 75bdb9c2-c5be-466d-8970-ea9ffd3c83e7
plotenergy(10*L) do a,b,c,d
	MEDYAN.cylinder_repulsion8(a,b,c,d,2.0,6.0)
end

# ╔═╡ 2c99dbd0-b88c-49a8-98cd-b80bc22ec2e4
plotenergy(10*L) do a,b,c,d
	50*MEDYAN.cylinder_repulsion9(a,b,c,d,1/3.0)
end

# ╔═╡ 2ff102bf-c2ac-4633-a533-f1bc8aba9ecd
function normhessian(f,a,b,c,d)
	vectorf(x) = f(x[1:3],x[4:6],x[7:9],x[10:12])
	x0 = Array(vcat(a,b,c,d)) + 0.001*randn(12)
	g0 = ForwardDiff.gradient(vectorf,x0)
	Δgs = zeros(12,12)
	scale = 0.1
	for i in 1:12
		newx = copy(x0)
		newx[i] += 0.1
		Δgs[:,i] = ForwardDiff.gradient(vectorf,newx) - g0
	end
	norm(Δgs)/scale
	# h = ForwardDiff.hessian(vectorf,x0)
	# if norm(h-h') > 1E-10
	# 	println(norm(h-h'))
	# end
	# norm(h)
end

# ╔═╡ 845f4c9d-760f-4fbb-8d0e-9289366f51e0
function plotenergyvsnormhessian(f,L)
	x = SA[1.0,0.0,0.0]
	y = SA[0.0,1.0,0.0]
	z = SA[0.0,0.0,1.0]
	c1 = L/2*x
	Es = []
	eigs = []
	for θ in range(start=0.0,stop=pi/2,length=100)
		c2 = L/2*cos(θ)*x + L/2*sin(θ)*z
		for r in range(start=0.0,stop=10.0,length=50)
			E = f(-c1, c1, r*y - c2 ,r*y + c2)
			if E ≤ 10
				eig = normhessian(f,-c1, c1, r*y - c2 ,r*y + c2)
				push!(Es,E)
				push!(eigs,eig)
			end
		end
	end
	scatter(Es,eigs; 
		xlims = (0,10),
	)
end

# ╔═╡ c7074d54-a726-4c21-b216-c3c336de3d31
plotenergyvsnormhessian(L) do a,b,c,d
	MEDYAN.cylinder_repulsion1(a,b,c,d,60.0,L,L)
end

# ╔═╡ f0e50469-aec7-46b1-8031-240d3ae68452
plotenergyvsnormhessian(10*L) do a,b,c,d
	MEDYAN.cylinder_repulsion5(a,b,c,d,2.0,6.0,1E-5)
end

# ╔═╡ 44ac5ee1-d1c7-4c79-aeb2-dc47689aca42
plotenergyvsnormhessian(10L) do a,b,c,d
	MEDYAN.cylinder_repulsion6(a,b,c,d,2.0,6.0,1E-5)
end

# ╔═╡ 314ee23c-dc3d-4764-a890-2b856633c86f
plotenergyvsnormhessian(L) do a,b,c,d
	MEDYAN.cylinder_repulsion7(a,b,c,d,0.1,6.0,1E-3)
end

# ╔═╡ 4bc57723-8150-4ea5-9a9e-900d8d9c195c
plotenergyvsnormhessian(10*L) do a,b,c,d
	MEDYAN.cylinder_repulsion8(a,b,c,d,2.0,6.0)
end

# ╔═╡ 5a5c36c7-5a23-4c61-978f-eeb103890185
plotenergyvsnormhessian(10*L) do a,b,c,d
	MEDYAN.cylinder_repulsion9(a,b,c,d,3.0,6.0)
end

# ╔═╡ e7a06389-e9ad-4e53-a29c-22aea49798e0


# ╔═╡ Cell order:
# ╠═58c39eab-533b-4c00-a0fa-71993e0736c5
# ╠═1a2ef36c-aaff-42bf-89e6-fc074998b860
# ╠═c7074d54-a726-4c21-b216-c3c336de3d31
# ╠═7e6bb91b-394d-4a83-a03a-3d2d7af7314e
# ╠═3b6628ed-4822-421f-99d1-7e635840dbef
# ╠═119a22ca-80bb-41e9-ba15-12e3a2e6b9c3
# ╠═c8da4e14-96b0-4870-b63d-8e7d53fa9f53
# ╠═f0e50469-aec7-46b1-8031-240d3ae68452
# ╠═a231f195-b821-49a9-a798-a9a6f3a0078d
# ╠═a4878e53-cbab-44b4-9c40-88fcce899518
# ╠═44ac5ee1-d1c7-4c79-aeb2-dc47689aca42
# ╠═c3b55f25-6081-44ab-be29-8048c6dcdc0b
# ╠═314ee23c-dc3d-4764-a890-2b856633c86f
# ╠═75bdb9c2-c5be-466d-8970-ea9ffd3c83e7
# ╠═4bc57723-8150-4ea5-9a9e-900d8d9c195c
# ╠═2c99dbd0-b88c-49a8-98cd-b80bc22ec2e4
# ╠═5a5c36c7-5a23-4c61-978f-eeb103890185
# ╠═7d5ef444-390b-4d61-883b-998c9147996e
# ╠═8f206981-7ad9-497e-8070-d9bc8b3744cb
# ╠═6f1f9066-f49a-4484-b9ea-0726056b8403
# ╠═0994097f-67e9-4671-a793-8fb2998662df
# ╠═2ff102bf-c2ac-4633-a533-f1bc8aba9ecd
# ╠═845f4c9d-760f-4fbb-8d0e-9289366f51e0
# ╠═fe60f470-3752-11ec-1cf8-19ed0e8f245c
# ╠═e7a06389-e9ad-4e53-a29c-22aea49798e0
