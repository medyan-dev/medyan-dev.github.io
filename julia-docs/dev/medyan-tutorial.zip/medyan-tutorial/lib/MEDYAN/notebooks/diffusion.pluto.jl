### A Pluto.jl notebook ###
# v0.19.9

using Markdown
using InteractiveUtils

# ╔═╡ fe60f470-3752-11ec-1cf8-19ed0e8f245c
begin
	filter!(LOAD_PATH) do path
		path != "@v#.#"
	end;
    import Pkg
    # activate the shared project environment
    Pkg.activate(Base.current_project())
	Pkg.resolve()#update Manifest.toml based on MEDYAN Project.toml updates
	Pkg.instantiate()
	
	using Revise
    using MEDYAN
	using MeshCat
	md"Packages"
end

# ╔═╡ ba276b7b-f136-4799-b767-a6d72c6326eb
agentnames = MEDYAN.AgentNames(
	diffusingspeciesnames= [:a,:b,:c],
)

# ╔═╡ 3c59de85-df1e-4feb-a0e9-141b1dfa3537
grid= CubicGrid((10,10,10),500.0)

# ╔═╡ f67e304b-237f-444e-a707-b6614e4920f3
begin
	s= MEDYAN.SysDef(agentnames)
	add_diffusion_coeff!(s, :a, 1.0E6)
	add_diffusion_coeff!(s, :b, 4.0E6)
	add_diffusion_coeff!(s, :c, 9.0E6)
end

# ╔═╡ b168a723-7e06-4157-8368-294c2b175a80
vis = Visualizer()

# ╔═╡ 68a91291-c519-45bc-a3bc-6b08bf0b094c
vis2 = Visualizer()

# ╔═╡ ef4b0e29-ca88-42ca-b673-771b354e1299
begin
	c= MEDYAN.Context(s,grid)
	
	MEDYAN.setdiffusingspeciescount!(c.chemistryengine,s.diffusing.a, 1,2000)
	MEDYAN.setdiffusingspeciescount!(c.chemistryengine,s.diffusing.b, 1,2000)
	MEDYAN.setdiffusingspeciescount!(c.chemistryengine,s.diffusing.c, 1,2000)
	setvisible!(vis["/Grid"], false)
	setvisible!(vis["/Axes"], false)
	setvisible!(vis["/Background"], false)
	MEDYAN.drawdiffusing!(vis["diffusing"], c.grid, c.chemistryengine, s)
	MEDYAN.run_chemistry!(c,0.1)
	#draw after
	setvisible!(vis2["/Grid"], false)
	setvisible!(vis2["/Axes"], false)
	setvisible!(vis2["/Background"], false)
	MEDYAN.drawdiffusing!(vis2["diffusing"], c.grid, c.chemistryengine, s)
	setvisible!(vis2["grid/inner"], false)
end

# ╔═╡ 8080faa8-95a7-493c-821b-2367a5403e0b
render_static(vis)

# ╔═╡ 57eb0a7b-3038-4b79-b532-5324b778fd84
render_static(vis2)

# ╔═╡ Cell order:
# ╠═ba276b7b-f136-4799-b767-a6d72c6326eb
# ╠═3c59de85-df1e-4feb-a0e9-141b1dfa3537
# ╠═f67e304b-237f-444e-a707-b6614e4920f3
# ╠═ef4b0e29-ca88-42ca-b673-771b354e1299
# ╠═b168a723-7e06-4157-8368-294c2b175a80
# ╠═68a91291-c519-45bc-a3bc-6b08bf0b094c
# ╠═8080faa8-95a7-493c-821b-2367a5403e0b
# ╠═57eb0a7b-3038-4b79-b532-5324b778fd84
# ╠═fe60f470-3752-11ec-1cf8-19ed0e8f245c
