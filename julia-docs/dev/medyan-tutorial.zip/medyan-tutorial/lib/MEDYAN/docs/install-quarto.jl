#!/bin/env julia
using Pkg.Artifacts
using ArtifactUtils: add_artifact!

# Run this script to update the version of quarto

# This is the path to the Artifacts.toml we will manipulate
artifact_toml = joinpath(@__DIR__, "Artifacts.toml")

version = "1.3.450"
quarto_url = "https://github.com/quarto-dev/quarto-cli/releases/download/v$(version)/quarto-$(version)-linux-amd64.tar.gz"

add_artifact!(artifact_toml, "quarto", quarto_url;
    force=true,
)