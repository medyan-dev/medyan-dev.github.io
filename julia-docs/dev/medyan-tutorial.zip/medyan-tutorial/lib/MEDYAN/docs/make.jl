#!/bin/env julia
#
# preview documentation.
# Invoke this script directly, `./docs/make.jl`
# or via `julia --project=docs docs/make.jl` to avoid 
# installing the project.
# Add Command line arg render to render the docs 
# instead of previewing them.

using Pkg: Pkg, PackageSpec
using Pkg.Artifacts: @artifact_str

function quarto()
    if Sys.MACHINE == "x86_64-linux-gnu"
        a = readdir(artifact"quarto")[1]
        joinpath(artifact"quarto", a, "bin", "quarto")
    else
        @warn "quarto must be manually installed on the path"
        "quarto"
    end
end

# Copied from https://github.com/JuliaIO/HDF5.jl/pull/1020
# Install the project if not the current project environment
if Base.active_project() != joinpath(@__DIR__, "Project.toml")
    Pkg.activate(@__DIR__)
    Pkg.develop([
        PackageSpec(path=relpath(dirname(@__DIR__))),
        PackageSpec(path=relpath(dirname(@__DIR__))*"/lib/MEDYANVis"),
    ])
    @info "instantiating docs environment"
    Pkg.instantiate()
    @info "building IJulia"
    Pkg.build("IJulia")
    @info "importing MEDYAN"
    import MEDYAN
    using QMDDocTools
    using CondaPkg
    @info "installing quarto extensions"
    QMDDocTools_version = Pkg.dependencies()[Pkg.project().dependencies["QMDDocTools"]].version
    cd(@__DIR__) do
        CondaPkg.withenv() do
            # add the lua filter with the correct version
            run(`$(quarto()) add medyan-dev/QMDDocTools.jl@v$(QMDDocTools_version) --no-prompt`)
        end
    end
else
    import MEDYAN
    using QMDDocTools
    using CondaPkg
end



include("make-docstrings.jl")
cd(@__DIR__) do
    CondaPkg.withenv() do
        if length(ARGS) == 0
            run(`$(quarto()) preview`)
        else
            run(`$(quarto()) render`)
        end
    end
end

if length(ARGS) != 0
    # Zip MEDYAN, Manifest, Project files so they can be downloaded.
    import ZipArchives
    import TOML
    let 
        # read the manifest and project files as strings
        local manifest = read(joinpath(@__DIR__,"Manifest.toml"), String)
        local project = read(joinpath(@__DIR__,"Project.toml"), String)

        # Now do something super hacky and replace the parent path with a path to lib/MEDYAN.

        local manifest_data = TOML.parse(manifest)

        # local sha = readchomp(`git rev-parse HEAD`)

        manifest_data["deps"]["MEDYAN"][1]["path"] = "lib/MEDYAN"
        manifest_data["deps"]["MEDYANVis"][1]["path"] = "lib/MEDYAN/lib/MEDYANVis"

        ZipArchives.ZipWriter(joinpath(@__DIR__,"_site","medyan-tutorial.zip")) do w
            ZipArchives.zip_newfile(w, "medyan-tutorial/Manifest.toml"; compress=true)
            TOML.print(w, manifest_data; sorted=true)
            ZipArchives.zip_newfile(w, "medyan-tutorial/Project.toml"; compress=true)
            write(w, project)
            # Now copy MEDYAN tracked files into lib/MEDYAN
            @info "copy in MEDYAN"
            cd(@__DIR__) do 
                # https://stackoverflow.com/a/55081559/10802538
                local filenames = readlines(`git ls-tree --full-tree --name-only -r HEAD`)
                for filename in filenames
                    local zip_prefix = "medyan-tutorial/lib/MEDYAN/"
                    local real_prefix = dirname(pwd())
                    ZipArchives.zip_newfile(w, zip_prefix*filename; compress=true)
                    open(joinpath(real_prefix,filename)) do io
                        write(w, io)
                    end
                end
            end
        end
    end
    @info "copy in license"
    cp(joinpath(dirname(@__DIR__),"license.txt"), joinpath(@__DIR__,"_site","license.txt"); force=true)
    using Documenter
    deploydocs(;
        dirname = "julia-docs",
        target = "_site",
        branch = "main",
        repo="github.com/medyan-dev/medyan-dev.github.io.git",
        devbranch = "master",
        deploy_config=Documenter.GitHubActions(
            "medyan-dev/medyan-dev.github.io",
            get(ENV, "GITHUB_EVENT_NAME", ""),
            get(ENV, "GITHUB_REF",        ""),
        ),
    )
end