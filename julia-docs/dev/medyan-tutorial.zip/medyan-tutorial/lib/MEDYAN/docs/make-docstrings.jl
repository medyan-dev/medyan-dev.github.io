import MEDYAN
using QMDDocTools


gen_docstrings(MEDYAN; outdir = @__DIR__)