
struct Monomer
    state::UInt8
    pos::SVector{3,Float32}
    plusvec::SVector{3,Float32}
end

@kwdef struct FilamentData
    first_monomer_ids::Vector{Int64} = []
    monomers::Vector{Vector{Monomer}} = []
    node_pos::Vector{SVector{3,Float32}} = []
    node_bend_angles::Vector{Float32} = [] # in radians, 0 is no bend.
    node_ranges::Vector{UnitRange{Int64}} = []
end

@kwdef struct MembraneData
    typeid::Int
    trilist::Vector{SVector{3,Int32}} = []
    vert_coords::Vector{SVector{3,Float32}} = []
    vert_copynumbers::Union{ElasticMatrix{Int32}, Nothing} = nothing
end

@kwdef struct TagData
    generations::Vector{UInt32}
    positions::Vector{SVector{3,Float32}} = []
end

struct LinkData
    # each column is one place, NaN if not attached
    positions::Matrix{SVector{3,Float32}}
end
